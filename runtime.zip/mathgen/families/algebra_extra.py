"""Additional integer inequalities, rounding, and exponent identities."""

from fractions import Fraction
from math import ceil, floor, isqrt
import re

from mathgen.families.algebra import (
    _LiteralParameters,
    _MATH_BLOCK,
    _MathParser,
    _affine,
    _bounded_case,
    _evaluate,
    _expression_template,
    _math_body,
    _tex,
    _tex_polynomial,
    _variables,
)


class _RoundParser(_MathParser):
    _groups = {r"\lfloor": (r"\rfloor", "floor"), r"\lceil": (r"\rceil", "ceil"),
               "|": ("|", "abs"), r"\lvert": (r"\rvert", "abs")}

    def _atom(self, freeze):
        token = self._peek()
        if token not in self._groups:
            return super()._atom(freeze)
        self._take(token)
        end, operation = self._groups[token]
        node = self._expr(0, freeze)
        self._take(end)
        return self._powered((operation, node))


def _rounded_root(value, upper, reference):
    if value < 0:
        raise ValueError("negative square root")
    if reference:
        lo, hi = 0, 1
        while hi * hi <= value:
            hi *= 2
        while hi - lo > 1:
            mid = (lo + hi) // 2
            if mid * mid <= value:
                lo = mid
            else:
                hi = mid
    else:
        lo = isqrt(floor(value))
    return lo + int(upper and lo * lo != value)


def _round_node(node, values, reference):
    operator = node[0]
    if operator in ("const", "literal", "var"):
        return node
    child = node[1]
    if operator in ("floor", "ceil"):
        negative = child[0] == "neg"
        radical = child[1] if negative else child
        if radical[0] == "sqrt":
            radicand = _evaluate(_round_node(radical[1], values, reference), values, {}, {})
            value = _rounded_root(radicand, (operator == "ceil") != negative, reference)
            return "const", Fraction(-value if negative else value)
        value = _evaluate(_round_node(child, values, reference), values, {}, {})
        return "const", Fraction((floor if operator == "floor" else ceil)(value))
    if operator == "abs":
        return "const", abs(_evaluate(_round_node(child, values, reference), values, {}, {}))
    if operator in ("neg", "sqrt"):
        return operator, _round_node(child, values, reference)
    return operator, _round_node(child, values, reference), _round_node(node[2], values, reference)


def _round_evaluation(row):
    problem = row["problem"]
    if r"\lceil" not in problem and r"\lfloor" not in problem:
        return None
    if not re.fullmatch(r"(?i)(?:evaluate|compute)(?: the expression)?\s*@\s*[.?!]?\s*",
                        _MATH_BLOCK.sub("@", problem)):
        return None
    ties = {"algebra/test/1093": (1, 2), "algebra/train/1536": ((1, 3), (2, 4)),
            "algebra/test/995": (1, 4)}
    params = _LiteralParameters(ties.get(row["id"], ()))
    try:
        expression, names = params.parse(*_math_body(next(_MATH_BLOCK.finditer(problem))),
                                         parser=_RoundParser)
    except (ValueError, RecursionError):
        return None

    def compute(p, reference=False):
        values = params.values(names, p)
        return _evaluate(_round_node(expression, values, reference), values, {}, {})

    return _expression_template(
        "algebra.rounded_expression", problem, params, compute,
        lambda p: compute(p, reference=True),
        ["Every square root must have a nonnegative radicand. An irrational square root "
         "must appear immediately inside its floor or ceiling, with optional negation."],
        arithmetic_constraint="Every denominator must be nonzero.",
    )


# Explicit bindings disambiguate the requested statistic and the integer domain.
_AFFINE_CASES = {
    "prealgebra/train/183": ("first", None),
    "prealgebra/train/251": ("last", None),
    "prealgebra/train/255": ("last", None),
    "prealgebra/train/397": ("last", 0),
    "prealgebra/train/417": ("unique", None),
    "prealgebra/train/480": ("last", 0),
    "prealgebra/train/734": ("sum", None),
    "prealgebra/train/847": ("last", None),
    "prealgebra/train/1137": ("count", 1),
    "prealgebra/test/90": ("last", None),
    "prealgebra/test/111": ("last", None),
    "prealgebra/test/149": ("unique", None),
    "prealgebra/test/234": ("sum", 1),
    "prealgebra/test/236": ("unique", None),
    "prealgebra/test/237": ("unique", None),
    "prealgebra/test/312": ("count", 1),
    "prealgebra/test/325": ("first", 1),
    "prealgebra/test/869": ("count", None),
}
_INEQUALITY = re.compile(r"\\leq?(?![A-Za-z])|\\geq?(?![A-Za-z])|[<>]")


def _affine_inequality(problem, operation, minimum):
    params = _LiteralParameters()
    expressions = []
    variables = set()
    try:
        for block in _MATH_BLOCK.finditer(problem):
            source, offset = _math_body(block)
            comparisons = list(_INEQUALITY.finditer(source))
            if not comparisons:
                continue
            start = 0
            clauses = []
            for match in comparisons:
                clauses.append(params.parse(source[start:match.start()], offset + start))
                start = match.end()
            clauses.append(params.parse(source[start:], offset + start))
            for tree, _ in clauses:
                variables.update(_variables(tree))
            for left, right, comparison in zip(clauses, clauses[1:], comparisons):
                operator = comparison.group()
                strict = operator in ("<", ">")
                expressions.append((right, left, strict) if "g" in operator or operator == ">"
                                   else (left, right, strict))
    except ValueError:
        return None
    if len(variables) != 1 or not expressions:
        return None
    variable, = variables

    def inequalities(p):
        rows = []
        for (a, a_nums), (b, b_nums), strict in expressions:
            lhs = _affine(a, params.values(a_nums, p), [variable])
            rhs = _affine(b, params.values(b_nums, p), [variable])
            rows.append((lhs[0] - rhs[0], lhs[1] - rhs[1], strict))
        return rows

    def bounds(p):
        low, high = minimum, None
        for a, b, strict in inequalities(p):
            if not a:
                if b > 0 or (b == 0 and strict):
                    return 1, 0
                continue
            root = -b / a
            if abs(root) > 2000:
                raise ValueError("root exceeds the reference search bound")
            if a > 0:
                candidate = ceil(root) - 1 if strict else floor(root)
                high = candidate if high is None else min(high, candidate)
            else:
                candidate = floor(root) + 1 if strict else ceil(root)
                low = candidate if low is None else max(low, candidate)
        return low, high

    def solve(p):
        low, high = bounds(p)
        if operation == "first" and low is not None and (high is None or low <= high):
            return low
        if operation == "last" and high is not None and (low is None or low <= high):
            return high
        if low is not None and high is not None:
            length = max(0, high - low + 1)
            if operation == "unique" and length == 1:
                return low
            if operation == "sum":
                return (low + high) * length // 2
            if operation == "count":
                return length
        raise ValueError("requested statistic is undefined or non-unique")

    def reference(p):
        rows = [(a.numerator * b.denominator, b.numerator * a.denominator, strict)
                for a, b, strict in inequalities(p)]
        candidates = [
            n for n in range(-2001 if minimum is None else minimum, 2002)
            if all(a * n + b < 0 if strict else a * n + b <= 0 for a, b, strict in rows)
        ]
        if operation in ("first", "unique"):
            return candidates[0]
        if operation == "last":
            return candidates[-1]
        return sum(candidates) if operation == "sum" else len(candidates)

    return _expression_template(
        "algebra.affine_integer_inequality." + operation, problem, params, solve, reference,
        ["All finite boundaries have magnitude at most 2000. The requested statistic "
         "exists and is unique, including a unique integer where the question asks for one."],
    )


_POWER_INEQUALITIES = {
    "algebra/train/127": (200, 900, 2, True, False),
    "algebra/train/281": (100, 200, 2, True, True),
    "intermediate_algebra/train/760": (-50, 50, 3, False, False),
    "intermediate_algebra/train/979": (10, 99, 2, False, False),
}


def _power_inequality(case):
    a, b, exponent, positive, inclusive = case

    def render(p):
        operator = r"\le " if inclusive else "<"
        domain = "positive integers" if positive else "integers"
        return f"How many {domain} $n$ satisfy ${p['low']}{operator}n^{exponent}{operator}{p['high']}$?"

    def count_nonnegative_up_to(n):
        if n < 0:
            return 0
        if exponent == 2:
            return isqrt(n) + 1
        low, high = 0, n + 1
        while high - low > 1:
            mid = (low + high) // 2
            if mid ** exponent <= n:
                low = mid
            else:
                high = mid
        return low + 1

    def nonnegative(a, b):
        return count_nonnegative_up_to(b) - count_nonnegative_up_to(a - 1)

    def solve(p):
        a, b = p["low"], p["high"]
        if not inclusive:
            a, b = a + 1, b - 1
        if a > b:
            return 0
        if positive:
            return nonnegative(max(1, a), b)
        if exponent % 2:
            return nonnegative(a, b) + nonnegative(max(1, -b), -a) if a <= -1 else nonnegative(a, b)
        return nonnegative(a, b) + nonnegative(max(1, a), b)

    def reference(p):
        a, b = p["low"], p["high"]
        candidates = range(1 if positive else -40, 41)
        return sum(a <= n**exponent <= b if inclusive else a < n**exponent < b for n in candidates)

    return _bounded_case(
        "algebra.power_integer_inequality", [
            ("low", a, -100 if exponent == 3 else 0, 300),
            ("high", b, 10, 1200),
        ], render, solve, reference, lambda p: p["low"] < p["high"],
        ["The lower endpoint is strictly smaller than the upper endpoint."],
    )


_FACTOR_INEQUALITIES = {
    "algebra/train/26": ((3, 8), "greatest", True, "expanded"),
    "algebra/train/206": ((-4, 2), "count", False, "factored"),
    "algebra/train/270": ((0, 7), "count", False, "opposed"),
    "algebra/test/1020": ((-5, 5), "least", False, "mirrored"),
    "intermediate_algebra/train/1027": ((-8, 3, 12), "positive_count", False, "factored"),
    "intermediate_algebra/train/1130": ((-8, -4, 2), "bounded_count", False, "factored"),
}


def _factor_inequality(case):
    roots, task, inclusive, shape = case
    entries = [("radius", roots[-1], 2, 22)] if shape == "mirrored" else [
        (f"root_{index}", root, 0 if shape == "opposed" and index == 1 else -25,
         0 if shape == "opposed" and index == 1 else 25)
        for index, root in enumerate(roots, 1)
    ]
    if task == "bounded_count":
        entries.extend([("lower", -11, -30, 10), ("upper", 11, -10, 30)])

    def get_roots(p):
        if shape == "mirrored":
            return (-p["radius"], p["radius"])
        return tuple(p[f"root_{index}"] for index in range(1, len(roots) + 1))

    def render(p):
        values = get_roots(p)
        if shape == "expanded":
            a, b = values
            expression = _tex_polynomial([a * b, -a - b, 1]) + r"\le 0"
        elif shape == "opposed":
            expression = rf"x^2<{_tex_polynomial([0, values[1]])}"
        else:
            expression = "".join(f"({_tex_polynomial([-root, 1])})" for root in values) + "<0"
        if task == "bounded_count":
            domain = rf"integers ${p['lower']}\le x\le {p['upper']}$"
        else:
            domain = "positive integers $x$" if task == "positive_count" else "integers $x$"
        if task in ("least", "greatest"):
            return f"What is the {task} integer $x$ satisfying ${expression}$?"
        return f"How many {domain} satisfy ${expression}$?"

    def intervals(p):
        values = get_roots(p)
        if len(values) == 2:
            a, b = values
            return [(a + (not inclusive), b - (not inclusive))]
        a, b, c = values
        low, high = (p["lower"], p["upper"]) if task == "bounded_count" else (1, 26)
        return [(low, min(high, a - 1)), (max(low, b + 1), min(high, c - 1))]

    def solve(p):
        regions = intervals(p)
        if task == "least":
            return regions[0][0]
        if task == "greatest":
            return regions[0][1]
        return sum(max(0, end - start + 1) for start, end in regions)

    def reference(p):
        from math import prod
        values = get_roots(p)
        low = p.get("lower", 1 if task == "positive_count" else -26)
        high = p.get("upper", 26)
        hits = [n for n in range(low, high + 1)
                if prod(n - root for root in values) <= -int(not inclusive)]
        return hits[0] if task == "least" else hits[-1] if task == "greatest" else len(hits)

    def check(p):
        values = get_roots(p)
        return (all(a < b for a, b in zip(values, values[1:]))
                and (task != "bounded_count" or p["lower"] <= p["upper"]))

    return _bounded_case(
        "algebra.factored_integer_inequality", entries, render, solve, reference, check,
        ["The real roots are distinct and ordered. Any explicit integer bounds are ordered."],
    )


def _centered_square():
    def render(p):
        term = _tex_polynomial([p["shift"], 1])
        return rf"How many integers $x$ satisfy $({term})^2\le {p['limit']}$?"

    return _bounded_case(
        "algebra.square_integer_inequality", [("shift", 3, -20, 20), ("limit", 1, 0, 100)],
        render, lambda p: 2 * isqrt(p["limit"]) + 1,
        lambda p: sum((n + p["shift"]) ** 2 <= p["limit"] for n in range(-30, 31)),
    )


_ABSOLUTE_EQUATIONS = {
    "algebra/train/567": (1, -5, 0, 12, "greatest"),
    "algebra/train/1624": (3, 7, 0, 26, "least"),
    "algebra/test/1008": (5, -1, 1, 3, "greatest"),
}


def _absolute_equation(case):
    a, b, c, d, task = case

    def roots(p):
        a, b, c, d = (p[key] for key in ("a", "b", "c", "d"))
        if a <= abs(c):
            raise ValueError("slopes do not give bounded branches")
        candidates = (Fraction(d - b, a - c), Fraction(-d - b, a + c))
        return [x for x in candidates if c * x + d >= 0]

    def render(p):
        left = _tex_polynomial([p["b"], p["a"]])
        right = _tex_polynomial([p["d"], p["c"]])
        return f"What is the {task} real value of $x$ satisfying $|{left}|={right}$?"

    def solve(p):
        return (min if task == "least" else max)(roots(p))

    def reference(p):
        a, b, c, d = (p[key] for key in ("a", "b", "c", "d"))
        candidates = [
            Fraction(n, q) for q in (a - c, a + c) for n in range(-45, 46)
            if abs(a * n + b * q) == c * n + d * q
        ]
        return (min if task == "least" else max)(candidates)

    def check(p):
        return p["a"] > abs(p["c"]) and len(set(roots(p))) == 2

    return _bounded_case(
        "algebra.absolute_value_equation", [
            ("a", a, 1, 12), ("b", b, -16, 16),
            ("c", c, 0 if not c else -5, 0 if not c else 5), ("d", d, 1, 29),
        ], render, solve, reference, check,
        ["The left slope is greater than the absolute right slope and there are two distinct roots."],
    )


def _absolute_inequality(task):
    if task == "count":
        entries = [("shift", 2, -25, 25), ("tenths", 56, 0, 130)]

        def render(p):
            term = _tex_polynomial([-p["shift"], 1])
            return rf"How many integers $x$ satisfy $|{term}|\le {p['tenths']//10}.{p['tenths']%10}$?"

        return _bounded_case(
            "algebra.absolute_integer_inequality", entries, render,
            lambda p: 2 * (p["tenths"] // 10) + 1,
            lambda p: sum(10 * abs(n - p["shift"]) <= p["tenths"] for n in range(-40, 41)),
        )

    def render(p):
        return (f"Find the least integer $x$ for which "
                f"${p['coefficient']}|x|+{p['offset']}<{p['limit']}$.")

    return _bounded_case(
        "algebra.absolute_integer_inequality", [
            ("coefficient", 2, 1, 12), ("offset", 7, 0, 25), ("limit", 17, 1, 50),
        ], render,
        lambda p: -((p["limit"] - p["offset"] - 1) // p["coefficient"]),
        lambda p: next(n for n in range(-50, 51)
                       if p["coefficient"] * abs(n) + p["offset"] < p["limit"]),
        lambda p: p["offset"] < p["limit"],
        ["The limit is greater than the constant offset."],
    )


def _reciprocal_inequality():
    def solve(p):
        from math import isqrt
        n = (isqrt(4 * p["bound"] + 1) - 1) // 2
        return n + 1

    return _bounded_case(
        "algebra.reciprocal_integer_inequality", [("bound", 10, 2, 1000)],
        lambda p: rf"What is the least positive integer $n$ such that "
                  rf"$\frac{{1}}{{n}}-\frac{{1}}{{n+1}}<\frac{{1}}{{{p['bound']}}}$?",
        solve, lambda p: next(n for n in range(1, 100) if Fraction(1, n) - Fraction(1, n+1)
                              < Fraction(1, p["bound"])),
    )


_LOG_AFFINE = {
    "algebra/train/488": (12, 1, 3, 0, 2, 1, "x"),
    "algebra/train/1048": (3, 2, 2, -7, 3, 2, "x"),
    "algebra/train/1375": (2, 4, 1, 16, 5, 4, "r"),
    "algebra/test/252": (5, 1, 1, -18, 2, 1, "x"),
}


def _log_affine(case):
    base, power, a, b, numerator, denominator, variable = case

    def render(p):
        arg = _tex_polynomial([p["offset"], p["slope"]], variable)
        exponent = _tex(Fraction(p["exponent_numerator"], p["exponent_denominator"]))
        return (f"Find ${variable}$ such that "
                rf"$\log_{{{p['base']**p['base_power']}}}({arg})={exponent}$.")

    def exponent(p):
        return Fraction(p["base_power"] * p["exponent_numerator"], p["exponent_denominator"])

    def solve(p):
        value = p["base"] ** int(exponent(p))
        return Fraction(value - p["offset"], p["slope"])

    def reference(p):
        # The displayed base to the numerator and argument to the denominator coincide.
        target = p["base"] ** (p["base_power"] * p["exponent_numerator"])
        low, high = 1, 1
        while high ** p["exponent_denominator"] < target:
            high *= 2
        while high > low:
            mid = (low + high) // 2
            if mid ** p["exponent_denominator"] < target:
                low = mid + 1
            else:
                high = mid
        return Fraction(low - p["offset"], p["slope"])

    return _bounded_case(
        "algebra.logarithm.affine_argument", [
            ("base", base, 2, 15), ("base_power", power, 1, 5),
            ("slope", a, 1, 12), ("offset", b, -24, 24),
            ("exponent_numerator", numerator, 1, 8),
            ("exponent_denominator", denominator, 1, 5),
        ], render, solve, reference, lambda p: exponent(p).denominator == 1,
        ["The logarithm base is greater than one. The source exponent times the "
         "base power is an integer, making the unique solution rational."],
    )


_LOG_LINEAR_COMBINATIONS = {
    "intermediate_algebra/train/497": (2, 2, 1, 1, 2, 10),
    "intermediate_algebra/train/627": (2, 1, 1, 2, 1, 6),
    "intermediate_algebra/train/719": (2, 1, 2, -1, 1, 5),
}


def _log_combination(case):
    base, p1, m1, p2, m2, rhs = case

    def render(p):
        base, a, b, c, d, rhs = (p[k] for k in
            ("base", "left_base_power", "left_argument_power", "right_base_power",
             "right_argument_power", "sum"))
        left_base = _tex(Fraction(base) ** a)
        right_base = _tex(Fraction(base) ** c)
        first = "x" if b == 1 else f"x^{{{b}}}"
        second = "x" if d == 1 else f"x^{{{d}}}"
        return (rf"For $x>0$, solve $\log_{{{left_base}}}({first}) + "
                rf"\log_{{{right_base}}}({second}) = {rhs}$.")

    def coefficient(p):
        return (Fraction(p["left_argument_power"], p["left_base_power"])
                + Fraction(p["right_argument_power"], p["right_base_power"]))

    def solve(p):
        return Fraction(p["base"]) ** int(p["sum"] / coefficient(p))

    def reference(p):
        multiplier = coefficient(p)
        power = next(j for j in range(-20, 21) if multiplier * j == p["sum"])
        return Fraction(p["base"]) ** power

    def check(p):
        multiplier = coefficient(p)
        return bool(multiplier) and p["sum"] / multiplier in range(-20, 21)

    return _bounded_case(
        "algebra.logarithm.linear_combination", [
            ("base", base, 2, 9), ("left_base_power", p1, 1, 5),
            ("left_argument_power", m1, 1, 4),
            ("right_base_power", p2, -5 if p2 < 0 else 1, -1 if p2 < 0 else 5),
            ("right_argument_power", m2, 1, 4), ("sum", rhs, -12, 20),
        ], render, solve, reference, check,
        ["The logarithm coefficient is nonzero. The resulting common-base exponent is an integer "
         "from -20 to 20."],
    )


def _log_chain():
    def render(p):
        a, n = p["base"], p["factors"]
        factors = r"\cdot ".join(rf"\log_{{{k}}}{{{k+1}}}" for k in range(a, a + n))
        return f"Find the exact value of ${factors}$."

    def exponent(p):
        base, value = p["base"], p["base"] + p["factors"]
        count = 0
        while value % base == 0:
            count += 1
            value //= base
        return count if value == 1 else 0

    return _bounded_case(
        "algebra.logarithm.telescoping_product", [
            ("base", 2, 2, 6), ("factors", 6, 2, 40),
        ], render, exponent,
        lambda p: next(j for j in range(1, 7) if p["base"]**j == p["base"] + p["factors"]),
        lambda p: exponent(p) > 0,
        ["The final logarithm argument is an integer power of the first base."],
    )


def _prime_power_equation(prefactor):
    # The displayed right-hand side is a parameter. The unknown exponent is
    # recovered from it by integer divisibility.
    entries = [
        ("base", 3, 2, 9),
        ("factor_base", 2, 2, 9),
        ("factor_exponent", 3 if prefactor else 1, 1, 6 if prefactor else 1),
        ("right", 72 if prefactor else 162, 2, 9**12),
    ]

    def render(p):
        coefficient = (f"{p['factor_base']}^{{{p['factor_exponent']}}}" if prefactor
                       else str(p["factor_base"]))
        return rf"For what value of $x$ is ${coefficient}\cdot {p['base']}^x = {p['right']}$?"

    def solve(p):
        coefficient = p["factor_base"] ** p["factor_exponent"]
        value, remainder = divmod(p["right"], coefficient)
        if remainder or value < 1:
            raise ValueError("right side is not divisible by the coefficient")
        exponent = 0
        while value % p["base"] == 0:
            value //= p["base"]
            exponent += 1
        if value != 1:
            raise ValueError("quotient is not a power of the base")
        return exponent

    def check(p):
        try:
            return solve(p) in range(1, 7)
        except ValueError:
            return False

    def sample(rng):
        base, factor = rng.randint(2, 9), rng.randint(2, 9)
        power = rng.randint(1, 6) if prefactor else 1
        right = factor**power * base**rng.randint(1, 6)
        return dict(base=base, factor_base=factor, factor_exponent=power, right=right)

    template = _bounded_case(
        "algebra.exponential_equation.scaled", entries, render, solve,
        lambda p: next(k for k in range(1, 7)
                       if p["factor_base"]**p["factor_exponent"] * p["base"]**k == p["right"]),
        check, ["The right side divided by the displayed prefactor is a power of the base "
                "with exponent from one to six."],
    )
    template.sample = sample
    return template


_DEGREE_COMBINATIONS = {
    "algebra/train/1673": (2, 1, "ordered_sum"),
    "algebra/test/327": (7, 7, "equal_product"),
    "algebra/test/634": (3, 5, "weighted_sum"),
    "algebra/test/759": (4, 2, "difference"),
}


def _degree_combination(case):
    a, b, mode = case
    entries = [("degree_f", a, 1, 24)]
    if mode in ("weighted_sum", "difference"):
        entries.append(("degree_g", b, 1, 24))

    def render(p):
        a = p["degree_f"]
        if mode == "ordered_sum":
            return (rf"Polynomials $f$ and $g$ satisfy $\deg f={a}$ and "
                    r"$\deg g<\deg f$. What is the degree of $f+g$?")
        if mode == "equal_product":
            return f"Polynomials $f$ and $g$ both have degree {a}. What is the degree of their product?"
        return (f"Polynomials $f$ and $g$ have degrees {a} and {p['degree_g']}, respectively. "
                f"What is the degree of ${'2f+4g' if mode == 'weighted_sum' else 'f-g'}$?")

    def solve(p):
        a = p["degree_f"]
        if mode == "equal_product":
            return 2 * a
        return max(a, p.get("degree_g", 0))

    def reference(p):
        a, b = p["degree_f"], p.get("degree_g", p["degree_f"] - 1)
        return max(i + j for i in (0, a) for j in (0, a)) if mode == "equal_product" else max({a, b})

    return _bounded_case(
        "algebra.polynomial.degree_combination", entries, render, solve, reference,
        lambda p: p["degree_f"] != p.get("degree_g"),
        ["The given degrees differ whenever their sum or difference could have cancellation."],
    )


def _degree_power():
    return _bounded_case(
        "algebra.polynomial.degree_power", [("coefficient", 3, 1, 15),
                                            ("inner_degree", 2, 1, 12),
                                            ("offset", 11, -20, 20),
                                            ("power", 12, 2, 20)],
        lambda p: rf"What is the degree of $({p['coefficient']}x^{{{p['inner_degree']}}}"
                  rf"{p['offset']:+d})^{{{p['power']}}}$?",
        lambda p: p["inner_degree"] * p["power"],
        lambda p: max(p["inner_degree"] * k for k in range(p["power"] + 1)),
    )


def _degree_grouped():
    return _bounded_case(
        "algebra.polynomial.degree_grouped", [("lower_degree", 3, 1, 15), ("upper_degree", 4, 2, 20),
                                              ("pi_multiple", 2, 1, 15), ("radicand", 10, 2, 40)],
        lambda p: (rf"What is the degree of the polynomial $(4+5x^{{{p['lower_degree']}}}+100"
                   rf"+{p['pi_multiple']}\pi x^{{{p['upper_degree']}}}"
                   rf"+\sqrt{{{p['radicand']}}}x^{{{p['upper_degree']}}}+9)$?"),
        lambda p: p["upper_degree"],
        lambda p: max(0, p["lower_degree"], p["upper_degree"]),
        lambda p: p["lower_degree"] < p["upper_degree"],
        ["The two highest-degree coefficients are positive and share an exponent higher "
         "than the other nonconstant term."],
    )


def _degree_cancellation():
    return _bounded_case(
        "algebra.polynomial.degree_cancellation", [("degree", 4, 3, 15),
                                                   ("next_degree", 3, 2, 12),
                                                   ("sum_degree", 1, 0, 12)],
        lambda p: (
            f"Let $f(x)=-7x^{{{p['degree']}}}+3x^{{{p['next_degree']}}}+x-5$. "
            f"The degree of $f+g$ is {p['sum_degree']}. What is the degree of polynomial $g$?"
        ),
        lambda p: p["degree"], None,
        lambda p: p["degree"] > max(p["next_degree"], p["sum_degree"]),
        ["The requested sum degree and the second displayed exponent are below the leading degree."],
    )


def _degree_division(plain_factor):
    if plain_factor:
        return _bounded_case(
            "algebra.polynomial.degree_division",
            [("degree", 5, 3, 22), ("factor_degree", 2, 2, 14)],
            lambda p: (
                f"A polynomial $h$ has degree {p['degree']} and satisfies "
                f"$h(x)=(x^{{{p['factor_degree']}}}-7x+10)g(x)$. What is the degree of $g$?"
            ),
            lambda p: p["degree"] - p["factor_degree"],
            None, lambda p: p["degree"] > p["factor_degree"],
            ["The degree of the product is greater than the degree of the displayed factor."],
        )

    return _bounded_case(
        "algebra.polynomial.degree_division",
        [("degree", 13, 5, 25), ("quotient_degree", 7, 1, 18), ("remainder_degree", 3, 3, 15)],
        lambda p: (
            f"A polynomial of degree {p['degree']} is divided by $d(x)$, giving a quotient of "
            f"degree {p['quotient_degree']} and remainder $3x^{{{p['remainder_degree']}}}+4x^2-x+12$. "
            "What is the degree of $d$?"
        ),
        lambda p: p["degree"] - p["quotient_degree"],
        None, lambda p: p["degree"] > p["quotient_degree"] + p["remainder_degree"],
        ["The remainder degree is strictly smaller than the divisor degree."],
    )


_ASYMPTOTE_DEGREES = {
    "intermediate_algebra/train/424": (6, 5, r"2x^{{{d}}}+3x^{{{e}}}-x^2-1", True),
    "intermediate_algebra/train/1120": (5, 4, r"2x^{{{d}}}+x^{{{e}}}-7x^2+1", False),
    "intermediate_algebra/test/671": (7, 4, r"2x^{{{d}}}-5x^{{{e}}}+3x^3-x+5", True),
    "intermediate_algebra/test/786": (6, 5, r"x^{{{d}}}-4x^{{{e}}}+3x^3+x^2-1", False),
}


def _asymptote_degree(case):
    degree, other, expression, numerator = case

    def render(p):
        polynomial = expression.format(d=p["degree"], e=p["next_degree"])
        a, b = (polynomial, "q(x)") if numerator else ("q(x)", polynomial)
        quantifier = "smallest" if numerator else "largest"
        return (rf"The graph of $\frac{{{a}}}{{{b}}}$ has a horizontal asymptote. "
                f"What is the {quantifier} possible degree of $q(x)$?")

    return _bounded_case(
        "algebra.polynomial.degree_for_asymptote",
        [("degree", degree, 4, 18), ("next_degree", other, 3 if other == 3 else 4, 16)],
        render, lambda p: p["degree"],
        None, lambda p: p["degree"] > p["next_degree"],
        ["The leading exponent of the displayed polynomial is greater than the other exponents."],
    )


def build(row):
    key, problem = row["id"], row["problem"]
    if key in _AFFINE_CASES:
        return _affine_inequality(problem, *_AFFINE_CASES[key])
    if key in _POWER_INEQUALITIES:
        return _power_inequality(_POWER_INEQUALITIES[key])
    if key in _FACTOR_INEQUALITIES:
        return _factor_inequality(_FACTOR_INEQUALITIES[key])
    if key in _ABSOLUTE_EQUATIONS:
        return _absolute_equation(_ABSOLUTE_EQUATIONS[key])
    if key in _LOG_AFFINE:
        return _log_affine(_LOG_AFFINE[key])
    if key in _LOG_LINEAR_COMBINATIONS:
        return _log_combination(_LOG_LINEAR_COMBINATIONS[key])
    if key in _DEGREE_COMBINATIONS:
        return _degree_combination(_DEGREE_COMBINATIONS[key])
    if key in _ASYMPTOTE_DEGREES:
        return _asymptote_degree(_ASYMPTOTE_DEGREES[key])
    curated = {
        "algebra/train/2": (_degree_grouped,),
        "algebra/train/883": (_absolute_inequality, "least"),
        "algebra/train/899": (_degree_power,),
        "algebra/train/1236": (_degree_cancellation,),
        "algebra/train/1432": (_centered_square,),
        "algebra/train/1585": (_prime_power_equation, False),
        "algebra/test/320": (_absolute_inequality, "count"),
        "algebra/test/340": (_degree_division, True),
        "prealgebra/test/572": (_prime_power_equation, True),
        "intermediate_algebra/train/136": (_degree_division, False),
        "intermediate_algebra/train/536": (_reciprocal_inequality,),
        "intermediate_algebra/test/797": (_log_chain,),
    }
    if key in curated:
        factory, *args = curated[key]
        return factory(*args)
    return _round_evaluation(row)
