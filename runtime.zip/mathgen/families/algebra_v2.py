"""Exact scalar algebra for source shapes outside the first two algebra passes."""
from fractions import Fraction
from functools import lru_cache
from itertools import product
from math import gcd, isqrt, lcm, prod
from random import Random
import re

from .algebra import (
    _MATH_BLOCK, _MathParser, _ParseError, _evaluate, _integer_domain,
    _math_body, _poly_add, _poly_divmod, _poly_mul,
    _rational_polynomials, _rational_square_root, _template, _trim, _variables,
)


class _Bindings:
    """Record literal spans separately from their exact mathematical values."""

    def __init__(self, problem):
        self.problem = problem
        self.original = {}
        self.domains = {}
        self.spans = []

    def bind(self, name, start, end, low=None, high=None, scale=1, single=False):
        raw = self.problem[start:end]
        original = int(Fraction(raw.replace(",", "")) * scale)
        if low is None:
            low = min(original, -12) if original < 0 else (1 if original else 0)
        if high is None:
            high = max(original + 8, 18 * scale)
        if single:
            high = min(high, 9)
        if name in self.original and self.original[name] != original:
            raise _ParseError("inconsistent shared literal")
        self.original[name] = original
        self.domains[name] = _integer_domain(low, high)
        self.spans.append((start, end, name, raw, scale))
        return name

    def parse(self, text, offset, parser=_MathParser, prefix="literal", ties=None):
        node, literals = parser(text).parse()
        keys = []
        for start, end, value, single in literals:
            raw = text[start:end]
            scale = 10 ** len(raw.partition(".")[2])
            name = (ties or {}).get(start, f"{prefix}_{len(self.spans) + 1}")
            # Leading coefficient signs are part of the tree, not the numeric span.
            bound = self.bind(name, offset + start, offset + end, scale=scale, single=single)
            keys.append((bound, scale))
        return node, keys

    @staticmethod
    def values(keys, p):
        return tuple(Fraction(p[name], scale) for name, scale in keys)

    def render(self, p):
        text = self.problem
        for start, end, name, raw, scale in sorted(self.spans, reverse=True):
            value = p[name]
            if value == self.original[name]:
                continue
            if scale != 1:
                places = len(str(scale)) - 1
                value = str(value).zfill(places + 1)
                value = value[:-places] + "." + value[-places:]
            elif "," in raw:
                value = f"{value:,}"
            text = text[:start] + str(value) + text[end:]
        return text

    def template(self, family, solve, constraints=(), reference=None, sample=None):
        def check(p):
            try:
                result = solve(p)
                return isinstance(result, (int, Fraction)) and not isinstance(result, bool)
            except (ArithmeticError, ValueError, KeyError, RecursionError):
                return False

        if not self.original or not check(self.original):
            return None

        def draw(rng):
            return {key: rng.randint(d["min"], d["max"]) for key, d in self.domains.items()}

        # Some domains are thin (e.g. integer inputs yielding a rational radical).
        # Draw independently first. Then use a deterministic pool of admissible
        # inputs built from the parameter domains, never from the answer key.
        if sample is None:
            reservoir = None

            def sample(rng):
                nonlocal reservoir
                for _ in range(12):
                    p = draw(rng)
                    if check(p):
                        return p
                if reservoir is None:
                    keys = list(self.original)
                    search = Random(34129)
                    pool = []
                    for key in keys:
                        d = self.domains[key]
                        if d["max"] - d["min"] <= 100:
                            for value in range(d["min"], d["max"] + 1):
                                p = dict(self.original, **{key: value})
                                if p != self.original and check(p):
                                    pool.append(p)
                    for i in range(1200):
                        p = draw(search)
                        if len(keys) > 2 and i % 3:
                            keep = search.sample(keys, search.randint(1, len(keys) - 1))
                            p.update((k, self.original[k]) for k in keep)
                        if p != self.original and check(p):
                            pool.append(p)
                        if len(pool) >= 80 and i >= 120:
                            break
                    reservoir = tuple(pool)
                return dict(rng.choice(reservoir)) if reservoir else dict(self.original)

        scales = [f"{name} is displayed divided by {scale}."
                  for _, _, name, _, scale in self.spans if scale != 1]
        return _template("algebra.v2." + family, self.original, self.domains, self.render,
                         solve, reference, check, [*constraints, *dict.fromkeys(scales)], sample)


class _ExactParser(_MathParser):
    """Real roots, rational/dynamic powers, logarithms and inverse function calls."""

    _spacing = re.compile(r"\s+|~|\\(?:left|right|displaystyle|,|!|;| )")

    def _powered(self, node):
        if self._peek() == "^":
            self._take("^")
            node = ("^", node, self._argument(False))
        return node

    def _atom(self, freeze):
        symbol = self._peek()
        if symbol == r"\sqrt":
            self._take(symbol)
            degree = ("const", Fraction(2))
            if self._peek() == "[":
                self._take("[")
                degree = self._expr(0, False)
                self._take("]")
            return self._powered(("root", self._argument(freeze), degree))
        if symbol == r"\log":
            self._take(symbol)
            self._take("_")
            base = self._argument(freeze)
            argument = self._atom(freeze)
            # In the supported numeric notation, a juxtaposed radical is part
            # of the argument: log_2 8 sqrt(2).
            while self._peek() == r"\sqrt":
                argument = ("*", argument, self._atom(freeze))
            return ("log", base, argument)
        if symbol in ("|", r"\lfloor"):
            self._take(symbol)
            node = self._expr(0, freeze)
            self._take("|" if symbol == "|" else r"\rfloor")
            return self._powered(("abs" if symbol == "|" else "floor", node))
        if symbol in ("f", "g", "h", "t"):
            self._take(symbol)
            name = symbol
            # A superscript -1 denotes the inverse only when followed by a call.
            inverse = re.match(r"\s*\^\s*\{\s*-1\s*\}\s*(?:\\left\s*)?\(",
                               self.source[self.offset:])
            if inverse:
                name += "^-1"
                self.offset += inverse.end()
            elif self._peek() == "(":
                self._take("(")
            else:
                return self._powered(("var", symbol))
            argument = self._expr(0, freeze)
            self._take(")")
            return self._powered(("call", name, argument))
        return super()._atom(freeze)

    def _argument(self, freeze):
        if self._peek() in (r"\frac", r"\dfrac", r"\tfrac", r"\sqrt", r"\log"):
            # Unlike _atom, a single TeX command argument does not consume a
            # following power: x^\frac{1}{2} and log_\frac{1}{3}9.
            symbol = self._peek()
            if symbol in (r"\frac", r"\dfrac", r"\tfrac"):
                self._take(symbol)
                return ("/", self._argument(freeze), self._argument(freeze))
            if symbol == r"\sqrt":
                self._take(symbol)
                return ("root", self._argument(freeze), ("const", Fraction(2)))
            return self._atom(freeze)
        return super()._argument(freeze)


class _PolynomialParser(_MathParser):
    """A polynomial has fixed monomial degrees, not independently varied slots."""

    def _powered(self, node):
        if self._peek() != "^":
            return node
        self._take("^")
        exponent = self._argument(True)
        if exponent[0] != "const" or exponent[1].denominator != 1 or not 0 <= exponent[1] <= 1100:
            raise _ParseError("unsupported polynomial exponent")
        return ("^", node, exponent)


class _FixedPowerParser(_ExactParser):
    """Freeze exponents when parity or a repeated degree is structural."""

    def _powered(self, node):
        if self._peek() == "^":
            self._take("^")
            node = ("^", node, self._argument(True))
        return node


def _rational(q):
    q = Fraction(q)
    return {(): q} if q else {}


def _scalar(terms):
    if any(key for key in terms):
        raise ValueError("not a rational scalar")
    return terms.get((), Fraction(0))


@lru_cache(maxsize=4096)
def _factor(n):
    if not 1 <= n <= 10**12:
        raise ValueError("factorization input outside the bounded exact domain")
    result = []
    p = 2
    while p * p <= n:
        if n % p:
            p = 3 if p == 2 else p + 2
            continue
        exponent = 0
        while n % p == 0:
            n //= p
            exponent += 1
        result.append((p, exponent))
    if n != 1:
        result.append((n, 1))
    return tuple(result)


def _prime_vector(key, q):
    if not q:
        raise ValueError("zero has no prime exponent vector")
    vector = dict(key)
    for number, sign in ((abs(q.numerator), 1), (q.denominator, -1)):
        for p, exponent in _factor(number):
            vector[p] = vector.get(p, Fraction(0)) + sign * exponent
    return {p: e for p, e in vector.items() if e}


def _monomial(vector, coefficient):
    key = []
    for p, exponent in sorted(vector.items()):
        whole = exponent.numerator // exponent.denominator
        coefficient *= Fraction(p) ** whole
        residue = exponent - whole
        if residue:
            key.append((p, residue))
    return {tuple(key): coefficient} if coefficient else {}


def _add(a, b, sign=1):
    result = dict(a)
    for key, value in b.items():
        total = result.get(key, 0) + sign * value
        if total:
            result[key] = total
        else:
            result.pop(key, None)
    return result


def _multiply(a, b):
    result = {}
    for ka, av in a.items():
        for kb, bv in b.items():
            vector = dict(ka)
            for p, e in kb:
                vector[p] = vector.get(p, 0) + e
            result = _add(result, _monomial(vector, av * bv))
    if len(result) > 24:
        raise ValueError("too many radical terms")
    return result


def _inverse(a):
    if len(a) == 1:
        key, q = next(iter(a.items()))
        return _monomial({p: -e for p, e in key}, 1 / q)
    if len(a) == 2:
        (key, q), (other, value) = a.items()
        first = {key: q}
        ratio = _multiply({other: -value}, _inverse(first))
        radical_key, = ratio
        order = lcm(*(e.denominator for _, e in radical_key))
        if order > 12:
            raise ValueError("radical inverse order exceeds 12")
        total = term = _rational(1)
        for _ in range(1, order):
            term = _multiply(term, ratio)
            total = _add(total, term)
        denominator = _scalar(_add(_rational(1), _multiply(term, ratio), -1))
        return _multiply(total, _multiply(_inverse(first), _rational(1 / denominator)))
    raise ValueError("only monomial and binomial radical reciprocals are supported")


def _exact_power(a, exponent):
    if abs(exponent) > 1200 or exponent.denominator > 32:
        raise ValueError("power outside the bounded exact domain")
    if exponent.denominator == 1:
        n = int(exponent)
        if n < 0:
            return _exact_power(_inverse(a), -exponent)
        if not a and not n:
            raise ValueError("zero to the power zero")
        # Bound *before* potentially expensive powers or integer formatting.
        if n * max((max(q.numerator.bit_length(), q.denominator.bit_length())
                    for q in a.values()), default=1) > 10000:
            raise ValueError("power output exceeds the bit bound")
        result = _rational(1)
        while n:
            if n % 2:
                result = _multiply(result, a)
            n //= 2
            if n:
                a = _multiply(a, a)
        return result
    if not a:
        if exponent > 0:
            return {}
        raise ValueError("zero cannot be raised to a negative power")
    if len(a) != 1:
        raise ValueError("fractional power requires a single radical term")
    key, q = next(iter(a.items()))
    if any(p < 0 for p, _ in key) or q < 0 and exponent.denominator % 2 == 0:
        raise ValueError("fractional powers require a real root")
    vector = {p: exponent * e for p, e in _prime_vector(key, q).items()}
    return _monomial(vector, -1 if q < 0 and exponent.numerator % 2 else 1)


def _log(a, b):
    def positive_vector(terms):
        if len(terms) != 1:
            raise ValueError("logarithm requires one positive radical term")
        key, q = next(iter(terms.items()))
        if q <= 0 or any(p < 0 for p, _ in key):
            raise ValueError("logarithm requires positive arguments")
        return _prime_vector(key, q)

    base, argument = positive_vector(a), positive_vector(b)
    if not base:
        raise ValueError("logarithm base cannot be 1")
    p, exponent = next(iter(base.items()))
    quotient = argument.get(p, Fraction(0)) / exponent
    if any(argument.get(p, 0) != quotient * base.get(p, 0) for p in base.keys() | argument.keys()):
        raise ValueError("logarithm is not rational")
    return quotient


def _exact(node, values, variables=None, functions=None):
    variables = {} if variables is None else variables
    functions = {} if functions is None else functions
    op = node[0]
    if op == "const":
        return _rational(node[1])
    if op == "literal":
        return _rational(values[node[1]])
    if op == "var":
        if node[1] == "i" and node[1] not in variables:
            return {((-1, Fraction(1, 2)),): Fraction(1)}
        return variables[node[1]]
    if op == "call":
        return functions[node[1]](_exact(node[2], values, variables, functions))
    a = _exact(node[1], values, variables, functions)
    if op == "neg":
        return {key: -value for key, value in a.items()}
    if op == "abs":
        conjugate = {key: (-value if any(p == -1 for p, _ in key) else value)
                     for key, value in a.items()}
        return _exact_power(_multiply(a, conjugate), Fraction(1, 2))
    if op == "floor":
        if not a:
            return {}
        if len(a) == 1:
            key, q = next(iter(a.items()))
            if not key:
                return _rational(q.numerator // q.denominator)
            if all(p > 0 and e.denominator == 2 for p, e in key):
                n = q * q * prod(p for p, _ in key)
                bound = isqrt(n.numerator // n.denominator)
                return _rational(bound if q > 0 else -bound - 1)
        raise ValueError("floor requires a rational or square-root monomial")
    b = _exact(node[2], values, variables, functions)
    if op in ("+", "-"):
        return _add(a, b, 1 if op == "+" else -1)
    if op == "*":
        return _multiply(a, b)
    if op == "/":
        return _multiply(a, _inverse(b))
    if op == "^":
        return _exact_power(a, _scalar(b))
    if op == "root":
        degree = _scalar(b)
        if degree.denominator != 1 or not 2 <= degree <= 16:
            raise ValueError("root index must be an integer from 2 through 16")
        return _exact_power(a, 1 / degree)
    if op == "log":
        return _rational(_log(a, b))
    raise ValueError("unsupported exact operator")


class _MixedPowerParser(_ExactParser):
    """Handle the mixed fractions explicitly written in two reviewed sources."""

    def _expr(self, min_priority, freeze):
        node = self._atom(freeze)
        while True:
            symbol = self._peek()
            implicit = (symbol in ("(", "{", "[", r"\frac", r"\dfrac", r"\tfrac", r"\sqrt", r"\log")
                        or len(symbol) == 1 and symbol.isascii() and symbol.isalpha())
            if not implicit and symbol not in self._operators:
                break
            mixed = symbol in (r"\frac", r"\dfrac", r"\tfrac") and node[0] in ("const", "literal")
            priority, operator = (2, "+" if mixed else "*") if implicit else self._operators[symbol]
            if priority < min_priority:
                break
            if not implicit:
                self._take(symbol)
            if mixed:
                rhs = self._argument(freeze)
            else:
                rhs = self._expr(priority + 1, freeze)
            node = (operator, node, rhs)
        return node


_SCALAR_QUERY = r"(?:evaluate|simplify(?: completely)?|compute|what is|find)(?: the (?:numerical )?value(?: of)?| the expression)?"
_SCALAR_END = r"\s*[.?!]?\s*(?:Express your answer (?:as a (?:simplified )?(?:common )?fraction|in simplest form)\s*\.)?\s*"


def _blocks(problem):
    return list(_MATH_BLOCK.finditer(problem)), _MATH_BLOCK.sub("@", problem)


def _block_parse(bindings, block, parser=_MathParser):
    source, offset = _math_body(block)
    return bindings.parse(source, offset, parser)


def _scalar_expression(row, blocks, skeleton):
    if not blocks:
        return None
    key, problem = row["id"], row["problem"]
    if key in {
        "algebra/train/81", "algebra/train/327", "algebra/train/535", "algebra/train/739", "algebra/train/751",
        "algebra/test/76", "algebra/test/207", "algebra/test/281", "intermediate_algebra/train/264",
        "intermediate_algebra/train/1119", "intermediate_algebra/train/1269", "intermediate_algebra/test/444",
        "intermediate_algebra/test/739",
    }:
        return None
    special = {
        "algebra/train/1132", "algebra/test/47",
    }
    plain = re.fullmatch(rf"(?i){_SCALAR_QUERY}\s*:?\s*@{_SCALAR_END}", skeleton)
    substitutions = re.fullmatch(
        rf"(?i){_SCALAR_QUERY}\s*:?\s*@\s*[,;]?\s*(?:if|when|for|where|given that)\s+"
        rf"@(?:\s*[,]?\s*(?:and\s+)?@){{0,4}}{_SCALAR_END}", skeleton)
    if not (plain or substitutions or key in special):
        return None
    if not blocks and key == "algebra/train/1132":
        return None
    if key == "algebra/train/1132":
        match = re.search(r"\\begin\{align\*\}(.*?)\\end\{align\*\}", problem, re.S)
        bindings = _Bindings(problem)
        query = bindings.parse(match[1], match.start(1), _MixedPowerParser)
        givens = blocks
    else:
        bindings = _Bindings(problem)
        parser = _ExactParser
        # Conjugate or repeated powers must move together, or stay fixed.
        if key in {"intermediate_algebra/train/339", "algebra/train/865"}:
            parser = _FixedPowerParser
        query = _block_parse(bindings, blocks[0], parser)
        givens = blocks[1:]
    definitions = []
    for block in givens:
        body, offset = _math_body(block)
        if key == "algebra/test/47":
            if body.replace(" ", "") != "i^2=-1":
                return None
            continue
        match = re.fullmatch(r"\s*([a-zA-Z])\s*=\s*(.+)", body, re.S)
        if match is None or any(name == match[1] for name, _ in definitions):
            return None
        definitions.append((match[1], bindings.parse(
            match[2], offset + match.start(2), _MixedPowerParser if key == "algebra/train/1132" else _ExactParser)))
    # Position groups refer to the parsed numeric literal sequence of the
    # individually reviewed source. Coincidental equal numbers stay independent.
    ties = {
        "algebra/train/13": ((0, 3, 5), (1, 4), (2, 6)),
        "algebra/train/50": ((0, 2), (1, 3)),
        "algebra/train/371": ((1, 3),),
        "algebra/train/739": ((0, 2),),
        "algebra/train/778": ((0, 2, 4, 6),),
        "algebra/train/934": ((0, 2),),
        "algebra/train/1148": ((0, 1, 2, 3),),
        "algebra/train/1307": ((0, 2),),
        "algebra/train/1317": ((0, 2),),
        "algebra/train/1340": ((1, 3, 5), (2, 4, 6)),
        "algebra/train/1537": ((0, 3), (1, 4), (2, 5)),
        "algebra/test/53": ((0, 2),),
        "algebra/test/55": ((0, 2),),
        "algebra/test/76": ((0, 2, 4, 6),),
        "algebra/test/242": ((1, 3, 5, 7), (2, 4, 6, 8)),
        "algebra/test/322": ((0, 2, 4, 6, 8), (1, 3, 5, 7, 9)),
        "algebra/test/523": ((0, 2),),
        "algebra/test/580": ((0, 2),),
        "algebra/test/706": ((0, 2, 4, 6),),
        "algebra/test/963": ((1, 3),),
        "algebra/test/1014": ((1, 2),),
        "intermediate_algebra/train/339": ((0, 3), (1, 4), (2, 5)),
        "intermediate_algebra/train/737": ((0, 2, 4, 6), (1, 3, 5, 7)),
        "intermediate_algebra/train/880": ((1, 3),),
        "intermediate_algebra/train/939": ((1, 2), (3, 4), (5, 6)),
        "intermediate_algebra/train/1289": ((0, 2), (1, 3)),
        "intermediate_algebra/test/134": (
            (0, 5, 10, 15), (1, 6, 11, 16), (2, 7, 12, 17),
            (3, 8, 13, 18), (4, 9, 14, 19)),
        "intermediate_algebra/test/588": ((0, 2), (1, 3)),
        "intermediate_algebra/test/739": ((1, 3),),
    }.get(key, ())
    fixed = {
        "algebra/train/466": (1,), "algebra/train/535": (1,),
        "algebra/train/739": (1,), "algebra/train/821": (0,), "algebra/train/934": (3,),
        "algebra/train/1148": (0, 1, 2, 3), "algebra/test/694": (0,),
        "algebra/test/745": (1,), "intermediate_algebra/train/80": (0, 1),
        "intermediate_algebra/test/134": (4, 9, 14, 19),
        "intermediate_algebra/test/527": (0, 1, 2, 3, 4, 5),
    }.get(key, ())
    query, definitions = _constrain_bindings(bindings, query, definitions, ties, fixed)

    def solve(p):
        pending = dict(definitions)
        variables = {}
        while pending:
            for name, (tree, keys) in tuple(pending.items()):
                if key == "algebra/train/1132":
                    _, numerator, denominator = bindings.values(keys, p)
                    if numerator >= denominator:
                        raise ValueError("the mixed number must have a proper fractional part")
                try:
                    variables[name] = _exact(tree, bindings.values(keys, p), variables)
                except KeyError:
                    continue
                del pending[name]
                break
            else:
                raise ValueError("cyclic or incomplete variable assignments")
        if key in _FAST_EXPRESSION:
            return _FAST_EXPRESSION[key](*bindings.values(query[1], p))
        return _scalar(_exact(query[0], bindings.values(query[1], p), variables))

    constraints = [
        "All powers and roots must be defined with the displayed real-root convention; radical indices are integers in [2, 16].",
        "Divisors are nonzero, logarithms have positive arguments and positive bases other than 1, and evaluated logarithms are rational.",
        "The final result must be rational; factorization inputs are at most 10^12 and integer powers are bounded.",
    ]
    if key == "algebra/train/1132":
        constraints.append("The numerator of the mixed number is strictly smaller than its denominator.")
    if key == "algebra/test/47":
        constraints.append("The two products contributing to the imaginary part must be equal.")
    reference = None
    if key in _FAST_EXPRESSION or key == "algebra/train/1537":
        def reference(p):
            if key == "algebra/train/1537":
                a, b, c = (p[f"literal_{j}"] for j in (1, 2, 3))
                return Fraction(a*a, b*b-c)
            if key == "intermediate_algebra/test/526":
                a,b,d,n = bindings.values(query[1], p)
                real,imaginary = 1,0
                for _ in range(int(n)):
                    real,imaginary = -a*real+b*d*imaginary,-b*real-a*imaginary
                return _rational_square_root(real*real+d*imaginary*imaginary)
            return _scalar(_exact(query[0], bindings.values(query[1], p)))
    return bindings.template("exact_expression", solve, constraints, reference)


def _root_of_power_sum(degree, a, power_a, b, power_b, c, power_c):
    order = int(degree)
    if order < 2:
        raise ValueError("root index must be at least two")
    radicand = int(a)**int(power_a) + int(b)**int(power_b) + int(c)**int(power_c)
    if radicand > 10**12:
        raise ValueError("factorization input outside the bounded exact domain")
    root = _integer_root(radicand, order)
    if root**order != radicand:
        raise ValueError("the power sum is not a perfect power")
    return root


def _bounded_square_root(value):
    if value > 10**12:
        raise ValueError("factorization input outside the bounded exact domain")
    return _rational_square_root(value)


_FAST_EXPRESSION = {
    "algebra/train/778": _root_of_power_sum,
    "intermediate_algebra/train/744": lambda a,b,c,d,e: _rational_square_root((a*a*b+c*c)*(d+e*e)),
    "intermediate_algebra/test/642": lambda a,b,c: _rational_square_root((a*a+b*b)/(c*c+1)),
    "intermediate_algebra/test/526": lambda a,b,c,n: _rational_square_root((a*a+b*b*c)**int(n)),
    "intermediate_algebra/test/345": lambda a,b,c,d: _rational_square_root((a*a+b*b)*(c*c+d*d)),
    "algebra/test/322": lambda a,n,*repeat: _bounded_square_root(5*a**int(n)),
}


def _multivariate(tree, values, variables):
    op = tree[0]
    zero = (0,) * len(variables)
    if op in ("const", "literal"):
        value = tree[1] if op == "const" else values[tree[1]]
        return {zero: value} if value else {}
    if op == "var":
        return {tuple(int(v == tree[1]) for v in variables): Fraction(1)}
    left = _multivariate(tree[1], values, variables)
    if op == "neg":
        return {key: -value for key, value in left.items()}

    def multiply(a, b):
        out = {}
        for key, value in a.items():
            for k, q in b.items():
                powers = tuple(x + y for x, y in zip(key, k))
                out[powers] = out.get(powers, 0) + value * q
        return {k: v for k, v in out.items() if v}

    right = _multivariate(tree[2], values, variables)
    if op == "*":
        return multiply(left, right)
    if op in ("+", "-"):
        return _add(left, right, 1 if op == "+" else -1)
    if op == "/" and set(right) == {zero}:
        return {key: value / right[zero] for key, value in left.items()}
    if op == "^" and set(right) <= {zero}:
        n = right.get(zero, 0)
        result = {zero: Fraction(1)}
        for _ in range(int(n)):
            result = multiply(result, left)
        return result
    raise ValueError("unsupported polynomial operation")


def _polynomial(node, values, variable):
    op = node[0]
    if not _variables(node):
        return _trim([_evaluate(node, values, {}, {})])
    if op == "var":
        if node[1] != variable:
            raise ValueError("unexpected polynomial variable")
        return (Fraction(0), Fraction(1))
    a = _polynomial(node[1], values, variable)
    if op == "neg":
        return tuple(-v for v in a)
    if op == "^":
        n = int(_evaluate(node[2], values, {}, {}))
        result = (Fraction(1),)
        while n:
            if n % 2:
                result = _poly_mul(result, a)
            n //= 2
            if n:
                a = _poly_mul(a, a)
        return result
    b = _polynomial(node[2], values, variable)
    if op in ("+", "-"):
        return _poly_add(a, b, 1 if op == "+" else -1)
    if op == "*":
        return _poly_mul(a, b)
    if op == "/" and len(b) == 1:
        return tuple(x / b[0] for x in a)
    raise ValueError("not a polynomial")


def _horner(coefficients, value):
    acc = Fraction(0)
    for coefficient in reversed(coefficients):
        acc = acc * value + coefficient
    return acc


def _polynomial_question(row, blocks, skeleton):
    problem = row["problem"]
    if row["id"] == "intermediate_algebra/test/264":
        return None
    coefficient = re.fullmatch(
        r"(?i)Find the coefficient of (?:the )?@(?: term)? (?:in the expansion of the product @|when @ is simplified)[.\s]*",
        skeleton)
    leading = re.fullmatch(r"(?i)Find the leading coefficient in the polynomial @ after it is simplified[.\s]*", skeleton)
    remainder = re.fullmatch(r"(?i)(?:Find|Determine|What is) the remainder when (?:the polynomial )?@ is divided by (?:the polynomial )?@[.?\s]*", skeleton)
    simplify_ids = {"algebra/train/32", "algebra/test/419", "algebra/test/520"}
    if not (coefficient or leading or remainder or row["id"] in simplify_ids):
        return None
    bindings = _Bindings(problem)
    if coefficient or leading or row["id"] in simplify_ids:
        block = blocks[-1]
        node, keys = _block_parse(bindings, block, _PolynomialParser)
        names = sorted(_variables(node))
        if coefficient:
            term, _ = _math_body(blocks[0])
            match = re.fullmatch(r"([a-z])(?:\^\{?(\d+)\}?)?", term)
            if not match or match[1] not in names:
                return None
            variable, degree = match[1], int(match[2] or 1)
        else:
            if len(names) != 1:
                return None
            variable, = names
            degree = None if leading else 0
        names = [variable, *[name for name in names if name != variable]]
        zero = (0,) * len(names)

        def solve(p):
            terms = _multivariate(node, bindings.values(keys, p), names)
            chosen = degree
            if leading:
                if not terms:
                    raise ValueError("zero polynomial has no leading coefficient")
                chosen = max(k[0] for k in terms)
            if row["id"] in simplify_ids and any(k[0] != 0 for k in terms):
                raise ValueError("the simplified expression is not constant")
            if any(k[0] == chosen and any(k[1:]) for k in terms):
                raise ValueError("coefficient depends on unspecified symbols")
            return terms.get((chosen, *zero[1:]), Fraction(0))

        def reference(p):
            values = bindings.values(keys, p)
            if len(names) > 1:
                # Coefficients independent of the distractors are unchanged
                # after substituting zero for each distractor.
                def replace(node):
                    if node[0] == "var" and node[1] != variable:
                        return ("const", Fraction(0))
                    if node[0] == "neg":
                        return ("neg", replace(node[1]))
                    if node[0] in ("+", "-", "*", "/", "^"):
                        return (node[0], replace(node[1]), replace(node[2]))
                    return node
                substituted = replace(node)
            else:
                substituted = node
            poly = _polynomial(substituted, values, variable)
            return poly[-1] if leading else (poly[degree] if degree < len(poly) else 0)

        return bindings.template(
            "polynomial_coefficient" if coefficient or leading else "constant_polynomial_identity",
            solve,
            ["The requested coefficient is independent of all unspecified symbols."
             if coefficient else "The expanded polynomial is nonzero." if leading else
             "The nonconstant coefficients cancel."],
            reference,
        )

    dividend, divisor = (_block_parse(bindings, block, _PolynomialParser) for block in blocks)
    names = _variables(dividend[0]) | _variables(divisor[0])
    if len(names) != 1:
        return None
    variable, = names
    divisor0 = _polynomial(divisor[0], bindings.values(divisor[1], bindings.original), variable)
    if len(divisor0) < 2:
        return None
    # In the cyclotomic examples every non-leading coefficient is structural.
    # Preserve the divisor by freezing it; the monomial exponents are then
    # parameterized together in a dedicated family.
    if len(divisor0) != 2:
        return None

    def get_divisor(p):
        poly = _polynomial(divisor[0], bindings.values(divisor[1], p), variable)
        if len(poly) != 2 or not poly[1]:
            raise ValueError("divisor must be linear")
        return poly

    def solve(p):
        b, a = get_divisor(p)
        return _evaluate(dividend[0], bindings.values(dividend[1], p), {variable: -b / a}, {})

    def reference(p):
        # Long division is independent of direct evaluation at the root.
        coeffs = list(_polynomial(dividend[0], bindings.values(dividend[1], p), variable))
        b, a = get_divisor(p)
        for j in range(len(coeffs) - 1, 0, -1):
            coeffs[j - 1] -= b * (coeffs[j] / a)
        return coeffs[0] if coeffs else 0

    return bindings.template("linear_polynomial_remainder", solve,
                             ["The divisor has degree one."],
                             reference)


_PIECEWISE = {
    "algebra/train/15", "algebra/train/379", "algebra/train/449",
    "algebra/train/605", "algebra/train/738", "algebra/train/898",
    "algebra/train/1157", "algebra/train/1527", "algebra/train/1530",
    "algebra/train/1716", "algebra/train/1733", "algebra/test/16",
    "algebra/test/273", "algebra/test/356", "algebra/test/510",
    "algebra/test/964", "algebra/test/1083",
}
_RELATIONS = {"<": lambda a, b: a < b, ">": lambda a, b: a > b,
              r"\le": lambda a, b: a <= b, r"\ge": lambda a, b: a >= b}
_PIECEWISE_SETUP = re.compile(
    r"([fgh])\(([xn])\)\s*=\s*(?:\\left\\\{\s*)?"
    r"\\begin\{(?:cases|array)\}(?:\{cl\})?(.*?)\\end\{(?:cases|array)\}"
    r"(?:\s*\\right\.?)?", re.S,
)


def _piecewise(row, blocks, skeleton):
    if row["id"] not in _PIECEWISE:
        return None
    bindings = _Bindings(row["problem"])
    header, base = _math_body(blocks[0])
    setup = _PIECEWISE_SETUP.fullmatch(header.strip())
    if not setup:
        return None
    fname, variable = setup[1], setup[2]
    base += len(header) - len(header.lstrip()) + setup.start(3)
    branch_source = setup[3]
    branches = []
    cutoffs = {}
    cutoff_re = re.compile(r"(?<![A-Za-z0-9])-?\d+")
    start = 0
    for delim in re.finditer(r"\\\\|\Z", branch_source):
        branch = branch_source[start:delim.start()]
        branch_base = base + start
        start = delim.end()
        if not branch.strip():
            continue
        expression, condition = branch.split("&", 1)
        tree = bindings.parse(expression, branch_base, _FixedPowerParser)
        condition_base = branch_base + len(expression) + 1
        cut = []
        for match in cutoff_re.finditer(condition):
            val = int(match[0])
            # Opposite thresholds such as -5 and 5 can be separate roles,
            # but repeated occurrences of either threshold are one input.
            name = cutoffs.setdefault(val, f"threshold_{len(cutoffs) + 1}")
            cut.append(bindings.bind(name, condition_base + match.start(),
                                     condition_base + match.end(), min(-18, val), max(18, val)))
        text = re.sub(r"\\(?:quad|text)|\{|\}|\$|[\s.,]", "", cutoff_re.sub("#", condition))
        text = text.replace(r"\geq", r"\ge").replace(r"\leq", r"\le").removeprefix("if")
        if text in (f"{variable}iseven", f"{variable}isodd"):
            cond = ("parity", int(text.endswith("odd")))
        elif text in (f"{variable}isaninteger", f"{variable}isnotaninteger"):
            cond = ("integral", "not" not in text)
        else:
            parts = re.split(r"(\\le|\\ge|<|>)", text)
            if len(parts) not in (3, 5) or any(v not in ("#", variable) for v in parts[::2]):
                return None
            inputs = iter(cut)
            operands = [next(inputs) if v == "#" else None for v in parts[::2]]
            cond = ("relations", operands, parts[1::2])
        branches.append((tree, cond))

    def applicable(cond, val, p):
        if cond[0] == "parity":
            return val.denominator == 1 and val.numerator % 2 == cond[1]
        if cond[0] == "integral":
            return (val.denominator == 1) == cond[1]
        _, operands, ops = cond
        values = [val if operand is None else p[operand] for operand in operands]
        return all(_RELATIONS[op](a, b) for op, a, b in zip(ops, values, values[1:]))

    def validate_partition(p):
        order = list(cutoffs)
        return all(p[cutoffs[k]] < p[cutoffs[j]] for k, j in zip(sorted(order), sorted(order)[1:]))

    query_block = blocks[-1]
    query_text, query_start = _math_body(query_block)
    inverse = row["id"] in {"algebra/train/738", "algebra/train/898"}
    if inverse:
        match = re.fullmatch(r"f\(x\)\s*=\s*(-?\d+)", query_text)
        target = bindings.bind("target", query_start + match.start(1), query_start + match.end(1), -20, 20)

        def solve(p):
            if not validate_partition(p):
                raise ValueError("crossed thresholds")
            roots = []
            for (node, keys), condition in branches:
                b, a = _polynomial(node, bindings.values(keys, p), variable)
                root = (p[target] - b) / a
                if applicable(condition, root, p):
                    roots.append(root)
            if not roots:
                raise ValueError("no preimage")
            return sum(roots)
    else:
        query, query_keys = bindings.parse(query_text, query_start, _FixedPowerParser, prefix="argument")
        # Allow signed arguments when the original syntax is a simple single call.
        if re.fullmatch(r"f\(\d+\)", query_text):
            key, _ = query_keys[0]
            old = bindings.domains.pop(key)
            bindings.domains["argument_1"] = _integer_domain(-18, old["max"])
            bindings.original["argument_1"] = bindings.original.pop(key)
            bindings.spans[-1] = (*bindings.spans[-1][:2], "argument_1", *bindings.spans[-1][3:])
            query_keys = [("argument_1", 1)]

        def solve(p):
            if not validate_partition(p):
                raise ValueError("crossed thresholds")

            def evaluate_at(a):
                try:
                    val = _scalar(a)
                except ValueError:
                    if row["id"] != "algebra/train/1530":
                        raise
                    # A non-rational square root cannot be an integer.
                    val = None
                candidates = [(node, keys) for (node, keys), cond in branches
                              if (cond == ("integral", False) if val is None else applicable(cond, val, p))]
                if len(candidates) != 1:
                    raise ValueError("function branch is missing or ambiguous")
                node, keys = candidates[0]
                return _exact(node, bindings.values(keys, p), {variable: a})

            if row["id"] == "algebra/test/964":
                # pi is in (3,4). Vary the branch value, not the cutoffs.
                result = evaluate_at(_rational(Fraction(22, 7)))
            else:
                result = _exact(query, bindings.values(query_keys, p), functions={fname: evaluate_at})
            return _scalar(result)

        if row["id"] == "algebra/test/964":
            for name in cutoffs.values():
                value = bindings.original[name]
                bindings.domains[name] = _integer_domain(value, value)
    return bindings.template(
        "piecewise_preimage_sum" if inverse else "piecewise_evaluation", solve,
        ["The breakpoints retain their original order and repeated breakpoints are shared.",
         "All relevant evaluations are defined and give a rational answer."
         if not inverse else "At least one branch contains its own solution."],
    )


def _equation_roots(polynomial):
    polynomial = _trim(list(polynomial))
    if len(polynomial) == 2:
        b, a = polynomial
        return (Fraction(-b, a),)
    if len(polynomial) == 3:
        c, b, a = polynomial
        discriminant = b * b - 4 * a * c
        if discriminant < 0:
            return ()
        root = _rational_square_root(discriminant)
        return tuple(sorted({(-b - root) / (2 * a), (-b + root) / (2 * a)}))
    raise ValueError("nonconstant linear or quadratic equation required")


def _solve_equation(row, blocks, skeleton):
    if row["id"] in {"intermediate_algebra/train/163", "intermediate_algebra/test/336",
                     "intermediate_algebra/test/616", "algebra/test/518"}:
        return None
    problem = row["problem"]
    mode = None
    if re.fullmatch(r"(?i)Solve for @\s*:\s*@\s*[.]?", skeleton):
        eq, target_block = blocks[1], blocks[0]
    elif re.fullmatch(
        r"(?i)Solve(?: the equation)? @ for @\s*[.]?(?: Express your answer as a simplified fraction\.)?",
        skeleton,
    ):
        eq, target_block = blocks[0], blocks[1]
    elif re.fullmatch(r"(?i)Solve the following equation for @\s*:\s*@\s*[.]?", skeleton):
        eq, target_block = blocks[1], blocks[0]
    elif re.fullmatch(r"(?i)Solve for the (?:largest|smallest) value of @ such that @.*", skeleton):
        # Match the entire optional format request separately.
        if not re.fullmatch(r"(?i)Solve for the (?:largest|smallest) value of @ such that @[.\s]*(?:Express your answer as a simplified common fraction\.)?", skeleton):
            return None
        mode = "largest" if "largest" in skeleton else "smallest"
        eq, target_block = blocks[1], blocks[0]
    elif re.fullmatch(r"(?i)Solve for @, where @ and @[.\s]*(?:Express your answer as a simplified common fraction\.)?", skeleton):
        target, _ = _math_body(blocks[0])
        if _math_body(blocks[1])[0].replace(" ", "") != f"{target}>0":
            return None
        mode, eq, target_block = "positive", blocks[2], blocks[0]
    else:
        return None
    text, offset = _math_body(eq)
    if text.count("=") != 1:
        return None
    left, right = text.split("=")
    bindings = _Bindings(problem)
    nodes = (bindings.parse(left, offset, _PolynomialParser),
             bindings.parse(right, offset + len(left) + 1, _PolynomialParser))
    names = _variables(nodes[0][0]) | _variables(nodes[1][0])
    if len(names) != 1:
        return None
    variable, = names
    if target_block and _math_body(target_block)[0].strip() != variable:
        return None

    def solve(p):
        from .algebra import _poly_gcd
        (n, d), (m, e) = tuple(_rational_polynomials(tree, bindings.values(keys, p), variable)
                              for tree, keys in nodes)
        numerator = _poly_add(_poly_mul(n, e), _poly_mul(m, d), -1)
        # Common factors of the numerator and denominator only contribute
        # excluded poles. Remove all powers of those factors before solving.
        denominator = _poly_mul(d, e)
        while len(numerator) > 1:
            common = _poly_gcd(numerator, denominator)
            if len(common) <= 1:
                break
            numerator, _ = _poly_divmod(numerator, common)
        roots = []
        for candidate in _equation_roots(numerator):
            try:
                a, b = (_evaluate(tree, bindings.values(keys, p), {variable: candidate}, {})
                        for tree, keys in nodes)
            except (ValueError, ArithmeticError):
                continue
            if a == b:
                roots.append(candidate)
        if mode in ("largest", "smallest") and len(roots) == 2:
            return max(roots) if mode == "largest" else min(roots)
        if mode == "positive":
            roots = [r for r in roots if r > 0]
        if len(roots) != 1 or mode in ("largest", "smallest"):
            raise ValueError("requested solution is not uniquely determined")
        return roots[0]

    return bindings.template(
        "quadratic_or_rational_equation", solve,
        ["After excluding poles, the equation must reduce to degree one or two with rational real roots.",
         "The requested root must be uniquely determined; largest/smallest asks about two distinct roots."],
    )


def _function_equation(row, blocks, skeleton):
    ids = {
        "algebra/train/140", "algebra/train/1298", "algebra/test/226",
        "algebra/test/278", "algebra/test/451", "algebra/test/1166",
        "intermediate_algebra/train/625",
    }
    if row["id"] not in ids:
        return None
    bindings = _Bindings(row["problem"])
    definitions = {}
    question = None
    asked = None
    for block in blocks:
        body, offset = _math_body(block)
        match = re.fullmatch(r"\s*([a-z])\(([a-z])\)\s*=\s*(.+)", body)
        if match and match[1] not in definitions:
            definitions[match[1]] = (match[2], *bindings.parse(
                match[3], offset + match.start(3), _FixedPowerParser))
        elif "=" in body:
            left, right = body.split("=")
            question = (bindings.parse(left, offset, _FixedPowerParser),
                        bindings.parse(right, offset + len(left) + 1, _FixedPowerParser))
        elif re.fullmatch(r"[a-z]", body):
            asked = body
        else:
            return None
    if not question or not asked:
        return None

    def difference(p, candidate):
        variables = {asked: _rational(candidate)}

        def function(variable, tree, keys):
            def call(a):
                return _exact(tree, bindings.values(keys, p), {**variables, variable: a})
            return call

        functions = {name: function(*definition) for name, definition in definitions.items()}
        left, right = (_exact(tree, bindings.values(keys, p), variables, functions) for tree, keys in question)
        return _scalar(_add(left, right, -1))

    # Reviewed bindings are affine in the unknown: it occurs once as a
    # coefficient of a known power, or as the input to affine compositions.
    def solve(p):
        zero = difference(p, 0)
        slope = difference(p, 1) - zero
        return -zero / slope

    def reference(p):
        two, three = difference(p, 2), difference(p, 3)
        return 2 - two / (three - two)

    return bindings.template("affine_function_equation", solve,
                             ["The coefficient of the unknown is nonzero."], reference)


def _function_expression(row, blocks, skeleton):
    special = {
        "algebra/train/1472", "algebra/train/1561", "algebra/train/1622",
        "algebra/test/111", "algebra/test/180", "algebra/test/199", "algebra/test/247",
        "algebra/test/897", "algebra/test/918", "intermediate_algebra/train/307",
        "intermediate_algebra/train/1110",
    }
    if row["id"] not in special:
        return None
    if row["id"] in {"intermediate_algebra/train/1163", "intermediate_algebra/train/118"}:
        return None
    bindings = _Bindings(row["problem"])
    definitions, assignments = {}, {}
    query = None
    for block in blocks:
        body, offset = _math_body(block)
        if body in (r"f^{-1}", r"g^{-1}", r"\frac{a}{b}"):
            continue
        definition = re.fullmatch(r"\s*([a-z])\s*\(\s*([a-z])\s*\)\s*=\s*(.+)", body)
        if definition:
            definitions[definition[1]] = (definition[2], *bindings.parse(
                definition[3], offset + definition.start(3), _FixedPowerParser))
            continue
        assignment = re.fullmatch(r"\s*([a-z])\s*=\s*(.+)", body)
        if assignment:
            assignments[assignment[1]] = bindings.parse(
                assignment[2], offset + assignment.start(2), _FixedPowerParser)
            continue
        if query is not None:
            return None
        query = bindings.parse(body, offset, _FixedPowerParser)
    if not query:
        return None

    def solve(p):
        if row["id"] == "algebra/test/897":
            # The middle f cancels one inverse. Inverting a shifted cube
            # exactly is an integer cube-root test on the positive argument.
            value = p["literal_1"] + p["literal_2"]
            root = _integer_root(value,3)
            if root**3 != value:
                raise ValueError("the inverse is not rational")
            return root
        functions = {}

        def direct(variable, tree, keys):
            def apply(argument):
                return _exact(tree, bindings.values(keys, p), {variable: argument}, functions)
            return apply

        def inverse(variable, tree, keys):
            def apply(argument):
                coeffs = _polynomial(tree, bindings.values(keys, p), variable)
                if len(coeffs) not in (2, 4) or any(coeffs[1:-1]):
                    raise ValueError("inverse requires a shifted odd monomial")
                power = Fraction(1, len(coeffs) - 1)
                argument = _add(argument, _rational(coeffs[0]), -1)
                return _exact_power(_multiply(argument, _rational(1 / coeffs[-1])), power)
            return apply

        for name, definition in definitions.items():
            functions[name] = direct(*definition)
            functions[name + "^-1"] = inverse(*definition)
        variables = {name: _exact(tree, bindings.values(keys, p)) for name, (tree, keys) in assignments.items()}
        if row["id"] == "algebra/test/199":
            # The inner function is constant for all x.
            variables["x"] = {}
        if row["id"] == "intermediate_algebra/train/307":
            # A commutator of two affine functions is a constant. A
            # nonconstant rational result would not satisfy the source task.
            variables["x"] = {}
        return _scalar(_exact(query[0], bindings.values(query[1], p), variables, functions))

    return bindings.template(
        "function_composition", solve,
        ["Evaluations and inverses must be defined; inverses are used only for affine or shifted odd monomials.",
         "The final value is rational."],
    )


def build(row):
    if row["subject"] not in ("algebra", "intermediate_algebra"):
        return None
    blocks, skeleton = _blocks(row["problem"])
    for builder in (_polynomial_question, _piecewise, _solve_equation,
                    _function_equation, _function_expression, _scalar_expression,
                    *_structured_builders()):
        try:
            template = builder(row, blocks, skeleton)
        except (ValueError, ArithmeticError, RecursionError):
            continue
        if template is not None:
            # Keep this pass disjoint from the fixed baseline irrespective of
            # where the coordinator lists new modules in the public registry.
            from . import algebra, algebra_extra, arithmetic, discrete, discrete_extra, geometry, word, word_extra
            if any(module.build(row) is not None for module in (
                    algebra, algebra_extra, arithmetic, discrete, discrete_extra, geometry, word, word_extra)):
                return None
            return template
    return None


_DIGITS = re.compile(r"\d+(?:,\d{3})*")


def _derived(row, family, entries, display, solve, constraints=(), check=lambda *p: True, reference=None,
             sampler=None):
    """Bind every displayed digit group to the explicit source form for an ID.

    A display function may repeat a parameter or derive terms (for example a
    progression endpoint). Only the source's own fixed operators stay literal.
    """
    problem = row["problem"]
    spans = list(_DIGITS.finditer(problem))
    original = {name: value for name, value, _, _ in entries}
    domains = {name: _integer_domain(lo, hi) for name, _, lo, hi in entries}

    def args(p):
        return tuple(p[name] for name in original)

    if tuple(int(m[0].replace(",", "")) for m in spans) != tuple(display(*args(original))):
        raise ValueError("source digits differ from the reviewed binding")

    def render(p):
        text = problem
        for match, value in reversed(list(zip(spans, display(*args(p))))):
            if value == int(match[0].replace(",", "")):
                continue
            replacement = f"{value:,}" if "," in match[0] else str(value)
            prefix = problem[:match.start()].rstrip()
            if len(replacement) > 1 and prefix.endswith(("^", "_")):
                replacement = "{" + replacement + "}"
            text = text[:match.start()] + replacement + text[match.end():]
        return text

    return _template(
        "algebra.v2." + family, original, domains, render, lambda p: solve(*args(p)),
        (lambda p: reference(*args(p))) if reference else None,
        lambda p: check(*args(p)), constraints,
        (lambda rng: dict(zip(original, sampler(rng)))) if sampler else None,
    )


def _entries(names, values, low=1, high=30):
    return tuple((name, value, min(low, value), max(high, value))
                 for name, value in zip(names.split(), values))


def _square_without_calculator(row):
    match = re.fullmatch(r"Compute the square of (\d+) without a calculator\.", row["problem"])
    if not match:
        return None
    n = int(match[1])
    return _derived(row, "mental_square", _entries("number", (n,), max(1, n - 80), n + 80),
                    lambda a: (a,), lambda a: a * a,
                    reference=lambda a: sum(2 * i + 1 for i in range(a)))


def _log_bracket(row):
    match = re.fullmatch(
        r"The value of \$\\log_\{(\d+)\}\{(\d+)\}\$ is between the consecutive integers "
        r"\$a\$ and \$b\$\.\s*Find \$a\+b\$\.", row["problem"])
    if not match:
        return None
    base, arg = map(int, match.groups())

    def lower(b, x):
        power, exponent = 1, 0
        while power * b < x:
            power *= b
            exponent += 1
        return exponent, power * b != x

    return _derived(
        row, "logarithm_bracket", _entries("base argument", (base, arg), 2, 36 if arg < 36 else 60000),
        lambda b, x: (b, x), lambda b, x: 2 * lower(b, x)[0] + 1,
        ["The argument is not an integer power of the base, so the inequalities are strict."],
        check=lambda b, x: lower(b, x)[1],
        reference=lambda b, x: sum(2 * j + 1 for j in range(17) if b ** j < x < b ** (j + 1)),
    )


def _sequences(row):
    key = row["id"].replace("intermediate_algebra/", "ia/").replace("algebra/", "a/")

    def case(family, names, values, display, solve, constraints=(), check=lambda *p: True,
             reference=None, low=1, high=30):
        entries = _entries(names, values, low, high) if isinstance(names, str) else names
        return _derived(row, family, entries, display, solve, constraints, check, reference)

    if key == "a/train/132":
        # The mean of the first four terms is at position 2.5.
        return case("arithmetic_term_from_sum", "sum_first_four fifth", (10, 5), lambda s, t: (s, t),
                    lambda s, t: t + Fraction(4 * t - s, 10),
                    reference=lambda s, t: Fraction(14 * t - s, 10))
    if key == "a/train/224":
        return case("sum_of_powers", "base", (3,),
                    lambda b: (b, b, 0, b, 0, b, 1, b, 0, b, 1, b, 2),
                    lambda b: sum(b ** j for j in range(4)), reference=lambda b: (b ** 4 - 1) // (b - 1),
                    low=2)
    if key == "a/train/403":
        # The first two displayed terms are negative, and the next two positive.
        return case("arithmetic_term_difference",
                    (("first_index", 2000, 1, 2400), ("index_gap", 5, 1, 20),
                     ("initial_magnitude", 8, 2, 26), ("step", 6, 2, 22)), (),
                    lambda n, k, a, d: (n, n + k, a, a - d, 2 * d - a, 3 * d - a),
                    lambda n, k, a, d: k * d,
                    ["The first two terms are negative and the following terms positive."],
                    lambda n, k, a, d: d < a < 2 * d,
                    lambda n, k, a, d: (-a + (n + k - 1) * d) - (-a + (n - 1) * d))
    if key == "a/train/430":
        return case("arithmetic_middle_term", "first fifth", (17, 41), lambda a, b: (a, b),
                    lambda a, b: Fraction(a + b, 2))
    if key == "a/train/450":
        def terms(bottom, second):
            return range(bottom, 0, -(bottom - second))

        return case("arithmetic_layer_sum", "bottom second", (28,25),
                    lambda a,b: (a,b), lambda a,b: ((a-1)//(a-b)+1)*(a+1)//2,
                    ["The layers decrease by a constant positive step and the last layer has one can."],
                    lambda a,b: a>b and (a-1)%(a-b)==0,
                    lambda a,b: sum(terms(a,b)), high=90)
    if key == "a/train/475":
        return case("arithmetic_finite_sum", "initial_magnitude step", (2, 5),
                    lambda a, d: (a, d - a, 7 * d - a), lambda a, d: 28 * d - 8 * a,
                    ["The first term is negative and the second positive."], lambda a, d: d > a,
                    lambda a, d: sum(-a + j * d for j in range(8)))
    if key == "a/train/686":
        return case("geometric_ratio", "ratio_numerator ratio_denominator scale", (3, 2, 2),
                    lambda a, b, c: (c * b ** 3, c * a * b ** 2, c * a ** 2 * b, c * a ** 3),
                    lambda a, b, c: Fraction(-(c * a * b ** 2), c * b ** 3),
                    reference=lambda a, b, c: Fraction(-(c * a ** 3), c * a ** 2 * b), high=12)
    if key in ("a/train/706", "a/train/793"):
        first = 6075 if key.endswith("706") else 1000000
        ratio = 3 if first == 6075 else 2

        def final(n, r):
            total = 1
            while n % r == 0:
                n //= r
                total += 1
            return n, total

        return case(
            "geometric_integer_prefix", (("initial", first, 4, first + 2000), ("divisor", ratio, 2, 12)), (),
            lambda n, r: (n, n // r, n // r ** 2, r), lambda n, r: final(n, r)[first == 6075],
            ["The initial term is divisible by the square of the displayed divisor."],
            lambda n, r: n % (r ** 2) == 0,
            lambda n, r: (sum(n % (r ** j) == 0 for j in range(n.bit_length() + 1))
                          if first == 6075 else n // (r ** (final(n, r)[1] - 1))),
        )
    if key == "a/train/808":
        return case("arithmetic_index_from_value",
                    (("first", 88, 10, 110), ("step_magnitude", 3, 1, 14),
                     ("endpoint_magnitude", 17, 1, 100)), (),
                    lambda a, d, n: (a, a - d, a - 2 * d, n),
                    lambda a, d, n: (a + n) // d,
                    ["The first three terms are positive and the negative endpoint is in the progression."],
                    lambda a, d, n: a > 2 * d and (a + n) % d == 0,
                    lambda a, d, n: len(range(a, -n, -d)))
    if key == "a/train/989":
        return case("geometric_earlier_term", "fourth fifth", (32, 64),
                    lambda a, b: (a, b), lambda a, b: a * Fraction(a, b) ** 3,
                    reference=lambda a, b: Fraction(a ** 4, b ** 3), high=96)
    if key == "a/test/52":
        return case("least_positive_arithmetic_term", "first step_magnitude", (1000,13),
                    lambda a,d: (a,a-d,a-2*d,a-3*d), lambda a,d: (a-1)%d+1,
                    ["The four displayed terms must be positive."], lambda a,d: a>3*d,
                    lambda a,d: min(range(a,0,-d)), high=1200)
    if key == "a/train/1621":
        return case("arithmetic_progression_endpoint", "first step", (2,5),
                    lambda a,d: (a,a+d,a+2*d,a+5*d), lambda a,d: (a+3*d)+(a+4*d),
                    reference=lambda a,d: 2*(a+5*d)-3*d)
    if key in {"a/train/1101", "a/test/97"}:
        count = key == "a/test/97"
        first,step,last = (13,7,2008) if count else (2,4,26)
        return case(
            "arithmetic_progression_endpoint",
            (("first",first,1,50), ("step",step,1,20),
             ("last",last,12,3500 if count else 200)), (),
            (lambda a,d,b: (a,a+d,a+2*d,a+3*d,b)) if count else (lambda a,d,b: (a,a+d,a+2*d,b)),
            (lambda a,d,b: (b-a)//d+1) if count else (lambda a,d,b: 2*b-3*d),
            ["The last term lies on the same arithmetic progression as the displayed initial terms."],
            lambda a,d,b: b-a>=5*d and (b-a)%d==0,
            (lambda a,d,b: len(range(a,b+1,d))) if count else
            (lambda a,d,b: sum(list(range(a,b+1,d))[-3:-1])),
        )
    if key == "a/train/1055":
        return case("arithmetic_middle_term", "given_sum", (6,), lambda s: (s,), lambda s: Fraction(s, 2))
    if key == "a/train/1243":
        return case("geometric_middle_term", "first third_numerator third_denominator", (20, 5, 4),
                    lambda a, n, d: (a, n, d), lambda a, n, d: _rational_square_root(Fraction(a * n, d)),
                    ["The product of the first and third terms is a positive rational square."],
                    lambda a, n, d: isqrt(a * n * d) ** 2 == a * n * d,
                    lambda a, n, d: Fraction(isqrt(a * n * d), d))
    if key == "a/train/1351":
        return case("geometric_later_term", "seventh tenth", (7, 21), lambda a, b: (a, b, 13),
                    lambda a, b: Fraction(b * b, a),
                    reference=lambda a, b: b * Fraction(b, a))
    if key == "a/train/1481":
        return case("finite_geometric_sum", "first_magnitude ratio", (1, 3),
                    lambda a, r: tuple(a * r ** j for j in range(7)), lambda a, r: -sum(a * r ** j for j in range(7)),
                    reference=lambda a, r: -a * ((r ** 7 - 1) // (r - 1) if r != 1 else 7), high=12)
    if key == "a/train/1024":
        return case("arithmetic_finite_sum",
                    (("denominator", 5, 1, 24), ("last", 10, 5, 90)), (),
                    lambda d, n: (1, d, 2, d, 3, d, n - 1, d, n, d),
                    lambda d, n: Fraction(n * (n + 1), 2 * d),
                    reference=lambda d, n: sum(Fraction(j, d) for j in range(1, n + 1)))
    if key == "a/train/1588":
        return case("arithmetic_sum_remainder",
                    (("count", 102, 1, 220), ("divisor", 5250, 2, 8000)), (),
                    lambda n, m: (n, m, 1), lambda n, m: n * (n + 1) // 2 % m,
                    reference=lambda n, m: sum(range(1, n + 1)) % m)
    if key == "a/test/140":
        return case("arithmetic_two_terms", "first step", (2222, 1010), lambda a, d: (a, d),
                    lambda a, d: 2 * a + 11 * d,
                    reference=lambda a, d: sum(range(a + 5 * d, a + 7 * d, d)), high=2400)
    if key == "a/test/152":
        return case("prime_factor_of_triangular_number", "last", (80,), lambda n: (1, 2, 3, n),
                    lambda n: _factor(n * (n + 1) // 2)[-1][0], low=4, high=160,
                    reference=lambda n: max(p for m in (n, n + 1) for p, _ in _factor(m)))
    if key == "a/test/235":
        return case("geometric_missing_terms", "fifth ratio_divisor", (3, 3),
                    lambda e, r: (e * r ** 4, e * r ** 3, e), lambda e, r: e * r * (r + 1),
                    reference=lambda e, r: sum(Fraction(e * r ** 4, r ** j) for j in (2, 3)), low=2, high=12)
    if key == "a/test/465":
        return case("arithmetic_initial_equals_step", "fourth", (8,), lambda d: (d,), lambda d: Fraction(d, 4))
    if key == "a/test/586":
        return case("arithmetic_prime_product", "product_first_third", (5,), lambda p: (p,),
                    lambda p: 1 + 3 * ((p - 1) // 2),
                    ["The product is an odd prime; positivity of the infinite progression rules out a negative step."],
                    lambda p: p > 2 and _factor(p) == ((p, 1),),
                    lambda p: next(a + 3 * d for a in range(1, p + 1) for d in range(p)
                                   if a * (a + 2 * d) == p), low=3, high=41)
    if key == "a/test/911":
        return case("arithmetic_middle_term", "offset middle", (6, 12), lambda a, b: (a, b),
                    lambda a, b: b - Fraction(a, 2))
    if key == "a/test/988":
        return case("odd_sequence_term", "index", (2003,), lambda n: (n, 1, 3, 5, 7), lambda n: 2 * n - 1,
                    ["The index ends in an ordinal-compatible 3 (but not 13)."],
                    lambda n: n % 10 == 3 and n % 100 != 13,
                    lambda n: range(1, 2 * n + 1, 2)[-1], high=2400)
    if key in ("ia/train/862", "ia/test/149"):
        odd = key.endswith("862")
        return case("alternating_integer_sum", (("last", 99 if odd else 100, 8, 300),), (),
                    (lambda n: (1, 2, 3, 4, n - 1, n)) if odd else (lambda n: (1, 2, 3, 4, 5, n - 1, n)),
                    lambda n: (n + 1) // 2 if odd else -(n // 2),
                    ["The endpoint parity matches the last displayed sign."], lambda n: n % 2 == int(odd),
                    lambda n: sum(j if j % 2 else -j for j in range(1, n + 1)))
    if key == "ia/train/518":
        return case("geometric_block_sums",
                    (("block_length", 2011, 1, 2300), ("first_sum", 200, 1, 310), ("second_sum", 380, 2, 620)), (),
                    lambda n, a, b: (n, a, 2 * n, b, 3 * n),
                    lambda n, a, b: b + Fraction((b - a) ** 2, a),
                    ["The block ratio is positive, so a real geometric progression exists for every block length."],
                    lambda n, a, b: b > a,
                    lambda n, a, b: sum(a * Fraction(b - a, a) ** i for i in range(3)))
    if key == "ia/train/544":
        return case("constant_sliding_sum", "third triple_sum", (5, 30), lambda a, s: (a, s),
                    lambda a, s: s - a)
    if key == "ia/train/591":
        def direct(a, n):
            result = a
            for k in range(1, n):
                result += a + k
            return result

        return case("additive_sequence_recurrence", "first index", (1, 12),
                    lambda a, n: (1, a, n), lambda a, n: n * a + n * (n - 1) // 2,
                    reference=direct, high=120)
    if key == "ia/train/721":
        return case("geometric_square_sum", "sum sum_of_squares", (15, 45), lambda a, b: (a, b),
                    lambda a, b: Fraction(2 * a * b, a * a + b),
                    ["Both sums are positive; the reconstructed common ratio lies in (-1, 1)."],
                    reference=lambda a, b: a * (1 - Fraction(a * a - b, a * a + b)), high=130)
    if key == "ia/train/847":
        def loop(a, b, n):
            a, b = Fraction(a), Fraction(b)
            for _ in range(n - 1):
                a, b = b, b / a
            return a
        return case("quotient_recurrence",
                    (("first", 2, 1, 30), ("second", 3, 1, 30), ("index", 2006, 1, 2600)), (),
                    lambda a, b, n: (1, 2, 1, a, 2, b, 1, 2, 3, n),
                    lambda a, b, n: (Fraction(a), Fraction(b), Fraction(b, a), Fraction(1, a),
                                     Fraction(1, b), Fraction(a, b))[(n - 1) % 6],
                    reference=loop)
    if key == "ia/train/861":
        def loop(a, b, n):
            if n == 1:
                return a
            for k in range(3, n + 1):
                a, b = b, b - a + k
            return b
        return case("linear_recurrence",
                    (("initial_value", 1, 0, 15), ("index", 2018, 1, 2600)), (),
                    lambda a, n: (1, 2, a, 1, 2, 3, n), lambda a, n: loop(a, a, n),
                    reference=lambda a, n: n + 1 + (a - 2, a - 3, -1, 2 - a, 3 - a, 1)[(n - 1) % 6])
    if key == "ia/train/924":
        return case("prefix_mean_recurrence", "first later later_index", (19, 99, 9),
                    lambda a, c, n: (1, 2, 3, 1, a, n, c, 3, 1, 2),
                    lambda a, c, n: 2 * c - a,
                    ["The given later term is at index three or greater."], lambda a, c, n: n >= 3,
                    high=130)
    if key == "ia/train/971":
        return case("term_from_prefix_mean", "index", (2008,), lambda n: (n,),
                    lambda n: n * n - (n - 1) ** 2,
                    ["The displayed ordinal suffix remains correct."],
                    lambda n: n % 10 not in (1, 2, 3) or 11 <= n % 100 <= 13,
                    lambda n: 2 * n - 1, high=2400)
    if key == "ia/test/50":
        def index(a, b):
            return isqrt(max(0, b - a))
        return case("arithmetic_sum_from_odd_increments", "original_sum revised_sum", (715, 836),
                    lambda a, b: (a, 1, 3, 5, b),
                    lambda a, b: Fraction(3 * a, index(a, b)),
                    ["The sum increase is an odd square greater than 1, so the middle term exists."],
                    lambda a, b: b > a and index(a, b) >= 3 and index(a, b) % 2 == 1 and index(a, b) ** 2 == b - a,
                    high=950)
    if key == "ia/test/162":
        return case("alternating_affine_sum",
                    (("slope", 3, 1, 25), ("constant", 2, 1, 30), ("count", 100, 3, 240)), (),
                    lambda a, b, n: (1, 1, a, b, 1, 2, n),
                    lambda a, b, n: -(n // 2) * a + (a * n + b if n % 2 else 0),
                    reference=lambda a, b, n: sum((-1) ** (j + 1) * (a * j + b) for j in range(1, n + 1)))
    if key == "ia/test/386":
        def recurrence(a, b, c, n):
            for _ in range(n - 1):
                a, b, c = b, c, a + b - c
            return a
        return case("subtract_previous_recurrence",
                    (("first", 2001, 1, 2200), ("second", 2002, 1, 2200),
                     ("third", 2003, 1, 2200), ("index", 2004, 4, 2400)), (),
                    lambda a, b, c, n: (a, b, c, a, b, c, a + b - c, n),
                    recurrence,
                    ["The fourth term shown in the example is positive; the ordinal suffix remains correct."],
                    lambda a, b, c, n: a + b > c and (n % 10 not in (1, 2, 3) or 11 <= n % 100 <= 13),
                    lambda a, b, c, n: Fraction(
                        a + 2 * b + c + (-1) ** (n - 1) * (3 * a - 2 * b - c + 2 * (n - 1) * (c - a)), 4))
    if key == "ia/test/416":
        return case("prefix_sum_recurrence", "known_index known_value gap", (19, 99, 1),
                    lambda j, a, d: (1, 2, 3, 2, j, a, j + d),
                    lambda j, a, d: a * 2 ** d,
                    ["The known term occurs after index one."], lambda j, a, d: j >= 2,
                    lambda j, a, d: sum(a * 2 ** k for k in range(d)) + a)
    if key == "ia/test/451":
        def solve(a, b):
            return _scalar(_exact_power(_rational(Fraction(b, a)), Fraction(1, 7)))
        seventh_powers = {Fraction(n, d)**7 for n in range(1, 5) for d in range(1, 5)}
        return case("geometric_ratio_from_terms",
                    (("fourth", 24, 1, 90), ("eleventh", 3072, 1, 8000)), (),
                    lambda a, b: (a, b), solve,
                    ["The ratio of displayed terms is the seventh power of a fraction with numerator and denominator from one through four."],
                    lambda a, b: Fraction(b, a) in seventh_powers,
                    lambda a, b: next(Fraction(n, d) for n in range(1, 5) for d in range(1, 5)
                                      if Fraction(b, a) == Fraction(n, d) ** 7))
    if key == "ia/test/636":
        return case("quadratic_product_recurrence", "index", (100,),
                    lambda n: (1, 1, 2, 2, 2, 1, 1, 1, 2, n),
                    lambda n: n, reference=lambda n: _product_recurrence(n), high=240)
    if key == "ia/test/719":
        def digits(a, b, count):
            for _ in range(count):
                yield a
                a, b = b, (a + b) % 10

        def index(a, b, threshold):
            acc = 0
            for n, value in enumerate(digits(a, b, threshold * 3 + 8), 1):
                acc += value
                if acc > threshold:
                    return n
            raise ValueError("threshold not reached")

        return case("modular_sequence_threshold",
                    (("first", 4, 0, 9), ("second", 7, 0, 9), ("threshold", 10000, 50, 15000)), (),
                    lambda a, b, s: (*digits(a, b, 7), 2, s), index,
                    ["The two initial digits are not both zero."], lambda a, b, s: bool(a or b))
    if key == "ia/test/722":
        def values(a, b, m, count):
            for _ in range(count):
                yield a
                a, b = b, (a + b) % m

        def cycle_sum(a, b, m, n):
            start = a, b
            cycle = [a]
            a, b = b, (a + b) % m
            while (a, b) != start:
                cycle.append(a)
                a, b = b, (a + b) % m
            return sum(cycle[(n + k) % len(cycle)] for k in range(8))

        return case("modular_sequence_window",
                    (("first", 0, 0, 8), ("second", 1, 0, 8), ("modulus", 3, 2, 15),
                     ("start_index", 2017, 3, 2500)), (),
                    lambda a, b, m, n: (0, a, 1, b, 1, 2, m, 2, *values(a, b, m, 6), *range(n, n + 8)),
                    cycle_sum, ["Both starting values lie between zero and modulus minus one, and at least one is nonzero."],
                    lambda a, b, m, n: (a or b) and a < m and b < m,
                    lambda a, b, m, n: sum(list(values(a, b, m, n + 8))[n:]))
    return None


def _product_recurrence(n):
    a, b = Fraction(1), Fraction(2)
    for _ in range(n - 1):
        a, b = b, (b * b - 1) / a
    return a


def _coordinates(row):
    key = row["id"].removeprefix("algebra/")
    if key == row["id"]:
        return None

    def case(family, names, values, display, solve, constraints=(), check=lambda *p: True,
             reference=None, low=0, high=28):
        return _derived(row, family, _entries(names, values, low, high), display, solve,
                        constraints, check, reference)

    identity = lambda *p: p
    if key == "train/10":
        return case("diameter_center", "x1 neg_y1 neg_x2 neg_y2", (9, 5, 3, 1), identity,
                    lambda x, y, u, v: Fraction(x - y - u - v, 2),
                    ["The diameter has two distinct endpoints."],
                    lambda x, y, u, v: x != -u or y != v,
                    lambda x, y, u, v: Fraction(x - u, 2) - Fraction(y + v, 2))
    if key == "train/45":
        return case("point_and_slope", "negative_slope_magnitude x y", (7, 3, 0), identity,
                    lambda m, x, y: -m + y + m * x,
                    reference=lambda m, x, y: y + (x - 1) * m)
    if key == "train/361":
        return case("parallel_intercept", "slope given_intercept x y", (2, 4, 2, 5), identity,
                    lambda m, b, x, y: y - m * x,
                    ["The line must have nonzero slope."], lambda m, b, x, y: m > 0)
    if key == "train/784":
        return case("point_slope_intercepts", "y slope x", (4, 4, 8), identity,
                    lambda y, m, x: (y - m * x) * (1 - Fraction(1, m)),
                    ["The line must have nonzero slope."], lambda y, m, x: m > 0,
                    lambda y, m, x: y - m * x + x - Fraction(y, m))
    if key == "train/990":
        return case("horizontal_intercept", "height", (13,), identity, lambda y: y)
    if key == "train/1279":
        return case("point_from_slope", "height slope_numerator slope_denominator", (4, 2, 3),
                    lambda y, m, n: (0, 0, y, m, n), lambda y, m, n: y + Fraction(y * n, m),
                    ["The height and both slope components are nonzero."], low=1)
    if key == "train/1660":
        return case("intercept_separation", "slope1 slope2 x y", (3, 5, 10, 15), identity,
                    lambda a, b, x, y: abs(Fraction(y, a) - Fraction(y, b)),
                    ["The slopes are distinct and nonzero."], lambda a, b, x, y: a != b,
                    lambda a, b, x, y: abs((x - Fraction(y, a)) - (x - Fraction(y, b))), low=1)
    if key == "train/1691":
        return case("linear_intercept", "y_coefficient_magnitude rhs", (2, 5), identity,
                    lambda a, b: Fraction(-b, a), low=1)
    if key == "train/1706":
        return case("coordinate_from_slope", "neg_x1 y1 x2 slope_numerator slope_denominator",
                    (2, 7, 4, 3, 2), identity, lambda x, y, u, m, n: y - Fraction(m * (x + u), n), low=1)
    if key == "test/645":
        return case("slope_between_midpoints", "x1 y1 x2 neg_y2 x3 y3 x4 y4",
                    (2, 4, 0, 2, 5, 1, 1, 5), identity,
                    lambda x, y, u, v, z, w, s, t: Fraction(w + t - y + v, z + s - x - u),
                    ["The two midpoints have distinct x coordinates."],
                    lambda x, y, u, v, z, w, s, t: z + s != x + u,
                    lambda x, y, u, v, z, w, s, t: (
                        (Fraction(w + t, 2) - Fraction(y - v, 2)) /
                        (Fraction(z + s, 2) - Fraction(x + u, 2))))
    if key == "test/741":
        # TeX has two unbraced fraction digits here, not the integer 12.
        return case("point_slope_intercept", "x neg_y slope_numerator slope_denominator",
                    (2, 3, 1, 2), lambda x, y, m, n: (x, y, 10 * m + n),
                    lambda x, y, m, n: -y - Fraction(x * m, n),
                    ["Both unbraced fraction fields are one nonzero digit."],
                    lambda x, y, m, n: m <= 9 and n <= 9, low=1)
    if key == "test/876":
        return case("perpendicular_intercept_form", "x_intercept neg_y_intercept", (4, 5),
                    lambda x, y: (x, y, 1), lambda x, y: Fraction(-x, y),
                    ["The unbraced fraction fields are one nonzero digit."], low=1, high=9)
    if key == "test/937":
        return case("line_x_intercept", "x1 y1 x2 y2", (7, 4, 6, 3), identity,
                    lambda x, y, u, v: x - Fraction(y * (u - x), v - y),
                    ["The two y coordinates are distinct."], lambda x, y, u, v: y != v,
                    lambda x, y, u, v: Fraction(x * v - u * y, v - y))
    return None


def _structured_builders():
    def wrap(builder):
        return lambda row, blocks, skeleton: builder(row)
    return tuple(wrap(builder) for builder in (_square_without_calculator, _log_bracket, _sequences, _coordinates,
                                                       _identities, _series, _algebra_cases, _operator_cases, _two_number_cases, _coordinate_polynomial_cases, _quotient_and_log_cases))


def _constrain_bindings(bindings, query, definitions, ties, fixed):
    spans = list(bindings.spans)
    canonical = {}
    for group in ties:
        first = spans[group[0]][2]
        for index in group[1:]:
            other = spans[index][2]
            if bindings.original[other] != bindings.original[first]:
                raise ValueError("shared literals differ")
            d, o = bindings.domains[first], bindings.domains[other]
            d["min"] = max(d["min"], o["min"])
            d["max"] = min(d["max"], o["max"])
            canonical[other] = first
    for index in fixed:
        name = canonical.get(spans[index][2], spans[index][2])
        val = bindings.original[name]
        bindings.domains[name] = _integer_domain(val, val)
    for index, (start, end, name, raw, scale) in enumerate(spans):
        bindings.spans[index] = (start, end, canonical.get(name, name), raw, scale)
    for alias in canonical:
        bindings.original.pop(alias)
        bindings.domains.pop(alias)

    def replace(parsed):
        node, keys = parsed
        return node, [(canonical.get(n, n), scale) for n, scale in keys]

    return replace(query), [(name, replace(parsed)) for name, parsed in definitions]


def _identities(row):
    key = row["id"].replace("intermediate_algebra/", "ia/").replace("algebra/", "a/")

    def case(family, names, values, display, solve, constraints=(), check=lambda *p: True,
             reference=None, low=1, high=25, sampler=None):
        entries = _entries(names, values, low, high) if isinstance(names, str) else names
        return _derived(row, family, entries, display, solve, constraints, check, reference, sampler)

    if key in {"a/train/81", "a/train/327"}:
        sign = 1 if key.endswith("81") else -1
        original = (4, 6, 5) if sign == 1 else (3, 8, 6)
        return case(
            "square_over_linear",
            (("exponent", original[0], 1, 8), ("shift_magnitude", original[1], 1, 25),
             ("input", original[2], 1, 15)), (),
            lambda k, h, x: (2 * k, 2 * h, k, h * h, k, h, x),
            lambda k, h, x: Fraction(x ** (2 * k) + sign * 2 * h * x ** k + h * h, x ** k + sign * h),
            ["The denominator does not vanish; the numerator is its square."],
            lambda k, h, x: x ** k + sign * h != 0,
            lambda k, h, x: x ** k + sign * h,
        )
    if key == "a/train/535":
        def pick(rng):
            degree = rng.randint(2,5)
            value = rng.randint(2, _integer_root(10**12, 4*degree))
            return degree, value**(4*degree)

        return case("nested_root_reciprocal",
                    (("middle_degree",3,2,5), ("denominator",4096,1,10**12)), (),
                    lambda k,n: (k,1,n), lambda k,n: Fraction(1,_integer_root(n,4*k)),
                    ["The denominator is a perfect power of order four times the middle root index."],
                    lambda k,n: _integer_root(n,4*k)**(4*k)==n,
                    lambda k,n: Fraction(1,prod(p**(e//(4*k)) for p,e in _factor(n))), sampler=pick)
    if key == "a/train/739":
        return case("logarithm_of_reciprocal_power", "base denominator_exponent", (3,1),
                    lambda b,e: (b,1,b**e), lambda b,e: _log(_rational(b),_rational(Fraction(1,b**e))),
                    ["The unbraced base is a single digit greater than one."], lambda b,e: 2<=b<=9,
                    lambda b,e: -e, high=9)
    if key == "a/train/751":
        def calculate(b, k, m, a):
            c = a + b - k
            return Fraction(a + b, a + b - m) * Fraction(a + b - m, a) * Fraction(c + k - b, c + k - 2 * b)

        return case("tied_rational_substitution", "offset_b offset_c offset_numerator input",
                    (2, 10, 1, 4), lambda b, k, m, a: (b, b - m, m, b, k - b, k - 2 * b, k, b, a),
                    calculate,
                    ["The displayed positive shifts stay positive and all denominators are nonzero."],
                    lambda b, k, m, a: b > m and k > 2 * b and a != b,
                    lambda b, k, m, a: Fraction(a + b, a - b), high=18)
    if key == "a/test/76":
        def pick(rng):
            while True:
                prefix = tuple(rng.randint(2, 30) for _ in range(3))
                needed = prod(p ** (-e % 3) for p, e in _factor(prod(prefix)))
                if needed <= 100:
                    limit = _integer_root(100 // needed, 3)
                    return *prefix, needed * rng.randint(1, limit) ** 3

        return case("product_of_cube_roots",
                    (("first", 12, 1, 100), ("second", 20, 1, 100),
                     ("third", 15, 1, 100), ("fourth", 60, 1, 100)), (),
                    lambda a, b, c, d: (3, a, 3, b, 3, c, 3, d),
                    lambda *terms: _integer_root(prod(terms), 3),
                    ["The product of radicands is a perfect cube."],
                    lambda *terms: _integer_root(prod(terms), 3) ** 3 == prod(terms),
                    lambda *terms: prod(p ** (e // 3) for p, e in _factor(prod(terms))),
                    sampler=pick)
    if key == "a/test/207":
        # Keep the overlapping arithmetic progressions and two unbraced digits.
        return case("finite_fraction_product", "initial ratio", (2, 2),
                    lambda a, r: tuple(
                        v for j in range(6) for v in
                        ((10*r*(a+j)+a+j+1,) if j<3 else (r*(a+j),a+j+1))),
                    lambda a, r: prod(Fraction(r * j, j + 1) for j in range(a, a + 6)),
                    ["Each originally unbraced fraction field must be one digit."],
                    lambda a, r: (a + 2) * r <= 9 and a + 3 <= 9,
                    lambda a, r: Fraction(r ** 6 * a, a + 6), high=8)
    if key == "a/test/281":
        def total(b, a, n, d, e, f, c, m, h, i, j):
            return (a + Fraction(n, d)) * Fraction(e, f) + 2 * (c + Fraction(m, h)) * Fraction(i, j)

        def exact(*p):
            return _scalar(_exact_power(_rational(p[0]), total(*p)))

        return case("tied_rational_powers", "base whole1 num1 den1 out_num1 out_den1 whole2 num2 den2 out_num2 out_den2",
                    (2, 1, 1, 4, 2, 5, 3, 1, 8, 2, 25),
                    lambda b, a, n, d, e, f, c, m, h, i, j: (b, a, n, d, e, f, b * b, c, m, h, i, j),
                    exact, ["Both displayed mixed fractions have proper fractional parts, and the result is rational."],
                    lambda *p: p[2] < p[3] and p[7] < p[8] and total(*p).denominator == 1 and total(*p) <= 30,
                    lambda *p: p[0] ** int(total(*p)), high=8)
    if key == "ia/train/264":
        return case("consecutive_product_under_root", "least", (28,),
                    lambda n: (n + 3, n + 2, n + 1, n, 1),
                    lambda n: isqrt(n * (n + 1) * (n + 2) * (n + 3) + 1),
                    reference=lambda n: n * (n + 3) + 1, high=300)
    if key == "ia/train/1119":
        def solve(exponent):
            one_plus_i = {(): Fraction(1), ((-1, Fraction(1,2)),): Fraction(1)}
            return _scalar(_exact_power(one_plus_i, Fraction(exponent)))

        return case("gaussian_integer_power", (("exponent",4,4,36),), (),
                    lambda n: (1,n), solve,
                    ["The exponent is a positive multiple of four, so the answer is real."],
                    lambda n: n%4==0, lambda n: (-4)**(n//4))
    if key == "ia/train/1269":
        def evaluate(a, b, c):
            weights = (Fraction(1, b) - Fraction(1, c), Fraction(1, c) - Fraction(1, a),
                       Fraction(1, a) - Fraction(1, b))
            return sum(x * x * w for x, w in zip((a, b, c), weights)) / sum(
                x * w for x, w in zip((a, b, c), weights))
        return case("cyclic_fraction_identity", "first second third", (11, 13, 17),
                    lambda a, b, c: (a*a, 1, b, 1, c, b*b, 1, c, 1, a, c*c, 1, a, 1, b,
                                     a, 1, b, 1, c, b, 1, c, 1, a, c, 1, a, 1, b),
                    evaluate, ["The three displayed bases are distinct and positive."],
                    lambda a, b, c: len({a, b, c}) == 3,
                    lambda a, b, c: a + b + c)
    if key == "ia/test/264":
        return case("remainder_with_power_cancellation",
                    (("divisor_shift", 2, 1, 14), ("linear_multiplier", 5, 2, 18),
                     ("paired_root_value", 3, 2, 25), ("high_exponent", 611, 3, 1200),
                     ("paired_exponent", 11, 3, 39), ("quadratic_coefficient", 3, 1, 20),
                     ("constant", 1, 1, 20)), (),
                    lambda b, a, c, n, k, q, d: (a, a * b - 1, n, b + c, k, c - b, k, q, 2, d, b),
                    lambda b, a, c, n, k, q, d: (a * -b + a * b - 1) ** n + c ** k + (-c) ** k + q * b * b + d,
                    ["The two paired powers have the same odd exponent; their values at the divisor root are opposite."],
                    lambda b, a, c, n, k, q, d: c > b and k % 2 == 1,
                    lambda b, a, c, n, k, q, d: (-1) ** n + q * b * b + d)
    if key == "ia/test/739":
        def integer_log(base, argument):
            exponent = 0
            while argument > 1 and argument%base == 0:
                exponent += 1
                argument //= base
            return exponent if argument == 1 else 0

        def valid(base, argument, middle):
            first = integer_log(base, argument)
            if first < 2:
                return False
            second = integer_log(first, middle)
            return second > 1 and _safe_rational_log(second, argument)

        def solve(base, argument, middle):
            first = _log(_rational(base), _rational(argument))
            second = _log(_rational(first), _rational(middle))
            return _log(_rational(second), _rational(argument))

        def pick(rng):
            while True:
                base = rng.randint(2,9)
                first = rng.randint(2,12)
                second = base**rng.randint(1,2)
                if first**second <= 10**12:
                    return base, base**first, first**second

        return case("nested_logarithms",
                    (("base",2,2,9), ("argument",256,4,10**12), ("middle_argument",64,4,10**12)), (),
                    lambda b,a,m: (b,a,m,a), solve,
                    ["The two inner logarithms are integers greater than one and the outer logarithm is rational."],
                    valid, sampler=pick)
    if key == "ia/test/444":
        return case("fourth_finite_difference", "start step", (2001, 2),
                    lambda a, d: (a + 4*d, 4, 4, a + 3*d, 4, 6, a + 2*d, 4, 4, a + d, 4, a, 4),
                    lambda a, d: sum(c * (a + j * d) ** 4 for j, c in enumerate((1, -4, 6, -4, 1))),
                    reference=lambda a, d: 24 * d ** 4, high=2500)
    return None


def _integer_root(n, order):
    low, high = 0, 1 << ((n.bit_length() + order - 1) // order)
    while low < high:
        m = (low + high + 1) // 2
        if m ** order <= n:
            low = m
        else:
            high = m - 1
    return low


def _series(row):
    key = row["id"].replace("intermediate_algebra/", "ia/").replace("algebra/", "a/")

    def case(family, names, values, display, solve, constraints=(), check=lambda *p: True,
             reference=None, low=1, high=30):
        return _derived(row, family, _entries(names, values, low, high), display, solve, constraints, check, reference)

    if key == "ia/train/141":
        return case("paired_geometric_sums", "first sum_product", (12, 2016),
                    lambda a, b: (1, 1, a, a, a, 2, a, 3, 1, 1, b),
                    lambda a, b: Fraction(2 * b, a),
                    ["The target product is at least the square of the first term."], lambda a, b: b >= a*a, high=2600)
    if key == "ia/train/186":
        return case("finite_telescoping_sum", "last", (1000,), lambda n: (1, n, 1, 2),
                    lambda n: Fraction(n, n + 1),
                    reference=lambda n: sum(Fraction(1, j*j+j) for j in range(1, n + 1)), high=1800)
    if key == "ia/train/258":
        return case("infinite_affine_geometric_sum", "linear constant base", (3, 1, 2),
                    lambda a, c, b: (1, a, c, b),
                    lambda a, c, b: Fraction(a*b, (b-1)**2) - Fraction(c, b-1),
                    ["The base exceeds 1."], lambda a, c, b: b > 1)
    if key == "ia/train/418":
        def ratio(a, b, c, d):
            m = min(a, b, c, d)

            def part(n):
                return prod(range(m + 1, n + 1))

            return Fraction(part(a) + part(b), part(c) + part(d))

        return case("floor_factorial_ratio", "top nearby", (2007, 2004),
                    lambda a, b: (a, b, a - 1, a - 2),
                    lambda a, b: ratio(a, b, a - 1, a - 2).__floor__(),
                    ["The four factorial arguments are nonnegative, and all differ by at most 12."],
                    lambda a, b: 3 <= a and 0 <= a - b <= 12, low=3, high=2100)
    if key == "ia/train/471":
        def evaluate(a, d):
            b, c = a + d, a + 2*d
            return (Fraction(c ** 3, a*b) - Fraction(a ** 3, b*c)).__floor__()

        return case("floor_paired_cubic_ratios", "first step", (2003, 1),
                    lambda a, d: (a + 2*d, 3, a, a + d, a, 3, a + d, a + 2*d),
                    evaluate, reference=lambda a, d: Fraction((a+2*d)**4 - a**4, a*(a+d)*(a+2*d)).__floor__(),
                    high=2100)
    if key == "ia/train/476":
        return case("finite_telescoping_product", "last shift", (20, 3),
                    lambda n, k: (1, n, k), lambda n, k: prod(Fraction(i + k, i) for i in range(1, n + 1)),
                    reference=lambda n, k: prod(Fraction(n + j, j) for j in range(1, k + 1)), high=90)
    if key == "ia/train/679":
        return case("paired_alternating_squares", "last", (100,),
                    lambda n: (n, 2, n - 1, 2, n - 2, 2, n - 3, 2, n - 4, 2, 4, 2, 3, 2, 2, 2, 1, 2),
                    lambda n: n * (n + 1),
                    ["The highest term is a multiple of four and exceeds the trailing displayed block."],
                    lambda n: n >= 12 and n % 4 == 0,
                    lambda n: sum(j*j if (n-j) % 4 < 2 else -j*j for j in range(1, n + 1)), high=300)
    if key == "ia/train/762":
        return case("finite_telescoping_product", "factor last", (4, 501),
                    lambda a, n: (2*a, a, 3*a, 2*a, 4*a, 3*a, a, a, a, (n + 1)*a, n*a),
                    lambda a, n: Fraction((n + 1)*a, a), ["The indexed example lies within the product."],
                    lambda a, n: n >= 5,
                    lambda a, n: prod(Fraction((j+1)*a, j*a) for j in range(1, n+1)), high=550)
    if key == "ia/train/824":
        return case("infinite_telescoping_sum", "shift", (2,), lambda k: (1, 1, k),
                    lambda k: sum(Fraction(1, j) for j in range(1, k + 1)) / k)
    if key == "ia/train/839":
        return case("cesaro_sum_after_prepend", "length original_sum prepended", (99, 1000, 1),
                    lambda n, s, a: (1, n, s, n + 1, a),
                    lambda n, s, a: a + Fraction(n*s, n+1), high=1500)
    if key == "ia/test/108":
        return case("infinite_telescoping_sum", "start constant", (2, 3), lambda n, c: (n, c, 2, 1),
                    lambda n, c: Fraction(1-c, 2*(n-1)) + Fraction(1+c, 2*n),
                    ["The start exceeds one, avoiding denominator zeros."], lambda n, c: n > 1)
    if key == "ia/test/289":
        return case("infinite_affine_geometric_sum", "linear base1 numerator base2", (2, 3, 1, 2),
                    lambda a, b, c, d: (1, a, b, c, d),
                    lambda a, b, c, d: Fraction(a*b, (b-1)**2) - Fraction(c, d-1),
                    ["Both bases exceed one."], lambda a, b, c, d: b > 1 and d > 1)
    if key == "ia/test/496":
        return _derived(row, "floor_quadratic_radical",
                        (("linear",10,1,65), ("constant",29,1,180), ("input",19941994,66,19942050)),
                        lambda a,b,n: (2,a,b,n), lambda a,b,n: isqrt(n*n-a*n+b),
                        ["The input exceeds the linear coefficient, so the radicand is positive."])
    if key == "ia/test/510":
        return case("infinite_telescoping_sum", "start", (0,), lambda n: (n, 4, 2, 1),
                    lambda n: Fraction(1, 2*(n*n - n + 1)), low=0)
    if key == "ia/test/608":
        return case("finite_polynomial_sum", "last", (19,),
                    lambda n: (1, 2, 2, 2, 3, 2, 3, 4, 2, n, n + 1, 2),
                    lambda n: sum(j*(j+1)**2 for j in range(1, n+1)),
                    ["The last index follows the explicitly displayed initial terms."], lambda n: n >= 5,
                    lambda n: (n*(n+1)//2)**2 + n*(n+1)*(2*n+1)//3 + n*(n+1)//2)
    if key == "ia/test/766":
        return case("paired_arithmetic_sum", "first offset step final_upper", (751, 6, 3, 496),
                    lambda a, k, d, b: (a, a-k, a-d, a-d-k, a-2*d, a-2*d-k, a-3*d, a-3*d-k, b+d, b+d-k, b, b-k),
                    lambda a, k, d, b: ((a - b)//d + 1)*k,
                    ["The displayed endpoints lie on the same descending arithmetic progression, with disjoint displayed blocks."],
                    lambda a, k, d, b: a - b >= 6*d and (a-b)%d == 0 and b > k,
                    lambda a, k, d, b: sum(j - (j-k) for j in range(a, b - 1, -d)), high=900)
    if key == "ia/test/902":
        return case("finite_telescoping_product", "count initial", (20, 2),
                    lambda n, a: (n, 10*a+a+1, 10*(a+1)+a+2, 10*(a+2)+a+3, 10*(a+3)+a+4),
                    lambda n, a: Fraction(a, a+n),
                    ["The four displayed unbraced fractions use one digit per field; count is at least four."],
                    lambda n, a: a <= 5 and n >= 4,
                    lambda n, a: prod(Fraction(i, i+1) for i in range(a, a+n)), high=90)
    return None


def _algebra_cases(row):
    key = row["id"].replace("intermediate_algebra/", "ia/").replace("algebra/", "a/")

    def case(family, names, values, display, solve, constraints=(), check=lambda *p: True,
             reference=None, low=1, high=28, sampler=None):
        entries = _entries(names, values, low, high) if isinstance(names, str) else names
        return _derived(row, family, entries, display, solve, constraints, check, reference, sampler)

    identity = lambda *p: p
    if key in {"a/train/95", "a/train/1022"}:
        return case("odd_power_equation", "shift denominator", (4, 8),
                    lambda a, d: (a, 3, 10 + d, 1), lambda a, d: a + _integer_root(d, 3),
                    ["The unbraced fraction denominator is a single-digit perfect cube."],
                    lambda a, d: d in (1, 8), high=16)
    if key == "a/train/137":
        return case("exponential_with_radical",
                    (("base", 3, 2, 10), ("multiplier", 3, 1, 12), ("rhs", 18, 2, 300)), (),
                    lambda a, c, r: (c, a, c*c, a*a, r),
                    lambda a, c, r: _log(_rational(a), _rational(Fraction(r, 2*c))),
                    ["The right side divided by twice the multiplier is an integer power of the base."],
                    lambda a, c, r: any(Fraction(r, 2*c) == Fraction(a)**n for n in range(-4, 8)),
                    lambda a, c, r: next(n for n in range(-4, 8) if Fraction(r, 2*c) == Fraction(a)**n))
    if key in {"a/train/163", "a/train/661", "a/test/1139"}:
        def solve(argument, base, other):
            exponent = _log(_rational(base), _rational(other))
            return _scalar(_exact_power(_rational(argument), 1 / exponent))

        def valid(*args):
            try:
                return all(a > 1 for a in args) and solve(*args) > 1
            except (ValueError, ArithmeticError):
                return False

        if key.endswith("1139"):
            values, display = (49, 7, 49), lambda a, b, c: (b, a, c)
        else:
            values, display = ((81,2,16) if key.endswith("163") else (4,27,3)), identity
        return case("unknown_logarithm_base", "argument other_base other_argument",
                    values, display, solve,
                    ["The known logarithm is positive and rational, and the resulting base is rational."], valid, high=105)
    if key == "a/train/417":
        return case("unknown_logarithm_base", "argument numerator denominator", (32, 5, 2), identity,
                    lambda a, n, d: _scalar(_exact_power(_rational(a), Fraction(d, n))),
                    ["The base is greater than one and rational."],
                    lambda a, n, d: a > 1 and all((e*d) % n == 0 for _, e in _factor(a)), high=32)
    if key == "a/train/650":
        return case("logarithm_in_exponent", "outer_base log_base rhs", (4, 7, 16), identity,
                    lambda a, b, c: _scalar(_exact_power(_rational(b), _log(_rational(a), _rational(c)))),
                    ["Both bases exceed one. The common exponent is a nonnegative integer."],
                    lambda a, b, c: a > 1 and b > 1 and any(a ** n == c for n in range(8)),
                    lambda a, b, c: next(b**n for n in range(8) if a**n == c), high=70)
    if key in {"a/train/817", "a/train/887"}:
        if key.endswith("817"):
            return case("affine_exponential_equation", "rhs multiplier base shift", (27,3,9,1), identity,
                        lambda r,m,b,h: h+_log(_rational(b),_rational(Fraction(r,m))),
                        ["The base exceeds one and the logarithm of the ratio is rational."],
                        lambda r,m,b,h: b>1 and _safe_rational_log(b,Fraction(r,m)), high=45)
        return case("affine_exponential_equation", "base slope intercept reciprocal_denominator",
                    (5,2,1,25), lambda b,a,h,r: (b,a,h,1,r),
                    lambda b,a,h,r: (-_log(_rational(b),_rational(r))-h)/a,
                    ["The base exceeds one and the logarithm of the denominator is rational."],
                    lambda b,a,h,r: b>1 and _safe_rational_log(b,r), high=40)
    if key == "a/train/905":
        return case("symbolic_substitution_cancellation", "constant input_shift", (3,7), identity,
                    lambda a,b: a+b)
    if key == "a/train/1066":
        return case("factored_quadratic_root_sum", "slope intercept shift1 shift2", (2,3,4,6),
                    lambda a,b,c,d: (a,b,c,a,b,d,0),
                    lambda a,b,c,d: Fraction(c+d,2)-Fraction(b,a),
                    reference=lambda a,b,c,d: Fraction(a*(c+d)-2*b,2*a))
    if key == "a/train/1293":
        return case("composed_power_equation", "outer_shift inner_offset", (8,4),
                    lambda a,b: (0,a,2,a,2,b), lambda a,b: isqrt(b),
                    ["The inner offset is a positive perfect square."], lambda a,b: isqrt(b)**2==b)
    if key == "a/train/1426":
        return case("quadratic_root_ratio", "linear_coefficient ratio_num ratio_den", (6,2,1),
                    lambda a,n,d: (2,a,0,n,d), lambda a,n,d: Fraction(a*a*n*d,(n+d)**2),
                    reference=lambda a,n,d: Fraction(-a*n,n+d)*Fraction(-a*d,n+d))
    if key == "a/train/1456":
        return case("affine_function_from_points", "slope intercept", (3,2),
                    lambda a,b: (1,a+b,2,2*a+b,b,3), lambda a,b: (2*a+b)+((2*a+b)-(a+b)),
                    reference=lambda a,b: 3*a+b)
    if key == "a/test/290":
        return case("affine_exponential_equation", "base shift outer_exponent rhs_exponent", (2,1,3,13),
                    lambda b,a,n,r: (b,a,n,b*b,b**r), lambda b,a,n,r: Fraction(r-a*n,n+2),
                    ["The base exceeds one and the unbraced power is a single digit."],
                    lambda b,a,n,r: b>1 and n<=9, high=18)
    if key == "a/test/432":
        def discriminant(a,c,d):
            return (d-2*a)**2-4*(a*a-c)

        return case("logarithm_with_variable_base", "shift constant slope", (1,10,2),
                    lambda a,c,d: (a,c,d,2),
                    lambda a,c,d: Fraction(2*a-d+isqrt(discriminant(a,c,d)),2),
                    ["One rational root lies above the base shift. At that root the base differs from one."],
                    lambda a,c,d: c>a*d and isqrt(discriminant(a,c,d))**2==discriminant(a,c,d)
                    and 2*a-d+isqrt(discriminant(a,c,d))!=2*(a+1))
    if key == "a/test/563":
        return case("affine_exponential_equation", "base slope rhs_exponent radical_denominator", (2,2,8,2),
                    lambda b,a,e,d: (b,a,b**e,1,d), lambda b,a,e,d: Fraction(e,a*d),
                    ["The displayed base exceeds one."], lambda b,a,e,d: b>1, high=16)
    if key in {"a/train/145", "a/test/749", "a/test/1017"}:
        def extra(c,d):
            return c**d if key.endswith("1017") else c*d

        values = {"a/train/145": (2,4,11,300), "a/test/749": (6,4,3,48),
                  "a/test/1017": (4,2,3,12)}[key]
        return case("exponent_in_multivariate_function",
                    (("base",values[0],2,10), ("third_argument",values[1],1,12),
                     ("fourth_argument",values[2],1,12), ("rhs",values[3],2,400)), (),
                    identity, lambda a,c,d,r: _log(_rational(a),_rational(r-extra(c,d))),
                    ["The target minus the other term is positive and has a rational logarithm."],
                    lambda a,c,d,r: r>extra(c,d) and _safe_rational_log(a,r-extra(c,d)))
    if key == "a/test/875":
        return case("affine_function_from_points", "input_magnitude value1 value2 query", (1,5,1,6),
                    lambda a,b,c,d: (a,b,a,c,d),
                    lambda a,b,c,d: Fraction(b+c,2)+Fraction((b-c)*d,2*a),
                    reference=lambda a,b,c,d: b+Fraction((d-a)*(b-c),2*a))
    if key == "a/test/953":
        return case("logarithm_in_exponent", "log_base_power_base exponent root_degree other_base", (4,3,3,4),
                    lambda b,e,d,a: (b**e,1,d,a,1),
                    lambda b,e,d,a: Fraction(e,d)*_log(_rational(a),_rational(b)),
                    ["Both bases exceed one and have proportional prime-exponent vectors."],
                    lambda b,e,d,a: a>1 and b>1 and _safe_rational_log(a,b), high=12)
    if key == "ia/train/89":
        # Substitute u = cbrt(a*x+k). Then u^3+u=k^3+k is strictly increasing.
        return case("nested_cube_root_equation", "linear_coefficient target", (20,13),
                    lambda a,k: (3,a,3,a,k,k), lambda a,k: Fraction(k**3-k,a))
    if key == "ia/train/13":
        return case("minimum_arithmetic_middle", "term_product", (64,), identity,
                    lambda a: _integer_root(a,3), ["The product is a perfect cube."],
                    lambda a: _integer_root(a,3)**3==a, high=500)
    if key in {"ia/train/114","ia/train/257","ia/train/1293","ia/train/928"}:
        values = {"ia/train/114": (15,20,3), "ia/train/257": (500,3,600),
                  "ia/train/1293": (30,20,40), "ia/train/928": (4,5,5)}[key]
        reciprocal = key.endswith(("257","1293"))
        return case("functional_homogeneity", "known_input known_value query", values, identity,
                    lambda a,b,c: Fraction(a*b,c) if reciprocal else Fraction(b*c,a), high=800)
    if key == "ia/train/118":
        return case("inverse_function_composition", "shift query", (1,7), lambda a,b: (1,3,a,1,b),
                    lambda a,b: _integer_root(a+b,3), ["The inverse argument plus shift is a perfect cube."],
                    lambda a,b: _integer_root(a+b,3)**3==a+b, high=120)
    if key == "ia/train/155":
        return case("exponential_equation_log_base", "first_base shift second_base", (7,7,8),
                    lambda a,b,c: (a,b,c,a,b), lambda a,b,c: Fraction(c,a),
                    ["Both bases exceed one and are different."], lambda a,b,c: a>1 and c>1 and a!=c)
    if key == "ia/train/163":
        return case("symmetric_reciprocal_equation", "shift inner_delta outer_delta", (8,1,2),
                    lambda a,b,c: (1,a+b,1,a-b,1,a+c,1,a-c),
                    lambda a,b,c: -a,
                    ["The shifts stay positive and the two nonzero radii differ."],
                    lambda a,b,c: 0<b<c<a)
    if key == "ia/test/336":
        return case("symmetric_reciprocal_equation", "left_low left_high inward_shift", (2,9,1),
                    lambda a,b,d: (a-1,a,b-1,b,a+d-1,a+d,b-d-1,b-d),
                    lambda a,b,d: Fraction(-a-b,2),
                    ["The inner denominator shifts lie strictly inside the outer pair and the same numerator adjustment applies to all."],
                    lambda a,b,d: a>=2 and b-a>2*d)
    if key == "a/test/518":
        return case("cancelled_quadratic_equation", "lead1 constant1 lead2 constant2 shift rhs_linear_magnitude",
                    (2,1,3,2,3,5),
                    lambda a,b,c,d,h,k: (a,b,c,d,h,a*c,k),
                    lambda a,b,c,d,h,k: Fraction(h*k-b*d,a*d+b*c+k+h*a*c),
                    reference=lambda a,b,c,d,h,k: _equation_roots(
                        _poly_add(_poly_mul((b,a),(d,c)),_poly_mul((-h,1),(-k,a*c)),-1))[0])
    if key == "ia/test/616":
        def coefficients(a,b,c,d,e):
            return _poly_add(
                _poly_add(_poly_mul((b,a),(e,d)),_poly_mul((-(a-1)*d*c,(a-1)*d),(-c,1)),-1),
                _poly_mul((-c,1),(e,d)),-1)

        def valid(a,b,c,d,e):
            poly=coefficients(a,b,c,d,e)
            return len(poly)==2 and (root:=_equation_roots(poly)[0]) not in (c,Fraction(-e,d))

        return case("rational_equation_cancelled_quadratic", "lead constant first_shift second_lead second_shift",
                    (2,3,4,2,1),
                    lambda a,b,c,d,e: (a,b,c,(a-1)*d,(a-1)*d*c,d,e,1),
                    lambda a,b,c,d,e: _equation_roots(coefficients(a,b,c,d,e))[0],
                    ["The numerator after clearing denominators is linear and its root is not a pole."],
                    lambda a,b,c,d,e: a>1 and valid(a,b,c,d,e))
    if key == "ia/train/213":
        def solve(b,a,n):
            power, exponent = 1, 0
            while power < n:
                power *= b
                exponent += 1
            return (power-n)*a+exponent

        return case("recursive_to_next_power", "base increment start", (2,1,100),
                    lambda b,a,n: (b,b,a,1,n), solve,
                    ["The logarithm base is a single digit from 2 through 9."], lambda b,a,n: 2<=b<=9, high=180)
    if key == "ia/train/247":
        return case("even_polynomial_symmetry", "constant input known_value", (3,91,1),
                    lambda a,b,c: (6,4,2,a,b,c,b,b), lambda a,b,c: 2*c, high=120)
    if key == "ia/train/310":
        def solve(b,n):
            _, remainder = _poly_divmod([0]*n+[1], (-b,-1,1))
            return remainder[0]*remainder[1]

        def reference(b,n):
            c,d=1,0
            for _ in range(n):
                c,d=b*d,c+d
            return c*d

        return case("polynomial_remainder_coefficients", "constant_magnitude target_degree", (1,5),
                    lambda b,n: (2,b,n), solve, ["The exponent is at least three."],
                    lambda b,n: n>=3, reference, high=16)
    if key == "ia/train/313":
        return case("linear_function_difference", "input_shift output_difference query1 query2", (1,3,3,5),
                    identity, lambda a,b,c,d: Fraction(b*(c-d),a))
    if key in {"ia/train/370", "ia/train/650"}:
        return case("reflected_function_equation", "multiplier reflection rhs_coefficient query",
                    (2,1,3,4 if key.endswith("370") else 3), lambda a,b,c,n: (a,b,c,2,n),
                    lambda a,b,c,n: Fraction(c*n*n-a*c*(b-n)**2,1-a*a),
                    ["The two equations under reflection have nonzero determinant."], lambda a,b,c,n: a!=1)
    if key == "ia/train/457":
        return case("signed_square_inverse", "positive negative_magnitude", (4,100),
                    lambda a,b: (1,a,1,b), lambda a,b: isqrt(a)-isqrt(b),
                    ["Both magnitudes are positive perfect squares."],
                    lambda a,b: isqrt(a)**2==a and isqrt(b)**2==b, high=180)
    if key == "ia/train/575":
        return case("functional_homogeneity", "known_value query", (25,79),
                    lambda a,b: (1,a,b), lambda a,b: a*b, high=150)
    if key == "ia/train/584":
        return case("vieta_reciprocal_root_sum", "root1 root2 root3", (1,2,3),
                    lambda a,b,c: (3,2,0,a,b,c), lambda a,b,c: -sum(Fraction(1,r) for r in (a,b,c)),
                    ["The three positive roots are distinct."], lambda a,b,c: len({a,b,c})==3,
                    lambda a,b,c: Fraction(-(a*b+b*c+a*c),a*b*c))
    if key == "ia/train/664":
        return case("vieta_shifted_reciprocal_product", "root_product reciprocal_numerator", (2,1),
                    lambda a,b: (2,a,0,b,b,2,0), lambda a,b: a*(1+Fraction(b,a))**2,
                    reference=lambda a,b: a+2*b+Fraction(b*b,a))
    if key == "ia/train/681":
        return case("vieta_shifted_root_product", "quadratic_magnitude linear constant_magnitude shift", (20,18,7,1),
                    lambda a,b,c,d: (3,a,2,b,c,0,d,d,d),
                    lambda a,b,c,d: -((-d)**3-a*(-d)**2+b*(-d)-c),
                    reference=lambda a,b,c,d: d**3+a*d*d+b*d+c)
    if key == "ia/train/766":
        return case("power_function_ratio", "degree known_input query1 query2", (2,2,5,1),
                    lambda p,a,b,c: (p,p,a,0,b,c,a), lambda p,a,b,c: Fraction(b**p-c**p,a**p),
                    ["The exponent remains a positive single digit."], lambda p,a,b,c: p<=9)
    if key == "ia/train/811":
        return case("odd_part_remainder", "constant root_magnitude given_remainder", (4,3,11),
                    lambda a,b,c: (5,3,a,b,c,b), lambda a,b,c: 2*a-c)
    if key == "ia/train/814":
        return case("logarithm_linear_system", "power_y rhs1 power_x rhs2", (3,1,2,1), identity,
                    lambda a,b,c,d: Fraction(b*(c-1)+d*(a-1),a*c-1),
                    ["The equations in log(x), log(y) are independent."], lambda a,b,c,d: a*c!=1)
    if key == "ia/train/838":
        return case("combined_product_logarithm", "base argument1 argument2", (10,40,25),
                    lambda b,a,c: (b,a,b,c), lambda b,a,c: _log(_rational(b),_rational(a*c)),
                    ["The product of the arguments has a rational logarithm."],
                    lambda b,a,c: b>1 and _safe_rational_log(b,a*c), high=65)
    if key in {"ia/train/955", "ia/train/1257", "ia/train/1151"}:
        if key.endswith("1151"):
            return case("vieta_root_product", "lead1 linear1 const1 lead2 quadratic2 const2", (2,8,20,5,25,19),
                        lambda a,b,c,d,e,f: (a,3,2,b,c,d,3,e,2,f,0),
                        lambda a,b,c,d,e,f: Fraction(c*f,a*d))
        if key.endswith("955"):
            return case("vieta_root_product", "quad linear constant", (12,48,28),
                        lambda a,b,c: (3,a,2,b,c,0), lambda a,b,c: -c, high=65)
        return case("vieta_root_product", "leading linear constant", (3,20,27),
                    lambda a,b,c: (a,3,2,b,c,0), lambda a,b,c: Fraction(-c,a))
    if key == "ia/train/1008":
        return case("remainder_unknown_coefficient", "divisor_slope divisor_shift cubic linear constant remainder",
                    (2,7,2,11,39,4), lambda a,b,c,d,e,r: (a,b,c,3,2,d,e,r),
                    lambda a,b,c,d,e,r: (r-c*Fraction(-b,a)**3+d*Fraction(-b,a)-e)/Fraction(b,a)**2,
                    high=48)
    if key == "ia/train/1062":
        return case("affine_composition_coefficients", "outer_slope inner_intercept composed_slope", (4,2,12),
                    identity, lambda a,b,m: a*b+Fraction(m,a))
    if key == "ia/train/1163":
        def evaluate(a,b,c,e,f,g,x,y):
            q,r = _poly_divmod((e,1,-c,b,a),(-g,f,1))
            return _horner(q,x)+_horner(r,-y)
        return case("quotient_and_remainder_evaluation",
                    "quartic cubic quadratic constant divisor_linear divisor_magnitude quotient_input remainder_magnitude",
                    (4,12,9,3,3,2,1,1), lambda a,b,c,e,f,g,x,y: (a,4,b,3,c,2,e,2,f,g,x,y),
                    evaluate)
    if key == "ia/train/1215":
        return case("multiplicative_additive_argument", "known_input value index_multiple", (2,3,3),
                    lambda a,b,c: (a,b,a*c), lambda a,b,c: b**c, high=12)
    if key == "ia/train/1246":
        return case("radical_conjugate_sum", "integer_part radicand", (10,2018), identity,
                    lambda a,b: 2*a, ["The radicand is not a square."], lambda a,b: isqrt(b)**2!=b, high=2400)
    if key == "ia/train/1274":
        return case("complex_conjugate_root_polynomial", "pure_imaginary real_part", (2,2),
                    lambda a,b: (4,3,2,a,b,0), lambda a,b: (1+a*a)*((1-b)**2+1)-1)
    if key == "ia/test/13":
        return case("binary_argument_recurrence", "initial increment index", (1,1,15),
                    lambda a,b,n: (1,a,2,1,b,0,n), lambda a,b,n: a+b*(n.bit_length()-1),
                    ["The index is one less than a power of two, so inverse steps reach index 1."],
                    lambda a,b,n: n&(n+1)==0, high=150)
    if key == "ia/test/92":
        return case("linear_functional_equation", "input_scale rhs_slope offset", (2,6,8),
                    lambda a,b,c: (a,b,a*b//2,c,0), lambda a,b,c: Fraction(c,b),
                    ["The product of input scale and right-side slope is even."], lambda a,b,c: a*b%2==0)
    if key == "ia/test/94":
        return case("domain_of_rational_composition", "numerator linear shift", (1,2,5),
                    identity, lambda a,b,c: Fraction(c*c+a*b,b*c),
                    reference=lambda a,b,c: Fraction(c,b)+Fraction(a,c))
    if key == "ia/test/128":
        return case("unknown_logarithm_base", "argument1 argument2 sum", (2,4,3), identity,
                    lambda a,b,c: _scalar(_exact_power(_rational(a*b),Fraction(1,c))),
                    ["The product of the arguments exceeds one and has a rational root."],
                    lambda a,b,c: a*b>1 and all(e%c==0 for _,e in _factor(a*b)))
    if key == "ia/test/203":
        return case("quadratic_additive_function", "product_coefficient f_at_one query", (2,4,8),
                    lambda a,b,n: (a,1,b,n), lambda a,b,n: n*b+a*n*(n-1)//2,
                    reference=lambda a,b,n: sum(b+a*j for j in range(n)))
    if key == "ia/test/205":
        return case("odd_polynomial_symmetry", "input value", (5,3),
                    lambda a,b: (7,3,a,b,a), lambda a,b: -b)
    if key == "ia/test/231":
        return case("radical_conjugate_product", "integer_part radicand", (5,3), identity,
                    lambda a,b: a*a-b, ["The radicand is not a square."], lambda a,b: isqrt(b)**2!=b)
    if key == "ia/test/274":
        return case("functional_equation_swapped_arguments", "x y", (1,2), lambda a,b: (1,a,b),
                    lambda a,b: Fraction(a+b*b,1-a*b),
                    ["The product of the arguments is not one."], lambda a,b: a*b!=1)
    if key == "ia/test/428":
        return case("logarithmic_power_equation", "base power rhs", (2,2,6),
                    lambda b,k,r: (b,b,k,r), lambda b,k,r: b**(r//(k+1)),
                    ["The base exceeds one and the resulting exponent is an integer."],
                    lambda b,k,r: 2<=b<=9 and k<=9 and r%(k+1)==0)
    if key == "ia/test/565":
        return case("horizontal_asymptote_ratio", "lead_num quadratic linear constant lead_den den_linear den_constant",
                    (6,4,11,5,3,15,20),
                    lambda a,b,c,d,e,f,g: (a,3,b,2,c,d,e,3,f,g), lambda a,b,c,d,e,f,g: Fraction(a,e))
    if key == "ia/test/583":
        return case("remainder_unknown_coefficient", "cubic linear constant divisor_shift remainder", (9,32,11,5,4),
                    lambda a,b,c,d,r: (4,a,3,2,b,c,d,r),
                    lambda a,b,c,d,r: Fraction(r+a*d**3+b*d+c,d**4+d*d), high=45)
    if key == "ia/test/660":
        return case("affine_triple_iteration", "slope rhs_intercept", (2,21),
                    lambda a,c: (a**3,c), lambda a,c: a+Fraction(c,a*a+a+1),
                    reference=lambda a,c: a+Fraction(c,sum(a**j for j in range(3))))
    if key == "ia/test/883":
        return case("linear_function_difference", "upper base given_difference query", (6,2,12,12),
                    lambda a,b,c,d: (a,b,c,d,b), lambda a,b,c,d: Fraction(c*(d-b),a-b),
                    ["The two known inputs are distinct."], lambda a,b,c,d: a!=b)
    return None


def _safe_rational_log(base, argument):
    try:
        _log(_rational(base), _rational(argument))
        return True
    except (ValueError, ArithmeticError):
        return False


def _bind_numbers(row, family, names, values, display, solve, *,
                  low=1, high=30, constraints=(), check=lambda *p: True, reference=None, sample=None):
    return _derived(row, family, _entries(names, values, low, high), display, solve,
                    constraints, check, reference, sample)


def _operator_cases(row):
    key = row["id"].removeprefix("algebra/")
    if key == row["id"]:
        return None

    def bind(family, names, values, display, solve, **kwargs):
        return _bind_numbers(row, family, names, values, display, solve, **kwargs)

    def identity(*values):
        return values

    if key in {"train/214", "train/232", "train/244"}:
        if key.endswith("244"):
            return bind("defined_rational_operation", "scale divisor left right", (3,2,8,6),
                        identity, lambda c,d,a,b: a+Fraction(c*a,d*b),
                        reference=lambda c,d,a,b: Fraction(a*(d*b+c),d*b))
        return bind("defined_rational_operation", "left right", (6,2) if key.endswith("214") else (12,3),
                    identity, lambda a,b: a+Fraction(a,b), reference=lambda a,b: Fraction(a*(b+1),b))
    if key in {"train/347", "test/373"}:
        return bind("defined_difference_of_squares", "left right", (6,3) if key.endswith("347") else (6,5),
                    identity, lambda a,b: (a+b)*(a-b), reference=lambda a,b: a*a-b*b)
    if key == "train/266":
        return bind("defined_quadratic_operation", "coefficient left right", (10,2,6),
                    lambda c,a,b: (c,2,a,b), lambda c,a,b: b+c*a-a*a,
                    reference=lambda c,a,b: b+a*(c-a))
    if key == "train/374":
        return bind("defined_linear_operation", "first_coefficient second_coefficient left right", (3,5,7,2),
                    identity, lambda c,d,a,b: c*a+d*b)
    if key == "train/264":
        def reference(s, p):
            a = next(i for i in range(1,s) if i*(s-i) == p)
            return Fraction(1,a)+Fraction(1,s-a)

        def valid(s, p):
            discriminant = s*s-4*p
            if discriminant < 0:
                return False
            d = isqrt(discriminant)
            return d*d == discriminant and (s-d)%2 == 0 and s>d

        def sample(rng):
            a,b = rng.randint(1,9),rng.randint(1,9)
            return a+b,a*b

        return _derived(row, "defined_reciprocal_operation",
                        (("sum",9,2,40),("product",20,1,150)), identity, Fraction,
                        ["The given sum and product are realized by positive integers."], valid, reference, sample)
    if key in {"train/284", "test/396"}:
        return bind("defined_fraction_operation", "left_num left_den right_num right_den",
                    (7,12,8,3) if key.endswith("284") else (7,30,10,21), identity,
                    lambda m,n,p,q: Fraction(m*p*q,n),
                    constraints=["The displayed right fraction is in lowest terms."],
                    check=lambda m,n,p,q: gcd(p,q)==1,
                    reference=lambda m,n,p,q: Fraction(m,n)*p*q)
    if key in {"train/589", "train/1526"}:
        # The worked example remains valid independently of the requested operands.
        example = (0,0,1,3,6,3,6,1,3,6,9,19)

        def star(a,b):
            return Fraction(a+b,1+a*b)

        if key.endswith("589"):
            return bind("defined_fractional_operation", "left right", (2,5),
                        lambda a,b: (*example,a,b), star)
        return bind("nested_fractional_operation", "left middle right", (1,2,3),
                    lambda a,b,c: (*example,a,b,c), lambda a,b,c: star(star(a,b),c),
                    reference=lambda a,b,c: Fraction(a+b+c+a*b*c,1+a*b+a*c+b*c))
    if key in {"train/819", "train/1257"}:
        def first(a,b):
            return Fraction(a+b,a-b)

        return bind("nested_fractional_operation", "left middle right", (1,2,3 if key.endswith("819") else 4),
                    identity, lambda a,b,c: first(first(a,b),c),
                    constraints=["The two inputs of each operation are distinct."],
                    check=lambda a,b,c: a!=b and first(a,b)!=c,
                    reference=lambda a,b,c: Fraction(a+b+c*(a-b),a+b-c*(a-b)))
    if key == "train/957":
        return bind("defined_quadratic_operation", "negative_left_magnitude right constant", (1,6,1),
                    lambda a,b,c: (2,c,a,b), lambda a,b,c: -a*b*b-b+c)
    if key == "train/1154":
        def first(c,a,b):
            return c+b**a

        return bind("nested_exponential_operation", "constant left middle right", (2,1,2,3),
                    identity, lambda c,a,b,d: c+d**first(c,a,b), high=9,
                    constraints=["The first operation produces an exponent of at most 64."],
                    check=lambda c,a,b,d: first(c,a,b)<=64)
    if key == "train/1178":
        return bind("nested_absolute_difference", "left middle right", (2,4,7),
                    identity, lambda a,b,c: abs(a-abs(b-c)),
                    reference=lambda a,b,c: abs(a-(max(b,c)-min(b,c))))
    if key == "train/1467":
        return bind("defined_quadratic_operation", "coefficient first second third", (4,1,2,3),
                    lambda k,a,b,c: (2,k,a,b,c), lambda k,a,b,c: b*b-k*a*c)
    if key == "test/490":
        return bind("defined_absolute_power", "exponent first second", (3,2,4),
                    identity, lambda n,a,b: abs(a)**n+b, high=18)
    if key == "test/831":
        return bind("commutator_defined_operation", "left right", (3,5),
                    lambda a,b: (a,b,b,a), lambda a,b: (a+b)*b-(b+a)*a,
                    reference=lambda a,b: b*b-a*a)
    if key == "test/872":
        return bind("nested_exponential_operation", "left middle right", (1,2,3),
                    identity, lambda a,b,c: (a**b+b)**c+c, high=12)
    if key in {"train/1165", "test/744"}:
        def operations(a,b):
            return (a+b,a-b,a*b,Fraction(a,b))

        def pairs(a,b,c,d,target):
            return [(i,j) for (i,left),(j,right) in product(
                enumerate(operations(a,b)), enumerate(operations(c,d)))
                if right and left == target*right]

        def outcomes(a,b,c,d,target,e,f,g,h):
            left, right = operations(e,f), operations(g,h)
            outcomes = set()
            for i,j in pairs(a,b,c,d,target):
                if not right[j]:
                    return set()
                outcomes.add(Fraction(left[i],right[j]))
            return outcomes

        def valid(*args):
            return len(outcomes(*args))==1

        def solve(*args):
            answer, = outcomes(*args)
            return answer

        def sample(rng):
            while True:
                a,b,c,d,e,f,g,h = [rng.randint(2,25) for _ in range(8)]
                left,right = rng.choice(operations(a,b)),rng.choice(operations(c,d))
                if not right:
                    continue
                target = Fraction(left,right)
                if target.denominator!=1 or not 1<=target<=30:
                    continue
                args = (a,b,c,d,int(target),e,f,g,h)
                if valid(*args):
                    return args

        values = (12,2,9,3,2,7,3,12,6) if key.endswith("1165") else (12,2,9,3,4,10,7,24,9)
        return bind("inferred_arithmetic_operations", "given_a given_b given_c given_d ratio query_a query_b query_c query_d",
                    values, identity, solve, constraints=[
                        "At least one ordered pair of operations fits the given ratio. Every fitting pair yields "
                        "the same defined query value."
                    ], check=valid, sample=sample)
    return None


def _two_number_cases(row):
    key = row["id"].removeprefix("algebra/")
    if key == row["id"]:
        return None

    def bind(family, names, values, solve, **kwargs):
        return _bind_numbers(row, family, names, values, lambda *p: p, solve, **kwargs)

    sum_difference = {
        "train/52": (45,3,-1), "train/578": (12,20,-1), "train/794": (22,4,1),
        "train/1237": (30,4,1), "test/925": (25,11,1), "test/1117": (25,11,-1),
    }
    if key in sum_difference:
        s,d,sign = sum_difference[key]
        return bind("number_from_sum_and_difference", "sum difference", (s,d),
                    lambda s,d: Fraction(s+sign*d,2), high=110)
    product_cases = {"train/703": (50,6), "train/1615": (19,5), "test/258": (40,12), "test/636": (25,9)}
    if key in product_cases:
        return bind("product_from_sum_and_difference", "sum difference", product_cases[key],
                    lambda s,d: Fraction(s*s-d*d,4),
                    reference=lambda s,d: Fraction(s+d,2)*Fraction(s-d,2), high=110)
    if key in {"train/287", "train/1352"}:
        values = (12,45) if key.endswith("287") else (6,112)

        def possible(d,p):
            square = d*d+4*p
            root = isqrt(square)
            return root*root==square and (root-d)%2==0

        def draw(rng):
            a,d = rng.randint(1,12),rng.randint(1,20)
            return d,a*(a+d)

        return _derived(row,"positive_integer_pair_from_difference_and_product",
                        (("difference",values[0],1,28),("product",values[1],1,400)),
                        lambda d,p: (d,p), lambda d,p: isqrt(d*d+4*p),
                        ["The sum reconstructed from the difference and product yields two positive integers."],
                        possible, lambda d,p: next(2*a+d for a in range(1,p+1) if a*(a+d)==p), draw)
    if key in {"train/380", "train/1614"}:
        values = (90,27) if key.endswith("380") else (193,84)

        def valid(s,p):
            if s<2*p:
                return False
            plus,minus = isqrt(s+2*p),isqrt(s-2*p)
            return plus*plus==s+2*p and minus*minus==s-2*p and (plus-minus)%2==0

        def draw(rng):
            a,b = rng.randint(1,16),rng.randint(1,16)
            return a*a+b*b,a*b

        return _derived(row,"positive_integer_pair_from_squared_sum_and_product",
                        (("sum_of_squares",values[0],2,512),("product",values[1],1,256)),
                        lambda s,p: (s,p), lambda s,p: isqrt(s+2*p),
                        ["The reconstructed sum and difference yield two positive integers."],
                        valid, lambda s,p: next(a+p//a for a in range(1,p+1)
                                                 if p%a==0 and a*a+(p//a)**2==s), draw)
    if key in {"train/987", "train/1385"}:
        return bind("maximum_integer_product_from_sum", "sum", (1998,) if key.endswith("987") else (246,),
                    lambda n: (n//2)*(n-n//2), reference=lambda n: n*n//4, high=2400)
    if key in {"train/1153", "test/959"}:
        return bind("difference_from_sum_and_square_difference", "sum difference_of_squares",
                    (6,12) if key.endswith("1153") else (3,33), lambda s,d: Fraction(d,s), high=140)
    if key in {"train/1535", "test/332"}:
        values = (25,126) if key.endswith("1535") else (12,35)
        return bind("difference_from_sum_and_product", "sum product", values,
                    lambda s,p: isqrt(s*s-4*p), high=140,
                    constraints=["The two numbers are distinct real numbers and their positive difference is integral."],
                    check=lambda s,p: s*s>4*p and isqrt(s*s-4*p)**2==s*s-4*p)
    if key in {"train/1459", "test/368"}:
        s, digit = (399,9) if key.endswith("1459") else (153,7)
        return _derived(row,"difference_from_sum_and_decimal_ratio",
                        (("sum",s,1,700),("ratio_tenths",digit,1,9)),
                        lambda a,b: (a,0,b), lambda a,b: Fraction(a*(10-b),10+b),
                        reference=lambda a,b: 2*Fraction(10*a,10+b)-a)
    if key == "train/1390":
        return bind("difference_from_linear_combination_and_sum", "sum combination", (30,5),
                    lambda s,t: Fraction(s+2*t,5), high=130,
                    reference=lambda s,t: 2*Fraction(3*s+t,5)-s)
    return None


def _coordinate_polynomial_cases(row):
    key = row["id"].replace("intermediate_algebra/", "ia/").replace("algebra/", "a/")

    def bind(family,names,values,display,solve,**kwargs):
        return _bind_numbers(row,family,names,values,display,solve,**kwargs)

    def identity(*args):
        return args

    def is_square(n):
        return n>=0 and isqrt(n)**2==n

    if key in {"a/train/252", "a/train/1401"}:
        def draw(rng):
            m,n = sorted(rng.sample(range(1,8),2),reverse=True)
            legs = (m*m-n*n,2*m*n)
            return legs if rng.randrange(2) else legs[::-1]

        return bind("axis_point_distance", "height horizontal", (15,8) if key.endswith("252") else (4,3),
                    lambda a,b: (0,a,b,0), lambda a,b: isqrt(a*a+b*b),
                    constraints=["The two positive legs have integral hypotenuse."],
                    check=lambda a,b: is_square(a*a+b*b), sample=draw, high=90)
    if key in {"a/train/289", "a/train/1129", "a/train/1611"}:
        values = {"a/train/289": (2,5,6,1), "a/train/1129": (2,4,3,8), "a/train/1611": (5,2,7,3)}[key]
        return bind("point_distance","first_x_magnitude first_y_magnitude second_x_magnitude second_y_magnitude",
                    values,identity,lambda a,b,c,d: isqrt((a+c)**2+(b+d)**2),
                    constraints=["The squared distance is a perfect square."],
                    check=lambda a,b,c,d: is_square((a+c)**2+(b+d)**2))
    if key in {"a/train/316", "a/train/854"}:
        if key.endswith("316"):
            return bind("collinear_middle_coordinate","x1 y1 negative_middle_x negative_x2 y2",
                        (6,8,2,10,4),identity,lambda a,b,c,d,e: b+Fraction((e-b)*(a+c),a+d),
                        constraints=["The three displayed points have distinct x coordinates."],
                        check=lambda a,b,c,d,e: c!=d)
        return bind("collinear_middle_coordinate","negative_x1 y1 middle_x x2 y2",
                    (1,6,6,20,3),identity,lambda a,b,c,d,e: b+Fraction((e-b)*(a+c),a+d),
                    constraints=["The three displayed points have distinct x coordinates."],
                    check=lambda a,b,c,d,e: c!=d)
    if key in {"a/train/785", "a/test/1076"}:
        return bind("line_intersection_abscissa", "first_slope first_shift second_x_coefficient second_constant",
                    (4,19,2,95) if key.endswith("785") else (2,13,3,92),identity,
                    lambda a,b,c,d: Fraction(d+b,a+c))
    if key == "a/train/918":
        return bind("line_slope_from_intersection", "known_slope positive_intercept negative_intercept x_magnitude",
                    (3,5,7,4), lambda m,b,c,x: (m,b,c,x,m*x-b),
                    lambda m,b,c,x: Fraction(m*x-b-c,x),
                    constraints=["The displayed intersection has negative ordinate."], check=lambda m,b,c,x: m*x>b)
    if key in {"a/train/936", "a/train/1202"}:
        if key.endswith("936"):
            return bind("line_slope_intercept_sum","x_magnitude first_y negative_intercept",
                        (3,5,4),lambda a,b,c: (a,b,0,c),lambda a,b,c: Fraction(-b-c,a)-c)
        return bind("line_slope_intercept_sum","x_magnitude intercept",
                    (2,2),lambda a,b: (a,0,0,b),lambda a,b: Fraction(b,a)+b)
    if key == "a/train/1735":
        return bind("line_intersection_missing_coefficients","first_intercept second_slope x y",
                    (4,3,6,10),identity,lambda a,b,x,y: y-b*x+Fraction(y-a,x),
                    constraints=["The lines have distinct slopes."], check=lambda a,b,x,y: y-a!=b*x)
    if key == "a/test/430":
        return bind("line_intercept","first_x_magnitude first_y second_x_magnitude second_y_magnitude",
                    (2,6,4,2),identity,lambda a,b,c,d: b+Fraction(a*(b+d),c-a),
                    constraints=["The two points have distinct x coordinates."],check=lambda a,b,c,d: a!=c,
                    reference=lambda a,b,c,d: Fraction(b*c+a*d,c-a))
    if key == "a/test/900":
        return bind("line_intersection_coordinate_sum","first_y_coefficient second_x_coefficient second_y_coefficient rhs",
                    (3,2,5,11),identity,lambda a,b,c,d: Fraction(d*(a+1),a*b+c),
                    reference=lambda a,b,c,d: a*Fraction(d,a*b+c)+Fraction(d,a*b+c))
    if key == "a/test/1061":
        return bind("sum_of_intersections_with_horizontal_line","linear_magnitude constant height_magnitude",
                    (7,7,3),lambda b,c,d: (2,b,c,d),lambda b,c,d: b,
                    constraints=["The quadratic and the line intersect in two distinct real points."],
                    check=lambda b,c,d: b*b>4*(c+d))
    if key in {"a/train/919", "a/train/1730", "a/test/889", "a/test/31"}:
        if key == "a/test/31":
            return bind("circle_radius", "horizontal_diameter_coefficient vertical_diameter_coefficient",
                        (8,6),lambda a,b: (2,a,2,b,0),lambda a,b: Fraction(isqrt(a*a+b*b),2),
                        constraints=["The squared distance from the center to the origin is a nonzero rational square."],
                        check=lambda a,b: is_square(a*a+b*b),high=42)
        configs = {
            "a/train/919": ((6,2,6), -1, lambda a,b,c: (2,a,2,b,c,0)),
            "a/train/1730": ((4,18,21), -1, lambda a,b,c: (2,2,c,a,b)),
            "a/test/889": ((6,2,6), 1, lambda a,b,c: (2,2,c,a,b)),
        }
        orig, sign, display = configs[key]

        def square(a,b,c):
            return a*a+b*b+sign*4*c

        def valid(a,b,c):
            return square(a,b,c)>0 and is_square(square(a,b,c))

        return bind("circle_radius","horizontal_diameter_coefficient vertical_diameter_coefficient constant",
                    orig,display,lambda a,b,c: Fraction(isqrt(square(a,b,c)),2),high=55,
                    constraints=["The equation describes a nondegenerate circle with rational radius."],
                    check=valid,reference=lambda a,b,c: _rational_square_root(Fraction(square(a,b,c),4)))
    if key == "a/train/1671":
        return bind("circle_center_coordinate_sum","horizontal_diameter_coefficient vertical_diameter_coefficient constant",
                    (4,12,39),lambda a,b,c: (2,2,a,b,c),lambda a,b,c: Fraction(a+b,2),high=65,
                    constraints=["The squared radius is positive."],check=lambda a,b,c: a*a+b*b>4*c)
    if key == "ia/train/887":
        def valid(a,b,c,d,e,f):
            r1,r2 = a*a+b*b+4*c,d*d+e*e-4*f
            sep = (a-d)**2+(b-e)**2
            return b!=e and r2>0 and (sep-r1-r2)**2<4*r1*r2

        return bind("slope_of_radical_axis","circle1_x circle1_y circle1_constant circle2_x circle2_y circle2_constant",
                    (4,2,11,14,12,60), lambda a,b,c,d,e,f: (2,2,a,b,c,0,2,2,d,e,f,0),
                    lambda a,b,c,d,e,f: Fraction(d-a,e-b),high=80,
                    constraints=["The circles intersect at two distinct points and their common chord is nonvertical."],
                    check=valid)
    if key == "ia/train/1263":
        def count(a,b,c,r):
            delta = r*(a*a+b*b)-c*c
            return 2 if delta>0 else 1 if delta==0 else 0

        return bind("line_circle_intersection_count","x_coefficient y_coefficient line_constant squared_radius",
                    (5,8,10,1),lambda a,b,c,r: (a,b,c,2,2,r),count,
                    reference=lambda a,b,c,r: {False: int(c*c==r*(a*a+b*b)),True:2}[Fraction(c*c,a*a+b*b)<r])
    if key == "ia/train/989":
        return bind("line_parabola_tangency_coefficient","parabola_linear parabola_constant line_offset",
                    (3,1,1),lambda b,c,d: (2,b,c,d),lambda b,c,d: Fraction((b+1)**2,4*(c+d)))
    if key == "a/train/468":
        def solve(a,b,c):
            disc = b*b-4*c
            return 1 + (2 if disc>0 else 1 if disc==0 else 0)

        return bind("polynomial_distinct_real_root_count","positive_root quadratic_linear quadratic_constant",
                    (5,5,6), lambda a,b,c: (a,2,b,c), solve)
    if key == "a/train/241":
        return bind("undefined_domain_product","numerator_shift denominator_constant_magnitude",
                    (1,3),lambda h,c: (2,2*h,h*h,2,2*h,c),lambda h,c: -c)
    if key in {"a/train/1404", "a/test/529"}:
        return bind("undefined_domain_sum","numerator_shift linear_magnitude constant",
                    (6,5,4) if key.endswith("1404") else (3,10,16),lambda a,b,c: (a,2,b,c),
                    lambda a,b,c: b, constraints=["The denominator has two distinct real roots."],
                    check=lambda a,b,c: b*b>4*c)
    if key == "a/train/1732":
        def count(root,b,c):
            # The first factor always has one positive and one negative real root.
            return 2 + (root*root+b*root-c != 0)

        def draw(rng):
            if rng.randrange(2):
                root = rng.randint(1,4)
                linear = rng.randint(1,30//root-root)
                return root,linear,root*(root+linear)
            while True:
                root,linear,constant = (rng.randint(1,30) for _ in range(3))
                if root*(root+linear) != constant:
                    return root,linear,constant

        return bind("undefined_domain_distinct_count","outer_root quadratic_linear quadratic_constant_magnitude",
                    (3,2,3),lambda r,b,c: (2,r*r,2,b,c,r),count,sample=draw)
    if key in {"a/train/1423", "a/test/836"}:
        sign = 1 if key.endswith("1423") else -1
        return bind("quadratic_discriminant","quadratic linear_magnitude constant_magnitude",
                    (3,7,12) if sign==1 else (2,8,15),lambda a,b,c: (a,2,b,c),
                    lambda a,b,c: b*b+sign*4*a*c,
                    reference=lambda a,b,c: -4*a*_horner((-sign*c,-b,a),Fraction(b,2*a)))
    return None


def _quotient_and_log_cases(row):
    key = row["id"].replace("intermediate_algebra/", "ia/").replace("algebra/", "a/")

    def bind(family,names,values,display,solve,**kwargs):
        return _bind_numbers(row,family,names,values,display,solve,**kwargs)

    if key == "ia/train/458":
        def dividend(a,b,c,d,e,k):
            return k, Fraction(a*d,e)-b*c, b-a*c, a

        def display(a,b,c,d,e,k):
            _,linear,quad,_ = dividend(a,b,c,d,e,k)
            return a,3,-quad,2,int(-linear),k,a,b,2,c,d,e

        def valid(a,b,c,d,e,k):
            _,linear,quad,_ = dividend(a,b,c,d,e,k)
            return quad<0 and linear<0 and linear.denominator==1

        return bind("remainder_with_known_quotient","divisor_slope divisor_constant quotient_linear quotient_num quotient_den dividend_constant",
                    (3,5,3,1,3,3),display,lambda a,b,c,d,e,k: _horner(dividend(a,b,c,d,e,k),Fraction(-b,a)),
                    constraints=["The displayed quotient times the divisor fixes the nonconstant dividend coefficients. "
                                 "The linear coefficient is a negative integer and the quadratic coefficient is negative."],
                    check=valid,reference=lambda a,b,c,d,e,k: k-Fraction(b*d,e),high=18)
    if key == "ia/test/259":
        def dividend(a,b,c,d,k):
            return k,d,b-a*c,a

        return bind("remainder_with_unknown_quotient_constant","divisor_slope divisor_constant quotient_linear dividend_linear dividend_constant",
                    (3,2,5,11,23),lambda a,b,c,d,k: (a,3,a*c-b,2,d,k,a,b,2,c),
                    lambda a,b,c,d,k: _horner(dividend(a,b,c,d,k),Fraction(-b,a)),
                    constraints=["The known quotient terms determine the negative quadratic coefficient of the dividend."],
                    check=lambda a,b,c,d,k: a*c>b,
                    reference=lambda a,b,c,d,k: k-b*Fraction(d+b*c,a),high=25)
    if key == "ia/test/562":
        def linear(a,b,m,s,p,q):
            quotient_linear = Fraction(s-b*m,a)
            return quotient_linear*(a*Fraction(p,q)+b)

        return bind("remainder_with_linked_quotient_coefficients",
                    "divisor_slope divisor_constant quotient_lead dividend_quadratic ratio_num ratio_den dividend_constant",
                    (2,3,3,5,5,2,8),
                    lambda a,b,m,s,p,q,k: (a*m,3,s,2,int(-linear(a,b,m,s,p,q)),k,a,b,m,2,p,q),
                    lambda a,b,m,s,p,q,k: _horner((k,linear(a,b,m,s,p,q),s,a*m),Fraction(-b,a)),
                    constraints=["The displayed negative linear coefficient is a whole number consistent with both linked quotient coefficients."],
                    check=lambda a,b,m,s,p,q,k: s<b*m and linear(a,b,m,s,p,q).denominator==1,
                    reference=lambda a,b,m,s,p,q,k: k-Fraction(b*p,q)*Fraction(s-b*m,a),high=18)
    if key == "ia/train/1066":
        def solve(a,b,c,d,e,f):
            lead = Fraction(a,d)
            constant = (-b+e*lead)/d
            return f*lead-e*constant

        def reference(a,b,c,d,e,f):
            _,rest = _poly_divmod((c,0,-b,a),(f,-e,d))
            return -rest[1] if len(rest)>1 else 0

        return bind("coefficient_for_constant_remainder",
                    "dividend_cubic dividend_quadratic_magnitude dividend_constant divisor_quadratic divisor_linear_magnitude divisor_constant",
                    (10,7,6,2,3,1),lambda a,b,c,d,e,f: (a,3,b,2,c,d,2,e,f),solve,
                    reference=reference)
    if key == "ia/train/874":
        return bind("coefficient_for_linear_factor","quadratic constant root", (2,10,5),
                    lambda a,b,r: (3,a,2,b,r),lambda a,b,r: -r*r-a*r-Fraction(b,r),
                    reference=lambda a,b,r: -_horner((b,0,a,1),r)/r)
    if key == "ia/train/581":
        def solve(a,b,c,d,e):
            return Fraction(c+a*e,a*d-b)

        return bind("horizontal_asymptote_crossing","leading linear_magnitude constant_magnitude denominator_linear denominator_constant",
                    (2,5,7,4,1),lambda a,b,c,d,e: (a,2,b,c,2,d,e),solve,
                    constraints=["The asymptote and graph have a unique intersection away from the poles."],
                    check=lambda a,b,c,d,e: a*d!=b and _horner((e,-d,1),solve(a,b,c,d,e))!=0)
    if key == "ia/test/282":
        return bind("horizontal_asymptote_crossing","numerator_slope numerator_shift denominator_quadratic denominator_linear denominator_constant",
                    (2,6,7,2,6),lambda a,b,c,d,e: (a,b,3,c,2,d,e),lambda a,b,c,d,e: Fraction(b,a),
                    constraints=["The numerator root is not a pole."],
                    check=lambda a,b,c,d,e: _horner((e,-d,-c,1),Fraction(b,a))!=0)
    if key in {"a/test/496", "a/test/1105"}:
        def solve(a,b,c):
            first = (b+a-1)//a
            return first+(first==c)

        if key.endswith("496"):
            return bind("smallest_integer_in_radical_domain","radical_offset pole",(1,2),
                        lambda b,c: (b,c),lambda b,c: solve(1,b,c),high=40)
        return bind("smallest_integer_in_radical_domain","radical_slope radical_offset pole",(2,6,3),
                    lambda a,b,c: (a,b,c),solve,
                    reference=lambda a,b,c: next(x for x in range(1,b+2) if a*x>=b and x!=c),high=40)
    if key in {"ia/train/724","ia/test/450"}:
        sign = -1 if key.endswith("724") else 1
        values = (2,3,9,5,3,2,2) if sign==-1 else (2,2,8,1,2,5,3)

        def display(base,a,b,c,d,h,power):
            if sign==-1:
                return base,a,b,c,d,base,c,d,h,power
            return base,a,b,d,base,d,h,power

        def solve(base,a,b,c,d,h,power):
            k = base**power
            return Fraction(b+k*h,k-a)

        def valid(base,a,b,c,d,h,power):
            if c!=1 and sign==1 or base**power==a:
                return False
            x = solve(base,a,b,c,d,h,power)
            middle = c*x+sign*d
            return middle!=0 and x!=h and (a*x+b)*middle>0 and middle*(x-h)>0

        entries = (
            ("base",values[0],2,9),("numerator_slope",values[1],1,22),
            ("numerator_constant",values[2],1,30),("middle_slope",values[3],1,20 if sign==-1 else 1),
            ("middle_shift",values[4],1,120),("denominator_shift",values[5],1,22),
            ("right_power",values[6],1,5),
        )
        return _derived(row,"sum_of_logarithms_with_cancellation",entries,display,solve,[
            "The exponentiated equation is linear in the unknown, and both uncancelled logarithm arguments are positive."
        ],valid)
    if key == "a/train/388":
        def bracket(base,argument):
            floor,power = 0,base
            while power<=argument:
                floor += 1
                power *= base
            return floor,argument**2-base**(2*floor+1)

        def solve(base,argument):
            floor,comparison = bracket(base,argument)
            return floor+(comparison>0)

        return _derived(row,"rounded_logarithm",(("base",7,2,22),("argument",2400,2,18000)),
                        lambda b,a: (b,a),solve,["The exact logarithm is not halfway between two integers."],
                        lambda b,a: bracket(b,a)[1]!=0)
    if key == "a/train/411":
        def exact_value(base,shift,num,den):
            return shift+_scalar(_exact_power(_rational(base),Fraction(num,den)))

        def valid(base,shift,num,den,other):
            try:
                return exact_value(base,shift,num,den)>1 and _safe_rational_log(other,exact_value(base,shift,num,den))
            except (ArithmeticError,ValueError):
                return False

        def sample(rng):
            while True:
                den = rng.randint(2,4)
                seed = rng.randint(2,6)
                base = seed**den
                num = rng.randint(1,2)
                other = rng.randint(2,10)
                for power in range(1,5):
                    shift = other**power-seed**num
                    if 1<=shift<=120 and base<=1300:
                        return base,shift,num,den,other

        return _derived(row,"reciprocal_logarithm_after_equation",
                        (("first_base",25,2,1300),("input_shift",4,1,120),("exponent_num",1,1,3),
                         ("exponent_den",2,1,6),("query_argument",3,2,10)),
                        lambda b,s,m,n,a: (b,s,m,n,1,a),
                        lambda b,s,m,n,a: _log(_rational(a),_rational(exact_value(b,s,m,n))),
                        ["The solved logarithm base exceeds one and both relevant powers or logarithms are rational."],
                        valid,sampler=sample)
    if key == "a/train/956":
        def valid(a,b,c,d):
            return a**c>b+1 and _safe_rational_log(d,a**c-b)

        def sample(rng):
            while True:
                a,d = rng.randint(2,12),rng.randint(2,12)
                c,k = rng.randint(1,4),rng.randint(1,4)
                b = a**c-d**k
                if 1<=b<=240:
                    return a,b,c,d

        return _derived(row,"logarithm_after_log_equation",
                        (("first_base",5,2,12),("shift",4,1,240),("exponent",3,1,4),("second_base",11,2,12)),
                        lambda a,b,c,d: (a,b,c,d),lambda a,b,c,d: _log(_rational(d),_rational(a**c-b)),
                        ["The solved argument exceeds one and the queried logarithm is rational."],valid,sampler=sample)
    if key in {"a/train/713","a/train/824"}:
        sign = -1 if key.endswith("713") else 1
        return _derived(row,"convergent_nested_radical",
                        (("radicand_constant",2 if sign==-1 else 12,2,600),),lambda a: (a,a,a,a),
                        lambda a: (isqrt(1+4*a)+sign)//2,[
                            "The integer constant is at least two, ensuring convergence, and yields a rational fixed point."
                        ],lambda a: isqrt(1+4*a)**2==1+4*a,
                        lambda a: next(x for x in range(1,a+1) if x*x==a+sign*x))
    if key == "ia/train/901":
        def display(a,b,m,n,c,d):
            base = a*b
            remaining = m+n+c-d
            return base,a**m,d,base,b,c,base,a,remaining,base,b,base,a**n

        def solve(a,b,m,n,c,d):
            terms = ((a,m),(b,d),(a,c),(b,m+n+c-d),(a,n))
            vector = {}
            for value, weight in terms:
                for prime, multiplicity in _factor(value):
                    vector[prime] = vector.get(prime,0)+weight*multiplicity
            base = dict(_factor(a*b))
            prime = next(iter(base))
            exponent = Fraction(vector[prime],base[prime])
            if any(vector[p] != e*exponent for p,e in base.items()):
                raise ValueError("the logarithm sum is not rational")
            return exponent

        return _derived(row,"weighted_logarithm_sum",
                        (("first_factor",2,2,7),("second_factor",5,2,9),("first_power",2,1,4),
                         ("last_power",3,1,4),("first_factor_weight",3,1,4),("first_second_factor_weight",2,1,6)),
                        display,solve,["Weights are positive and balance the prime factors between the five logarithms."],
                        lambda a,b,m,n,c,d: gcd(a,b)==1 and d<m+n+c,lambda a,b,m,n,c,d: m+n+c)
    if key == "ia/train/204":
        return bind("operation_determined_by_functional_identity","outer_argument inner_argument target",
                    (2016,6,100),lambda a,b,c: (1,a,b,c),lambda a,b,c: Fraction(b*c,a),high=2500,
                    reference=lambda a,b,c: b/Fraction(a,c))
    return None
