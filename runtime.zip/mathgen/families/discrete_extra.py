"""Additional exact arithmetic and elementary number-theory templates."""

import re
from fractions import Fraction
from itertools import combinations
from math import comb, factorial, gcd, isqrt, lcm, perm, prod

from mathgen.families.discrete import (
    _choose, _divisors, _factorization, _is_prime, _prime_sieve, _template,
)


_NUMBER_WORDS = {
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6,
    "seven": 7, "eight": 8, "nine": 9, "ten": 10, "eleven": 11,
    "twelve": 12, "thirteen": 13, "fourteen": 14, "fifteen": 15,
    "sixteen": 16, "seventeen": 17, "eighteen": 18, "nineteen": 19,
    "twenty": 20, "thirty": 30, "forty": 40, "fifty": 50, "hundred": 100,
}
_CARDINAL = r"(?:\d+|" + "|".join(_NUMBER_WORDS) + ")"
_WIDTH = r"(?:[2-5]|two|three|four|five)"
_INT = r"-?\d+(?:,\d{3})*"
_POS = r"\d+(?:,\d{3})*"


def _number(text):
    return _NUMBER_WORDS[text] if text in _NUMBER_WORDS else int(text.replace(",", ""))


def _math_text(statement):
    # Convert inline math delimiters and place terminal punctuation normally.
    return " ".join(statement.replace("$", "").replace(r"\!", "").split()).strip()


def _simple_prime_factors(body):
    patterns = (
        (r"(?:What is|Find) the (?:greatest|largest) prime (?:factor|divisor) of (" + _POS + r")[?.]", "max"),
        (r"(?:What is|Find) the (?:least|smallest) prime (?:factor|divisor) of (" + _POS + r")[?.]", "min"),
        (r"(?:What is|Find) the sum of the (?:distinct )?prime factors of (" + _POS + r")[?.]", "sum"),
        (r"(?:What is|Find) the sum of the largest and smallest prime factors of (" + _POS + r")[?.]", "extrema_sum"),
        (r"What is the positive difference between the (?:greatest|largest) and (?:least|smallest) prime factors of (" + _POS + r")[?.]", "difference"),
        (r"How many (?:distinct|different) prime factors does (" + _POS + r") have\?", "count"),
        (r"How many prime positive integers are divisors of (" + _POS + r")\?", "count"),
        (r"How many primes must be multiplied to make (" + _POS + r")\?", "multiplicity"),
    )
    for pattern, mode in patterns:
        match = re.fullmatch(pattern, body)
        if match:
            return _prime_factor_template(_number(match[1]), mode, "distinct" in body)
    return None


def _prime_factor_template(n, mode, distinct=True):
    def summarize(factors):
        primes = list(factors)
        if mode == "max":
            return max(primes)
        if mode == "min":
            return min(primes)
        if mode == "sum":
            return sum(primes)
        if mode == "extrema_sum":
            return max(primes) + min(primes)
        if mode == "difference":
            return max(primes) - min(primes)
        return len(primes) if mode == "count" else sum(factors.values())

    def reference(n):
        factors = {}
        for p in _divisors(n):
            if _is_prime(p):
                power = p
                exponent = 1
                while n % (power * p) == 0:
                    power *= p
                    exponent += 1
                factors[p] = exponent
        return summarize(factors)

    question = {
        "max": "What is the largest prime factor of {n}?",
        "min": "What is the smallest prime factor of {n}?",
        "sum": ("What is the sum of the distinct prime factors of {n}?" if distinct else
                "What is the sum of the prime factors of {n}?"),
        "extrema_sum": "What is the sum of the largest and smallest prime factors of {n}?",
        "difference": "What is the positive difference between the largest and smallest prime factors of {n}?",
        "count": "How many distinct prime factors does {n} have?",
        "multiplicity": "How many primes, counted with multiplicity, appear in the prime factorization of {n}?",
    }[mode]
    if mode == "difference":
        allowed = lambda n: len(_factorization(n)) > 1
        constraints = ("n has at least two distinct prime factors.",)
    elif mode == "sum" and not distinct:
        allowed = lambda n: all(power == 1 for power in _factorization(n).values())
        constraints = ("n is squarefree, so every prime factor appears once.",)
    else:
        allowed, constraints = None, ()

    return _template(
        "discrete.prime_factor_" + mode, {"n": (n, 2, max(n, 3500))},
        lambda n: question.format(n=n), lambda n: summarize(_factorization(n)), reference,
        allowed=allowed, constraints=constraints,
    )


_LIST = rf"{_POS}(?:(?:, and | and |,\s+){_POS})+"
_GCD = r"greatest common (?:factor|divisor)(?: \(GCD\))?"
_LCM = r"least common multiple(?: \(LCM\))?"


def _values(text):
    return tuple(_number(value) for value in re.findall(_POS, text.replace(", ", " ")))


def _common_factor_and_multiple(body):
    direct = re.fullmatch(
        rf"(?:What is|Find|Calculate) the ({_GCD}|{_LCM}) of ({_LIST})[?.]", body
    )
    smallest = re.fullmatch(
        rf"(?:What is|Find) the (?:smallest|least) positive (?:whole )?integer "
        rf"(?:that is )?(?:divisible by|with factors of) ({_LIST})[?.]", body
    )
    both_multiples = re.fullmatch(
        rf"What is the (?:least|smallest) positive (?:integer that is both a multiple|multiple) "
        rf"of ({_POS}) (?:and|that is also) a multiple of ({_POS})[?.]", body
    )
    paired = re.fullmatch(
        rf"(?:What is|Find) the (sum|product) of the ({_GCD}|{_LCM})(?: of ({_LIST}))? "
        rf"and the ({_GCD}|{_LCM}) of ({_LIST})[?.]", body
    )
    names = re.fullmatch(
        rf"Let A be the {_GCD} and let B be the {_LCM} of ({_LIST})\. What is the value of A \+ B\?", body
    )
    if direct:
        operation, text = direct.groups()
        original = _values(text)
        if len(original) == 2:
            return None  # Existing exact two-input family.
        left, right = ("gcd" if operation.startswith("greatest") else "lcm"), ""
        method = "single"
    elif smallest or both_multiples:
        original = _values(smallest[1]) if smallest else tuple(map(_number, both_multiples.groups()))
        left, right, method = "lcm", "", "single"
    elif paired:
        method, op_a, text_a, op_b, text_b = paired.groups()
        left = "gcd" if op_a.startswith("greatest") else "lcm"
        right = "gcd" if op_b.startswith("greatest") else "lcm"
        if left == right:
            return None
        a, b = (_values(text_a) if text_a else ()), _values(text_b)
        original = a + b if a and a != b else b
        split_at = len(a) if a and a != b else None
    elif names:
        original = _values(names[1])
        left, right, method, split_at = "gcd", "lcm", "sum", None
    else:
        return None
    if method == "single":
        split_at = None
    if not 2 <= len(original) <= 5 or any(n < 1 for n in original):
        return None
    domains = {f"n_{i}": (n, 2 if n > 1 else 1, max(n, 80))
               for i, n in enumerate(original, 1)}

    def groups(values):
        inputs = tuple(values[name] for name in domains)
        if split_at is None:
            return inputs, inputs
        return inputs[:split_at], inputs[split_at:]

    def evaluate(fn, **values):
        a, b = groups(values)
        first = fn(left, a)
        if method == "single":
            return first
        second = fn(right, b)
        return first + second if method == "sum" else first * second

    def reference(operation, inputs):
        factors = [_factorization(n) for n in inputs]
        primes = set().union(*factors)
        reducer = min if operation == "gcd" else max
        return prod(p ** reducer(f.get(p, 0) for f in factors) for p in primes)

    def render(**values):
        a, b = groups(values)
        name = {"gcd": "greatest common divisor", "lcm": "least common multiple"}
        if method == "single":
            return f"Find the {name[left]} of {', '.join(map(str, a))}."
        return (f"Find the {method} of the {name[left]} of {', '.join(map(str, a))} "
                f"and the {name[right]} of {', '.join(map(str, b))}.")

    return _template(
        "discrete.common_" + (left if method == "single" else method),
        domains, render,
        lambda **values: evaluate(lambda op, xs: gcd(*xs) if op == "gcd" else lcm(*xs), **values),
        lambda **values: evaluate(reference, **values),
    )


def _nearest_strict_multiple(body):
    patterns = (
        (rf"What is the (?:smallest|least)( positive)? multiple of ({_POS})(?: that is| which is)? greater than ({_INT})[?.]", "first"),
        (rf"What is the (?:largest|greatest)( positive)? multiple of ({_POS})(?: that is| which is)? (?:less|smaller) than ({_INT})[?.]", "last"),
        (rf"What is the (?:smallest|least)( positive)? integer (?:greater than ({_INT}) that is divisible by) ({_POS})[?.]", "flipped"),
    )
    for pattern, mode in patterns:
        match = re.fullmatch(pattern, body)
        if match:
            positive, modulus, bound = match.groups()
            if mode == "flipped":
                modulus, bound = bound, modulus
                mode = "first"
            break
    else:
        return None
    modulus, bound = map(_number, (modulus, bound))
    if modulus < 1:
        return None

    def solve(modulus, bound):
        if mode == "first":
            smallest = (bound // modulus + 1) * modulus
            return max(modulus, smallest) if positive else smallest
        return ((bound - 1) // modulus) * modulus

    def reference(modulus, bound):
        if mode == "first":
            start = max(bound + 1, 1) if positive else bound + 1
            return next(n for n in range(start, start + modulus) if n % modulus == 0)
        return next(n for n in range(bound - 1, bound - modulus - 1, -1) if n % modulus == 0)

    upper_bound = max(1200, bound)
    lower_bound = min(-140, bound) if not positive else 1
    return _template(
        "discrete.strict_multiple_" + mode,
        {"modulus": (modulus, 2 if modulus > 1 else 1, max(modulus, 125)),
         "bound": (bound, lower_bound, upper_bound)},
        lambda modulus, bound: (
            f"What is the {'smallest' if mode == 'first' else 'greatest'}"
            f"{positive or ''} multiple of {modulus} "
            f"{'greater' if mode == 'first' else 'less'} than {bound}?"
        ),
        solve, reference,
        allowed=(lambda modulus, bound: modulus < bound) if positive and mode == "last" else None,
        constraints=("modulus < bound, so a positive multiple exists.",)
        if positive and mode == "last" else (),
    )


def _multiples_interval(body):
    candidates = (
        (rf"How many (positive )?multiples of ({_POS}) are (?:strictly )?between ({_INT}) and ({_INT})\?", "count"),
        (rf"How many (positive )?(integers|natural numbers) between ({_INT}) and ({_INT}) are divisible by ({_POS})\?", "reorder"),
        (rf"How many positive multiples of ({_POS}) are less than ({_POS})\?", "one_sided"),
        (rf"How many multiples of ({_POS}) are greater than ({_INT}) and less than ({_INT})\?", "signed"),
    )
    for pattern, mode in candidates:
        match = re.fullmatch(pattern, body)
        if not match:
            continue
        if mode == "one_sided":
            modulus, upper = map(_number, match.groups())
            lower, positive = 0, True
        elif mode == "signed":
            modulus, lower, upper = map(_number, match.groups())
            positive = False
        elif mode == "reorder":
            positive, noun, lower, upper, modulus = match.groups()
            positive = positive or noun == "natural numbers"
            modulus, lower, upper = map(_number, (modulus, lower, upper))
        else:
            positive, modulus, lower, upper = match.groups()
            modulus, lower, upper = map(_number, (modulus, lower, upper))
        break
    else:
        return None

    domains = {"modulus": (modulus, 2 if modulus > 1 else 1, max(modulus, 70)),
               "upper": (upper, min(30, upper), max(upper, 900))}
    if mode != "one_sided":
        domains["lower"] = (lower, min(lower, -150 if not positive else 0), max(lower, 380))

    def minimum(lower):
        return max(0, lower) if positive else lower

    def render(modulus, upper, lower=0):
        adjective = "positive " if positive else ""
        limits = (f"less than {upper}" if mode == "one_sided" else
                  f"strictly between {lower} and {upper}")
        return f"How many {adjective}multiples of {modulus} are {limits}?"

    return _template(
        "discrete.multiples_open_interval", domains, render,
        lambda modulus, upper, lower=0: (upper - 1) // modulus - minimum(lower) // modulus,
        lambda modulus, upper, lower=0: sum(
            n % modulus == 0 for n in range(minimum(lower) + 1, upper)
        ),
        allowed=lambda modulus, upper, lower=0: minimum(lower) < upper,
        constraints=("The strict upper bound exceeds the effective lower bound.",),
    )


def _digit_width_multiples(body):
    patterns = (
        (rf"(?:What is|Find) the (smallest|least|greatest|largest),? (?:positive )?({_WIDTH})-digit multiple of ({_POS})[?.]", False),
        (rf"(?:What is|Find) the (smallest|least|greatest|largest),? (?:possible )?({_WIDTH})-digit (?:positive )?(?:integer|number) (?:that|which) is (?:divisible by|a multiple of) ({_POS})[?.]", False),
        (rf"How many (positive )?({_WIDTH})-digit (?:positive )?(?:integers|numbers) are (?:multiples of|divisible by) ({_POS})\?", True),
        (rf"How many (positive )?multiples of ({_CARDINAL}) are ({_WIDTH})-digit (?:integers|numbers)\?", True),
    )
    for i, (pattern, counting) in enumerate(patterns):
        match = re.fullmatch(pattern, body)
        if match:
            goal, digits, modulus = match.groups()
            if i == 3:
                modulus, digits = digits, modulus
            digits, modulus = map(_number, (digits, modulus))
            break
    else:
        return None
    mode = "count" if counting else "first" if goal in {"smallest", "least"} else "last"

    def interval(digits):
        return 10 ** (digits - 1), 10 ** digits - 1

    def solve(digits, modulus):
        lo, hi = interval(digits)
        first = -(-lo // modulus)
        last = hi // modulus
        if mode == "count":
            return last - first + 1
        return modulus * (first if mode == "first" else last)

    def reference(digits, modulus):
        lo, hi = interval(digits)
        multiples = [n for n in range(lo, hi + 1) if n % modulus == 0]
        if mode == "count":
            return len(multiples)
        return multiples[0 if mode == "first" else -1]

    def render(digits, modulus):
        if counting:
            return f"How many positive {digits}-digit integers are divisible by {modulus}?"
        return f"What is the {goal} positive {digits}-digit multiple of {modulus}?"

    return _template(
        "discrete.digit_width_multiple_" + mode,
        {"digits": (digits, 2, max(4, digits)), "modulus": (modulus, 2 if modulus > 1 else 1, max(90, modulus))},
        render, solve, reference,
        allowed=(lambda digits, modulus: solve(digits, modulus) in range(
            10 ** (digits - 1), 10 ** digits
        )) if not counting else None,
        constraints=("At least one multiple has the requested number of digits.",) if not counting else (),
    )


def _prime_ranges(body):
    pair = re.fullmatch(
        rf"How many prime numbers are between ({_POS}) and ({_POS})\?", body
    )
    total = re.fullmatch(
        rf"(?:Find|What is) the sum of the first ({_CARDINAL}) prime(?: numbers|s)[?.]", body
    )
    digit = re.fullmatch(
        rf"How many (two-digit )?prime numbers (?:less than ({_POS}) )?have a units digit of ([0-9])\?",
        body,
    )
    sum_digits = re.fullmatch(
        r"For how many two-digit prime(?: numbers|s) is the sum of (?:its|the) digits (?:equal to )?(\d+)\?",
        body,
    )
    if pair:
        lower, upper = map(_number, pair.groups())
        return _template(
            "discrete.primes_between",
            {"lower": (lower, 2, max(lower, 140)), "upper": (upper, 8, max(upper, 200))},
            lambda lower, upper: f"How many prime numbers are strictly between {lower} and {upper}?",
            lambda lower, upper: sum(n > lower for n in _prime_sieve(upper - 1)),
            lambda lower, upper: sum(_is_prime(n) for n in range(lower + 1, upper)),
            allowed=lambda lower, upper: lower < upper,
            constraints=("lower < upper",),
        )
    if total:
        count = _number(total[1])
        return _template(
            "discrete.prime_prefix_sum", {"count": (count, 2, max(count, 45))},
            lambda count: f"What is the sum of the first {count} prime numbers?",
            lambda count: sum(_prime_sieve(max(1000, count * count))[:count]),
            _prime_prefix_sum_reference,
        )
    if digit:
        two_digit, upper, digit_value = digit.groups()
        if bool(two_digit) == bool(upper):
            return None
        minimum = 10 if two_digit else 2
        maximum = 100 if two_digit else _number(upper)
        domains = {"digit": (int(digit_value), 0, 9)}
        if not two_digit:
            domains["upper"] = (maximum, 15, max(maximum, 250))

        def render(digit, upper=maximum):
            qualifier = "two-digit prime numbers" if two_digit else f"prime numbers less than {upper}"
            return f"How many {qualifier} have units digit {digit}?"

        return _template(
            "discrete.prime_units_digit", domains, render,
            lambda digit, upper=maximum: sum(p >= minimum and p % 10 == digit
                                            for p in _prime_sieve(upper - 1)),
            lambda digit, upper=maximum: sum(_is_prime(n) and str(n)[-1] == str(digit)
                                            for n in range(minimum, upper)),
        )
    if sum_digits:
        return _template(
            "discrete.prime_digit_sum", {"digit_sum": (int(sum_digits[1]), 2, 17)},
            lambda digit_sum: f"How many two-digit prime numbers have digit sum {digit_sum}?",
            lambda digit_sum: sum(p >= 10 and p // 10 + p % 10 == digit_sum for p in _prime_sieve(99)),
            lambda digit_sum: sum(_is_prime(10 * tens + ones) for tens in range(1, 10)
                                  for ones in range(10) if tens + ones == digit_sum),
        )
    return None


def _prime_prefix_sum_reference(count):
    total = 0
    candidate = 2
    while count:
        if _is_prime(candidate):
            total += candidate
            count -= 1
        candidate += 1
    return total


def _divisor_statistics(body, problem_id):
    plain_count = re.fullmatch(
        rf"How many (?:different )?positive (?:integer )?(?:factors|divisors) does ({_POS}) have\?",
        body,
    )
    signed = re.fullmatch(
        rf"How many integers \(positive and negative\) are divisors of ({_POS})\?", body,
    )
    probability = re.fullmatch(
        rf"What is the probability that a positive integer less than or equal to ({_POS}) "
        rf"is a factor of ({_POS})\? Express your answer as a common fraction\.", body,
    )
    if probability and probability[1] != probability[2]:
        return None
    if plain_count:
        n, mode = _number(plain_count[1]), "count"
    elif signed:
        n, mode = _number(signed[1]), "signed"
    elif probability:
        n, mode = _number(probability[1]), "probability"
    else:
        cases = {
            "prealgebra/train/135": (210, "prime_count"),
            "prealgebra/train/614": (24, "count"),
            "prealgebra/test/753": (2400, "multiplicity"),
            "number_theory/train/696": (42, "product_prime_count"),
        }
        if problem_id not in cases:
            return None
        n, mode = cases[problem_id]

    def summarize(count, n):
        if mode == "probability":
            return Fraction(count, n)
        return count * 2 if mode == "signed" else count

    if mode in {"prime_count", "multiplicity"}:
        return _prime_factor_template(n, "count" if mode == "prime_count" else mode)

    question = {
        "signed": "How many positive and negative integer divisors does {n} have?",
        "count": "How many positive divisors does {n} have?",
        "probability": ("Choose an integer uniformly at random from 1 through {n}. "
                        "What is the probability that it divides {n}?"),
        "product_prime_count": ("Let A be the product of all positive divisors of {n}. "
                                "How many distinct prime factors does A have?"),
    }[mode]

    def solve(n):
        factors = _factorization(n)
        if mode == "product_prime_count":
            return len(factors)
        return summarize(prod(exponent + 1 for exponent in factors.values()), n)

    def reference(n):
        divisors = _divisors(n)
        if mode == "product_prime_count":
            return sum(_is_prime(d) for d in divisors)
        return summarize(len(divisors), n)

    return _template(
        "discrete.divisor_statistics_" + mode, {"n": (n, 2, max(1600, n))},
        lambda n: question.format(n=n), solve, reference,
    )


def _common_multiples_interval(problem_id):
    cases = {
        "number_theory/train/114": ((1, 9), (0, 0), "first_consecutive"),
        "number_theory/train/273": ((3, 4), (0, 500), "last"),
        "number_theory/train/326": ((3, 6), (3, 0), "width_last"),
        "number_theory/train/693": ((11, 8), (100, 300), "count_open"),
        "number_theory/train/783": ((11, 5), (3, 0), "width_count"),
        "number_theory/test/98": ((3, 4, 5), (0, 100), "count_through"),
        "prealgebra/train/551": ((8, 12), (0, 90), "last"),
        "prealgebra/train/589": ((2, 5, 7), (3, 0), "width_first"),
        "prealgebra/train/788": ((5, 7), (2, 0), "width_count"),
        "prealgebra/train/1039": ((2, 3, 5), (0, 200), "count_open"),
        "prealgebra/test/475": ((4, 6), (0, 100), "count_open"),
        "prealgebra/test/739": ((3, 4), (0, 100), "count_open"),
        "prealgebra/test/835": ((3, 4, 5), (0, 500), "count_through"),
    }
    if problem_id not in cases:
        return None
    original, (lower, upper), mode = cases[problem_id]
    if mode == "first_consecutive":
        return _template(
            "discrete.first_common_multiple_consecutive",
            {"end": (original[1], 3, 16)},
            lambda end: f"What is the smallest positive integer divisible by every integer from 1 through {end}?",
            lambda end: lcm(*range(1, end + 1)),
            lambda end: prod(max(p ** e for e in range(1, end + 1) if p ** e <= end)
                             for p in _prime_sieve(end)),
        )
    domains = {f"divisor_{i}": (n, 2, 15) for i, n in enumerate(original, 1)}
    if mode.startswith("width"):
        domains["digits"] = (lower, 2, 4)
    else:
        domains["upper"] = (upper, 30, max(1000, upper))
        if lower:
            domains["lower"] = (lower, 15, 350)

    def unpack(values):
        divisors = tuple(values[f"divisor_{i}"] for i in range(1, len(original) + 1))
        if mode.startswith("width"):
            digits = values["digits"]
            return divisors, 10 ** (digits - 1), 10 ** digits - 1
        return divisors, values.get("lower", lower) + 1, values["upper"] - int(mode != "count_through")

    def render(**values):
        divisors, lo, hi = unpack(values)
        condition = f"divisible by each of {', '.join(map(str, divisors))}"
        if mode.startswith("width"):
            scope = f"positive {values['digits']}-digit integers"
        else:
            scope = f"integers from {lo} through {hi}, inclusive"
        if mode in {"last", "width_last", "width_first"}:
            order = "least" if mode.endswith("first") else "greatest"
            return f"Among {scope}, what is the {order} integer {condition}?"
        return f"How many {scope} are {condition}?"

    def solve(**values):
        divisors, lo, hi = unpack(values)
        modulus = lcm(*divisors)
        first, last = -(-lo // modulus), hi // modulus
        if mode in {"last", "width_last", "width_first"}:
            return (first if mode.endswith("first") else last) * modulus
        return last - first + 1

    def reference(**values):
        divisors, lo, hi = unpack(values)
        matches = [n for n in range(lo, hi + 1) if all(n % d == 0 for d in divisors)]
        if mode in {"last", "width_last", "width_first"}:
            return matches[0 if mode.endswith("first") else -1]
        return len(matches)

    def allowed(**values):
        divisors, lo, hi = unpack(values)
        if lo > hi or len(set(divisors)) != len(divisors):
            return False
        if mode in {"last", "width_last", "width_first"}:
            return lo <= solve(**values) <= hi
        return True

    return _template(
        "discrete.common_multiples_" + mode, domains, render, solve, reference, allowed=allowed,
        constraints=("Divisors are distinct and the integer interval is nonempty.",
                     "If an extremum is requested, at least one common multiple lies in the interval."),
    )


def _missing_digit(problem_id):
    cases = {
        "number_theory/train/11": ("854", "526", 11, "unique"),
        "number_theory/train/39": ("712", "", 18, "unique"),
        "number_theory/train/59": ("7", "933", 33, "unique"),
        "number_theory/test/60": ("374", "", 18, "unique"),
        "number_theory/test/218": ("20", "7", 11, "unique"),
        "number_theory/test/504": ("5913", "8", 12, "sum"),
        "prealgebra/train/193": ("63", "", 3, "difference"),
        "prealgebra/train/347": ("1", "3", 3, "count"),
        "prealgebra/train/709": ("2345", "", 6, "largest"),
        "prealgebra/train/749": ("5228", "", 6, "unique"),
        "prealgebra/train/776": ("757", "", 3, "count"),
        "prealgebra/train/988": ("3", "6792", 3, "largest"),
        "prealgebra/train/1031": ("437", "03", 9, "smallest"),
        "prealgebra/train/1040": ("14", "", None, "count"),
        "prealgebra/train/1060": ("2345", "", 9, "unique"),
        "prealgebra/test/174": ("3529", "2", 4, "largest"),
        "prealgebra/test/797": ("6", "", None, "count"),
    }
    if problem_id not in cases:
        return None
    prefix, suffix, divisor, mode = cases[problem_id]
    width = len(suffix)
    domains = {"prefix": (int(prefix), 10 ** (len(prefix) - 1), 10 ** len(prefix) - 1)}
    if suffix:
        domains["suffix"] = (int(suffix), 0, 10 ** width - 1)
    if divisor is not None:
        domains["divisor"] = (divisor, 2, max(15, divisor))
    default_suffix = int(suffix or "0")

    def hits(prefix, suffix=default_suffix, divisor=divisor):
        if divisor is None:
            return [n for n in range(1, 10) if 10 * prefix % n == 0]
        # The digit contributes one place value. Solve A*d = -B mod m
        # by dividing out the gcd, then enumerate the resulting progression.
        place = 10 ** width
        target = -(10 * prefix * place + suffix)
        common = gcd(place, divisor)
        if target % common:
            return []
        modulus = divisor // common
        residue = (target // common * pow(place // common, -1, modulus)) % modulus if modulus > 1 else 0
        return list(range(residue, 10, modulus))

    def render(prefix, suffix=default_suffix, divisor=divisor):
        suffix_text = f"{suffix:0{width}d}" if width else ""
        number = f"{prefix}d{suffix_text}"
        condition = f"divisible by {divisor}" if divisor is not None else "divisible by its nonzero units digit"
        target = {
            "unique": "What is the unique value of $d$?",
            "largest": "What is the greatest possible value of $d$?",
            "smallest": "What is the least possible value of $d$?",
            "difference": "What is the greatest possible difference between two distinct values of $d$?",
            "sum": "What is the sum of all possible values of $d$?",
            "count": "How many possible values of $d$ are there?",
        }[mode]
        return f"The decimal integer ${number}$ has a missing digit $d$ and is {condition}. {target}"

    def evaluate(valid):
        if mode == "difference":
            return valid[-1] - valid[0]
        if mode == "sum":
            return sum(valid)
        if mode == "count":
            return len(valid)
        return valid[-1] if mode == "largest" else valid[0]

    def reference(prefix, suffix=default_suffix, divisor=divisor):
        valid = []
        for d in range(10):
            text = f"{prefix}{d}"
            if width:
                text += f"{suffix:0{width}d}"
            m = divisor if divisor is not None else d
            if m and int(text) % m == 0:
                valid.append(d)
        return evaluate(valid)

    def allowed(**values):
        size = len(hits(**values))
        if mode == "unique":
            return size == 1
        return size >= (2 if mode == "difference" else 1)

    return _template(
        "discrete.missing_digit_" + mode, domains, render,
        lambda **values: evaluate(hits(**values)), reference, allowed=allowed,
        constraints=("Exactly one digit satisfies the divisibility requirement."
                     if mode == "unique" else "At least two digits satisfy the divisibility requirement."
                     if mode == "difference" else "At least one digit satisfies the divisibility requirement.",),
        adaptation="Writes the missing digit as d and states its place in the decimal numeral.",
    )


def _range_probability(problem_id):
    cases = {
        "number_theory/train/101": (1, 50, 5, 2, "residue"),
        "number_theory/test/81": (35, 42, 0, 0, "prime"),
        "prealgebra/train/690": (2, 7, 0, 0, "prime"),
        "prealgebra/test/459": (1, 100, 3, 0, "multiple"),
        "prealgebra/test/846": (1, 100, 0, 0, "square"),
        "counting_and_probability/test/399": (10, 99, 7, 0, "contains"),
    }
    if problem_id not in cases:
        return None
    lower, upper, parameter, residue, mode = cases[problem_id]
    if mode == "contains":
        domains = {"digit": (parameter, 0, 9), "width": (2, 2, 4)}
    else:
        domains = {"upper": (upper, 6, max(210, upper))}
        if lower != 1:
            domains["lower"] = (lower, 2, max(45, lower))
        if mode in {"residue", "multiple"}:
            domains["modulus"] = (parameter, 2, 24)
        if mode == "residue":
            domains["residue"] = (residue, 0, 12)

    def render(upper=99, lower=1, modulus=1, residue=0, digit=0, width=2):
        if mode == "contains":
            return (f"Choose a positive {width}-digit integer uniformly at random. "
                    f"What is the probability that at least one of its digits is {digit}?")
        description = {
            "residue": f"leaves remainder {residue} upon division by {modulus}",
            "multiple": f"is a multiple of {modulus}",
            "prime": "is prime",
            "square": "is a perfect square",
        }[mode]
        return (f"Choose an integer uniformly at random from {lower} through {upper}, inclusive. "
                f"What is the probability that the chosen integer {description}?")

    def solve(upper=99, lower=1, modulus=1, residue=0, digit=0, width=2):
        if mode == "contains":
            leading_choices = 9 if digit == 0 else 8
            return 1 - Fraction(leading_choices * 9 ** (width - 1), 9 * 10 ** (width - 1))
        if mode == "square":
            count = isqrt(upper) - isqrt(lower - 1)
        elif mode == "prime":
            count = sum(n >= lower for n in _prime_sieve(upper))
        else:
            count = (upper - residue) // modulus - (lower - 1 - residue) // modulus
        return Fraction(count, upper - lower + 1)

    def reference(upper=99, lower=1, modulus=1, residue=0, digit=0, width=2):
        if mode == "contains":
            lower, upper = 10 ** (width - 1), 10 ** width - 1
            test = lambda n: str(digit) in str(n)
        elif mode == "prime":
            test = _is_prime
        elif mode == "square":
            test = lambda n: isqrt(n) ** 2 == n
        else:
            test = lambda n: n % modulus == residue
        return Fraction(sum(test(n) for n in range(lower, upper + 1)), upper - lower + 1)

    def allowed(upper=99, lower=1, modulus=1, residue=0, digit=0, width=2):
        return lower <= upper and residue < modulus

    return _template(
        "discrete.range_probability_" + mode, domains, render, solve, reference,
        allowed=allowed, constraints=tuple(
            constraint for field, constraint in
            (("lower", "lower <= upper"), ("residue", "residue < modulus")) if field in domains
        ),
    )


def _elementary_count(problem_id):
    cases = {
        "prealgebra/train/351": (3, 3, "offices"),
        "prealgebra/train/588": (6, 6, "line"),
        "prealgebra/train/643": (5, 2, "offices"),
        "prealgebra/train/1177": (12, 3, "balls"),
        "prealgebra/train/1199": (11, 2, "read"),
        "prealgebra/test/80": (8, 3, "offices"),
        "prealgebra/test/612": (4, 4, "shelf"),
        "prealgebra/test/693": (5, 5, "shelf"),
        "prealgebra/test/734": (8, 3, "medals"),
        "prealgebra/test/760": (12, 2, "doors"),
        "prealgebra/test/782": (9, 4, "offices"),
        "prealgebra/test/810": (5, 2, "committee"),
        "counting_and_probability/test/469": (20, 3, "offices"),
    }
    if problem_id not in cases:
        return None
    total, selected, mode = cases[problem_id]
    same = mode in {"line", "shelf"} or total == selected
    unordered = mode in {"read", "committee"}
    domains = {"total": (total, max(2, selected if mode in {"medals", "doors"} else 2), max(total, 16))}
    if not same and mode not in {"medals", "doors"}:
        domains["selected"] = (selected, 2, 9)

    def count(total, selected=None):
        return total if same else selected if selected is not None else cases[problem_id][1]

    def render(total, selected=None):
        k = count(total, selected)
        contexts = {
            "offices": f"How many ways can {k} distinct offices be assigned to {total} people if nobody holds more than one office?",
            "line": f"In how many ways can {total} different people stand in a line for a ticket?",
            "shelf": f"In how many ways can {total} different books be arranged on a shelf?",
            "balls": f"How many ordered sequences of {k} distinct balls can be drawn without replacement from {total} numbered balls?",
            "read": f"In how many ways can I choose {k} different books from a collection of {total}, if order does not matter?",
            "medals": f"How many ways can gold, silver and bronze be awarded to {total} sprinters with no ties?",
            "doors": f"A building has {total} doors. How many ways can you choose a door to enter and a different door to leave?",
            "committee": f"How many unordered committees of {k} people can be chosen from a group of {total}?",
        }
        return contexts[mode]

    def reference(total, selected=None):
        k = count(total, selected)
        if unordered:
            return _choose(total, k)
        return factorial(total) // factorial(total - k)

    return _template(
        "discrete.elementary_" + mode, domains, render,
        lambda total, selected=None: (comb(total, count(total, selected))
                                      if unordered else perm(total, count(total, selected))),
        reference, allowed=lambda total, selected=None: count(total, selected) <= total,
        constraints=("selected <= total",) if "selected" in domains else (),
    )


def _factorial_valuations(problem_id):
    cases = {
        "counting_and_probability/train/456": (25, 10, "zeros"),
        "counting_and_probability/train/576": (20, 12, "maximum"),
        "counting_and_probability/test/182": (15, 3, "count_powers"),
        "counting_and_probability/test/462": (100, 9, "count_factorials"),
    }
    if problem_id not in cases:
        return None
    n, divisor, mode = cases[problem_id]
    domains = {"n": (n, 4, max(140, n))}
    if mode == "count_powers":
        domains["divisor"] = (divisor, (2, 3, 5, 7, 11, 13))
    elif mode != "zeros":
        domains["divisor"] = (divisor, 2, 25)

    def exponent(n, divisor):
        result = []
        for prime, power in _factorization(divisor).items():
            total = 0
            quotient = n
            while quotient:
                quotient //= prime
                total += quotient
            result.append(total // power)
        return min(result)

    def solve(n, divisor=10):
        if mode != "count_factorials":
            return exponent(n, divisor)
        lower, upper = 0, n + 1
        while upper - lower > 1:
            midpoint = (upper + lower) // 2
            if exponent(midpoint, divisor):
                upper = midpoint
            else:
                lower = midpoint
        return n + 1 - upper

    def reference(n, divisor=10):
        if mode == "count_factorials":
            return sum(factorial(j) % divisor == 0 for j in range(1, n + 1))
        value = factorial(n)
        count = 0
        while value % divisor == 0:
            value //= divisor
            count += 1
        return count

    def render(n, divisor=10):
        if mode == "zeros":
            return f"How many trailing zeros does the decimal representation of ${n}!$ have?"
        if mode == "count_factorials":
            return f"How many of the factorials $1!$, $2!$, through ${n}!$ are divisible by {divisor}?"
        if mode == "count_powers":
            return f"For how many positive integers $k$ does ${divisor}^k$ divide ${n}!$?"
        return f"What is the largest nonnegative integer $k$ for which ${divisor}^k$ divides ${n}!$?"

    return _template(
        "discrete.factorial_valuation_" + mode, domains, render, solve, reference,
    )


def _factorial_sums(problem_id):
    cases = {
        "counting_and_probability/train/34": (5, 5, 20, 100, "last_two"),
        "counting_and_probability/train/76": (1, 1, 50, 15, "remainder"),
        "counting_and_probability/train/77": (1, 1, 1000, 10, "units"),
        "counting_and_probability/test/325": (7, 1, 2000, 100, "tens"),
        "number_theory/test/95": (1, 2, 6, 10, "units"),
    }
    if problem_id not in cases:
        return None
    start, step, count, modulus, mode = cases[problem_id]
    if problem_id == "counting_and_probability/test/325":
        # Inclusive range 7 through 2006 contains 2000 terms.
        assert start + step * (count - 1) == 2006
    domains = {"count": (count, 3, max(35, count))}
    starts_at_step = problem_id == "counting_and_probability/train/34"
    if start != 1 and not starts_at_step:
        domains["start"] = (start, 1, 15)
    if step != 1:
        domains["step"] = (step, 2, 8)
    if mode == "remainder":
        domains["modulus"] = (modulus, 3, 40)

    def render(count, start=start, step=step, modulus=modulus):
        start = step if starts_at_step else start
        end = start + step * (count - 1)
        expression = f"${start}! + {start + step}! + {start + 2 * step}! + \\cdots + {end}!$"
        if count <= 4:
            expression = "$" + " + ".join(f"{n}!" for n in range(start, end + 1, step)) + "$"
        if mode == "remainder":
            return f"What is the remainder when {expression} is divided by {modulus}?"
        if mode == "last_two":
            return f"What integer is represented by the last two digits of {expression}?"
        label = "units digit" if mode == "units" else "tens digit"
        return f"What is the {label} of {expression}?"

    def solve(count, start=start, step=step, modulus=modulus):
        start = step if starts_at_step else start
        end = start + step * (count - 1)
        current = 1
        total = 0
        for n in range(1, end + 1):
            current = (current * n) % modulus
            if n >= start and (n - start) % step == 0:
                total += current
            if not current:
                break
        return total % modulus // (10 if mode == "tens" else 1)

    def reference(count, start=start, step=step, modulus=modulus):
        start = step if starts_at_step else start
        # Factorials starting at modulus are all divisible by modulus.
        total = sum(factorial(n) for n in range(start, min(modulus, start + count * step), step))
        return total % modulus // (10 if mode == "tens" else 1)

    return _template(
        "discrete.factorial_progression_" + mode, domains, render, solve, reference,
    )


def _die_events(problem_id):
    cases = {
        "counting_and_probability/train/118": (8, "expectation"),
        "counting_and_probability/train/476": (6, "expectation"),
        "counting_and_probability/train/566": (8, "expectation"),
        "counting_and_probability/train/609": (12, "digit_expectation"),
        "counting_and_probability/test/43": (6, "not_even_prime"),
        "counting_and_probability/test/246": (6, "neither_prime"),
        "counting_and_probability/test/310": (8, "sum_expectation"),
        "counting_and_probability/test/314": (6, "prime_payoff"),
        "prealgebra/test/380": (6, "prime"),
        "prealgebra/test/436": (6, "doubles"),
    }
    if problem_id not in cases:
        return None
    n, mode = cases[problem_id]
    two = mode in {"sum_expectation", "neither_prime", "doubles"}
    question = {
        "expectation": "What is the expected value of the roll?",
        "digit_expectation": "What is the expected number of decimal digits of the roll?",
        "not_even_prime": "What is the probability that the roll is not an even prime?",
        "neither_prime": "What is the probability that neither roll is prime?",
        "sum_expectation": "What is the expected sum of the rolls?",
        "prime_payoff": "You win one dollar if the number is prime, lose one dollar if it is composite and win nothing if it is 1. What is your expected net gain in dollars?",
        "prime": "What is the probability that the roll is prime?",
        "doubles": "What is the probability that both dice show the same number?",
    }[mode]

    def solve(n):
        if mode == "expectation":
            return Fraction(n + 1, 2)
        if mode == "sum_expectation":
            return n + 1
        if mode == "digit_expectation":
            return Fraction(9 + 2 * (n - 9), n) if n > 9 else 1
        if mode == "not_even_prime":
            return Fraction(n - 1, n)
        if mode == "doubles":
            return Fraction(1, n)
        prime = len(_prime_sieve(n))
        if mode == "neither_prime":
            return Fraction(n - prime, n) ** 2
        if mode == "prime_payoff":
            return Fraction(2 * prime - n + 1, n)
        return Fraction(prime, n)

    def reference(n):
        faces = range(1, n + 1)
        if mode == "expectation":
            return Fraction(sum(faces), n)
        if mode == "sum_expectation":
            return Fraction(sum(a + b for a in faces for b in faces), n ** 2)
        if mode == "digit_expectation":
            return Fraction(sum(len(str(face)) for face in faces), n)
        if mode == "not_even_prime":
            return Fraction(sum(face % 2 or not _is_prime(face) for face in faces), n)
        if mode == "doubles":
            return Fraction(sum(a == b for a in faces for b in faces), n ** 2)
        if mode == "neither_prime":
            return Fraction(sum(not _is_prime(a) and not _is_prime(b) for a in faces for b in faces), n ** 2)
        if mode == "prime_payoff":
            return Fraction(sum(1 if _is_prime(face) else -1 if face > 1 else 0 for face in faces), n)
        return Fraction(sum(_is_prime(face) for face in faces), n)

    if mode == "digit_expectation":
        # The expected digit count is 2 - 9/n when the die has two-digit labels.
        # Its reduced denominator may contain only 2 and 5 for an exact decimal.
        choices = tuple(sides for sides in range(10, 41)
                        if _factorization(sides // gcd(sides, 9)).keys() <= {2, 5})
        domain = (n, choices)
    else:
        domain = (n, 4, 40)
    if mode == "digit_expectation" or problem_id == "counting_and_probability/train/118":
        question += " Express your answer as a decimal."

    return _template(
        "discrete.die_" + mode, {"n": domain},
        lambda n: (
            (f"Two independent fair {n}-sided dice numbered from 1 to {n} are rolled. " if two else
             f"A fair {n}-sided die numbered from 1 to {n} is rolled. ") + question
        ), solve, reference,
        adaptation="States fair rolls and the face labels explicitly.",
    )


def _consecutive_set_differences(problem_id):
    cases = {
        "counting_and_probability/train/61": (1, 1, 6),
        "counting_and_probability/train/736": (1, 1, 16),
        "counting_and_probability/test/212": (1, 2, 7),
    }
    if problem_id not in cases:
        return None
    start, step, size = cases[problem_id]
    return _template(
        "discrete.arithmetic_progression_differences",
        {"start": (start, 1, 20), "step": (step, 1, 8), "size": (size, 2, 24)},
        lambda start, step, size: (
            "How many distinct positive integers are differences of two distinct terms "
            f"in an arithmetic progression of {size} terms, starting at {start} with common difference {step}?"
        ),
        lambda start, step, size: size - 1,
        lambda start, step, size: len({b - a for a, b in combinations(range(start, start + step * size, step), 2)}),
    )

def build(row):
    body = _math_text(row["problem"])
    for parser in (_simple_prime_factors, _common_factor_and_multiple, _nearest_strict_multiple,
                   _digit_width_multiples, _multiples_interval, _prime_ranges):
        template = parser(body)
        if template is not None:
            return template
    template = _divisor_statistics(body, row["id"])
    if template is not None:
        return template
    for parser in (_common_multiples_interval, _missing_digit, _range_probability, _elementary_count,
                   _factorial_valuations, _factorial_sums, _die_events, _consecutive_set_differences):
        template = parser(row["id"])
        if template is not None:
            return template
    return None
