"""Exact equations based on comparing powers of a common positive base."""
from fractions import Fraction as Q
from functools import partial

from .round2_algebra_common import register

BINDINGS = {}
bind = partial(register, BINDINGS)


def power_exponent(base, value):
    exponent = 0
    while value > 1 and value % base == 0:
        exponent += 1
        value //= base
    return exponent if value == 1 else None


bind('test/217', 'power_of_power',
     {'base': (2, 25), 'inner': (1, 20), 'outer': (1, 20)}, [(2,3,4)],
     lambda b,m,n: f'Find $x$ if $({b}^{{{m}}})^{{{n}}}={b}^x$.',
     lambda b,m,n:m*n,
     reference=lambda b,m,n:power_exponent(b,(b**m)**n))

bind('test/100', 'inverse_power_of_power',
     {'base': (2, 25), 'outer': (1, 20), 'rhs_exponent': (1, 100)}, [(3,6,6)],
     lambda b,n,e: f'Find $k$ if $({b}^k)^{{{n}}}={b}^{{{e}}}$.',
     lambda b,n,e:Q(e,n))

def are_powers(base, *values):
    return all(power_exponent(base, value) is not None for value in values)


def sample_three_factors(rng):
    base = rng.randint(2,12)
    return (base, base**rng.randint(1,7), base**rng.randint(2,7),
            rng.randint(1,10), base**rng.randint(2,7), rng.randint(1,10))


def sample_two_factors(rng):
    base = rng.randint(2,12)
    return (base, base**rng.randint(2,7), rng.randint(1,10),
            base**rng.randint(2,7), rng.randint(1,10))


bind('train/416', 'multiply_powers_of_common_base',
     {'base': (2, 12), 'factor': (2, 12**7), 'second_base': (4, 12**7), 'outer2': (1, 10),
      'third_base': (4, 12**7), 'outer3': (1, 10)}, [(3,3,9,3,81,2)],
     lambda b,a,c,d,e,f: f'Find $n$ if $ {b}^n={a}\\cdot {c}^{{{d}}}\\cdot {e}^{{{f}}}$.',
     lambda b,a,c,d,e,f:power_exponent(b,a)+d*power_exponent(b,c)+f*power_exponent(b,e),
     valid=lambda b,a,c,d,e,f:are_powers(b,a,c,e),
     sample=sample_three_factors,
     constraints=('factor, second_base and third_base are positive integer powers of base',),
     reference=lambda b,a,c,d,e,f:power_exponent(b,a*c**d*e**f))

bind('train/586', 'multiply_two_powers',
     {'base': (2, 12), 'first_base': (4, 12**7), 'outer1': (1, 10),
      'second_base': (4, 12**7), 'outer2': (1, 10)}, [(2,16,3,8,3)],
     lambda b,a,c,d,e: f'Find $K$ if $ {a}^{{{c}}}\\times {d}^{{{e}}}={b}^K$.',
     lambda b,a,c,d,e:c*power_exponent(b,a)+e*power_exponent(b,d),
     valid=lambda b,a,c,d,e:are_powers(b,a,d),
     sample=sample_two_factors,
     constraints=('first_base and second_base are positive integer powers of base',),
     reference=lambda b,a,c,d,e:power_exponent(b,a**c*d**e))

bind('train/895', 'solve_product_exponent',
     {'base': (2, 15), 'known_exponent': (1, 20), 'rhs': (2, 15**10)}, [(5,6,25)],
     lambda b,a,c: f'Find $w$ if $ {b}^{{{a}}}\\cdot {b}^w={c}$.',
     lambda b,a,c:power_exponent(b,c)-a,
     valid=lambda b,a,c:are_powers(b,c),
     sample=lambda rng:(lambda b,a,e:(b,a,b**e))(
         rng.randint(2,15),rng.randint(1,20),rng.randint(1,10)),
     constraints=('rhs is a positive integer power of base',))

bind('train/557 train/1602', 'scaled_power_equation',
     {'base': (2, 10), 'divisor': (2, 10**8), 'numerator_exponent': (9, 30),
      'target_base': (2, 10**5)}, [(2,4,30,2),(2,4,30,4)],
     lambda b,d,n,e: f'If $1/{d}$ of $ {b}^{{{n}}}$ equals $ {e}^x$, find $x$.',
     lambda b,d,n,e:Q(n-power_exponent(b,d),power_exponent(b,e)),
     valid=lambda b,d,n,e:are_powers(b,d,e),
     sample=lambda rng:(lambda b,d,n,e:(b,b**d,n,b**e))(
         rng.randint(2,10),rng.randint(1,8),rng.randint(9,30),rng.randint(1,5)),
     constraints=('divisor and target_base are positive integer powers of base',))

bind('train/1384 test/784', 'affine_exponent',
     {'base': (2, 12), 'slope': (1, 20), 'offset': (-30, 30), 'rhs': (2, 12**15)},
     [(2,5,1,4),(5,2,-3,25)],
     lambda b,a,c,n: f'Find $x$ if $ {b}^{{{a}x+({c})}}={n}$.',
     lambda b,a,c,n:Q(power_exponent(b,n)-c,a),
     valid=lambda b,a,c,n:are_powers(b,n),
     sample=lambda rng:(lambda b,a,c,n:(b,a,c,b**n))(
         rng.randint(2,12),rng.randint(1,20),rng.randint(-30,30),rng.randint(1,15)),
     constraints=('rhs is a positive integer power of base',))

bind('test/299', 'integer_affine_exponent',
     {'base': (2, 12), 'offset': (-30, 30), 'rhs': (1, 12**20)}, [(2,2,32)],
     lambda b,c,t: f'What integer $x$ satisfies $ {b}^{{x+({c})}}={t}$?',
     lambda b,c,t:power_exponent(b,t)-c,
     valid=lambda b,c,t:power_exponent(b,t) is not None,
     sample=lambda rng:(lambda b,c,n:(b,c,b**n))(
         rng.randint(2,12),rng.randint(-30,30),rng.randint(0,20)),
     constraints=('rhs is a nonnegative integer power of base',))

bind('train/732', 'cancel_quadratic_exponents',
     {'base': (2, 12), 'quadratic': (1, 20), 'linear1': (-30, 30), 'constant1': (-30, 30),
      'linear2': (-30, 30), 'constant2': (-30, 30)}, [(3,2,-5,2,7,-4)],
     lambda b,a,c,d,e,f: f'Find $x$ if $ {b}^{{{a}x^2+({c})x+({d})}}='
                         f'{b}^{{{a}x^2+({e})x+({f})}}$.',
     lambda b,a,c,d,e,f:Q(f-d,c-e), valid=lambda b,a,c,d,e,f:c!=e,
     constraints=('linear1 differs from linear2',))

def solve_affine_exponents(base, other_base, first_offset, second_offset):
    exponent = power_exponent(base, other_base)
    return Q(first_offset-exponent*second_offset,exponent-1)


bind('test/321', 'two_affine_exponents',
     {'base': (2, 12), 'other_base': (4, 12**9), 'first_offset': (-30, 30),
      'second_offset': (-30, 30)}, [(3,9,8,3)],
     lambda b,e,a,c: f'Find $x$ if $ {b}^{{x+({a})}}={e}^{{x+({c})}}$.',
     solve_affine_exponents,
     valid=lambda b,e,a,c:e>b and are_powers(b,e),
     sample=lambda rng:(lambda b,e,a,c:(b,b**e,a,c))(
         rng.randint(2,12),rng.randint(2,9),rng.randint(-30,30),rng.randint(-30,30)),
     constraints=('other_base is an integer power of base with exponent at least 2',))

bind('test/614', 'reciprocal_base_exponent',
     {'base': (2, 12), 'power': (1, 25), 'denominator': (2, 12**9)}, [(2,12,8)],
     lambda b,e,d: f'Find $x$ if $ {b}^{{{e}}}=(1/{d})^x$.',
     lambda b,e,d:Q(-e,power_exponent(b,d)),
     valid=lambda b,e,d:are_powers(b,d),
     sample=lambda rng:(lambda b,e,d:(b,e,b**d))(
         rng.randint(2,12),rng.randint(1,25),rng.randint(1,9)),
     constraints=('denominator is a positive integer power of base',))


def common_base_exponent(first, second):
    for base in range(2,17):
        a = power_exponent(base,first)
        c = power_exponent(base,second)
        if a is not None and c is not None:
            return Q(c,a)
    return None


bind('test/127', 'power_between_perfect_powers',
     {'base': (2, 16**10), 'rhs': (2, 16**10)}, [(4,8)],
     lambda a,c: f'What power of {a} equals {c}? Express the answer as a common fraction.',
     common_base_exponent,
     valid=lambda a,c:common_base_exponent(a,c) is not None,
     sample=lambda rng:(lambda b,a,c:(b**a,b**c))(
         rng.randint(2,16),rng.randint(1,10),rng.randint(1,10)),
     constraints=('base and rhs are positive integer powers of a common integer from 2 to 16',))


def transfer_exponent(first_base, first_rhs, second_base):
    exponent = power_exponent(first_rhs, first_base)
    if exponent is None or exponent < 2:
        return None
    return next((candidate for candidate in range(2,17)
                 if candidate**exponent==second_base), None)


bind('test/326', 'transfer_exponent',
     {'first_base': (4, 16**9), 'first_rhs': (2, 16), 'second_base': (4, 16**9)},
     [(125,5,27)],
     lambda a,r,b: f'If $ {a}^x={r}$ and $ {b}^x=c$, what is $c$?',
     transfer_exponent,
     valid=lambda a,r,b:transfer_exponent(a,r,b) is not None,
     sample=lambda rng:(lambda a,b,n:(a**n,a,b**n))(
         rng.randint(2,16),rng.randint(2,16),rng.randint(2,9)),
     constraints=('first_base is a power of first_rhs of degree at least 2 and second_base is '
                  'an exact power of an integer from 2 to 16 of the same degree',))

bind('test/813', 'rational_base_exponent',
     {'base_numerator': (1, 15), 'base_gap': (1, 15), 'rhs_numerator': (1, 15**10),
      'rhs_denominator': (2, 30**10)}, [(3,1,81,256)],
     lambda a,g,n,d: f'Find $x$ if $({a}/{a+g})^x={n}/{d}$.',
     lambda a,g,n,d:next(e for e in range(1,11) if Q(a,a+g)**e==Q(n,d)),
     valid=lambda a,g,n,d:any(Q(a,a+g)**e==Q(n,d) for e in range(1,11)),
     sample=lambda rng:(lambda a,g,e:(a,g,a**e,(a+g)**e))(
         rng.randint(1,15),rng.randint(1,15),rng.randint(1,10)),
     constraints=('rhs is a positive integer power of the rational base with exponent from 1 to 10',))

bind('train/603 test/464', 'sum_of_repeated_powers',
     {'base': (2, 9), 'term_count': (2, 16), 'rhs': (2, 9**15)}, [(2,4,512),(6,6,6**6)],
     lambda b,n,t: 'Find $x$ if $'+'+'.join(f'{b}^x' for _ in range(n))+f'={t}$.',
     lambda b,n,t:power_exponent(b,t//n),
     valid=lambda b,n,t:t%n==0 and power_exponent(b,t//n) is not None,
     sample=lambda rng:(lambda b,n,e:(b,n,n*b**e))(
         rng.randint(2,9),rng.randint(2,16),rng.randint(1,12)),
     constraints=('rhs divided by term_count is a nonnegative integer power of base',))

bind('train/1078', 'quadratic_of_repeated_power_exponent',
     {'base': (2, 9), 'term_count': (2, 16), 'rhs': (2, 9**15), 'offset': (1, 12)},
     [(2,4,128,1)],
     lambda b,n,t,d: 'Given $'+'+'.join(f'{b}^x' for _ in range(n))+f'={t}$, find $(x+{d})(x-{d})$.',
     lambda b,n,t,d:power_exponent(b,t//n)**2-d*d,
     valid=lambda b,n,t,d:t%n==0 and power_exponent(b,t//n) is not None,
     sample=lambda rng:(lambda b,n,e,d:(b,n,n*b**e,d))(
         rng.randint(2,9),rng.randint(2,16),rng.randint(1,12),rng.randint(1,12)),
     constraints=('rhs divided by term_count is a nonnegative integer power of base',))

bind('test/737', 'difference_of_exponentials',
     {'base': (2, 16), 'offset': (1, 6), 'rhs': (1, 16**18)}, [(6,1,1080)],
     lambda b,d,t: f'Find $x$ if $ {b}^{{x+{d}}}-{b}^x={t}$.',
     lambda b,d,t:power_exponent(b,t//(b**d-1)),
     valid=lambda b,d,t:t%(b**d-1)==0 and power_exponent(b,t//(b**d-1)) is not None,
     sample=lambda rng:(lambda b,d,e:(b,d,(b**d-1)*b**e))(
         rng.randint(2,16),rng.randint(1,6),rng.randint(0,12)),
     constraints=('rhs divided by base**offset-1 is a nonnegative integer power of base',))

bind('test/303', 'power_of_monomial_with_radical',
     {'inner_power': (1, 24), 'index': (2, 8), 'outside_power': (1, 12)}, [(3,2,4)],
     lambda a,n,b: f'For $x>0$, when $(x\\sqrt[{n}]{{x^{{{a}}}}})^{{{b}}}$ is '
                   'written as a power of $x$, what is the exponent?',
     lambda a,n,b:b*(1+Q(a,n)),
     adaptation='Restrict x to positive real values to make real radical and power identities unambiguous.')

bind('test/335', 'radical_quotient_exponent',
     {'base': (2, 150), 'index1': (2, 12), 'index2': (2, 12)}, [(10,2,4)],
     lambda b,m,n: f'The expression $\\frac{{\\sqrt[{m}]{{{b}}}}}{{\\sqrt[{n}]{{{b}}}}}$ '
                   f'equals {b} raised to what power?',
     lambda b,m,n:Q(1,m)-Q(1,n))

def solve_power_quotient(base, other_base, slope, offset, divisor, rhs):
    return Q(power_exponent(base,rhs)+power_exponent(base,divisor)-offset,
             power_exponent(base,other_base)+slope)


bind('test/223', 'linear_exponent_with_quotient',
     {'base': (2, 10), 'other_base': (2, 10**10), 'slope': (1, 10), 'offset': (-20, 20),
      'divisor': (2, 10**10), 'rhs': (2, 10**10)}, [(3,9,2,1,81,243)],
     lambda b,a,c,d,e,f: f'Find $n$ if $\\frac{{{a}^n\\cdot {b}^{{{c}n+({d})}}}}{{{e}}}={f}$.',
     solve_power_quotient,
     valid=lambda b,a,c,d,e,f:are_powers(b,a,e,f),
     sample=lambda rng:(lambda b,a,c,d,e,f:(b,b**a,c,d,b**e,b**f))(
         rng.randint(2,10),rng.randint(1,10),rng.randint(1,10),
         rng.randint(-20,20),rng.randint(1,10),rng.randint(1,10)),
     constraints=('other_base, divisor and rhs are positive integer powers of base',))

bind('test/583', 'power_of_power_exponential_exponent',
     {'base': (2, 8), 'first_exponent': (1, 9), 'second_exponent': (1, 9)}, [(2,3,3)],
     lambda b,a,c: f'If $({b}^{{{a}}})^{{({b}^{{{c}}})}}={b}^N$, what is $N$?',
     lambda b,a,c:a*b**c)
