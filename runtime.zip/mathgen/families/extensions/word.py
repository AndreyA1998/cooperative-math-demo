"""Dispatch source bindings for the remaining prealgebra and prose algebra."""

from copy import deepcopy
from . import word_counts, word_numbers, word_quantities, word_expressions, word_stories

_SOURCES = {}
for module in (word_counts, word_numbers, word_quantities, word_expressions, word_stories):
    overlap = _SOURCES.keys() & module.CASES.keys()
    if overlap:
        raise ValueError(f'Duplicate word problem bindings: {sorted(overlap)}')
    _SOURCES.update(module.CASES)


def build(row):
    model = _SOURCES.get(row['id'])
    return deepcopy(model) if model else None
