"""Exact trigonometric domains with branch and feasibility checks."""
from fractions import Fraction as F
from functools import lru_cache
from .common import integer as I, choice, template
def T(name,*args,**kw):return template('extensions.precalculus.'+name,*args,**kw)
def qmul(x,y):return (x[0]*y[0]+3*x[1]*y[1],x[0]*y[1]+x[1]*y[0])
def qinv(x):
    d=x[0]*x[0]-3*x[1]*x[1];return (x[0]/d,-x[1]/d)
def qpow(x,n):
    a=(F(1),F(0))
    for _ in range(n):a=qmul(a,x)
    return a
def tan_power_reference(p):
    t={15:(F(2),F(-1)),30:(F(0),F(1,3)),45:(F(1),F(0)),60:(F(0),F(1)),75:(F(2),F(1))}[p['angle']]
    ct=qinv(t);a,b=qpow(t,p['power']),qpow(ct,p['power'])
    ans=qmul((a[0]+b[0],a[1]+b[1]),qinv((t[0]+ct[0],t[1]+ct[1])))
    assert ans[1]==0;return ans[0]
def tan_power(p):
    s={15:F(16),30:F(16,3),45:F(4),60:F(16,3),75:F(16)}[p['angle']]
    a,b=F(1),s-3
    for _ in range((p['power']-1)//2):a,b=b,(s-2)*b-a
    return a
RATIONAL_SINES={F(0):F(0),F(1,6):F(1,2),F(1,2):F(1),F(5,6):F(1,2),
                F(1):F(0),F(7,6):F(-1,2),F(3,2):F(-1),F(11,6):F(-1,2)}
def sine_pi(q):return RATIONAL_SINES.get(q%2)
def niven_holds(h,c,n):
    # Squared equation, then restore the sign lost by squaring.
    angle=F(h,2*n)%2
    return sine_pi(F(h,n))==F(n,c*c)-1 and (angle<F(3,4) or angle>F(7,4))
def niven_solutions(p):
    c,h=p['c'],p['h']
    candidates={F(c*c)*v for v in (F(1,2),F(1),F(3,2),F(2))}
    return [int(n) for n in sorted(candidates) if n.denominator==1 and niven_holds(h,c,int(n))]
@lru_cache(None)
def niven_inputs():
    return tuple((h,c) for h in range(1,101) for c in range(1,11) if len(niven_solutions(dict(h=h,c=c)))==1)
def complex_product(values):
    re,im=1,0
    for a in values:re,im=a*re-im,re+a*im
    return re,im
def arctan_n(p):
    re,im=complex_product([p[k] for k in 'abc'])
    return F(re+im,re-im)
def arctan_valid(p):
    re,im=complex_product([p[k] for k in 'abc'])
    return 0<im<re and arctan_n(p).denominator==1
@lru_cache(None)
def arctan_inputs():
    return tuple((a,b,c) for a in range(3,31) for b in range(3,31) for c in range(3,31) if arctan_valid(dict(a=a,b=b,c=c)))
def arctan_reference(p):
    n=arctan_n(p);re,im=complex_product([p[k] for k in 'abc']+[n])
    assert re==im and re>0
    return n
def cosine_product_reference(p):
    # Expand products in the cyclic group. With coprime numerator, residues
    # occur once each plus one additional constant; all roots sum to zero.
    d=2**p['terms']-1;counts={0:1}
    for j in range(p['terms']):
        shift=p['numerator']*2**j;new={}
        for k,v in counts.items():
            for sign in (-1,1):
                key=(k+sign*shift)%d;new[key]=new.get(key,0)+v
        counts=new
    baseline=min(counts.get(k,0) for k in range(d))
    assert all(counts.get(k,0)==baseline for k in range(1,d))
    return F(counts[0]-baseline,2**p['terms'])

def build(row):
    pid=row['id']
    if pid=='precalculus/train/86':
        return T('odd_tangent_power',{'angle':choice([15,30,45,60,75]),'power':choice([1,3,5,7,9])},dict(angle=75,power=3),
          lambda p:rf"Evaluate $\frac{{\tan^{p['power']}({p['angle']}^\circ)+\cot^{p['power']}({p['angle']}^\circ)}}{{\tan({p['angle']}^\circ)+\cot({p['angle']}^\circ)}}$.",
          tan_power,reference=tan_power_reference,constraints=['Odd power; acute exact quadratic-field tangent.'])
    if pid=='precalculus/train/161':
        def solve(p):
            if p['a']==p['b']==1:return F(1)
            s={30:F(1,4),45:F(1,2),60:F(3,4)}[p['angle']]
            return (1-F(p['a']**2)/(1-s))*(1-F(p['b']**2)/s)
        def sample(r):
            if r.randrange(3)==0:return dict(angle=r.randint(1,89),a=1,b=1)
            return dict(angle=r.choice([30,45,60]),a=r.randint(1,10),b=r.randint(1,10))
        return T('complementary_reciprocal_product',{'angle':I(1,89),'a':I(1,10),'b':I(1,10)},dict(angle=23,a=1,b=1),
          lambda p:rf"Evaluate $(1-\frac{{{p['a']}}}{{\cos {p['angle']}^\circ}})(1+\frac{{{p['a']}}}{{\sin {90-p['angle']}^\circ}})(1-\frac{{{p['b']}}}{{\sin {p['angle']}^\circ}})(1+\frac{{{p['b']}}}{{\cos {90-p['angle']}^\circ}})$.",
          solve,valid=lambda p:p['angle'] in (30,45,60) or p['a']==p['b']==1,sample=sample,
          constraints=['Acute angle. Unless both numerators are one, angle is 30, 45 or 60 degrees.'])
    if pid=='precalculus/train/192':
        return T('integer_trig_equation',{'h':I(1,100),'c':I(1,10)},dict(h=1,c=2),
          lambda p:rf"Find the positive integer $n$ satisfying $\sin(\frac{{{p['h']}\pi}}{{2n}})+\cos(\frac{{{p['h']}\pi}}{{2n}})=\frac{{\sqrt n}}{{{p['c']}}}$.",
          lambda p:niven_solutions(p)[0],valid=lambda p:len(niven_solutions(p))==1,
          sample=lambda r:dict(zip(('h','c'),r.choice(niven_inputs()))),
          reference=lambda p:next(n for n in range(1,2*p['c']**2+1) if niven_holds(p['h'],p['c'],n)),
          constraints=['Exactly one positive integer solution; 2*sin(rational*pi) is a rational algebraic integer, hence one of -2,-1,0,1,2. Unsquared sign is checked.'])
    if pid=='precalculus/train/606':
        return T('four_arctangents',{k:I(3,30) for k in 'abc'},dict(a=3,b=4,c=5),
          lambda p:rf"Find the positive integer $n$ with $\arctan(1/{p['a']})+\arctan(1/{p['b']})+\arctan(1/{p['c']})+\arctan(1/n)=\pi/4$.",
          arctan_n,valid=arctan_valid,sample=lambda r:dict(zip('abc',r.choice(arctan_inputs()))),reference=arctan_reference,
          constraints=['First three principal arctangents sum to less than pi/4; the uniquely implied n is a positive integer.'])
    if pid=='precalculus/train/610':
        def sample(r):
            total=r.randint(3,89);a,c=r.randint(1,total-1),r.randint(1,total-1)
            return dict(a=a,b=total-a,c=c,d=total-c)
        return T('equal_angle_sine_quotient',{k:I(1,88) for k in 'abcd'},dict(a=18,b=12,c=22,d=8),
          lambda p:rf"Evaluate $\frac{{\sin {p['a']}^\circ\cos {p['b']}^\circ+\cos {180-p['a']}^\circ\cos {90+p['b']}^\circ}}{{\sin {p['c']}^\circ\cos {p['d']}^\circ+\cos {180-p['c']}^\circ\cos {90+p['d']}^\circ}}$.",
          lambda p:1,valid=lambda p:p['a']+p['b']==p['c']+p['d']<90,sample=sample,
          constraints=['Both sums coincide and are strictly between zero and 90 degrees; denominator is nonzero.'])
    if pid=='precalculus/test/102':
        sins={30:F(1,2),90:F(1),150:F(1,2)}
        return T('symmetric_sine_sum',{'a':choice([30,90,150]),'b':choice([30,90,150]),'theta':I(1,29)},dict(a=30,b=90,theta=17),
          lambda p:rf"Evaluate $\frac{{\sin {p['a']-p['theta']}^\circ+\sin {p['a']+p['theta']}^\circ+\sin {p['b']-p['theta']}^\circ+\sin {p['b']+p['theta']}^\circ}}{{\cos {p['theta']}^\circ}}$.",
          lambda p:2*(sins[p['a']]+sins[p['b']]),constraints=['cos(theta) is nonzero; both center angles have rational sine.'])
    if pid=='precalculus/test/152':
        def valid(p):return F(p['snum'],p['sden'])+F(p['cnum'],p['cden'])**2<=4
        return T('sum_of_two_unit_vectors',{'snum':I(0,48),'sden':I(1,12),'cnum':I(-12,12),'cden':I(1,12)},
          dict(snum=5,sden=3,cnum=1,cden=1),
          lambda p:rf"If $\sin a+\sin b=\sqrt{{{p['snum']}/{p['sden']}}}$ and $\cos a+\cos b={p['cnum']}/{p['cden']}$, find $\cos(a-b)$.",
          lambda p:(F(p['snum'],p['sden'])+F(p['cnum'],p['cden'])**2-2)/2,valid=valid,
          constraints=['Squared length of the given sum vector is at most four, ensuring realizability.'])
    if pid=='precalculus/test/155':
        return T('cosine_solution_period',{'frequency':I(1,30),'sign':choice([-1,1])},dict(frequency=4,sign=-1),
          lambda p:rf"All real solutions of $\cos({p['frequency']}x)={p['sign']}/2$ have the form $x=(kn\pm1)\pi/{3*p['frequency']//(2 if p['sign']==-1 else 1)}$, $n\in\mathbb Z$. Find positive $k$.",
          lambda p:3 if p['sign']==-1 else 6,valid=lambda p:p['sign']==1 or p['frequency']%2==0,
          constraints=['Negative sign requires even frequency so the displayed denominator is integral.'])
    if pid=='precalculus/test/185':
        return T('tangent_complement',{'angle':I(1,44)},dict(angle=20),
          lambda p:rf"Find the smallest positive $x$ in degrees with $\tan {p['angle']}^\circ+2\tan {90-2*p['angle']}^\circ=\tan x^\circ$.",
          lambda p:90-p['angle'],constraints=['0 < angle < 45 degrees; cot(angle)-tan(angle)=2*cot(2*angle).'])
    if pid=='precalculus/test/195':
        return T('secant_cosecant_count',{'radicand':I(1,100),'periods':I(1,20)},dict(radicand=15,periods=1),
          lambda p:rf"How many real solutions of $\sec\theta+\csc\theta=\sqrt{{{p['radicand']}}}$ lie in $0\le\theta\le {2*p['periods']}\pi$?",
          lambda p:p['periods']*(2+(p['radicand']>=8)+(p['radicand']>8)),
          constraints=['Positive radicand; poles are excluded. Two mixed-sign solutions per period and zero/one/two first-quadrant solutions below/at/above radicand 8.'])
    if pid in ('precalculus/test/230','precalculus/test/472'):
        from math import gcd
        def sample(r):
            n=r.randint(2,9);d=2**n-1
            return dict(terms=n,numerator=r.choice([u for u in range(1,d) if gcd(u,d)==1]))
        return T('doubling_cosine_product',{'terms':I(2,9),'numerator':I(1,510)},dict(terms=3 if pid.endswith('/230') else 4,numerator=1),
          lambda p:r"Evaluate $"+r"\cdot ".join(rf"\cos\frac{{{2**(j+1)*p['numerator']}\pi}}{{{2**p['terms']-1}}}" for j in range(p['terms']))+"$.",
          lambda p:F(1,2**p['terms']),valid=lambda p:p['numerator']<2**p['terms']-1 and gcd(p['numerator'],2**p['terms']-1)==1,
          sample=sample,reference=cosine_product_reference,
          constraints=['The numerator is positive, smaller than, and coprime to the odd denominator 2^terms-1.'],
          adaptation='The number of doubling-angle factors and their common angular numerator may vary.')
    if pid=='precalculus/test/394':
        return T('sqrt_log_sine_range',{'base':I(2,30),'offset_root':I(0,30)},dict(base=2,offset_root=0),
          lambda p:rf"How many integers are in the range of the real-valued function $y=\sqrt{{\log_{{{p['base']}}}(\sin x)+{p['offset_root']**2}}}$?",
          lambda p:p['offset_root']+1,constraints=['Base exceeds one; real domain gives exactly the range [0, offset_root].'],
          adaptation='The implicit additive zero inside the square root becomes a nonnegative square, changing the real domain and range.')
