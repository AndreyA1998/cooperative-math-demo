"""Exact rates, decimal place-value problems, and elementary word equations."""
from fractions import Fraction as F
from math import floor

from .round3_algebra_test_common import bind


def rounded(q,scale):
    units=floor(abs(q)*scale+F(1,2))
    return F(units if q>=0 else -units,scale)


def away_from_tie(q,scale):
    return (abs(q)*scale)%1 != F(1,2)


def build(row,index):
    def make(*args,**kwargs):
        return bind(row,*args,**kwargs)

    if index == 18:
        def number(n):
            return {2:'Two',10:'Ten'}.get(n,str(n))

        return make('equivalent_weights',dict(first_treeks=(1,200),first_squigs=(1,30),second_treeks=(1,30)),
                    (10,3,2), [('Ten treeks',lambda a,b,c:f'{number(a)} treeks'),
                                ('three squigs',lambda a,b,c:f'{("three" if b==3 else b)} squigs'),
                                ('Two treeks',lambda a,b,c:f'{number(c)} treeks')],
                    lambda a,b,c:F(a+c,b+1),
                    valid=lambda a,b,c:a>b*c and (a+c)%(b+1)==0,
                    sample=lambda rng:treek_draw(rng),
                    constraints=['All three weights are positive and the requested number of treeks is an integer.'])
    if index == 71:
        def multiplier(a,b,c,d,e,f):
            return F(c*f+d*e,a*f-b*e)

        return make('changed_pair_ratios',dict(original_low=(1,25),original_high=(2,30),subtract=(1,100),
                    add=(1,100),changed_low=(1,25),changed_high=(2,30)),(3,5,4,8,2,7),
                    [('3:5',lambda a,b,c,d,e,f:f'{a}:{b}'),('When 4',lambda a,b,c,d,e,f:f'When {c}'),
                     ('and 8',lambda a,b,c,d,e,f:f'and {d}'),('2:7',lambda a,b,c,d,e,f:f'{e}:{f}'),
                     ('before 8',lambda a,b,c,d,e,f:f'before {d}')],
                    lambda a,b,c,d,e,f:b*multiplier(a,b,c,d,e,f),
                    valid=lambda a,b,c,d,e,f:a<b and a*f>b*e,
                    constraints=['The original ratio is below one and the changed ratio is strictly smaller than the original ratio.'])
    if index == 82:
        def solve(a,b,total):
            prefix=(total-a-b)//200
            return sum(map(int,str(prefix)))

        return make('shared_decimal_prefix',dict(first_suffix=(10,99),second_suffix=(10,99),total=(20020,199998)),
                    (10,12,123422),[('AMC10',lambda a,b,t:f'AMC{a}'),('AMC12',lambda a,b,t:f'AMC{b}'),
                                    ('$123422.',lambda a,b,t:f'${t}.')],
                    solve,valid=lambda a,b,t:a!=b and (t-a-b)%200==0 and 100<=(t-a-b)//200<=999 and len(set(str((t-a-b)//200)))==3,
                    sample=lambda rng:prefix_draw(rng),
                    constraints=['Suffixes are distinct and subtracting both from the total gives 200 times a three-digit common prefix with distinct digits.'])
    if index == 238:
        return make('repeat_block_division',dict(dividend=(1010,99999999),divisor=(101,10001)),(123123,1001),
                    [('123123',lambda n,d:n),('1001',lambda n,d:d)],lambda n,d:n//d,
                    valid=lambda n,d:d in (101,1001,10001) and n%d==0 and (d-1)//10<=n//d<d-1,
                    sample=lambda rng:block_draw(rng),
                    constraints=['The divisor is one more than 10 to the power of the repeated block length, and the dividend repeats that full-width decimal block twice.'])
    if index == 381:
        def valid(s,d):
            return d%9==0 and (s-d//9)%2==0 and 1<=(s-d//9)//2<(s+d//9)//2<=9

        return make('reverse_digits_sum',dict(digit_sum=(3,17),difference=(9,72)),(13,27),
                    [('$13.',lambda s,d:f'${s}.'),('$27.',lambda s,d:f'${d}.')],
                    lambda s,d:11*s,valid=valid,sample=lambda rng:reverse_draw(rng),
                    reference=lambda s,d:next(11*(a+b) for a in range(1,10) for b in range(1,10)
                                              if a+b==s and 9*(a-b)==d),
                    constraints=['There are two nonzero digits whose sum is prescribed and whose signed reversal difference is prescribed.'])
    if index == 532:
        return make('hourly_chimes',dict(cycle_hours=(3,120)),(12,),
                    [('and so forth.',lambda n:f'and so forth, cycling back to one chime after {n} hours.'),
                     ('twelve-hour',lambda n:f'{n}-hour')],
                    lambda n:n*(n+1)//2, reference=lambda n:sum(range(1,n+1)),
                    adaptation='States when the sequence of chime counts resets, generalizing the usual twelve-hour clock.')
    if index == 786:
        def first(degrees,duration,target):
            return 'one day' if duration==24 else 'one hour' if duration==1 else f'{duration} hours'

        return make('constant_angular_rate',dict(degrees=(1,3600),elapsed_hours=(1,120),target_hours=(1,120)),
                    (360,24,1),[('The earth',lambda a,b,c:'The earth' if (a,b)==(360,24) else 'A planet'),
                                 ('360 degrees',lambda a,b,c:f'{a} degrees'),
                                 ('one day',first),('one hour',lambda a,b,c:'one hour' if c==1 else f'{c} hours')],
                    lambda a,b,c:F(a*c,b),
                    adaptation='Uses a hypothetical planet for angular rates different from the source rate for Earth.')
    if index == 800:
        return make('scaled_absolute_difference_rounded',
                    dict(first_num=(1,50),first_den=(1,60),second_abs_num=(1,50),second_den=(1,60),scale=(1,120)),
                    (1,4,1,2,18),[(r'\frac{1}{4}',lambda a,b,c,d,k:fr'\frac{{{a}}}{{{b}}}'),
                                   (r'\frac{1}{2}',lambda a,b,c,d,k:fr'\frac{{{c}}}{{{d}}}'),
                                   ('18A',lambda a,b,c,d,k:f'{k}A'),('18B',lambda a,b,c,d,k:f'{k}B')],
                    lambda a,b,c,d,k:rounded(k*(F(a,b)+F(c,d)),10),
                    valid=lambda a,b,c,d,k:away_from_tie(k*(F(a,b)+F(c,d)),10),
                    constraints=['The result before rounding does not land exactly between two tenths.'])
    if index == 913:
        return make('unknown_divisor_digit',dict(dividend=(11,891),quotient_tens=(1,9)),(144,1),
                    [('144',lambda n,t:n),(r'1\Delta',lambda n,t:fr'{t}\Delta'),
                     ('with 1 the',lambda n,t:f'with {t} the')],
                    lambda n,t:next(d for d in range(1,10) if d*(10*t+d)==n),
                    valid=lambda n,t:any(d*(10*t+d)==n for d in range(1,10)),
                    sample=lambda rng:digit_divisor_draw(rng),
                    constraints=['The dividend must equal a nonzero digit times the two-digit quotient with that digit in the ones place.'])
    if index == 977:
        return make('rounded_horsepower_conversion',dict(horsepower=(1,5000)),
                    (500,),[('$500$',lambda a:f'${a}$')],
                    lambda a:rounded(F(25*a,34),1),
                    valid=lambda a:away_from_tie(F(25*a,34),1),
                    constraints=['The conversion factor stays fixed and the result is not an exact half kilowatt.'])
    if index == 999:
        return make('sum_of_intercepts_rounded',dict(first_slope_num=(1,50),first_slope_den=(1,50),
                    first_intercept=(-100,100),second_slope=(1,50),second_intercept=(-100,100)),
                    (1,3,7,2,5),[(r'\frac{1}{3}x + 7',lambda a,b,c,d,e:fr'\frac{{{a}}}{{{b}}}x {signed(c)}'),
                                 ('2x+5',lambda a,b,c,d,e:f'{d}x{signed(e).replace(" ","")}')],
                    lambda a,b,c,d,e:rounded(-F(b*c,a)-F(e,d),10),
                    valid=lambda a,b,c,d,e:away_from_tie(-F(b*c,a)-F(e,d),10),
                    constraints=['The sum of the intercepts is not exactly between two tenths.'])


def signed(n):
    return f'+ {n}' if n>=0 else f'- {-n}'


def treek_draw(rng):
    squigs=rng.randint(1,15)
    second=rng.randint(1,15)
    ratio=rng.randint(second+1,second+10)
    return (squigs+1)*ratio-second,squigs,second


def prefix_draw(rng):
    a,b=rng.sample(range(10,100),2)
    return a,b,200*rng.randint(100,999)+a+b


def block_draw(rng):
    digits=rng.randint(2,4)
    place=10**digits
    divisor=place+1
    return divisor*rng.randrange(place//10,place),divisor


def reverse_draw(rng):
    b,a=sorted(rng.sample(range(1,10),2))
    return a+b,9*(a-b)


def digit_divisor_draw(rng):
    d,t=(rng.randint(1,9) for _ in range(2))
    return d*(10*t+d),t
