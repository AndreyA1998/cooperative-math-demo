"""Integer sequences and exact finite counts."""
from fractions import Fraction as F
from math import isqrt

from .round3_algebra_test_common import bind


def build(row, index):
    def make(*args, **kwargs):
        return bind(row,*args,**kwargs)

    if index in (90,489):
        original = 60 if index==90 else 128
        def solve(d):
            midpoint = d//4
            return 2*midpoint if index==90 else midpoint**2-1

        def oracle(d):
            n = next(n for n in range(1,d) if (n+2)**2-n*n==d)
            return n+n+2 if index==90 else n*(n+2)

        residue = 4 if index==90 else 0
        return make('consecutive_squares',dict(difference=(8,8000)),(original,),
                    [(str(original),str)],solve,reference=oracle,
                    valid=lambda d:d%8==residue,
                    sample=lambda rng:(8*rng.randint(2,999)+residue,),
                    constraints=['The difference is 4 modulo 8 for positive consecutive evens, or 0 modulo 8 for consecutive odds, respectively.'])
    if index == 271:
        def numerator(n,m,c):
            return m*m-c-n*(n-1)

        return make('even_run_and_initial_odds',dict(even_count=(2,25),odd_count=(2,100),deficit=(1,10000)),
                    (5,8,4), [('5 consecutive',lambda n,m,c:f'{n} consecutive'),
                              ('4 less',lambda n,m,c:f'{c} less'),
                              ('first 8',lambda n,m,c:f'first {m}')],
                    lambda n,m,c:numerator(n,m,c)//n,
                    valid=lambda n,m,c:numerator(n,m,c)%(2*n)==0,
                    sample=lambda rng:even_run_draw(rng),
                    reference=lambda n,m,c:2*((sum(range(1,2*m,2))-c)//(2*n))-n+1
                    if n%2 else (sum(range(1,2*m,2))-c)//n-n+1,
                    constraints=['The odd-run sum minus the deficit and n(n−1) is divisible by 2n.'])
    if index == 391:
        def solve(side):
            return (side*side-1).bit_length()

        def oracle(side):
            unpainted=F(side*side)
            days=0
            while unpainted>1:
                unpainted/=2
                days+=1
            return days

        return make('painting_halves',dict(side=(2,1000)),(15,),
                    [(r"15^\prime \times 15^\prime",lambda s:fr"{s}^\prime \times {s}^\prime"),
                     ("until there was only one square foot or less left, in which case he would stay and finish the job that day",
                      lambda s: "and then finish that same day if the half-painting left one square foot or less")],
                    solve,reference=oracle,
                    adaptation='Finish during the day when the planned half-painting leaves at most one square foot, matching the source key.')
    if index == 803:
        return make('consecutive_odd_product',dict(product=(3,3999999)),(255,),
                    [('255',str)],lambda p:isqrt(p+1)+1,
                    valid=lambda p:(m:=isqrt(p+1))**2==p+1 and m%2==0,
                    sample=lambda rng:((2*rng.randint(1,1000))**2-1,),
                    reference=lambda p:next(n for n in range(3,2002,2) if n*(n-2)==p),
                    constraints=['Product plus one is an even perfect square.'])
    if index == 877:
        return make('arithmetic_progression_given_sum',dict(first=(-100,100),pair_sum=(-300,300)),
                    (2,25), [('is $2$',lambda a,b:f'is ${a}$'),('is $25$',lambda a,b:f'is ${b}$')],
                    lambda a,b:F(a+3*b,7),
                    reference=lambda a,b:a+3*F(b-2*a,7))
    if index == 993:
        def solve(digits):
            lower=10**(digits-1)
            n=(isqrt(1+4*lower)-1)//2
            if n*(n+1)<lower:
                n+=1
            return n*(n+1)

        names=('zero','one','two','three','four','five','six','seven','eight','nine')
        return make('first_pronic_of_length',dict(digits=(2,8)),(4,),
                    [('four-digit',lambda n:f'{names[n]}-digit')],solve,
                    reference=lambda n:next(i*(i+1) for i in range(1,10**((n+1)//2)+1) if i*(i+1)>=10**(n-1)))
    if index == 1056:
        names={10:'ten'}
        def total(n):
            return n*(n+1)//2

        def solve(n):
            return total(n)-isqrt(total(n)-1)**2

        return make('omitted_term_for_square',dict(count=(2,10000)),(10,),
                    [('first ten',lambda n:f'first {names.get(n,n)}'),('first ten',lambda n:f'first {names.get(n,n)}')],
                    solve,valid=lambda n:solve(n)<=n,
                    reference=omitted_term_oracle,
                    constraints=['The largest square strictly below the sum of the first n terms is at least that sum minus n.'])
    if index == 942:
        def choices(a,b):
            return [n for n in range(-100,0) if -b<n**3<-a]

        return make('integer_between_negative_cube_roots',dict(near=(1,999999),far=(2,1000000)),
                    (45,101), [('-45',lambda a,b:f'-{a}'),('-101',lambda a,b:f'-{b}')],
                    lambda a,b:choices(a,b)[0],valid=lambda a,b:len(choices(a,b))==1,
                    sample=lambda rng:cube_draw(rng),
                    constraints=['The two negative radicands strictly enclose exactly one integer cube.'])


def even_run_draw(rng):
    n=rng.randint(2,25)
    m=rng.randint(55,95)
    first=2*rng.randint(1,25)
    return n,m,m*m-n*(first+n-1)


def cube_draw(rng):
    n=rng.randint(2,99)
    return rng.randint((n-1)**3,n**3-1),rng.randint(n**3+1,(n+1)**3)


def omitted_term_oracle(n):
    total = sum(range(1,n+1))
    return next(x for x in range(1,n+1) if isqrt(total-x)**2 == total-x)
