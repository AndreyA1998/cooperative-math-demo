"""Explicit source bindings for the second algebra extension."""
from .round2_algebra_equations import BINDINGS as EQUATIONS
from .round2_algebra_expressions import BINDINGS as EXPRESSIONS
from .round2_algebra_powers import BINDINGS as POWERS
from .round2_algebra_quadratics import BINDINGS as QUADRATICS
from .round2_algebra_sequences import BINDINGS as SEQUENCES
from .round2_algebra_words import BINDINGS as WORDS


BINDINGS = {**EQUATIONS, **EXPRESSIONS, **POWERS, **QUADRATICS, **SEQUENCES, **WORDS}


def build(row):
    if row.get('subject') != 'algebra':
        return None
    factory = BINDINGS.get(row['id'].removeprefix('algebra/'))
    return factory() if factory else None
