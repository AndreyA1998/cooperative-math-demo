"""Additional exact templates for the remaining algebra sources."""
from . import algebra_equations, algebra_extrema, algebra_identities, algebra_polynomials, algebra_symbols, algebra_vieta


def build(row):
    return (algebra_equations.build(row) or algebra_vieta.build(row) or
            algebra_symbols.build(row) or algebra_polynomials.build(row) or algebra_identities.build(row)
            or algebra_extrema.build(row))
