"""Additional exact families organized by mathematical subject.

The registry appends these builders after released families. The public API and
source corpus remain centralized; this package contains no downloader or runner.
"""
