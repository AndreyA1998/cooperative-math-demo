"""Real-root queries, including poles, absolute values and principal radicals."""
from fractions import Fraction
from itertools import product
from math import gcd, isqrt, lcm

from mathgen.families.algebra import (
    _MATH_BLOCK, _MathParser, _ParseError, _math_body, _poly_add, _poly_divmod,
    _poly_gcd, _poly_mul, _poly_power, _tex_polynomial,
)
from mathgen.families.algebra_v2 import (
    _Bindings, _add, _exact_power, _horner, _multiply, _rational, _scalar,
)

from .common import integer, is_square, sqrt_fraction, template


class EquationParser(_MathParser):
    """Extend arithmetic with explicit absolute values and principal radicals."""

    def __init__(self, source):
        super().__init__(source)
        self.abs_depth = 0

    def _atom(self, freeze):
        symbol = self._peek()
        if symbol == "|":
            self._take("|")
            self.abs_depth += 1
            child = self._expr(0, freeze)
            self._take("|")
            self.abs_depth -= 1
            return self._powered(("abs", child))
        if symbol == r"\sqrt":
            self._take(symbol)
            degree = 2
            if self._peek() == "[":
                self._take("[")
                exponent = self._number_node(True)
                self._take("]")
                degree = int(exponent[1])
                if degree not in (2, 3):
                    raise _ParseError("unsupported root index")
            return self._powered(("radical", self._argument(freeze), degree))
        return super()._atom(freeze)


    def _expr(self, minimum, freeze):
        node = self._atom(freeze)
        while True:
            symbol = self._peek()
            implicit = (
                symbol in ("(", "{", "[", r"\frac", r"\dfrac", r"\tfrac", r"\sqrt")
                or symbol == "|" and self.abs_depth == 0
                or len(symbol) == 1 and symbol.isascii() and symbol.isalpha()
            )
            if not implicit and symbol not in self._operators:
                break
            if symbol in (r"\frac", r"\dfrac", r"\tfrac") and node[0] in ("const", "literal"):
                raise _ParseError("ambiguous mixed fraction")
            priority, operation = (2, "*") if implicit else self._operators[symbol]
            if priority < minimum:
                break
            if not implicit:
                self._take(symbol)
            node = operation, node, self._expr(priority + 1, freeze)
        return node


def variables(node):
    op = node[0]
    if op in ("const", "literal"):
        return set()
    if op == "var":
        return {node[1]}
    if op in ("neg", "radical", "abs"):
        return variables(node[1])
    if op in ("+", "-", "*", "/", "^"):
        return variables(node[1]) | variables(node[2])
    raise _ParseError("unsupported expression")


ONE = (Fraction(1),)


def rational_form(node, values, variable):
    """Return numerator, denominator and all original nonzero pole factors."""
    op = node[0]
    if op in ("const", "literal"):
        value = values[node[1]] if op == "literal" else node[1]
        return (value,) if value else (), ONE, ONE
    if op == "var":
        if node[1] != variable:
            raise ValueError("unexpected variable")
        return (Fraction(0), Fraction(1)), ONE, ONE
    a, b, holes = rational_form(node[1], values, variable)
    if op == "neg":
        return tuple(-x for x in a), b, holes
    if op == "^":
        power = int(node[2][1])
        if power < 0:
            if not a:
                raise ValueError("identically zero denominator")
            holes = _poly_mul(holes, a)
            a, b = b, a
        return _poly_power(a, abs(power)), _poly_power(b, abs(power)), holes
    c, d, other_holes = rational_form(node[2], values, variable)
    holes = _poly_mul(holes, other_holes)
    if op in ("+", "-"):
        sign = 1 if op == "+" else -1
        return _poly_add(_poly_mul(a, d), _poly_mul(c, b), sign), _poly_mul(b, d), holes
    if op == "*":
        return _poly_mul(a, c), _poly_mul(b, d), holes
    if op == "/":
        if not c:
            raise ValueError("identically zero denominator")
        return _poly_mul(a, d), _poly_mul(b, c), _poly_mul(holes, c)
    raise ValueError("unsupported rational operation")


def reduced_zero_polynomial(numerator, holes):
    if not numerator:
        raise ValueError("equation has an interval of solutions or needs branch analysis")
    while len(numerator) > 1:
        common = _poly_gcd(numerator, holes)
        if len(common) <= 1:
            break
        numerator, remainder = _poly_divmod(numerator, common)
        if remainder:
            raise ArithmeticError("unexpected polynomial division remainder")
    return numerator


def real_root_count(coefficients):
    """Distinct real roots by the signs of the Sturm sequence at infinities."""
    if len(coefficients) <= 1:
        return 0
    derivative = tuple(index * value for index, value in enumerate(coefficients) if index)
    sequence = [coefficients, derivative]
    while sequence[-1]:
        _, remainder = _poly_divmod(sequence[-2], sequence[-1])
        if not remainder:
            break
        sequence.append(tuple(-value for value in remainder))

    def changes(direction):
        signs = [polynomial[-1] * direction ** (len(polynomial) - 1) > 0
                 for polynomial in sequence]
        return sum(a != b for a, b in zip(signs, signs[1:]))

    return changes(-1) - changes(1)


def divisors(n):
    for d in range(1, isqrt(n) + 1):
        if n % d == 0:
            yield d
            if d * d != n:
                yield n // d


def rational_roots(coefficients):
    """The primitive integer polynomial's rational root theorem candidates."""
    if len(coefficients) <= 1:
        return set()
    if coefficients[0] == 0:
        return {Fraction(0)} | rational_roots(coefficients[1:])
    denominator = lcm(*(Fraction(c).denominator for c in coefficients))
    integers = [int(denominator * c) for c in coefficients]
    content = gcd(*integers)
    numerators = tuple(divisors(abs(integers[0] // content)))
    denominators = tuple(divisors(abs(integers[-1] // content)))
    candidates = {Fraction(sign * a, b) for a, b, sign in
                  product(numerators, denominators, (-1, 1))}
    return {candidate for candidate in candidates if not _horner(coefficients, candidate)}


def positive_integer_roots(coefficients):
    """Integer roots divide the primitive constant; skip other rational roots."""
    # Zero roots are irrelevant here, but factoring them out exposes the
    # constant needed by the integer root theorem for the remaining roots.
    while coefficients and not coefficients[0]:
        coefficients = coefficients[1:]
    if len(coefficients) <= 1:
        return set()
    denominator = lcm(*(Fraction(c).denominator for c in coefficients))
    integers = [int(denominator * c) for c in coefficients]
    content = gcd(*integers)
    integers = [c // content for c in integers]
    roots = set()
    for candidate in divisors(abs(integers[0])):
        value = 0
        for coefficient in reversed(integers):
            value = value * candidate + coefficient
        if not value:
            roots.add(Fraction(candidate))
    return roots


def _compile_polynomial(node, variable):
    """Compile division-free polynomial terms once; reject other syntax."""
    def terms(tree):
        op = tree[0]
        if op == "const":
            value = Fraction(tree[1])
            value = value.numerator if value.denominator == 1 else value
            return ((0, lambda values: value),)
        if op == "literal":
            return ((0, lambda values: values[tree[1]]),)
        if op == "var" and tree[1] == variable:
            return ((1, lambda values: 1),)
        if op == "neg":
            return tuple((degree, lambda values, f=f: -f(values))
                         for degree, f in terms(tree[1]))
        if op in ("+", "-", "*"):
            left, right = terms(tree[1]), terms(tree[2])
            if op == "+":
                return left + right
            if op == "-":
                return left + tuple((degree, lambda values, f=f: -f(values))
                                    for degree, f in right)
            return tuple((a + b, lambda values, f=f, g=g: f(values) * g(values))
                         for a, f in left for b, g in right)
        if op == "^" and tree[2][0] == "const":
            exponent = tree[2][1]
            if exponent >= 0 and exponent == int(exponent):
                base = terms(tree[1])
                if len(base) == 1:
                    degree, coefficient = base[0]
                    exponent = int(exponent)
                    return ((degree * exponent,
                             lambda values: coefficient(values) ** exponent),)
        # In particular, division, radicals, absolute values and expanded
        # polynomial powers retain the original rational/branch solver.
        raise ValueError("expression needs the general equation solver")

    compiled = terms(node)
    size = max(degree for degree, _ in compiled) + 1

    def evaluate(values):
        coefficients = [0] * size
        for degree, coefficient in compiled:
            coefficients[degree] += coefficient(values)
        while coefficients and not coefficients[-1]:
            coefficients.pop()
        return tuple(coefficients)

    return evaluate


def branches(node):
    """Each absolute value branch records a disjoint sign condition."""
    op = node[0]
    if op in ("literal", "const", "var"):
        return [(node, ())]
    if op == "abs":
        result = []
        for child, conditions in branches(node[1]):
            result.extend(((child, conditions + ((child, True),)),
                           (("neg", child), conditions + ((child, False),))))
        return result
    if op in ("neg", "radical"):
        return [((op, child, *node[2:]), conditions) for child, conditions in branches(node[1])]
    return [((op, left, right), left_conditions + right_conditions)
            for (left, left_conditions), (right, right_conditions)
            in product(branches(node[1]), branches(node[2]))]


def quadratic_roots(coefficients):
    """Represent each real root as (rational part, coefficient, radicand)."""
    if len(coefficients) == 1:
        return ()
    if len(coefficients) == 2:
        b, a = coefficients
        return ((-b / a, 0, 0),)
    if len(coefficients) != 3:
        raise ValueError("equation exceeds quadratic degree")
    c, b, a = coefficients
    delta = b * b - 4 * a * c
    if delta < 0:
        return ()
    center, scale = -b / (2 * a), 1 / (2 * a)
    if is_square(delta):
        offset = scale * sqrt_fraction(delta)
        return tuple((root, 0, 0) for root in sorted({center - offset, center + offset}))
    return ((center, -scale, delta), (center, scale, delta))


def polynomial_sign(coefficients, root):
    center, scale, delta = root
    a = b = Fraction(0)
    for coefficient in reversed(coefficients):
        a, b = a * center + b * scale * delta + coefficient, a * scale + b * center
    if not b or not delta:
        return (a > 0) - (a < 0)
    if a >= 0 and b > 0:
        return 1
    if a <= 0 and b < 0:
        return -1
    comparison = a * a - b * b * delta
    return ((comparison > 0) - (comparison < 0)) * ((a > 0) - (a < 0))


def _prepare_radicals(left, right):
    """Raise principal radicals to a shared index, retaining domain checks."""
    if left[0] == "radical" and right[0] == "radical":
        if left[2] != right[2]:
            raise ValueError("root index mismatch")
        conditions = ((left[1], True), (right[1], True)) if left[2] == 2 else ()
        return left[1], right[1], conditions
    if left[0] != "radical" and right[0] == "radical":
        left, right = right, left
    if left[0] != "radical":
        return left, right, ()
    conditions = ((left[1], True), (right, True)) if left[2] == 2 else ()
    return left[1], ("^", right, ("const", Fraction(left[2]))), conditions


def _root_sets(nodes, p, bindings, variable, mode):
    left_node, left_keys = nodes[0]
    right_node, right_keys = nodes[1]
    values = bindings.values(left_keys, p) + bindings.values(right_keys, p)

    def offset_literals(node, offset):
        op = node[0]
        if op == "literal":
            return op, node[1] + offset
        if op in ("const", "var"):
            return node
        if op in ("neg", "abs", "radical"):
            return op, offset_literals(node[1], offset), *node[2:]
        return op, offset_literals(node[1], offset), offset_literals(node[2], offset)

    right_node = offset_literals(right_node, len(left_keys))
    roots = set()
    for (left, left_constraints), (right, right_constraints) in product(branches(left_node), branches(right_node)):
        left, right, radical_constraints = _prepare_radicals(left, right)
        conditions = left_constraints + right_constraints + radical_constraints
        numerator, _, holes = rational_form(("-", left, right), values, variable)
        polynomial = reduced_zero_polynomial(numerator, holes)
        if mode == "real_count" and not conditions:
            return real_root_count(polynomial)
        if mode == "complex_count" and not conditions:
            derivative = tuple(i * c for i, c in enumerate(polynomial) if i)
            return len(polynomial) - len(_poly_gcd(polynomial, derivative))
        if mode == "positive_integer" and not conditions:
            candidates = [(root, 0, 0) for root in positive_integer_roots(polynomial)]
        elif mode in ("rational_sum", "integer_sum") and not conditions:
            candidates = [(root, 0, 0) for root in rational_roots(polynomial)
                          if mode == "rational_sum" or root.denominator == 1]
        else:
            candidates = quadratic_roots(polynomial)
        for candidate in candidates:
            for condition, nonnegative in conditions:
                cn, cd, ch = rational_form(condition, values, variable)
                sign = polynomial_sign(cn, candidate) * polynomial_sign(cd, candidate)
                if not polynomial_sign(ch, candidate) or (sign >= 0) != nonnegative:
                    break
            else:
                roots.add(candidate)
    return roots


def _surd(root):
    center, scale, delta = root
    if not scale:
        return _rational(center)
    return _add(_rational(center), _multiply(_rational(scale), _exact_power(_rational(delta), Fraction(1, 2))))


EQUATIONS = {
    "algebra/train/27": "difference",
    "algebra/train/33": "sum",
    "algebra/train/75": "sum",
    "algebra/train/115": "average",
    "algebra/train/151": "largest",
    "algebra/train/165": "product",
    "algebra/train/227": "unique",
    "algebra/train/247": "unique",
    "algebra/train/278": "product",
    "algebra/train/285": "sum",
    "algebra/train/333": "smallest",
    "algebra/train/383": "unique",
    "algebra/train/520": "product",
    "algebra/train/594": "sum",
    "algebra/train/624": "smallest",
    "algebra/train/627": "unique",
    "algebra/train/642": "sum",
    "algebra/train/688": "sum",
    "algebra/train/1087": "nonnegative_count",
    "algebra/train/1098": "difference",
    "algebra/train/1185": "largest",
    "algebra/train/1193": "sum",
    "algebra/train/1244": "sum",
    "algebra/train/1252": "smallest",
    "algebra/train/1366": "sum",
    "algebra/train/1372": "unique",
    "algebra/train/1381": "largest",
    "algebra/train/1445": "unique",
    "algebra/train/1460": "positive",
    "algebra/train/1507": "sum",
    "algebra/train/1555": "nonzero",
    "algebra/train/1576": "unique",
    "algebra/train/1579": "unique",
    "algebra/train/1595": "sum",
    "algebra/train/1679": "sum_two",
    "algebra/train/1723": "sum",
    "algebra/test/42": "sum",
    "algebra/test/74": "sum",
    "algebra/test/304": "smallest",
    "algebra/test/318": "sum",
    "algebra/test/459": "sum",
    "algebra/test/555": "largest",
    "algebra/test/557": "sum_two",
    "algebra/test/605": "product_two",
    "algebra/test/607": "unique",
    "algebra/test/646": "difference",
    "algebra/test/763": "unique",
    "algebra/test/785": "unique",
    "algebra/test/842": "difference",
    "algebra/test/928": "smallest",
    "algebra/test/987": "negative",
    "intermediate_algebra/train/128": "integer_sum",
    "intermediate_algebra/train/167": "rational_sum",
    "intermediate_algebra/train/342": "real_count",
    "intermediate_algebra/train/489": "unique",
    "intermediate_algebra/train/528": "real_count",
    "intermediate_algebra/train/552": "sum",
    "intermediate_algebra/train/562": "sum",
    "intermediate_algebra/train/858": "positive_count",
    "intermediate_algebra/train/860": "complex_count",
    "intermediate_algebra/test/127": "sum",
    "intermediate_algebra/test/164": "real_count",
    "intermediate_algebra/test/232": "sum",
    "intermediate_algebra/test/243": "real_count",
    "intermediate_algebra/test/590": "unique",
    "intermediate_algebra/test/725": "positive_integer",
    "intermediate_algebra/test/831": "product",
}


def _count_positive(polynomial):
    """Apply Sturm's theorem using right-hand signs at zero and signs at infinity."""
    while polynomial and not polynomial[0]:
        polynomial = polynomial[1:]
    if len(polynomial) <= 1:
        return 0
    derivative = tuple(i * c for i, c in enumerate(polynomial) if i)
    sequence = [polynomial, derivative]
    while sequence[-1]:
        _, remainder = _poly_divmod(sequence[-2], sequence[-1])
        if not remainder:
            break
        sequence.append(tuple(-value for value in remainder))

    def changes(signs):
        return sum(a != b for a, b in zip(signs, signs[1:]))

    zero = [next(c for c in poly if c) > 0 for poly in sequence]
    infinity = [poly[-1] > 0 for poly in sequence]
    return changes(zero) - changes(infinity)


def _solve_summary(roots, mode):
    if isinstance(roots, int):
        return roots
    if mode == "real_count":
        return len(roots)
    if mode == "nonnegative_count":
        return sum(polynomial_sign((0, 1), root) >= 0 for root in roots)
    filters = {"positive": lambda sign: sign > 0,
               "negative": lambda sign: sign < 0, "nonzero": lambda sign: sign != 0}
    if mode in filters:
        roots = {root for root in roots if filters[mode](polynomial_sign((0, 1), root))}
    if not roots:
        raise ValueError("no roots")
    if mode in {"unique", "positive", "negative", "nonzero", "positive_integer"} and len(roots) != 1:
        raise ValueError("the unique root must exist")
    if mode in ("largest", "smallest", "difference"):
        if len(roots) != 2 or any(root[1] for root in roots):
            raise ValueError("two distinct rational roots required")
        low, high = sorted(root[0] for root in roots)
        return {"largest": high, "smallest": low, "difference": high - low}[mode]
    if mode in {"sum_two", "product_two"} and len(roots) != 2:
        raise ValueError("the source states that there are two distinct roots")
    multiply = mode in {"product", "product_two"}
    total = _rational(1) if multiply else {}
    combine = _multiply if multiply else _add
    for root in roots:
        total = combine(total, _surd(root))
    answer = _scalar(total)
    return answer / len(roots) if mode == "average" else answer


def _find_nodes(row, bindings):
    for block in _MATH_BLOCK.finditer(row["problem"]):
        source, offset = _math_body(block)
        if source.count("=") != 1:
            continue
        left, right = source.split("=")
        if row["id"] == "intermediate_algebra/train/167":
            left = ""
        try:
            if left:
                lhs = bindings.parse(left, offset, EquationParser, "left")
            else:
                lhs = (("const", Fraction(0)), ())
            rhs = bindings.parse(right, offset + len(source.split("=")[0]) + 1, EquationParser, "right")
            names = variables(lhs[0]) | variables(rhs[0])
            if len(names) != 1:
                return None
            return (lhs, rhs), next(iter(names))
        except (ValueError, _ParseError):
            return None
    return None


def _build_bound_equation(row, mode):
    bindings = _Bindings(row["problem"])
    parsed = _find_nodes(row, bindings)
    if not parsed or not bindings.original:
        return None
    nodes, variable = parsed
    polynomial_evaluators = None
    if mode == "positive_integer":
        try:
            polynomial_evaluators = tuple(_compile_polynomial(tree, variable)
                                          for tree, _ in nodes)
        except ValueError:
            pass

    def solve(p):
        if polynomial_evaluators is not None:
            polynomial = []
            for evaluate, (_, keys), sign in zip(polynomial_evaluators, nodes, (1, -1)):
                values = tuple(p[name] if scale == 1 else Fraction(p[name], scale)
                               for name, scale in keys)
                for degree, coefficient in enumerate(evaluate(values)):
                    if degree == len(polynomial):
                        polynomial.append(0)
                    polynomial[degree] += sign * coefficient
            while polynomial and not polynomial[-1]:
                polynomial.pop()
            if not polynomial:
                raise ValueError("equation has an interval of solutions")
            roots = {(root, 0, 0) for root in positive_integer_roots(polynomial)}
            return _solve_summary(roots, mode)
        if mode == "positive_count":
            forms = [rational_form(tree, bindings.values(keys, p), variable) for tree, keys in nodes]
            (a, b, h), (c, d, j) = forms
            polynomial = reduced_zero_polynomial(_poly_add(_poly_mul(a, d), _poly_mul(b, c), -1),
                                                 _poly_mul(h, j))
            return _count_positive(polynomial)
        result = _solve_summary(_root_sets(nodes, p, bindings, variable, mode), mode)
        if row["id"] == "algebra/train/1252":
            denominator = Fraction(result).denominator
            for prime in (2, 5):
                while denominator % prime == 0:
                    denominator //= prime
            if denominator != 1:
                raise ValueError("the required exact decimal must terminate")
        return result

    adapted = ""
    if row["id"] == "intermediate_algebra/test/590":
        adapted = "Ask for the unique real root and omit the comma-separated output instruction."

    def render(p):
        problem = bindings.render(p)
        if adapted:
            return (problem.replace("Find the real roots of", "Find the unique real root of")
                    .replace("Enter the roots, separated by commas.", ""))
        return problem

    def valid(p):
        try:
            return isinstance(solve(p), (int, Fraction))
        except (ArithmeticError, ValueError, IndexError):
            return False

    # Deterministic, bounded completion: for thin discriminant conditions,
    # vary all but one literal and enumerate the last literal's domain.
    domains = bindings.domains
    keys = tuple(domains)
    completed = None

    def sample(rng):
        nonlocal completed
        for _ in range(18):
            proposal = {k: rng.randint(d["min"], d["max"]) for k, d in domains.items()}
            if proposal != bindings.original and valid(proposal):
                return proposal
        if completed is None:
            from random import Random
            search = Random(963)
            proposals = []
            for i in range(90):
                key = keys[i % len(keys)]
                fixed = dict(bindings.original) if i < 2 * len(keys) else {
                    k: search.randint(d["min"], d["max"]) for k, d in domains.items()
                }
                d = domains[key]
                for value in range(d["min"], d["max"] + 1):
                    candidate = dict(fixed, **{key: value})
                    if candidate != bindings.original and valid(candidate):
                        proposals.append(candidate)
                if len(proposals) >= 36 and i >= 3 * len(keys):
                    break
            completed = tuple(proposals)
        return dict(rng.choice(completed)) if completed else dict(bindings.original)

    constraints = [
        "Exclude every original denominator zero, including holes canceled in algebraic simplification.",
        "Absolute-value branches use disjoint sign conditions and even roots must be principal real roots.",
        "The queried statistic is a rational scalar, respecting any stated root count, integrality or sign.",
    ]
    if mode in {"largest", "smallest", "difference"}:
        constraints.append("Two distinct rational real roots exist.")
    if row["id"] == "algebra/train/1252":
        constraints.append("The smallest root has a terminating decimal expansion.")
    result = template(
        "extensions.algebra.real_equation", domains, bindings.original, render, solve,
        valid=valid, sample=sample,
        constraints=constraints,
        adaptation=adapted,
    )
    return result if valid(result.original) else None


SQUARES = {
    "algebra/train/636": ("x", 16, "sum"),
    "algebra/train/681": ("t", 36, "product"),
    "algebra/test/811": ("y", 81, "smallest"),
}


def _shifted_square(key):
    variable, rhs, mode = SQUARES[key]
    domains = {"center": integer(-24, 24), "rhs": integer(1, 300)}
    original = {"center": 0, "rhs": rhs}

    def solve(p):
        h, value = p["center"], p["rhs"]
        if mode == "smallest":
            return h - sqrt_fraction(value)
        return 2*h if mode == "sum" else h*h-value

    def reference(p):
        d = sqrt_fraction(p["rhs"])
        a, b = p["center"]-d, p["center"]+d
        return {"sum": a+b, "product": a*b, "smallest": a}[mode]

    def render(p):
        h = p["center"]
        x = "(" + _tex_polynomial((-h, 1), variable) + ")" if h else variable
        query = f"the {mode} of all real solutions for ${variable}$" if mode != "smallest" else f"the smallest real solution for ${variable}$"
        return f"Find {query} to ${x}^2={p['rhs']}$."

    return template(
        "extensions.algebra.shifted_square_roots", domains, original, render, solve,
        valid=lambda p: is_square(p["rhs"]), reference=reference,
        sample=lambda rng: {"center": rng.randint(-24, 24), "rhs": rng.randint(1, 17)**2},
        constraints=("The right-hand side is a positive integer square.",),
        adaptation="Allow a horizontal shift of the original square.",
    )


def _opposite_signs():
    domains = {"square_scale": integer(1, 15), "absolute_scale": integer(1, 15),
               "square_center": integer(-12, 12), "absolute_center": integer(-12, 12)}
    original = {"square_scale": 1, "absolute_scale": 1, "square_center": 0, "absolute_center": 0}

    def sample(rng):
        a, b = (rng.randint(1, 15) for _ in range(2))
        h, k = (rng.randint(-12, 12) for _ in range(2))
        if rng.randrange(2):
            k = h
        return {"square_scale": a, "absolute_scale": b, "square_center": h, "absolute_center": k}

    def render(p):
        lhs = _tex_polynomial((-p["square_center"], 1))
        rhs = _tex_polynomial((-p["absolute_center"], 1))
        return (f"How many real solutions does ${p['square_scale']}({lhs})^2"
                f"=-{p['absolute_scale']}|{rhs}|$ have?")

    return template(
        "extensions.algebra.opposite_sign_root_count", domains, original, render,
        lambda p: int(p["square_center"] == p["absolute_center"]), sample=sample,
        constraints=("The square coefficient is positive and the coefficient on the absolute value is negative.",),
        adaptation="Allow each nonnegative component to have its own center and positive scale.",
    )


def build(row):
    key = row["id"]
    if key in SQUARES:
        return _shifted_square(key)
    if key == "algebra/test/663":
        return _opposite_signs()
    mode = EQUATIONS.get(key)
    if mode is not None:
        return _build_bound_equation(row, mode)
    return None
