"""Constrained algebraic systems and stationary-point templates."""
from fractions import Fraction as F
from itertools import combinations_with_replacement
from math import isqrt, prod

from .common import is_square
from .round3_intermediate_common import I, bind, integers, polynomial


def log_ratio_exponent(b,left,right):
    q=F(prod(left),prod(right))
    if q==1:
        return 0
    sign=1 if q>1 else -1
    q=q if sign>0 else 1/q
    if q.denominator==1:
        value, exponent = q.numerator, 0
        # Each division decreases the positive integer; field bounds and
        # base >= 2 bound the loop by the product's bit length.
        while value % b == 0:
            value //= b
            exponent += 1
        if value == 1:
            return sign*exponent
    raise ValueError('Expected integer logarithm')


def integer_log_valid(b,left,right):
    try:
        log_ratio_exponent(b,left,right)
    except ValueError:
        return False
    return True


def log_ratio_prompt(b,left,right):
    def terms(values):
        return '+'.join(rf'a_{{{n}}}' for n in values)
    return rf'For integers $n>1$, let $a_n=1/\log_n {b}$. Let $b={terms(left)}$ and $c={terms(right)}$. Find $b-c$.'


def log_ratio_sample(rng):
    if rng.randrange(2):
        base=rng.randint(2,12)
        powers=[]
        value=base
        while value<=200:
            powers.append(value)
            value*=base
        left=[rng.choice(powers) for _ in range(4)]
        right=[rng.choice(powers) for _ in range(5)]
        return base,left,right
    left=rng.sample(range(2,13),4)
    p,q,k=[rng.randint(2,9) for _ in range(3)]
    right=[left[0]*p,left[1]*q,left[2],left[3],k]
    rng.shuffle(right)
    return p*q*k,left,right


bind('r152','difference_of_reciprocal_log_sums','base left right',(2002,[2,3,4,5],[10,11,12,13,14]),
     (I(2,20000),integers(4,2,200),integers(5,2,200)),log_ratio_prompt,log_ratio_exponent,
     valid=integer_log_valid,sample=log_ratio_sample,
     constraints=('The ratio of the two term-index products is an integer power of the logarithm base.',))


def ap_expression_sum(a,b):
    y=F(-(a+2*b),2*a+3*b)
    x=F((a+2*b)*y,1-y)
    return x-(3*a+4*b)*y


bind('r711','arithmetic_sequence_linear_product_quotient','first second',(1,1),
     (I(1,80),)*2,
     lambda a,b:rf'The first four terms in an arithmetic sequence are $x+{a}y$, $x-{b}y$, $xy$, and $x/y$, in that order. What is the fifth term?',
     ap_expression_sum)


def cyclic_reciprocal_product(c):
    return isqrt(c)**3


bind('r549','cyclic_reciprocals_absolute_product','numerator',(1,), (I(1,10000),),
     lambda k:rf'Let $a,b,c$ be distinct nonzero real numbers with $a+\frac{{{k}}}b=b+\frac{{{k}}}c=c+\frac{{{k}}}a$. Find $|abc|$.',
     cyclic_reciprocal_product,valid=is_square,sample=lambda r:(r.randint(1,100)**2,),
     constraints=('The reciprocal numerator is a positive perfect square.',))


bind('t174','maximum_symmetric_product_on_simplex','sum',(3,), (I(1,100),),
     lambda n:rf'Let $x,y,z\ge0$ satisfy $x+y+z={n}$. Find the maximum of $(xy+z)(xz+y)$.',
     lambda n:F((n+1)**4,64))


def shifted_radical_equation(b,c,d,k):
    for t in range(1,150):
        x=t*t-c
        if x>0 and x*(x+b+d*t)==k:
            return x
    raise ValueError('No integer radical value in range')


def shifted_radical_valid(b,c,d,k):
    if b<c:
        return False
    try:
        shifted_radical_equation(b,c,d,k)
    except ValueError:
        return False
    return True


def shifted_radical_sample(rng):
    t=rng.randint(2,16)
    c=rng.randint(1,min(t*t-1,50))
    b,d=c+rng.randint(0,30),rng.randint(1,20)
    return b,c,d,(t*t-c)*(t*t-c+b+d*t)


bind('r743','quadratic_plus_linear_radical_product','linear shift radical rhs',(4,3,4,13),
     (I(1,100),I(1,80),I(1,30),I(1,1000000)),
     lambda b,c,d,k:rf'Find all real solutions of $x^2+{b}x+{d}x\sqrt{{x+{c}}}={k}$.',
     shifted_radical_equation,valid=shifted_radical_valid,sample=shifted_radical_sample,
     constraints=('The linear coefficient is at least the radical shift, and an integer radical value below 150 produces a positive solution.',))


def increasing_power_sum(a,b,c,d):
    for n in range(1,17):
        if a**n+b**n+c**n==d**n:
            return n
    raise ValueError('Expected a positive integer solution')


def power_sum_valid(a,b,c,d):
    if max(a,b,c)>=d:
        return False
    try:
        increasing_power_sum(a,b,c,d)
    except ValueError:
        return False
    return True


def power_sum_sample(rng):
    if rng.randrange(2):
        a,b,c=[rng.randint(1,35) for _ in range(3)]
        return a,b,c,a+b+c
    a,b,c,d=rng.choice(_POWER_TRIPLES)
    s=rng.randint(1,5)
    terms=[s*a,s*b,s*c]
    rng.shuffle(terms)
    return *terms,s*d


_POWER_TRIPLES=[(a,b,c,isqrt(a*a+b*b+c*c)) for a,b,c in combinations_with_replacement(range(1,17),3)
                if is_square(a*a+b*b+c*c)]+[(3,4,5,6)]


bind('r828','three_term_exponential_equation','a b c d',(3,4,5,6),
     (I(1,120),)*4,
     lambda a,b,c,d:rf'Find all real $x$ satisfying $ {a}^x+{b}^x+{c}^x={d}^x$.',
     increasing_power_sum,valid=power_sum_valid,sample=power_sum_sample,
     constraints=('Each left base is less than the right base, and the equation has a positive integer solution at most 16.',))


def orbit_index(a,b,k,t):
    x=a
    value=b
    for _ in range(20):
        if x==t:
            return value
        x+=value
        value*=k
    raise ValueError('Target is outside the determined orbit')


def orbit_valid(*args):
    try:
        orbit_index(*args)
    except ValueError:
        return False
    return True


def orbit_sample(rng):
    a,b,k,j=rng.randint(-50,50),rng.randint(1,20),rng.randint(2,10),rng.randint(1,4)
    return a,b,k,a+b*sum(k**m for m in range(j))


bind('r841','iterated_nonlinear_argument_function','start value factor target',(1,4,4,21),
     (I(-100,100),I(1,100),I(2,20),I(-100,50000)),
     lambda a,b,k,t:rf'A real function satisfies $f(x+f(x))={k}f(x)$ for all $x$ and $f({a})={b}$. Find $f({t})$.',
     orbit_index,valid=orbit_valid,sample=orbit_sample,
     constraints=('The target is among the first twenty points in the forward orbit of the given input.',))


def product_eq_count(a,b,c):
    return 1


def cyclic_product_prompt(a,b,c):
    return rf'How many ordered triples of positive reals $(x,y,z)$ satisfy $(x+\frac{{{a}}}y)(y+\frac{{{b}}}z)(z+\frac{{{c}}}x)={8*isqrt(a*b*c)}$?'


bind('t278','equality_in_cyclic_product_amgm','a b c',(1,1,1),(I(1,400),)*3,
     cyclic_product_prompt,product_eq_count,
     sample=lambda r:(lambda x,y,z:(x*y,y*z,z*x))(*(r.randint(1,20) for _ in range(3))),
     valid=lambda a,b,c:is_square(a*b*c),
     constraints=('The product of the three reciprocal numerators is a perfect square.',))


def log_compose_prompt(a,b,p,q):
    return rf'Functions $f,g:[1,\infty)\to[1,\infty)$ satisfy $f(g(x))=x^{{{p}}}$ and $g(f(x))=x^{{{q}}}$ for every $x\ge1$. If $g({a**p})={b}$, find $[g({a})]^{{{q}}}$.'


bind('r1117','two_function_power_compositions','query given_value first_power second_power',
     (4,16,2,3),(I(2,30),I(2,100),I(2,8),I(2,8)),log_compose_prompt,
     lambda a,b,p,q:b)


def monomial_reduction_sample(rng):
    h,k,d=rng.randint(-8,8),rng.randint(1,150),rng.randint(-100,100)
    from math import comb
    c=[comb(5,j)*h**(5-j) for j in range(6)]
    c[1]-=k
    c[0]+=d-k*h
    return c,d


def binomial_shape(c,d):
    from math import comb
    if c[-1]!=1 or c[-2]%5:
        return None
    h=c[-2]//5
    k=5*h**4-c[1]
    if k<=0 or c[0]!=h**5-k*h+d:
        return None
    return (h,k) if all(c[j]==comb(5,j)*h**(5-j) for j in range(2,5)) else None


bind('t652','recover_fourth_power_from_shifted_quintic','coefficients rhs',
     ([1,-5,10,10,5,1],10),(integers(6,-100000,100000),I(-1000,1000)),
     lambda c,d:rf'If $ {polynomial(c)}={d}$ and $x\ne{-binomial_shape(c,d)[0]}$, find $({polynomial([binomial_shape(c,d)[0],1])})^4$.',
     lambda c,d:binomial_shape(c,d)[1],sample=monomial_reduction_sample,
     valid=lambda c,d:binomial_shape(c,d) is not None,
     constraints=('The ascending-power polynomial minus rhs has the form (x+h)^5−k(x+h) for an integer h and positive integer k.',))


def minimum_fifth_inverse_power(a,b,c,d):
    for x in range(1,21):
        if 2*a*x**7+b*x**6==5*d:
            return a*x*x+b*x+c+F(d,x**5)
    raise ValueError('No integer stationary point')


def fifth_valid(*args):
    try:
        minimum_fifth_inverse_power(*args)
    except ValueError:
        return False
    return True


def fifth_sample(rng):
    a,b,c,x=rng.randint(1,30),rng.randint(1,30),rng.randint(-50,50),rng.randint(1,5)
    b+=(-2*a*x-b)%5
    return a,b,c,(2*a*x**7+b*x**6)//5


def fifth_prompt(a,b,c,d):
    v=polynomial([-1,1])
    numerator=f'{a}({v})^7+{b}({v})^6{c:+}({v})^5+{d}'
    return rf'Find the minimum of $\frac{{{numerator}}}{{({v})^5}}$ for $x>1$.'


bind('t424','minimum_with_inverse_fifth_power','a b c d',(1,3,1,1),
     (I(1,100),I(1,100),I(-100,100),I(1,2000000)),
     fifth_prompt,minimum_fifth_inverse_power,valid=fifth_valid,sample=fifth_sample,
     constraints=('The strictly convex function in x−1 has an integer stationary point from 1 to 20.',))


def inverse_cubic_min(a,b,c):
    for x in range(1,21):
        if 4*a*x**7-b*x*x==3*c:
            return a*x**4+F(b,x)+F(c,x**3)
    raise ValueError('No integer stationary point')


def inverse_cubic_valid(*args):
    try:
        inverse_cubic_min(*args)
    except ValueError:
        return False
    return True


def inverse_cubic_sample(rng):
    a,x=rng.randint(1,20),rng.randint(2,5)
    b=rng.randint(1,50)
    b+=(4*a*x**7-b*x*x)%3 if x%3 else 0
    return a,b,(4*a*x**7-b*x*x)//3


bind('t521','minimum_with_inverse_cubic_power','a b c',(1,32,128),
     (I(1,100),I(1,1000),I(1,3000000)),
     lambda a,b,c:rf'Find the minimum of $\frac{{{polynomial([c,0,b,0,0,0,0,a])}}}{{x^3}}$ for $x>0$.',
     inverse_cubic_min,valid=inverse_cubic_valid,sample=inverse_cubic_sample,
     constraints=('The strictly convex function has an integer stationary point from 1 to 20.',))


bind('t687','minimum_trigonometric_reciprocal_pair','quadratic constant',(9,4),
     (I(1,10000),I(1,10000)),
     lambda a,b:rf'Find the minimum of $\frac{{{a}x^2\sin^2 x+{b}}}{{x\sin x}}$ for $0<x<\pi$.',
     lambda a,b:2*isqrt(a*b),valid=lambda a,b:b<=a and is_square(a*b),
     sample=lambda r:(lambda n,m,k:(k*n*n,k*m*m))(n:=r.randint(1,20),r.randint(1,n),r.randint(1,20)),
     constraints=('The product of the coefficients is a square, and the constant is at most the quadratic coefficient.',))
