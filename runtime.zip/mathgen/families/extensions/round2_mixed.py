"""Additional prealgebra and precalculus source-ID bindings."""
from .round2_mixed_prealgebra import BINDINGS as PREALGEBRA
from .round2_mixed_linear import BINDINGS as LINEAR

from .round2_mixed_trig import BINDINGS as TRIG

BINDINGS = {
    **{'prealgebra/' + key: value for key, value in PREALGEBRA.items()},
    **{'precalculus/' + key: value for key, value in {**LINEAR, **TRIG}.items()},
}
IDS = tuple(BINDINGS)


def build(row):
    return BINDINGS.get(row['id'])
