"""Finite angle-state recurrences with exact independent field arithmetic."""
from fractions import Fraction as F
from functools import lru_cache
from .common import integer as I, choice, template
from .precalculus_trig import qmul,qinv
TANS=((F(0),F(0)),(F(2),F(-1)),(F(0),F(1,3)),(F(1),F(0)),
      (F(0),F(1)),(F(2),F(1)),None,(F(-2),F(-1)),(F(0),F(-1)),
      (F(-1),F(0)),(F(0),F(-1,3)),(F(-2),F(1)))
@lru_cache(None)
def phase_cycle(a,b):
    start=(a,b);values=[]
    for _ in range(145):
        if a==6 or b==6:return ()
        values.append(a);a,b=b,(a+b)%12
        if (a,b)==start:return tuple(values)
    raise AssertionError('There are only 144 invertible states modulo 12')
@lru_cache(None)
def safe_initials():
    return tuple((a,b) for a in range(12) for b in range(12) if (a,b)!=(0,0) and phase_cycle(a,b)
                 and any(x in (0,3,9) for x in phase_cycle(a,b)))
def fib(n):
    if n==0:return 0,1
    a,b=fib(n//2);c=a*(2*b-a)%12;d=(a*a+b*b)%12
    return (d,(c+d)%12) if n%2 else (c,d)
def target_phase(p):
    if p['n']==1:return p['first']
    a,b=fib(p['n']-2);return (p['first']*a+p['second']*b)%12
def sequence_valid(p):
    return (p['first'],p['second'])!=(0,0) and bool(phase_cycle(p['first'],p['second'])) and target_phase(p) in (0,3,9)
def sequence_sample(r):
    a,b=r.choice(safe_initials());cycle=phase_cycle(a,b)
    residues=[i+1 for i,x in enumerate(cycle) if x in (0,3,9)]
    offset=r.choice(residues);n=offset+len(cycle)*r.randint(0,(10000-offset)//len(cycle))
    return dict(first=a,second=b,n=n)
def sequence_reference(p):
    a,b=TANS[p['first']],TANS[p['second']];start=(a,b);values=[]
    for _ in range(145):
        values.append(a);product=qmul(a,b)
        value=qmul((a[0]+b[0],a[1]+b[1]),qinv((1-product[0],-product[1])))
        a,b=b,value
        if (a,b)==start:
            ans=values[(p['n']-1)%len(values)];assert ans[1]==0;return ans[0]
    raise AssertionError('Exact tangent orbit failed to close')
def root_power_reference(p):
    d=p['radicand'];root=(F(1),F(0)) if d==1 else (F(0),F(1))
    a,b=(F(1),F(0)),(F(0),F(0))
    for _ in range(p['exponent']):
        prod=(b[0]*root[0]+d*b[1]*root[1],b[0]*root[1]+b[1]*root[0])
        a,b=(-b[0],-b[1]),(a[0]+prod[0],a[1]+prod[1])
    assert b==(0,0) and a[1]==0
    return a[0]
def build(row):
    if row['id']=='precalculus/test/423':
        return template('extensions.precalculus.tangent_fibonacci_recurrence',
          {'first':I(0,11),'second':I(0,11),'n':I(1,10000)},dict(first=3,second=2,n=2009),
          lambda p:rf"Let $a_1=\tan({p['first']}\pi/12)$, $a_2=\tan({p['second']}\pi/12)$, and $a_{{j+2}}=(a_j+a_{{j+1}})/(1-a_ja_{{j+1}})$ for $j\ge1$. Find $a_{{{p['n']}}}$.",
          lambda p:{0:0,3:1,9:-1}[target_phase(p)],valid=sequence_valid,sample=sequence_sample,reference=sequence_reference,
          constraints=['The complete finite phase orbit modulo 12 avoids tangent poles. Initial terms are not both zero; the requested phase is 0,3 or9, giving a rational scalar.'],
          adaptation='Initial constants are written as equivalent exact tangents and their phases, as well as the requested index, can vary.')
    if row['id']=='precalculus/train/546':
        periods={1:3,2:4,3:6}
        return template('extensions.precalculus.quadratic_root_power',
          {'radicand':choice([1,2,3]),'exponent':I(1,120)},dict(radicand=3,exponent=18),
          lambda p:rf"For a nonzero complex number $x$ satisfying $x+1/x=\sqrt{{{p['radicand']}}}$, find $x^{{{p['exponent']}}}$.",
          lambda p:(-1)**(p['exponent']//periods[p['radicand']]),
          valid=lambda p:p['exponent']%periods[p['radicand']]==0,
          sample=lambda r:(lambda d:dict(radicand=d,exponent=periods[d]*r.randint(1,120//periods[d])))(r.choice([1,2,3])),
          reference=root_power_reference,
          constraints=['Exponent is a multiple of the half-order 3,4,6 for radicands1,2,3; both quadratic roots then give the same real answer.'],
          adaptation='The source implicitly requires complex x; that domain is now explicit.')
