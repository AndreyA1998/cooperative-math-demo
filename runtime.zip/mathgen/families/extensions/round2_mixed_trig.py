"""Additional exact precalculus trigonometry and complex-exponential bindings."""
from fractions import Fraction as Q
from itertools import product
from math import isqrt

from .common import choice, integers, is_square, sqrt_fraction
from .round2_mixed_prealgebra import PI_HI, PI_LO, add as _add

BINDINGS = {}


def add(key,*args,**kwargs):
    _add(key,*args,bindings=BINDINGS,**kwargs)


def unity_roots(re,im):
    rhs = f'{re}{im:+d}i' if im else str(re)
    return f'Let $u,v,w$ be the roots, counted with multiplicity, of $z^3={rhs}$. Find $uv+uw+vw$.'


add('test/119','vieta_cube_roots',{'rhs_real':(-20,20),'rhs_imaginary':(-20,20)},(1,0),
    unity_roots,lambda a,b:0)


def cis(angle):
    return rf'\cos({angle}^\circ)+i\sin({angle}^\circ)'


def cis_pair_valid(a,b,n):
    return a<b and (b-a)%360!=180 and n*(a+b)%360==0


def sample_cis_pair(r):
    n=r.randint(2,12)
    mid=r.choice([m for m in range(-120,121) if n*m%180==0])
    diff=r.randint(1,45)
    return mid-diff,mid+diff,n


add('test/268','imaginary_part_of_power_of_phasor_sum',
    {'first_angle_degrees':(-180,180),'second_angle_degrees':(-180,180),'exponent':(2,12)},(12,48,6),
    lambda a,b,n:rf'Find the imaginary part of $\bigl({cis(a)}+{cis(b)}\bigr)^{{{n}}}$.',
    lambda a,b,n:0,valid=cis_pair_valid,sample=sample_cis_pair,
    constraint='Angles increase, are not opposite, and the exponent times their sum is a multiple of 360 degrees.')


def root_product_prompt(a,b,es):
    factors=''.join(f'(a^{{{j}}}+b^{{{e}}})(a^{{{j}}}+b^{{{17-e}}})' for j,e in enumerate(es,1))
    return rf'Let $a=e^{{2\pi i({a})/5}}$ and $b=e^{{2\pi i({b})/17}}$. Compute ${factors}$.'


def exact_root_product(a,b,es):
    # Coefficients of a formal polynomial modulo x^5−1 and y^17−1.
    terms={(0,0):1}
    for j,e in enumerate(es,1):
        for power in (e,-e):
            expanded={}
            for (i,k),coeff in terms.items():
                for key in (((i+a*j)%5,k),(i,(k+b*power)%17)):
                    expanded[key]=expanded.get(key,0)+coeff
            terms=expanded
    # Eliminate x^4 and y^16 using the two prime cyclotomic polynomials.
    result = {}
    for i,k in product(range(4),range(16)):
        value=terms.get((i,k),0)-terms.get((4,k),0)-terms.get((i,16),0)+terms.get((4,16),0)
        if value:
            result[i,k]=value
    if set(result)-{(0,0)}:
        return None
    return result.get((0,0),0)


def sample_root_product(r):
    es=[1,2,8,4]
    es=[r.choice((e,17-e)) for e in es]
    return r.randint(1,4),r.randint(1,16),es


add('test/280','cyclotomic_product_exact_reduction',
    {'a_exponent_numerator':(1,4),'b_exponent_numerator':(1,16),'b_exponents':integers(4,1,16)},
    (2,1,[1,2,8,4]),root_product_prompt,exact_root_product,
    valid=lambda a,b,e:exact_root_product(a,b,e) is not None,
    sample=sample_root_product,constraint='The product reduces to a constant modulo the fifth and seventeenth cyclotomic polynomials.')


add('test/296','arctangent_sum_rational_slope',{'tangent_of_sum':(1,12)},(1,),
    lambda k:rf'If $\arctan x+\arctan y=\arctan {k}$, compute ${k}xy+x+y$.',
    lambda k:k,adaptation='Write π/4 as arctan(1) and allow other rational tangents of the sum.')


add('test/30','reciprocal_tangent_terms',{'tangent_squared_coefficient':(1,20)},(1,),
    lambda k:rf'Simplify $\frac1{{1-{k}\tan^2 x}}+\frac1{{1-\cot^2 x/{k}}}$, wherever both terms are defined.',
    lambda k:1,reference=lambda k:1/(1-Q(k,4))+1/(1-Q(4,k)) if k!=4 else 1/(1-Q(k,9))+1/(1-Q(9,k)))


# sin(theta) = sign * sqrt(square) for a catalog of exact special angles.
SPECIAL = {
    0:(0,0),30:(1,Q(1,4)),45:(1,Q(1,2)),60:(1,Q(3,4)),90:(1,1),
    120:(1,Q(3,4)),135:(1,Q(1,2)),150:(1,Q(1,4)),180:(0,0),
    210:(-1,Q(1,4)),225:(-1,Q(1,2)),240:(-1,Q(3,4)),270:(-1,1),
    300:(-1,Q(3,4)),315:(-1,Q(1,2)),330:(-1,Q(1,4)),
}


CONJUGATE_SINES = {
    15:(1,0), 165:(1,0), 195:(-1,0), 345:(-1,0),
    75:(1,1), 105:(1,1), 255:(-1,1), 285:(-1,1),
}


def reduced_sine_product(a,b):
    if a in SPECIAL and b in SPECIAL:
        s,qs=SPECIAL[a]
        t,qt=SPECIAL[b]
        return s*t*sqrt_fraction(qs*qt) if is_square(qs*qt) else None
    if a in CONJUGATE_SINES and b in CONJUGATE_SINES:
        s,u=CONJUGATE_SINES[a]
        t,v=CONJUGATE_SINES[b]
        if u!=v:
            return Q(s*t,4)
    if (a in SPECIAL and SPECIAL[a][0]==0) or (b in SPECIAL and SPECIAL[b][0]==0):
        if a in SPECIAL or a in CONJUGATE_SINES:
            if b in SPECIAL or b in CONJUGATE_SINES:
                return 0
    return None


def sine_product(a,b,c):
    return reduced_sine_product((a+b)%360,(a-c)%360)


SINE_PRODUCT_PAIRS = tuple((a,b) for a,b in product((*SPECIAL,*CONJUGATE_SINES),repeat=2)
                           if reduced_sine_product(a,b) is not None)


def sample_sine_product(r):
    a=r.randint(1700,2300)
    b,c=r.choice(SINE_PRODUCT_PAIRS)
    plus=(b-a)%360+r.randint(0,2)*360
    minus=a-c-360*r.randint(0,2)
    return a,plus,minus


add('test/321','product_of_two_exact_sines',
    {'common_angle':(1700,2300),'added_angle':(0,1079),'subtracted_angle':(600,2400)},(1998,237,1653),
    lambda a,b,c:rf'Evaluate $\sin(({a}+{b})^\circ)\sin(({a}-{c})^\circ)$.',sine_product,
    valid=lambda a,b,c:sine_product(a,b,c) is not None,sample=sample_sine_product,
    constraint='The two reduced angles are special angles and the product of their squared sines is a rational square.')


def tangent_product(angles):
    return 'Evaluate $'+r'\,'.join(rf'\tan {d}^\circ' for d in sorted(angles+[90-x for x in angles]))+'$.'


add('test/366','product_complementary_tangents',{'lower_angles':integers(4,1,44,min_length=2,max_length=8)},([10,20,30,40],),
    tangent_product,lambda a:1,valid=lambda a:len(a)==len(set(a)),
    sample=lambda r:(r.sample(range(1,45),r.randint(2,8)),),
    constraint='Distinct acute angles below 45 degrees. The product contains each angle and its complement.')


def angular_modes(n):
    return rf'An angular unit is defined so that {n} units equal a half-turn. The two least positive real values of $x$ for which the sine of $x$ units equals the sine of $x$ radians are $m\pi/(k-\pi)$ and $p\pi/(q+\pi)$, in some order, where $m,k,p,q$ are positive integers. Find $m+k+p+q$.'


add('test/397','sine_agreement_in_two_angular_modes',{'units_in_half_turn':(20,500)},(180,),
    angular_modes,lambda n:5*n,
    adaptation='Define the angular unit by its half-turn measure, with 180 units giving degrees.')


def rational_sine(angle):
    sign,value=SPECIAL.get(angle%360,(0,-1))
    return sign*sqrt_fraction(value) if is_square(value) else None


THIRD_ANGLES = choice(a for a in range(1,180) if rational_sine(3*a) not in (None,0))
add('test/398','triple_angle_sine_cosine_cancellation',{'angle_degrees':THIRD_ANGLES},(10,),
    lambda a:rf'Find $8\cos^2 {a}^\circ-\frac{{{2*rational_sine(3*a)}}}{{\sin {a}^\circ}}$.',
    lambda a:2,constraint='The sine of the triple angle is nonzero and rational.')


def cosine_product(a,b):
    s,qs=SPECIAL[(90-3*a)%360]
    t,qt=SPECIAL[(90-b)%360]
    return Q(s*t,4)*sqrt_fraction(qs*qt)


add('test/405','cosine_triple_product_identity',{'center_offset_degrees':choice((10,15,20,30,40,45,50,70,80)),'additional_angle_degrees':choice((0,30,45,60,90,120,135,150,180))},
    (10,30),lambda a,b:rf'Find $\cos {a}^\circ\cos {b}^\circ\cos {60-a}^\circ\cos {60+a}^\circ$.',cosine_product,
    valid=lambda a,b:is_square(SPECIAL[(90-3*a)%360][1]*SPECIAL[(90-b)%360][1]),
    constraint='The product of the squared cosines of the triple angle and additional angle is a rational square.')


add('test/443','sine_quadratic_cosine_expression',{'linear_sine_coefficient':(1,16)},(1,),
    lambda a:rf'If $\sin^2\theta+{a}\sin\theta=1$, find $\frac{{\cos^4\theta}}{{{a*a}}}+\cos^2\theta$.',
    lambda a:1)


add('test/502','triple_angle_sine_cancel_reciprocal',{'angle_degrees':THIRD_ANGLES},(10,),
    lambda a:rf'Compute $\frac{{{rational_sine(3*a)}}}{{\sin {a}^\circ}}-2\sin({90-2*a}^\circ)$.',
    lambda a:1,constraint='The sine of the triple angle is nonzero and rational.')


for key,kind,src in [('test/516','cos',90),('train/220','sin',0)]:
    add(key,'principal_inverse_trig_pi_coefficient',{'input':choice(str(rational_sine(a)) for a in (0,30,90))},(str(rational_sine(src)),),
        lambda v,k=kind:rf'Compute $\arc{k}({v})$ in radians. Give the coefficient of $\pi$ in the answer.',
        lambda v,k=kind:(Q(1,2) if k=='cos' else Q(0))- (1 if k=='cos' else -1)*{'0':Q(0),'1/2':Q(1,6),'1':Q(1,2)}[v],
        adaptation='Report the coefficient of π in the principal radian value to allow nonzero exact scalar answers.')


def triangle_first_side(d,e):
    disc=(d+2*e)**2+4*(d+e)**2
    return (d+2*e+isqrt(disc))//2 if is_square(disc) else None


def triangle_sides_valid(d,e):
    a=triangle_first_side(d,e)
    return a is not None and a>e


add('train/16','triangle_angle_double_with_side_gaps',{'first_gap':(1,100),'second_gap':(1,100)},(1,1),
    lambda a,b:f'A triangle has integer side lengths in increasing order. The second side is {a} more than the first, and the third is {b} more than the second. The largest angle is twice the smallest angle. Find the cosine of the smallest angle.',
    lambda a,b:Q(triangle_first_side(a,b)+a+b,2*triangle_first_side(a,b)),
    valid=triangle_sides_valid,constraint='The positive root of the side equation is an integer and the triangle inequalities hold.',
    reference=lambda d,e:(lambda a,b,c:Q(b*b+c*c-a*a,2*b*c))(triangle_first_side(d,e),triangle_first_side(d,e)+d,triangle_first_side(d,e)+d+e),
    adaptation='Parameterize the two successive side differences, both one for the source.')


add('train/165','cotangent_difference_at_median',
    {'tangent_numerator':(1,25),'tangent_denominator':(1,25)},(1,1),
    lambda a,b:rf'In triangle $ABC$, let $AD$ be the median to $BC$. The smaller angle between the lines $AD$ and $BC$ has tangent ${Q(a,b)}$. Find $|\cot B-\cot C|$.',
    lambda a,b:Q(2*b,a),adaptation='Specify the acute line angle by its tangent, with tangent 1 at the source.')


add('train/252','nested_inverse_trig_unique_positive_solution',{'inside_multiplier':(1,12),'right_multiplier':(1,12)},(1,1),
    lambda a,b:rf'How many positive real solutions does $\sin(\arccos({a}\tan(\arcsin x)))={b}x$ have?',
    lambda a,b:1)


add('train/273','floor_first_root_trig_sum',{'sine_coefficient':(1,12),'cosine_coefficient':(1,12),'tangent_coefficient':(2,35)},(1,2,3),
    lambda a,b,c:rf'Let $f(x)={a}\sin x+{b}\cos x+{c}\tan x$ for real $x$ in radians. Let $r$ be its smallest positive zero. Find $\lfloor r\rfloor$.',
    lambda a,b,c:3,valid=lambda a,b,c:c>=a+b,
    constraint='The tangent coefficient is at least the sum of the two other positive coefficients.')


def doubling_sines(n,a):
    angles = [(90-2**j*a)%180 for j in range(n)]
    return tuple(sorted(min(t,180-t) for t in angles))


DOUBLING_PRODUCTS = tuple(sorted({
    doubling_sines(n,a)
    for n in range(3,10) for a in range(1,180)
    if 0 not in doubling_sines(n,a) and any((2**n+s)*a%180==0 for s in (-1,1))
}))
DOUBLING_PRODUCTS_SET = set(DOUBLING_PRODUCTS)


def doubling_prompt(angles):
    return 'Compute $'+r'\,'.join(rf'\sin({d}^\circ)' for d in angles)+'$.'


add('train/314','sine_product_from_repeated_double_angle',
    {'angles_degrees':integers(4,1,90,min_length=3,max_length=9)},([6,42,66,78],),
    doubling_prompt,lambda a:Q(1,2**len(a)),valid=lambda a:tuple(sorted(a)) in DOUBLING_PRODUCTS_SET,
    sample=lambda r:(list(r.choice(DOUBLING_PRODUCTS)),),
    constraint='The acute sines are the absolute cosine factors in a doubling chain for some integer initial angle a, with (2^n±1)a divisible by 180.')


def dirichlet_prompt(m):
    d=8*m+6
    terms='+'.join(rf'\cos\frac{{{4*j}\pi}}{{{d}}}' for j in range(1,m+1))
    return rf'Compute $\csc\frac{{\pi}}{{{d}}}-4\left({terms}\right)$.'


add('train/361','cosecant_minus_cosine_series',{'number_of_cosine_terms':(1,12)},(1,),dirichlet_prompt,lambda m:2,
    adaptation='Extend the single cosine to the finite Dirichlet cosine sum whose one-term case is the source.')


def sine_rule_valid(q,r,radicand):
    p=180-q-r
    return p in SPECIAL and 0<p<180 and is_square(radicand*SPECIAL[p][1]/Q(SPECIAL[q][1]))


def sine_rule_answer(q,r,radicand):
    return sqrt_fraction(radicand*SPECIAL[180-q-r][1]/Q(SPECIAL[q][1]))


def sample_sine_rule(rng):
    q,r=rng.choice([(q,r) for q,r in product((30,45,60,90,120,135,150),(15,30,45,60,75,90,105,120,135)) if 180-q-r in SPECIAL and 0<180-q-r<180])
    scale=rng.randint(1,12)
    ratio=Q(SPECIAL[q][1])/Q(SPECIAL[180-q-r][1])
    return q,r,ratio.numerator*ratio.denominator*scale**2


add('train/387','law_of_sines_exact_side',
    {'angle_q_degrees':choice((30,45,60,90,120,135,150)),'angle_r_degrees':(15,135),'pr_squared':(1,2000)},(30,105,32),
    lambda q,r,s:rf'In triangle $PQR$, $\angle Q={q}^\circ$, $\angle R={r}^\circ$, and $PR=\sqrt{{{s}}}$. Find $QR$.',
    sine_rule_answer,valid=sine_rule_valid,sample=sample_sine_rule,
    constraint='The remaining angle is a special acute or obtuse angle and the sine rule gives a rational side length.')


add('train/453','vieta_equal_length_root_rays',
    {'included_angle_degrees':choice((60,90,120))},(60,),
    lambda a:rf'Let $z_1,z_2$ be the roots of $z^2+az+b=0$. The triangle with vertices $0,z_1,z_2$ has equal sides from $0$ and an included angle of ${a}^\circ$. Find $a^2/b$.',
    lambda a:{60:3,90:2,120:1}[a],
    adaptation='Specify the apex angle of the isosceles triangle explicitly, with 60 degrees making it equilateral at the source.')


Pell = choice(k for k in range(2,10001) if (k*k-k+1)%3==0 and is_square((k*k-k+1)//3))
add('train/535','inverse_cosine_difference_rational_root',{'argument_multiplier':Pell},(2,),
    lambda k:rf'Solve $\arccos({k}x)-\arccos x=\pi/3$ for real $x$. Enter all solutions.',
    lambda k:Q(-1,2*isqrt((k*k-k+1)//3)),
    constraint='k is at least 2 and k²−k+1 is three times a square.')


def certified_sine_lobe_count(n):
    k=n//(2*PI_HI)
    if 2*(k+1)*PI_LO<n or Q(4*k+1,2)*PI_HI>=n:
        return None
    return 4*k+3


add('train/741','count_intersections_of_line_and_sine',
    {'denominator':choice(n for n in range(2,401) if certified_sine_lobe_count(n) is not None)},(100,),
    lambda n:rf'Find the number of real solutions of $x/{n}=\sin x$.',
    certified_sine_lobe_count,
    constraint='Every positive sine lobe starting below the denominator has its midpoint below it. Rational bounds on π certify both tests.')

def shifted_cotangent_square(k):
    if k==0:
        return r'Simplify $\frac{\csc\theta}{\sin\theta}-\frac{\cot\theta}{\tan\theta}$ wherever defined.'
    return rf'Simplify $\frac{{\csc\theta}}{{\sin\theta}}-(\cot\theta+{k})(1/\tan\theta-{k})$ wherever defined.'


add('test/176','cosecant_minus_cotangent_square',{'cotangent_shift':(0,12)},(0,),
    shifted_cotangent_square,lambda k:1+k*k,
    reference=lambda k:1+Q(4,9)-(Q(2,3)+k)*(Q(2,3)-k))


add('test/364','ratio_of_trig_power_defects',{'numerator_power':choice((4,6)),'denominator_power':choice((4,6))},(4,6),
    lambda a,b:rf'Simplify $\frac{{\sin^{a}x+\cos^{a}x-1}}{{\sin^{b}x+\cos^{b}x-1}}$ wherever defined.',
    lambda a,b:Q(a,b),
    reference=lambda a,b:(Q(1,4)**(a//2)+Q(3,4)**(a//2)-1)/(Q(1,4)**(b//2)+Q(3,4)**(b//2)-1))


GOLDEN_SINES={18:(-1,1),162:(-1,1),54:(1,1),126:(1,1),198:(1,-1),342:(1,-1),234:(-1,-1),306:(-1,-1)}
def rational_sine_cubic(a,k):
    if a in GOLDEN_SINES:
        u,v=GOLDEN_SINES[a]
        # s=(u+v*sqrt(5))/4. The irrational coefficient cancels when k=-u.
        return Q(u**3+15*u+4*k*(u*u+5),64) if k==-u else None
    value=rational_sine(a)
    return value**3+k*value**2 if value is not None else None


add('test/407','sine_cubic_with_rational_reduction',
    {'angle_degrees':choice(sorted({*SPECIAL,*GOLDEN_SINES})),'square_coefficient':(-8,8)},(18,1),
    lambda a,k:rf'Compute $\sin^3 {a}^\circ {k:+d}\sin^2 {a}^\circ$.',
    rational_sine_cubic,valid=lambda a,k:rational_sine_cubic(a,k) is not None,
    constraint='The sine is rational, or the squared-term coefficient cancels the irrational part of the golden-ratio sine cube.')


def inverse_sine_pair(a):
    if 2*a in GOLDEN_SINES:
        u,v=GOLDEN_SINES[2*a]
        return -u,v
    s=rational_sine(2*a)
    return (1/s,0) if s else None


def reciprocal_sine_difference(a,b):
    u,v=inverse_sine_pair(a),inverse_sine_pair(b)
    return 2*(u[0]-v[0]) if u and v and u[1]==v[1] else None


add('test/506','difference_of_tangent_cotangent_sums',{'first_angle_degrees':(1,89),'second_angle_degrees':(1,89)},(9,27),
    lambda a,b:rf'Simplify $\tan {a}^\circ+\cot {a}^\circ-\tan {b}^\circ-\cot {b}^\circ$.',
    reciprocal_sine_difference,valid=lambda a,b:a!=b and reciprocal_sine_difference(a,b) is not None,
    constraint='Angles differ and the doubled-angle cosecants are rational or have the same irrational part.')


def mixed_secant_cosecant(a):
    coefficients={20:r'-\sqrt3',40:r'+\sqrt3',60:'',80:r'-\sqrt3'}
    term=rf'\frac{{1}}{{\cos {a}^\circ}}'
    if coefficients[a]:
        term+=coefficients[a][0]+rf'\frac{{{coefficients[a][1:]}}}{{\sin {a}^\circ}}'
    return f'Compute ${term}$.'


add('train/271','reciprocal_trig_with_triple_angle_relation',{'angle_degrees':choice((20,40,60,80))},(80,),
    mixed_secant_cosecant,lambda a:{20:-4,40:4,60:2,80:4}[a])


GOLDEN_COSINES={36:(Q(1,4),1),72:(Q(-1,4),1),108:(Q(1,4),-1),144:(Q(-1,4),-1)}
COSINE_VALUES={**GOLDEN_COSINES,**{a:(rational_sine(90-a),0) for a in (0,60,90,120,180)}}
def exact_cosine_difference(a,b):
    u,v=COSINE_VALUES[a],COSINE_VALUES[b]
    return u[0]-v[0] if u[1]==v[1] else None


add('train/357','difference_of_exact_cosines',{'first_angle_degrees':choice(COSINE_VALUES),'second_angle_degrees':choice(COSINE_VALUES)},(36,72),
    lambda a,b:rf'Simplify $\cos {a}^\circ-\cos {b}^\circ$.',
    exact_cosine_difference,valid=lambda a,b:a!=b and exact_cosine_difference(a,b) is not None,
    constraint='The angles differ and their cosines have the same irrational part.')


add('train/451','harmonics_of_three_balanced_unit_vectors',{'harmonic':choice(n for n in range(1,45) if n%3)},(2,),
    lambda n:rf'Let $x,y,z$ satisfy $\cos x+\cos y+\cos z=\sin x+\sin y+\sin z=0$. Find the sum of all possible values of $\cos {n}x+\cos {n}y+\cos {n}z$.',
    lambda n:0,constraint='The harmonic is not divisible by three.')


add('train/706','geometric_sequence_trig_power_relation',{'tangent_coefficient':(1,15)},(1,),
    lambda k:rf'If $\sin x,\cos x,{k}\tan x$ form a geometric sequence in this order, find $\cot^6 x-{k*k}\cot^2 x$.',
    lambda k:k*k,constraint='The positive tangent coefficient permits a nonzero geometric sequence.')


def triangle_cotangent_det(a):
    mat=r'\begin{vmatrix}\sin^2 A & \cot A & 1\\\sin^2 B & \cot B & 1\\\sin^2 C & \cot C & 1\end{vmatrix}'
    given=''
    if a!='A':
        given=f' with $A={a}^\\circ$'
        mat=mat.replace(' A',rf'({a}^\circ)')
    return f'Let $A,B,C$ be the angles of a triangle{given}. Evaluate ${mat}$.'


add('train/742','triangle_sine_squared_cotangent_determinant',{'first_angle':choice(['A',*(str(n) for n in range(1,180))])},('A',),
    triangle_cotangent_det,lambda a:0,
    adaptation='Leave the first angle arbitrary at the source instance and give its measure in generated variants.')
