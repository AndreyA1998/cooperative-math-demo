"""Coordinate geometry with public coordinates and bounded integral-distance draws."""
from fractions import Fraction as F
from math import isqrt

from .round3_algebra_test_common import bind


def distance2(x, y, u, v):
    return (x-u)**2+(y-v)**2


def square(n):
    return isqrt(n)**2 == n


def leg_pair(rng):
    m = rng.randint(2, 10)
    n = rng.randint(1, m-1)
    return m*m-n*n, 2*m*n


def segment_draw(rng):
    x, y = (rng.randint(-80, 80) for _ in range(2))
    dx, dy = leg_pair(rng)
    if rng.randrange(2):
        dx, dy = dy, dx
    return x, y, x+rng.choice((-dx, dx)), y+rng.choice((-dy, dy))


def length_oracle(d):
    return next(n for n in range(1, d+1) if n*n == d)


def triangle_draw(rng):
    x, y, u, v = segment_draw(rng)
    return x, y, u, v, (x+u)//2, (y+v)//2+1


def area2(x,y,u,v,j,k):
    return (u-x)*(k-y)-(v-y)*(j-x)


def build(row, index):
    originals = {269: (-4,1,1,13), 619: (1,2,-4,-10), 1156: (-3,7,2,-5),
                 796: (7,9,10,2), 934: (7,-6,-3,-4)}
    if index in originals:
        x,y,u,v = originals[index]
        def first(x,y,u,v):
            return f'({x}, {y})' if index == 934 else f'({x},{y})'

        def second(x,y,u,v):
            return f'({u}, {v})' if index == 934 else f'({u},{v})'

        fragments = [(first(x,y,u,v),first), (second(x,y,u,v),second)]
        domains = {name:(-200,200) for name in ('first_x','first_y','second_x','second_y')}
        if index in (269,619,1156):
            return bind(row,'segment_length',domains,(x,y,u,v),fragments,
                        lambda *p:isqrt(distance2(*p)),
                        valid=lambda *p:distance2(*p)>0 and square(distance2(*p)),
                        sample=segment_draw,
                        reference=lambda *p:length_oracle(distance2(*p)),
                        constraints=['Endpoints are distinct and their squared distance is a perfect square.'])
        solve = (lambda x,y,u,v:y+v) if index==796 else (lambda x,y,u,v:F(x+y+u+v,2))
        return bind(row,'diagonal_midpoint',domains,(x,y,u,v),fragments,solve,
                    valid=lambda *p:distance2(*p)>0, constraints=['The endpoints are distinct.'])
    if index == 276:
        return bind(row,'segment_interpolation',dict(endpoint_x=(-200,200), endpoint_y=(-200,200),
                    numerator=(1,50), denominator=(2,100)),(9,6,1,3),
                    [('(9, 6)',lambda x,y,a,b:f'({x}, {y})'),
                     (r'\frac{1}{3}',lambda x,y,a,b:fr'\frac{{{a}}}{{{b}}}')],
                    lambda x,y,a,b:F(a*(x+y),b), valid=lambda x,y,a,b:(x!=0 or y!=0) and a<b,
                    constraints=['The endpoint differs from the origin and the fraction is strictly between zero and one.'],
                    reference=lambda x,y,a,b:F(a*x,b)+F(a*y,b))
    if index in (279,344):
        original = (4,3,6,1,1,7) if index==279 else (11,1,2,3,3,7)
        fragments = [
            (f'({original[2*i]},{original[2*i+1]})', lambda *p,i=i:f'({p[2*i]},{p[2*i+1]})')
            for i in range(3)
        ]

        def distances(x,y,u,v,j,k):
            pair = (distance2(x,y,u,v),distance2(x,y,j,k))
            return pair if index==279 else pair+(distance2(u,v,j,k),)

        def valid(*p):
            ds = distances(*p)
            distinct = (p[2],p[3])!=(p[4],p[5])
            geometric = ds[0]!=ds[1] and distinct if index==279 else area2(*p)!=0
            return geometric and min(ds)>0 and square(max(ds))

        return bind(row,'coordinate_longest_distance',
                    {name:(-200,200) for name in ('first_x','first_y','second_x','second_y','third_x','third_y')},
                    original,fragments,lambda *p:isqrt(max(distances(*p))), valid=valid,
                    sample=triangle_draw, reference=lambda *p:length_oracle(max(distances(*p))),
                    constraints=['The farthest distance is integral; the people are distinct with unequal distances, or the triangle is noncollinear, as applicable.'])
    if index == 527:
        def valid(x,y,u,v):
            return x!=u and y!=v and square(distance2(x,y,u,v))

        return bind(row,'axis_aligned_triangle_perimeter',
                    {name:(-200,200) for name in ('a_x','a_y','c_x','c_y')},(-6,6,9,-2),
                    [('A(-6,6), B(9,6)',lambda x,y,u,v:f'A({x},{y}), B({u},{y})'),
                     ('C(9,-2)',lambda x,y,u,v:f'C({u},{v})')],
                    lambda x,y,u,v:abs(x-u)+abs(y-v)+isqrt(distance2(x,y,u,v)),
                    valid=valid, sample=segment_draw,
                    reference=lambda x,y,u,v:abs(x-u)+abs(y-v)+length_oracle(distance2(x,y,u,v)),
                    constraints=['Both perpendicular legs are nonzero and the hypotenuse is integral.'])
    if index == 1159:
        return bind(row,'circle_center',dict(x_linear=(1,150),y_linear=(1,150)),(6,8),
                    [('6x',lambda x,y:f'{x}x'),('8y',lambda x,y:f'{y}y')],
                    lambda x,y:-F(x+y,2))
