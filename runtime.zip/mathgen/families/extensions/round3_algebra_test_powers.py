"""Exact radicals, exponent equations, and convergent nested expressions."""
from fractions import Fraction as F
from math import isqrt

from .round3_algebra_test_common import bind


def integral_root(value, degree):
    """Floor of a nonnegative integer's degree-th root."""
    lo, hi = 0, 1 << ((value.bit_length()+degree-1)//degree)
    while lo < hi:
        middle = (lo+hi+1)//2
        if middle**degree <= value:
            lo = middle
        else:
            hi = middle-1
    return lo


def integral_log(base, power):
    if power < 1:
        return None
    exponent = 0
    while power > 1:
        power, remainder = divmod(power,base)
        if remainder:
            return None
        exponent += 1
    return exponent


def build(row,index):
    def make(*args,**kwargs):
        return bind(row,*args,**kwargs)

    if index == 17:
        def solve(n,d,r):
            square_factor = next(k for k in range(isqrt(r),0,-1) if r%(k*k)==0)
            squarefree = r//square_factor**2
            ratio = F(n,d*square_factor*squarefree)
            return ratio.numerator+ratio.denominator+squarefree

        return make('radical_fraction_normal_form',dict(numerator=(1,150),coefficient=(1,150),radicand=(1,500)),
                    (9,2,3),[(r'9}{2\sqrt{3}',lambda n,d,r:fr'{n}}}{{{d}\sqrt{{{r}}}')],
                    solve)
    if index == 22:
        def solve(b,n,d):
            quotient=F((b-1)*b**n,d)
            return integral_log(b,quotient.numerator) if quotient.denominator==1 else None

        def sample(rng):
            b=rng.randint(2,40)
            n=rng.randint(1,15)
            return b,n,(b-1)*b**rng.randint(0,min(n,3))

        return make('difference_of_consecutive_powers',dict(base=(2,40),lower_exponent=(1,15),divisor=(1,3000000)),
                    (17,5,16),[(r'(17^6-17^5)\div16=17^x',lambda b,n,d:
                                 fr'({b}^{n+1}-{b}^{n})\div{d}={b}^x' if n<9 else
                                 fr'({b}^{{{n+1}}}-{b}^{{{n}}})\div{d}={b}^x')],
                    solve,valid=lambda b,n,d:solve(b,n,d) is not None,sample=sample,
                    constraints=['The quotient of the difference by the divisor is a nonnegative integer power of the base.'])
    if index == 329:
        def radicand(b,n,count):
            return count*b**n

        return make('cube_root_of_repeated_powers',dict(base=(2,30),exponent=(1,20),term_count=(2,12)),
                    (4,5,4), [('4^5+4^5+4^5+4^5',lambda b,n,k:'+'.join(
                        (f'{b}^{n}' if n<10 else f'{b}^{{{n}}}',)*k))],
                    lambda *p:integral_root(radicand(*p),3),
                    valid=lambda *p:integral_root(radicand(*p),3)**3==radicand(*p),
                    sample=cube_sum_draw,
                    constraints=['The sum under the radical is an exact cube.'])
    if index == 413:
        return make('nested_subtraction_radical',dict(radicand=(2,1001000)),(12,),
                    [('12-',lambda n:f'{n}-'),('12-',lambda n:f'{n}-'),('12-',lambda n:f'{n}-')],
                    lambda n:(isqrt(1+4*n)-1)//2,
                    valid=lambda n:isqrt(1+4*n)**2==1+4*n,
                    sample=lambda rng:((k:=rng.randint(1,1000))*(k+1),),
                    constraints=['The radicand is a product of two consecutive positive integers.'],
                    reference=lambda n:next(k for k in range(1,1001) if k*k+k==n))
    if index == 435:
        def draw(rng):
            b=rng.randint(2,12)
            k=rng.randint(2,5)
            e=rng.randint(1,5)
            return k*e,b**k,e

        return make('radical_of_power',dict(index=(2,25),base=(2,250000),exponent=(1,20)),
                    (12,8,4),[(r'\sqrt[12]{8^4}',lambda k,b,e:r'\sqrt[12]{8^4}' if (k,b,e)==(12,8,4)
                               else fr'\sqrt[{k}]{{{b}^{{{e}}}}}')],
                    lambda k,b,e:integral_root(b**e,k),
                    valid=lambda k,b,e:integral_root(b**e,k)**k==b**e,sample=draw,
                    constraints=['The radicand is an exact power of the given root index.'])
    if index == 488:
        factor = lambda a,n: 'x' if a==1 else f'{a}x'
        return make('nested_product_radical',dict(multiplier=(1,200),limit=(1,1000)),(1,3),
                    [(r'x\cdot',lambda a,n:factor(a,n)+r'\cdot')]*3+
                    [(r'x\cdots',lambda a,n:factor(a,n)+r'\cdots'),
                     ('}}=3',lambda a,n:f'}}}}={n}')],
                    lambda a,n:F(n,a),
                    constraints=['A positive nested-radical limit equals the repeated positive factor.'])
    if index == 613:
        def choices(a,b,rhs):
            return [x for x in range(1,13) if 1+a**x+b**x==rhs]

        return make('sum_of_exponential_terms',dict(first_base=(2,24),second_base=(2,24),rhs=(1,2*24**12+1)),
                    (2,5,642),[('2^x + 5^x = 642',lambda a,b,c:f'{a}^x + {b}^x = {c}')],
                    lambda a,b,c:choices(a,b,c)[0],
                    valid=lambda a,b,c:a!=b and bool(choices(a,b,c)),
                    sample=lambda rng:exponential_sum_draw(rng),
                    constraints=['The bases are distinct and the right side equals the sum of powers for some exponent 1 through 12.'])
    if index == 674:
        def coefficients(a,b,c):
            r = next(k for k in range(isqrt(a),0,-1) if a%(k*k)==0)
            d = a//(r*r)
            if b%d or c%d:
                return None
            s,t=isqrt(b//d),isqrt(c//d)
            return (d,d*(r+s+t)) if s*s==b//d and t*t==c//d else None

        return make('rationalize_like_radicals',dict(first=(1,20000),second=(1,20000),third=(1,20000)),
                    (2,8,32),[(r'\sqrt{2}+\sqrt{8}+\sqrt{32}',lambda a,b,c:
                               fr'\sqrt{{{a}}}+\sqrt{{{b}}}+\sqrt{{{c}}}')],
                    lambda *p:sum(coefficients(*p)),valid=lambda *p:coefficients(*p) is not None,
                    sample=lambda rng:like_radicals_draw(rng),
                    constraints=['All three radicands have the same squarefree part; the denominator of the final expression is positive.'])
    if index == 845:
        def solve(a,b,c,d):
            radicand=F(d*d,a*b*c)
            numerator,denominator=(integral_root(n,3) for n in (radicand.numerator,radicand.denominator))
            if numerator**3==radicand.numerator and denominator**3==radicand.denominator:
                return F(numerator,denominator)
            return None

        return make('product_of_three_radicals',dict(first=(1,200),second=(1,200),third=(1,200),rhs=(1,2000000)),
                    (5,10,18,30),[(r'\sqrt{5x}\cdot\sqrt{10x}\cdot\sqrt{18x}=30',lambda a,b,c,d:
                                   fr'\sqrt{{{a}x}}\cdot\sqrt{{{b}x}}\cdot\sqrt{{{c}x}}={d}')],
                    solve,valid=lambda *p:solve(*p) is not None,
                    sample=lambda rng:radical_product_draw(rng),
                    reference=radical_product_oracle,
                    constraints=['The quotient of the squared right side by the product of radicand coefficients is a rational cube.'])
    if index == 1082:
        def solve(base,first,second):
            a=integral_log(base,first)
            if a is None or a<2:
                return None
            b=integral_log(a,second)
            return b**a if b is not None else None

        return make('two_exponential_equations',dict(base=(2,20),first_rhs=(4,20**12),second_rhs=(1,12**10)),
                    (2,32,125),[('2^a = 32',lambda b,u,v:f'{b}^a = {u}'),
                                ('a^b = 125',lambda b,u,v:f'a^b = {v}')],
                    solve,valid=lambda *p:solve(*p) is not None,
                    sample=lambda rng:log_chain_draw(rng),
                    constraints=['The first right side is an integral power of the base with exponent at least two; the second is a nonnegative integral power of that exponent.'])
    if index == 1181:
        def valid(a,b):
            delta=a*a-4*b
            return delta>=0 and isqrt(delta)**2==delta

        def sample(rng):
            x=rng.randint(1,50)
            y=rng.randint(x,100-x)
            return x+y,x*y

        return make('convergent_subtractive_fraction',dict(denominator_constant=(2,100),numerator=(1,2500)),
                    (2,1),[(r'\frac{1}{2-',lambda a,b:fr'\frac{{{b}}}{{{a}-')]*3,
                    lambda a,b:F(a-isqrt(a*a-4*b),2),valid=valid,sample=sample,
                    constraints=['The discriminant is a nonnegative perfect square; the usual finite truncations converge to the smaller fixed point.'])
    if index == 1185:
        def rendered(a,b):
            n='x' if b==1 else f'{b}x'
            return fr'{a} + \frac{{{n}}}{{{a} + \frac{{{n}}}{{{a}+ \frac{{{n}}}{{{a} + \cdots}}}}}}'

        return make('self_referential_positive_fraction',dict(denominator_constant=(1,150),numerator_coefficient=(1,150)),
                    (1,1),[(rendered(1,1),rendered)],
                    lambda a,b:a+b,
                    constraints=['The infinite continued fraction is evaluated by the limit of finite truncations.'])


def exponential_sum_draw(rng):
    a,b=rng.sample(range(2,25),2)
    x=rng.randint(1,12)
    return a,b,1+a**x+b**x


def like_radicals_draw(rng):
    d=rng.choice((1,2,3,5,6,7,10,11,13,14,15,17,19))
    return tuple(d*rng.randint(1,30)**2 for _ in range(3))


def radical_product_draw(rng):
    a,b,c=(rng.randint(1,12) for _ in range(3))
    t=rng.randint(1,18)
    return a*a,b*b,c*c,a*b*c*t**3


def radical_product_oracle(a,b,c,d):
    def root_via_prime_factors(n):
        result=1
        factor=2
        while factor*factor<=n:
            exponent=0
            while n%factor==0:
                n//=factor
                exponent+=1
            if exponent%3:
                raise ValueError('Expected a cube')
            result*=factor**(exponent//3)
            factor+=1
        if n!=1:
            raise ValueError('Expected a cube')
        return result

    cube=F(d*d,a*b*c)
    return F(root_via_prime_factors(cube.numerator),root_via_prime_factors(cube.denominator))


def log_chain_draw(rng):
    base=rng.randint(2,20)
    a=rng.randint(2,12)
    b=rng.randint(0,10)
    return base,base**a,a**b


def cube_sum_draw(rng):
    if rng.randrange(2):
        return rng.randint(2,30),3*rng.randint(1,6),8
    base=rng.randint(2,12)
    return base,3*rng.randint(0,6)+2,base
