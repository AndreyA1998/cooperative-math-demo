"""Attained algebraic extrema with exact feasibility and equality conditions."""
from fractions import Fraction
from math import ceil, comb, floor, prod

from mathgen.families.algebra import _tex, _tex_polynomial

from .common import choice, draw, integer, integers, is_square, sqrt_fraction, template


RATIONAL = {"type": "rational", "min": 0, "max": 10**12}


def _exact_integer_root(n, degree):
    lo, hi = 0, 1 << ((n.bit_length() + degree - 1) // degree)
    while lo <= hi:
        mid = (lo + hi) // 2
        power = mid**degree
        if power == n:
            return mid
        if power < n:
            lo = mid + 1
        else:
            hi = mid - 1
    raise ValueError("expected a perfect power")


def rational_root(x, degree):
    value = Fraction(x)
    if value < 0:
        raise ValueError("expected a nonnegative radicand")
    return Fraction(_exact_integer_root(value.numerator, degree),
                    _exact_integer_root(value.denominator, degree))


def _positive_exact(function):
    def valid(p):
        try:
            return function(p) > 0
        except (ValueError, ArithmeticError):
            return False
    return valid


def _weighted_amgm(key):
    originals = {
        "intermediate_algebra/train/6": ("product", 8, [1, 2, 4]),
        "intermediate_algebra/train/714": ("cycle", 1, [2, 4, 8]),
        "intermediate_algebra/train/1033": ("cycle", 1, [1, 1, 1]),
        "intermediate_algebra/test/200": ("cubes", 1, [1, 2, 4]),
    }
    mode, fixed, weights = originals[key]
    domains = {"a": integer(1, 20), "b": integer(1, 20), "c": RATIONAL}
    original = dict(zip(("a", "b", "c"), weights))
    if mode == "product":
        domains["xyz"] = RATIONAL
        original["xyz"] = fixed

    def product_of_terms(p):
        scale = Fraction(p["a"]) * p["b"] * Fraction(p["c"])
        if mode == "cycle":
            return 1 / scale
        if mode == "product":
            return scale * Fraction(p["xyz"])
        return scale

    def solve(p):
        return 3 * rational_root(product_of_terms(p), 3)

    def sample(rng):
        a, b, k = (rng.randint(1, 12) for _ in range(3))
        if mode == "product":
            c = rng.randint(1, 12)
            return {"a": a, "b": b, "c": c, "xyz": str(Fraction(k**3, a*b*c))}
        return {"a": a, "b": b, "c": str(Fraction(k**3, a*b))}

    def valid(p):
        return Fraction(p["c"]) > 0 and ("xyz" not in p or Fraction(p["xyz"]) > 0) and _positive_exact(solve)(p)

    def render(p):
        a, b, c = p["a"], p["b"], _tex(Fraction(p["c"]))
        if mode == "product":
            product_text = _tex(Fraction(p["xyz"]))
            return f"If $x,y,z>0$ and $xyz={product_text}$, find the minimum of ${a}x+{b}y+{c}z$."
        if mode == "cycle":
            query = r"\frac{x}{%d y}+\frac{y}{%d z}+\frac{z}{%s x}" % (a, b, c)
        else:
            query = r"\frac{%d x^3+%d y^3+%s z^3}{xyz}" % (a, b, c)
        return f"For positive real $x,y,z$, find the minimum of ${query}$."

    return template(
        "extensions.algebra.weighted_amgm_three_terms", domains, original, render, solve,
        valid=valid, sample=sample,
        constraints=("All weights and any stated product are positive. The product of the three AM–GM terms is a rational cube.",),
        adaptation="Allow the positive weights to vary independently subject to rational exactness.",
    )


POSITIVE_POWERS = {
    "intermediate_algebra/train/50": (4, 1, 1, 4, False),
    "intermediate_algebra/train/520": (2, 1, 1, 2, True),
    "intermediate_algebra/train/917": (4, 5, 5, 4, False),
}


def _opposite_powers(key):
    a, b, up, down, sqrt_substitution = POSITIVE_POWERS[key]
    domains = {"a": integer(1, 20), "b": RATIONAL,
               "up": choice([1]) if up == 1 else integer(1, 7),
               "down": choice([2]) if sqrt_substitution else integer(1, 7)}
    original = {"a": a, "b": b, "up": up, "down": down}

    def critical(p):
        a, b, up, down = p["a"], Fraction(p["b"]), p["up"], p["down"]
        return rational_root(b * down / (a * up), up + down)

    def solve(p):
        point = critical(p)
        return p["a"] * point**p["up"] + Fraction(p["b"]) / point**p["down"]

    def reference(p):
        # At the attained weighted AM–GM equality, A*x^m and B/x^n
        # are proportional to n and m, respectively.
        m, n = p["up"], p["down"]
        a, b = Fraction(p["a"], n), Fraction(p["b"]) / m
        return (m + n) * rational_root(a**n * b**m, m+n)

    def sample(rng):
        m, n = draw(rng, domains["up"]), draw(rng, domains["down"])
        point = Fraction(rng.randint(1, 7), rng.randint(1, 5))
        a = rng.randint(1, 15)
        b = Fraction(a*m, n) * point**(m+n)
        return {"a": a, "b": str(b), "up": m, "down": n}

    def render(p):
        if sqrt_substitution:
            expression = r"%d\sqrt{x}+\frac{%s}{x}" % (p["a"], _tex(Fraction(p["b"])))
        else:
            expression = r"%d x^{%d}+\frac{%s}{x^{%d}}" % (p["a"], p["up"], _tex(Fraction(p["b"])), p["down"])
        return f"Find the minimum value of ${expression}$ for real $x>0$."

    return template(
        "extensions.algebra.opposite_power_minimum", domains, original, render, solve,
        valid=_positive_exact(solve), sample=sample, reference=reference,
        constraints=("Both coefficients are positive, and the unique positive stationary point has an exact rational value "
                     "in x or in the source substitution t=√x.",),
    )


def _square_root_fraction(key):
    translated = key == "intermediate_algebra/train/329"
    domains = {"numerator_offset": integer(-20, 120), "denominator_offset": integer(1, 64)}
    original = {"numerator_offset": 8 if translated else 7, "denominator_offset": 1 if translated else 3}

    def solve(p):
        a, b = p["numerator_offset"], p["denominator_offset"]
        if translated:
            if a+b <= 0:
                raise ValueError("minimum requires a positive reciprocal term")
            return 2 * sqrt_fraction(a+b)
        return 2 * sqrt_fraction(a-b) if a >= 2*b else Fraction(a) / sqrt_fraction(b)

    def sample(rng):
        if translated:
            b = rng.randint(1, 20)
            return {"denominator_offset": b, "numerator_offset": rng.randint(1, 10)**2-b}
        if rng.randrange(2):
            k = rng.randint(2, 8)
            b = rng.randint(1, k*k)
            return {"denominator_offset": b, "numerator_offset": b + k*k}
        b = rng.randint(1, 7)**2
        return {"denominator_offset": b, "numerator_offset": rng.randint(1, 2*b-1)}

    def render(p):
        a, b = p["numerator_offset"], p["denominator_offset"]
        n = _tex_polynomial((a, 1)) if translated else _tex_polynomial((a, 0, 1))
        d = _tex_polynomial((-b, 1)) if translated else _tex_polynomial((b, 0, 1))
        expression = r"\frac{%s}{\sqrt{%s}}" % (n, d)
        return f"Find the minimum of ${expression}$ for " + (f"real $x>{b}$." if translated else "all real $x$.")

    return template(
        "extensions.algebra.rational_radical_minimum", domains, original, render, solve,
        valid=_positive_exact(solve), sample=sample,
        constraints=("After taking the denominator as the new variable, the minimum occurs at its positive "
                     "stationary point or the allowed endpoint. The attained value is rational.",),
    )


def _weighted_xy():
    domains = {"x_weight": integer(1, 20), "y_weight": integer(1, 20), "total": integer(1, 140)}
    original = {"x_weight": 4, "y_weight": 9, "total": 60}

    def solve(p):
        return Fraction(p["total"]**2, 4*p["x_weight"]*p["y_weight"])

    def reference(p):
        a, b, c = (p[k] for k in domains)
        x = Fraction(c, 2*a)
        return x * (c-a*x) / b

    def render(p):
        a, b, c = (p[k] for k in domains)
        return f"For positive real $x,y$ with ${a}x+{b}y={c}$, find the maximum of $xy$."

    return template("extensions.algebra.linear_constraint_product_maximum", domains, original, render, solve,
                    reference=reference, constraints=("The weights and total are positive.",))


def _weighted_reciprocals():
    domains = {"x_cost": integer(1, 15), "y_cost": RATIONAL, "x_weight": integer(1, 15),
               "y_weight": integer(1, 15), "total": integer(1, 45)}
    original = {"x_cost": 2, "y_cost": 1, "x_weight": 1, "y_weight": 2, "total": 1}

    def constants(p):
        return (Fraction(p["x_cost"]), Fraction(p["y_cost"]),
                p["x_weight"], p["y_weight"], p["total"])

    def solve(p):
        a, b, u, v, t = constants(p)
        return (a*u + b*v + 2*sqrt_fraction(a*b*u*v))/t

    def reference(p):
        a, b, u, v, t = constants(p)
        ratio = sqrt_fraction(a*u / (b*v))
        y = t / (v*(1+ratio))
        x = (t-v*y)/u
        return a/x+b/y

    def sample(rng):
        a, u, v, t = (rng.randint(1, 12) for _ in range(4))
        k = rng.randint(1, 18)
        return {"x_cost": a, "y_cost": str(Fraction(k*k, a*u*v)), "x_weight": u, "y_weight": v, "total": t}

    def render(p):
        a, b, u, v, t = constants(p)
        expression = r"\frac{%s}{x}+\frac{%s}{y}" % (_tex(a), _tex(b))
        return f"For positive real $x,y$ with ${u}x+{v}y={t}$, find the minimum of ${expression}$."

    return template(
        "extensions.algebra.weighted_reciprocal_minimum", domains, original, render, solve,
        valid=lambda p: Fraction(p["y_cost"]) > 0 and _positive_exact(solve)(p), sample=sample, reference=reference,
        constraints=("All weights are positive and the product of the four weights is a rational square.",),
    )


def _weighted_quadratic():
    domains = {"weights": integers(3, 1, 20), "total": integer(-30, 30)}
    original = {"weights": [2, 3, 6], "total": 1}

    def solve(p):
        return p["total"]**2 / sum(Fraction(1, w) for w in p["weights"])

    def reference(p):
        a, b, c = p["weights"]
        xyz = [Fraction(p["total"]*k, a*b+a*c+b*c) for k in (b*c, a*c, a*b)]
        return sum(w*x*x for w, x in zip(p["weights"], xyz))

    def render(p):
        a, b, c = p["weights"]
        return f"For real $a,b,c$ with $a+b+c={p['total']}$, find the minimum of ${a}a^2+{b}b^2+{c}c^2$."

    return template("extensions.algebra.weighted_quadratic_minimum", domains, original, render, solve,
                    reference=reference, constraints=("All quadratic weights are positive.",))


def _sum_squares_box():
    domains = {"first_product": integer(1, 80), "second_product": RATIONAL}
    original = {"first_product": 4, "second_product": 9}

    def solve(p):
        return 4*sqrt_fraction(p["first_product"]*Fraction(p["second_product"]))

    def sample(rng):
        a, root = rng.randint(1, 35), rng.randint(1, 28)
        return {"first_product": a, "second_product": str(Fraction(root*root, a))}

    def render(p):
        a, b = p["first_product"], _tex(Fraction(p["second_product"]))
        return (f"For real $a,b,c,d,e,f,g,h$ with $abcd={a}$ and $efgh={b}$, "
                "find the minimum of $(ae)^2+(bf)^2+(cg)^2+(dh)^2$.")

    return template("extensions.algebra.paired_products_amgm", domains, original, render, solve,
                    valid=_positive_exact(solve), sample=sample,
                    constraints=("Both products are positive and their product is a rational square.",))


def _product_power_amgm():
    domains = {"left_power": integer(1, 5), "right_power": integer(1, 5), "power": integer(2, 8),
               "product": integer(1, 45)}
    original = {"left_power": 1, "right_power": 2, "power": 4, "product": 5}

    def solve(p):
        return 2*sqrt_fraction(p["product"]**p["power"])

    def render(p):
        a, b, n, total = (p[k] for k in domains)
        return (f"For positive real $a,b$ satisfying $a^{{{a}}}b^{{{b}}}={total}$, "
                f"find the minimum of $a^{{{a*n}}}+b^{{{b*n}}}$.")

    return template("extensions.algebra.power_product_amgm", domains, original, render, solve,
                    valid=_positive_exact(solve),
                    constraints=("The product is positive and its requested power has an exact square root.",))


def _quadratic_form():
    domains = {"xx": integer(1, 15), "xy": integer(-12, 12), "yy": integer(1, 15),
               "x": integer(-15, 15), "y": integer(-15, 15), "offset": integer(-20, 20)}
    original = {"xx": 1, "xy": 1, "yy": 1, "x": 0, "y": 0, "offset": 0}

    def valid(p):
        return 4*p["xx"]*p["yy"] > p["xy"]**2

    def solve(p):
        a, b, c, d, e, f = (p[k] for k in domains)
        return f - Fraction(c*d*d-b*d*e+a*e*e, 4*a*c-b*b)

    def reference(p):
        a, b, c, d, e, f = (p[k] for k in domains)
        y = Fraction(b*d-2*a*e, 4*a*c-b*b)
        x = -(b*y+d)/(2*a)
        return a*x*x+b*x*y+c*y*y+d*x+e*y+f

    def render(p):
        a, b, c, d, e, f = (p[k] for k in domains)
        terms = [(a, "x^2"), (b, "xy"), (c, "y^2"), (d, "x"), (e, "y"), (f, "")]
        pieces = []
        for value, mono in terms:
            if not value:
                continue
            coefficient = "" if abs(value) == 1 and mono else str(abs(value))
            pieces.append(("+" if value > 0 and pieces else "-" if value < 0 else "") + coefficient + mono)
        return "Find the minimum of $" + "".join(pieces) + "$ over all real $x,y$."

    return template("extensions.algebra.positive_definite_quadratic_minimum", domains, original, render, solve,
                    valid=valid, reference=reference,
                    constraints=("The quadratic part is positive definite, i.e. 4·xx·yy > xy².",),
                    adaptation="Allow independent linear and constant terms while retaining positive definiteness.")


def _cubic_maximum():
    domains = {"linear": integer(1, 340), "cubic": integer(1, 16), "upper_squared": integer(1, 144)}
    original = {"linear": 3, "cubic": 1, "upper_squared": 3}

    def point_squared(p):
        return min(Fraction(p["linear"], 3*p["cubic"]), p["upper_squared"])

    def solve(p):
        t = sqrt_fraction(point_squared(p))
        return p["linear"]*t-p["cubic"]*t**3

    def sample(rng):
        n, b = rng.randint(1, 5), rng.randint(1, 4)
        upper = rng.randint(n*n, 100)
        if rng.randrange(3) == 0:
            upper = rng.randint(1, n)**2
        return {"linear": 3*b*n*n, "cubic": b, "upper_squared": upper}

    def render(p):
        expr = _tex_polynomial((0, p["linear"], 0, -p["cubic"]))
        return fr"Find the maximum of ${expr}$ on $0\le x\le\sqrt{{{p['upper_squared']}}}$."

    return template("extensions.algebra.cubic_interval_maximum", domains, original, render, solve,
                    valid=_positive_exact(solve), sample=sample,
                    constraints=("The maximum occurs at the positive critical point or the right endpoint, "
                                 "whichever lies first. Its input is rational.",),
                    adaptation="Allow the right endpoint to vary independently of the positive zero of the cubic.")


def _radical_maximum():
    domains = {"left": integer(1, 320), "right": integer(1, 320)}
    original = {"left": 25, "right": 25}

    def solve(p):
        return sqrt_fraction(2*(p["left"]+p["right"]))

    def reference(p):
        a, b = p["left"], p["right"]
        x = Fraction(b-a, 2)
        return sqrt_fraction(a+x)+sqrt_fraction(b-x)

    def sample(rng):
        n = rng.randint(2, 12)
        a = rng.randint(1, 2*n*n-1)
        return {"left": a, "right": 2*n*n-a}

    def render(p):
        a, b = p["left"], p["right"]
        return fr"For ${-a}\le x\le {b}$, find the maximum of $\sqrt{{{a}+x}}+\sqrt{{{b}-x}}$."

    return template("extensions.algebra.radical_sum_maximum", domains, original, render, solve,
                    valid=_positive_exact(solve), sample=sample, reference=reference,
                    constraints=("The interval is the common real domain and twice the sum of the radicand offsets is a square.",),
                    adaptation="Allow distinct offsets in the two radicands and update the interval to their common domain.")


def _absolute_minimum(key):
    interval = key == "intermediate_algebra/test/163"
    if interval:
        domains = {"p": integer(1, 32), "center": integer(2, 40), "weights": integers(3, 1, 9)}
        original = {"p": 3, "center": 15, "weights": [1, 1, 1]}
    else:
        domains = {"shifts": integers(3, -20, 20)}
        original = {"shifts": [-2, -4, -5]}

    def valid(p):
        return p["p"] < p["center"] if interval else len(set(p["shifts"])) == 3

    def solve(p):
        if not interval:
            return max(p["shifts"])-min(p["shifts"])
        x, y = p["p"], p["center"]
        a, b, c = p["weights"]
        return min(b*(y-x)+c*y, a*(y-x)+c*x)

    def render(p):
        if interval:
            x, y = p["p"], p["center"]
            a, b, c = p["weights"]
            return (fr"Find the minimum of ${a}|x-{x}|+{b}|x-{y}|+{c}|x-{x+y}|$ "
                    fr"for ${x}\le x\le{y}$.")
        terms = "+".join("|" + _tex_polynomial((-s, 1)) + "|" for s in p["shifts"])
        return f"Find the minimum of ${terms}$ over all real $x$."

    def reference(p):
        if interval:
            x, y = p["p"], p["center"]
            points, weights, candidates = (x, y, x+y), p["weights"], (x, y)
        else:
            points, weights, candidates = p["shifts"], (1, 1, 1), p["shifts"]
        return min(sum(w*abs(t-center) for center, w in zip(points, weights)) for t in candidates)

    return template("extensions.algebra.absolute_sum_minimum", domains, original, render, solve,
                    valid=valid, reference=reference,
                    constraints=("The three shifts differ." if not interval else
                                 "The two interval endpoints are positive and strictly ordered.",),
                    adaptation="Choose a concrete allowed value for the source symbolic parameter p, "
                               "then let both endpoints and all three weights vary." if interval else "")


SIMPLE = {
    "intermediate_algebra/train/505": _weighted_xy,
    "intermediate_algebra/test/704": _weighted_reciprocals,
    "intermediate_algebra/test/638": _weighted_quadratic,
    "intermediate_algebra/train/787": _sum_squares_box,
    "intermediate_algebra/test/10": _product_power_amgm,
    "intermediate_algebra/train/208": _quadratic_form,
    "intermediate_algebra/train/222": _cubic_maximum,
    "intermediate_algebra/train/256": _radical_maximum,
}


def build(row):
    key = row["id"]
    if key in SIMPLE:
        return SIMPLE[key]()
    if key in {"intermediate_algebra/train/6", "intermediate_algebra/train/714",
               "intermediate_algebra/train/1033", "intermediate_algebra/test/200"}:
        return _weighted_amgm(key)
    if key in POSITIVE_POWERS:
        return _opposite_powers(key)
    if key in {"intermediate_algebra/train/15", "intermediate_algebra/train/329"}:
        return _square_root_fraction(key)
    if key in {"intermediate_algebra/train/361", "intermediate_algebra/test/163"}:
        return _absolute_minimum(key)
    return None
