"""Explicit bindings for the third intermediate algebra expansion."""
from . import round3_intermediate_arithmetic
from . import round3_intermediate_complex
from . import round3_intermediate_polynomial
from . import round3_intermediate_equations
from . import round3_intermediate_identities
from . import round3_intermediate_advanced
from . import round3_intermediate_systems
from . import round3_intermediate_radicals
from . import round3_intermediate_misc
from .round3_intermediate_common import build
