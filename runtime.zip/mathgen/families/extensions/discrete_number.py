"""Exact prime, divisor, product and perfect-power families."""

from calendar import monthrange, weekday
from fractions import Fraction
from functools import lru_cache
from itertools import combinations, product
from math import factorial, gcd, isqrt, lcm, prod

from .common import integers
from .discrete_helpers import (binder, ceildiv, choose, divisor_count, divisors, factors,
                               finite, floor_root, one, prime, primes, singleton)

TRAIN, train = binder('number_theory/train')
TEST, test = binder('number_theory/test')


def top_perfect_power(limit,minimum_exponent):
    best = max((a**b,a,b) for b in range(minimum_exponent,(limit-1).bit_length())
               if (a:=floor_root(limit-1,b))>=2)
    return best[1]+best[2]


def square_power_roots(lower,upper,power):
    factor = 2//gcd(power,2)
    lo = max(2,floor_root(lower,power*factor)+1)
    hi = floor_root(upper-1,power*factor)
    return [n**factor for n in range(lo,hi+1)]


def sample_square_roots(rng):
    power = rng.randint(2,4)
    factor = 2//gcd(power,2)
    q = rng.randint(2,4)
    if power==3:
        q = rng.choice([2,3,4])
    target = q**(power*factor)
    lower = target-rng.randint(1,min(80,target-1))
    upper = target+rng.randint(1,80)
    if len(square_power_roots(lower,upper,power))!=1:
        lower,upper = target-1,target+1
    return dict(lower=lower,upper=upper,power=power)


def largest_mersenne(limit,radix):
    return max(radix**n-1 for n in primes(limit.bit_length()) if
               radix**n-1<limit and prime(radix**n-1))


def tau_power(count,power):
    # A prime number of divisors forces a single prime power.
    return 1+(count-1)*power


def composite_blocks(start, length_a, length_b):
    composites = [n for n in range(4,2*(start+length_a+length_b)+5) if not prime(n)]
    a = composites[start-1:start-1+length_a]
    b = composites[start-1+length_a:start-1+length_a+length_b]
    return Fraction(prod(a),prod(b))


def first_prime_after_nonprimes(run,upper):
    # The preceding run may include 1. A prime p qualifies iff the
    # gap from the previous prime exceeds run.
    ps = primes(upper)
    return next((p for previous,p in zip([0]+ps,ps)
                 if p-previous>run and p>run),None)


def unique_prime_remainder(lower,upper,modulus,remainder):
    return [n for n in primes(upper-1) if n>lower and n%modulus==remainder]


def sample_prime_remainder(rng):
    p = rng.choice(primes(250)[5:])
    m = rng.randint(3,19)
    return dict(lower=p-m,upper=p+m,modulus=m,remainder=p%m)


def smallest_prime_power_sum(a,b,x,y,bound=150):
    return next((p for p in primes(bound) if (pow(a,x,p)+pow(b,y,p))%p==0),None)


def exact_rows(small,large,people):
    return [count for count in range(people//large+1) if (people-count*large)%small==0]


def sample_rows(rng):
    small, large = rng.choice([(a,b) for a,b in combinations(range(3,15),2) if gcd(a,b)==1])
    count = rng.randint(1,small-1)
    short = rng.randint(1,large-1)
    return dict(small=small,large=large,people=count*large+short*small)


def least_prime_common_multiple(width,count):
    p = prod(primes(41)[:count])
    return ceildiv(10**(width-1),p)*p


def chain_products(number,length):
    starts = range(1,floor_root(number,length)+1)
    return next((list(range(n,n+length)) for n in starts
                 if prod(range(n,n+length))==number),[])


def age_candidates(before,after,power):
    return [age for age in range(before+1,121) if isqrt(age-before)**2==age-before
            and floor_root(age+after,power)**power==age+after]


def age_sample(rng):
    options = [(a,b,c) for a,b,c in finite((1,10),(1,15),(2,5)) if len(age_candidates(a,b,c))==1]
    return choose(rng,('before','after','power'),options)


def sum_of_divisors_candidates(total,divisor):
    return [x for x in range(divisor,total+1,divisor) if sum(divisors(x))==total]


def nth_nonsquare(rank):
    lo,hi = rank,2*rank+2
    while lo<hi:
        mid = (lo+hi)//2
        if mid-isqrt(mid)<rank:
            lo = mid+1
        else:
            hi = mid
    return lo


def pair_products(product_a, product_b):
    result = set()
    for B in divisors(product_a):
        A = product_a//B
        for C in divisors(product_b):
            D = product_b//C
            if len({A,B,C,D})==4 and A-B==C+D:
                result.add(A)
    return sorted(result)


def sample_pair_products(rng):
    candidates = []
    for B,C,D in combinations(range(1,17),3):
        for b,c,d in [(B,C,D),(C,B,D),(D,B,C)]:
            a = b+c+d
            p,q = a*b,c*d
            if pair_products(p,q)==[a]:
                candidates.append((p,q))
    return choose(rng,('product_a','product_b'),candidates)


def prime_progression(length, step):
    # For prime length and step coprime to it, one term is divisible by
    # length and therefore equals length. The start is at most length.
    return [sum(seq) for p in primes(length) if
            all(map(prime, seq:=list(range(p,p+length*step,step))))]


def two_composites(total, minimum):
    return next((total-2*a for a in range((total-1)//2,minimum-1,-1)
                 if not prime(a) and not prime(total-a)),None)


def chip_count(total,minimum):
    return next(((total-p)//2 for p in primes(total-2)
                 if (total-p)%2==0 and p>=minimum),None)


def candidate_prime_expressions(lower,upper,options):
    return sorted(set(options)&{p*q-p-q for p,q in combinations([p for p in primes(upper-1)
                                                                  if p>lower],2)})


def sample_prime_expressions(rng):
    low,high = rng.randint(2,12),rng.randint(18,32)
    values = {p*q-p-q for p,q in combinations([p for p in primes(high-1) if p>low],2)}
    answer = rng.choice(sorted(values))
    options = [answer,*rng.sample([n for n in range(1,1000) if n not in values],4)]
    rng.shuffle(options)
    return dict(lower=low,upper=high,options=options)


def quotient_unit_product(start, stop, divisor):
    # Computing the numerator modulo 10*divisor retains the quotient's
    # units digit for every exact division.
    return prod(range(start,stop+1))%(10*divisor)//divisor


def least_nested_divisors(count):
    # Witness a = 2^(count-1), b = 2^(a-1); any qualifying b divides no
    # later minimum, so complete the search from 2 through that witness.
    limit = 1 << ((1 << (count-1))-1)
    for b in range(2,limit+1):
        a = divisor_count(b)
        if b%a==0 and divisor_count(a)==count:
            return b
    raise AssertionError('Known two-power witness missing')


def capped_tower(base,height,cap):
    if cap<=1 or height==0:
        return min(1,cap)
    exponent_limit = 0
    power = 1
    while power<cap:
        power *= base
        exponent_limit += 1
    return min(base**capped_tower(base,height-1,exponent_limit),cap)


def modular_tower(base,height,mod):
    if mod==1:
        return 0
    if height==0:
        return 1
    phi = mod
    for p,_ in factors(mod):
        phi = phi//p*(p-1)
    exponent = modular_tower(base,height-1,phi)
    if capped_tower(base,height-1,phi)==phi:
        exponent += phi
    return pow(base,exponent,mod)


def consecutive_prime_sum(square,count):
    if isqrt(square)**2!=square:
        return []
    target = isqrt(square)
    ps = primes(target)
    return [ps[i+count-1] for i in range(len(ps)-count+1) if sum(ps[i:i+count])==target]


def sample_prime_sum(rng):
    ps = primes(97)
    count = rng.randint(2,6)
    start = rng.randrange(len(ps)-count+1)
    return dict(square=sum(ps[start:start+count])**2,count=count)


def minimum_distinct_product_sum(total, minimum):
    def candidates(n, previous):
        if n>=previous and n>=minimum:
            yield n
        for d in divisors(n):
            if max(previous,minimum)<=d<=isqrt(n):
                for tail in candidates(n//d,d+1):
                    yield d+tail

    return min(candidates(total,max(2,minimum)))


def sum_of_powered_powers(width,power,first,second):
    lo = floor_root(10**(width-1)-1,power)+1
    hi = floor_root(10**width-1,power)
    return sum(n**power for n in range(lo,hi+1)
               if floor_root(n,first)**first==n or floor_root(n,second)**second==n)


def prime_triple_sum(fixed,delta,upper):
    if len(set(fixed))!=len(fixed) or not prime(sum(fixed)+delta):
        return None
    starts = range(max(fixed)+1,upper+1)
    return next((x for x in starts if all(prime(sum(pair)+x+delta) for pair in combinations(fixed,2))),None)


def least_power_consecutive_sum(length,power):
    # The sum is length*a + length*(length-1)/2 for any integer a.
    r = length*(length-1)//2%length
    return next((x**power for x in range(1,length+1) if x**power%length==r),None)


def unique_factor_pair(number, minimum, maximum):
    return [(a,number//a) for a in divisors(number) if minimum<=a<=number//a<=maximum]


def prime_run_multiple(modulus,length,upper):
    ps = primes(upper)
    for i in range(len(ps)-length+1):
        value = sum(ps[i:i+length])
        if value%modulus==0:
            return value
    return None


def prime_congruence_above(lower,modulus,remainder,upper):
    return next((p for p in range(lower+1+(remainder-lower-1)%modulus,upper+1,modulus)
                 if prime(p)),None)


def gcd_lcm_inverse(n,k,g):
    total = factorial(k)*g
    return [total//n] if total%n==0 and gcd(n,total//n)==g and lcm(n,total//n)==factorial(k) else []


def sample_lcm_gcd(rng):
    k = rng.randint(4,8)
    fs = factors(factorial(k))
    g = prod(p**rng.randint(0,e) for p,e in fs)
    coprime_partition = prod(p**e for p,e in factors(factorial(k)//g) if rng.choice((False,True)))
    return dict(k=k,n=g*coprime_partition,g=g)


def square_progression_sum(length,step):
    minimum = step*length*(length+1)//2
    modulus = step*length
    residue = minimum%modulus
    root = isqrt(minimum-1)+1
    return next((s*s for s in range(root,root+modulus) if s*s%modulus==residue),None)


def ratio_lcm_gcd_product(number,ratio):
    if number%ratio:
        return []
    g = isqrt(number//ratio)
    if g*g*ratio!=number:
        return []
    return [g*(a+ratio//a) for a in divisors(ratio)
            if a<=ratio//a and gcd(a,ratio//a)==1]


def next_square_triangular(lower):
    x, y = 3, 1
    while (x-1)//2<=lower:
        x,y = 3*x+8*y,x+3*y
    return (x-1)//2


def formation_rows(total, more, fewer):
    return [rows for rows in divisors(total) if total//rows>fewer and
            (rows+more)*(total//rows-fewer)==total]


def sample_formation(rng):
    more,fewer = rng.randint(2,11),rng.randint(1,8)
    n = rng.randint(1,7)
    g = gcd(more,fewer)
    rows = n*(more//g)
    seats = fewer+n*(fewer//g)
    return dict(total=rows*seats,more=more,fewer=fewer)


def prime_rational(a,b):
    # n+a over b-n is (a+b)/(b-n) - 1. A positive value
    # requires 0 < b-n < a+b and the denominator divides a+b.
    return [b-d for d in divisors(a+b) if prime((a+b)//d-1)]


def multiples_with_tau(modulus,count):
    required = factors(modulus)
    used = {p for p,_ in required}
    extras = [p for p in primes(50) if p not in used]

    def build(index, available, previous):
        if index<len(required):
            p,minimum = required[index]
            for d in divisors(available):
                if d>minimum:
                    for rest in build(index+1,available//d,previous):
                        yield p**(d-1)*rest
        elif available==1:
            yield 1
        else:
            p = extras[index-len(required)]
            for d in divisors(available):
                if 2<=d<=previous:
                    for rest in build(index+1,available//d,d):
                        yield p**(d-1)*rest

    return min(build(0,count,count),default=None)


train(6,'largest_bounded_perfect_power',dict(limit=(399,30,5000),minimum_exponent=(2,2,4)),
      'Among perfect powers a^b strictly below {limit}, with integer a ≥ 2 and b ≥ {minimum_exponent}, '
      'choose the greatest value. If there is a tie, choose the greatest a. What is a + b?',
      top_perfect_power,adaptation='Specifies a tie rule and a variable minimum exponent.')
train(10,'unique_perfect_square_power_in_interval',dict(lower=(500,1,4095),upper=(1000,2,4300),power=(3,2,4)),
      'An integer k > 1 has k^{power} strictly between {lower} and {upper}, and k^{power} is a perfect square. What is k?',
      one(square_power_roots),valid=singleton(square_power_roots),sample=sample_square_roots,
      constraints=['Exactly one integer greater than one meets the stated interval and square condition.'])
train(21,'count_divisor_rows_in_interval',dict(total=(72,30,300),lo=(5,2,15),hi=(20,16,70)),
      'A marching band has {total} members and forms rows of equal size. The row length is between '
      '{lo} and {hi}, inclusive. How many row lengths are possible?',
      lambda total,lo,hi: sum(lo<=d<=hi for d in divisors(total)),
      reference=lambda total,lo,hi: sum(total%d==0 for d in range(lo,hi+1)))
train(30,'forced_prime_neighbors_in_divisor_cycle',dict(p=(5,2,19),q=(7,2,23)),
      lambda p,q: f'Arrange the positive divisors of {p*p*q} other than 1 in a circle so each adjacent pair '
      f'has gcd greater than 1. What is the sum of the two neighbors of {q}?',
      lambda p,q: q*(p+p*p),valid=lambda p,q: p!=q and prime(p) and prime(q),
      constraints=['p and q are distinct primes; the displayed number is p²q.'])
train(48,'largest_mersenne_prime_below_bound',dict(limit=(200,8,40000)),
      'What is the largest prime of the form 2^n − 1 with n prime and 2^n − 1 < {limit}?',
      lambda limit: largest_mersenne(limit,2))
train(61,'divisor_count_of_prime_power_power',dict(count=(3,2,31),power=(2,2,15)),
      'A positive integer n has {count} positive divisors. How many positive divisors does n^{power} have?',
      tau_power,valid=lambda count,power: prime(count),
      constraints=['The specified number of divisors is prime.'])
train(147,'mean_of_prime_list_entries',dict(values=([21,23,25,27,29],integers(5,2,200))),
      'Find the arithmetic mean of the prime entries of the list {values}, counting repeated entries.',
      lambda values: (lambda ps: Fraction(sum(ps),len(ps)))([n for n in values if prime(n)]),
      valid=lambda values: any(prime(n) for n in values),
      constraints=['The list contains at least one prime.'])
train(174,'ratio_of_two_composite_blocks',dict(start=(1,1,8),length_a=(5,2,10),length_b=(5,2,10)),
      'Starting with the {start}-th positive composite integer, form two consecutive blocks of composite '
      'integers of lengths {length_a} and {length_b}. Divide the first block’s product by the second block’s product.',
      composite_blocks)
train(178,'least_prime_after_nonprime_run',dict(run=(5,2,16),upper=(50,25,600)),
      'What is the smallest prime no greater than {upper} immediately preceded by at least {run} consecutive '
      'positive nonprime integers?',
      first_prime_after_nonprimes,valid=lambda run,upper: first_prime_after_nonprimes(run,upper) is not None,
      constraints=['The bound includes a qualifying prime.'],
      adaptation='Supplies a search upper bound above the source solution.')
train(220,'unique_prime_in_residue_interval',dict(lower=(20,10,250),upper=(30,13,270),modulus=(8,3,19),remainder=(5,0,18)),
      'A prime strictly between {lower} and {upper} leaves remainder {remainder} on division by {modulus}. What is it?',
      one(unique_prime_remainder),valid=singleton(unique_prime_remainder),sample=sample_prime_remainder,
      constraints=['Exactly one prime in the open interval has the specified legal residue.'])
train(263,'least_prime_divisor_of_power_sum',dict(a=(5,2,17),b=(7,2,17),x=(23,2,25),y=(17,2,25)),
      'What is the smallest prime divisor of {a}^{x} + {b}^{y}?',
      smallest_prime_power_sum,valid=lambda a,b,x,y: smallest_prime_power_sum(a,b,x,y) is not None,
      constraints=['The sum has at least one prime divisor at most 150.'])
train(278,'unique_mix_of_row_capacities',dict(small=(7,3,13),large=(8,4,14),people=(46,10,420)),
      'Seat exactly {people} people in rows of capacity {small} or {large}, filling all seats of each row. '
      'How many rows of capacity {large} are used?',
      one(exact_rows),valid=lambda small,large,people: small<large and len(exact_rows(small,large,people))==1,
      sample=sample_rows,constraints=['Capacities are distinct and exactly one mixture of full rows is possible.'])
train(401,'least_fixed_width_multiple_of_first_primes',dict(width=(4,2,10),count=(4,2,8)),
      'What is the smallest positive {width}-digit decimal integer divisible by the first {count} primes?',
      least_prime_common_multiple,valid=lambda width,count: least_prime_common_multiple(width,count)<10**width,
      constraints=['The smallest multiple with at least the requested width has that width exactly.'])
train(425,'unique_number_from_divisor_count_and_multiples',
      dict(a=(12,2,60),b=(15,2,60),count=(12,2,40)),
      'An integer x has exactly {count} positive divisors and is a multiple of {a} and {b}. What is the least possible x?',
      lambda a,b,count: multiples_with_tau(lcm(a,b),count),
      valid=lambda a,b,count: multiples_with_tau(lcm(a,b),count) is not None,
      constraints=['The divisor count is compatible with divisibility by both factors.'],
      adaptation='Asks for the minimum; the source solution is also unique for its input.')
train(436,'shared_product_of_consecutive_chains',dict(number=(210,10,2000),length_a=(2,2,4),length_b=(3,2,5)),
      'The integer {number} equals the product of {length_a} consecutive positive integers and also the product '
      'of {length_b} consecutive positive integers. What is the sum of both runs, counting their entries separately?',
      lambda number,length_a,length_b: sum(chain_products(number,length_a)+chain_products(number,length_b)),
      valid=lambda number,length_a,length_b: length_a<length_b and bool(chain_products(number,length_a))
      and bool(chain_products(number,length_b)),
      sample=lambda rng: _shared_product_sample(rng),
      constraints=['Both runs exist and their lengths differ.'])
train(459,'age_square_then_cube',dict(before=(1,1,10),after=(1,1,15),power=(3,2,5)),
      'Jane’s age is an integer no greater than 120. Exactly {before} years ago it was a positive '
      'perfect square, and in {after} years it will be a perfect {power}-th power. How old is Jane?',
      one(age_candidates),valid=singleton(age_candidates),sample=age_sample,
      constraints=['There is exactly one age within the stated bounds.'],
      adaptation='Supplies a finite maximum age and generalizes the offsets.')
train(502,'inverse_sum_of_divisors',dict(total=(24,7,300),divisor=(3,2,20)),
      'The sum of the positive divisors of x is {total}; one divisor is {divisor}. What is x?',
      one(sum_of_divisors_candidates),valid=singleton(sum_of_divisors_candidates),
      sample=lambda rng: _sample_sigma(rng),
      constraints=['Exactly one multiple of the specified divisor has the given divisor sum.'])
train(510,'count_prime_pairs_by_sum',dict(total=(40,8,160)),
      'How many unordered pairs of prime numbers, allowing equal primes, have sum {total}?',
      lambda total: sum(prime(total-p) for p in primes(total//2)),
      adaptation='States the convention for equal primes. The source has no equal pair.')
train(542,'rank_in_nonsquare_sequence',dict(rank=(200,1,8000)),
      'What is term {rank} of the increasing sequence of positive integers after omitting all perfect squares?',
      nth_nonsquare)
train(685,'prime_linear_transform_of_prime',dict(multiplier=(11,3,95),offset=(1,1,15)),
      'For an odd multiplier {multiplier} and odd offset {offset}, both p and '
      '{multiplier}p + {offset} are prime. What is the value of {multiplier}p + {offset}?',
      lambda multiplier,offset: 2*multiplier+offset,
      valid=lambda multiplier,offset: multiplier%2==offset%2==1 and prime(2*multiplier+offset),
      constraints=['The multiplier and offset are odd and the only possible transformed value is prime.'])
train(687,'linked_factor_pairs',dict(product_a=(60,9,1000),product_b=(60,4,700)),
      'Four distinct positive integers A, B, C, D satisfy AB = {product_a}, CD = {product_b}, '
      'and A − B = C + D. What is A?',
      one(pair_products),valid=singleton(pair_products),sample=sample_pair_products,
      constraints=['At least one factor-pair arrangement exists and A has the same value in every arrangement.'])
train(688,'divisor_count_of_fixed_dividend',dict(number=(1000,40,6000),cap=(1000,35,6000)),
      'A player picks a positive integer at most {cap}. For how many choices will dividing {number} by '
      'the chosen integer give an integer?',
      lambda number,cap: sum(d<=cap for d in divisors(number)),
      adaptation='Allows an upper bound other than the dividend.')
train(701,'inverse_fraction_decimal_exact',dict(delta=(27,2,1000),milli=(865,350,975)),
      lambda delta,milli: f'A positive integer a satisfies a/(a + {delta}) = 0.{milli:03d}. What is a?',
      lambda delta,milli: milli*delta//(1000-milli),
      valid=lambda delta,milli: milli*delta%(1000-milli)==0,
      sample=lambda rng: (lambda m: dict(milli=m,delta=(1000-m)//gcd(m,1000)*rng.randint(1,2)))(
          rng.randint(500,975)),
      constraints=['The exact decimal equation has an integral solution.'])
train(707,'prime_length_arithmetic_progression',dict(length=(5,3,11),step=(6,2,90)),
      'There is a unique arithmetic progression of {length} positive primes with common difference {step}. '
      'What is its sum?',
      one(prime_progression),valid=lambda length,step: prime(length) and step%length!=0
      and len(prime_progression(length,step))==1,
      sample=lambda rng: _sample_prime_progression(rng),
      constraints=['Length is prime, does not divide the step, and exactly one progression qualifies.'])
train(725,'maximize_smaller_group_with_prime_difference',dict(total=(54,12,180),minimum=(2,2,17)),
      'There are {total} chips in two nonempty groups. The larger group exceeds the smaller by a prime '
      'number at least {minimum}. What is the greatest possible size of the smaller group?',
      chip_count,valid=lambda total,minimum: chip_count(total,minimum) is not None,
      constraints=['There is an allowable prime difference of the same parity as the total.'],
      adaptation='Allows a lower bound on the prime difference, equal to two in the source.')
train(742,'inverse_consecutive_integer_product',dict(value=(840,20,40000),length=(4,2,5)),
      'The product of {length} consecutive positive integers is {value}. What is the largest of those integers?',
      lambda value,length: chain_products(value,length)[-1],
      valid=lambda value,length: bool(chain_products(value,length)),
      sample=lambda rng: (lambda n,k: dict(value=prod(range(n,n+k)),length=k))(rng.randint(4,6),rng.randint(2,5)),
      constraints=['The strictly increasing consecutive-product sequence contains the given value.'])
train(744,'least_difference_between_composite_summands',dict(total=(87,22,180),minimum=(4,4,16)),
      'The integer {total} is the sum of two distinct composite integers, each at least {minimum}. '
      'What is their smallest possible positive difference?',
      two_composites,valid=lambda total,minimum: two_composites(total,minimum) is not None,
      constraints=['At least one pair of admissible composite summands exists.'])
train(747,'coprime_factor_grouping_sum',dict(total=(27000,30,90000)),
      'Three integers greater than one are pairwise relatively prime and have product {total}. What is their sum?',
      lambda total: sum(p**e for p,e in factors(total)),
      valid=lambda total: len(factors(total))==3,
      sample=lambda rng: dict(total=prod(p**rng.randint(1,2) for p in rng.sample([2,3,5,7,11,13],3))),
      constraints=['The product has exactly three distinct prime divisors.'])
train(767,'attainable_expression_on_two_primes',
      dict(lower=(4,2,12),upper=(18,16,33),options=([21,60,119,180,231],integers(5,1,1000))),
      'Choose two different primes strictly between {lower} and {upper}. Subtract their sum from '
      'their product. Which value in the list {options} can be obtained?',
      one(candidate_prime_expressions),valid=singleton(candidate_prime_expressions),sample=sample_prime_expressions,
      constraints=['Exactly one listed value can be obtained.'])
train(769,'units_digit_of_divided_consecutive_product',dict(start=(20,8,45),stop=(25,12,60),divisor=(1000,2,2000)),
      'What is the units digit of the product of integers from {start} through {stop}, inclusive, divided by {divisor}?',
      quotient_unit_product,valid=lambda start,stop,divisor: start<=stop and prod(range(start,stop+1))%divisor==0,
      sample=lambda rng: _sample_consecutive_product(rng),
      constraints=['The interval is nonempty and the division is exact.'])
train(834,'number_of_primes_divisible_by_given_number',dict(divisor=(39,2,100)),
      'How many prime numbers are divisible by {divisor}?',lambda divisor: int(prime(divisor)))
train(837,'largest_prime_factor_of_power_sum',dict(a=(3,2,9),b=(6,2,9),x=(7,2,8),y=(6,2,8)),
      'What is the largest prime factor of {a}^{x} + {b}^{y}?',
      lambda a,b,x,y: factors(a**x+b**y)[-1][0])
train(840,'least_multiple_with_nested_divisor_counts',dict(count=(3,2,5)),
      'Positive integers a and b satisfy that a has {count} positive divisors, b has exactly a '
      'positive divisors, and b is divisible by a. What is the least possible b?',
      least_nested_divisors)

test(91,'last_digits_of_factorial_power_tower',dict(n=(4,2,9),width=(1,1,4)),
     'Build a right-associated power tower of {n}! copies of the base {n}!. What is the decimal value '
     'of its last {width} digits?',
     lambda n,width: modular_tower(factorial(n),factorial(n),10**width),
     adaptation='Generalizes the units digit to an arbitrary displayed suffix width.')
test(125,'largest_prime_in_fixed_consecutive_sum',dict(square=(72361,100,300000),count=(3,2,6)),
     'The square of the sum of {count} consecutive primes is {square}. What is the largest of those primes?',
     one(consecutive_prime_sum),valid=singleton(consecutive_prime_sum),sample=sample_prime_sum,
     constraints=['The value is a square and its root equals the sum of exactly one consecutive prime block.'])
test(177,'minimum_distinct_factors_sum',dict(total=(84,20,1200),minimum=(1,1,10)),
     'A set of distinct integers, all at least {minimum}, has product {total}. What is the least possible sum of its elements?',
     minimum_distinct_product_sum,
     adaptation='Allows a lower bound on factors. The factor 1 never improves the minimum.')
test(182,'sum_of_fixed_width_powered_powers',dict(width=(3,2,6),power=(3,2,5),first=(2,2,4),second=(3,2,5)),
     'What is the sum of the {width}-digit decimal perfect {power}-th powers whose positive integer '
     '{power}-th roots are either perfect {first}-th powers or perfect {second}-th powers?',
     sum_of_powered_powers)
test(259,'fraction_arithmetic_progressions_next_term',dict(start_num=(0,0,10),start_den=(1,1,12),step=(1,1,4),shown=(4,3,8)),
     'A fraction sequence starts at {start_num}/{start_den}. To find each new term, add {step} to both '
     'the numerator and denominator as carried forward from the previous step, without simplifying between steps. '
     'What is the next term after {shown} terms have been shown?',
     lambda start_num,start_den,step,shown: Fraction(start_num+step*shown,start_den+step*shown))
test(287,'count_primes_through_trial_division_limit',dict(number=(2003,100,12000)),
     'Trial division for {number} uses the list of primes at most √{number}. How many primes are in that list?',
     lambda number: len(primes(isqrt(number))),
     adaptation='Asks for the full list length, even if an early divisor is found.')
test(302,'least_prime_triple_completion',
     dict(fixed=([2,4,10],integers(3,1,15)),delta=(1,1,13),upper=(100,30,220)),
     'Choose the least integer x greater than each number in {fixed} and at most {upper}, such that '
     'adding {delta} to the sum of any three of the four distinct integers gives a prime. What is x?',
     prime_triple_sum,valid=lambda fixed,delta,upper: prime_triple_sum(fixed,delta,upper) is not None,
     sample=lambda rng: _sample_triple(rng),
     constraints=['The fixed entries are distinct and a qualifying completion exists.'],
     adaptation='Supplies a search upper bound above the source solution.')
test(322,'least_power_as_consecutive_sum',dict(length=(3,3,35),power=(3,2,7)),
     'What is the smallest positive perfect {power}-th power that is the sum of {length} consecutive integers?',
     least_power_consecutive_sum,valid=lambda length,power: least_power_consecutive_sum(length,power) is not None,
     constraints=['A power residue equals the fixed sum offset modulo the length.'])
test(334,'unique_nontrivial_factor_pair_sum',dict(number=(2005,20,7000)),
     'The positive integer {number} has exactly one unordered factor pair with both factors greater than 1. '
     'What is the sum of the factors in that pair?',
     lambda number: sum(unique_factor_pair(number,2,number)[0]),
     valid=lambda number: len(unique_factor_pair(number,2,number))==1,
     sample=lambda rng: dict(number=prod(rng.sample(primes(61),2))),
     constraints=['There is exactly one unordered nontrivial factor pair.'])
test(337,'least_consecutive_prime_sum_multiple',dict(modulus=(7,3,22),length=(3,2,6),upper=(100,30,300)),
     'Find the least sum of {length} consecutive primes that is a multiple of {modulus}. '
     'The greatest prime in the block is at most {upper}.',
     prime_run_multiple,valid=lambda modulus,length,upper: prime_run_multiple(modulus,length,upper) is not None,
     constraints=['There is a qualifying prime block within the bound.'],
     adaptation='Supplies a search upper bound above the source solution.')
test(340,'least_prime_above_lower_with_residue',dict(lower=(25,8,100),modulus=(25,3,39),remainder=(2,0,38),upper=(500,120,1000)),
     'What is the least prime greater than {lower} and at most {upper} that leaves remainder {remainder} '
     'when divided by {modulus}?',
     prime_congruence_above,
     valid=lambda lower,modulus,remainder,upper: remainder<modulus and
     prime_congruence_above(lower,modulus,remainder,upper) is not None,
     constraints=['The remainder is legal and the interval contains a qualifying prime.'],
     adaptation='Supplies a search upper bound above the source solution.')
test(359,'last_weekday_of_month',dict(year=(2008,1900,2200),month=(2,1,12),target=(4,0,6)),
     lambda year,month,target: f'In Gregorian month {month} of {year}, what is the date of the last '
     f'{["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"][target]}?',
     lambda year,month,target: (lambda d: d-(weekday(year,month,d)-target)%7)(monthrange(year,month)[1]),
     adaptation='Derives the starting weekday from the Gregorian calendar.')
test(371,'missing_factor_from_lcm_gcd_factorial',dict(n=(315,1,40320),k=(7,4,8),g=(9,1,40320)),
     'Two positive integers have least common multiple {k}! and greatest common divisor {g}. '
     'One integer is {n}. What is the other?',
     one(gcd_lcm_inverse),valid=singleton(gcd_lcm_inverse),sample=sample_lcm_gcd,
     constraints=['The proposed factor pair realizes both gcd and lcm.'])
test(394,'least_square_sum_positive_multiples_progression',dict(length=(4,2,12),step=(2,1,8)),
     'What is the least perfect square that is the sum of {length} consecutive positive multiples of {step}?',
     square_progression_sum,valid=lambda length,step: square_progression_sum(length,step) is not None,
     constraints=['A square residue matches the progression sum modulo length times step.'])
test(410,'factor_sum_from_product_and_lcm_gcd_ratio',dict(number=(144,20,3600),ratio=(9,2,70)),
     'Two positive integers have product {number}, and their lcm divided by their gcd is {ratio}. '
     'What is their sum?',
     one(ratio_lcm_gcd_product),valid=singleton(ratio_lcm_gcd_product),
     sample=lambda rng: (lambda p,g: dict(number=g*g*p,ratio=p))(rng.choice(primes(67)),rng.randint(4,7)),
     constraints=['The equations admit exactly one unordered pair.'])
test(421,'least_square_triangular_index',dict(lower=(3,1,300000)),
     'Find the smallest n greater than {lower} for which (1 + 2 + … + n)² is a perfect fourth power.',
     next_square_triangular)
test(432,'unique_two_digit_factor_pair_sum',dict(number=(4641,100,9801)),
     'The decimal integer {number} is the product of exactly one unordered pair of two-digit positive '
     'integers. What is the sum of the two factors?',
     lambda number: sum(unique_factor_pair(number,10,99)[0]),
     valid=lambda number: len(unique_factor_pair(number,10,99))==1,
     constraints=['Exactly one unordered factor pair consists of two-digit numbers.'])
test(444,'formation_rows_inverse',dict(total=(105,6,4900),more=(6,2,12),fewer=(2,1,8)),
     'A band of {total} members stands in a rectangular formation. A second rectangle has {more} more '
     'rows but {fewer} fewer members per row. How many rows were in the first formation?',
     one(formation_rows),valid=singleton(formation_rows),sample=sample_formation,
     constraints=['Exactly one starting rectangle has the required positive second dimensions.'])
test(452,'unique_integer_prime_rational_expression',dict(a=(1,1,29),b=(13,4,39)),
     'For what integer n is (n + {a}) / ({b} − n) a positive prime?',
     one(prime_rational),valid=singleton(prime_rational),
     constraints=['Exactly one divisor of a+b yields a prime quotient after subtracting one.'])
test(459,'calendar_month_day_tens_count',dict(year=(2007,1900,2200),digit=(3,0,3)),
     'Across the Gregorian year {year}, how many dates have tens digit {digit} in the day of the month, '
     'using a leading zero for days 1 through 9?',
     lambda year,digit: sum(day//10==digit for m in range(1,13) for day in range(1,monthrange(year,m)[1]+1)),
     adaptation='Specifies a year and allows a different day tens digit.')
test(461,'least_multiple_with_divisor_count',dict(modulus=(72,2,200),count=(16,4,40)),
     'What is the least positive multiple of {modulus} with exactly {count} positive divisors?',
     multiples_with_tau,valid=lambda modulus,count: multiples_with_tau(modulus,count) is not None,
     constraints=['The requested divisor count is compatible with the required prime exponents.'])
test(533,'least_square_root_of_integer_multiple',dict(x=(735,18,20000)),
     'What is the least possible value of √(a × {x}) if a is a positive integer and a × {x} is a perfect square?',
     lambda x: prod(p**ceildiv(e,2) for p,e in factors(x)))


@lru_cache(maxsize=1)
def _shared_product_catalog():
    by_number = {}
    for length in range(2,6):
        for start in range(1,floor_root(2000,length)+1):
            n = prod(range(start,start+length))
            if 10<=n<=2000:
                by_number.setdefault(n,[]).append(length)
    return [(n,a,b) for n,lengths in sorted(by_number.items()) for a,b in combinations(lengths,2)]


def _shared_product_sample(rng):
    return choose(rng,('number','length_a','length_b'),_shared_product_catalog())


def _sample_sigma(rng):
    values = [(sum(divisors(n)),d) for n in range(6,130) for d in divisors(n)
              if 2<=d<=20 and sum(divisors(n))<=300 and
              len(sum_of_divisors_candidates(sum(divisors(n)),d))==1]
    return choose(rng,('total','divisor'),values)


def _sample_prime_progression(rng):
    options = [(l,s) for l in (3,5,7,11) for s in range(2,91)
               if s%l and len(prime_progression(l,s))==1]
    return choose(rng,('length','step'),options)


def _sample_consecutive_product(rng):
    start = rng.randint(12,38)
    stop = start+rng.randint(2,10)
    options = [d for d in divisors(prod(range(start,stop+1))) if 2<=d<=2000] if stop-start<=3 else []
    if not options:
        value = prod(range(start,stop+1))
        options = [d for d in range(2,2001) if value%d==0]
    return dict(start=start,stop=stop,divisor=rng.choice(options))


def _sample_triple(rng):
    options = []
    for fixed in combinations(range(1,13),3):
        for delta in range(1,10):
            if prime_triple_sum(fixed,delta,120):
                options.append((fixed,delta))
    fixed,delta = rng.choice(options)
    return dict(fixed=list(fixed),delta=delta,upper=rng.randint(120,220))



def fibonacci(n):
    a,b = 0,1
    for _ in range(n):
        a,b = b,a+b
    return a


test(344,'greatest_fibonacci_gcd_at_fixed_gap',dict(gap=(1,1,50)),
     'The Fibonacci sequence starts with F₀ = 0 and F₁ = 1. Each following term is the sum '
     'of the previous two. What is the greatest possible gcd of Fₙ and the Fibonacci number '
     '{gap} positions later, over all n ≥ 0?',
     lambda gap: fibonacci(gap),
     reference=lambda gap: max(gcd(fibonacci(n),fibonacci(n+gap)) for n in range(1,2*gap+1)),
     adaptation='Varies the index gap, equal to one in the source.')
