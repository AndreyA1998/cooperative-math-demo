"""Coefficient matching, prime-value quadratics, and scalar polynomial simplification."""
from fractions import Fraction as F
from math import isqrt

from .round2_algebra_common import polynomial
from .round3_algebra_test_common import bind
from .round3_algebra_test_equations import quadratic_roots


def factors(n):
    """All positive divisors, without duplicates."""
    for k in range(1,isqrt(n)+1):
        if n%k==0:
            yield k
            if k*k!=n:
                yield n//k


def prime(n):
    return n>1 and all(n%d for d in range(2,isqrt(n)+1))


def build(row,index):
    def make(*args,**kwargs):
        return bind(row,*args,**kwargs)

    if index == 141:
        def solve(b,c):
            roots=quadratic_roots(1,b,c)
            if len(roots)==1:
                roots=roots*2
            a,d=roots
            return len({n for r,s in ((a,d),(d,a)) for n in (r-1,r+1)
                        if n>0 and prime(int((n-r)*(n-s)))})

        def valid(b,c):
            roots=quadratic_roots(1,b,c)
            return bool(roots) and all(r.denominator==1 for r in roots)

        def sample(rng):
            u,v=(rng.randint(-50,50) for _ in range(2))
            return -u-v,u*v

        return make('prime_values_of_reducible_quadratic',dict(linear=(-100,100),constant=(-2500,2500)),
                    (-3,2),[('n^2-3n+2',lambda b,c:polynomial(1,b,c,'n').replace(' ',''))],
                    solve,valid=valid,sample=sample,
                    reference=lambda b,c:sum(prime(n*n+b*n+c) for n in range(1,abs(b)+abs(c)+3)),
                    constraints=['The monic quadratic has integral roots, so a prime value requires one of the two linear factors to be 1 or −1.'])
    if index == 190:
        return make('positive_real_coefficient_matching',
                    dict(leading=(1,300),middle=(-300,300),constant_magnitude=(1,1000),
                         first_constant=(1,50),second_scale=(1,50),target_scale=(1,50)),
                    (24,-19,35,5,2,3),[('24x^2-19x-35',lambda a,b,c,d,e,f:polynomial(a,b,-c).replace(' ','')),
                                         ('Ax-5',lambda a,b,c,d,e,f:f'Ax-{d}'),
                                         ('2Bx+C',lambda a,b,c,d,e,f:f'{e}Bx+C'),
                                         ('AB-3C',lambda a,b,c,d,e,f:f'AB-{f}C')],
                    lambda a,b,c,d,e,f:F(a,e)-F(f*c,d),
                    constraints=['A, B, C are positive real numbers. After fixing AB and C, the middle coefficient AC − d·eB is strictly increasing from −∞ to +∞ as A ranges over positive values.'])
    if index == 216:
        def choices(a,b,c,k):
            if a%k:
                return ()
            return tuple((j,c//j) for j in factors(c) if c//j-a*j==b)

        def draw(rng):
            k,m,b,c=(rng.randint(1,15) for _ in range(4))
            return k*m,b-k*m*c,b*c,k

        return make('integer_factorization_with_monic_factor',
                    dict(leading=(1,225),middle=(-3374,225),constant_magnitude=(1,225),scale=(1,15)),
                    (6,-1,51,3),[('6y^2-y-51',lambda a,b,c,k:polynomial(a,b,-c,'y').replace(' ','')),
                                    ('3Ay+B',lambda a,b,c,k:f'{k}Ay+B')],
                    lambda a,b,c,k:(a//k*choices(a,b,c,k)[0][0])**2-choices(a,b,c,k)[0][1],
                    valid=lambda *p:len(choices(*p))==1,sample=draw,
                    constraints=['The leading coefficient is divisible by the scale and exactly one positive divisor of the constant magnitude gives the prescribed middle coefficient.'])
    if index == 461:
        def valid(d,e,a,b,c):
            return a%d==0 and c%e==0 and a//d!=c//e and e*(a//d)+d*(c//e)==b

        def draw(rng):
            u,v=rng.sample(range(1,31),2)
            d,e=(rng.randint(1,30) for _ in range(2))
            return d,e,d*u,d*v+e*u,e*v

        return make('linear_factor_product',
                    dict(factor_linear=(1,30),factor_constant=(1,30),leading=(1,900),middle=(1,1800),constant=(1,900)),
                    (2,3,20,44,21),[('2x+3',lambda d,e,a,b,c:f'{d}x+{e}'),
                                     ('20x^2+44x+21',lambda d,e,a,b,c:polynomial(a,b,c).replace(' ',''))],
                    lambda d,e,a,b,c:a//d+c//e,valid=valid,sample=draw,
                    constraints=['Matching the leading and constant coefficients yields two distinct integers; they also match the middle coefficient.'])
    if index == 610:
        return make('subtraction_cancelling_linear_terms',dict(expanded_constant=(-1000,1000),
                    first_offset=(1,50),second_offset=(1,50)),(7,3,2),
                    [('x^2-5x+7',lambda c,a,b:polynomial(1,-a-b,c).replace(' ','')),
                     ('(x-3)(x-2)',lambda c,a,b:f'(x-{a})(x-{b})')],
                    lambda c,a,b:c-a*b,reference=lambda c,a,b:1-a-b+c-(1-a)*(1-b))
    if index in (611,849):
        sign=1 if index==611 else -1
        def choices(a,b,u,v):
            pairs = ((x,a//x) for d in factors(a) for x in (d,-d))
            return tuple((x,y) for x,y in pairs if v*x+sign*u*y==b)

        def draw(rng):
            x,y,u,v=(rng.randint(1,25) for _ in range(4))
            return x*y,v*x+sign*u*y,u,v

        def solve(a,b,u,v):
            if index==611:
                return a
            return a+choices(a,b,u,v)[0][1]

        values=(6,17,1,5) if index==611 else (10,-1,8,3)
        lhs='6x^2 + 17x + 5' if index==611 else '10x^2-x-24'
        rhs='(Ax+1)(Bx+5)' if index==611 else '(Ax-8)(Bx+3)'
        return make('two_fixed_factor_constants',
                    dict(leading=(1,625),middle=(-1250,1250),first_constant=(1,25),second_constant=(1,25)),
                    values,[(lhs,lambda a,b,u,v:polynomial(a,b,sign*u*v) if index==611
                                          else polynomial(a,b,sign*u*v).replace(' ','')),
                             (rhs,lambda a,b,u,v:f'(Ax{"+" if sign==1 else "-"}{u})(Bx+{v})')],
                    solve,valid=lambda *p:bool(choices(*p)) if index==611 else len(choices(*p))==1,
                    sample=draw,
                    constraints=['There is an integer coefficient match; when B contributes separately to the answer, the match is unique.'])
    if index in (879,984):
        def choices(k,b,c):
            return tuple((a,c//a) for a in factors(c)
                         if (a+k*(c//a) if index==879 else k*a+c//a)==b)

        def draw(rng):
            k,a,b=(rng.randint(1,25) for _ in range(3))
            return k,(a+k*b if index==879 else k*a+b),a*b

        if index==879:
            fragments=[('3x^2 + 14x + 8',lambda k,b,c:polynomial(k,b,c)),
                       ('3x + A',lambda k,b,c:f'{k}x + A')]
            original=(3,14,8)
        else:
            fragments=[('2z^2+13z+21',lambda k,b,c:polynomial(k,b,c,'z').replace(' ','')),
                       ('2z + b',lambda k,b,c:f'{k}z + b'),
                       ('2a + b',lambda k,b,c:f'{k}a + b')]
            original=(2,13,21)
        return make('matching_factor_constants',
                    dict(leading=(1,25),middle=(1,650),constant=(1,625)),
                    original,fragments,lambda *p:choices(*p)[0][0]-choices(*p)[0][1] if index==879 else p[1],
                    valid=lambda *p:len(choices(*p))==1 if index==879 else bool(choices(*p)),sample=draw,
                    constraints=['A factorization into integer constants exists; when the two constants occur separately in the answer, they are unique.'])
