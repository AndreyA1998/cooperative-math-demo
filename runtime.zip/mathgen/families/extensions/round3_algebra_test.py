"""Explicit source bindings for the third algebra test extension."""
from . import round3_algebra_test_arithmetic as arithmetic
from . import round3_algebra_test_compositions as compositions
from . import round3_algebra_test_counts as counts
from . import round3_algebra_test_equations as equations
from . import round3_algebra_test_factorization as factorization
from . import round3_algebra_test_geometry as geometry
from . import round3_algebra_test_powers as powers
from . import round3_algebra_test_word as word


def build(row):
    if row.get('subject') != 'algebra' or row.get('split') != 'test':
        return None
    index = int(row['id'].rsplit('/',1)[-1])
    if index == 260:
        return compositions.symbols(row)
    if index == 388:
        return compositions.rational_powers(row)
    for group in (arithmetic, compositions, counts, equations, factorization, geometry, powers, word):
        case = group.build(row,index)
        if case is not None:
            return case
    return None
