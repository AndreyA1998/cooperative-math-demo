"""Registration and exact formatting helpers for explicit algebra bindings."""
from .common import integer, template


def register(bindings, ids, family, domains, originals, render, solve, *,
             reference=None, valid=None, constraints=(), adaptation='', sample=None):
    names = tuple(domains)
    for key, values in zip(ids.split(), originals):
        original = dict(zip(names, values))

        def factory(original=original):
            def unpack(function):
                return lambda p: function(*(p[name] for name in names))

            options = {'constraints': constraints, 'adaptation': adaptation}
            if valid is not None:
                options['valid'] = unpack(valid)
            if sample is not None:
                options['sample'] = lambda rng: dict(zip(names, sample(rng)))
            return template('round2_algebra_' + family,
                            {k: integer(*v) for k, v in domains.items()},
                            original, unpack(render), unpack(solve),
                            reference=unpack(reference) if reference else None, **options)

        if key in bindings or len(original) != len(domains):
            raise ValueError(f'Invalid algebra binding for {key}')
        bindings[key] = factory


def polynomial(a, b, c, variable='x'):
    terms = [(a, variable + '^2'), (b, variable), (c, '')]
    result = ''
    for coefficient, suffix in terms:
        if not coefficient:
            continue
        magnitude = '' if suffix and abs(coefficient) == 1 else str(abs(coefficient))
        if result:
            result += ' - ' if coefficient < 0 else ' + '
        elif coefficient < 0:
            result = '-'
        result += magnitude + suffix
    return result or '0'
