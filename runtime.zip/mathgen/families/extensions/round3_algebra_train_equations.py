"""Linear, rational, digit, and integer equations from explicit source IDs."""
from fractions import Fraction as Q
from math import ceil, floor, isqrt

from .round3_algebra_train_common import decimal, register, root, signed, square

BINDINGS = {}


def add(*args, **kwargs):
    register(BINDINGS, *args, **kwargs)


def digits(n,t):
    return tuple(x for x in range(1,10) if x*(10*t+2*x)==n)


add(276, 'digit_equation_quotient',
    (('dividend',252,12,972),('tens_digit',3,1,9)),
    lambda n,t:rf'Which digit is $\Theta$ if ${n}/\Theta=\underline{{{t}\Theta}}+\Theta$, with ${t}$ the tens digit and $\Theta$ the ones digit of the two-digit number?',
    lambda n,t:digits(n,t)[0],
    valid=lambda n,t:len(digits(n,t))==1,
    sample=lambda r:((x:=r.randint(1,9))*(10*(t:=r.randint(1,9))+2*x),t),
    constraints=('one nonzero digit x satisfies x*(10*tens_digit+2*x) = dividend',))


def fraction_numerator(a,b,p,q):
    return Q(p*b,a*p-q)


def positive_fraction_sample(r):
    a,n=r.randint(2,15),r.randint(1,200)
    d=r.randint(1,min(200,a*n-1))
    return a,d,n,a*n-d


def fraction_valid(a,b,p,q):
    return a*p>q and fraction_numerator(a,b,p,q).denominator==1


add(303, 'numerator_from_fraction_relation',
    (('denominator_multiplier',3,1,15),('denominator_decrease',7,1,200),
     ('equivalent_numerator',2,1,200),('equivalent_denominator',5,1,2999)),
    lambda a,b,p,q:rf'The denominator of a fraction is {b} less than {a} times its numerator. If it is equivalent to $\frac{{{p}}}{{{q}}}$, find its numerator.',
    fraction_numerator,
    valid=fraction_valid, sample=positive_fraction_sample,
    reference=lambda a,b,p,q:next(x for x in range(1,40001) if a*x>b and Q(x,a*x-b)==Q(p,q)),
    constraints=('denominator_multiplier*equivalent_numerator > equivalent_denominator and the solved numerator is an integer',),
    adaptation='As in the source solution, the requested numerator and denominator are positive integers.')


add(326, 'radical_ratio_positive_denominator',
    (('numerator_coefficient',5,1,100),('denominator_coefficient',3,1,30),
     ('denominator_offset',1,1,50),('ratio',2,1,20)),
    lambda a,b,c,k:rf'Find $x$ satisfying $\frac{{\sqrt{{{a}x}}}}{{\sqrt{{{b}(x-{c})}}}}={k}$. Express the answer as a fraction.',
    lambda a,b,c,k:Q(k*k*b*c,k*k*b-a),
    valid=lambda a,b,c,k:k*k*b>a,
    constraints=('ratio²*denominator_coefficient > numerator_coefficient',))


def fractional_decimal_solution(t,a,b,c,d):
    den=100*a-t*c
    return Q(t*d-100*b,den) if den else None


def fractional_decimal_sample(r):
    a,c,d,v=(r.randint(1,12) for _ in range(4))
    t=25*r.randint(1,8)
    d*=4
    c*=4
    b=t*(c*v+d)//100-a*v
    return t,a,b,c,d


add(414, 'fractional_linear_equation_decimal',
    (('target_hundredths',76,1,200),('numerator_coefficient',4,1,20),('numerator_constant',19,-150,400),
     ('denominator_coefficient',6,1,50),('denominator_constant',11,1,50)),
    lambda t,a,b,c,d:rf'The decimal ${decimal(t,2)}$ equals $\frac{{{a}b{signed(b)}}}{{{c}b+{d}}}$, where $b$ is a positive integer. Find $b$.',
    fractional_decimal_solution,
    valid=lambda *p:(v:=fractional_decimal_solution(*p)) is not None and v>0 and v.denominator==1,
    sample=fractional_decimal_sample,
    constraints=('cross-multiplication has a nonzero coefficient and determines a positive integer b',))


add(517, 'nonpositive_absolute_value',
    (('slope',3,-50,50),('constant',5,-100,100)),
    lambda a,b:f'For what $x$ is $|{a}x{signed(b)}|$ not positive? Express your answer as a fraction.',
    lambda a,b:Q(-b,a),
    valid=lambda a,b:a!=0, constraints=('slope is nonzero',))


def quotient_integer(a,b,p):
    value=Q(a*p,b)
    return isqrt(value.numerator) if value.denominator==1 and square(value.numerator) else None


def product_ratio_sample(r):
    b=r.randint(1,20)
    a=r.randint(b+1,30)
    k=r.randint(1,20)
    return a,b,a*b*k*k


add(666, 'product_and_quotient_larger_integer',
    (('quotient_numerator',5,2,30),('quotient_denominator',2,1,20),('product',160,2,240000)),
    lambda a,b,p:rf'The larger of two positive integers divided by the smaller is $\frac{{{a}}}{{{b}}}$ and their product is {p}. What is the larger integer?',
    quotient_integer,
    valid=lambda a,b,p:a>b and (x:=quotient_integer(a,b,p)) is not None and p%x==0,
    sample=product_ratio_sample,
    constraints=('quotient > 1 and the product and quotient yield two positive integers',))


def bows_total(a,b,c,d,e,f,w):
    return Q(w)/(1-Q(a,b)-Q(c,d)-Q(e,f))


def bows_valid(a,b,c,d,e,f,w):
    portions=(Q(a,b),Q(c,d),Q(e,f))
    if sum(portions)>=1:
        return False
    total=bows_total(a,b,c,d,e,f,w)
    return all((p*total).denominator==1 for p in portions)


def bows_sample(r):
    a,c,e,w=(r.randint(1,25) for _ in range(4))
    total=a+c+e+w
    fractions = [Q(k,total) for k in (a,c,e)]
    return *(i for q in fractions for i in (q.numerator,q.denominator)),w


add(930, 'colored_bows_from_remaining_count',
    (('red_numerator',1,1,25),('red_denominator',5,2,100),('blue_numerator',1,1,25),
     ('blue_denominator',2,2,100),('green_numerator',1,1,25),('green_denominator',10,2,100),
     ('white_count',30,1,300)),
    lambda a,b,c,d,e,f,w:rf'A bag of bows is $\frac{{{a}}}{{{b}}}$ red, $\frac{{{c}}}{{{d}}}$ blue, and $\frac{{{e}}}{{{f}}}$ green. The remaining {w} bows are white. How many bows are green?',
    lambda a,b,c,d,e,f,w:bows_total(a,b,c,d,e,f,w)*Q(e,f),
    valid=bows_valid,sample=bows_sample,
    constraints=('red+blue+green fractions sum to less than 1 and the implied counts are integers',))


add(941, 'cubic_ratio_equation',
    (('left_first_term',4,1,1000),('right_second_term',16,1,1000)),
    lambda a,b:f'If ${a}:x^2=x:{b}$, what is $x$?',
    lambda a,b:root(a*b,3),
    valid=lambda a,b:root(a*b,3)**3==a*b,
    sample=lambda r:((k:=r.randint(1,10))*(j:=r.randint(1,10))**2,k*k*j),
    constraints=('left_first_term*right_second_term is a perfect cube',))


add(1127, 'ratio_linear_forms_quotient',
    (('a_ratio',2,1,40),('b_ratio',1,1,40),('c_ratio',4,1,40),
     ('a_numerator_coefficient',3,1,20),('b_coefficient',2,1,20),
     ('c_coefficient',4,1,20),('a_denominator_coefficient',1,1,20)),
    lambda a,b,c,d,e,f,g:rf'If $A:B:C={a}:{b}:{c}$, find $({d}A+{e}B)\div({f}C-{g}A)$ as a fraction.',
    lambda a,b,c,d,e,f,g:Q(d*a+e*b,f*c-g*a),
    valid=lambda a,b,c,d,e,f,g:f*c!=g*a,
    constraints=('c_coefficient*c_ratio != a_denominator_coefficient*a_ratio',))


def unique_integer_candidates(b,c):
    # The strict quadratic comparison is equivalent to (2*x-b)^2 < b²+4*c.
    discriminant=b*b+4*c
    if discriminant<=0:
        return ()
    radius=isqrt(discriminant-1)
    lo=ceil(Q(b-radius,2))
    hi=floor(Q(b+radius,2))
    return (lo,) if lo==hi else ()


add(1263, 'unique_integer_strict_quadratic_comparison',
    (('linear_coefficient',2,-100,100),('constant',0,-2500,100)),
    lambda b,c:f'What is the only integer $x$ for which $x^2<{b}x{signed(c)}$?',
    lambda b,c:unique_integer_candidates(b,c)[0],
    valid=lambda b,c:bool(unique_integer_candidates(b,c)),
    sample=lambda r:(2*(z:=r.randint(-50,50)),1-z*z),
    reference=lambda b,c:next(x for x in range(-100,101) if x*x<b*x+c),
    constraints=('the open interval determined by x² < linear_coefficient*x+constant contains exactly one integer',),
    adaptation='Allow a constant term in the linear bound. At the source tuple the bound is twice x.')


def rational_intersection(a,b,c,d):
    denominator=a+d-b-c
    return Q(b*c-a*d,denominator) if denominator else None


add(1283, 'two_shifted_rational_functions_equal',
    (('first_numerator',3,-40,40),('first_denominator',5,-40,40),
     ('second_numerator',1,-40,40),('second_denominator',2,-40,40)),
    lambda a,b,c,d:rf'For what $x$ are $\frac{{x{signed(a)}}}{{x{signed(b)}}}$ and $\frac{{x{signed(c)}}}{{x{signed(d)}}}$ equal?',
    rational_intersection,
    valid=lambda a,b,c,d:(x:=rational_intersection(a,b,c,d)) is not None and x not in (-b,-d),
    constraints=('the linear cross-multiplied equation has a unique root, and neither denominator is zero there',))


def format_root(p,q):
    return str(p) if q==1 else rf'\frac{{{p}}}{{{q}}}'


def k_from_two_roots(b,c,p,q,r,s):
    x,y=Q(p,q),Q(r,s)
    k=Q(-b*x-c,x*x) if x else None
    return k if k and x!=y and k*y*y+b*y+c==0 else None


def two_roots_sample(rng):
    a,b,c,d=(rng.randint(1,12) for _ in range(4))
    scale=rng.randint(1,5)
    return scale*(a*d-b*c),-scale*b*d,b,a,-d,c


add(1301, 'leading_coefficient_from_two_roots',
    (('linear',-5,-720,720),('constant',-12,-720,-1),
     ('root1_numerator',3,1,12),('root1_denominator',1,1,12),
     ('root2_numerator',-4,-12,-1),('root2_denominator',3,1,12)),
    lambda b,c,p,q,r,s:rf'Find $k$ for which $kx^2{signed(b)}x{signed(c)}=0$ has roots $x={format_root(p,q)}$ and $x={format_root(r,s)}$.',
    k_from_two_roots,
    valid=lambda *p:k_from_two_roots(*p) is not None,
    sample=two_roots_sample,
    reference=lambda b,c,p,q,r,s:Q(c*q*s,p*r),
    constraints=('the two displayed roots are consistent with the same nonzero leading coefficient',))


def quiz_valid(n,a,c,u,t):
    return a<n and (n-a)*u<t<=a*c+(n-a)*u


def quiz_sample(r):
    n=r.randint(5,100)
    a=r.randint(1,n-1)
    c,u=r.randint(2,30),r.randint(0,10)
    return n,a,c,u,r.randint((n-a)*u+1,a*c+(n-a)*u)


add(1424, 'quiz_score_threshold',
    (('questions',25,5,100),('attempted',22,1,99),('correct_halfpoints',12,2,30),
     ('unanswered_halfpoints',3,0,10),('target_halfpoints',200,1,3100)),
    lambda n,a,c,u,t:f'A contest awards {Q(c,2)} points for each correct answer, 0 for each incorrect answer, and {Q(u,2)} for each question left unanswered. Sarah attempts the first {a} of {n} questions and leaves the rest unanswered. How many of the attempted questions must she solve correctly to score at least {Q(t,2)} points?',
    lambda n,a,c,u,t:ceil(Q(t-(n-a)*u,c)),
    valid=quiz_valid,sample=quiz_sample,
    reference=lambda n,a,c,u,t:next(k for k in range(a+1) if k*c+(n-a)*u>=t),
    constraints=('0 < attempted < questions and target exceeds the unanswered credit but is reachable',),
    adaptation='Remove the AMC contest name and year because generated scoring rules and contest lengths vary.')


def reciprocal_unique(a,b,p):
    q=Q(2*b,a)
    return q if q>1 and q*q==p else None


def reciprocal_unique_sample(rng):
    # A rational q with integral q² is integral. In reduced 2/q, the
    # numerator is 1 or 2; both values and all representable q are sampled.
    n = rng.choice(tuple(range(2, 101)) + tuple(range(102, 201, 2)))
    ratio = Q(2, n)
    return ratio.numerator, ratio.denominator, n*n


add(1453, 'reciprocal_sum_product_double_root',
    (('reciprocal_sum_numerator',1,1,100),('reciprocal_sum_denominator',1,1,100),
     ('product',4,2,40000)),
    lambda a,b,p:rf'Let $p>1$ and $q>1$ be real numbers with $\frac1p+\frac1q=\frac{{{a}}}{{{b}}}$ and $pq={p}$. What is $q$?',
    reciprocal_unique,
    valid=lambda *p:reciprocal_unique(*p) is not None,
    sample=reciprocal_unique_sample,
    constraints=('q=2*reciprocal_sum_denominator/reciprocal_sum_numerator is greater than 1 and q² = product',))


add(1548, 'count_integer_radicand_interval',
    (('coefficient',2,1,40),('lower_root',3,0,35),('upper_root',4,1,40)),
    lambda a,b,c:rf'The square root of ${a}x$ is greater than {b} and less than {c}. How many integer values of $x$ satisfy this?',
    lambda a,b,c:ceil(Q(c*c,a))-floor(Q(b*b,a))-1,
    valid=lambda a,b,c:b<c,
    reference=lambda a,b,c:sum(b*b<a*x<c*c for x in range(1601)),
    constraints=('lower_root < upper_root',))


def symbols_render(a,b,k):
    return rf'All triangles have the same value and all circles have the same value. \begin{{align*}}\Delta+\bigcirc+\Delta+\bigcirc+\Delta&={a}\\\bigcirc+\Delta+\bigcirc+\Delta+\bigcirc&={b}\end{{align*}} What is the sum of {k} circles?'


add(1681, 'triangle_circle_system',
    (('first_sum',21,-150,150),('second_sum',19,-150,150),('requested_circles',3,1,30)),
    symbols_render,
    lambda a,b,k:Q(k*(3*b-2*a),5))


add(1724, 'chain_of_proportional_variables',
    (('a_to_b',3,1,50),('b_to_c',2,1,50),('c_to_d',4,1,50)),
    lambda a,b,c:rf'For nonzero numbers, $a$ is {a} times $b$, $b$ is {b} times $c$, and $c$ is {c} times $d$. Find $\frac{{a\cdot c}}{{b\cdot d}}$.',
    lambda a,b,c:a*c,
    reference=lambda a,b,c:Q((a*b*c)*c,b*c),
    adaptation='Explicitly require nonzero values, as needed by the displayed quotient.')
