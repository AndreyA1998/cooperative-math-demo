"""Registry entry point for explicitly bound intermediate algebra problems."""
from . import (
    round2_intermediate_elementary,
    round2_intermediate_equations,
    round2_intermediate_geometry,
)
from .round2_intermediate_common import build
