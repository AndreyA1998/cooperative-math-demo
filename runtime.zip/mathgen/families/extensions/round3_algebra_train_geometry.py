"""Coordinate, perimeter, and elementary geometry templates."""
from fractions import Fraction as Q
from itertools import combinations
from math import isqrt

from .round3_algebra_train_common import register, signed, square

BINDINGS = {}


def add(*args, **kwargs):
    register(BINDINGS, *args, **kwargs)


def coordinates(*points):
    return tuple((f'{axis}{i}', value, -1000, 1000)
                 for i, point in enumerate(points,1) for axis,value in zip('xy',point))


def edges2(*points):
    pts=list(zip(points[::2],points[1::2]))
    return tuple((x-u)**2+(y-v)**2 for (x,y),(u,v) in combinations(pts,2))


def nondegenerate(x,y,u,v,s,t):
    return (u-x)*(t-y)!=(s-x)*(v-y)


add(283, 'rectangle_opposite_coordinate_sum',
    coordinates((3,17),(9,-4)),
    lambda x,y,u,v:f'If $({x},{y})$ and $({u},{v})$ are opposite vertices of a rectangle, what is the sum of the $y$-coordinates of its other two vertices?',
    lambda x,y,u,v:y+v,
    valid=lambda x,y,u,v:(x,y)!=(u,v), constraints=('opposite vertices are distinct',))


add(319, 'least_fence_square',
    (('minimum_area',400,1,1000000),),
    lambda a:f'Luke wants to fence a square plot of at least {a} square feet. What side length in feet minimizes the amount of fencing?',
    isqrt,
    valid=square,sample=lambda r:(r.randint(1,1000)**2,),
    constraints=('minimum_area is a perfect square',))


def line_args(values):
    return list(zip(values[::3],values[1::3],values[2::3]))


def good_pairs(*values):
    return sum(a*d==b*c or a*c==-b*d
               for (a,b,_),(c,d,_) in combinations(line_args(values),2))


def lines_render(*values):
    equations=r'\\'.join(rf'{b}y&={a}x{signed(c)}' for a,b,c in line_args(values))
    return rf'Consider the lines \begin{{align*}}{equations}\end{{align*}} How many pairs are parallel or perpendicular?'


def lines_distinct(*values):
    return len({(Q(a,b),Q(c,b)) for a,b,c in line_args(values)})==5


def lines_sample(r):
    a,b=r.randint(-5,5),r.randint(1,5)
    first=(a,b,r.randint(-10,10))
    lines=[first]+[(r.randint(-10,10),r.randint(1,10),r.randint(-30,30)) for _ in range(4)]
    mode=r.randrange(3)
    if mode==1:
        lines[1]=(a,b,first[2]+1)
    elif mode==2 and a:
        lines[1]=(-b if a>0 else b,abs(a),r.randint(-30,30))
    return tuple(v for line in lines for v in line)


add(712, 'count_parallel_perpendicular_pairs',
    tuple((f'{label}{i}',v,lo,hi)
          for i,line in enumerate(((3,1,5),(4,2,5),(9,3,-2),(1,2,-3),(1,4,-5)),1)
          for (label,lo,hi),v in zip((('x_coefficient',-10,10),('y_coefficient',1,10),('constant',-30,30)),line)),
    lines_render, good_pairs, valid=lines_distinct, sample=lines_sample,
    reference=lambda *v:sum(s==t or s*t==-1 for s,t in combinations([Q(a,b) for a,b,_ in line_args(v)],2)),
    constraints=('the five lines are distinct',))


def square_vertices(x,y,u,v,s,t,i,j):
    ux,uy=u-x,v-y
    vx,vy=i-x,j-y
    return (ux or uy) and ux*vx+uy*vy==0 and ux*ux+uy*uy==vx*vx+vy*vy and (s,t)==(u+i-x,v+j-y)


def square_sample(r):
    x,y=r.randint(-200,200),r.randint(-200,200)
    u,v=r.randint(-200,200),r.randint(-200,200)
    return x,y,x+u,y+v,x+u-v,y+u+v,x-v,y+u


add(931, 'square_area_from_vertices',
    coordinates((0,0),(-5,-1),(-4,-6),(1,-5)),
    lambda x,y,u,v,s,t,i,j:f'Find the area of the square with vertices $A({x},{y}), B({u},{v}), C({s},{t}), D({i},{j})$.',
    lambda x,y,u,v,s,t,i,j:(u-x)**2+(v-y)**2,
    valid=square_vertices,sample=square_sample,
    reference=lambda *p:abs(sum(p[i]*p[(i+3)%8]-p[i+1]*p[(i+2)%8] for i in range(0,8,2)))//2,
    constraints=('A,B,C,D are the cyclic vertices of a nondegenerate square',))


def pythagorean_sample(r):
    m=r.randint(2,12)
    n=r.randint(1,m-1)
    k=r.randint(1,3)
    return k*(m*m-n*n),2*k*m*n,k*(m*m+n*n)


def triangle_longest_sample(r):
    a,b,c=pythagorean_sample(r)
    x,y=r.randint(-150,150),r.randint(-150,150)
    d=r.randint(1,min(c,2*a))
    return x,y,x+a,y+b,x+d,y


add(1228, 'longest_triangle_side_from_vertices',
    coordinates((2,2),(5,6),(6,2)),
    lambda x,y,u,v,s,t:f'What is the length of the longest side of the triangle with vertices $({x},{y}),({u},{v}),({s},{t})$?',
    lambda *p:isqrt(max(edges2(*p))),
    valid=lambda *p:nondegenerate(*p) and square(max(edges2(*p))),
    sample=triangle_longest_sample,
    constraints=('vertices are noncollinear and the largest squared side is a perfect square',))


def triangle_perimeter_sample(r):
    a,b,_=pythagorean_sample(r)
    x,y=r.randint(-50,50),r.randint(-50,50)
    return x,y,x,y+2*b,x+a,y+b


add(1300, 'integer_triangle_perimeter_from_vertices',
    coordinates((1,2),(1,8),(5,5)),
    lambda x,y,u,v,s,t:f'Find the perimeter of the triangle with vertices $A({x},{y}),B({u},{v}),C({s},{t})$.',
    lambda *p:sum(map(isqrt,edges2(*p))),
    valid=lambda *p:nondegenerate(*p) and all(map(square,edges2(*p))),
    sample=triangle_perimeter_sample,
    constraints=('vertices are noncollinear and each squared side is a perfect square',))


add(1335, 'least_fence_fixed_side_difference',
    (('minimum_area',100,1,30000),('side_difference',15,1,150)),
    lambda a,d:f'Sarah is fencing a rectangular area of at least {a} square feet using the least material. If the length is {d} feet longer than the width, find the width in feet.',
    lambda a,d:Q(isqrt(d*d+4*a)-d,2),
    valid=lambda a,d:square(d*d+4*a),
    sample=lambda r:((w:=r.randint(1,100))*(w+(d:=r.randint(1,150))),d),
    constraints=('side_difference² + 4*minimum_area is a perfect square',))


def segment_sample(r):
    a,b,_=pythagorean_sample(r)
    x,y=r.randint(-200,200),r.randint(-200,200)
    return x,y,x+a,y-b


add(1489, 'distance_between_integer_points',
    coordinates((2,3),(7,15)),
    lambda x,y,u,v:f'Find the length of the segment with endpoints $({x},{y})$ and $({u},{v})$.',
    lambda *p:isqrt(edges2(*p)[0]),
    valid=lambda *p:edges2(*p)[0]>0 and square(edges2(*p)[0]),
    sample=segment_sample,
    constraints=('the endpoints are distinct and the squared distance is a perfect square',))


def prism_sample(r):
    a,b,c=r.choice(((1,2,2),(2,3,6),(3,4,12),(1,4,8),(4,4,7),(2,5,14),(2,10,11)))
    k=r.randint(1,80)
    dims=r.sample([a,b,c],3)
    return dims[0]*k,dims[1]*k,isqrt(a*a+b*b+c*c)*k


add(1523, 'prism_width_from_diagonal',
    (('length',3,1,1200),('height',12,1,1200),('diagonal',13,1,1300)),
    lambda a,b,d:rf'The diagonal of a rectangular prism with dimensions $l,w,h$ is $\sqrt{{l^2+w^2+h^2}}$. If $l={a}$, $h={b}$ and the diagonal is ${d}$, find $w$.',
    lambda a,b,d:isqrt(d*d-a*a-b*b),
    valid=lambda a,b,d:d*d>a*a+b*b and square(d*d-a*a-b*b),
    sample=prism_sample,
    constraints=('diagonal² - length² - height² is a positive perfect square',))
