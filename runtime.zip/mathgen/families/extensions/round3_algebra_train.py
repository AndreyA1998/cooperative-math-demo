"""Explicit remaining algebra/train bindings."""
from . import (
    round3_algebra_train_arithmetic,
    round3_algebra_train_equations,
    round3_algebra_train_functions,
    round3_algebra_train_geometry,
    round3_algebra_train_powers,
    round3_algebra_train_quadratics,
    round3_algebra_train_sequences,
)

_GROUPS = (
    round3_algebra_train_arithmetic,
    round3_algebra_train_equations,
    round3_algebra_train_functions,
    round3_algebra_train_geometry,
    round3_algebra_train_powers,
    round3_algebra_train_quadratics,
    round3_algebra_train_sequences,
)


def build(row):
    prefix = 'algebra/train/'
    problem_id = row['id']
    if not problem_id.startswith(prefix):
        return None
    number = int(problem_id[len(prefix):])
    for group in _GROUPS:
        factory = group.BINDINGS.get(number)
        if factory is not None:
            return factory()
    return None
