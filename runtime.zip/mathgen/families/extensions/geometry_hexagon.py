"""Explicit shape extension of the regular hexagon diagonal/perimeter problem.

The source has no numerical lengths. Fixing one side to 1 removes scale;
allowing the other two opposite-side pairs to vary relaxes regularity while
preserving central symmetry, all six 120-degree angles, and the ratio asked.
"""
from fractions import Fraction as F
from functools import lru_cache
from itertools import combinations

from .common import integer, is_square, sqrt_fraction, template


def longest_diagonal_squared(p):
    """The maximum of the three opposite-vertex squared distances (a=1)."""
    b, c = p['b'], p['c']
    return 1 + b*b + c*c + b + c + b*c - 2*min(b, c, b*c)


@lru_cache(maxsize=1)
def admissible_shapes():
    """Exhaustive finite square-diagonal domain; includes source normalization."""
    return tuple((b, c) for b in range(1, 31) for c in range(1, 31)
                 if is_square(longest_diagonal_squared(dict(b=b, c=c))))


def coordinate_reference(p):
    """Walk the six edges in Q(sqrt(3)), measure nine diagonals and six edges.

    A stored point (x,y) represents the Euclidean point (x,y*sqrt(3)).
    This calculation does not use the opposite-diagonal theorem or closed form.
    """
    half = F(1, 2)
    directions = [(1, 0), (half, half), (-half, half),
                  (-1, 0), (-half, -half), (half, -half)]
    lengths = [1, p['b'], p['c'], 1, p['b'], p['c']]
    walk = [(F(0), F(0))]
    for length, (dx, dy) in zip(lengths, directions):
        x, y = walk[-1]
        walk.append((x + length*dx, y + length*dy))
    if walk[-1] != walk[0]:
        raise ValueError('The hexagon must close')
    vertices = walk[:-1]

    def squared_distance(v, w):
        return (v[0]-w[0])**2 + 3*(v[1]-w[1])**2

    diagonal_squares = [squared_distance(vertices[i], vertices[j])
                        for i, j in combinations(range(6), 2) if j-i not in (1, 5)]
    perimeter = sum(sqrt_fraction(squared_distance(vertices[i], vertices[(i+1) % 6]))
                    for i in range(6))
    return sqrt_fraction(max(diagonal_squares)) / perimeter


def build(row):
    if row['id'] != 'geometry/test/133':
        return None
    return template(
        'extensions.geometry.equiangular_hexagon_ratio',
        {'b': integer(1, 30), 'c': integer(1, 30)},
        {'b': 1, 'c': 1},
        lambda p: (
            'A centrally symmetric convex hexagon has all six interior angles '
            f'equal to $120^\\circ$ and consecutive side lengths '
            f'$1, {p["b"]}, {p["c"]}, 1, {p["b"]}, {p["c"]}$. '
            'What is the ratio of the length of its longest diagonal to its '
            'perimeter? Express your answer as a common fraction.'
        ),
        lambda p: sqrt_fraction(longest_diagonal_squared(p)) / (2*(1+p['b']+p['c'])),
        valid=lambda p: is_square(longest_diagonal_squared(p)),
        sample=lambda rng: dict(zip(('b', 'c'), rng.choice(admissible_shapes()))),
        reference=coordinate_reference,
        constraints=[
            'b and c are integers from 1 through 30; the fixed first side 1 removes overall scale.',
            'The squared longest diagonal 1+b^2+c^2+b+c+bc-2*min(b,c,bc) must be a perfect square.',
            'Positive side lengths 1,b,c,1,b,c with successive 60-degree turns form a centrally symmetric convex hexagon.',
        ],
        adaptation=(
            'Explicit structural extension: regular is relaxed to centrally symmetric '
            'and equiangular, with consecutive sides 1,b,c,1,b,c. The source has no '
            'numerical side lengths; b=c=1 is only a scale normalization of its regular '
            'hexagon, not extracted source data. Varying b or c changes shape and the '
            'requested longest-diagonal/perimeter ratio. The number of sides and all '
            '120-degree angles stay fixed.'
        ),
    )
