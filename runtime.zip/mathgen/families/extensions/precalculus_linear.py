"""Linear algebra and finite exact minimization extensions."""
from fractions import Fraction as F
from functools import lru_cache
from math import isqrt
from .common import integer as I, integers as L, template
def T(name,*args,**kw):return template('extensions.precalculus.'+name,*args,**kw)
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def matrix_minimum(k):
    best=k+2
    for a in range(1,best//2+1):
        product=abs(k-a*a)
        if not product:continue
        for b in range(1,isqrt(product)+1):
            if product%b==0:best=min(best,2*a+b+product//b)
    return best
def matrix_minimum_reference(p):
    k=p['k']
    for total in range(4,k+3):
        for a in range(1,(total-2)//2+1):
            for b in range(1,total-2*a):
                c=total-2*a-b
                if a*a+b*c==k or a*a-b*c==k:return total
    raise AssertionError('Explicit witness provides an upper bound')
def tangent_norm_sample(r):
    u=[r.randint(-10,10) for _ in range(2)];v=[r.randint(-20,20) for _ in range(2)]
    if u==[0,0]:u=[1,0]
    d=F(dot(v,v)*dot(u,u)-dot(u,v)**2,dot(u,u))
    return dict(u=u,v=v,rnum=d.numerator,rden=d.denominator)
def homogeneous_solution(p):
    x=-F(p['b']-p['d'],p['a']-p['c']);y=-F(p['e']*x+p['g'],p['f'])
    return x/(y*y)
def homogeneous_valid(p):
    return p['a']!=p['c'] and p['f']!=0 and all(cross([p['a']-p['c'],0,p['b']-p['d']],[p['e'],p['f'],p['g']]))
def homogeneous_reference(p):
    v=cross([p['a']-p['c'],0,p['b']-p['d']],[p['e'],p['f'],p['g']])
    k=-F(p['a']*v[0]+p['b']*v[2],v[1])
    assert p['c']*v[0]+k*v[1]+p['d']*v[2]==0
    return F(v[0]*v[2],v[1]*v[1])
def prime(n):return n>=2 and all(n%d for d in range(2,isqrt(n)+1))
@lru_cache(None)
def coupled_powers():return tuple((a,b) for a in range(3,32,2) for b in range(3,32,2) if prime((a*b-1)//2))
def build(row):
    pid=row['id']
    if pid=='precalculus/train/7':
        return T('matrix_inverse_sum',{'b':I(-20,20),'c':I(-20,20),'k':I(1,100)},dict(b=1,c=-2,k=1),
          lambda p:rf"For real $a,d$, let $A=\begin{{pmatrix}}a&{p['b']}\\{p['c']}&d\end{{pmatrix}}$. If $A+{p['k']}A^{{-1}}=0$, find $\det A$.",
          lambda p:p['k'],valid=lambda p:p['b']*p['c']<=-p['k'],
          constraints=['b*c <= -k < 0, so real a=-d with a^2=-k-b*c exist; the off-diagonal inverse equation forces determinant k.'])
    if pid=='precalculus/train/79':
        return T('tangent_vector_norm',{'u':L(2,-20,20),'v':L(2,-30,30),'rnum':I(0,3000000),'rden':I(1,800)},dict(u=[2,-3],v=[4,7],rnum=52,rden=1),
          lambda p:rf"Find the real number $k$ with $\|k{tuple(p['u'])}-{tuple(p['v'])}\|=\sqrt{{{p['rnum']}/{p['rden']}}}$.",
          lambda p:F(dot(p['u'],p['v']),dot(p['u'],p['u'])),
          valid=lambda p:dot(p['u'],p['u'])>0 and F(p['rnum'],p['rden'])*dot(p['u'],p['u'])==dot(p['v'],p['v'])*dot(p['u'],p['u'])-dot(p['u'],p['v'])**2,
          sample=tangent_norm_sample,constraints=['u is nonzero; squared radius is the squared distance from v to span(u), giving exactly one real root.'])
    if pid=='precalculus/train/210':
        return T('cosine_grid_determinant',{'start':I(-180,180),'row_step':I(1,60),'col_step':I(1,60)},dict(start=1,row_step=3,col_step=1),
          lambda p:r"Find the determinant of $\begin{pmatrix}"+r"\\".join("&".join(rf"\cos({p['start']+i*p['row_step']+j*p['col_step']})" for j in range(3)) for i in range(3))+r"\end{pmatrix}$. All angles are in radians.",
          lambda p:0,constraints=['cos(alpha_i+beta_j) is a sum of two outer products, giving rank at most two.'])
    if pid=='precalculus/train/505':
        return T('integer_matrix_square_minimum',{'k':I(2,60)},dict(k=7),
          lambda p:rf"Let $A=\begin{{pmatrix}}a&b\\c&d\end{{pmatrix}}$ have nonzero integer entries and satisfy $A^2={p['k']}I$. Find the minimum of $|a|+|b|+|c|+|d|$.",
          lambda p:matrix_minimum(p['k']),reference=matrix_minimum_reference,
          constraints=['k >= 2; d=-a and bc=k-a^2 != 0. Witness (1,1,k-1,-1) bounds the minimum by k+2.'])
    if pid=='precalculus/train/718':
        return T('homogeneous_unknown_coefficient',{k:I(-20,20) for k in 'abcdefg'},dict(a=1,b=3,c=3,d=-2,e=2,f=4,g=-3),
          lambda p:rf"For some real $k$, the system $ {p['a']}x+ky+({p['b']})z=0$, $ {p['c']}x+ky+({p['d']})z=0$, $ {p['e']}x+({p['f']})y+({p['g']})z=0$ has a solution with $xyz\ne0$. Find $xz/y^2$.",
          homogeneous_solution,valid=homogeneous_valid,reference=homogeneous_reference,
          constraints=['a != c; f != 0; cross product of (a-c,0,b-d) and (e,f,g) has no zero coordinate. This determines one k and one solution direction.'])
    if pid=='precalculus/test/281':
        return T('common_line_plane_determinant',{'diagonal':I(1,40)},dict(diagonal=1),
          lambda p:rf"The planes $-{p['diagonal']}x+cy+bz=0$, $cx-{p['diagonal']}y+az=0$, $bx+ay-{p['diagonal']}z=0$ contain a common line. Find $a^2+b^2+c^2+2abc/{p['diagonal']}$.",
          lambda p:p['diagonal']**2,constraints=['Positive diagonal coefficient. Singularity forces the expression; a real configuration exists with a=diagonal,b=c=0.'],
          adaptation='The common diagonal coefficient and its determinant-induced cubic coefficient vary together.')
    if pid=='precalculus/test/367':
        def solve(p):return (p['a']*p['b']-1)//2
        def reference(p):
            q=solve(p);denoms={F(k,q).denominator for k in range(1,q)}
            assert len(denoms)==1
            return denoms.pop()
        return T('coupled_complex_powers',{'a':I(3,31),'b':I(3,31)},dict(a=13,b=11),
          lambda p:rf"Complex numbers satisfy $z^{{{p['a']}}}=w$ and $w^{{{p['b']}}}=z$. If $\operatorname{{Im}}z=\sin(m\pi/n)>0$, where $0<m<n$ and $m/n$ is reduced, find $n$.",
          solve,valid=lambda p:p['a']%2==p['b']%2==1 and prime(solve(p)),
          sample=lambda r:dict(zip(('a','b'),r.choice(coupled_powers()))),reference=reference,
          constraints=['a,b are odd; (a*b-1)/2 is prime, forcing the reduced angular denominator for each upper-half-plane root.'])
