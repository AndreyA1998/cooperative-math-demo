"""Conics, a weighted monomial extremum and Pascal-row reconstruction."""
from fractions import Fraction as F
from math import comb,gcd,isqrt,prod
from itertools import product
from mathgen.families.arithmetic import _root
from .common import integer,choice,is_square,sqrt_fraction,template

IDS=tuple('intermediate_algebra/'+s for s in ('train/224','train/925','train/994','test/7','test/216','test/487','test/584','test/851'))


def ellipse_parts(p):
    a,b,c,d,e=[p[k] for k in ('xx','yy','x','y','constant')]
    h,k=F(-c,2*a),F(-d,2*b)
    r=a*h*h+b*k*k-e
    return h,k,r/a,r/b


def ellipse_valid(p):
    _,_,a,b=ellipse_parts(p)
    return a>0 and b>0 and is_square(a) and is_square(b)


def ellipse_solve(p):
    h,k,a,b=ellipse_parts(p)
    return h+k+sqrt_fraction(a)+sqrt_fraction(b)


def ellipse_reference(p):
    a,b,c,d,e=[p[k] for k in ('xx','yy','x','y','constant')]
    h,k=F(-c,2*a),F(-d,2*b)
    dx=c*c-4*a*(b*k*k+d*k+e)
    dy=d*d-4*b*(a*h*h+c*h+e)
    return h+k+sqrt_fraction(dx)/(2*a)+sqrt_fraction(dy)/(2*b)


def ellipse_sample(r):
    a,b=r.randint(1,8)**2,r.randint(1,8)**2
    h,k=r.randint(-10,10),r.randint(-10,10)
    rhs=a*b*r.randint(1,4)**2
    return {'xx':a,'yy':b,'x':-2*a*h,'y':-2*b*k,'constant':a*h*h+b*k*k-rhs}


def hyperbola_eigenvalue(p):
    a,b,c=p['xx'],p['xy'],p['yy'];d=(a-c)**2+b*b
    if not is_square(d):raise ValueError('Nonrational eigenvalues')
    return F(a+c+isqrt(d),2)


def hyperbola_valid(p):
    a,b,c=p['xx'],p['xy'],p['yy']
    if b*b<=4*a*c:return False
    try:value=hyperbola_eigenvalue(p)
    except ValueError:return False
    return value>0 and is_square(F(p['rhs'],value))


def hyperbola_solve(p):
    return sqrt_fraction(F(p['rhs'],hyperbola_eigenvalue(p)))


def hyperbola_reference(p):
    lam=hyperbola_eigenvalue(p);a,b,c=p['xx'],p['xy'],p['yy']
    x,y=F(b),2*(lam-a)
    if x==y==0:x,y=F(1),F(0)
    assert a*x+b*y/2==lam*x and b*x/2+c*y==lam*y
    energy=a*x*x+b*x*y+c*y*y
    assert lam-a>=0 and lam-c>=0 and (lam-a)*(lam-c)==F(b*b,4)
    return sqrt_fraction(p['rhs']*(x*x+y*y)/energy)


def hyperbola_sample(r):
    u,v=r.randint(1,3),r.randint(0,3);a,b=r.randint(1,5),r.randint(1,5)
    return {'xx':a*u*u-b*v*v,'xy':2*(a+b)*u*v*r.choice((-1,1)),
            'yy':a*v*v-b*u*u,'rhs':a*(u*u+v*v)*r.randint(1,16)**2}


def monomial_scale(p):
    powers=[p[k] for k in ('x_power','y_power','z_power')];s=sum(powers)
    q=F(p['product']**2,prod(a**a for a in powers))
    return F(_root(q.numerator,s),_root(q.denominator,s))


def monomial_valid(p):
    try:k=monomial_scale(p)
    except ValueError:return False
    return k>0 and is_square(k*sum(p[n] for n in ('x_power','y_power','z_power')))


def monomial_solve(p):
    return sqrt_fraction(monomial_scale(p)*sum(p[n] for n in ('x_power','y_power','z_power')))


_MONOMIAL_POWERS=tuple(a for a in product(range(1,5),repeat=3)
    if is_square(sum(a)**sum(a)*prod(x**x for x in a)))


def monomial_sample(r):
    powers=r.choice(_MONOMIAL_POWERS);s=sum(powers);k=s*r.randint(1,5)**2
    return dict(zip(('x_power','y_power','z_power','product'),(*powers,isqrt(k**s*prod(a**a for a in powers)))))


def pascal_indices(p):
    a,b,c=p['first'],p['middle'],p['last'];d=b*b-a*c
    if d<=0:raise ValueError('Strict log-concavity required')
    k=F(2*a*c-b*b+a*b,d);n=k+F(b,a)*(k+1)
    return k,n


def pascal_valid(p):
    try:k,n=pascal_indices(p)
    except ValueError:return False
    return gcd(p['first'],p['middle'],p['last'])==1 and k.denominator==n.denominator==1 and 0<=k<=n-2 and 2<=n<=300


def pascal_solve(p):
    return pascal_indices(p)[1]


def pascal_sample(r):
    n=r.randint(2,300);k=r.randint(0,n-2)
    a,b,c=(k+1)*(k+2),(n-k)*(k+2),(n-k)*(n-k-1);d=gcd(a,b,c)
    return {'first':a//d,'middle':b//d,'last':c//d}


def pascal_reference(p):
    a,b,c=p['first'],p['middle'],p['last'];solutions=[]
    for n in range(2,301):
        k=F(a*n-b,a+b)
        if k.denominator!=1 or not 0<=k<=n-2:continue
        k=int(k);v=[comb(n,k+j) for j in range(3)]
        if b*v[0]==a*v[1] and c*v[1]==b*v[2]:solutions.append(n)
    assert len(solutions)==1
    return solutions[0]


def tangent_sample(r):
    major=r.randint(2,50);minor=r.randint(1,major-1);axis=r.choice((0,1))
    h,k=(minor,major) if axis else (major,minor)
    return {'center_x':h*r.choice((-1,1)),'center_y':k*r.choice((-1,1)),
            'focus_offset_squared':major*major-minor*minor,'vertical':axis}


def tangent_valid(p):
    h,k,d,v=[p[n] for n in ('center_x','center_y','focus_offset_squared','vertical')]
    return h!=0 and k!=0 and d==(k*k-h*h if v else h*h-k*k) and d>0


def tangent_render(p):
    h,k,d,v=[p[n] for n in ('center_x','center_y','focus_offset_squared','vertical')]
    foci=rf'({h},{k}\pm\sqrt{{{d}}})' if v else rf'({h}\pm\sqrt{{{d}}},{k})'
    return rf'An ellipse is tangent to both coordinate axes and has foci at ${foci}$. Find the length of its major axis.'


def build(row):
    key=row['id']
    if key==IDS[0]:
        return template('geometry.round3.ellipse_foci_covertex',
            {'focus_x':integer(-30,30),'focus_y1':integer(-60,60),'focus_y2':integer(-60,60),
             'point_x':integer(-60,60),'point_y':integer(-30,30)},
            {'focus_x':-1,'focus_y1':-1,'focus_y2':-3,'point_x':4,'point_y':-2},
            lambda p:rf'An ellipse has foci $({p["focus_x"]},{p["focus_y1"]})$ and $({p["focus_x"]},{p["focus_y2"]})$ and passes through $({p["point_x"]},{p["point_y"]})$. Its equation is $(x-h)^2/a^2+(y-k)^2/b^2=1$, with $a,b>0$. Find $a+k$.',
            lambda p:abs(p['point_x']-p['focus_x'])+F(p['focus_y1']+p['focus_y2'],2),
            valid=lambda p:p['focus_y1']!=p['focus_y2'] and 2*p['point_y']==p['focus_y1']+p['focus_y2'] and p['point_x']!=p['focus_x'],
            sample=lambda r:(lambda h,k,c,d:{'focus_x':h,'focus_y1':k+c,'focus_y2':k-c,'point_x':h+d,'point_y':k})(r.randint(-20,20),r.randint(-20,20),r.randint(1,30),r.choice(tuple(range(-30,0))+tuple(range(1,31)))),
            constraints=('Foci are distinct and vertical; the given point is horizontally aligned with their midpoint and is not that midpoint.',))
    if key==IDS[1]:
        return template('geometry.round3.ellipse_tangent_axes',
            {'center_x':integer(-50,50),'center_y':integer(-50,50),'focus_offset_squared':integer(1,2500),'vertical':choice((0,1))},
            {'center_x':2,'center_y':-3,'focus_offset_squared':5,'vertical':1},tangent_render,
            lambda p:2*abs(p['center_y'] if p['vertical'] else p['center_x']),
            valid=tangent_valid,sample=tangent_sample,
            constraints=('Both center coordinates are nonzero; the specified squared focal offset equals the squared major semiaxis minus the squared minor semiaxis forced by tangency.',))
    if key==IDS[2]:
        return template('geometry.round3.pascal_ratio_row',
            {k:integer(1,100000) for k in ('first','middle','last')},
            {'first':3,'middle':4,'last':5},
            lambda p:f"In which row of Pascal's triangle do three consecutive entries have ratio ${p['first']}:{p['middle']}:{p['last']}$? The top single-entry row is row 0.",
            pascal_solve,valid=pascal_valid,sample=pascal_sample,reference=pascal_reference,
            constraints=('The three ratios are primitive, strictly log-concave and yield an integer index and row with 0<=index<=row-2 and 2<=row<=300.',))
    if key==IDS[3]:
        return template('geometry.round3.hyperbola_distance',
            {'xx':integer(-50,50),'xy':integer(-200,200),'yy':integer(-50,50),'rhs':integer(1,50000)},
            {'xx':1,'xy':8,'yy':7,'rhs':225},
            lambda p:rf'Let $P$ lie on the hyperbola $({p["xx"]})x^2+({p["xy"]})xy+({p["yy"]})y^2={p["rhs"]}$. Find its minimum distance from the origin.',
            hyperbola_solve,valid=hyperbola_valid,sample=hyperbola_sample,reference=hyperbola_reference,
            constraints=('The quadratic form is indefinite; its eigenvalue discriminant is a perfect square and RHS divided by its positive eigenvalue is a positive rational square.',))
    if key==IDS[4]:
        return template('geometry.round3.monomial_distance',
            {'x_power':integer(1,4),'y_power':integer(1,4),'z_power':integer(1,4),'product':integer(1,10**24)},
            {'x_power':1,'y_power':1,'z_power':2,'product':2},
            lambda p:rf'For positive real coordinates $x,y,z$ satisfying $x^{{{p["x_power"]}}}y^{{{p["y_power"]}}}z^{{{p["z_power"]}}}={p["product"]}$, find the minimum distance from $(x,y,z)$ to the origin.',
            monomial_solve,valid=monomial_valid,sample=monomial_sample,
            constraints=('Writing s as the sum of the exponents, product² divided by the product of exponent**exponent must be an exact positive rational s-th power k, and s*k must be a rational square.',),
            adaptation='Generalize the monomial exponents. Restrict coordinates to the positive octant; for the original xy*z²=2, absolute values preserve the equation and distance, so the minimum is unchanged.')
    if key in IDS[5:7]:
        source=(4,16,-16,96,144) if key==IDS[5] else (9,4,-54,40,145)
        return template('geometry.round3.ellipse_coefficient_sum',
            {'xx':integer(1,64),'yy':integer(1,64),'x':integer(-2000,2000),'y':integer(-2000,2000),'constant':integer(-100000,100000)},
            dict(zip(('xx','yy','x','y','constant'),source)),
            lambda p:rf'Rewrite ${p["xx"]}x^2+{p["yy"]}y^2+({p["x"]})x+({p["y"]})y+({p["constant"]})=0$ as $(x-h)^2/a^2+(y-k)^2/b^2=1$, with $a,b>0$. Find $h+k+a+b$.',
            ellipse_solve,valid=ellipse_valid,sample=ellipse_sample,reference=ellipse_reference,
            constraints=('Completing both squares gives a positive right-hand side and both squared semiaxes are rational squares.',))
    if key==IDS[7]:
        return template('geometry.round3.ellipse_focal_circle',
            {'horizontal_scale':integer(1,100),'vertical_scale':integer(1,100),'center_x':integer(-30,30),'center_y':integer(-30,30)},
            {'horizontal_scale':1,'vertical_scale':1,'center_x':0,'center_y':0},
            lambda p:rf'An ellipse has equation $k(x-({p["center_x"]}))^2/{p["horizontal_scale"]}+(y-({p["center_y"]}))^2/{p["vertical_scale"]}=1$, where $k>{p["horizontal_scale"]}/{p["vertical_scale"]}$. A circle passes through both foci and is tangent to the ellipse at its two intersections with $y={p["center_y"]}$. Find $k$.',
            lambda p:F(2*p['horizontal_scale'],p['vertical_scale']),
            adaptation='Allow positive axis-denominator scales and a translated center; use the horizontal centerline instead of the x-axis. Unit scales and zero center recover the source.')
    return None
