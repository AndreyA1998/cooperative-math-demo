"""Exact evaluations, inverse operation chains, and rounding."""

from fractions import Fraction as F
from functools import partial
from math import isqrt, prod
from .word_common import PRE, add, decimal, rounded

CASES={}
pre=partial(add,CASES,PRE)


def frac(n,d):
    return r'\frac{'+str(n)+'}{'+str(d)+'}'


for suffix,ns,ds,operation in (
    ('train/275',[3,1],[4,8],'minus'),('train/731',[7,4],[17,51],'minus'),
    ('train/863',[9,5],[10,6],'plus'),('test/125',[3,1],[4,8],'plus'),
    ('train/808',[4,9],[3,2],'times'),('train/1182',[8,1],[1,8],'divided by'),
    ('train/1005',[1,2,3],[2,3,4],'times'),('test/631',[1,1,1],[2,3,4],'reciprocal'),
    ('test/82',[1,1,9000],[2,100,1],'times'),('train/149',[1,1,1,60],[3,4,5,1],'times'),
):
    def render(*args,op=operation,ds=ds):
        values=[f'${frac(n,d) if d!=1 else n}$' for n,d in pairs(args,ds)]
        if op=='reciprocal':
            return 'What is the reciprocal of the sum of '+', '.join(values)+'?'
        return 'Compute '+f' {op} '.join(values)+'. Give your answer as a simplified fraction.'

    def solve(*args,op=operation,ds=ds):
        values=[F(n,d) for n,d in pairs(args,ds)]
        if op=='plus':return sum(values)
        if op=='minus':return values[0]-values[1]
        if op=='times':return prod(values)
        if op=='reciprocal':return 1/sum(values)
        return values[0]/values[1]

    fields={}
    for i,(n,d) in enumerate(zip(ns,ds),1):
        fields[f'numerator_{i}']=(n,1,max(30,n*2))
        if d!=1:
            fields[f'denominator_{i}']=(d,2,max(25,d*2))
    pre(suffix,'fraction-arithmetic',fields,render,solve)


def pairs(args,ds):
    it=iter(args)
    return [(next(it),next(it) if d!=1 else 1) for d in ds]


for suffix,fields,text,solve in (
    ('train/218',dict(unit=(4,2,25),n=(7,1,40),d=(2,2,20)),
     lambda k,n,d:f'How many copies of ${frac(1,k)}$ make ${frac(n,d)}$?',lambda k,n,d:F(n*k,d)),
    ('train/408',dict(n=(5,1,12),d=(6,2,25),number=(30,2,180)),
     lambda n,d,x:f'What is ${frac(n,d)}$ of {x}?',lambda n,d,x:F(n*x,d)),
    ('train/901',dict(d=(3,2,18),tenths=(54,11,1500)),
     lambda d,t:f'Find ${frac(1,d)}$ of {decimal(t,1)} as a simplified fraction.',lambda d,t:F(t,10*d)),
    ('train/468',dict(hundredths=(224,101,1399)),
     lambda n:f'Write {decimal(n,2)} as a simplified fraction.',lambda n:F(n,100)),
    ('train/799',dict(a=(2,2,10),b=(7,2,15),c=(3,2,10),d=(5,2,12),value=(90,10,240)),
     lambda a,b,c,d,v:f'${frac(1,a)}$ of ${frac(1,b)}$ of T equals ${frac(1,c)}$ of ${frac(1,d)}$ of {v}. What is T?',lambda a,b,c,d,v:F(a*b*v,c*d)),
    ('test/472',dict(value=(10,2,45),n=(2,1,16),d=(3,2,18)),
     lambda x,n,d:f'Remmy wants to divide {x} by ${frac(n,d)}$. What number should he multiply {x} by to get the same result?',lambda x,n,d:F(d,n)),
    ('train/161',dict(divisor=(4,2,16),a=(6,2,30),b=(8,2,30)),
     lambda d,a,b:f'Find ${frac(1,d)}$ of the product of {a} and {b}.',lambda d,a,b:F(a*b,d)),
):
    pre(suffix,'fraction-operations',fields,text,solve)


pre('train/441','mixed-fraction-inverse',dict(whole=(1,1,4),n=(1,1,5),d=(2,2,10),result=(30,3,150)),
    lambda a,b,c,z:f'What number becomes {z} when multiplied by the mixed number ${a}{frac(b,c)}$?',
    lambda a,b,c,z:F(z*c,a*c+b),
    check=lambda a,b,c,z:b<c,draw=lambda r:(lambda d:(r.randint(1,4),r.randint(1,min(d-1,5)),d,r.randint(3,150)))(r.randint(2,10)),
    constraint='The fractional part is strictly between zero and one.')


for suffix,values,scales,places,op in (
    ('train/200',[33333,11111],[2,2],2,'subtract'),
    ('train/256',[8176,34587],[2,3],1,'add'),
    ('train/682',[3689753],[5],1,'single'),
    ('train/778',[184851],[4],2,'single'),
    ('train/1129',[53463,129873],[3,4],3,'add'),
    ('test/587',[26,52],[0,0],-1,'add'),
    ('test/791',[54355,2523,29998],[2,2,2],1,'round-first'),
    ('test/347',[3,3],[1,3],3,'fraction-add'),
):
    fields={k:(v,1,1000*10**s) for k,v,s in zip('abc',values,scales)}
    labels={-1:'ten',1:'tenth',2:'hundredth',3:'thousandth'}

    def render(*args,scales=scales,places=places,op=op):
        ds=[f'${frac(v,10**s)}$' if op=='fraction-add' else decimal(v,s) for v,s in zip(args,scales)]
        p=labels[places]
        if op=='single':return f'Round {ds[0]} to the nearest {p}.'
        if op=='round-first':return f'Round each number to the nearest {p} and add the results: '+', '.join(ds)+'.'
        if op=='subtract':return f'Subtract {ds[1]} from {ds[0]} and round to the nearest {p}.'
        return f'Add {ds[0]} and {ds[1]} and round to the nearest {p}.'

    def solve(*args,scales=scales,places=places,op=op):
        ds=[F(v,10**s) for v,s in zip(args,scales)]
        if op=='round-first':return sum(rounded(x,places) for x in ds)
        return rounded(ds[0]-ds[1] if op=='subtract' else sum(ds),places)

    pre(suffix,'rounding',fields,render,solve,adaptation='Exact ties round away from zero.')


for suffix,values,scales,difference in (
    ('test/390',[78,12,133,1328],[2,2,2,3],True),
    ('test/586',[45,445,45,54],[1,2,2,2],False),
):
    pre(suffix,'decimal-extremes',
        {k:(x,1,10**s*10) for k,x,s in zip('abcd',values,scales)},
        lambda *xs,s=scales,d=difference:'Find the '+('difference between' if d else 'sum of')+' the largest and smallest of: '+', '.join(decimal(x,p) for x,p in zip(xs,s))+'.',
        lambda *xs,s=scales,d=difference:(lambda xs:max(xs)+(-1 if d else 1)*min(xs))([F(x,10**p) for x,p in zip(xs,s)]))


pre('test/153','rounding-open-interval',
    dict(lower=(274,1,1999),upper=(275,2,2000)),
    lambda a,b:f'Rebecca is thinking of a number strictly between {decimal(a,2)} and {decimal(b,2)}. What does her number round to, to the nearest tenth?',
    lambda a,b:rounded(F(a+b,200),1),
    check=lambda a,b:a<b and not any(a<k<b for k in range(5,2001,10)),
    draw=lambda r:(lambda threshold:(threshold-r.randint(1,7),threshold))(r.randrange(15,1996,10)),
    constraint='The ordered open interval contains no halfway threshold between consecutive tenths.')


pre('test/163','rounded-decimal-product',
    dict(a=(100000198,1,180000000),b=(59999985401,1,120000000000),c=(69999852,1,120000000)),
    lambda a,b,c:f'What is ${decimal(a,7)}\\cdot {decimal(b,10)}\\cdot {decimal(c,7)}$ to the nearest whole number?',
    lambda a,b,c:rounded(F(a*b*c,10**24)))


for suffix,fields,text,solve in (
    ('train/89',dict(offset=(2,1,25),multiplier=(3,2,12),result=(20,3,180)),
     '{offset} more than {multiplier} times $B$ is {result}. What is $B$?',lambda b,m,y:F(y-b,m)),
    ('train/142',dict(multiplier=(2,2,12),offset=(3,1,25),divisor=(5,2,12),result=(11,-18,30)),
     'If $x$ is multiplied by {multiplier}, increased by {offset}, and divided by {divisor}, the result is {result}. What is $x$?',lambda m,b,d,y:F(d*y-b,m)),
    ('train/442',dict(offset=(27,1,80),multiplier=(2,2,12),result=(39,3,180)),
     '{offset} increased by {multiplier} times a number is {result}. What is the number?',lambda b,m,y:F(y-b,m)),
    ('train/454',dict(add=(2,1,30),multiplier=(2,2,12),subtract=(2,1,30),divisor=(2,2,12),result=(7,-30,60)),
     'Juan adds {add} to a number, multiplies by {multiplier}, subtracts {subtract}, and divides by {divisor}. The result is {result}. What was his number?',lambda a,m,b,d,y:F(d*y+b,m)-a),
    ('train/929',dict(multiplier=(2,2,12),offset=(10,1,30),last_multiplier=(4,2,12),result=(120,10,450)),
     'Pete multiplies a number by {multiplier}, adds {offset}, then multiplies by {last_multiplier}. He ends with {result}. What was his number?',lambda m,b,d,y:(F(y,d)-b)/m),
    ('train/986',dict(multiplier=(2,2,12),divisor=(5,2,12),result=(10,-20,45)),
     'A number $y$ is multiplied by {multiplier} and then divided by {divisor}. The result is {result}. What is $y$?',lambda m,d,y:F(d*y,m)),
    ('train/1109',dict(divisor=(2,2,12),subtract=(2,1,30)),
     'Dividing a number by {divisor} gives the same result as subtracting {subtract} from it. What is the number?',lambda d,b:F(d*b,d-1)),
    ('test/404',dict(multiplier=(3,2,12),offset=(7,1,30),result=(-8,-60,60)),
     'If $x$ is multiplied by {multiplier} and then increased by {offset}, the result is {result}. What is $x$?',lambda m,b,y:F(y-b,m)),
    ('test/617',dict(multiplier=(2,2,12),offset=(7,1,30),result=(81,20,150)),
     'If $x$ is multiplied by {multiplier} and then increased by {offset}, the result is {result}. What is $x$?',lambda m,b,y:F(y-b,m)),
    ('test/557',dict(multiplier=(2,2,12),offset=(10,1,40)),
     'When $A$ is multiplied by {multiplier}, the new value is {offset} more than $A$. What is $A$?',lambda m,b:F(b,m-1)),
    ('train/145',dict(first_divisor=(2,2,12),second_divisor=(5,2,12),value=(60,20,500)),
     'The value of $x$ is $y$ divided by {first_divisor}, and $y$ is $z$ divided by {second_divisor}. If $z={value}$, what is $x$?',lambda a,b,z:F(z,a*b)),
    ('train/780',dict(first=(5,1,30),second=(10,1,30),third=(20,1,30),base=(80,1,100)),
     'Suppose $x=y+{first}$, $y=z+{second}$, $z=w+{third}$, and $w={base}$. What is $x$?',lambda a,b,c,w:a+b+c+w),
    ('train/169',dict(start=(2007,30,9000),first=(3,2,20),second=(3,2,20)),
     'Let $M={start}/{first}$ and $N=M/{second}$. What is $M-N$?',lambda a,b,c:F(a,b)-F(a,b*c)),
):
    pre(suffix,'affine-operation-chain',fields,text,solve)


for suffix,a,b,c,neg,text in (
    ('test/74',5,2,21,False,'{left} times a number equals {offset} plus {right} times the original number. What is it?'),
    ('test/569',6,1,20,True,'Multiplying a negative number by {left} gives {offset} less than {right} times the original number. What is it?'),
):
    pre(suffix,'affine-equivalence',dict(left=(a,2,14),right=(b,1,14),offset=(c,1,60)),
        text,lambda a,b,c,n=neg:F(-c if n else c,a-b),
        check=lambda a,b,c:a>b,
        draw=lambda r:(lambda a:(a,r.randint(1,a-1),r.randint(1,60)))(r.randint(2,14)),
        constraint='The multiplier on the left exceeds the one on the right.')


pre('test/418','affine-equivalence',
    dict(left=(5,2,14),right=(10,2,14),offset_left=(10,1,50),offset_right=(5,1,50)),
    '{offset_left} more than {left} times a number equals {offset_right} more than {right} times the number. What is it?',
    lambda a,b,c,d:F(c-d,b-a),
    check=lambda a,b,c,d:a!=b,draw=lambda r:(*r.sample(range(2,15),2),r.randint(1,50),r.randint(1,50)),
    constraint='The multipliers differ, so the equation has a unique solution.')


pre('test/366','inverse-integer-affine',dict(add=(5,1,50),multiplier=(4,2,16),result=(277,-1500,1700)),
    '{add} is added to {multiplier} times an integer to get {result}. What was the integer?',
    lambda a,m,y:(y-a)//m,
    check=lambda a,m,y:(y-a)%m==0,
    draw=lambda r:(lambda a,m,x:(a,m,m*x+a))(r.randint(1,50),r.randint(2,16),r.randint(-80,90)),
    constraint='Subtracting the offset from the result gives a multiple of the multiplier.')


for suffix,fields,text,solve in (
    ('train/55',dict(a=(5,2,15),b=(4,2,15),p=(3,2,6)),'Evaluate $({a}^2-{b}^2)^{p}$.',lambda a,b,p:(a*a-b*b)**p),
    ('train/413',dict(x=(-7,-30,30),a=(4,1,20),b=(4,1,20)),
     'If $x^2+x+{a}=y-{b}$ and $x={x}$, what is $y$?',lambda x,a,b:x*x+x+a+b),
    ('train/573',dict(x=(-5,-30,30),offset=(3,1,45)),
     'If $x^2=y-{offset}$ and $x={x}$, what is $y$?',lambda x,a:x*x+a),
    ('train/422',dict(n=(10,1,30),d=(4,2,30),value=(18,1,60)),
     r'Given $\frac{{x}}{{y}}=\frac{{{n}}}{{{d}}}$ and $y={value}$, what is $x$?',lambda n,d,y:F(y*n,d)),
    ('train/423',dict(a=(8,1,30),b=(6,1,30),x=(2,1,12),y=(3,1,12)),
     r'Evaluate $\frac{{{a}xy^2}}{{{b}x^2y}}$ when $x={x}$ and $y={y}$.',lambda a,b,x,y:F(a*y,b*x)),
    ('train/476',dict(a=(3,1,20),b=(-2,-15,-1),c=(2,1,20)),
     r'If ${a}({b})=\nabla+{c}$, what is $\nabla$?',lambda a,b,c:a*b-c),
    ('train/490',dict(a=(5,1,30),b=(4,1,30)),
     r'What is $(a^3+b^3)\div(a^2-ab+b^2)$ when $a={a}$ and $b={b}$?',lambda a,b:a+b),
    ('train/1048',dict(c=(3,2,7)),
     r'Evaluate $\left(c^c-c(c-1)^c\right)^c$ when $c={c}$.',lambda c:(c**c-c*(c-1)**c)**c),
    ('test/461',dict(n=(5321,2,9999)),r'Compute $\left(-\sqrt{{{n}}}\right)^2$.',lambda n:n),
    ('train/818',dict(a=(2,1,12),offset=(1,1,20),right=(1,-20,50),difference=(1,-20,25)),
     'If ${a}a+{offset}={right}$ and $b-a={difference}$, what is $b$?',lambda a,b,c,d:F(c-b,a)+d),
    ('train/937',dict(n=(4,1,15),d=(3,2,15),result=(12,1,100)),
     lambda n,d,y:f'The sum of $r,s,t$ multiplied by ${frac(n,d)}$ equals {y}. What is their average?',lambda n,d,y:F(y*d,3*n)),
):
    pre(suffix,'exact-evaluation',fields,text,solve)


pre('train/352','positive-square-root',dict(square=(729,4,10000)),
    'If $x$ is positive and $x^2={square}$, what is $x$?',isqrt,
    check=lambda n:isqrt(n)**2==n,draw=lambda r:(r.randint(2,100)**2,),
    constraint='The right-hand side is a perfect square.')


pre('train/396','square-root-of-powers',dict(a=(2,2,16),b=(3,2,16),m=(2,2,12),n=(4,2,12)),
    r'Compute $\sqrt{{{a}^{{{m}}}\cdot {b}^{{{n}}}}}$.',lambda a,b,m,n:isqrt(a**m*b**n),
    check=lambda a,b,m,n:isqrt(a**m*b**n)**2==a**m*b**n,
    draw=lambda r:(r.randint(2,16),r.randint(2,16),2*r.randint(1,6),2*r.randint(1,6)),
    constraint='The radicand is a perfect square.')


pre('test/637','positive-power-difference',dict(a=(2,2,12),b=(5,2,12)),
    'What is the positive difference between ${a}^{{{b}}}$ and ${b}^{{{a}}}$?',lambda a,b:abs(a**b-b**a),
    check=lambda a,b:a**b!=b**a,draw=lambda r:tuple(r.sample(range(5,13),2)),
    constraint='The two powers differ.')


pre('train/449','linear-fraction-coefficients',
    dict(a=(4,1,200),b=(8,1,200),divisor=(4,2,15)),
    r'The expression $\frac{{{a}k+{b}}}{{{divisor}}}$ simplifies to $Ak+B$, where $A,B$ are integers. Find $A/B$.',
    lambda a,b,d:F(a,b),check=lambda a,b,d:a%d==0 and b%d==0,
    draw=lambda r:(lambda d:(d*r.randint(1,12),d*r.randint(1,12),d))(r.randint(2,15)),
    constraint='The divisor divides both numerator coefficients.')


for suffix,x,m,b,n,c in (('train/1033',-3,-1,2,4,7),('test/414',8,2,2,1,-21)):
    pre(suffix,'linked-affine-values',
        dict(x=(x,-50,80),x_scale=(m,-10,-1) if m<0 else (m,1,10),x_offset=(b,0,20),
             y_scale=(n,1,12),y_offset=(c,-25,25)),
        lambda x,m,b,n,c:f'Suppose $x={b}{m:+}t$ and $y={n}t{c:+}$. If $x={x}$, what is $y$?',
        lambda x,m,b,n,c:n*F(x-b,m)+c)
