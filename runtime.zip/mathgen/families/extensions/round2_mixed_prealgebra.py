"""Additional prealgebra bindings keyed by reviewed source IDs."""
from fractions import Fraction as Q
from itertools import product
from math import factorial, gcd, isqrt, prod
from .common import choice, integer, integers, is_square, sqrt_fraction, template

BINDINGS = {}


def add(key, name, domains, original, render, solve, *, valid=None, constraint='', sample=None, reference=None, adaptation='', bindings=BINDINGS):
    keys = tuple(domains)
    bounds = {k:integer(*d) if isinstance(d,tuple) else d for k,d in domains.items()}
    def unpack(fn):
        return lambda p:fn(*(p[k] for k in keys))
    if valid is not None and sample is None:
        axes = [d['choices'] if 'choices' in d else range(d['min'], d['max']+1) for d in bounds.values()]
        accepted = []
        def sample(rng):
            if not accepted:
                accepted.extend(row for row in product(*axes) if valid(*row))
            return rng.choice(accepted)
    kwargs = {}
    if valid is not None:
        kwargs['valid'] = unpack(valid)
    if sample is not None:
        kwargs['sample'] = lambda rng:dict(zip(keys,sample(rng)))
    if reference is not None:
        kwargs['reference'] = unpack(reference)
    bindings[key] = template('round2_'+name,bounds,dict(zip(keys,original)),unpack(render),unpack(solve),
                             constraints=[constraint] if constraint else [],adaptation=adaptation,**kwargs)


def prime(n):
    return n>1 and all(n%d for d in range(2,isqrt(n)+1))


def pairs(n):
    return [(d,n//d) for d in range(1,isqrt(n)+1) if n%d==0]


def square(lo,hi):
    return choice(i*i for i in range(lo,hi+1))


def least_gap(g):
    return 2*(g+2) if prime(g+1) else g+1


def factor_count(n):
    return sum(n%d==0 and prime(d) for d in range(2,n+1))


def count_prime_power(p,q,n):
    counts = []
    for b in (p,q):
        e = 0
        while n%b==0:
            e+=1
            n//=b
        counts.append(e)
    return counts,n


def sample_prime_power(r):
    p,q=sorted(r.sample([2,3,5,7],2))
    return p,q,p**r.randint(1,6)*q**r.randint(1,6)


def radical_product(r,n):
    nodes=r.sample(range(2,16),n)
    return ([a*b for a,b in zip(nodes,nodes[1:]+nodes[:1])],)


def middle(n):
    return next(m for m in range(2,31) if m*(m*m-1)==n)


PI_LO, PI_HI = Q(103993,33102), Q(104348,33215)
def pi_floor(k):
    lo,hi=k*PI_LO,k*PI_HI
    return lo.__floor__() if lo.__floor__()==hi.__floor__() else None


def suffix(prefix,divisor):
    return [i for i in range(1,10) if (10*prefix+i)%divisor==0]


def smallest_prime_factor(n):
    return next((d for d in range(2,isqrt(n)+1) if n%d==0),n)


add('test/136','other_square_root',{'number':(2,200)},(15,),
    lambda n:f'The square of {n} is {n*n}. The square of what other number is {n*n}?',lambda n:-n)
add('test/196','power_minus_offset',{'base':(2,12),'offset':(1,20),'rhs':(1,12**7)},(10,10,9990),
    lambda b,c,n:f'If ${b}^x-{c}={n}$, what is $x$?',lambda b,c,n:next(e for e in range(2,8) if b**e==n+c),
    valid=lambda b,c,n:n+c in [b**e for e in range(2,8)],
    sample=lambda r:(lambda b,e,c:(b,c,b**e-c))(r.randint(4,12),r.randint(2,7),r.randint(1,15)),
    constraint='The sum of the offset and RHS is a power of the base with exponent 2 to 7.')
add('test/207','opposite_odd_powers',{'magnitude':(2,50),'iterations':(2,50),'odd_power':choice((3,5,7)),'small_1':choice((-1,0,1)),'small_2':choice((-1,0,1))},(2,20,3,1,1),
    lambda a,n,e,u,v:f'Four players start with {u}, {v}, {a}, and {-a}. Each replaces their number by its {e}th power {n} times. What is the sum of their final numbers?',lambda a,n,e,u,v:u+v)
add('test/212','nested_radical_sum',{'outer_addend':(1,500),'inner_radicand':square(2,50)},(28,1296),
    lambda a,b:rf'Simplify $\sqrt{{{a}+\sqrt{{{b}}}}}$.',lambda a,b:isqrt(a+isqrt(b)),
    valid=lambda a,b:is_square(a+isqrt(b)),constraint='The outer radicand is a perfect square.')
add('test/26','strict_multiple_bounds',{'divisor':(2,25),'lower_bound':(650,2500),'exponent':(2,4)},(11,1000,2),
    lambda d,l,e:f'Let $x$ be the smallest multiple of {d} greater than {l} and $y$ the greatest multiple of {d} less than ${d}^{e}$. Compute $x-y$.',
    lambda d,l,e:d*(l//d+2)-d**e,
    reference=lambda d,l,e:next(n for n in range(l+1,l+d+1) if n%d==0)-(d**e-d))
for key, fs in [('test/261',[5,10,14,21,15,20]),('test/63',[10,15,24]),('test/658',[15,35,21]),('test/704',[30,21,70]),('test/730',[3,6,10,15,21,28])]:
    add(key,'radical_product',{'factors':integers(len(fs),2,300)},(fs,),
        lambda a:r'Evaluate $\sqrt{'+r'\cdot'.join(map(str,a))+'}$.',
        lambda a:isqrt(prod(a)),valid=lambda a:is_square(prod(a)),
        sample=lambda r,n=len(fs):radical_product(r,n),
        constraint='The product of the positive factors is a perfect square.')
add('test/279','least_composite_factor_gap',{'factor_gap':(1,120)},(10,),
    lambda g:f'Let $n$ be the smallest composite number which is the product of two positive integers differing by {g}. How many distinct prime factors does $n$ have?',
    lambda g:factor_count(least_gap(g)),
    reference=lambda g:factor_count(next(n for n in range(4,2*(g+2)+1) if not prime(n) and any(b-a==g for a,b in pairs(n)))))
add('test/313','prime_exponents',{'first_prime':choice((2,3,5,7)),'second_prime':choice((2,3,5,7)),'product':(6,35**6)},(2,3,1296),
    lambda p,q,n:f'If $x,y$ are positive integers and ${p}^x{q}^y={n}$, find $x+y$.',
    lambda p,q,n:sum(count_prime_power(p,q,n)[0]),
    valid=lambda p,q,n:p<q and count_prime_power(p,q,n)[1]==1 and all(1<=e<=6 for e in count_prime_power(p,q,n)[0]),
    sample=sample_prime_power,constraint='The primes increase and their exponents in the product both lie in 1–6.')
add('test/333','radical_quotient',{'first_square':square(2,65),'second_square':square(1,64)},(25,16),
    lambda a,b:rf'What is $\frac{{\sqrt{{{a}-{b}}}}}{{\sqrt{{{a}}}-\sqrt{{{b}}}}}$?',lambda a,b:Q(isqrt(a-b),isqrt(a)-isqrt(b)),
    valid=lambda a,b:a>b and is_square(a-b),constraint='The difference is a positive perfect square.')
add('test/352','inverse_powers',{'base':(2,150),'power':(1,9),'coefficient':(1,40),'first_addend':(1,8),'second_addend':(1,8),'subtrahend':(1,16)},(42,4,2,2,1,3),
    lambda a,e,k,b,c,d:rf'Calculate $(\frac1a)^{e}\cdot {k}\cdot a^{e}+a^{{{b}+{c}-{d}}}$ when $a={a}$.',
    lambda a,e,k,b,c,d:k+Q(a)**(b+c-d))
add('test/355','scientific_notation',{'significand_hundredths':(101,999),'integer_value':(101,99900000)},(821,8210),
    lambda m,n:rf'If ${n}={m//100}.{m%100:02d}\times10^{{\square}}$, what goes in the square?',lambda m,n:len(str(n))-1,
    valid=lambda m,n:n in [m*10**k for k in range(6)],
    sample=lambda r:(lambda m:(m,m*10**r.randint(0,5)))(r.randint(101,999)),
    constraint='The integer is the three significand digits followed by zero to five zeros.')
add('test/371','alternating_prefix',{'last_exponent':(5,5000)},(2011,),
    lambda n:rf'Let $x=-1$. Find $x+x^2+x^3+\cdots+x^{{{n-1}}}+x^{{{n}}}$.',lambda n:-(n%2),
    reference=lambda n:sum((-1)**i for i in range(1,n+1)))
OHARA=r"Three positive integers form an O'Hara triple $(a,b,x)$ when $\sqrt a+\sqrt b=x$."
add('test/382','ohara_missing_square',{'second_radicand':square(1,30),'total':(2,65)},(9,5),
    lambda b,x:OHARA+f" If $(a,{b},{x})$ is an O'Hara triple, determine $a$.",lambda b,x:(x-isqrt(b))**2,
    valid=lambda b,x:x>isqrt(b),constraint='The total exceeds the known square root.')
add('train/411','ohara_total',{'first_radicand':square(1,40),'second_radicand':square(1,40)},(36,25),
    lambda a,b:OHARA+f" If $({a},{b},x)$ is an O'Hara triple, determine $x$.",lambda a,b:isqrt(a)+isqrt(b))
for key, m in [('test/451',5),('train/230',6)]:
    add(key,'consecutive_product',{'product':choice(i*(i*i-1) for i in range(2,31))},(m*(m*m-1),),
        lambda n,key=key:(f'The product of three consecutive integers is {n}. That product divided by their mean is {n//middle(n)}. What is the largest integer?' if key=='test/451' else f'The product of three consecutive integers is {n}. What is their sum?'),
        lambda n,key=key:middle(n)+1 if key=='test/451' else 3*middle(n))
for key, base, b, e in [('test/463',1,2,235423523),('test/744',0,5,6431564)]:
    add(key,'constant_base_power',{'outer_base':choice((0,1)),'exponent_base':(2,12),'exponent_power':(100,300000000)},(base,b,e),
        lambda a,b,e:f'What is ${a}^{{({b}^{{{e}}})}}$?',lambda a,b,e:a)
add('test/486','power_of_ten_quotient',{'first_exponent':(1,35),'second_exponent':(1,250),'divisor_exponent':(1,25),'outer_exponent':(1,7)},(5,77,15,4),
    lambda a,b,c,d:rf'When $(10^{{{a}}}\cdot10^{{{b}}}\div10^{{{c}}})\div(10^{{{c}}})^{{{d}}}$ is written as an integer, how many zeros follow the initial 1?',
    lambda a,b,c,d:a+b-c*(d+1),valid=lambda a,b,c,d:a+b>c*(d+1),
    sample=lambda r:(lambda a,c,d:(a,r.randint(max(1,c*(d+1)+1-a),250),c,d))(r.randint(1,35),r.randint(1,25),r.randint(1,7)),
    constraint='The resulting power of ten has a positive exponent.',
    reference=lambda a,b,c,d:len(str(10**a*10**b//10**(c*(d+1))))-1)
for key,n in [('test/494',64),('test/79',9)]:
    add(key,'sqrt_power',{'square_base':square(2,50),'exponent':(2,7)},(n,3),
        lambda a,b:rf'Simplify $\sqrt{{{a}^{b}}}$.',lambda a,b:isqrt(a)**b,reference=lambda a,b:isqrt(a**b))
add('test/503','median_mean',{'count':choice((3,5,7,9,11,13)),'total':(3,5000)},(5,105),
    lambda n,t:f'The sum of {n} consecutive whole numbers is {t}. Subtract their mean from their median.',lambda n,t:0,
    valid=lambda n,t:t%n==0 and t//n>=n//2,
    sample=lambda r:(lambda n:(n,n*r.randint(n//2,350)))(r.choice((3,5,7,9,11,13))),
    constraint='The total is a multiple of the odd count and the initial whole number is nonnegative.')
add('test/512','largest_odd_power_of_square_root',{'square':square(2,40),'odd_power':choice((3,5,7))},(36,3),
    lambda a,b:f'If $y^2={a}$, what is the greatest possible value of $y^{b}$?',lambda a,b:isqrt(a)**b,
    reference=lambda a,b:max(i**b for i in (-isqrt(a),isqrt(a))))
add('test/555','integers_below_pi_multiple',{'pi_multiplier':choice(i for i in range(1,2001) if pi_floor(i) is not None)},(200,),
    lambda n:rf'How many positive integers are less than ${n}\pi$?',pi_floor,
    constraint='The bounds 103993/33102 < π < 104348/33215 certify a unique floor.')
def reciprocal_prompt(a,b):
    factors=[rf'\left(\frac{{{x}}}{{{y}}}\right)' for x,y in zip(a,b)]
    return 'Simplify $'+''.join(factors)+''.join(f+'^{-1}' for f in factors)+'$.'
add('test/606','product_of_reciprocals',{'numerators':integers(3,2,1000),'denominators':integers(3,2,1000)},
    ([123,456,789],[321,654,987]),reciprocal_prompt,lambda a,b:1,
    reference=lambda a,b:prod(Q(x,y) for x,y in zip(a,b))*prod(Q(y,x) for x,y in zip(a,b)))
def nonmultiples(n,d):
    return [(a,b) for a,b in pairs(n) if a%d and b%d]
add('test/677','factor_pair_avoiding_multiples',{'product':(10,1800),'excluded_divisor':(2,12)},(1000,10),
    lambda n,d:f'The product of two whole numbers is {n}. Neither is a multiple of {d}. What is their sum?',
    lambda n,d:sum(nonmultiples(n,d)[0]),valid=lambda n,d:len(nonmultiples(n,d))==1,
    constraint='Exactly one unordered factor pair avoids multiples of the stated divisor.')
add('test/750','divisibility_suffix',{'prefix':(21000,21600),'divisor':(4,18)},(21420,6),
    lambda p,d:f'Which nonzero digit $N$ makes ${p}N$ divisible by {d}?',lambda p,d:suffix(p,d)[0],
    valid=lambda p,d:len(suffix(p,d))==1,constraint='Exactly one nonzero units digit works.')
add('test/776','number_trick_cancel',{'multiplier':(2,12),'addend':(2,500),'divisor':(2,20)},(2,200,4),
    lambda k,a,d:f'Think of a number. Multiply it by {k}, add {a}, and divide the result by {d}. Subtract {Q(k,d)} times the original number. What remains?',
    lambda k,a,d:Q(a,d),reference=lambda k,a,d:Q(37*k+a,d)-37*Q(k,d))
add('test/832','radical_sequence_prefix',{'threshold':(2,100)},(20,),
    lambda n:rf'How many terms of $\sqrt1,\sqrt2,\sqrt3,\ldots$ are at most {n}?',lambda n:n*n)
add('test/84','factor_or_multiple',{'factor_target':(10,120),'multiple_base':(2,20),'numbers':integers(10,1,120)},
    (34,7,[1,2,3,4,8,14,17,29,56,91]),
    lambda a,b,ns:f'How many of the following numbers are factors of {a} or multiples of {b}? '+', '.join(map(str,ns)),
    lambda a,b,ns:sum(a%n==0 or n%b==0 for n in ns),valid=lambda a,b,ns:len(set(ns))==len(ns),
    sample=lambda r:(r.randint(10,120),r.randint(2,20),sorted(r.sample(range(1,121),10))),
    constraint='The list entries are distinct.',
    reference=lambda a,b,ns:len(set(ns)&({i for i in range(1,a+1) if a%i==0}|set(range(b,121,b)))))
def digit_prime_pair(n):
    return [(i,n-i) for i in (2,3,5,7) if 10<=n-i<=99 and prime(n-i)]
add('test/865','unique_prime_sum',{'total':(12,106)},(100,),
    lambda n:f'The number {n} is the sum of a one-digit prime and a two-digit prime. What is their product?',
    lambda n:prod(digit_prime_pair(n)[0]),valid=lambda n:len(digit_prime_pair(n))==1,
    constraint='Exactly one such prime pair exists.')
add('train/1027','identity_linear_coefficient',{'outer_factor':(2,15),'constant':(-20,30),'right_slope':(2,300)},(2,4,12),
    lambda a,b,k:f'If infinitely many values of $y$ satisfy ${a}({b}+cy)={k}y{a*b:+d}$, what is $c$?',lambda a,b,k:Q(k,a))
for key,source in [('train/1045',(5,50)),('train/1197',(7,77))]:
    add(key,'integers_between_radicals',{'lower_radicand':(1,75),'upper_radicand':(2,150)},source,
        lambda a,b:rf'How many integers lie strictly between $\sqrt{{{a}}}$ and $\sqrt{{{b}}}$?',lambda a,b:isqrt(b-1)-isqrt(a),
        valid=lambda a,b:a<b,constraint='The lower radicand is smaller.',
        reference=lambda a,b:sum(a<n*n<b for n in range(1,isqrt(b)+1)))
add('train/1049','sqrt_equal_power_sum',{'base':(2,16),'term_count':(2,16),'power':(2,6)},(3,3,3),
    lambda a,n,e:r'What is $\sqrt{'+'+'.join([f'{a}^{e}']*n)+'}$?',lambda a,n,e:isqrt(n*a**e),
    valid=lambda a,n,e:is_square(n*a**e),constraint='The sum of the displayed powers is square.')
add('train/1051','unary_minus_and_powers',{'exponent_1':(1,4000),'exponent_2':(1,4000),'exponent_3':(1,4000),'exponent_4':(1,4000)},(2004,2005,2006,2007),
    lambda a,b,c,d:f'Simplify $-1^{{{a}}}+(-1)^{{{b}}}+1^{{{c}}}-1^{{{d}}}$.',
    lambda a,b,c,d:(-1)**b-1,reference=lambda a,b,c,d:-pow(1,a)+pow(-1,b)+pow(1,c)-pow(1,d))
add('train/1058','count_common_multiples',{'first_divisor':(2,40),'second_divisor':(2,40),'third_divisor':(2,40),'bound':(8,500),'power':(2,5)},(6,3,2,30,3),
    lambda a,b,c,n,e:f'Let $a$ count positive multiples of {a} less than {n}, and $b$ count positive integers below {n} divisible by both {b} and {c}. Compute $(a-b)^{e}$.',
    lambda a,b,c,n,e:((n-1)//a-(n-1)//(b*c//gcd(b,c)))**e,
    reference=lambda a,b,c,n,e:(sum(i%a==0 for i in range(1,n))-sum(i%b==i%c==0 for i in range(1,n)))**e)
def large_multiple(d,t,h):
    return range(d*(isqrt(t)//d+1),h,d)
add('train/1062','unique_multiple_above_square',{'divisor':(2,30),'square_threshold':(4,5000),'upper_bound':(4,120)},(8,100,20),
    lambda d,t,h:f'If $x$ is a positive multiple of {d}, $x^2>{t}$, and $x<{h}$, what is $x$?',
    lambda d,t,h:large_multiple(d,t,h)[0],valid=lambda d,t,h:len(large_multiple(d,t,h))==1,
    sample=lambda r:(lambda d,k:(d,r.randint(((k-1)*d)**2,(k*d)**2-1),r.randint(k*d+1,(k+1)*d)))(r.randint(2,15),r.randint(2,4)),
    constraint='Exactly one positive multiple satisfies both strict bounds.',
    reference=lambda d,t,h:next(i for i in range(d,h,d) if i*i>t))
add('train/1065','alternating_integer_interval',{'first_exponent':(-100,-2),'last_exponent':(2,100)},(-10,10),
    lambda a,b:rf'Find $(-1)^{{{a}}}+(-1)^{{{a+1}}}+\cdots+(-1)^{{{b}}}$, summing one term for each exponent from {a} through {b}.',
    lambda a,b:(-1 if a%2 else 1) if (b-a)%2==0 else 0,
    reference=lambda a,b:sum(Q(-1)**i for i in range(a,b+1)))
add('train/1106','positive_square_equation',{'first_factor':(2,150),'second_factor':(2,60),'right_factor':(2,60)},(22,55,10),
    lambda a,b,d:rf'What positive integer $N$ satisfies ${a}^2\times{b}^2={d}^2\times N^2$?',
    lambda a,b,d:a*b//d,valid=lambda a,b,d:a*b%d==0,
    sample=lambda r:(lambda d:(d*r.randint(2,8),r.randint(2,60),d))(r.randint(2,15)),
    constraint='The right factor divides the product of the left factors.',
    reference=lambda a,b,d:isqrt((a*a*b*b)//(d*d)))
def root_difference_sample(r):
    root=r.randint(4,20)
    a=r.randint(1,root*root-1)
    b=r.randint(1,200)
    return a,root*root-a,b+r.randint(1,12)**2,b
add('train/1123','difference_of_radicals',{'addend_1':(1,400),'addend_2':(1,400),'minuend':(2,400),'subtrahend':(1,399)},(36,64,25,16),
    lambda a,b,c,d:rf'What is $\sqrt{{{a}+{b}}}-\sqrt{{{c}-{d}}}$?',lambda a,b,c,d:isqrt(a+b)-isqrt(c-d),
    valid=lambda a,b,c,d:c>d and is_square(a+b) and is_square(c-d),sample=root_difference_sample,
    constraint='Both radicands are positive perfect squares.')
add('train/1145','square_perimeter_area',{'perimeter_multiplier':(1,25),'area_multiplier':(1,25)},(1,1),
    lambda k,a:f'For a square, {k} times the numerical value of its perimeter in inches equals {a} times that of its area in square inches. Find the side length in inches.',
    lambda k,a:Q(4*k,a))
add('train/1163','commute_percentages',{'first_percentage':(1,100),'second_percentage':(1,100),'given_result':(1,100)},(20,10,12),
    lambda a,b,n:rf'If ${a}\%$ of ${b}\%$ of a number is {n}, what is ${b}\%$ of ${a}\%$ of that number?',lambda a,b,n:n,
    reference=lambda a,b,n:Q(b,100)*Q(a,100)*Q(10000*n,a*b))
def precedence(a,b,c,d,e,f,g,h):
    return a+Q(b,c)+d*e-f-Q(g,h)
add('train/1201','parentheses_precedence',{'constant':(1,150),'dividend_1':(1,350),'divisor_1':(1,30),'factor_1':(1,30),'factor_2':(1,30),'subtrahend':(1,300),'dividend_2':(1,350),'divisor_2':(1,30)},(54,98,14,23,17,200,312,6),
    lambda a,b,c,d,e,f,g,h:rf'We are given ${a}+({b}\div{c})+({d}\cdot{e})-{f}-({g}\div{h})={precedence(a,b,c,d,e,f,g,h)}$. What does ${a}+{b}\div{c}+{d}\cdot{e}-{f}-{g}\div{h}$ equal?',
    precedence)
add('train/128','divide_powers',{'base':(2,8),'numerator_exponent':(8,40),'denominator_base':choice(sorted({b**e for b in range(2,9) for e in range(1,5)})),'denominator_exponent':(2,6)},(2,16,16,2),
    lambda b,n,d,e:rf'What is ${b}^{{{n}}}\div{d}^{e}$? Give an integer.',lambda b,n,d,e:b**n//d**e,
    valid=lambda b,n,d,e:b**n%d**e==0,
    sample=lambda r:(lambda b,k,e:(b,r.randint(max(8,k*e),40),b**k,e))(r.randint(2,8),r.randint(1,4),r.randint(2,6)),
    constraint='The denominator power divides the numerator power.')
def composite_runs(b,n):
    return [i for i in range(9+n,b) if all(not prime(j) for j in range(i-n+1,i+1))]
add('train/147','unique_composite_run',{'bound':(15,100),'count':(3,8)},(30,5),
    lambda b,n:f'{n} consecutive two-digit positive integers, all less than {b}, are composite. What is the largest of these integers?',
    lambda b,n:composite_runs(b,n)[0],valid=lambda b,n:len(composite_runs(b,n))==1,
    constraint='Exactly one run satisfies the constraints.')
add('train/226','primality_repeated_block',{'block':(10,999)},(43,),
    lambda n:rf'How many numbers in the infinite list ${n}$, ${n}{n}$, ${n}{n}{n}$, $\ldots$ are prime?',lambda n:int(prime(n)))
add('train/282','zeros_in_power',{'base':choice(10**i for i in range(1,10)),'exponent':(2,200)},(1000,100),
    lambda b,e:f'When ${b}^{{{e}}}$ is expanded, how many zeros follow its initial 1?',lambda b,e:(len(str(b))-1)*e,
    reference=lambda b,e:len(str(b**e))-1)
add('train/331','least_integer_above_root',{'radicand':(2,30000)},(300,),
    lambda n:rf'What is the least integer greater than $\sqrt{{{n}}}$?',lambda n:isqrt(n)+1)
add('train/400','extract_integer_power',{'base':(2,10),'first_exponent':(1,25),'second_exponent':(1,35),'outer_exponent':(2,8)},(2,10,15,5),
    lambda a,b,c,d:rf'If ${a}^{{{b}}}\cdot{a}^{{{c}}}$ is the {d}th power of a positive integer, find that integer.',
    lambda a,b,c,d:a**((b+c)//d),valid=lambda a,b,c,d:(b+c)%d==0,
    constraint='The combined exponent is a multiple of the outer exponent.')
add('train/440','mean_of_linear_expressions',{'mean':(2,100),'offset_1':(1,20),'constant_1':(1,40),'slope_1':(1,8),'constant_2':(1,40),'slope_2':(1,8),'offset_2':(1,20)},(24,8,15,2,13,2,4),
    lambda m,a,b,c,d,e,f:f'The arithmetic mean of $x+{a}$, ${b}$, ${c}x$, ${d}$, and ${e}x+{f}$ is {m}. What is $x$?',
    lambda m,a,b,c,d,e,f:Q(5*m-a-b-d-f,1+c+e))
add('train/455','least_positive_multiple',{'base':(2,500)},(32,),
    lambda n:f'What is the smallest positive multiple of {n}?',lambda n:n)
def square_minus_prime(d):
    return next((n*n-d for n in range(isqrt(d)+1,100) if prime(n*n-d)),None)
add('train/462','smallest_prime_below_square',{'offset':choice(d for d in range(1,200) if square_minus_prime(d) is not None)},(10,),
    lambda d:f'What is the smallest prime that is {d} less than a perfect square?',square_minus_prime,
    constraint='A witness square root below 100 exists, so increasing search certifies minimality.')
add('train/498','inhabitable_land_fraction',{'land_numerator':(1,29),'land_denominator':(2,30),'habitable_numerator':(1,29),'habitable_denominator':(2,30)},(1,4,1,2),
    lambda a,b,c,d:f'If {Q(a,b)} of Earth’s surface is land and {Q(c,d)} of that land is inhabitable, what fraction of Earth’s surface is inhabitable?',
    lambda a,b,c,d:Q(a*c,b*d),valid=lambda a,b,c,d:a<b and c<d,
    sample=lambda r:(lambda b,d:(r.randint(1,b-1),b,r.randint(1,d-1),d))(r.randint(2,30),r.randint(2,30)),
    constraint='Both displayed fractions are strictly between zero and one.')
add('train/502','calculator_fixed_points',{'participants':(2,120),'odd_power':choice((3,5,7)),'zero_power':(2,7),'first_display':choice((-1,0,1)),'last_display':choice((-1,0,1))},(42,3,2,1,-1),
    lambda n,a,b,u,v:f'{n} participants sit in a circle. Three calculators initially show {u}, 0 and {v}. Each participant in turn raises the first display to power {a}, raises the second to power {b}, and negates the third. After everyone has had one turn, what is the sum of the displays?',
    lambda n,a,b,u,v:u+(-1)**n*v)
def sample_radical_ratio(r):
    a,b=r.choice([(i,j) for i in range(1,31) for j in range(i+1,41) if is_square(i*i+j*j)])
    root=r.randint(2,20)
    c=r.randint(1,root*root-1)
    return a,b,c,root*root-c
add('train/510','fraction_from_radicals',{'leg_1':(1,30),'leg_2':(2,40),'addend_1':(1,400),'addend_2':(1,400)},(5,12,16,9),
    lambda a,b,c,d:rf'Find $\frac{{\sqrt{{{a}^2+{b}^2}}}}{{\sqrt{{{c}+{d}}}}}$ as a common fraction.',
    lambda a,b,c,d:Q(isqrt(a*a+b*b),isqrt(c+d)),valid=lambda a,b,c,d:a<b and is_square(a*a+b*b) and is_square(c+d),
    sample=sample_radical_ratio,constraint='Both radicands are positive squares and the first leg is shorter.')
def unique_prime_factor_minimum(items):
    factors=[smallest_prime_factor(i) for i in items]
    return len(set(items))==len(items) and factors.count(min(factors))==1
add('train/537','smallest_prime_factor_in_set',{'members':integers(5,2,119)},([55,57,58,59,61],),
    lambda a:'Which number in the set {'+', '.join(map(str,a))+'} has the smallest prime factor?',
    lambda a:min(a,key=smallest_prime_factor),valid=unique_prime_factor_minimum,
    sample=lambda r:(r.sample(range(3,120,2),4)+[r.randrange(4,120,2)],),
    constraint='Distinct entries and a unique smallest prime factor among the entries.')
add('train/541','side_from_square_diagonal',{'radicand':choice(2*n*n for n in range(1,60))},(2,),
    lambda d:rf'A square has diagonal $\sqrt{{{d}}}$ inches. What is the side length in inches?',lambda d:isqrt(d//2))
def favorite(lo,hi,d,e):
    return [n for n in range(lo+1,hi) if n%d==0 and n%2 and sum(map(int,str(n)))%e==0]
def sample_favorite(r):
    n,d,e=r.choice([(n,d,e) for n in range(41,106,2) for d in range(3,17) for e in range(2,6) if n%d==0 and sum(map(int,str(n)))%e==0])
    return r.randint(n-d,n-1),r.randint(n+1,n+d),d,e
add('train/546','favorite_number',{'lower_bound':(20,105),'upper_bound':(42,125),'divisor':(3,16),'digit_sum_divisor':(2,5)},(50,100,11,3),
    lambda l,h,d,e:f'Bob’s favorite number is strictly between {l} and {h}, is an odd multiple of {d}, and has digit sum divisible by {e}. What is it?',
    lambda l,h,d,e:favorite(l,h,d,e)[0],valid=lambda l,h,d,e:len(favorite(l,h,d,e))==1,
    sample=sample_favorite,constraint='Exactly one number satisfies all the stated conditions.')
def last_two(d,s):
    return [(a,b) for a,b in product(range(10),repeat=2) if (10*a+b)%d==0 and a+b==s]
add('train/560','unique_two_digit_suffix',{'divisor':choice((2,4,5,10,20,25,50)),'digit_sum':(1,18)},(4,13),
    lambda d,s:f'An integer is divisible by {d} and its last two digits sum to {s}. What is the product of those digits?',
    lambda d,s:prod(last_two(d,s)[0]),valid=lambda d,s:len(last_two(d,s))==1,
    constraint='The divisor divides 100 and exactly one suffix has the given sum.')
def square_gap_prime(a,b):
    return ((a+b-1)//2)**2+a
add('train/581','prime_between_consecutive_squares',{'lower_offset':(1,30),'upper_offset':(1,30)},(4,7),
    lambda a,b:f'What prime is {a} greater than a perfect square and {b} less than the next perfect square?',
    square_gap_prime,valid=lambda a,b:(a+b)%2==1 and prime(square_gap_prime(a,b)),
    constraint='The gap is odd and the implied intermediate integer is prime.',
    reference=lambda a,b:next(i*i+a for i in range(30) if (i+1)**2-i*i==a+b))
add('train/600','greatest_multiple_below_cube_bound',{'divisor':(2,20),'cube_bound':(10,100000)},(3,1000),
    lambda d,t:f'What is the greatest positive multiple of {d} whose cube is less than {t}?',
    lambda d,t:next((i-1)//d*d for i in range(1,50) if i**3>=t),valid=lambda d,t:d**3<t,
    sample=lambda r:(lambda d:(d,r.randint(d**3+1,100000)))(r.randint(2,20)),
    constraint='The cube of the divisor is strictly below the bound.',
    reference=lambda d,t:max(i for i in range(d,50,d) if i**3<t))
add('train/647','sum_grouped_quotients',{'sum_start':(1,20),'divisor_1':(1,20),'factor_1':(1,20),'factor_2':(1,20),'addend':(1,40),'divisor_2':(1,20)},(2,2,2,5,8,3),
    lambda a,d,b,c,k,e:rf'Simplify $[({a}+{a+1}+{a+2}+{a+3})\div{d}]+[({b}\cdot{c}+{k})\div{e}]$.',
    lambda a,d,b,c,k,e:Q(4*a+6,d)+Q(b*c+k,e))
def sample_factorial_square(r):
    n=r.randint(4,10)
    f=factorial(n)
    return n,r.choice([f//(i*i) for i in range(2,isqrt(f)+1) if f%(i*i)==0])
add('train/703','sqrt_factorial_quotient',{'factorial_argument':(4,10),'divisor':(1,4000000)},(8,70),
    lambda n,d:rf'Find $\sqrt{{\dfrac{{{n}!}}{{{d}}}}}$.',lambda n,d:isqrt(factorial(n)//d),
    valid=lambda n,d:factorial(n)%d==0 and is_square(factorial(n)//d),
    sample=sample_factorial_square,constraint='The divisor divides the factorial and the quotient is square.')
def mod_digits(prefix,ds):
    return [i for i in range(10) if all((10*prefix+i)%d==0 for d in ds)]
def sample_mod_digits(r):
    ds=sorted(r.sample([2,3,4,5,6,8,9],r.randint(3,7)))
    step=1
    for d in ds:
        step=step*d//gcd(step,d)
    return (step*r.randint((1000000+step-1)//step,9999999//step))//10,ds
add('train/721','simultaneous_divisibility_suffix',{'prefix':(100000,999999),'divisors':integers(7,2,9,min_length=3,max_length=7)},
    (353808,[2,3,4,5,6,8,9]),lambda p,d:f'Let $A$ be a digit. If ${p}A$ is divisible by each of '+', '.join(map(str,d))+', what is $A$?',
    lambda p,d:mod_digits(p,d)[0],valid=lambda p,d:len(set(d))==len(d) and len(mod_digits(p,d))==1,
    sample=sample_mod_digits,constraint='The divisors are distinct and exactly one digit satisfies them.')
def square_divisor_count(n,d):
    lo,hi=isqrt(10**(n-1)-1),isqrt(10**n-1)
    step=next(i for i in range(1,d+1) if i*i%d==0)
    return hi//step-lo//step
add('train/723','divisible_squares_by_digit_count',{'digits':(1,6),'divisor':(2,60)},(2,3),
    lambda n,d:f'How many positive perfect squares have exactly {n} decimal digits and are divisible by {d}?',square_divisor_count,
    reference=lambda n,d:sum(k*k%d==0 for k in range(isqrt(10**(n-1)-1)+1,isqrt(10**n-1)+1)))
add('train/727','integers_between_fraction_and_pi',{'numerator':(1,100),'denominator':(2,30),'pi_multiplier':(1,20)},(5,3,2),
    lambda a,b,k:rf'How many whole numbers lie strictly between $\frac{{{a}}}{{{b}}}$ and ${k}\pi$?',lambda a,b,k:pi_floor(k)-a//b,
    valid=lambda a,b,k:Q(a,b)<k*PI_LO and pi_floor(k) is not None,
    sample=lambda r:(lambda b,k:(r.randint(1,min(100,(b*k*PI_LO).__floor__())),b,k))(r.randint(2,30),r.randint(1,20)),
    constraint='The lower endpoint is below the certified rational lower bound for the upper endpoint.')
add('train/741','opposite_odd_power_sums',{'last_base':(5,300),'odd_power':choice((3,5,7,9))},(100,3),
    lambda n,e:rf'Add the sums $1^{e}+2^{e}+\cdots+{n}^{e}$ and $(-1)^{e}+(-2)^{e}+\cdots+(-{n})^{e}$.',
    lambda n,e:0,reference=lambda n,e:sum(i**e for i in range(-n,n+1)))
add('train/797','largest_reciprocal_sum',{'common_denominator':(2,25),'other_denominators':integers(5,2,25)},(4,[5,6,3,8,7]),
    lambda a,ds:'Choose the largest sum and express it as a reduced fraction: '+', '.join(rf'$\frac1{{{a}}}+\frac1{{{d}}}$' for d in ds)+'.',
    lambda a,ds:Q(1,a)+Q(1,min(ds)),valid=lambda a,ds:len(set(ds))==len(ds),
    sample=lambda r:(r.randint(2,25),r.sample(range(2,26),5)),constraint='The varying denominators are distinct.',
    reference=lambda a,ds:max(Q(1,a)+Q(1,d) for d in ds))
def sample_mixed_square(r):
    b=r.choice((2,3,5,7,11))
    q=Q(b*r.randint(1,12)+r.randint(1,b-1),b)**2
    a,c=divmod(q.numerator,q.denominator)
    return a,c,q.denominator
add('train/801','sqrt_mixed_number',{'whole_part':(1,200),'fraction_numerator':(1,150),'fraction_denominator':(2,150)},(6,1,4),
    lambda a,b,c:rf'Express $\sqrt{{{a}\frac{{{b}}}{{{c}}}}}$ as a reduced fraction.',
    lambda a,b,c:sqrt_fraction(a+Q(b,c)),valid=lambda a,b,c:b<c and gcd(b,c)==1 and is_square(a+Q(b,c)),
    sample=sample_mixed_square,constraint='The fraction is proper and reduced, and the mixed number is a rational square.')
def smallest_digits(d,n):
    return ((10**(n-1)+d-1)//d)*d
add('train/858','smallest_digit_length_multiples',{'divisor_1':(2,12),'digit_count_1':(2,5),'divisor_2':(2,12),'digit_count_2':(2,5)},(3,2,4,3),
    lambda a,m,b,n:f'If $a$ is the smallest positive {m}-digit multiple of {a} and $b$ is the smallest positive {n}-digit multiple of {b}, find $a+b$.',
    lambda a,m,b,n:smallest_digits(a,m)+smallest_digits(b,n))
add('train/868','product_bracketing_radical',{'radicand':choice(n for n in range(2,2000) if not is_square(n))},(73,),
    lambda n:rf'$\sqrt{{{n}}}$ lies strictly between two consecutive positive integers. What is their product?',lambda n:isqrt(n)*(isqrt(n)+1))
add('train/881','max_share_divisible_ratio',{'total':(2,300)},(24,),
    lambda n:f'Andy and Alexa bake {n} cookies and eat them all. Alexa eats a positive integer multiple of the number Andy eats. What is the maximum number Andy could eat?',
    lambda n:n//smallest_prime_factor(n),reference=lambda n:max(i for i in range(1,n) if (n-i)%i==0))
add('train/883','nested_radical_product',{'coefficient':(2,200),'inner_radicand':square(2,24)},(36,16),
    lambda a,b:rf'What is $\sqrt{{{a}\times\sqrt{{{b}}}}}$?',lambda a,b:isqrt(a*isqrt(b)),
    valid=lambda a,b:is_square(a*isqrt(b)),constraint='The outer radicand is a perfect square.')
add('train/909','gcd_two_digit_palindromes',{'base':(2,36)},(10,),
    lambda b:f'What is the greatest common factor of the values of all two-digit palindromes in base {b}? Give the answer in decimal.',
    lambda b:b+1,reference=lambda b:gcd(*(d*(b+1) for d in range(1,b))),
    adaptation='Specify the numeral base explicitly, with base 10 at the source instance.')
add('train/915','diameter_from_circle_area',{'pi_coefficient':square(1,60)},(1,),
    lambda a:rf'A circle has area ${a}\pi$ square units. What is its diameter?',lambda a:2*isqrt(a))
add('train/938','arithmetic_list_length',{'first_term':(-30,30),'step':(1,15),'last_term':(-10,550)},(-4,3,32),
    lambda a,d,b:rf'How many numbers are in the arithmetic list ${a},{a+d},{a+2*d},{a+3*d},\ldots,{b}$?',
    lambda a,d,b:(b-a)//d+1,valid=lambda a,d,b:b>a+3*d and (b-a)%d==0,
    sample=lambda r:(lambda a,d:(a,d,a+d*r.randint(4,32)))(r.randint(-10,30),r.randint(1,15)),
    constraint='The last term occurs after the four explicitly displayed terms.',
    reference=lambda a,d,b:len(range(a,b+1,d)))
def divisor_leader(n):
    counts=[2*len(pairs(i))-(isqrt(i)**2==i) for i in range(1,n+1)]
    return counts.index(max(counts))+1 if counts.count(max(counts))==1 else None
add('train/954','largest_divisor_count',{'bound':choice(n for n in range(3,181) if divisor_leader(n) is not None)},(15,),
    lambda n:f'Of the integers from 1 through {n}, which has the most positive divisors?',divisor_leader,
    constraint='Exactly one integer has the maximum divisor count.',
    reference=lambda n:max(range(1,n+1),key=lambda i:sum(i%d==0 for d in range(1,i+1))))

def least_prime_sum(lower):
    return next(n for n in range(lower,250) if prime(n) and n-2!=2 and prime(n-2))


add('test/425','least_prime_sum_of_distinct_primes',{'lower_bound':choice(n for n in range(1,100) if any(prime(j) and prime(j-2) for j in range(max(5,n),250)))},(1,),
    lambda n:f'What is the smallest prime number at least {n} that is the sum of two distinct primes?',
    least_prime_sum,adaptation='Add a lower bound of 1 at the source instance.',
    reference=lambda lo:next(n for n in range(lo,250) if prime(n) and any(prime(d) and prime(n-d) for d in range(2,(n+1)//2))))


def least_prime_square_sum(lower):
    return min(n for a in range(1,25) for b in range(a+1,25) if (n:=a*a+b*b)>=lower and prime(n))


add('test/98','least_prime_sum_of_distinct_squares',{'lower_bound':(1,200)},(1,),
    lambda n:f'What is the least prime at least {n} that is the sum of two distinct positive perfect squares?',
    least_prime_square_sum,adaptation='Add a lower bound of 1 at the source instance.',
    constraint='13² + 2² = 173 and 15² + 2² = 229 are examples. A prime at 229 or below suffices for all stated lower bounds.',
    reference=lambda lo:next(n for n in range(lo,230) if prime(n) and any(2*a*a<n and is_square(n-a*a) for a in range(1,isqrt(n)+1))))

add('train/1076','multiple_of_unbounded_set',{'base_divisor':(1,100)},(1,),
    lambda n:f'What integer is a multiple of every integer divisible by {n}?',
    lambda n:0,adaptation='Restrict the divisors to multiples of a specified positive integer, with 1 at the source instance.')

def square_free(n):
    return all(n%(i*i) for i in range(2,isqrt(n)+1))


add('train/1152','minimum_rectangles_tiling_square',{'first_side':(1,20),'second_side':(2,25)},(2,3),
    lambda a,b:f'What is the smallest number of whole {a}-by-{b} rectangles needed to cover a square exactly, without overlaps, gaps, or overhangs?',
    lambda a,b:a*b,valid=lambda a,b:a<b and square_free(a*b),
    constraint='The side lengths increase and their product is squarefree.')

add('train/82','obtuse_angles_in_triangle',{'obtuse_angle_degrees':(91,179)},(120,),
    lambda n:rf'A triangle has an interior angle measuring ${n}^\circ$. How many obtuse interior angles does it have?',
    lambda n:1,adaptation='Specify the measure of an obtuse interior angle instead of describing the triangle as obtuse.')
