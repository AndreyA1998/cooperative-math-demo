"""Partially known inverse matrices and positive integer eigendirections."""
from fractions import Fraction as F
from .common import integer as I, template
def T(name,*args,**kw):return template('extensions.precalculus.'+name,*args,**kw)
def det(m):
    return sum(m[0][j]*(m[1][(j+1)%3]*m[2][(j+2)%3]-m[1][(j+2)%3]*m[2][(j+1)%3]) for j in range(3))
def inverse(m):
    d=det(m)
    result=[]
    for i in range(3):
        row=[]
        for j in range(3):
            rr=[k for k in range(3) if k!=j];cc=[k for k in range(3) if k!=i]
            row.append(F((-1)**(i+j)*(m[rr[0]][cc[0]]*m[rr[1]][cc[1]]-m[rr[0]][cc[1]]*m[rr[1]][cc[0]]),d))
        result.append(row)
    return result
def gauss_inverse(matrix):
    m=[[F(x) for x in row]+[F(i==j) for j in range(3)] for i,row in enumerate(matrix)]
    for col in range(3):
        pivot=next(i for i in range(col,3) if m[i][col])
        m[col],m[pivot]=m[pivot],m[col];v=m[col][col]
        m[col]=[x/v for x in m[col]]
        for i in range(3):
            if i!=col:
                v=m[i][col];m[i]=[x-v*y for x,y in zip(m[i],m[col])]
    return [row[3:] for row in m]
def completed_inverse(p):
    f=-F(p['m10']*p['n00']+p['m12']*p['n20'],p['m11'])
    g=-F(p['m10']*p['n02']+p['m12']*p['n22'],p['m11'])
    e=-F(p['n00']*p['m01']+p['n02']*p['m21'],p['m11'])
    h=-F(p['n20']*p['m01']+p['n22']*p['m21'],p['m11'])
    return [[F(p['n00']),e,F(p['n02'])],[f,F(p['n11']),g],[F(p['n20']),h,F(p['n22'])]]
def partial_valid(p):
    if p['m11']==0:return False
    n=completed_inverse(p)
    if det(n)==0:return False
    m=inverse(n)
    return all(m[i][j]==p['m'+str(i)+str(j)] for i,j in ((0,1),(1,0),(1,1),(1,2),(2,1)))
def partial_solve(p,method=inverse):
    n=completed_inverse(p);m=method(n)
    return m[0][0]+m[0][2]+m[2][0]+m[2][2]+n[0][1]+n[1][0]+n[1][2]+n[2][1]
def partial_sample(r):
    m=[[int(i==j) for j in range(3)] for i in range(3)]
    for _ in range(6):
        a,b=r.sample(range(3),2);k=r.choice([-2,-1,1,2])
        m[a]=[x+k*y for x,y in zip(m[a],m[b])]
    n=inverse(m)
    p={'m'+str(i)+str(j):m[i][j] for i,j in ((0,1),(1,0),(1,1),(1,2),(2,1))}
    p.update({'n'+str(i)+str(j):int(n[i][j]) for i,j in ((0,0),(0,2),(1,1),(2,0),(2,2))})
    return p
def eigen_ratios(p):return [F(-p['w'],p['u']-p[k]) for k in ('l1','l2')]
def eigen_valid(p):
    if p['l1']==p['l2'] or p['w']==0 or p['u'] in (p['l1'],p['l2']):return False
    if p['u']+p['z']!=p['l1']+p['l2'] or p['u']*p['z']-p['v']*p['w']!=p['l1']*p['l2']:return False
    return all(q>0 and q.numerator<=50 and q.denominator<=50 for q in eigen_ratios(p))
def eigen_sample(r):
    t=r.randint(1,10);a,b,c,d=t+1,t,t+2,t+1;l1,l2=r.sample(range(-10,11),2)
    return dict(l1=l1,l2=l2,u=d*l1*a-b*l2*c,v=d*b*(l1-l2),w=a*c*(l2-l1),z=-c*l1*b+a*l2*d)
def eigen_reference(p):
    answer=0
    for name in ('l1','l2'):
        candidates=[a+b for a in range(1,51) for b in range(1,51)
                    if p[name]*a==p['u']*a+p['w']*b and p[name]*b==p['v']*a+p['z']*b]
        answer+=min(candidates)
    return answer
def build(row):
    if row['id']=='precalculus/train/39':
        return T('minimum_positive_integer_eigenmatrix',{k:I(-4000,4000) for k in ('l1','l2','u','v','w','z')},
          dict(l1=3,l2=2,u=18,v=12,w=-20,z=-13),
          lambda p:rf"Positive integers $a,b,c,d$ satisfy $\begin{{pmatrix}}{p['l1']}&0\\0&{p['l2']}\end{{pmatrix}}\begin{{pmatrix}}a&b\\c&d\end{{pmatrix}}=\begin{{pmatrix}}a&b\\c&d\end{{pmatrix}}\begin{{pmatrix}}{p['u']}&{p['v']}\\{p['w']}&{p['z']}\end{{pmatrix}}$. Find the minimum of $a+b+c+d$.",
          lambda p:sum(q.numerator+q.denominator for q in eigen_ratios(p)),
          valid=eigen_valid,sample=eigen_sample,reference=eigen_reference,
          constraints=['Distinct real integer eigenvalues match trace and determinant. w and u-l_i are nonzero; both reduced positive left-eigenvector ratios have numerator/denominator at most 50.'])
    if row['id']=='precalculus/train/132':
        original=dict(m01=1,m10=2,m11=2,m12=3,m21=5,n00=-5,n02=-11,n11=-13,n20=2,n22=4)
        return T('partial_inverse_completion',{k:I(-1000,1000) for k in original},original,
          lambda p:rf"If $\begin{{pmatrix}}a&{p['m01']}&b\\{p['m10']}&{p['m11']}&{p['m12']}\\c&{p['m21']}&d\end{{pmatrix}}^{{-1}}=\begin{{pmatrix}}{p['n00']}&e&{p['n02']}\\f&{p['n11']}&g\\{p['n20']}&h&{p['n22']}\end{{pmatrix}}$, find $a+b+c+d+e+f+g+h$.",
          partial_solve,valid=partial_valid,sample=partial_sample,reference=lambda p:partial_solve(p,gauss_inverse),
          constraints=['m11 != 0; four orthogonality equations complete the displayed inverse; it is invertible, and its inverse agrees with all five known original entries.'])
