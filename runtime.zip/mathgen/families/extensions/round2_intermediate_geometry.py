"""Conics and areas bounded by algebraic curves."""
from fractions import Fraction as F
from math import isqrt

from .common import is_square, sqrt_fraction
from .round2_intermediate_common import I, _bind, _pythagorean_sample, _square


_bind('r47','hyperbola_vertex_distance','a b c d e',(9,1,54,10,55),
      (I(1,100),I(1,100),I(-200,200),I(-200,200),I(-5000,5000)),
      r'Find the distance between the vertices of \({a}x^2-{b}y^2+({c})x+({d})y+({e})=0\).',
      lambda a,b,c,d,e:2*sqrt_fraction(_hyperbola_rhs(a,b,c,d,e)/a),
      valid=lambda p:_hyperbola_distance_valid(*[p[k] for k in 'abcde']),
      sample=lambda r:_hyperbola_sample(r),
      constraints=('Completing squares gives a positive right-hand side and a rational horizontal semiaxis.',))


def _hyperbola_rhs(a,b,c,d,e):
    return F(c*c,4*a)-F(d*d,4*b)-e


def _hyperbola_distance_valid(a,b,c,d,e):
    rhs = _hyperbola_rhs(a,b,c,d,e)
    return rhs>0 and is_square(rhs/a)


def _hyperbola_sample(r):
    a,b = r.randint(1,25),r.randint(1,25)
    h,k,t = r.randint(-4,4),r.randint(-4,4),r.randint(1,8)
    return dict(a=a,b=b,c=-2*a*h,d=2*b*k,e=a*(h*h-t*t)-b*k*k)


_bind('r1022','degenerate_ellipse_constant','a b c d',(2,1,8,-10),
      (I(1,30),I(1,30),I(-80,80),I(-80,80)),
      r'If the graph of \({a}x^2+{b}y^2+({c})x+({d})y+C=0\) consists of exactly one point, find \(C\).',
      lambda a,b,c,d:F(c*c,4*a)+F(d*d,4*b))

_bind('r469','degenerate_ellipse_point','xshift yshift a_squared b_squared',(0,-5,36,16),
      (I(-60,60),I(-60,60),I(1,400),I(1,400)),
      r'Find the greatest possible \(y\)-coordinate on the graph \((x-({xshift}))^2/{a_squared}+(y-({yshift}))^2/{b_squared}=0\).',
      lambda h,k,a,b:k)

_bind('r852','shared_hyperbola_asymptotes','xden yden second_yden',(4,9,18),
      (I(1,120),I(1,120),I(1,120)),
      r'The hyperbolas \(x^2/{xden}-y^2/{yden}=1\) and \(y^2/{second_yden}-x^2/N=1\) share their asymptotes. Find \(N\).',
      lambda a,b,c:F(a*c,b))

_bind('s702','hyperbola_focus_distance','a_squared b_squared right',(50,22,2),
      (I(1,400),I(1,400),I(1,100)),
      r'Find the distance between the foci of \(x^2/{a_squared}-y^2/{b_squared}={right}\).',
      lambda a,b,c:2*isqrt((a+b)*c),
      valid=lambda p:_square((p['a_squared']+p['b_squared'])*p['right']),
      sample=lambda r:{'a_squared':(a:=r.randint(1,(q:=r.randint(2,20))**2-1)),
                       'b_squared':q*q-a, 'right':r.randint(1,10)**2},
      constraints=('The right-hand side times the sum of the two denominators is a perfect square.',))

_bind('r328','hyperbola_given_focus_vertex','center_x center_y vertex_x focus_offset_squared',
      (-2,0,-5,34),(I(-40,40),I(-40,40),I(-80,80),I(2,3200)),
      r'A horizontal hyperbola has center \(({center_x},{center_y})\), vertex \(({vertex_x},{center_y})\) and focus '
      r'\(({center_x}+\sqrt{{{focus_offset_squared}}},{center_y})\). In standard form, with center \((h,k)\) and positive semiaxes \(a,b\), find \(h+k+a+b\).',
      lambda h,k,v,c:h+k+abs(v-h)+isqrt(c-(v-h)**2),
      valid=lambda p:p['center_x']!=p['vertex_x'] and (b:=p['focus_offset_squared']-(p['vertex_x']-p['center_x'])**2)>0 and _square(b),
      sample=lambda r:{'center_x':(h:=r.randint(-40,40)), 'center_y':r.randint(-40,40),
                       'vertex_x':h+r.choice([-1,1])*(a:=r.randint(1,40)),
                       'focus_offset_squared':a*a+r.randint(1,40)**2},
      constraints=('The vertex differs from the center; subtracting the squared vertex offset from the squared focus offset gives a positive square.',))

_bind('s38','ellipse_semimajor_from_foci','h k focus_squared half_minor',
      (3,10,105,8),(I(-60,60),I(-60,60),I(1,1600),I(1,40)),
      r'An ellipse has foci \(({h},{k}\pm\sqrt{{{focus_squared}}})\). Its horizontal axis has endpoints at \(({h}\pm{half_minor},{k})\). Find its semimajor axis.',
      lambda h,k,c,b:isqrt(c+b*b),
      valid=lambda p:_square(p['focus_squared']+p['half_minor']**2),
      sample=lambda r:{'h':r.randint(-60,60),'k':r.randint(-60,60),'half_minor':(b:=r.randint(1,39)),
                       'focus_squared':r.randint(b+1,40)**2-b*b},
      constraints=('The focus offset squared plus the horizontal semiaxis squared is a perfect square.',))

_bind('r430','ellipse_internal_focus_circle','major minor',(10,8),(I(2,200),I(2,199)),
      r'An ellipse has axes of lengths {major} and {minor}, with the first being the major axis. A circle centered at a focus is tangent internally to the ellipse. Find its radius.',
      lambda a,b:F(a-isqrt(a*a-b*b),2),
      valid=lambda p:p['major']>p['minor'] and _square(p['major']**2-p['minor']**2),
      sample=lambda r:{'major':isqrt((b:=(p:=_pythagorean_sample(r,'minor','focus',max_m=10))['minor'])**2+p['focus']**2),'minor':b},
      constraints=('The major axis is longer and the difference of their squared lengths is a perfect square.',))

_bind('s394','space_diagonal_nearby_sides','first',(2003,),(I(1,5000),),
      r'A rectangular box has side lengths \(n,n+1,n(n+1)\), with \(n={first}\). Find the space diagonal.',
      lambda n:n*n+n+1,
      reference=lambda n:isqrt(n*n+(n+1)**2+(n*(n+1))**2))

_bind('s724','fixed_volume_min_surface','volume',(216,),(I(1,1000000),),
      r'A rectangular box has volume {volume}. Find the minimum surface area.',
      lambda v:6*_cube_root(v)**2,
      valid=lambda p:_cube_root(p['volume'])**3==p['volume'],
      sample=lambda r:{'volume':r.randint(1,100)**3},
      constraints=('The volume is a perfect cube, so the minimum is rational.',))


def _cube_root(n):
    low,high = 0,1
    while high**3<=n:
        high*=2
    while high-low>1:
        mid=(high+low)//2
        if mid**3<=n:
            low=mid
        else:
            high=mid
    return low


_bind('r320','focus_directrix_piecewise_vertices','height distance',(1,3),(I(-50,50),I(2,100)),
      r'The graph \(\sqrt{{x^2+y^2}}+|y-({height})|={distance}\) consists of portions of two parabolas. Find the distance between their vertices.',
      lambda h,d:d,valid=lambda p:abs(p['height'])<p['distance'],
      sample=lambda r:{'distance':(d:=r.randint(2,100)), 'height':r.randint(-min(50,d-1),min(50,d-1))},
      constraints=('The absolute value of the horizontal split height is less than the distance constant, giving two nondegenerate parabolas.',))

_bind('r751','absolute_rotated_square_area','bound',(4,),(I(1,300),),
      r'Find the area of \(|x+y|+|x-y|\le {bound}\).',lambda s:s*s)

_bind('s499','area_under_absolute_distance_sum','first second cap',(1,3,8),(I(-50,49),I(-49,50),I(1,150)),
      r'Find the area above \(y=|x-({first})|+|x-({second})|\) and below \(y={cap}\).',
      lambda a,b,c:F(c*c-(b-a)**2,2),
      valid=lambda p:0<p['second']-p['first']<p['cap'],
      sample=lambda r:{'first':(a:=r.randint(-50,49)), 'second':(b:=r.randint(a+1,50)),
                       'cap':r.randint(b-a+1,150)},
      constraints=('The breakpoints are ordered and their difference is less than the cap.',))

_bind('r279','area_between_absolute_graphs','lower upper cap',(3,1,4),(I(-40,40),I(-40,40),I(1,120)),
      r'Find the area of the region \(|x-({lower})|\le y\le {cap}-|x-({upper})|\).',
      lambda a,b,c:F(c*c-(b-a)**2,2),
      valid=lambda p:abs(p['lower']-p['upper'])<p['cap'],
      sample=lambda r:{'lower':(a:=r.randint(-40,40)), 'upper':(b:=r.randint(-40,40)),
                       'cap':r.randint(abs(a-b)+1,120)},
      constraints=('The cap exceeds the distance between the breakpoints.',))

_bind('r590','area_two_diagonal_boundaries','scale',(20,),(I(1,160),),
      r'Find the area of the bounded region cut out by \(y^2+2xy+2\cdot {scale}|x|={scale}^2\).',
      lambda a:2*a*a)

_bind('r44','area_four_absolute_edges','center ratio',(60,4),(I(1,160),I(2,40)),
      r'Find the area enclosed by \(|x-{center}|+|y|=|x/{ratio}|\).',
      lambda a,b:F(2*a*a,b*b-1))

_bind('s585','integer_absolute_intersection','addend cap shift exclusion',
      (5,7,3,2),(I(1,50),I(1,140),I(-60,60),I(1,60)),
      r'How many integers \(x\) satisfy \(|x|+{addend}<{cap}\) and \(|x-({shift})|>{exclusion}\)?',
      lambda a,b,h,d:max(0,2*(b-a)-1)-max(0,min(b-a-1,h+d)-max(a-b+1,h-d)+1),
      reference=lambda a,b,h,d:sum(abs(x)+a<b and abs(x-h)>d for x in range(-b,b+1)))

_bind('r1089','positive_box_quartic_volume','offset volume_cap',(5,700),(I(1,40),I(2,4000000)),
      r'A rectangular box has sides \(x+{offset}\), \(x-{offset}\) and \(x^2+{offset}^2\). For how many positive integers \(x\) does such a box have volume less than {volume_cap}?',
      lambda a,b:isqrt(isqrt(a**4+b-1))-a,
      reference=lambda a,b:sum((x+a)*(x-a)*(x*x+a*a)<b for x in range(a+1,100)))

_bind('r123','alternating_factor_intervals','initial step count',(1,2,49),(I(1,40),I(2,20),I(3,150)),
      r'How many positive integers \(n\) satisfy \(\prod_{{k=0}}^{{{count}-1}}(n-({initial}+{step}k))<0\)?',
      lambda a,d,n:(n//2)*(d-1)+(n%2)*(a-1),
      reference=lambda a,d,n:sum(sum(x<a+d*k for k in range(n))%2
                                 for x in range(1,a+d*(n-1)) if x<a or (x-a)%d))

_bind('s777','strict_power_inequality','numerator exponent',(100000000,4),(I(1,10**10),I(2,14)),
      r'Find the least positive integer \(x\) such that \({numerator}/x^{{{exponent}}}<1\).',
      lambda a,n:_least_power_greater(a,n))


def _least_power_greater(a,n):
    low,high = 0,1
    while high**n<=a:
        high*=2
    while high-low>1:
        mid=(high+low)//2
        if mid**n<=a:
            low=mid
        else:
            high=mid
    return high
