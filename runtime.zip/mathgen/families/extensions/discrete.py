"""Stable bindings for the additional discrete templates."""

from copy import deepcopy
from . import (
    discrete_counting,
    discrete_digits,
    discrete_inverse_identities,
    discrete_modular,
    discrete_number,
)


_MODELS = {
    problem_id: model
    for module in (discrete_counting, discrete_digits, discrete_modular, discrete_number)
    for models in (module.TRAIN, module.TEST)
    for problem_id, model in models.items()
}
_MODELS.update(discrete_inverse_identities.TRAIN)


def build(row):
    model = _MODELS.get(row['id'])
    return deepcopy(model) if model is not None else None
