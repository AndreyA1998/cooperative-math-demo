"""Small exact construction helpers; mathematical domains stay with each family."""
from copy import deepcopy
from fractions import Fraction
from math import isqrt
from mathgen.core import Template


def integer(lo,hi):
    return {'type':'int','min':lo,'max':hi}


def integers(length,lo,hi,*,min_length=None,max_length=None):
    return {'type':'list[int]','min_length':length if min_length is None else min_length,
            'max_length':length if max_length is None else max_length,'items':integer(lo,hi)}


def choice(values):
    values=list(values)
    return {'type':'int' if all(type(v) is int for v in values) else 'str','choices':values}


def draw(rng,domain):
    if 'choices' in domain:return deepcopy(rng.choice(domain['choices']))
    if domain.get('type','int').startswith('list'):
        return [draw(rng,domain['items']) for _ in range(rng.randint(domain['min_length'],domain['max_length']))]
    return rng.randint(domain['min'],domain['max'])


def template(family,parameters,original,render,solve,*,valid=lambda p:True,
             sample=None,reference=None,constraints=(),adaptation=''):
    """Default samples are proposals; core applies domains, constraints and retry cap."""
    if sample is None:sample=lambda rng:{k:draw(rng,d) for k,d in parameters.items()}
    return Template(family=family,parameters=deepcopy(parameters),original=deepcopy(original),
                    render=render,solve=solve,sample=sample,validate=valid,
                    constraints=list(constraints),reference=reference,adaptation=adaptation)


def is_square(value):
    q=Fraction(value)
    return q>=0 and isqrt(q.numerator)**2==q.numerator and isqrt(q.denominator)**2==q.denominator


def sqrt_fraction(value):
    q=Fraction(value)
    if not is_square(q):raise ValueError('Expected a nonnegative rational square')
    return Fraction(isqrt(q.numerator),isqrt(q.denominator))
