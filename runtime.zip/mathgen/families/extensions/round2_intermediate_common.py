"""Explicit source bindings for exact intermediate algebra templates."""
from math import isqrt
from .common import integer, template

_BINDINGS = {}
I = integer


def _bind(ids, name, names, original, domains, prompt, solve, *, reference=None,
          valid=lambda p: True, sample=None, constraints=(), adaptation=''):
    fields = names.split()
    if len(fields)!=len(original) or len(fields)!=len(domains):
        raise ValueError(f'Parameter count mismatch in {name}')
    t = template(
        'intermediate_algebra.round2.' + name,
        dict(zip(fields, domains)), dict(zip(fields, original)),
        lambda p: prompt.format(**p), lambda p: solve(*(p[k] for k in fields)),
        reference=None if reference is None else lambda p: reference(*(p[k] for k in fields)),
        valid=valid, sample=sample, constraints=constraints, adaptation=adaptation,
    )
    for key in ids.split():
        split = 'train' if key[0] == 'r' else 'test'
        problem_id = f'intermediate_algebra/{split}/{key[1:]}'
        if problem_id in _BINDINGS:
            raise ValueError(f'Duplicate binding for {problem_id}')
        _BINDINGS[problem_id] = t


def build(row):
    return _BINDINGS.get(row['id'])


def _pythagorean_sample(rng, first, second, *, scale=1, max_m=15):
    m = rng.randint(2,max_m)
    n = rng.randint(1,m-1)
    k = rng.randint(1,scale)
    a,b = k*(m*m-n*n),k*2*m*n
    if rng.randrange(2):
        a,b = b,a
    return {first:a,second:b}


def _square(n):
    return n>=0 and isqrt(n)**2==n
