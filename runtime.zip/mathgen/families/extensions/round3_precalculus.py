"""Four structural extensions of the remaining invariant precalculus problems."""
from fractions import Fraction as F
from math import gcd
from .common import integer,integers,choice,template

IDS=('precalculus/train/297','precalculus/train/337','precalculus/train/598','precalculus/test/55')


def vectors(p):
    entries=p['vectors']
    return [entries[k:k+3] for k in range(0,len(entries),3)]


def outer_sum(p):
    v=vectors(p)
    return [[sum(a[i]*a[j] for a in v) for j in range(3)] for i in range(3)]


def frame_valid(p):
    if len(p['vectors'])%3 or len(p['vectors'])<9:return False
    m=outer_sum(p)
    return m[0][0]>0 and all(m[i][j]==(m[0][0] if i==j else 0) for i in range(3) for j in range(3))


def frame_solve(p):
    # Trace of the sum of double-cross operators is twice the frame energy.
    return F(2*sum(x*x for x in p['vectors']),3)


def cross(a,b):
    return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]


def frame_reference(p):
    columns=[]
    for k in range(3):
        e=[int(i==k) for i in range(3)]
        terms=[cross(a,cross(e,a)) for a in vectors(p)]
        columns.append([sum(a[i] for a in terms) for i in range(3)])
    answer=columns[0][0]
    assert all(columns[k][i]==(answer if i==k else 0) for k in range(3) for i in range(3))
    return answer


def frame_sample(r):
    entries=[]
    for _ in range(r.randint(1,3)):
        if r.randrange(2):
            block=[[1,1,1],[1,-1,-1],[-1,1,-1],[-1,-1,1]]
        else:
            u=r.randint(1,3);v=r.randint(0,3)
            block=[[u*u-v*v,2*u*v,0],[-2*u*v,u*u-v*v,0],[0,0,u*u+v*v]]
        scale=r.randint(1,3);axes=r.sample(range(3),3);signs=[r.choice((-1,1)) for _ in range(3)]
        entries.extend(scale*a[j]*signs[i] for a in block for i,j in enumerate(axes))
    return {'vectors':entries}


def frame_render(p):
    rows=', '.join('('+','.join(map(str,a))+')' for a in vectors(p))
    return (f'Let the vectors $a_1,\\ldots,a_m$ in $\\mathbb R^3$ be {rows}, in that order. '
            r'There exists a scalar $c$ such that $\sum_{j=1}^m a_j\times(v\times a_j)=cv$ '
            r'for every vector $v\in\mathbb R^3$. Find $c$.')


def cauchy_solve(p):
    a,b=p['cosine_weight'],p['sine_weight'];y=F(p['numerator'],p['denominator'])
    return (a*y+b*(1-y))*(y/a+(1-y)/b)


def cauchy_reference(p):
    y=F(p['numerator'],p['denominator']);a,b=p['cosine_weight'],p['sine_weight']
    # The quadratic equality becomes (D*x-a*y)^2=0 after clearing positive denominators.
    x=a*y/(a*y+b*(1-y))
    return y*y/x+(1-y)**2/(1-x)


def cauchy_render(p):
    a,b=p['cosine_weight'],p['sine_weight'];n,d=p['numerator'],p['denominator']
    return (rf'Let real angles $\alpha,\beta$ have nonzero sine and cosine, with $\cos^2\beta={n}/{d}$. '
            rf'If $\frac{{\cos^4\alpha}}{{{a}\cos^2\beta}}+'
            rf'\frac{{\sin^4\alpha}}{{{b}\sin^2\beta}}='
            rf'\frac{{1}}{{{a}\cos^2\beta+{b}\sin^2\beta}}$, '
            r'find the sum of all distinct possible values of '
            r'$\frac{\sin^4\beta}{\sin^2\alpha}+\frac{\cos^4\beta}{\cos^2\alpha}$.')


def rational_angles():
    for n in (1,2,3,4,5,-1,-2,-3,-4,-5):
        t=F(n,3)
        if abs(t)==1:continue
        yield 2*t/(1+t*t),(1-t*t)/(1+t*t)


def half_angle_reference(p):
    a,b=p['secant_scale'],p['shift'];values=[]
    for s,c in rational_angles():
        tangent,secant=s/c,1/c
        if a*secant+b==0:continue
        values.append((a*a*tangent+(a*a-b*b)/tangent)/(a*secant+b)-(a*secant-b)/tangent)
    assert values and all(x==values[0] for x in values)
    return values[0]


def half_angle_render(p):
    a,b=p['secant_scale'],p['shift'];k=a*a-b*b
    first=(r'\tan x' if a==1 else rf'{a*a}\tan x')
    if k:first+=rf'+({k})\cot x'
    secant=r'\sec x' if a==1 else rf'{a}\sec x'
    return (rf'Simplify $\frac{{{first}}}{{{secant}+({b})}}-'
            rf'\frac{{{secant}-({b})}}{{\tan x}}$ '
            r'for real $x$ wherever every displayed trigonometric function and denominator is defined and nonzero.')


def product_reference(p):
    e,k=p['cotangent_sign'],p['cosecant_sign'];values=[]
    for s,c in rational_angles():
        values.append((1+e*c/s+k/s)*(1+e*s/c-e*k/c))
    assert values and all(x==values[0] for x in values)
    return values[0]


def product_render(p):
    e,k=p['cotangent_sign'],p['cosecant_sign']
    term=lambda coefficient,name:('+' if coefficient==1 else '-')+'\\'+name+' A'
    return ('Simplify $(1'+term(e,'cot')+term(k,'csc')+')(1'+term(e,'tan')+
            term(-e*k,'sec')+')$ for real $A$ with nonzero sine and cosine.')


def build(row):
    key=row['id']
    if key==IDS[0]:
        return template('precalculus.round3.isotropic_frame',
            {'vectors':integers(9,-60,60,min_length=9,max_length=36)},
            {'vectors':[1,0,0,0,1,0,0,0,1]},frame_render,frame_solve,
            valid=frame_valid,sample=frame_sample,reference=frame_reference,
            constraints=('Flattened ordered three-dimensional vectors; length is a multiple of three.',
                         'The sum of vector outer products is a strictly positive scalar multiple of the identity matrix.'),
            adaptation='Generalize the three standard basis vectors to an explicit finite isotropic frame, including nonorthogonal frames; retain the double-cross operator and its all-vectors scalar condition.')
    if key==IDS[1]:
        return template('precalculus.round3.weighted_cauchy_equality',
            {'cosine_weight':integer(1,50),'sine_weight':integer(1,50),
             'numerator':integer(1,49),'denominator':integer(2,50)},
            {'cosine_weight':1,'sine_weight':1,'numerator':1,'denominator':2},cauchy_render,cauchy_solve,
            valid=lambda p:p['numerator']<p['denominator'] and gcd(p['numerator'],p['denominator'])==1,
            sample=lambda r:{'cosine_weight':r.randint(1,50),'sine_weight':r.randint(1,50),
                'denominator':(d:=r.randint(2,50)),'numerator':r.choice([n for n in range(1,d) if gcd(n,d)==1])},
            reference=cauchy_reference,constraints=('The specified cosine square is a reduced rational strictly between zero and one.',),
            adaptation='Generalize the original Cauchy equality to positive denominator weights and specify a cosine square. At weights1,1 the original equality and reverse expression are retained and its unique value1 holds for every admissible cosine square;1/2 is a representative source specialization.')
    if key==IDS[2]:
        return template('precalculus.round3.conjugate_sign_identity',
            {'cotangent_sign':choice((-1,1)),'cosecant_sign':choice((-1,1))},
            {'cotangent_sign':1,'cosecant_sign':-1},product_render,lambda p:2,
            reference=product_reference,
            adaptation='Vary two internal signs and couple the other signs to preserve a conjugate-product identity. The family contains four symbolic identities with invariant answer2; no argument substitution or external answer scaling is used.')
    if key==IDS[3]:
        return template('precalculus.round3.secant_difference_of_squares',
            {'secant_scale':integer(1,20),'shift':integer(-20,20)},
            {'secant_scale':1,'shift':1},half_angle_render,lambda p:0,
            reference=half_angle_reference,
            adaptation='Generalize the secant denominator factors and add the linked cotangent correction required by difference of squares. The correction vanishes at the original parameters; this is a symbolic identity family, not argument substitution or an external output multiplier.')
    return None
