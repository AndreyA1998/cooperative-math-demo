"""Exact story problems using proportional and affine relationships."""
from fractions import Fraction as Q
from functools import partial
from math import isqrt

from .round2_algebra_common import register

BINDINGS = {}
bind = partial(register, BINDINGS)


bind('train/156 train/684 test/920 test/967', 'two_stage_exchange',
     {'a': (1, 60), 'b': (1, 60), 'c': (1, 60), 'd': (1, 60), 'target': (1, 1000)},
     [(5,3,2,4,12),(15,24,9,15,1000),(7,4,9,20,80),(6,4,8,3,12)],
     lambda a,b,c,d,n: f'At fixed exchange rates, {a} units of A are worth {b} units of B, '
                       f'and {c} units of B are worth {d} units of C. '
                       f'How many units of A are worth {n} units of C?',
     lambda a,b,c,d,n:Q(n*a*c,b*d),
     reference=lambda a,b,c,d,n:n*Q(c,d)*Q(a,b),
     adaptation='Use A, B and C for the named currencies or traded goods, and put the exchanges in chain order.')

bind('train/926', 'multiple_balance_scales',
     {'greens': (1, 30), 'blue_for_green': (1, 30), 'yellows': (1, 30),
      'blue_for_yellow': (1, 30), 'whites': (1, 30), 'blue_for_white': (1, 30),
      'target_green': (1, 30), 'target_yellow': (1, 30), 'target_white': (1, 30)},
     [(3,6,2,5,4,6,4,2,2)],
     lambda a,b,c,d,e,f,u,v,w: f'On a balance scale, {a} green balls balance {b} blue balls, '
                              f'{c} yellow balance {d} blue, and {e} white balance {f} blue. '
                              f'What weight, measured in blue balls, balances {u} green, {v} yellow and {w} white?',
     lambda a,b,c,d,e,f,u,v,w:Q(u*b,a)+Q(v*d,c)+Q(w*f,e),
     adaptation='State the answer as a weight in blue-ball units, allowing a rational number of units.')

bind('train/625 test/283', 'sum_with_three_transformations',
     {'total': (-500, 500), 'shift': (1, 30), 'multiplier': (2, 30)}, [(60,7,7),(88,5,5)],
     lambda s,d,k: f'The sum of $a,b,c$ is {s}. Decreasing $a$ by {d}, increasing $b$ by {d}, '
                   f'and multiplying $c$ by {k} all give the same value $N$. Find $N$.',
     lambda s,d,k:Q(k*s,2*k+1))

bind('train/889', 'largest_of_three_with_gaps',
     {'total': (-500, 500), 'small_gap': (1, 30), 'large_gap': (1, 30)}, [(67,3,7)],
     lambda s,a,b: f'Three numbers have sum {s}. The two smaller numbers differ by {a} and '
                   f'the two larger differ by {b}. What is the largest number?',
     lambda s,a,b:Q(s+a+2*b,3))

bind('train/1297', 'largest_from_sum_difference',
     {'sum': (-1000, 1000), 'difference': (1, 300)}, [(31,3)],
     lambda s,d: f'Two numbers have sum {s} and difference {d}. What is the larger?',
     lambda s,d:Q(s+d,2))

bind('train/1275', 'sum_from_pairwise_sums',
     {'sum1': (-200, 200), 'sum2': (-200, 200), 'sum3': (-200, 200)}, [(29,46,53)],
     lambda a,b,c: f'When three numbers are added two at a time, the pairwise sums are '
                   f'{a}, {b}, and {c}. Find the sum of all three.',
     lambda a,b,c:Q(a+b+c,2))

bind('train/1421', 'associativity_error',
     {'correct': (-100, 100), 'incorrect': (-100, 100)}, [(3,11)],
     lambda a,b: f'The value of $a-b-c$ is {a}, but calculating $a-(b-c)$ gives {b}. '
                 'What is $a-b$?',
     lambda a,b:Q(a+b,2))

bind('test/105', 'apple_count_with_ratio',
     {'total': (3, 1200), 'ratio': (2, 20)}, [(20,3)],
     lambda s,r: f'Amy and Betty have {s} apples altogether. Amy has {r} times as many '
                 'as Betty. How many more apples does Amy have?',
     lambda s,r:s//(r+1)*(r-1), valid=lambda s,r:s%(r+1)==0,
     sample=lambda rng:(lambda n,r:(n*(r+1),r))(rng.randint(1,50),rng.randint(2,20)),
     constraints=('total is divisible by ratio+1',))

bind('train/1645', 'purchase_count',
     {'volumes': (2, 60), 'paperback_price': (1, 40), 'price_difference': (1, 40),
      'total': (2, 4800)}, [(10,15,10,220)],
     lambda n,p,d,s: f'Each of the {n} volumes of a collection costs {p} dollars in paperback '
                     f'or {p+d} dollars in hardcover. Theresa buys one copy of each volume '
                     f'and pays {s} dollars. How many hardcovers did she buy?',
     lambda n,p,d,s:(s-n*p)//d,
     valid=lambda n,p,d,s:0<=s-n*p<=n*d and (s-n*p)%d==0,
     sample=lambda rng:(lambda n,p,d:(n,p,d,n*p+d*rng.randint(0,n)))(
         rng.randint(2,60),rng.randint(1,40),rng.randint(1,40)),
     constraints=('the extra payment above the paperback total is a whole multiple of price_difference '
                  'and cannot exceed volumes times that difference',),
     reference=lambda n,p,d,s:next(h for h in range(n+1) if h*(p+d)+(n-h)*p==s))

bind('train/1573', 'runner_rate_comparison',
     {'jordan_distance': (1, 20), 'time_divisor': (2, 10), 'steve_distance': (1, 20),
      'steve_time': (1, 120), 'target_distance': (1, 60)}, [(2,2,3,24,5)],
     lambda a,d,b,t,n: f'Jordan ran {a} miles in 1/{d} of the time Steve needed to run '
                       f'{b} miles. Steve took {t} minutes for his run. At the same rate as before, '
                       f'how many minutes would Jordan take to run {n} miles?',
     lambda a,d,b,t,n:Q(t*n,a*d))



bind('train/1000', 'room_area_unit_conversion',
     {'length_ft': (1, 200), 'width_ft': (1, 200)}, [(12,6)],
     lambda a,b: f'A rectangular room is {a} feet long and {b} feet wide. How many square yards '
                 'of carpet are needed to cover the floor exactly?',
     lambda a,b:Q(a*b,9), reference=lambda a,b:Q(a,3)*Q(b,3))

bind('test/19', 'calories_in_bottle',
     {'initial_ounces': (1, 40), 'calories': (1, 500), 'target_ounces': (1, 50)}, [(8,125,12)],
     lambda a,c,b: f'A {a}-fluid-ounce bottle of a drink contains {c} calories. How many calories '
                   f'are in a {b}-fluid-ounce bottle of the same drink? Give an exact value.',
     lambda a,c,b:Q(c*b,a),
     valid=lambda a,c,b:terminating(Q(c*b,a)),
     constraints=('the resulting fraction has a terminating decimal expansion',),
     adaptation='Request an exact value; the API serializes it as a reduced rational string instead of decimal notation.')


def terminating(value):
    d = value.denominator
    for p in (2,5):
        while d%p==0:
            d//=p
    return d==1


bind('test/703', 'proportional_student_representation',
     {'grade7': (1, 1000), 'grade8': (1, 1000), 'representatives': (2, 100)},
     [(520,650,18)],
     lambda a,b,n: f'The seventh and eighth grades have {a} and {b} students respectively. '
                   f'They share {n} student council seats in exact proportion to enrollment. '
                   'How many seats should the eighth grade have?',
     lambda a,b,n:n*b//(a+b),
     valid=lambda a,b,n:n*b%(a+b)==0 and n<=a+b,
     sample=lambda rng:(lambda a,b,k,t:(a*k,b*k,(a+b)*t))(
         rng.randint(1,10),rng.randint(1,10),rng.randint(5,100),rng.randint(1,5)),
     constraints=('both seat counts are integers and total seats do not exceed total students',))

bind('test/838', 'nested_percentage',
     {'percent1': (1, 500), 'percent2': (1, 500), 'quantity': (1, 400)}, [(50,200,10)],
     lambda a,b,c: f'What is {a}% of {b}% of {c}?',
     lambda a,b,c:Q(a*b*c,10000),
     reference=lambda a,b,c:Q(a,100)*Q(b,100)*c)

bind('test/922', 'inverse_percentage',
     {'addend': (1, 100), 'known_percent': (1, 500), 'known_quantity': (1, 100),
      'unknown_percent': (1, 500)}, [(5,500,10,110)],
     lambda a,b,c,d: f'{a} plus {b}% of {c} is equal to {d}% of what number?',
     lambda a,b,c,d:Q(100*a+b*c,d))

bind('train/842', 'ratio_of_inverse_variation',
     {'ratio_numerator': (1, 100), 'ratio_denominator': (1, 100)}, [(2,3)],
     lambda a,b: f'Two nonzero quantities $u,v$ vary inversely. At two settings, the ratio '
                 f'$u_1/u_2$ is $ {a}/{b}$. Find $v_1/v_2$.',
     lambda a,b:Q(b,a))

bind('train/691', 'compare_shifted_squares',
     {'increase': (1, 500), 'decrease': (1, 100)}, [(85,17)],
     lambda a,b: f'{a} more than the square of a number equals the square of {b} less '
                 'than that number. What is the number?',
     lambda a,b:Q(b*b-a,2*b))

bind('train/1644', 'sum_of_roots_from_product',
     {'offset': (1, 80), 'product': (-100, 100)}, [(6,-5)],
     lambda a,b: f'The product of a real number and {a} less than that number is {b}. '
                 'What is the sum of all possible values of the number?',
     lambda a,b:a, valid=lambda a,b:a*a+4*b>0,
     constraints=('the discriminant is strictly positive, so both real roots are distinct',))

bind('train/39', 'sum_integer_quadratic_roots',
     {'increment': (2, 200000)}, [(182,)],
     lambda s: f'The square of an integer is {s} greater than the integer itself. '
               'What is the sum of all integers with this property?',
     lambda s:1,
     valid=lambda s:isqrt(1+4*s)**2==1+4*s,
     sample=lambda rng:(lambda n:(n*(n-1),))(rng.randint(2,447)),
     constraints=('1+4*increment is an odd square',),
     reference=lambda s:sum(n for n in range(-448,449) if n*n-n==s))
