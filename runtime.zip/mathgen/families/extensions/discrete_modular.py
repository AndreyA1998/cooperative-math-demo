"""Remainders, cyclic processes and exact congruence templates."""

from fractions import Fraction
from functools import lru_cache
from itertools import combinations
from math import gcd, lcm, prod

from .common import integers
from .discrete_helpers import binder, ceildiv, one, prime, primes, singleton

TRAIN, train = binder('number_theory/train')
TEST, test = binder('number_theory/test')


def listed_remainder(totals, modulus):
    return sum(totals)%modulus


def inverse_lcms(a, b, c, d):
    return [n for n in range(1,gcd(c,d)+1) if c%n==d%n==0 and lcm(a,n)==c and lcm(b,n)==d]


def lcm_sample(rng):
    coprime = [(a,b) for a,b in combinations(range(2,26),2) if gcd(a,b)==1]
    a,b = rng.choice(coprime)
    n = rng.randint(2,20)
    return dict(a=a,b=b,c=lcm(a,n),d=lcm(b,n))


def clock_components(hours, minutes, seconds, cycle):
    carry,s = divmod(hours*3600+minutes*60+seconds,60)
    h,m = divmod(carry,60)
    return (h%cycle or cycle)+m+s


def repunit_gcd(a, b, m, n):
    # Cross-cancellation via Euclid; decimal repdigits are exact integers.
    return gcd(a*(10**m-1)//9,b*(10**n-1)//9)


def inverse_logs(base, target, modulus):
    values = [e for e in range(1,modulus) if pow(base,e,modulus)==target]
    return values[0] if values else None


def log_pair(base, target, modulus):
    return inverse_logs(base,target,modulus),inverse_logs(target,base,modulus)


@lru_cache(maxsize=1)
def class_catalog():
    return [(m,s) for m in range(4,16) for s in range(2,min(m,8))
            if unique_class_product(m,s)]


def sample_classes(rng):
    mod,size = rng.choice(class_catalog())
    return dict(mod=mod,size=size)


def class_products(mod, size):
    return {prod(residues)%mod for residues in combinations(range(1,mod),size)}-{0}


def unique_class_product(mod, size):
    return size<mod and len(class_products(mod,size))==1


def lcm_interval(lower, upper, moduli, remainder):
    period = lcm(*moduli)
    start = lower+1+(remainder-(lower+1))%period
    return list(range(start,upper,period))


def valid_lcm_interval(lower, upper, moduli, remainder):
    return remainder<min(moduli) and len(lcm_interval(lower,upper,moduli,remainder))==1


def sample_lcm_interval(rng):
    moduli = rng.sample(range(2,10),3)
    period = lcm(*moduli)
    remainder = rng.randrange(min(moduli))
    multiple = period*rng.randint(1,3)+remainder
    return dict(lower=multiple-rng.randint(1,period), upper=multiple+rng.randint(1,period),
                moduli=moduli,remainder=remainder)


def remainder_drop(value, modulus):
    r = value%modulus
    # At modulus/gcd(value,modulus), the remainder is zero.
    return value*next(i for i in range(2,modulus//gcd(value,modulus)+1) if value*i%modulus<r)


def max_stamps(a, b, target):
    return min((target-b*j)//a+j for j in range(target//b+1) if (target-b*j)%a==0)


def stamps_exist(a,b,target):
    return any((target-b*j)%a==0 for j in range(target//b+1))


def discrete_quadratic(period, lower):
    return next(n for n in range(lower+1,lower+period+1) if (n*n-n)%period==0)


def power_tower_ones(a,b,c,modulus):
    return pow(a,b**c,modulus)


train(23,'least_stamps',dict(a=(3,2,13),b=(4,2,17),target=(33,16,110)),
      'What is the least number of stamps of values {a} and {b} cents needed to make exactly {target} cents?',
      max_stamps,valid=stamps_exist,constraints=['At least one exact combination exists.'])
train(80,'two_lcm_constraints',dict(a=(24,2,40),b=(27,2,40),c=(72,2,600),d=(108,2,600)),
      'What positive integer n satisfies lcm({a}, n) = {c} and lcm(n, {b}) = {d}?',
      one(inverse_lcms),valid=singleton(inverse_lcms),sample=lcm_sample,
      constraints=['Exactly one common divisor of the two right-hand sides satisfies both equations.'])
train(105,'unit_digit_scaled_nested_exponent',dict(base=(22,11,70),scale=(22,2,40),
      inner=(11,2,20),power=(11,2,15)),
      'Find the units digit of {base}^({scale} × {inner}^{power}).',
      lambda base,scale,inner,power: pow(base,scale*inner**power,10))
train(113,'largest_remainder_below_budget',dict(limit=(100,21,300),friends=(11,3,20),extra=(2,1,18)),
      'A pile of fewer than {limit} coins leaves {extra} coins after giving equal shares to {friends} '
      'friends and maximizing the share. What is the largest possible pile?',
      lambda limit,friends,extra: limit-1-(limit-1-extra)%friends,
      valid=lambda limit,friends,extra: extra<friends and limit>friends+extra,
      constraints=['The remainder is below the number of friends and a positive share is possible.'])
train(120,'least_unequal_row_population',dict(lower=(30,10,200),rows=(4,2,14),extra=(1,1,12)),
      'There are more than {lower} students. They form {rows} rows, with equally many students in each '
      'except one row which has {extra} additional students. What is the least possible class size?',
      lambda lower,rows,extra: lower+1+(extra-(lower+1))%rows,
      valid=lambda lower,rows,extra: extra<rows and lower>=rows+extra,
      constraints=['Each short row is nonempty, and the difference is below the number of rows.'])
train(129,'repeating_card_rank',dict(index=(42,15,200),ranks=(13,5,21)),
      'A repeated sequence of cards has ranks numbered 1 through {ranks}, in increasing order in each repetition. '
      'What is the rank of card {index}?',
      lambda index,ranks: (index-1)%ranks+1,
      adaptation='Numbers the ranks 1 to 13 in the original order, with A = 1.')
train(159,'last_digits_known_power',dict(base=(3,2,19),known=(400,2,600),offset=(11600,2,11999),width=(3,1,4)),
      'Given that {base}^{known} leaves remainder 1 modulo 10^{width}, what is the base-ten value of '
      'the last {width} digits of {base}^({known} + {offset})?',
      lambda base,known,offset,width: pow(base,offset,10**width),
      valid=lambda base,known,offset,width: pow(base,known,10**width)==1,
      sample=lambda rng: dict(base=rng.choice([3,7,9,11,13,17,19]),known=400,
                              offset=rng.randint(2,99),width=rng.randint(1,3)),
      constraints=['The stated modular exponent identity holds.'],
      adaptation='Writes the queried exponent as a known period plus an independently variable offset.')
train(197,'aggregate_carton_remainder',dict(totals=([37,49,14],integers(3,3,180)),modulus=(12,3,30)),
      'Three sellers pool eggs from lots of sizes {totals}. They fill as many {modulus}-egg cartons as possible. '
      'How many eggs are left over?',listed_remainder)
train(256,'small_prime_product_remainder',dict(base=(2,2,8),power=(4,2,4),exclude=(2,2,7)),
      'Multiply all prime numbers less than {base}^{power}, excluding any primes at most {exclude}. '
      'What is the remainder modulo {base}^{power}?',
      lambda base,power,exclude: prod(p for p in primes(base**power-1) if p>exclude)%(base**power),
      valid=lambda base,power,exclude: exclude<base**power-1,
      constraints=['The cutoff lies below the modulus minus one.'],
      adaptation='Allows a prime cutoff; the source excludes only 2.')
train(287,'equal_full_pages_maximum',dict(first=(840,10,1500),second=(1008,10,1500)),
      'Two stamp albums have {first} and {second} stamps. All pages in both are full and have the same number '
      'of stamps. What is the greatest possible number of stamps per page?',
      lambda first,second: gcd(first,second),reference=lambda first,second: max(k for k in range(1,min(first,second)+1) if first%k==second%k==0))
train(303,'percent_divisible_in_prefix',dict(limit=(100,20,220),modulus=(5,2,20)),
      'What percentage of the positive integers up to {limit}, inclusive, are divisible by {modulus}? '
      'Give the number before the percent sign.',
      lambda limit,modulus: Fraction(100*(limit//modulus),limit))
train(305,'clock_component_sum',dict(hours=(122,1,240),minutes=(39,0,59),seconds=(44,0,59),cycle=(12,4,24)),
      'A clock uses hours 1 through {cycle} and displays {cycle}:00:00 now. After {hours} hours, '
      '{minutes} minutes and {seconds} seconds, what is the sum of the displayed hour, minute and second?',
      clock_components)
train(317,'square_residue_count',dict(modulus=(10,3,30),power=(2,2,5)),
      'How many different remainders can an integer {power}-th power have modulo {modulus}?',
      lambda modulus,power: len({pow(n,power,modulus) for n in range(modulus)}),
      adaptation='Generalizes the units digit (modulo 10) and exponent 2.')
train(342,'common_divisor_consecutive_sums',dict(length=(3,3,39),step=(1,1,16)),
      'What is the greatest positive integer that divides the sum of every arithmetic progression of '
      '{length} integer terms and common difference {step}?',
      lambda length,step: gcd(length,step*length*(length-1)//2),
      adaptation='Asks for the greatest universal divisor, which is the sole universal prime in the source.')
train(352,'first_quadratic_clock_fixed_point',dict(period=(12,3,36),lower=(4,1,60)),
      'On a {period}-hour clock, an elapsed whole number n of hours is clock equivalent to n² hours '
      'if they leave the same remainder modulo {period}. What is the smallest n greater than {lower} with this property?',
      discrete_quadratic)
train(375,'repacking_remainder',dict(boxes=(1335,80,1800),size=(39,12,45),new_size=(40,12,60)),
      'Unpack {boxes} boxes of {size} books and fill as many {new_size}-book boxes as possible. '
      'How many books are left over?',lambda boxes,size,new_size: boxes*size%new_size)
train(440,'simultaneous_periodic_awards',dict(capacity=(4000,180,6000),periods=([75,30,50],integers(3,2,90))),
      'The first {capacity} entrants are numbered 1 upward. Three gifts are given to entrants '
      'whose numbers are multiples of the respective periods {periods}. How many entrants receive all three?',
      lambda capacity,periods: capacity//lcm(*periods))
train(456,'largest_quotient_minus_remainder',dict(value=(839,40,1500),base=(19,2,28)),
      'Write {value} as {base}q + r with q and r positive integers, without imposing an upper bound on r. '
      'What is the greatest possible q − r?',
      lambda value,base: (base+1)*((value-1)//base)-value,
      reference=lambda value,base: max(q-(value-base*q) for q in range(1,(value-1)//base+1)))
train(472,'aggregate_balloon_remainder',dict(totals=([17,33,65,83],integers(4,3,120)),modulus=(8,3,24)),
      'Winnie has balloons in four lots of sizes {totals}. If she gives equal shares to {modulus} friends '
      'and gives away as many as possible, how many does she keep?',listed_remainder)
train(484,'minimal_packing_with_shortages',dict(lower=(100,25,300),size=(12,3,25),short=(2,1,9),missing=(1,1,4)),
      'A shipment has more than {lower} items. Of its {size}-item containers, {short} are short by '
      '{missing} items each, and all others are full. What is the smallest possible shipment size?',
      lambda lower,size,short,missing: size*max(short,(lower+short*missing)//size+1)-short*missing,
      valid=lambda lower,size,short,missing: missing<size,
      constraints=['A short container still holds at least one item.'])
train(485,'polynomial_at_residue',dict(mod=(50,10,80),deficit=(1,1,9),linear=(2,1,13),constant=(3,1,24)),
      'An integer n is {deficit} less than a multiple of {mod}. What is the remainder of '
      'n² + {linear}n + {constant} modulo {mod}?',
      lambda mod,deficit,linear,constant: (deficit**2-linear*deficit+constant)%mod)
train(512,'aggregate_unknown_bag_remainder',dict(bags=(3,2,16),modulus=(9,3,23),rem=(7,1,19)),
      'Each of {bags} bags contains the same number of candies. Dividing one bag among {modulus} '
      'kids leaves {rem} candies. What is the remainder when the combined bags are divided among the same kids?',
      lambda bags,modulus,rem: bags*rem%modulus,
      valid=lambda bags,modulus,rem: rem<modulus,constraints=['The original remainder is below the divisor.'])
train(518,'unique_common_remainder_interval',dict(lower=(10,0,600),upper=(100,20,1600),
      moduli=([3,4,5],integers(3,2,10)),remainder=(1,0,8)),
      'An integer is strictly between {lower} and {upper}. Its remainder is {remainder} '
      'for each divisor in {moduli}. What is the integer?',
      one(lcm_interval),valid=valid_lcm_interval,sample=sample_lcm_interval,
      constraints=['The common remainder is below each divisor and the open interval contains exactly one solution.'],
      adaptation='States the strict interval in number of dimes directly.')
train(523,'mixed_distance_units_remainder',dict(yards=(385,25,1100),unit=(1760,1200,2400),trips=(10,2,24)),
      lambda yards,unit,trips: (f'Each course is 26 miles and {yards} yards; a mile is 1,760 yards. '
                                f'After {trips} courses, how many yards remain after counting full miles?'
                                if unit==1760 else
                                f'A course measures 26 large units plus {yards} small units, with {unit} '
                                f'small units per large unit. After {trips} courses, how many small units '
                                'remain after counting full large units?'),
      lambda yards,unit,trips: yards*trips%unit,
      adaptation='Treats the unit conversion as a premise of each instance.')
train(541,'least_purchase_for_exact_remainder',dict(lower=(100,25,300),mod=(13,3,30),rem=(11,1,25)),
      'A shopper needs at least {lower} jellybeans and wants exactly {rem} left after sharing as many '
      'as possible among {mod} people. What is the smallest possible number of jellybeans?',
      lambda lower,mod,rem: lower+(rem-lower)%mod,
      valid=lambda lower,mod,rem: rem<mod,constraints=['The requested remainder is below the number of people.'])
train(598,'unit_digit_nested_exponent',dict(a=(9,2,42),b=(8,2,27),c=(7,2,25)),
      'Find the units digit of {a}^({b}^{c}).',
      lambda a,b,c: power_tower_ones(a,b,c,10))
train(683,'aggregate_lollipop_remainder',dict(totals=([45,116,4,229],integers(4,3,240)),modulus=(11,3,29)),
      'Winnie combines lollipops from lots of sizes {totals}. She gives the largest possible equal '
      'share to each of {modulus} friends. How many are left?',listed_remainder)
train(709,'least_common_multiple_excluding_divisor',dict(a=(30,2,55),b=(40,2,55),exclude=(16,2,60)),
      'What is the smallest positive integer divisible by both {a} and {b}, and indivisible by {exclude}?',
      lambda a,b,exclude: lcm(a,b),valid=lambda a,b,exclude: lcm(a,b)%exclude!=0,
      constraints=['The least common multiple is not divisible by the excluded divisor.'])
train(712,'unknown_factor_units_digit',dict(base=(21,3,71),power=(6,2,12),last=(7,1,9)),
      'Positive integers m and n satisfy mn = {base}^{power}, and the units digit of m is {last}. '
      'What is the units digit of n?',
      lambda base,power,last: pow(base,power,10)*pow(last,-1,10)%10,
      valid=lambda base,power,last: gcd(last,10)==1 and last in _possible_unit_factors(base,power),
      sample=lambda rng: _sample_unit_factor(rng),
      constraints=['The stated units digit is invertible modulo 10 and occurs among divisors of the product.'])
train(715,'maximum_weekday_in_period',dict(days=(49,14,280),week=(7,3,12)),
      'A calendar uses {week}-day weeks. What is the greatest possible number of occurrences of one '
      'fixed weekday in an interval of {days} consecutive days?',
      lambda days,week: ceildiv(days,week),
      adaptation='Permits hypothetical week lengths.')
train(729,'cancelled_variable_remainder',dict(a=(7,3,35),b=(3,1,24),mod=(7,3,35)),
      'For any integer n, what is the remainder when ({a} − n) + (n + {b}) is divided by {mod}?',
      lambda a,b,mod: (a+b)%mod)
train(816,'square_divisor_remainder_inverse',dict(number=(60,15,270),remainder=(6,2,27),query=(100,30,150)),
      'A positive integer k satisfies that {number} leaves remainder {remainder} on division by k². '
      'What is the remainder when {query} is divided by k?',
      lambda number,remainder,query: query%_square_quotient(number,remainder)[0],
      valid=lambda number,remainder,query: len(_square_quotient(number,remainder))==1,
      constraints=['Exactly one k meets the specified division condition.'])
train(854,'prime_multiple_card_probability',dict(cards=(50,15,120),divisor=(7,2,25)),
      'A uniformly random card is chosen from cards numbered 1 through {cards}. What is the probability '
      'its number is prime and divisible by {divisor}?',
      lambda cards,divisor: Fraction(int(divisor<=cards and prime(divisor)),cards),
      reference=lambda cards,divisor: Fraction(sum(p%divisor==0 for p in primes(cards)),cards))
train(855,'future_clock_hour',dict(now=(9,1,12),elapsed=(2004,15,3200),cycle=(12,8,25)),
      'A clock cycles through hours 1 to {cycle}. It is {now} o’clock now. What hour will it show '
      'after {elapsed} hours?',lambda now,elapsed,cycle: (now+elapsed-1)%cycle+1,
      valid=lambda now,elapsed,cycle: now<=cycle,constraints=['The starting hour is on the clock.'])
train(856,'unique_small_common_congruence',dict(moduli=([2,3,4,5,6],integers(5,2,12)),rem=(1,1,7)),
      'What two-digit positive integer leaves remainder {rem} when divided by each integer in {moduli}?',
      lambda moduli,rem: lcm_interval(9,100,moduli,rem)[0],
      valid=lambda moduli,rem: valid_lcm_interval(9,100,moduli,rem),
      constraints=['The same remainder is legal for each modulus and exactly one two-digit value qualifies.'])
train(862,'repdigit_gcd',dict(a=(2,1,9),b=(4,1,9),m=(8,2,17),n=(9,2,17)),
      'Find the gcd of the decimal integer consisting of {m} copies of digit {a} and the integer '
      'consisting of {n} copies of digit {b}.',repunit_gcd)


def _square_quotient(number,remainder):
    from math import isqrt
    return [k for k in range(2,isqrt(max(0,number-remainder))+1) if k*k>remainder
            and (number-remainder)%(k*k)==0]


def _possible_unit_factors(base,power):
    from .discrete_helpers import factors
    results = {1}
    for p,e in factors(base):
        results = {r*pow(p,i,10)%10 for r in results for i in range(e*power+1)}
    return results


def _sample_unit_factor(rng):
    base,power = rng.randint(3,71),rng.randint(2,12)
    return dict(base=base,power=power,last=rng.choice(sorted(
        d for d in _possible_unit_factors(base,power) if gcd(d,10)==1)))


test(6,'next_periodic_departure',dict(start=(313,230,380),arrival=(515,400,690),interval=(20,3,40)),
     'A bus first leaves {start} minutes after midnight and runs every {interval} minutes. '
     'Jerry arrives {arrival} minutes after midnight. How many minutes until the next available bus, '
     'counting a bus at his arrival time as available?',
     lambda start,arrival,interval: (start-arrival)%interval,
     adaptation='Uses minutes after midnight and clarifies arrivals exactly at departure.')
test(58,'shifted_product_congruence',dict(modulus=(20,4,40),residue=(17,1,38),multiple=(1,1,7)),
     lambda modulus,residue,multiple: f'Integers a and b have ab ≡ {residue} (mod {modulus}). '
     f'What is the remainder of (a + {multiple*modulus//2})(b + {multiple*modulus//2}) modulo {modulus}?',
     lambda modulus,residue,multiple: (residue+((multiple*modulus//2)**2 if modulus%4 else 0))%modulus,
     valid=lambda modulus,residue,multiple: modulus%2==0 and residue<modulus and
         (multiple%2==0 or residue%2==1),
     constraints=['The modulus is even; the known product is a residue and is odd for an odd half-modulus shift.'],
     reference=lambda modulus,residue,multiple: next((a+multiple*modulus//2)*(b+multiple*modulus//2)%modulus
         for a in range(modulus) for b in range(modulus) if a*b%modulus==residue))
test(72,'minimal_addition_to_full_units',dict(first=(8,2,65),second=(13,2,75),unit=(16,4,45)),
     lambda first,second,unit: f'A mixture contains {first} ounces of red candies and {second} ounces of green '
     f'candies. How many ounces of white candies must be added at minimum to make the total weight '
     f'an exact multiple of {unit} ounces?', lambda first,second,unit: (-first-second)%unit,
     adaptation='Treats the unit conversion as a premise.')
test(114,'distinct_class_nonzero_product',dict(mod=(6,4,15),size=(4,2,7)),
     'Take {size} integers pairwise incongruent modulo {mod}. Their product is not divisible '
     'by {mod}. What is the remainder of their product modulo {mod}?',
     lambda mod,size: min(class_products(mod,size)),valid=unique_class_product,sample=sample_classes,
     constraints=['There is exactly one nonzero remainder attainable by a product of that many distinct residues.'])
test(202,'aggregate_marbles_remainder',dict(totals=([239,174,83],integers(3,4,320)),modulus=(10,3,24)),
     'Three players pool lots of marbles of sizes {totals} into piles of {modulus}. How many marbles '
     'must be removed to leave as many complete piles as possible?',listed_remainder)
test(207,'last_digits_power_sum',dict(base=(2005,20,3000),powers=([2,0,0,5],integers(4,0,24)),width=(2,1,4)),
     'Raise {base} to each exponent in {powers} and add those powers, counting repeated exponents. '
     'What is the base-ten value of the last {width} digits?',
     lambda base,powers,width: sum(pow(base,e,10**width) for e in powers)%10**width)
test(226,'least_multiple_remainder_decrease',dict(value=(1342,18,2200),modulus=(13,3,29)),
     'What is the smallest positive multiple of {value} whose remainder modulo {modulus} '
     'is strictly less than the remainder of {value} itself?',remainder_drop,
     valid=lambda value,modulus: value%modulus!=0,
     constraints=['The original remainder is positive, so the zero remainder is smaller.'])
test(297,'reduce_known_remainder_to_divisor',dict(rows=(8,4,48),smaller=(4,2,12),rem=(7,1,30)),
     'Rows of {rows} leave {rem} students after forming as many complete rows as possible. '
     'What is the remainder if rows have {smaller} students?',
     lambda rows,smaller,rem: rem%smaller,
     valid=lambda rows,smaller,rem: rows%smaller==0 and smaller<rows and rem<rows,
     sample=lambda rng: (lambda k,m: dict(rows=k*m,smaller=k,rem=rng.randrange(1,k*m)))(
         rng.randint(2,8),rng.randint(2,4)),
     constraints=['The second row size properly divides the first; the original remainder is legal.'])
test(300,'totient_exponent_remainder',dict(modulus=(8,3,36),base=(3,2,45)),
     'Let n count the integers from 1 through {modulus} that are relatively prime to {modulus}. '
     'What is the remainder of {base}^n modulo {modulus}?',
     lambda modulus,base: pow(base,sum(gcd(k,modulus)==1 for k in range(1,modulus+1)),modulus))
test(342,'least_number_in_residue_and_units_classes',dict(a=(3,2,13),r=(2,1,9),b=(5,2,13),s=(4,1,9)),
     'A positive integer has remainder {r} modulo {a}. Its units digit equals the units digit of '
     'some positive integer with remainder {s} modulo {b}. What is the smallest possible first integer?',
     lambda a,r,b,s: _digit_congruences(a,r,b,s)[0],
     valid=lambda a,r,b,s: r<a and s<b and bool(_digit_congruences(a,r,b,s)),
     constraints=['Both residues are legal and at least one compatible units digit exists.'])
test(351,'pooled_currency_remainder',dict(totals=([2567,1721,3917,2632],integers(4,1000,8000)),modulus=(100,50,150)),
     'Four people earned {totals} cents. They pool the money and exchange as many full lots of '
     '{modulus} cents as possible for bills. How many cents remain?',listed_remainder,
     adaptation='Expresses individual earnings as cents and allows a hypothetical bill denomination.')
test(384,'mutual_discrete_logs_product',dict(base=(3,2,28),target=(5,2,28),modulus=(7,3,29)),
     'Let i and j be the smallest positive exponents such that {base}^i ≡ {target} and '
     '{target}^j ≡ {base}, both modulo {modulus}. What is the remainder of ij modulo {modulus} − 1?',
     lambda base,target,modulus: prod(log_pair(base,target,modulus))%(modulus-1),
     valid=lambda base,target,modulus: prime(modulus) and max(base,target)<modulus and
         all(e is not None for e in log_pair(base,target,modulus)),
     constraints=['The modulus is prime and the two nonzero residues generate the same subgroup.'])
test(397,'pooled_cookie_currency_remainder',dict(totals=([2747,3523,3737,2652],integers(4,1000,8000)),modulus=(100,50,150)),
     'Four sellers earned {totals} cents. They pool the money and exchange as many full lots of '
     '{modulus} cents as possible for bills. How many cents remain?',listed_remainder,
     adaptation='Expresses individual earnings as cents and allows a hypothetical bill denomination.')
test(446,'unique_multiple_consecutive_sum',dict(mod=(89,8,120),lower=(600,50,900),upper=(900,90,1200),length=(3,3,9)),
     'The sum of {length} consecutive integers is divisible by {mod} and strictly between {lower} '
     'and {upper}. What is the sum?',
     lambda mod,lower,upper,length: _consecutive_sums(mod,lower,upper,length)[0],
     valid=lambda mod,lower,upper,length: len(_consecutive_sums(mod,lower,upper,length))==1,
     constraints=['Exactly one multiple in the open interval can be such a sum.'])
test(528,'least_nonzero_residue_square_sum',dict(modulus=(3,2,25),count=(2,2,5)),
     'There are {count} positive integers, none divisible by {modulus}. What is the least '
     'possible remainder of the sum of their squares modulo {modulus}?',
     lambda modulus,count: _least_nonzero_square_sum(modulus,count),
     adaptation='Allows a variable number of summands.')


def _digit_congruences(a,r,b,s):
    common = gcd(10,b)
    period = lcm(a,common)
    return [n for n in range(1,period+1) if n%a==r and (n-s)%common==0]


def _consecutive_sums(mod,lower,upper,length):
    offset = length*(length-1)//2
    return [n for n in range((lower//mod+1)*mod,upper,mod) if (n-offset)%length==0]


def _least_nonzero_square_sum(modulus,count):
    squares = {pow(n,2,modulus) for n in range(1,modulus)}
    residues = {0}
    for _ in range(count):
        residues = {(a+b)%modulus for a in residues for b in squares}
    return min(residues)



def bounded_maximum_remainder(modulus,cap):
    return modulus-1 if cap==0 else min(modulus-1,cap-modulus)


def share_question(items,groups,modulus,cap):
    amount = f'A pile of at most {cap} {items}' if cap else f'A pile of {items}'
    return f'{amount} is divided among {modulus} {groups}. Each receives the same positive whole number of ' \
           f'items and shares are as large as possible. At least one item remains. What is the largest remainder?'


def share_sample(rng):
    modulus = rng.randint(3,24)
    return dict(modulus=modulus,cap=modulus+rng.randint(1,2*modulus))


for bind,number,modulus,items,groups in [
    (train,216,9,'pieces of candy','bags'),
    (train,681,5,'grapes','children'),
    (test,368,3,'pencils','bags'),
]:
    bind(number,'maximum_equal_share_remainder',dict(modulus=(modulus,2,24),cap=(0,0,72)),
         lambda modulus,cap,items=items,groups=groups: share_question(items,groups,modulus,cap),
         bounded_maximum_remainder,valid=lambda modulus,cap: cap==0 or cap>modulus,
         sample=share_sample,
         constraints=['If a cap is given, there are enough items for positive shares and a positive remainder.'],
         adaptation='Permits an upper bound on the number of items. The source has no upper bound.')
