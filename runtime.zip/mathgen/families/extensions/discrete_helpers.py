"""Utilities for the remaining discrete problem families."""

from copy import deepcopy
from itertools import product
from math import isqrt, prod
from .common import draw, integer, template


def binder(prefix):
    models = {}

    def register(number, family, fields, question, solve, *, valid=None, sample=None,
                 reference=None, constraints=(), adaptation=''):
        original = {}
        parameters = {}
        for name, field in fields.items():
            original[name] = field[0]
            parameters[name] = field[1] if len(field) == 2 else integer(field[1], field[2])

        def render(p):
            return question(**p) if callable(question) else question.format(**p)

        def proposals(rng):
            for _ in range(32):
                p = {k: draw(rng, d) for k, d in parameters.items()}
                if valid is None or valid(**p):
                    return p
            return deepcopy(original)

        models[f'{prefix}/{number}'] = template(
            f'discrete_{family}', parameters, original, render, lambda p: solve(**p),
            valid=(lambda p: valid(**p)) if valid else (lambda p: True),
            sample=sample or proposals,
            reference=(lambda p: reference(**p)) if reference else None,
            constraints=constraints, adaptation=adaptation,
        )

    return models, register


def prime(n):
    if n < 2 or n % 2 == 0:
        return n == 2
    return all(n % d for d in range(3, isqrt(n) + 1, 2))


def primes(n):
    sieve = bytearray(b'\1') * (n + 1)
    sieve[:2] = b'\0' * min(2, n + 1)
    for p in range(2, isqrt(n) + 1):
        if sieve[p]:
            sieve[p*p::p] = b'\0' * (1 + (n-p*p)//p)
    return [p for p in range(2, n + 1) if sieve[p]]


def factors(n):
    result = []
    for p in range(2, isqrt(n) + 1):
        if p*p > n:
            break
        exponent = 0
        while n % p == 0:
            exponent += 1
            n //= p
        if exponent:
            result.append((p, exponent))
    if n > 1:
        result.append((n, 1))
    return result


def divisors(n):
    low = [d for d in range(1, isqrt(n) + 1) if n % d == 0]
    return low + [n//d for d in reversed(low) if d*d != n]


def divisor_count(n):
    return prod(e+1 for _, e in factors(n))


def digits(n, base=10):
    result = []
    while n:
        n, digit = divmod(n, base)
        result.append(digit)
    return result[::-1] or [0]


def numeral(values):
    return ''.join(map(str, values))


def from_digits(values, base=10):
    value = 0
    for d in values:
        value = value * base + d
    return value


def digit_sum(n, base=10):
    return sum(digits(n, base))


def floor_root(n, power):
    lo, hi = 0, 1 << ((n.bit_length() + power - 1)//power)
    while lo < hi:
        mid = (lo + hi + 1)//2
        if mid**power <= n:
            lo = mid
        else:
            hi = mid-1
    return lo


def ceildiv(n, d):
    return -(-n//d)


def singleton(matches):
    """Return a validation callback for a bounded candidate search."""
    return lambda **p: len(matches(**p)) == 1


def one(matches):
    return lambda **p: matches(**p)[0]


def choose(rng, labels, tuples):
    return dict(zip(labels, rng.choice(tuples)))


def finite(*ranges):
    """Cartesian product of explicit finite domains for a sampler."""
    return product(*(range(lo, hi+1) for lo, hi in ranges))
