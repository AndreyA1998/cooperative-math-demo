"""Digit restrictions, decimal expansions and positional notation."""

from collections import deque
from fractions import Fraction
from functools import lru_cache
from itertools import combinations, permutations, product
from math import gcd, isqrt, prod

from .common import integers
from .discrete_helpers import (binder, ceildiv, choose, digit_sum, digits, factors, finite,
                               floor_root, from_digits, numeral, one, prime, primes, singleton)

TRAIN, train = binder('number_theory/train')
TEST, test = binder('number_theory/test')


def smallest_prime_sum(total, upper):
    return next((n for n in primes(upper) if digit_sum(n)==total),None)


def repeated_digit_cube(modulus, power):
    return [11*d for d in range(1,10) if (11*d)%modulus==0 and
            floor_root(d*d,power)**power==d*d]


def singleton_sampler(rng, labels, ranges, predicate):
    return choose(rng,labels,[t for t in finite(*ranges) if predicate(*t)])


def money_sum(base, values):
    return sum(int(str(v),base) for v in values)


def root_interval(divisor, lower, upper, power):
    denom = 10**power
    low = lower**power//denom+1
    high = ceildiv(upper**power,denom)-1
    return range(ceildiv(low,divisor)*divisor,high+1,divisor)


def sample_root_interval(rng, power):
    # Construct an interval of width one tenth around a root, then choose a
    # divisor with exactly one multiple in that interval.
    lower,upper = rng.choice([(q,q+1) for q in range(25,121)]) if power==3 else (
        lambda q: (q,q+2))(rng.randint(70,330))
    feasible = [m for m in range(2,100) if len(root_interval(m,lower,upper,power))==1]
    return dict(divisor=rng.choice(feasible),lower=lower,upper=upper)


def bounded_quotient(divisor, lower, upper):
    return list(range(divisor*lower//10+1,ceildiv(divisor*upper,10)))


def product_digits_multiple(modulus, base):
    """Find the shortest, lexicographically least accepted nonzero-digit word."""
    states = {}
    queue = deque()

    def enqueue(n, p, previous, digit):
        key = (n,p)
        if key not in states:
            states[key] = previous,digit
            queue.append(key)

    for d in range(1,base):
        enqueue(d%modulus,d%modulus,None,d)
    while queue:
        key = queue.popleft()
        if key == (0,0):
            word = []
            while key is not None:
                key,d = states[key]
                word.append(d)
            return from_digits(reversed(word),base)
        n,p = key
        for d in range(1,base):
            enqueue((n*base+d)%modulus,p*d%modulus,key,d)
    return None


def between_digit_sum(lower,total):
    # Try increasing lengths and lexicographic digits. The suffix can attain
    # every sum from 0 to nine times its length; prune infeasible prefixes.
    boundary = digits(lower+1)
    for width in range(len(boundary),6):
        low = boundary if width==len(boundary) else [1]+[0]*(width-1)
        for result in _minimum_sum_suffix(low,total,0,True):
            return from_digits(result)
    return None


def _minimum_sum_suffix(low,total,offset,tight):
    if offset==len(low):
        if total==0:
            yield []
        return
    start = low[offset] if tight else 0
    for d in range(start,10):
        if 0<=total-d<=9*(len(low)-offset-1):
            for suffix in _minimum_sum_suffix(low,total-d,offset+1,tight and d==start):
                yield [d,*suffix]


def palindromic_primes(width):
    half = (width+1)//2
    result = []
    for prefix in range(10**(half-1),10**half):
        value = str(prefix)
        palindrome = int(value+value[:width//2][::-1])
        if prime(palindrome):
            result.append(palindrome)
    return result


def bases_with_width(number,width):
    return [b for b in range(2,floor_root(number,width-1)+1) if number < b**width]


def two_base_digits(a,b,c,d):
    return [x for x in range(1,min(b,d,10)) if a<b and c<d and a*b+x==x*d+c]


def leading_two_base_digits(a,b,c,d):
    return [x for x in range(1,min(b,d,10)) if a<b and c<d and x*b+a==x*d+c]


def sample_two_base(rng, second_leading):
    values = [(a,b,c,d) for a,b,c,d in finite((1,8),(3,10),(0,8),(3,13))
              if (two_base_digits if second_leading else leading_two_base_digits)(a,b,c,d)]
    return choose(rng,('a','b','c','d'),values)


def repeating_part(num,den):
    seen = {}
    out = []
    remainder = num%den
    while remainder and remainder not in seen:
        seen[remainder] = len(out)
        digit,remainder = divmod(10*remainder,den)
        out.append(digit)
    return out[seen[remainder]:] if remainder else []


def leading_zeros(num,den):
    count = 0
    while 10*num<den:
        count += 1
        num *= 10
    return count


def valid_base(base, *numbers):
    return all(all(d<base for d in digits(n)) for n in numbers)


def equivalent_bases(left,known,right):
    return [b for b in range(max(2,1+max(digits(right))),11)
            if int(str(left),known)==int(str(right),b)] if valid_base(known,left) else []


def sample_equivalent_bases(rng):
    known = rng.randint(6,10)
    unknown = rng.randint(3,8)
    n = rng.randint(unknown**2,min(unknown**3-1,known**3-1))
    return dict(left=int(numeral(digits(n,known))),known=known,right=int(numeral(digits(n,unknown))))


def addition_bases(a,b,c):
    minimum = 1+max(d for n in [a,b,c] for d in digits(n))
    return [r for r in range(max(minimum,2),11) if int(str(a),r)+int(str(b),r)==int(str(c),r)]


def addition_sample(rng):
    base = rng.randint(5,10)
    limit = base**3
    left = rng.randint(limit,limit*base-1)
    right = rng.randint(limit//base,limit)
    a,b,c = [int(numeral(digits(n,base))) for n in [left,right,left+right]]
    return dict(a=a,b=b,c=c)


def two_digit_reversal(offset, multiplier):
    return [n for n in range(10,100) if 10*(n%10)+n//10+offset==multiplier*n]


def missing_radix_digit(base, prefix, tail, divisor):
    return [x for x in range(base) if (int(str(prefix),base)*base*base+x*base+tail)%divisor==0]


def valid_missing_radix(base,prefix,tail,divisor):
    return tail<base and valid_base(base,prefix) and len(missing_radix_digit(base,prefix,tail,divisor))==1


def sample_missing_radix(rng):
    base = rng.randint(4,10)
    prefix = int(numeral([rng.randrange(1,base),rng.randrange(base)]))
    tail = rng.randrange(base)
    x = rng.randrange(base)
    n = int(str(prefix),base)*base*base+x*base+tail
    options = [m for m in range(2,61) if n%m==0 and len(missing_radix_digit(base,prefix,tail,m))==1]
    # n itself always works; this constructive fallback remains in the public range.
    return dict(base=base,prefix=prefix,tail=tail,divisor=rng.choice(options or [n]))


def prime_permutation_sums(symbols):
    if len(symbols)%2 or len(symbols)!=len(set(symbols)):
        return set()

    def partitions(remaining):
        if not remaining:
            yield 0
            return
        a = remaining[0]
        for i,b in enumerate(remaining[1:],1):
            candidates = [n for n in (10*a+b,10*b+a) if n>=10 and prime(n)]
            if candidates:
                for subtotal in partitions(remaining[1:i]+remaining[i+1:]):
                    for n in candidates:
                        yield n+subtotal

    return set(partitions(tuple(symbols)))


@lru_cache(maxsize=1)
def prime_partition_catalog():
    return [s for size in [4,6] for s in combinations(range(10),size)
            if len(prime_permutation_sums(s))==1]


def sample_prime_partition(rng):
    return dict(symbols=list(rng.choice(prime_partition_catalog())))


def repdigit_factor_sums(width,total):
    return [n for n in ((10**width-1)//9*d for d in range(1,10))
            if sum(p*e for p,e in factors(n))==total]


def decimal_digits_of_sum(terms, length):
    value = sum(Fraction(n,d) for n,d in zip(terms[::2],terms[1::2]))
    return digit_sum(value.numerator*10**length//value.denominator%10**length)


def formed_multiples(digits,modulus):
    return [n for seq in permutations(digits) if seq[0] and (n:=from_digits(seq))%modulus==0]


def binary_alphabet_min(modulus, nonzero):
    # Each remainder has at most one shortest lexicographically first witness.
    queue = deque([(nonzero%modulus,nonzero)])
    seen = {nonzero%modulus}
    while queue:
        r,n = queue.popleft()
        if r==0:
            return n
        for d in [0,nonzero]:
            target = (10*r+d)%modulus
            if target not in seen:
                seen.add(target)
                queue.append((target,10*n+d))
    raise AssertionError('A repdigit multiple followed by zeros always exists')


def sequence_digit_gcd(width, step):
    numbers = [from_digits(range(d,d+width*step,step)) for d in range(1,10-(width-1)*step)]
    return gcd(*numbers)


def concatenated_squares(width_left,width_right):
    lo,hi = ceildiv(10**(width_left-1),1),10**width_left-1
    left = range(isqrt(lo-1)+1,isqrt(hi)+1)
    right = range(isqrt(10**(width_right-1)-1)+1,isqrt(10**width_right-1)+1)
    return [n for a,b in product(left,right) if
            isqrt(n:=a*a*10**width_right+b*b)**2==n]


train(16,'least_prime_with_digit_sum',dict(total=(19,2,29),upper=(999,250,9999)),
      'Find the least prime at most {upper} with decimal digit sum {total}.',
      smallest_prime_sum,valid=lambda total,upper: smallest_prime_sum(total,upper) is not None,
      constraints=['The search interval contains a prime of the requested digit sum.'],
      adaptation='Supplies a search upper bound above the source solution.')
train(75,'sum_of_base_encoded_balances',dict(base=(5,4,10),values=([3124,3122,124],integers(3,10,7777))),
      'Three amounts in base {base} are {values}. What is their sum in base ten?',
      money_sum,valid=lambda base,values: valid_base(base,*values),
      sample=lambda rng: (lambda b: dict(base=b,values=[int(numeral(digits(rng.randint(b,b**3-1),b)))
                                                      for _ in range(3)]))(rng.randint(4,10)),
      constraints=['All displayed digits are below the radix.'])
train(88,'double_digit_perfect_power',dict(modulus=(2,2,11),power=(3,2,7)),
      'A positive two-digit decimal number has equal digits and is divisible by {modulus}. '
      'The product of its digits is a perfect {power}-th power. What is the number?',
      one(repeated_digit_cube),valid=singleton(repeated_digit_cube),
      sample=lambda rng: singleton_sampler(rng,('modulus','power'),((2,11),(2,7)),
                                            lambda a,b: len(repeated_digit_cube(a,b))==1),
      constraints=['Exactly one repdigit satisfies both conditions.'])
train(99,'unique_multiple_with_cube_root_interval',dict(divisor=(18,2,99),lower=(80,25,120),upper=(81,26,125)),
      lambda divisor,lower,upper: f'Find the positive multiple of {divisor} whose cube root is strictly '
      f'between {lower/10:.1f} and {upper/10:.1f}.',
      lambda divisor,lower,upper: root_interval(divisor,lower,upper,3)[0],
      valid=lambda divisor,lower,upper: len(root_interval(divisor,lower,upper,3))==1,
      sample=lambda rng: sample_root_interval(rng,3),
      constraints=['The open cubed interval contains exactly one multiple.'])
train(119,'palindromic_prime_rank',dict(width=(3,1,5),rank=(2,1,20)),
      'What is the {rank}-th smallest {width}-digit palindromic prime?',
      lambda width,rank: palindromic_primes(width)[rank-1],
      valid=lambda width,rank: len(palindromic_primes(width))>=rank,
      constraints=['There are at least rank many palindromic primes of the specified width.'])
train(133,'unique_integer_rational_open_interval',dict(divisor=(3,2,12),lower=(75,12,150),upper=(80,13,160)),
      lambda divisor,lower,upper: f'For a whole number N, N/{divisor} is strictly between '
      f'{lower/10:.1f} and {upper/10:.1f}. What is N?',
      one(bounded_quotient),valid=singleton(bounded_quotient),
      sample=lambda rng: _sample_quotient(rng),
      constraints=['The scaled interval contains exactly one whole number.'])
train(144,'least_positive_multiple_with_digit_product_divisible',dict(modulus=(25,2,30),base=(10,4,12)),
      'In base {base}, what is the least positive multiple of {modulus} whose digit product is '
      'also a positive multiple of {modulus}? Give the result in base ten.',
      product_digits_multiple,valid=lambda modulus,base: product_digits_multiple(modulus,base) is not None,
      constraints=['The finite two-remainder automaton admits a nonzero-digit word.'])
train(214,'interval_contains_required_digits',dict(lower=(500,100,800),upper=(1000,850,1200),a=(3,0,9),b=(4,0,9)),
      'How many decimal integers strictly between {lower} and {upper} contain both digit {a} and digit {b}?',
      lambda lower,upper,a,b: sum(str(a) in str(n) and str(b) in str(n) for n in range(lower+1,upper)),
      valid=lambda lower,upper,a,b: a!=b,constraints=['The two required digits are distinct.'])
for number, lower, total in [(243,2000,12),(454,2010,3)]:
    train(number,'next_year_digit_sum',dict(lower=(lower,1600,4500),total=(total,2,25)),
          'What is the first year after {lower} whose decimal digits sum to {total}?',
          between_digit_sum,valid=lambda lower,total: (answer:=between_digit_sum(lower,total)) is not None
          and answer<=9999,constraints=['A later four-digit year with the required digit sum exists.'])
train(319,'largest_distinct_digit_number_matching_sum',
      dict(phone=([2,7,1,3,1,4,7],integers(7,0,9)),width=(4,2,6)),
      'A phone number has digits {phone}. What is the greatest {width}-digit positive integer with '
      'distinct digits that has the same digit sum as this phone number?',
      lambda phone,width: _largest_distinct_sum(sum(phone),width),
      valid=lambda phone,width: _largest_distinct_sum(sum(phone),width) is not None,
      constraints=['A distinct-digit numeral of the specified width attains the digit sum.'])
train(321,'equivalent_numerals_unknown_base',dict(left=(53,10,999),known=(6,6,10),right=(113,100,999)),
      'Find the base b (between 2 and 10) for which numeral {right} in base b equals numeral {left} in base {known}.',
      one(equivalent_bases),valid=singleton(equivalent_bases),sample=sample_equivalent_bases,
      constraints=['All digits are valid in the known base; exactly one base in the interval works.'])
for register, number, orig in [(train,330,(6453,7512,16165)),(test,381,(6651,115,10066))]:
    register(number,'positional_addition_unknown_base',dict(a=(orig[0],100,9999),b=(orig[1],100,9999),
             c=(orig[2],1000,19999)),
             'What base b from 2 through 10 makes {a} + {b} = {c}, with all three numerals in base b?',
             one(addition_bases),valid=singleton(addition_bases),sample=addition_sample,
             constraints=['Exactly one candidate radix admits all digits and satisfies the sum.'])
train(331,'digit_probability_in_repetend',dict(num=(5,1,50),den=(7,3,59),digit=(4,0,9)),
      'Choose a uniformly random position in one complete recurring block of the decimal expansion '
      'of {num}/{den}. What is the probability the digit is {digit}?',
      lambda num,den,digit: Fraction(repeating_part(num,den).count(digit),len(repeating_part(num,den))),
      valid=lambda num,den,digit: num<den and bool(repeating_part(num,den)),
      constraints=['The fraction is proper and has a nonempty recurring block.'],
      adaptation='Defines the uniform selection on one repetend, as in the source solution.')
train(341,'digit_sum_two_digit_repeating_decimal',dict(num=(3,1,50),den=(11,3,99)),
      'The decimal representation of {num}/{den} is 0.ababab… . What is a + b?',
      lambda num,den: sum(repeating_part(num,den)),
      valid=lambda num,den: num<den and len(repeating_part(num,den))==2 and 100*num%den==num%den,
      sample=lambda rng: (lambda d: dict(den=d,num=rng.choice([n for n in range(1,min(51,d))
              if len(repeating_part(n,d))==2])))(rng.choice([11,33,99])),
      constraints=['The proper fraction has a purely repeating decimal expansion of period two.'])
train(348,'missing_digit_radix_divisibility',dict(base=(5,4,10),prefix=(34,10,99),tail=(1,0,9),divisor=(31,2,9999)),
      'The four-digit numeral {prefix}x{tail} in base {base} is divisible by {divisor} in decimal. What is x?',
      one(missing_radix_digit),valid=valid_missing_radix,sample=sample_missing_radix,
      constraints=['All supplied digits are below the radix and exactly one missing digit works.'])
train(349,'sum_of_divisible_missing_digits',dict(prefix=(992466,1000,999999),hundreds=(1,0,9),
      units=(6,0,9),modulus=(8,2,17)),
      'Replace A with any decimal digit in {prefix}{hundreds}A{units}. What is the sum of the '
      'digits A for which the resulting number is divisible by {modulus}?',
      lambda prefix,hundreds,units,modulus: sum(a for a in range(10)
             if (prefix*1000+hundreds*100+10*a+units)%modulus==0))
train(385,'difference_of_radix_balances',dict(balance=(4444,1000,9999),base=(8,4,10),cost=(1000,10,1800)),
      'A traveler has {balance} dollars expressed in base {base}, and spends {cost} dollars in '
      'base ten. What is the remaining amount in base ten?',
      lambda balance,base,cost: int(str(balance),base)-cost,
      valid=lambda balance,base,cost: valid_base(base,balance) and int(str(balance),base)>=cost,
      sample=lambda rng: (lambda b,n: dict(base=b,balance=int(numeral(digits(n,b))),
          cost=rng.randint(10,min(n,1800))))(rng.randint(6,10),rng.randint(1000,1290)),
      constraints=['All digits are valid and the traveler has sufficient funds.'])
train(418,'leading_decimal_zero_count',dict(num=(3,1,9),den=(1250,20,15000)),
      'How many zeros occur after the decimal point and before the first nonzero digit of {num}/{den}?',
      leading_zeros,
      sample=lambda rng: dict(num=rng.randint(1,9),den=rng.choice([25,50,100,125,250,500,1000,1250,2500,5000,10000])),
      constraints=['The denominator exceeds the positive numerator.'])
train(489,'four_radix_quotient_sum',
      dict(a=(165,10,500),b=(11,10,33),c=(121,10,500),d=(21,10,33),
           ba=(7,3,10),bb=(2,2,5),bc=(6,3,10),bd=(3,2,5)),
      'Evaluate ({a} in base {ba}) / ({b} in base {bb}) + ({c} in base {bc}) / ({d} in base {bd}) in base ten.',
      lambda a,b,c,d,ba,bb,bc,bd: Fraction(int(str(a),ba),int(str(b),bb))+
                                  Fraction(int(str(c),bc),int(str(d),bd)),
      valid=lambda a,b,c,d,ba,bb,bc,bd: all(valid_base(r,n) for n,r in [(a,ba),(b,bb),(c,bc),(d,bd)]),
      sample=lambda rng: _sample_four_radices(rng),
      constraints=['Each numeral uses only digits below its stated radix.'])
train(690,'unique_radix_given_width',dict(number=(100,20,9000),width=(5,3,12)),
      'A decimal integer {number} has exactly {width} digits in base b. What is b?',
      one(bases_with_width),valid=singleton(bases_with_width),
      constraints=['Exactly one base has the specified numeral width.'])
train(745,'shared_digit_two_radices',dict(a=(3,1,8),b=(4,3,10),c=(2,0,8),d=(11,3,13)),
      'Find the positive digit x such that {a}x in base {b} equals x{c} in base {d}.',
      one(two_base_digits),valid=singleton(two_base_digits),sample=lambda rng: sample_two_base(rng,True),
      constraints=['The numerals are valid two-digit values and exactly one shared digit works.'])
train(756,'least_digit_reversal_solution',dict(offset=(3,0,40),multiplier=(2,1,6)),
      'What is the smallest two-digit decimal integer n for which reversing its digits and adding '
      '{offset} gives {multiplier}n? The reverse may have a leading zero.',
      lambda offset,multiplier: two_digit_reversal(offset,multiplier)[0],
      valid=lambda offset,multiplier: bool(two_digit_reversal(offset,multiplier)),
      constraints=['At least one two-digit integer satisfies the equation.'])
train(782,'shared_leading_digit_two_radices',dict(a=(4,1,8),b=(7,3,10),c=(1,0,8),d=(8,3,13)),
      'Find the leading digit x such that x{a} in base {b} equals x{c} in base {d}.',
      one(leading_two_base_digits),valid=singleton(leading_two_base_digits),
      sample=lambda rng: sample_two_base(rng,False),
      constraints=['The numerals are valid and exactly one shared leading digit works.'])
train(813,'sum_of_last_two_digits_of_power',dict(a=(2,1,14),b=(3,1,14),exponent=(23,2,45)),
      'What is the sum of the tens and ones digits of ({a} + {b})^{exponent}?',
      lambda a,b,exponent: digit_sum(pow(a+b,exponent,100)))
train(815,'maximal_digit_in_divisibility_pattern',dict(a=(5,1,9),b=(2,0,9),modulus=(22,2,35)),
      'Among six-digit decimal multiples of {modulus} of the form {a}d{a}{b}{b}e, where d and e '
      'are digits, what is the greatest possible d?',
      lambda a,b,modulus: _pattern_digits(a,b,modulus)[-1],
      valid=lambda a,b,modulus: bool(_pattern_digits(a,b,modulus)),
      constraints=['At least one assignment of d and e produces a multiple.'])
train(866,'unique_multiple_with_square_root_interval',dict(divisor=(14,2,99),lower=(250,70,330),upper=(253,71,337)),
      lambda divisor,lower,upper: f'Find the positive multiple of {divisor} whose square root is strictly '
      f'between {lower/10:.1f} and {upper/10:.1f}.',
      lambda divisor,lower,upper: root_interval(divisor,lower,upper,2)[0],
      valid=lambda divisor,lower,upper: len(root_interval(divisor,lower,upper,2))==1,
      sample=lambda rng: sample_root_interval(rng,2),
      constraints=['The open squared interval contains exactly one multiple.'])


def _sample_quotient(rng):
    choices = []
    for d,low in finite((2,12),(12,150)):
        high = low+1
        while high<=160 and len(bounded_quotient(d,low,high))<2:
            if bounded_quotient(d,low,high):
                choices.append((d,low,high))
                break
            high += 1
    return choose(rng,('divisor','lower','upper'),choices)


def _largest_distinct_sum(total,width):
    for chosen in combinations(range(9,-1,-1),width):
        if sum(chosen)==total and chosen[0]:
            return from_digits(chosen)
    return None


def _sample_four_radices(rng):
    bases = [rng.randint(3,9),rng.randint(2,5),rng.randint(3,9),rng.randint(2,5)]
    limits = [((1,4),True),((1,2),False),((1,4),True),((1,2),False)]
    ns = [rng.randrange(r,min(r**(3 if large else 2),r**2+1)) for r,(_,large) in zip(bases,limits)]
    return dict(zip(('a','b','c','d','ba','bb','bc','bd'),
                    [int(numeral(digits(n,b))) for n,b in zip(ns,bases)]+bases))


def _pattern_digits(a,b,modulus):
    return [d for d in range(10) if any((101000*a+10000*d+110*b+e)%modulus==0 for e in range(10))]


test(15,'least_multiple_using_two_digits',dict(modulus=(30,2,90),nonzero=(2,1,9)),
     'What is the smallest positive multiple of {modulus} using only the decimal digits 0 and {nonzero}?',
     binary_alphabet_min)
test(34,'count_digit_pair_multiples',dict(digits=([2,3,5,7,9],integers(5,0,9,min_length=3,max_length=7)),
     modulus=(3,2,13)),
     'Use two distinct digits from {digits} to form a positive two-digit decimal number. How many '
     'different such numbers are divisible by {modulus}?',
     lambda digits,modulus: len(formed_multiples_pair(digits,modulus)),
     valid=lambda digits,modulus: len(digits)==len(set(digits)),
     constraints=['The available digits are distinct.'])
test(55,'partition_digits_into_prime_pairs',dict(symbols=([1,2,3,4,5,6,7,9],integers(8,0,9,min_length=4,max_length=8))),
     lambda symbols: f'Use each digit in {symbols} exactly once to form {len(symbols)//2} two-digit primes. '
     'What is their total sum?',
     lambda symbols: min(prime_permutation_sums(symbols)),
     valid=lambda symbols: len(prime_permutation_sums(symbols))==1,
     sample=sample_prime_partition,
     constraints=['At least one prime partition exists and all prime partitions have the same sum.'])
test(69,'extrema_of_digit_permutation_multiples',dict(digits=([1,2,3,4],integers(4,0,9)),modulus=(4,2,24)),
     'Using every digit in {digits} exactly once, form four-digit positive multiples of {modulus}. '
     'What is the sum of the smallest and greatest such numbers?',
     lambda digits,modulus: (lambda ns: min(ns)+max(ns))(formed_multiples(digits,modulus)),
     valid=lambda digits,modulus: len(digits)==len(set(digits)) and bool(formed_multiples(digits,modulus)),
     constraints=['Digits are distinct and at least one admissible permutation has a nonzero leading digit.'])
test(111,'repdigit_from_prime_factor_sum',dict(width=(3,2,6),total=(47,4,380)),
     'A {width}-digit number repeats one nonzero digit. The sum of its prime factors counted with '
     'multiplicity is {total}. What is the number?',
     one(repdigit_factor_sums),valid=singleton(repdigit_factor_sums),
     sample=lambda rng: _sample_repdigit(rng),
     constraints=['Exactly one repdigit has the specified prime-factor sum.'],
     adaptation='States that repeated prime factors are counted with multiplicity.')
test(179,'decimal_digits_of_rational_sum',dict(terms=([4,37,3,11,23,9],integers(6,1,45)),length=(6,2,16)),
     'The alternating entries in {terms} are numerator-denominator pairs for three fractions. '
     'Add the fractions. What is the sum of the first {length} digits after the decimal point '
     'in the resulting decimal expansion, padding with zeros for a terminating expansion?',
     decimal_digits_of_sum,adaptation='States the digit count and the convention for terminating expansions.')
test(213,'unique_multiple_of_digit_sum',dict(multiplier=(2,2,9),width=(2,2,3)),
     'Which positive {width}-digit decimal integer equals {multiplier} times the sum of its digits?',
     lambda multiplier,width: _digit_sum_multiples(multiplier,width)[0],
     valid=lambda multiplier,width: len(_digit_sum_multiples(multiplier,width))==1,
     constraints=['Exactly one integer with the specified width satisfies the equation.'])
test(290,'least_reversible_prime_above_threshold',dict(lower=(17,4,700),upper=(100,30,1000)),
     'A reversible prime is a prime whose digit reversal is also prime. What is the least '
     'reversible prime strictly above {lower} and at most {upper}?',
     lambda lower,upper: _least_reversible(lower,upper),
     valid=lambda lower,upper: _least_reversible(lower,upper) is not None,
     constraints=['The search interval contains a reversible prime.'],
     adaptation='Supplies an upper bound above the source solution.')
test(292,'largest_self_dividing_units_digit',dict(base=(10,4,16),width=(2,2,4)),
     'A positive {width}-digit base-{base} integer is divisible by its nonzero units digit. '
     'What is the greatest possible value of that digit, in decimal?',
     lambda base,width: base-1,
     reference=lambda base,width: max(n%base for n in range(base**(width-1),base**width)
                                      if n%base and n%(n%base)==0),
     adaptation='Allows other radices. The base-minus-one digit has a repdigit or two-nonzero-digit witness.')
test(402,'gcd_of_increasing_digit_patterns',dict(width=(3,2,8),step=(1,1,4)),
     'Find the gcd of all positive {width}-digit decimal numbers whose successive digits increase by {step}.',
     sequence_digit_gcd,valid=lambda width,step: (width-1)*step<=8,
     constraints=['There is at least one admissible sequence of digits.'])
test(428,'concatenated_perfect_square_pair',dict(width_left=(2,1,4),width_right=(2,1,4)),
     'Concatenate a {width_left}-digit positive perfect square with a {width_right}-digit positive perfect square. '
     'What is the unique resulting number that is itself a perfect square?',
     one(concatenated_squares),valid=singleton(concatenated_squares),
     constraints=['Exactly one concatenation of positive squares is itself a square.'])
test(448,'sum_multiples_with_digit_sum',dict(modulus=(7,2,17),total=(10,2,17)),
     'What is the sum of all two-digit decimal multiples of {modulus} with digit sum {total}?',
     lambda modulus,total: sum(n for n in range(10,100) if n%modulus==0 and digit_sum(n)==total),
     adaptation='Asks for the sum over all solutions; the original instance has two.')
test(502,'least_integer_after_threshold_with_digit_sum',dict(lower=(3456,1200,9990),total=(12,1,32)),
     'What is the smallest decimal integer greater than {lower} whose digits sum to {total}?',
     between_digit_sum,valid=lambda lower,total: between_digit_sum(lower,total) is not None,
     constraints=['A solution exists below 100000.'])
test(530,'two_digit_primes_from_digit_set',dict(digits=([1,3,7],integers(3,0,9,min_length=2,max_length=6))),
     'How many different two-digit prime numbers can be formed using only digits in {digits}, with repetitions allowed?',
     lambda digits: sum(a!=0 and prime(10*a+b) for a,b in product(digits,repeat=2)),
     valid=lambda digits: len(digits)==len(set(digits)),constraints=['The input digits are distinct.'])


def formed_multiples_pair(symbols,modulus):
    return [10*a+b for a,b in permutations(symbols,2) if a and (10*a+b)%modulus==0]


def _sample_repdigit(rng):
    choices = []
    for width in range(2,7):
        for digit in range(1,10):
            n = (10**width-1)//9*digit
            total = sum(p*e for p,e in factors(n))
            if 4<=total<=380 and len(repdigit_factor_sums(width,total))==1:
                choices.append((width,total))
    return choose(rng,('width','total'),choices)


def _digit_sum_multiples(multiplier,width):
    return [n for n in range(10**(width-1),10**width) if n==multiplier*digit_sum(n)]


def _least_reversible(lower,upper):
    return next((n for n in primes(upper) if n>lower and prime(int(str(n)[::-1]))),None)



def absent_unit_digit(base, divisor, rank):
    common = gcd(base,divisor)
    return [d for d in range(base) if d%common][rank-1]


train(15,'rank_of_absent_units_digit',dict(base=(10,3,24),divisor=(2,2,24),rank=(1,1,15)),
      'In base {base}, list the digits that cannot occur as the units digit of a multiple of {divisor}. '
      'What is the {rank}-th smallest such digit, as a base-ten value?',
      absent_unit_digit,valid=lambda base,divisor,rank: rank<=base-base//gcd(base,divisor),
      constraints=['The number of forbidden digits is at least the requested rank.'],
      adaptation='Varies the radix, divisibility condition and rank.')
train(125,'product_of_two_decimal_digits_after_conversion',
      dict(base=(7,5,10),number=(656,100,999)),
      'Write the base-{base} numeral {number} as a three-digit decimal number. Divide the product '
      'of its tens and ones digits by 15. What is the result?',
      lambda base,number: (lambda n: Fraction(n//10%10*(n%10),15))(int(str(number),base)),
      valid=lambda base,number: valid_base(base,number) and 100<=int(str(number),base)<1000,
      constraints=['The numeral uses valid digits and its decimal representation has three digits.'],
      adaptation='Omits the redundant displayed hundreds digit.')
train(780,'prime_common_divisor_of_digit_reversal_difference',dict(base=(10,4,80)),
      'In base {base}, reverse the digits of a two-digit number with two distinct nonzero digits. '
      'Subtract the smaller numeral from the greater. What is the least prime dividing every such difference?',
      lambda base: factors(base-1)[0][0],
      adaptation='Allows other radices and chooses the least universal prime where several exist.')
