"""Exponent equations and compositions with power functions."""
from fractions import Fraction as Q
from functools import reduce

from .round3_algebra_train_common import decimal, register, root

BINDINGS = {}


def add(*args, **kwargs):
    register(BINDINGS, *args, **kwargs)


def prime_powers(n):
    result = {}
    divisor = 2
    while divisor*divisor<=n:
        while n%divisor==0:
            result[divisor] = result.get(divisor,0)+1
            n //= divisor
        divisor += 1
    if n>1:
        result[n] = 1
    return result


def exponent_ratio(value, base):
    """Rational e with base**e=value, or None when the ratio is irrational."""
    top, bottom = prime_powers(value), prime_powers(base)
    if top.keys()!=bottom.keys():
        return None
    ratios = {Q(top[k],bottom[k]) for k in bottom}
    return next(iter(ratios)) if len(ratios)==1 else None


add(510, 'power_equation_exponent_shift',
    (('base',7,2,20),('coefficient',4,1,25),('right_side',343,1,20**10),('shift',3,0,15)),
    lambda a,b,v,d:rf'If ${a}^{{{b}x}}={v}$, what is ${a}^{{{b}x-{d}}}$?',
    lambda a,b,v,d:Q(v,a**d))


def equal_summands(a,e,b):
    equation = '+'.join(rf'{a}^{{{e}}}' for _ in range(b))
    return rf'Find $x$ in ${equation}={b}^x$.'


add(943, 'sum_equal_powers_as_single_power',
    (('summand_base',9,2,128),('summand_exponent',4,1,12),('right_base',3,2,8)),
    equal_summands,
    lambda a,e,b:1+e*exponent_ratio(a,b),
    valid=lambda a,e,b:exponent_ratio(a,b) is not None,
    sample=lambda r:((b:=r.randint(2,5))**r.randint(1,3),r.randint(1,12),b),
    constraints=('summand_base and right_base have proportional prime-exponent vectors',),
    adaptation='Tie the number of equal summands to the displayed right-hand base, as in the source.')


add(1125, 'radical_power_exponent',
    (('left_base',81,2,100000),('root_degree',2,2,10),('right_base',3,2,100000)),
    lambda a,k,b:rf'Find $m$ such that $({a})^{{1/{k}}}={b}^m$.',
    lambda a,k,b:exponent_ratio(a,b)/k,
    valid=lambda a,k,b:exponent_ratio(a,b) is not None,
    sample=lambda r:((b:=r.randint(2,10))**r.randint(1,5),r.randint(2,10),b**r.randint(1,5)),
    constraints=('left_base and right_base have proportional prime-exponent vectors',))

add(1194, 'power_coefficient_inverse',
    (('coefficient',2,1,30),('target',4,2,100000),('given_x',4,2,100000)),
    lambda k,t,x:rf'If $x^{{{k}y}}={t}$ and $x={x}$, find $y$ as a fraction.',
    lambda k,t,x:exponent_ratio(t,x)/k,
    valid=lambda k,t,x:exponent_ratio(t,x) is not None,
    sample=lambda r:(r.randint(1,30),(b:=r.randint(2,10))**r.randint(1,5),b**r.randint(1,5)),
    constraints=('target and given_x have proportional prime-exponent vectors',))

add(1206, 'sqrt_square_composition',
    (('sqrt_coefficient',2,1,30),('argument',3,-100,100)),
    lambda a,x:rf'Let $N(x)={a}\sqrt x$ and $O(x)=x^2$. Find $N(O(N(O(N(O({x}))))))$.',
    lambda a,x:a**3*abs(x),
    reference=lambda a,x: reduce(lambda z,_:a*root(z*z,2),range(3),x))


def variation_root(a,rad,x,u):
    v=Q(rad*rad*u,x)
    q,d=root(v.numerator,4),root(v.denominator,4)
    return Q(a*q,d) if q**4==v.numerator and d**4==v.denominator else None


add(1310, 'quarter_power_variation',
    (('initial_multiplier',3,1,30),('initial_radicand',2,1,100),
     ('initial_x',81,1,1000000),('new_x',4,1,1000000)),
    lambda a,n,x,u:rf'If $y=kx^{{1/4}}$ and $y={a}\sqrt{{{n}}}$ when $x={x}$, find $y$ when $x={u}$.',
    variation_root,
    valid=lambda *p:variation_root(*p) is not None,
    sample=lambda r:((a:=r.randint(1,10)),(n:=r.randint(1,10))*r.randint(1,3)**2,
                     (n*r.randint(1,5)**2)**2,r.randint(1,5)**4),
    constraints=('initial_radicand²*new_x/initial_x is a rational fourth power',))


def reciprocal_power_solution(a,k,b,c):
    if (e:=exponent_ratio(a,b)) is None:
        return None
    powers={prime:e*k*exponent for prime,exponent in prime_powers(c).items()}
    if any(value.denominator!=1 for value in powers.values()):
        return None
    result=Q(1)
    for prime, value in powers.items():
        result /= prime**value.numerator
    return result


add(1358, 'reciprocal_power_transfer',
    (('left_base',64,2,100000),('left_exponent',5,1,12),
     ('right_base',32,2,100000),('query_base',2,2,100000)),
    lambda a,k,b,c:rf'If ${a}^{{{k}}}={b}^x$, find ${c}^{{-x}}$ as a fraction.',
    reciprocal_power_solution,
    valid=lambda *p:reciprocal_power_solution(*p) is not None,
    sample=lambda r:((b:=r.randint(2,10))**r.randint(1,5),r.randint(1,12),
                     b**(c:=r.randint(1,5)),r.randint(2,10)**c),
    constraints=('left_base and right_base have proportional prime-exponent vectors and query_base^(-x) is rational',))


add(1396, 'power_equation_nonzero_solution',
    (('left_coefficient',5,1,40),('right_coefficient',10,1,40),
     ('right_exponent',3,1,10),('left_exponent',4,2,11)),
    lambda a,b,c,d:rf'Find the nonzero real $x$ satisfying $({a}x)^{{{d}}}=({b}x)^{{{c}}}$. Express the answer as a fraction.',
    lambda a,b,c,d:Q(b**c,a**d),
    valid=lambda a,b,c,d:d==c+1, sample=lambda r:(r.randint(1,40),r.randint(1,40),(n:=r.randint(1,10)),n+1),
    constraints=('left_exponent is one more than right_exponent',))


def decimal_exponent_sample(r):
    base = r.randint(2,30)
    exps = [r.randint(0,20) for _ in range(4)]
    exps.append((-sum(exps))%10+10*r.randint(0,1))
    return (base,*exps)


add(1439, 'decimal_exponents_product',
    (('base',10,2,30),*((f'exponent{i}_tenths',v,0,20) for i,v in enumerate((5,3,2,1,9),1))),
    lambda a,*e:'Simplify $' + ''.join(rf'({a}^{{{decimal(x,1)}}})' for x in e) + '$.',
    lambda a,*e:a**(sum(e)//10),
    valid=lambda a,*e:sum(e)%10==0, sample=decimal_exponent_sample,
    constraints=('the sum of the five exponents is an integer',))


add(1476, 'defined_product_power_root',
    (('exponent',3,1,10),('target',625,1,20**11)),
    lambda e,t:rf'Define $E(a,b,c)=ab^c$. Find positive $r$ satisfying $E(r,r,{e})={t}$.',
    lambda e,t:root(t,e+1),
    valid=lambda e,t:root(t,e+1)**(e+1)==t,
    sample=lambda r:((e:=r.randint(1,10)),r.randint(1,20)**(e+1)),
    constraints=('target is a perfect (exponent+1)th power',))


add(1477, 'strict_integer_power_bound',
    (('numerator_exponent',4,2,18),('denominator_exponent',2,1,17),('bound',10,2,10000)),
    lambda a,b,t:rf'Find the greatest positive integer $x$ such that $\frac{{x^{{{a}}}}}{{x^{{{b}}}}}<{t}$.',
    lambda a,b,t:root(t-1,a-b),
    reference=lambda a,b,t:next(x-1 for x in range(2,t+1) if x**a>=t*x**b),
    valid=lambda a,b,t:a>b, constraints=('numerator_exponent > denominator_exponent',))
