"""Dispatcher for separately testable remaining-precalculus themes."""
from . import precalculus_geometry, precalculus_linear, precalculus_trig, precalculus_matrices, precalculus_sequences
def build(row):
    if row['subject']!='precalculus':return None
    for module in (precalculus_geometry,precalculus_linear,precalculus_trig,precalculus_matrices,precalculus_sequences):
        result=module.build(row)
        if result is not None:return result
    return None
