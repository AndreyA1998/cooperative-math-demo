"""Exact geometric, trigonometric and linear-algebra constructions.

Bindings are individually reviewed source IDs. Prompts are normalized mathematical
statements (no source-answer lookup); all correlated numeric roles are rendered
from one parameter. Proofs for identity/count families are in the expansion report.
"""
from fractions import Fraction as F
from math import gcd, isqrt
from functools import lru_cache
from itertools import combinations
from mathgen.core import Template


def I(lo=1,hi=30): return {'type':'int','min':lo,'max':hi}
def L(n,lo=-30,hi=30):
    return {'type':'list[int]','min_length':n,'max_length':n,'items':I(lo,hi)}
def sq(q):
    q=F(q)
    return q>=0 and isqrt(q.numerator)**2==q.numerator and isqrt(q.denominator)**2==q.denominator

def root(q):
    q=F(q)
    if not sq(q): raise ValueError('not a rational square')
    return F(isqrt(q.numerator),isqrt(q.denominator))
def dot(a,b): return sum(x*y for x,y in zip(a,b))
def cross(a,b): return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def det2(a,b): return a[0]*b[1]-a[1]*b[0]
def vec(v): return '('+', '.join(map(str,v))+')'
def _draw(r,d):
    if 'choices' in d: return r.choice(d['choices'])
    if d['type'].startswith('list'): return [_draw(r,d['items']) for _ in range(d['min_length'])]
    return r.randint(d['min'],d['max'])
def T(name,original,domains,render,solve,valid=lambda p:True,sample=None,reference=None,constraints=()):
    if sample is None: sample=lambda r:{k:_draw(r,d) for k,d in domains.items()}
    return Template('precalculus_v2.'+name,domains,original,render,solve,sample,valid,
                    list(constraints),reference,
                    'Equivalent normalized notation; tied numeric roles are rendered together. '
                    'Some families extend an implicit unit coefficient or number of terms.')

@lru_cache(None)
def nice_vectors(dim):
    if dim==2:
        return tuple((a,b) for a in range(-15,16) for b in range(-15,16)
                     if 0<a*a+b*b and sq(a*a+b*b))
    return tuple((a,b,c) for a in range(-12,13) for b in range(-12,13) for c in range(-12,13)
                 if 0<a*a+b*b+c*c and sq(a*a+b*b+c*c))

def _complex_product(values):
    a,b=1,0
    for v in values: a,b=a*v-b,a+b*v
    return a,b

def _cot_reference(p):
    values=p['cotangents']; coeff=[1]
    # Polynomial multiplication followed by i^j cycling, distinct from pair recursion.
    for v in values:
        new=[0]*(len(coeff)+1)
        for j,c in enumerate(coeff): new[j]+=v*c;new[j+1]+=c
        coeff=new
    re=sum(c*((-1)**(j//2)) for j,c in enumerate(coeff) if j%2==0)
    im=sum(c*((-1)**((j-1)//2)) for j,c in enumerate(coeff) if j%2)
    return F(re,im)

def _fib(n):
    a,b=0,1
    for _ in range(n): a,b=b,a+b
    return a

def _tridiagonal(n):
    # Determinant recurrence for the A_(n-1) Cartan matrix.
    a,b=1,2
    for _ in range(2,n):a,b=b,2*b-a
    return 1 if n==1 else b

def _line_ref(p):
    def point(t):
        y=F((p['c']-p['e'])*t+p['d']-p['f'],p['a']-p['b'])
        return p['c']*t+p['d']-p['a']*y,y
    a,b=point(0),point(1)
    return (b[1]-a[1])/(b[0]-a[0])

def _transform_ref(p):
    u,v,a,b=(p[k] for k in ('u','v','a','b'));d=det2(u,v)
    m00=F(a[0]*v[1]-b[0]*u[1],d);m01=F(b[0]*u[0]-a[0]*v[0],d)
    m10=F(a[1]*v[1]-b[1]*u[1],d);m11=F(b[1]*u[0]-a[1]*v[0],d)
    return m00*m11-m01*m10

def _root_angles(p):
    return [F(120*k,p['m']) for k in range(1,3*p['m'])
            if k%3 and p['lower']<F(120*k,p['m'])<p['upper']]


def build(row):
    key=row['id']
    if not key.startswith(('precalculus/','geometry/')): return None
    if key=='precalculus/train/52':
        return T('unity_sum',{'n':13},{'n':I(2,80)},
          lambda p:rf"Compute $\sum_{{j=1}}^{{{p['n']-1}}} e^{{2\pi i j/{p['n']}}}$.",lambda p:-1)
    if key=='precalculus/train/87':
        def weight_root(v,n):
            if n==1:return v if v<=20 else None
            # The root domain is bounded independently of large coefficient magnitudes.
            lo,hi=1,21
            while lo+1<hi:
                m=(lo+hi)//2
                if m**(n-1)<=v:lo=m
                else:hi=m
            return lo if lo**(n-1)==v else None
        def solve(p):
            if p['n']==1:return min(p['a'],p['b'])
            a,b=weight_root(p['a'],p['n']),weight_root(p['b'],p['n'])
            return F(a*b,a+b)**(p['n']-1)
        def sample(r):
            n,a,b=r.randint(1,12),r.randint(1,10),r.randint(1,10)
            return dict(n=n,a=a**max(1,n-1),b=b**max(1,n-1))
        def ref(p):
            d=weight_root(p['a'],p['n'])+weight_root(p['b'],p['n'])
            return min(p['a']*F(k,d)**p['n']+p['b']*F(d-k,d)**p['n'] for k in range(d+1))
        return T('even_trig_minimum',dict(n=2,a=1,b=1),{'n':I(1,20),'a':I(1,20**19),'b':I(1,20**19)},
          lambda p:rf"Find the minimum over real $x$ of ${p['a']}\sin^{{{2*p['n']}}}x+{p['b']}\cos^{{{2*p['n']}}}x$.",solve,
          lambda p:weight_root(p['a'],p['n']) is not None and weight_root(p['b'],p['n']) is not None,sample,ref,
          ['a and b are independent positive (n-1)th powers with integer roots in [1,20]; for n=1, a,b are in [1,20].'])
    complex_cases={'precalculus/train/96':(12,-9,8,15),'precalculus/test/58':(5,-8,30,48),'precalculus/test/103':(4,2,6,-3)}
    if key in complex_cases:
        a,b,c,d=complex_cases[key]
        def sample(r):
            if r.randrange(2):
                a,b=r.choice(nice_vectors(2));c,d=r.choice(nice_vectors(2))
            else:
                a,b=r.randint(1,10),r.randint(-10,10);k=r.randint(1,5);c,d=k*a,k*b*r.choice([-1,1])
            return dict(a=a,b=b,c=c,d=d)
        return T('complex_modulus_product',dict(a=a,b=b,c=c,d=d),{k:I(-60,60) for k in 'abcd'},
          lambda p:(rf"Evaluate $|{p['a']}+({p['b']})i|\cdot|{p['c']}+({p['d']})i|$." if key.endswith('/103') else rf"Evaluate $|({p['a']}+({p['b']})i)({p['c']}+({p['d']})i)|$." ),
          lambda p:root((p['a']**2+p['b']**2)*(p['c']**2+p['d']**2)),
          lambda p:sq((p['a']**2+p['b']**2)*(p['c']**2+p['d']**2)),sample,
          lambda p:root((p['a']*p['c']-p['b']*p['d'])**2+(p['a']*p['d']+p['b']*p['c'])**2),
          ['The product of squared moduli is a perfect square.'])
    if key=='precalculus/train/119':
        def sample(r):
            n=r.randint(2,15);m=r.randint(1,n-1)
            return {'a':n*n-m*m,'b':m*n}
        return T('tangent_cosine_equation',{'a':8,'b':3},{'a':I(1,300),'b':I(1,300)},
          lambda p:rf"If ${p['a']}\tan\theta={p['b']}\cos\theta$ and $0<\theta<\pi$, find $\sin\theta$.",
          lambda p:F(isqrt(p['a']**2+4*p['b']**2)-p['a'],2*p['b']),
          lambda p:sq(p['a']**2+4*p['b']**2),sample,
          constraints=['a²+4b² is a perfect square; positivity gives exactly one root sin(theta) in (0,1).'])
    if key=='precalculus/train/135':
        d=L(4,1,40);d['min_length']=2;d['max_length']=8
        return T('sum_inverse_cotangents',{'cotangents':[3,7,13,21]},{'cotangents':d},
          lambda p:r'Find $\cot('+ '+'.join(rf'\operatorname{{arccot}}({v})' for v in p['cotangents'])+r')$, with arccot in $(0,\pi)$.',
          lambda p:F(*_complex_product(p['cotangents'])),lambda p:_complex_product(p['cotangents'])[1]!=0,
          sample=lambda r:{'cotangents':[r.randint(1,30) for _ in range(r.randint(2,8))]},
          reference=_cot_reference,constraints=['Imaginary part of the product of (cotangent+i) is nonzero; cotangent is defined.'])
    if key=='precalculus/train/143':
        return T('tangent_product_power',{'m':45},{'m':I(1,90)},
          lambda p:rf"If $\prod_{{j=1}}^{{{p['m']}}}(1+\tan((45j/{p['m']})^\circ))=2^n$, find $n$.",
          lambda p:F(p['m']+1,2),reference=lambda p:1+(p['m']-1)//2+F(1,2)*(p['m']%2==0))
    if key=='precalculus/train/174':
        return T('half_angle_identity',{'tangent':5},{'tangent':I(1,50)},
          lambda p:rf"Given $\tan\theta={p['tangent']}$, evaluate $\frac{{1-\cos\theta}}{{\sin\theta}}-\frac{{\sin\theta}}{{1+\cos\theta}}$.",lambda p:0)
    if key=='precalculus/train/194':
        return T('moving_intersection_slope',dict(a=2,b=-1,c=7,d=3,e=2,f=-2),{k:I(-20,20) for k in 'abcdef'},
          lambda p:rf"For real $t$, intersect $x+({p['a']})y={p['c']}t+({p['d']})$ and $x+({p['b']})y={p['e']}t+({p['f']})$. Find the slope of the line traced by the intersection.",
          lambda p:F(p['c']-p['e'],p['a']*p['e']-p['b']*p['c']),
          lambda p:p['a']!=p['b'] and p['a']*p['e']!=p['b']*p['c'],reference=_line_ref,
          constraints=['a != b; a*e != b*c, so intersections exist and trace a nonvertical line.'])
    if key=='precalculus/train/225':
        return T('rotation_determinant',{'angle':58},{'angle':I(0,359)},
          lambda p:rf"Find the determinant of the matrix for a counterclockwise rotation by ${p['angle']}^\circ$ about the origin.",lambda p:1)
    if key=='precalculus/train/229':
        def power_root(v):
            n=1
            while n**6<v:n+=1
            return n
        return T('sixth_roots_positive_real',{'modulus':64},{'modulus':I(1,10**6)},
          lambda p:rf"Of the six complex roots of $z^6=-{p['modulus']}$, find the product of those with positive real part.",
          lambda p:power_root(p['modulus'])**2,lambda p:power_root(p['modulus'])**6==p['modulus'],
          sample=lambda r:{'modulus':r.randint(1,10)**6},constraints=['modulus is a positive perfect sixth power.'])
    if key=='precalculus/train/269':
        return T('unity_root_resultant',{'m':11,'n':13},{'m':I(2,40),'n':I(2,40)},
          lambda p:rf"Compute $\prod_{{k=1}}^{{{p['n']-1}}}\prod_{{j=1}}^{{{p['m']-1}}}(e^{{2\pi ji/{p['m']}}}-e^{{2\pi ki/{p['n']}}})$.",
          lambda p:int(gcd(p['m'],p['n'])==1))
    if key=='precalculus/train/281':
        return T('polar_rectangle',{'a':1,'b':1},{'a':I(),'b':I()},
          lambda p:rf"Find the area bounded by $r={p['a']}\sec\theta$, $r={p['b']}\csc\theta$, and the positive coordinate axes.",lambda p:p['a']*p['b'])
    if key=='precalculus/train/315':
        return T('complementary_tangent_product',{'angle':20},{'angle':I(1,44)},
          lambda p:rf"Simplify $(1+\tan {p['angle']}^\circ)(1+\tan {45-p['angle']}^\circ)$.",lambda p:2)
    if key=='precalculus/train/323':
        return T('incenter_bisector_ratio',dict(a=3,b=5,c=7),{k:I(1,50) for k in 'abc'},
          lambda p:rf"In triangle ABC, AB={p['c']}, AC={p['b']}, BC={p['a']}. Angle bisectors AD and BE meet at P. Find BP/PE.",
          lambda p:F(p['a']+p['c'],p['b']),lambda p:2*max(p.values())<sum(p.values()),
          constraints=['Strict triangle inequalities.'])
    if key=='precalculus/train/330':
        return T('commuting_matrix_ratio',dict(p=1,q=2,r=3,s=4),{k:I(-15,15) for k in 'pqrs'},
          lambda p:rf"Matrices $A=\begin{{pmatrix}}{p['p']}&{p['q']}\\{p['r']}&{p['s']}\end{{pmatrix}}$ and $B=\begin{{pmatrix}}a&b\\c&d\end{{pmatrix}}$ commute. Given $c\ne {p['r']}b$, find $(a-d)/(c-{p['r']}b)$.",
          lambda p:F(p['p']-p['s'],p['r']*(1-p['q'])),lambda p:p['q'] not in (0,1) and p['r']!=0,
          reference=lambda p:F(p['p']-p['s'],p['r']-p['r']*p['q']),
          constraints=['q != 0,1 and r != 0. The specified nonzero denominator is attainable (take B=A).'])
    if key in ('precalculus/train/336','precalculus/train/658'):
        minimum=key.endswith('/336')
        def render(p):
            e=rf"(\sin x+{p['k']}\csc x)^2+(\cos x+{p['k']}\sec x)^2"
            return (rf"Find the minimum of ${e}$ for $0<x<\pi/2$." if minimum else
                    rf"Find the constant $C$ in the identity ${e}=C+{p['k']**2}(\tan^2x+\cot^2x)$, where all expressions are defined.")
        return T('reciprocal_trig_minimum' if minimum else 'reciprocal_trig_identity',{'k':1},{'k':I(1,30)},render,
          (lambda p:(2*p['k']+1)**2) if minimum else (lambda p:1+4*p['k']+2*p['k']**2))
    if key=='precalculus/train/353':
        return T('finite_rotation_order',{'angle':60},{'angle':I(1,359)},
          lambda p:rf"Find the least positive integer n for which $\begin{{pmatrix}}\cos {p['angle']}^\circ&\sin {p['angle']}^\circ\\-\sin {p['angle']}^\circ&\cos {p['angle']}^\circ\end{{pmatrix}}^n=I$.",
          lambda p:360//gcd(p['angle'],360),reference=lambda p:next(n for n in range(1,361) if (n*p['angle'])%360==0))
    if key=='precalculus/train/390':
        return T('three_collinear_points',dict(A=1,B=2,C=3),{k:I(-20,20) for k in 'ABC'},
          lambda p:rf"The three points $({p['A']},a,b)$, $(a,{p['B']},b)$, $(a,b,{p['C']})$ are collinear. Find $a+b$.",
          lambda p:p['A']+p['C'],lambda p:len(set(p.values()))==3,
          constraints=['A, B, C are pairwise distinct; the collinearity minors force a=A and b=C.'])
    if key=='precalculus/train/430':
        def ratio(p):
            u=F(p['b'],p['a']+p['b']);v=F(p['c'],p['c']+p['d'])
            return abs(v-u)/(1-v)
        return T('triangle_transversal_ratio',dict(a=3,b=2,c=3,d=2),{k:I(1,20) for k in 'abcd'},
          lambda p:rf"In triangle ABC, D is on AB with AD:DB={p['a']}:{p['b']}, and E is on BC with BE:EC={p['c']}:{p['d']}. Lines DE and AC meet at F. Find DE/EF.",ratio,
          lambda p:p['b']*(p['c']+p['d'])!=p['c']*(p['a']+p['b']),
          constraints=['DE is not parallel to AC; points D and E are strictly on the sides.'])
    if key=='precalculus/train/491':
        return T('cassini',{'n':785},{'n':I(1,2000)},
          lambda p:rf"For Fibonacci numbers $F_0=0,F_1=1,F_{{k+2}}=F_{{k+1}}+F_k$, it is given that $\begin{{pmatrix}}1&1\\1&0\end{{pmatrix}}^k=\begin{{pmatrix}}F_{{k+1}}&F_k\\F_k&F_{{k-1}}\end{{pmatrix}}$ for positive integer k. Compute $F_{{{p['n']-1}}}F_{{{p['n']+1}}}-F_{{{p['n']}}}^2$.",
          lambda p:(-1)**p['n'],reference=lambda p:_fib(p['n']-1)*_fib(p['n']+1)-_fib(p['n'])**2)
    if key=='precalculus/train/498':
        def answer(p):return F(p['leg']**2-p['cevian']**2,p['ad'])
        return T('isosceles_cevian',dict(leg=7,ad=8,cevian=3),{k:I(1,30) for k in ('leg','ad','cevian')},
          lambda p:rf"In triangle ABC, AC=BC={p['leg']}. Point D lies on segment AB, AD={p['ad']} and CD={p['cevian']}. Find BD.",answer,
          lambda p:p['cevian']<p['leg'] and p['ad']+answer(p)<2*p['leg'],
          constraints=['cevian < leg and AD+BD < 2*leg, with BD=(leg²-cevian²)/AD; nondegenerate triangle and interior D.'])
    if key=='precalculus/train/510':
        return T('odd_angle_cosine_product',{'n':4},{'n':I(1,20)},
          lambda p:rf"Compute $\prod_{{k=1}}^{{{p['n']}}}(1+\cos((2k-1)\pi/{2*p['n']}))$.",lambda p:F(1,2**(p['n']-1)))
    if key=='precalculus/train/536':
        return T('trig_square_identity',{'angle':20},{'angle':I(1,89)},
          lambda p:rf"Evaluate $(\tan^2 {p['angle']}^\circ-\sin^2 {p['angle']}^\circ)/(\tan^2 {p['angle']}^\circ\sin^2 {p['angle']}^\circ)$.",lambda p:1)
    if key=='precalculus/train/557':
        return T('log_tangent_sum',{'n':90,'base':10},{'n':I(2,100),'base':I(2,30)},
          lambda p:rf"Compute $\sum_{{k=1}}^{{{p['n']-1}}}\log_{{{p['base']}}}(\tan(k\pi/{2*p['n']}))$.",lambda p:0)
    if key=='precalculus/train/573':
        def sample(r):
            a,b,k=r.randint(1,12),r.randint(-12,12),r.randint(1,10)
            return dict(a=k*a,b=k*b,c=a*a+b*b)
        return T('complex_modulus_quotient',dict(a=12,b=-8,c=13),{'a':I(-150,150),'b':I(-150,150),'c':I(1,300)},
          lambda p:rf"Suppose $wz={p['a']}+({p['b']})i$ and $|w|=\sqrt{{{p['c']}}}$. Find $|z|$.",
          lambda p:root(F(p['a']**2+p['b']**2,p['c'])),lambda p:sq(F(p['a']**2+p['b']**2,p['c'])),sample,
          constraints=['(a²+b²)/c is a rational square.'])
    if key=='precalculus/train/639':
        return T('semicircle_chord_product',{'n':7,'radius':2},{'n':I(2,25),'radius':I(1,10)},
          lambda p:rf"A semicircle of radius {p['radius']} has endpoints A,B and is divided into {p['n']} equal arcs by points C_1,...,C_{p['n']-1}. Find the product of all {2*(p['n']-1)} chord lengths AC_j and BC_j.",
          lambda p:p['n']*p['radius']**(2*p['n']-2),reference=lambda p:_tridiagonal(p['n'])*p['radius']**(2*p['n']-2))
    if key=='precalculus/train/683':
        return T('triangle_double_angle',dict(a=15,b=9),{'a':I(1,60),'b':I(1,40)},
          lambda p:rf"One triangle angle is twice another. The sides opposite these angles have lengths {p['a']} and {p['b']}, respectively. Find the third side.",
          lambda p:F(p['a']**2,p['b'])-p['b'],lambda p:p['b']<p['a']<2*p['b'],
          constraints=['b < a < 2b ensures the smaller angle lies in (0,60 degrees).'])
    if key=='precalculus/train/685':
        return T('sine_exponential_intersections',{'base':2,'interval':100},{'base':I(2,20),'interval':I(1,200)},
          lambda p:rf"Count solutions of $\sin x=({F(1,p['base'])})^x$ on $(0,{p['interval']}\pi)$.",
          lambda p:2*((p['interval']+1)//2),reference=lambda p:sum(2 for k in range(p['interval']) if k%2==0))
    if key=='precalculus/train/701':
        return T('cross_product_basis',dict(a=[3,1,-2],b=[0,2,-1],v=[4,1,-4]),{k:L(3,-15,15) for k in ('a','b','v')},
          lambda p:rf"Let a={vec(p['a'])}, b={vec(p['b'])}. If {vec(p['v'])}=p a+q b+r(a cross b), find r.",
          lambda p:F(dot(p['v'],cross(p['a'],p['b'])),dot(cross(p['a'],p['b']),cross(p['a'],p['b']))),
          lambda p:any(cross(p['a'],p['b'])),
          reference=lambda p:F(dot(p['a'],cross(p['b'],p['v'])),dot(p['a'],cross(p['b'],cross(p['a'],p['b'])))),
          constraints=['a and b are not parallel.'])
    if key=='precalculus/train/717':
        return T('rotation_dilation_tangent',dict(a=8,b=4),{'a':I(-30,30),'b':I(-30,30)},
          lambda p:rf"A positive dilation followed by a counterclockwise rotation through theta has matrix $\begin{{pmatrix}}{p['a']}&{-p['b']}\\{p['b']}&{p['a']}\end{{pmatrix}}$. Find tan(theta).",
          lambda p:F(p['b'],p['a']),lambda p:p['a']!=0,constraints=['a != 0, so tan(theta) is defined.'])
    if key=='precalculus/test/33':
        return T('area_side_angle',{'coefficient':1},{'coefficient':I(1,30)},
          lambda p:rf"Triangle ABC has area ${p['coefficient']}(a^2-(b-c)^2)$, with sides a,b,c opposite A,B,C. Find tan(A).",
          lambda p:F(8*p['coefficient'],16*p['coefficient']**2-1))
    if key=='precalculus/test/39':
        return T('complex_argument_extremum',{'small':1,'large':10},{'small':I(1,50),'large':I(2,100)},
          lambda p:rf"Complex numbers w,z satisfy |w|={p['small']}, |z|={p['large']}. For theta=arg((w-z)/z), find the maximum tan²(theta).",
          lambda p:F(p['small']**2,p['large']**2-p['small']**2),lambda p:p['small']<p['large'],
          constraints=['0 < small < large; the circle is separated from the imaginary axis, giving a finite maximum.'])
    if key=='precalculus/test/87':
        return T('tangent_secant_root_count',{'coefficient':2},{'coefficient':I(1,30)},
          lambda p:rf"Count solutions on $[0,2\pi]$ of $\tan x+\sec x={p['coefficient']}\cos x$.",
          lambda p:3 if p['coefficient']==1 else 2)
    if key=='precalculus/test/115':
        return T('reciprocal_unity_sum',{'n':3},{'n':{'type':'int','choices':list(range(3,32,2))}},
          lambda p:rf"If $\omega^{{{p['n']}}}=1$, find $\sum_{{k=1}}^{{{p['n']-1}}}1/(1+\omega^k)$.",lambda p:F(p['n']-1,2))
    if key=='precalculus/test/140':
        return T('sine_linear_root_count',{'frequency':6},{'frequency':I(1,100)},
          lambda p:rf"Find the number of real solutions to $\sin({p['frequency']}\pi x)=x$.",lambda p:4*((p['frequency']+1)//2)-1,
          reference=lambda p:1+2*sum(1 if k==0 else 2 for k in range(0,p['frequency'],2)))
    if key=='precalculus/test/163':
        def sample(r):
            m=r.randint(2,20);k=r.choice([k for k in range(1,3*m) if k%3]);angle=F(120*k,m)
            return dict(m=m,lower=angle.numerator//angle.denominator-1,upper=-(-angle.numerator//angle.denominator)+1)
        return T('unity_root_in_sector',dict(m=3,lower=90,upper=180),{'m':I(1,30),'lower':I(0,359),'upper':I(1,360)},
          lambda p:rf"The polynomial $z^{{{2*p['m']}}}+z^{{{p['m']}}}+1$ has exactly one root with argument measured in [0,360) degrees strictly between {p['lower']} and {p['upper']} degrees. Find its argument in degrees.",
          lambda p:_root_angles(p)[0],lambda p:p['lower']<p['upper'] and len(_root_angles(p))==1,sample,
          constraints=['Exactly one of the angles 120k/m, 1<=k<3m, k not divisible by 3, lies strictly inside the sector.'])
    if key=='precalculus/test/224':
        def ref(p):
            n=3*p['m'];result=1
            for k in range(1,n):
                if k%3:
                    order=n//gcd(n,k);result=result*order//gcd(result,order)
            return result
        return T('unity_polynomial_order',{'m':2},{'m':I(1,50)},
          lambda p:rf"Find the least positive n such that every root of $z^{{{2*p['m']}}}+z^{{{p['m']}}}+1=0$ is an nth root of unity.",
          lambda p:3*p['m'],reference=ref)
    if key=='precalculus/test/235':
        return T('integer_pi_exponential',{'multiple':1},{'multiple':I(-100,100)},
          lambda p:rf"Compute $e^{{{p['multiple']}\pi i}}$.",lambda p:1 if p['multiple']%2==0 else -1)
    if key=='precalculus/test/303':
        return T('basis_cross_norm_sum',{'norm':1},{'norm':I(1,30)},
          lambda p:rf"A vector a in three dimensions has norm {p['norm']}. For standard unit basis vectors i,j,k, compute ||a cross i||²+||a cross j||²+||a cross k||².",lambda p:2*p['norm']**2,
          reference=lambda p:sum(dot(cross([p['norm'],0,0],e),cross([p['norm'],0,0],e)) for e in ([1,0,0],[0,1,0],[0,0,1])))
    if key=='precalculus/test/313':
        return T('equiangular_hexagon_area_ratio',{'side':1,'percent':70},{'side':I(1,30),'percent':I(51,99)},
          lambda p:rf"Equiangular hexagon ABCDEF has AB=CD=EF={p['side']} and BC=DE=FA=r>0. Triangle ACE has {p['percent']}% of the hexagon's area. Find the sum of all possible r.",
          lambda p:F(p['side']*(4*p['percent']-100),100-p['percent']),
          constraints=['50 < percent < 100 gives two distinct positive reciprocal side ratios.'])
    if key=='precalculus/test/431':
        return T('arcsine_product_identity',dict(a=4,b=5,d=10),{'a':I(-30,30),'b':I(-30,30),'d':I(1,30)},
          lambda p:rf"Evaluate $\sin(\arcsin({F(p['a'],p['d'])})+\arcsin({F(p['b'],p['d'])}))\sin(\arcsin({F(p['b'],p['d'])})-\arcsin({F(p['a'],p['d'])}))$.",
          lambda p:F(p['b']**2-p['a']**2,p['d']**2),lambda p:abs(p['a'])<=p['d'] and abs(p['b'])<=p['d'],
          reference=lambda p:F(p['b']**2*(p['d']**2-p['a']**2)-p['a']**2*(p['d']**2-p['b']**2),p['d']**4),
          constraints=['Both arcsine arguments are in [-1,1].'])
    if key=='precalculus/test/435':
        return T('tan_sec_rational_identity',{'value':1},{'value':I(-30,30)},
          lambda p:rf"Given $\tan\theta\sec\theta={p['value']}$, find $(1+\sin\theta)/(1-\sin\theta)-(1-\sin\theta)/(1+\sin\theta)$.",lambda p:4*p['value'])
    if key=='precalculus/test/457':
        return T('reciprocal_trig_root_count',{'value':3,'periods':1},{'value':I(2,50),'periods':I(1,20)},
          lambda p:rf"Count solutions on $[0,{2*p['periods']}\pi]$ of $\frac{{1}}{{\sin^2\theta}}-\frac{{1}}{{\cos^2\theta}}-\frac{{1}}{{\tan^2\theta}}-\frac{{1}}{{\cot^2\theta}}-\frac{{1}}{{\sec^2\theta}}-\frac{{1}}{{\csc^2\theta}}=-{p['value']}$, requiring all displayed expressions to be defined.",
          lambda p:4*p['periods'])
    if key=='precalculus/test/473':
        return T('equally_spaced_cosine_squares',{'n':3},{'n':I(2,50)},
          lambda p:rf"Simplify $\sum_{{k=0}}^{{{p['n']-1}}}\cos^2(x+k\pi/{p['n']})$.",lambda p:F(p['n'],2))
    if key=='precalculus/test/475':
        return T('coplanar_rank_one_identity',{'k':1},{'k':I(1,30)},
          lambda p:rf"The points (0,0,0), (a,{p['k']},{p['k']}), ({p['k']},b,{p['k']}), ({p['k']},{p['k']},c) are coplanar; a,b,c are different from {p['k']}. Compute 1/({p['k']}-a)+1/({p['k']}-b)+1/({p['k']}-c).",
          lambda p:F(1,p['k']))
    if key=='precalculus/test/480':
        d=L(3,1,30);d['min_length']=2;d['max_length']=8
        return T('cosine_sum_extremal',{'frequencies':[1,2,3]},{'frequencies':d},
          lambda p:'If $'+'+'.join(rf'\cos({v}x)' for v in p['frequencies'])+f"={len(p['frequencies'])}$, find $"+'+'.join(rf'\sin({v}x)' for v in p['frequencies'])+'$.',
          lambda p:0,sample=lambda r:{'frequencies':[r.randint(1,30) for _ in range(r.randint(2,8))]})
    if key=='precalculus/test/511':
        return T('bisector_120_degrees',dict(b=3,c=6),{'b':I(1,50),'c':I(1,50)},
          lambda p:rf"D lies on BC in triangle ABC. Angles CAD and BAD are both 60 degrees. AC={p['b']}, AB={p['c']}. Find AD.",lambda p:F(p['b']*p['c'],p['b']+p['c']))
    if key=='precalculus/test/525':
        return T('linear_map_determinant',dict(u=[2,1],v=[3,0],a=[5,4],b=[1,2]),{k:L(2,-20,20) for k in ('u','v','a','b')},
          lambda p:rf"A two-dimensional linear map M sends {vec(p['u'])} to {vec(p['a'])} and {vec(p['v'])} to {vec(p['b'])}. Find det(M).",
          lambda p:F(det2(p['a'],p['b']),det2(p['u'],p['v'])),lambda p:det2(p['u'],p['v'])!=0,reference=_transform_ref,
          constraints=['The two input vectors are linearly independent.'])
    from mathgen.families.precalculus_geometry_v2 import build as geometry_build
    return geometry_build(row)
