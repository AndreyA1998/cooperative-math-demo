"""Versioned, validated composite programs; atomic solvers remain authoritative."""
from collections import OrderedDict, namedtuple
from copy import deepcopy
from fractions import Fraction
from functools import lru_cache, wraps
from hashlib import sha256
import json
import random
import re
from threading import RLock

from mathgen.corpus import load_corpus
from mathgen.core import validate_parameters
from mathgen.registry import get_template, solve as atomic_solve

VERSION = 'composite-2'
MAX_SCHEMA_BYTES = 8 * 1024 * 1024
MAX_VALIDATION_CACHE_BYTES = 8 * 1024 * 1024
MAX_NODES = 1536
MAX_DEPTH = 12
MAX_ARITY = 10
MAX_QUESTION_PATTERN_CHARS = 4000
MAX_PROFILE_BYTES = 512000


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False)


def seed_value(seed):
    if type(seed) is not int or not 0 <= seed < 2**64:
        raise ValueError('Seed must be an integer in [0, 2**64 - 1]')
    return seed


def derived_seed(seed, *parts):
    seed_value(seed)
    return int.from_bytes(sha256(canonical([VERSION, str(seed), *parts]).encode()).digest()[:8], 'big')


def digest(value):
    return sha256(canonical(value).encode()).hexdigest()


def schema_id(schema):
    return digest({k: v for k, v in schema.items() if k not in ('schema_id', 'problem_template')})


def profile_answers(source_id, profile):
    """Recompute certificates from native solvers, never trust a saved answer key."""
    encoded = canonical(profile)
    if len(encoded) > MAX_PROFILE_BYTES:
        raise ValueError('Invalid or oversized profile')
    if isinstance(profile, dict) and 'answers' in profile:
        # Validate JSON even for ignored metadata, then share certificates with
        # executable profiles, which deliberately omit saved answer tables.
        encoded = canonical({key: value for key, value in profile.items() if key != 'answers'})
    return _checked_profile(source_id, encoded)


@lru_cache(maxsize=2048)
def _checked_profile(source_id, serialized):
    from .operators import classify
    profile = json.loads(serialized)
    if len(serialized) > MAX_PROFILE_BYTES or not isinstance(profile, dict):
        raise ValueError('Invalid or oversized profile')
    t = get_template(source_id)
    if (profile.get('id') != source_id or type(profile.get('certificate_version')) is not int
            or profile['certificate_version'] != 1):
        raise ValueError('Profile source or certificate version mismatch')
    names, groups, rows = (profile.get(k) for k in ('parameter_names', 'groups', 'rows'))
    arity = profile.get('arity')
    if type(arity) is not int or not 1 <= arity <= MAX_ARITY:
        raise ValueError('Invalid profile arity')
    if not isinstance(names, list) or names != list(t.parameters):
        raise ValueError('Profile parameter names differ from native template')
    if not isinstance(groups, list) or len(groups) != arity or any(not isinstance(g, list) or not g for g in groups):
        raise ValueError('Invalid profile groups')
    flattened = [name for group in groups for name in group]
    if any(type(name) is not str for name in flattened) or sorted(flattened) != sorted(names):
        raise ValueError('Profile groups must own every native parameter exactly once')
    if not isinstance(rows, list) or len(rows) != 2**arity:
        raise ValueError('Incomplete Cartesian profile')
    answers = []
    for index, params in enumerate(rows):
        if not validate_parameters(t, params):
            raise ValueError('Profile contains invalid native parameters')
        for bit, group in enumerate(groups):
            for name in group:
                if params[name] != rows[(1 << bit) if index & (1 << bit) else 0][name]:
                    raise ValueError('Profile parameter depends on more than one child')
        answers.append(atomic_solve(source_id, params))
    truth = [classify(profile.get('classifier'), a) for a in answers]
    if (not isinstance(profile.get('truth_table'), list)
            or any(type(b) is not int or b not in (0, 1) for b in profile['truth_table'])
            or truth != profile['truth_table']):
        raise ValueError('Profile classifier certificate differs from native computation')
    expected_fixed = [name for name in names if rows[0][name] == rows[-1][name]]
    if profile.get('fixed_coordinates') != expected_fixed:
        raise ValueError('Profile fixed-coordinate metadata mismatch')
    for bit in range(arity):
        if not any(truth[i] != truth[i ^ (1 << bit)] for i in range(len(truth))):
            raise ValueError('Profile has a mathematically irrelevant child group')
    return tuple(answers)


@lru_cache(maxsize=4)
def _default_split_catalogue(split, provider):
    corpus = load_corpus()
    selected = {key: values for key, values in sorted(provider().items())
                if corpus[key]['split'] == split and values}
    return selected, digest(selected)


def build_schema(depth, width, seed, *, split='train', allow_template_reuse=False, catalogue=None):
    from .profiles import get_catalogue
    from .topology import sample_tree
    from .rendering import _render
    from .patterns import render_pattern
    seed_value(seed)
    if split not in ('train', 'test'):
        raise ValueError('split must be train or test')
    if type(allow_template_reuse) is not bool:
        raise ValueError('allow_template_reuse must be boolean')
    if catalogue is None:
        selected, catalogue_fingerprint = _default_split_catalogue(split, get_catalogue)
    else:
        corpus = load_corpus()
        selected = {key: values for key, values in sorted(deepcopy(catalogue).items())
                    if key in corpus and corpus[key]['split'] == split and values}
        catalogue_fingerprint = digest(selected)
    capabilities = {key: [len(values[0]['parameter_names'])] for key, values in selected.items()}
    tree = sample_tree(capabilities, depth, width, seed, allow_template_reuse)
    result = dict(tree, version=VERSION, seed=str(seed), split=split,
                  allow_template_reuse=tree.get('allow_template_reuse', allow_template_reuse),
                  catalogue_fingerprint=catalogue_fingerprint, support='certified-joint-upper/pattern-checked-bottom')
    for node in result['nodes']:
        available = selected[node['source_id']]
        if node['children']:
            # Maximize real answer diversity within a readable question budget.
            # Avoid thousands of repeated full statements from an opaque renderer.
            scored = [(len(set(profile_answers(node['source_id'], p))), p['arity']) for p in available]
            candidates = []
            rendered = []
            for score in sorted(set(scored), reverse=True):
                for p, candidate_score in zip(available, scored):
                    if candidate_score != score:
                        continue
                    length = len(render_pattern(node['source_id'], p, 'R', upper=True))
                    rendered.append((length, p))
                    if length <= MAX_QUESTION_PATTERN_CHARS:
                        candidates.append(p)
                if candidates:
                    break
            if not candidates:
                shortest = min(length for length, p in rendered)
                candidates = [p for length, p in rendered if length == shortest]
        else:
            candidates = [p for p in available if p['arity'] == 1] or available
        rng = random.Random(derived_seed(seed, 'profile', node['node_id']))
        profile = deepcopy(rng.choice(candidates))
        profile.pop('answers', None)
        profile_answers(node['source_id'], profile)
        node['profile'] = profile
        node['adapter'] = _joint_adapter(profile) if node['children'] else {'kind': 'external'}
        node['bindings'] = []
    ordered = sorted(result['nodes'], key=lambda n: (-n['level'], int(n['node_id'][1:])))
    for number, node in enumerate(ordered, 1):
        node['number'] = number
        node['label'] = 'R' + str(number)
    by_id = {n['node_id']: n for n in result['nodes']}
    for node in result['nodes']:
        node['bindings'] = _expected_bindings(node, by_id)
    result['schema_id'] = schema_id(result)
    validate_schema(result)
    result['problem_template'] = _render(result, None)
    validate_schema(result)
    return result


def _joint_adapter(profile):
    names = profile['parameter_names']
    return {'kind': 'joint_groups',
            'groups': [[names.index(name) for name in group] for group in profile['groups']]}


def _expected_bindings(node, by_id):
    """Consume each child answer once, as one signal for the joint adapter."""
    from .smart_adapters import compile_adapter
    profile = node['profile']
    result = []
    for index, child_id in enumerate(node['children']):
        name = profile['parameter_names'][index]
        group_index = next(g for g, names in enumerate(profile['groups']) if name in names)
        child = by_id[child_id]
        result.append({
            'source_node': child_id, 'source_id': child['source_id'],
            'receiver_id': node['source_id'], 'input_name': name,
            'input_index': index, 'group_index': group_index,
            'operator': compile_adapter(child['profile'], [0, 1],
                                        source_closed=bool(child['children']),
                                        source_answers=profile_answers(child['source_id'], child['profile'])),
        })
    return result


def validate_schema(schema):
    try:
        encoded = canonical(schema)
    except (TypeError, ValueError, OverflowError, RecursionError) as error:
        raise ValueError('Schema must contain finite JSON data') from error
    if len(encoded.encode()) > MAX_SCHEMA_BYTES:
        raise ValueError('Schema exceeds the size limit')
    # JSON encoding normalizes tuples and numeric subclasses. Validate the
    # original Python tree too, since execution uses its typed values.
    pending = [schema]
    while pending:
        value = pending.pop()
        if type(value) is dict:
            if any(type(key) is not str for key in value):
                raise ValueError('Schema object keys must be strings')
            pending.extend(value.values())
        elif type(value) is list:
            pending.extend(value)
        elif type(value) not in (str, int, bool, type(None)):
            raise ValueError('Schema must use exact JSON types without floats or tuples')
    try:
        _validate_schema_json(encoded)
    except (KeyError, TypeError, IndexError, OverflowError, RecursionError) as error:
        raise ValueError('Malformed composite schema') from error
    return schema


def _bounded_validation_cache(function):
    """Retain successful full-JSON checks within both entry and byte limits."""
    entries = OrderedDict()
    lock = RLock()
    info_type = namedtuple('CacheInfo', 'hits misses maxsize currsize')
    retained_bytes = hits = misses = 0

    @wraps(function)
    def validate(encoded):
        nonlocal retained_bytes, hits, misses
        with lock:
            if encoded in entries:
                entries.move_to_end(encoded)
                hits += 1
                return
            misses += 1
        # Failed validations are never cached. Keep native checks outside the
        # cache lock, as functools.lru_cache does for concurrent misses.
        function(encoded)
        size = len(encoded.encode())
        with lock:
            if size <= MAX_VALIDATION_CACHE_BYTES and encoded not in entries:
                while entries and (len(entries) >= 128
                                   or retained_bytes + size > MAX_VALIDATION_CACHE_BYTES):
                    _, evicted_size = entries.popitem(last=False)
                    retained_bytes -= evicted_size
                entries[encoded] = size
                retained_bytes += size

    def cache_clear():
        nonlocal retained_bytes, hits, misses
        with lock:
            entries.clear()
            retained_bytes = hits = misses = 0

    def cache_info():
        with lock:
            return info_type(hits, misses, 128, len(entries))

    validate.cache_clear = cache_clear
    validate.cache_info = cache_info
    return validate


@_bounded_validation_cache
def _validate_schema_json(encoded):
    schema = json.loads(encoded)
    if not isinstance(schema, dict) or schema.get('version') != VERSION:
        raise ValueError('Unsupported composite schema version')
    allowed = {'actual_width', 'allow_template_reuse', 'catalogue_fingerprint', 'depth',
               'nodes', 'requested_width', 'root_id', 'schema_id', 'seed', 'split', 'support', 'version'}
    sampling_fields = {'sampling_policy', 'minimum_internal_nodes', 'internal_node_budget'}
    optional = {'problem_template', 'requested_allow_template_reuse'} & set(schema)
    if set(schema) not in (allowed | optional, allowed | optional | sampling_fields):
        raise ValueError('Unknown or missing schema fields')
    if (type(schema['catalogue_fingerprint']) is not str
            or re.fullmatch(r'[0-9a-f]{64}', schema['catalogue_fingerprint']) is None
            or schema['support'] != 'certified-joint-upper/pattern-checked-bottom'):
        raise ValueError('Invalid catalogue or support metadata')
    if schema.get('schema_id') != schema_id(schema):
        raise ValueError('Composite schema fingerprint mismatch')
    if (type(schema.get('seed')) is not str or not 1 <= len(schema['seed']) <= 20
            or not schema['seed'].isascii() or not schema['seed'].isdigit()):
        raise ValueError('Schema seed must be decimal text')
    seed_value(int(schema['seed']))
    depth = schema.get('depth')
    if type(depth) is not int or not 1 <= depth <= MAX_DEPTH:
        raise ValueError('Invalid depth')
    if schema.get('split') not in ('train', 'test') or type(schema.get('allow_template_reuse')) is not bool:
        raise ValueError('Invalid split or reuse policy')
    if 'requested_allow_template_reuse' in schema:
        requested_reuse = schema['requested_allow_template_reuse']
        if (type(requested_reuse) is not bool
                or (requested_reuse and not schema['allow_template_reuse'])):
            raise ValueError('Invalid requested reuse policy')
    nodes = schema.get('nodes')
    if not isinstance(nodes, list) or not 1 <= len(nodes) <= MAX_NODES:
        raise ValueError('Invalid node count')
    if any(not isinstance(n, dict) for n in nodes):
        raise ValueError('Invalid nodes')
    if 'sampling_policy' in schema:
        minimum, budget = schema['minimum_internal_nodes'], schema['internal_node_budget']
        width = schema.get('actual_width')
        internal = sum(bool(node.get('children')) for node in nodes)
        # These are provenance bounds, not an optimality certificate. Saved
        # schemas execute their explicit shape without rerunning the sampler.
        if (schema['sampling_policy'] != 'compact-shape-first-1'
                or type(minimum) is not int or type(budget) is not int
                or type(width) is not int
                or not depth - 1 <= minimum <= internal <= budget <= (depth - 1) * width):
            raise ValueError('Invalid compact sampling metadata')
    ids = [n.get('node_id') for n in nodes]
    if ids != ['n' + str(i) for i in range(len(nodes))] or schema.get('root_id') != 'n0':
        raise ValueError('Node IDs must be canonical BFS addresses with root n0')
    by_id = {n['node_id']: n for n in nodes}
    corpus = load_corpus()
    source_ids, parents, leaves, numbers = [], [], [], []
    for node in nodes:
        if set(node) != {'node_id', 'source_id', 'level', 'arity', 'children', 'profile', 'bindings', 'number', 'label', 'adapter'}:
            raise ValueError('Unknown or missing node fields')
        source_id = node.get('source_id')
        if source_id not in corpus or corpus[source_id]['split'] != schema['split']:
            raise ValueError('Unknown or cross-split source ID')
        source_ids.append(source_id)
        if type(node.get('level')) is not int or not 0 <= node['level'] < depth:
            raise ValueError('Invalid node level')
        if type(node.get('number')) is not int or node.get('label') != 'R' + str(node['number']):
            raise ValueError('Invalid public node label')
        numbers.append(node['number'])
        profile = node.get('profile')
        if (not isinstance(profile, dict) or set(profile) != {'id', 'arity', 'parameter_names', 'groups',
                'rows', 'classifier', 'truth_table', 'certificate_version', 'fixed_coordinates'}):
            raise ValueError('Invalid node profile fields')
        profile_answers(source_id, profile)
        children, arity = node.get('children'), node.get('arity')
        if type(arity) is not int or not isinstance(children, list) or arity != len(children):
            raise ValueError('Invalid children')
        if any(type(c) is not str or c not in by_id for c in children) or len(set(children)) != arity:
            raise ValueError('Unknown or repeated child')
        if children:
            if arity != len(profile['parameter_names']) or node['level'] == depth - 1:
                raise ValueError('Joint adapter requires one child per native input port')
            if canonical(node['adapter']) != canonical(_joint_adapter(profile)):
                raise ValueError('Joint adapter groups must partition every incoming signal exactly once')
            for child in children:
                if by_id[child]['level'] != node['level'] + 1:
                    raise ValueError('Edges must connect adjacent levels')
                parents.append(child)
            expected = _expected_bindings(node, by_id)
            if canonical(node.get('bindings')) != canonical(expected):
                raise ValueError('Bindings do not match the certified joint input signals')
        else:
            if (node['level'] != depth - 1 or node.get('bindings') != []
                    or node['adapter'] != {'kind': 'external'}):
                raise ValueError('Every leaf must be on the bottom level')
            leaves.append(node['node_id'])
    display_order = sorted(nodes, key=lambda n: (-n['level'], int(n['node_id'][1:])))
    if [n['number'] for n in display_order] != list(range(1, len(nodes) + 1)):
        raise ValueError('Public labels must follow canonical bottom-up order')
    if nodes[0]['level'] != 0 or sorted(parents) != sorted(ids[1:]):
        raise ValueError('Composite must be a single rooted tree without unused nodes')
    if not schema['allow_template_reuse'] and len(set(source_ids)) != len(source_ids):
        raise ValueError('Source ID reused despite uniqueness policy')
    actual, requested = schema.get('actual_width'), schema.get('requested_width')
    if type(actual) is not int or type(requested) is not int or not 1 <= actual <= requested or actual != len(leaves):
        raise ValueError('Invalid requested or actual width')

    if 'problem_template' in schema:
        from .rendering import _render
        if schema['problem_template'] != _render(schema, None):
            raise ValueError('Public template does not match its executable schema')
