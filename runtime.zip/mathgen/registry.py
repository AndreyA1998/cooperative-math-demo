"""Bind source IDs to strict family builders. No silent static fallback."""
from functools import lru_cache
from copy import deepcopy
import importlib
from .corpus import load_corpus
from .core import canonical_answer, instantiate, validate_parameters, VERSION

FAMILY_MODULES = ('algebra', 'discrete', 'geometry', 'arithmetic', 'word', 'discrete_extra', 'word_extra', 'algebra_extra', 'algebra_v2', 'discrete_v2', 'word_v2', 'precalculus_v2', 'precalculus_v3', 'extensions.algebra', 'extensions.discrete', 'extensions.word', 'extensions.precalculus', 'extensions.geometry_hexagon', 'extensions.round2_algebra', 'extensions.round2_intermediate', 'extensions.round2_mixed', 'extensions.round3_algebra_train', 'extensions.round3_algebra_test', 'extensions.round3_intermediate', 'extensions.round3_precalculus', 'extensions.round3_geometry')


class UnsupportedProblemError(ValueError):
    pass


@lru_cache(maxsize=1)
def _builders():
    return tuple(importlib.import_module('.families.'+name,'mathgen') for name in FAMILY_MODULES)


@lru_cache(maxsize=None)
def _bind_id(problem_id):
    """Validate and cache only this source row; unsupported rows cache None."""
    row=load_corpus()[problem_id]
    for module in _builders():
        template=module.build(row)
        if template is None:continue
        if not validate_parameters(template,template.original):
            raise ValueError(f'{problem_id}: original parameters outside domain ({template.family})')
        if canonical_answer(template.solve(template.original))!=canonical_answer(row['answer']):
            raise ValueError(f'{problem_id}: source answer regression ({template.family})')
        from .families.reformulated import reformulate
        return reformulate(problem_id, template)
    return None


@lru_cache(maxsize=1)
def registry():
    """The full catalogue, sharing exactly the same bindings as single-ID calls."""
    result={}
    for problem_id in load_corpus():
        template=_bind_id(problem_id)
        if template is not None:result[problem_id]=template
    return result


def get_template(problem_id):
    if problem_id not in load_corpus():raise KeyError(f'Unknown source ID: {problem_id}')
    template=_bind_id(problem_id)
    if template is None:
        raise UnsupportedProblemError(f'{problem_id}: no verified parameterized family; see reports/UNSUPPORTED.md')
    return template


def generate(problem_id, seed):
    return instantiate(load_corpus()[problem_id],get_template(problem_id),seed)


def solve(problem_id, parameters):
    t=get_template(problem_id)
    if not validate_parameters(t,parameters):
        raise ValueError('Parameters violate declared domains or joint constraints; use describe(id)')
    return canonical_answer(t.solve(parameters))


def describe(problem_id):
    t=get_template(problem_id);r=load_corpus()[problem_id]
    result = {'id':problem_id,'split':r['split'],'subject':r['subject'],
            'family':t.family,'generator_version':VERSION,'parameters':t.parameters,
            'constraints':t.constraints,'original_parameters':t.original,
            'original_rendered':t.render(t.original),'adaptation':t.adaptation,
            'has_reference':t.reference is not None, 'answer_type':'exact rational scalar'}
    if hasattr(t, 'reformulation'):
        result['reformulated'] = True
        result['reformulation'] = deepcopy(t.reformulation)
    return deepcopy(result)
