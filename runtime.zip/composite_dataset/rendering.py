"""Public mathematical text built without access to instance answer traces."""
import json

from template_dataset.registry import get_template
from .patterns import render_pattern
from .schema import validate_schema
from .smart_adapters import describe_adapter


def render(schema, bottom_parameters=None):
    validate_schema(schema)
    if bottom_parameters is not None:
        from .runtime import checked_bottom
        checked_bottom(schema, bottom_parameters)
    return _render(schema, bottom_parameters)


def _render(schema, bottom_parameters):
    nodes = sorted(schema['nodes'], key=lambda node: node['number'])
    by_id = {node['node_id']: node for node in nodes}
    text = [
        'Solve the subproblems in order. R1, R2, … denote their exact answers. '
        'Within each subproblem, substitute the local input values for the slots in ⟨angle brackets⟩.',
        'If a subproblem requests digits without a base subscript, read that digit sequence '
        'as a decimal integer in the conversion rules.',
    ]
    for node in nodes:
        label = node['label']
        source_id = node['source_id']
        text.append(f"\nSubproblem {node['number']} ({label})")
        if not node['children']:
            if bottom_parameters is None:
                text.append('Inputs: ' + ', '.join(
                    name + '={{' + label + '.' + name + '}}'
                    for name in node['profile']['parameter_names']) + '.')
                text.append(render_pattern(source_id, node['profile'], label))
            else:
                text.append(get_template(source_id).render(bottom_parameters[node['node_id']]))
            continue
        text.append(_render_inputs(node, by_id))
        text.append(render_pattern(source_id, node['profile'], label, upper=True))
    root = by_id[schema['root_id']]['label']
    text.append(f'\nReturn only {root}, the answer to the final subproblem.')
    return '\n\n'.join(text)



def _render_inputs(node, by_id):
    bindings = node['bindings']
    expressions = [
        describe_adapter(binding['operator'], by_id[binding['source_node']]['label'])
        for binding in bindings
    ]
    adapter = node.get('adapter')
    if adapter is None:
        return '\n'.join(f"{binding['input_name']} = {expr}" for binding, expr in zip(bindings, expressions))

    profile = node['profile']
    names, rows = profile['parameter_names'], profile['rows']
    used = set(names)

    def local(prefix, i):
        label = f'{prefix}{i + 1}'
        while label in used:
            label = '_' + label
        used.add(label)
        return label

    signals = [local('u', i) for i in range(len(names))]
    signal_rules = [
        f"{signals[binding['input_index']]} = {expr}" for binding, expr in zip(bindings, expressions)
    ]
    parameter_rules = []
    for group, ports in enumerate(adapter['groups']):
        inputs = [signals[port] for port in ports]
        bit = inputs[0]
        if len(inputs) > 1:
            bit = local('b', group)
            signal_rules.append(f"{bit} = ({' + '.join(inputs)}) mod 2")
        parameters = [names[port] for port in ports]
        lhs = _tuple_text(parameters)
        zero, one = [
            _tuple_text([json.dumps(rows[index][name], ensure_ascii=False, separators=(',', ':'))
                         for name in parameters])
            for index in (0, 1 << group)
        ]
        parameter_rules.append(f'{lhs} = {zero} if {bit} = 0, otherwise {one}')
    return '\n'.join([*signal_rules, *parameter_rules])


def _tuple_text(values):
    return values[0] if len(values) == 1 else '(' + ', '.join(values) + ')'
