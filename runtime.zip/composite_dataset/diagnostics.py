"""Read-only structure and ideal-distribution diagnostics for composite schemas.

These diagnostics never change generation, sampling weights or replay seeds.
Probability results are exact for independent fair incoming leaf bits, NOT for
uniformly drawing a finite uint64 parameter seed or for all native leaf answers.
"""
from collections import Counter, defaultdict
from fractions import Fraction
from itertools import combinations
from math import prod
from statistics import mean

from .schema import profile_answers, validate_schema


MODEL = 'independent-fair-leaf-bits'
MODEL_NOTE = ('Exact rational probabilities under independent fair outgoing leaf bits; '
              'not exact frequencies over uint64 seeds. Native leaf answer distributions '
              'within each bit class are unspecified.')


def structure_diagnostics(tree):
    """Measure branching separately from the requested full mathematical depth."""
    nodes = tree['nodes']
    by_id = {node['node_id']: node for node in nodes}
    level_widths = Counter(node['level'] for node in nodes)
    internal = [node for node in nodes if node['children']]
    unary = sum(len(node['children']) == 1 for node in internal)
    pending = [(tree['root_id'], 0)]
    depths = {}
    while pending:
        node_id, branching_depth = pending.pop()
        node = by_id[node_id]
        if not node['children']:
            depths[node_id] = branching_depth
        else:
            pending.extend((child, branching_depth + (len(node['children']) > 1))
                           for child in node['children'])
    return {'nodes': len(nodes), 'internal_nodes': len(internal), 'unary_internal_nodes': unary,
            'unary_internal_share': unary / len(internal) if internal else 0,
            'level_widths': [level_widths[level] for level in range(tree['depth'])],
            'nonunary_depth_per_leaf': dict(sorted(depths.items())),
            'nonunary_depth_summary': {'min': min(depths.values()), 'mean': mean(depths.values()),
                                      'max': max(depths.values())}}


def source_overlap(trees):
    """Count distinct source IDs, so template reuse cannot inflate overlap."""
    result = {}
    for name, include in [('all_sources', lambda node: True),
                          ('unary_internal_sources', lambda node: node['arity'] == 1)]:
        source_sets = [{node['source_id'] for node in tree['nodes'] if include(node)} for tree in trees]
        union = set().union(*source_sets)
        intersection = set.intersection(*source_sets) if source_sets else set()
        frequencies = Counter(source for sources in source_sets for source in sources)
        similarities = [len(a & b) / len(a | b) if a | b else 1
                        for a, b in combinations(source_sets, 2)]
        result[name] = {'union_count': len(union), 'intersection_count': len(intersection),
                        'intersection_ids': sorted(intersection),
                        'mean_pairwise_jaccard': mean(similarities) if similarities else None,
                        'trees_per_source_histogram': dict(sorted(Counter(frequencies.values()).items()))}
    return result


def _row_probability(index, probabilities, omit=None):
    return prod((p if index & (1 << axis) else 1-p)
                for axis, p in enumerate(probabilities) if axis != omit)


def _fair_leaf_bit_model(tree, root_answers):
    """Evaluate a certified tree's Boolean interfaces without enumerating leaves.

    Each group is a disjoint parity. Complementing any one member flips its
    group regardless of the other members. Its local derivative depends only
    on the OTHER groups. Along one leaf path these derivative events depend
    on disjoint sibling subtrees, so their probabilities multiply exactly.
    The root derivative compares native answers; intermediate ones compare
    outgoing bits. Runtime validation supplies the classifier correspondence.
    """
    nodes = tree['nodes']
    by_id = {node['node_id']: node for node in nodes}
    root = by_id[tree['root_id']]
    result = {'model': MODEL, 'model_note': MODEL_NOTE}
    if not root['children']:
        return dict(result, root_answer_probabilities=None, leaf_flip_influences=None,
                    leaf_flip_influence_summary=None,
                    unavailable_reason='A depth-one native leaf has no outgoing bit interface; '
                                       'its full native answer distribution is unspecified.')
    bit_probabilities, derivatives = {}, {}
    answer_probabilities = defaultdict(Fraction)
    for node in sorted(nodes, key=lambda n: -n['level']):
        node_id = node['node_id']
        if not node['children']:
            bit_probabilities[node_id] = Fraction(1, 2)
            continue
        probabilities = [(1-prod(1-2*bit_probabilities[node['children'][port]] for port in group))/2
                         for group in node['adapter']['groups']]
        truth = node['profile']['truth_table']
        bit_probabilities[node_id] = sum((_row_probability(index, probabilities)
                                         for index, bit in enumerate(truth) if bit), Fraction())
        outputs = root_answers if node_id == tree['root_id'] else truth
        derivatives[node_id] = [sum((_row_probability(index, probabilities, omit=axis)
                                    for index in range(len(outputs))
                                    if not index & (1 << axis)
                                    and outputs[index] != outputs[index | (1 << axis)]), Fraction())
                                for axis in range(len(probabilities))]
        if node_id == tree['root_id']:
            for index, answer in enumerate(outputs):
                answer_probabilities[answer] += _row_probability(index, probabilities)
    pending = [(tree['root_id'], Fraction(1))]
    influences = {}
    while pending:
        node_id, influence = pending.pop()
        node = by_id[node_id]
        if not node['children']:
            influences[node_id] = influence
        else:
            for axis, group in enumerate(node['adapter']['groups']):
                pending.extend((node['children'][port], influence * derivatives[node_id][axis])
                               for port in group)
    return dict(result,
                root_answer_probabilities={answer: str(p) for answer, p in sorted(answer_probabilities.items())},
                leaf_flip_influences={leaf: str(p) for leaf, p in sorted(influences.items())},
                leaf_flip_influence_summary={'min': str(min(influences.values())),
                                             'mean': str(sum(influences.values()) / len(influences)),
                                             'max': str(max(influences.values()))})


def fair_leaf_bit_diagnostics(schema):
    """Validate the executable certificate, then compute the ideal model exactly."""
    validate_schema(schema)
    root = next(node for node in schema['nodes'] if node['node_id'] == schema['root_id'])
    answers = profile_answers(root['source_id'], root['profile']) if root['children'] else None
    return _fair_leaf_bit_model(schema, answers)
