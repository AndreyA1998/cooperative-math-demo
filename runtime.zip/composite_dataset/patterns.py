"""Visible question patterns derived from the native renderer and certified rows."""
from dataclasses import dataclass
from difflib import SequenceMatcher
from functools import lru_cache
from inspect import getclosurevars
import json
import re

from template_dataset.core import validate_parameters
from template_dataset.registry import get_template


_TOKEN = re.compile(r'\\[A-Za-z]+|\\[^\w\s]|[+-]?\d+(?:[,.]\d+)*|[^\W\d_]+|\s+|.', re.S)
# Python counts the sign inside the field width. Use a certified fallback for both together.
_FORMAT = re.compile(r'(?![+ -]\d)[+ -]?\d{0,2},?[ds]?\Z')
_MARKER = re.compile(r'\ue000(\d+)\ue001')
_MAX_FRAGMENT_LENGTH = 60
_MAX_FRAGMENT_VARIANTS = 8
_MAX_FRAGMENT_DEFINITIONS = 20


def _json(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'), sort_keys=True)


@dataclass(frozen=True)
class _Field:
    name: str
    path: tuple = ()
    spec: str = ''
    conversion: str = ''

    def fill(self, params):
        value = params[self.name]
        for index in self.path:
            value = value[index]
        if self.conversion == 'repr':
            return repr(value)
        if self.conversion == 'str':
            return str(value)
        return format(value, self.spec)

    def label(self):
        path = ''.join(f'[{index + 1}]' for index in self.path)
        name = self.name + path
        if self.conversion == 'repr':
            return f'literal({name})'
        if ',' in self.spec:
            name = f'grouped({name})'
        width = re.search(r'\d+', self.spec)
        if width:
            function = 'pad' if width[0].startswith('0') else ('rightpad' if self.spec.endswith('s') else 'leftpad')
            name = f'{function}({name}, {int(width[0])})'
        if self.spec.startswith('+'):
            name = f'signed({name})'
        elif self.spec.startswith(' '):
            name = f'spaced({name})'
        return name

    def legend(self):
        rules = []
        if self.conversion == 'repr':
            rules.append('literal(x) writes the value in literal notation: quote strings and bracket lists.')
        if ',' in self.spec:
            rules.append('grouped(x) separates thousands with commas.')
        width = re.search(r'\d+', self.spec)
        if width:
            if width[0].startswith('0'):
                rules.append('pad(x, N) uses at least N characters, padding with zeros after any minus sign.')
            elif self.spec.endswith('s'):
                rules.append('rightpad(x, N) adds trailing spaces to reach at least N characters.')
            else:
                rules.append('leftpad(x, N) adds leading spaces to reach at least N characters.')
        if self.spec.startswith('+'):
            rules.append('signed(x) includes a leading + for nonnegative values and a minus sign for negative values.')
        elif self.spec.startswith(' '):
            rules.append('spaced(x) prefixes nonnegative values with a blank and negative values with a minus sign.')
        return rules


class _Slot:
    """Record supported formatting calls while refusing data-dependent decisions."""

    def __init__(self, name, record, path=(), length=None):
        self.name = name
        self.record = record
        self.path = path
        self.length = length

    def __format__(self, spec):
        if not _FORMAT.fullmatch(spec):
            raise ValueError('Unsupported symbolic format')
        return self.record(_Field(self.name, self.path, spec))

    def __str__(self):
        return self.record(_Field(self.name, self.path, conversion='str'))

    def __repr__(self):
        return self.record(_Field(self.name, self.path, conversion='repr'))

    def __len__(self):
        if self.length is None:
            raise ValueError('Variable symbolic length')
        return self.length

    def __getitem__(self, index):
        if self.length is None or type(index) is not int:
            raise ValueError('Unsupported symbolic index')
        if not -self.length <= index < self.length:
            raise IndexError(index)
        return _Slot(self.name, self.record, self.path + (index % self.length,))

    def _unsupported(self, *args):
        raise ValueError('Unsupported symbolic decision')

    __bool__ = __eq__ = __ne__ = __lt__ = __le__ = __gt__ = __ge__ = __hash__ = _unsupported


@dataclass(frozen=True)
class _SourceField:
    name: str
    original: int
    raw: str
    places: int = 0
    keep_original: bool = True
    grouped: bool = False
    exponent: bool = False
    signed_decimal: bool = True

    def fill(self, params):
        value = params[self.name]
        if self.keep_original and value == self.original:
            return self.raw
        if self.places:
            if self.signed_decimal:
                sign = '-' if value < 0 else ''
                digits = str(abs(value))
            else:
                sign, digits = '', str(value)
            digits = digits.zfill(self.places + 1)
            text = sign + digits[:-self.places] + '.' + digits[-self.places:]
        elif self.grouped:
            text = format(value, ',')
        else:
            text = str(value)
        return '{' + text + '}' if self.exponent and len(text) > 1 else text

    def label(self):
        name = self.name
        if self.places:
            name += '/' + str(10 ** self.places)
        return name


@dataclass(frozen=True)
class _Fragment:
    names: tuple
    alternatives: tuple

    def fill(self, params):
        key = tuple(_json(params[name]) for name in self.names)
        return next(text for keys, text in self.alternatives if keys == key)


@dataclass(frozen=True)
class _Pattern:
    scope: str
    parts: tuple


def _fill(parts, params):
    return ''.join(part if isinstance(part, str) else part.fill(params) for part in parts)


def _proxy_parts(template):
    fields = []

    def record(field):
        index = len(fields)
        fields.append(field)
        return f'\ue000{index}\ue001'

    slots = {}
    for name, domain in template.parameters.items():
        length = None
        if domain.get('type', '').startswith('list') and domain.get('min_length') == domain.get('max_length'):
            length = domain.get('min_length')
        slots[name] = _Slot(name, record, length=length)
    try:
        statement = template.render(slots)
        pieces = _MARKER.split(statement)
        parts = tuple(piece if index % 2 == 0 else fields[int(piece)] for index, piece in enumerate(pieces))
    except (ArithmeticError, AttributeError, IndexError, KeyError, TypeError, ValueError):
        return ()
    visible = {part.name for part in parts if isinstance(part, _Field)}
    if visible != set(slots):
        return ()
    return parts


def _source_parts(template):
    """Use spans already bound by a small set of known native renderers."""
    render = template.render
    renderer = getattr(render, '__module__', ''), getattr(render, '__qualname__', '')
    if renderer == ('template_dataset.families.algebra_v2', '_Bindings.render'):
        binding = render.__self__
        problem = binding.problem
        spans = [
            (start, end, _SourceField(name, binding.original[name], raw,
                                      places=len(str(scale)) - 1, grouped=',' in raw,
                                      signed_decimal=False))
            for start, end, name, raw, scale in binding.spans
        ]
    elif renderer in (('template_dataset.families.word_v2', 'build.<locals>.render'),
                      ('template_dataset.families.word_extra', 'build.<locals>.render')):
        context = getclosurevars(render).nonlocals
        problem = context['problem']
        spans = []
        if renderer[0].endswith('word_v2'):
            for match, name, places in context['slots']:
                field = _SourceField(name, template.original[name], match[0], places)
                spans.append((match.start(), match.end(), field))
        else:
            for match, descriptor in zip(context['matches'], context['fields']):
                name = descriptor.split(':', 1)[0]
                if name == '_':
                    continue
                start = match.start()
                field = _SourceField(
                    name, template.original[name], match[0], context['widths'][name],
                    keep_original=False, exponent=start > 0 and problem[start - 1] == '^',
                )
                spans.append((start, match.end(), field))
    else:
        return ()

    parts, offset = [], 0
    for start, end, field in sorted(spans, key=lambda entry: entry[0]):
        if not offset <= start < end <= len(problem) or problem[start:end] != field.raw:
            return ()
        parts.extend((problem[offset:start], field))
        offset = end
    if {field.name for _, _, field in spans} != set(template.parameters):
        return ()
    return (*parts, problem[offset:])


def _fragments(statements):
    """Yield a vector of corresponding fragments across all native statements."""
    tokens = [_TOKEN.findall(text) for text in statements]
    reference = tokens[0]
    if all(len(row) == len(reference) for row in tokens):
        yield from zip(*tokens)
        return

    # Only monotone anchors found in every statement can be fixed text.
    anchors = [{index: index for index in range(len(reference))}]
    for candidate in tokens[1:]:
        matches = SequenceMatcher(None, reference, candidate, autojunk=False).get_matching_blocks()
        anchors.append({start + offset: other + offset
                        for start, other, length in matches for offset in range(length)})
    common = sorted(set.intersection(*(set(mapping) for mapping in anchors)))
    previous = [-1] * len(tokens)
    for anchor in common + [len(reference)]:
        positions = [mapping.get(anchor, len(row)) for mapping, row in zip(anchors, tokens)]
        gaps = [row[before + 1:after] for row, before, after in zip(tokens, previous, positions)]
        if any(gaps):
            if all(len(gap) == len(gaps[0]) for gap in gaps):
                yield from zip(*gaps)
            else:
                yield tuple(''.join(gap) for gap in gaps)
        if anchor < len(reference):
            yield (reference[anchor],) * len(tokens)
        previous = positions


def _alternative_map(columns, names, fragments):
    alternatives = {}
    for key, fragment in zip(zip(*(columns[name] for name in names)), fragments):
        if key in alternatives and alternatives[key] != fragment:
            return None
        alternatives[key] = fragment
    return alternatives


def _compile_finite(template, rows, statements):
    names = list(template.parameters)
    columns = {name: tuple(_json(row[name]) for row in rows) for name in names}
    known_fields = {}
    for name in names:
        for spec in ('', '+d', ','):
            field = _Field(name, spec=spec)
            try:
                vector = tuple(field.fill(row) for row in rows)
            except (TypeError, ValueError):
                continue
            owners = known_fields.setdefault(vector, {})
            owners.setdefault(name, field)

    parts = []
    definitions = 0
    fixed_length = 0
    for vector in _fragments(statements):
        if len(set(vector)) == 1:
            fixed_length += len(vector[0])
            if parts and isinstance(parts[-1], str):
                parts[-1] += vector[0]
            else:
                parts.append(vector[0])
            continue
        owners = known_fields.get(vector, {})
        if len(owners) == 1:
            parts.append(next(iter(owners.values())))
            continue

        # A fragment may depend on multiple named inputs. Certify the smallest
        # conditions this greedy elimination finds instead of guessing an owner.
        dependencies = names
        for name in names:
            candidate = [item for item in dependencies if item != name]
            if candidate and _alternative_map(columns, candidate, vector) is not None:
                dependencies = candidate
        alternatives = _alternative_map(columns, dependencies, vector)
        if (alternatives is None or len(alternatives) > _MAX_FRAGMENT_VARIANTS
                or max(map(len, vector)) > _MAX_FRAGMENT_LENGTH):
            return ()
        parts.append(_Fragment(tuple(dependencies), tuple(alternatives.items())))
        definitions += 1
    if definitions > _MAX_FRAGMENT_DEFINITIONS or fixed_length * 2 < min(map(len, statements)):
        return ()
    return tuple(parts)


def _case_pattern(rows, statements, names):
    variants = tuple((tuple(_json(row[name]) for name in names), text) for row, text in zip(rows, statements))
    return _Pattern('certified-cases', (_Fragment(tuple(names), variants),))


@lru_cache(maxsize=1024)
def _get_pattern(source_id, encoded_rows):
    template = get_template(source_id)
    rows = json.loads(encoded_rows)
    if not rows:
        raise ValueError('Question pattern requires certified rows')
    statements = tuple(template.render(row) for row in rows)
    for build in (_source_parts, _proxy_parts):
        try:
            native = build(template)
            if native and all(_fill(native, row) == text for row, text in zip(rows, statements)):
                return _Pattern('native-filtered', native)
        except (ArithmeticError, AttributeError, IndexError, KeyError, StopIteration, TypeError, ValueError):
            continue
    finite = _compile_finite(template, rows, statements)
    if finite and all(_fill(finite, row) == text for row, text in zip(rows, statements)):
        return _Pattern('certified-finite', finite)
    return _case_pattern(rows, statements, template.parameters)


def pattern_scope(source_id, profile, *, upper=False):
    scope = _get_pattern(source_id, _json(profile['rows'])).scope
    return 'certified-finite' if upper and scope == 'native-filtered' else scope


def pattern_accepts(source_id, profile, params):
    """Admit only leaves whose concrete statement is exactly represented."""
    template = get_template(source_id)
    if not validate_parameters(template, params):
        return False
    pattern = _get_pattern(source_id, _json(profile['rows']))
    if pattern.scope != 'native-filtered' and not any(params == row for row in profile['rows']):
        return False
    try:
        return _fill(pattern.parts, params) == template.render(params)
    except (ArithmeticError, AttributeError, IndexError, KeyError, StopIteration, TypeError, ValueError):
        return False


def _conditions(names, values):
    return ', '.join(f'{name} = {value}' for name, value in zip(names, values))


def render_pattern(source_id, profile, prefix, *, upper=False):
    """Render actual question text with named slots or certified local inserts."""
    pattern = _get_pattern(source_id, _json(profile['rows']))

    def slot(name):
        return f'⟨{name}⟩' if upper else '{{' + prefix + '.' + name + '}}'

    if pattern.scope == 'certified-cases':
        fragment = pattern.parts[0]
        return '\n'.join([
            'This template has conditional wording. Use the statement matching the input values.',
            *(f'If {_conditions(fragment.names, values)}: {statement}'
              for values, statement in fragment.alternatives),
        ])

    pieces, definitions = [], []
    legends = []
    fragments = {}
    for part in pattern.parts:
        if isinstance(part, str):
            pieces.append(part)
        elif isinstance(part, (_Field, _SourceField)):
            pieces.append(slot(part.label()))
            if isinstance(part, _Field):
                legends.extend(rule for rule in part.legend() if rule not in legends)
        else:
            if part not in fragments:
                label = slot(f'fragment {len(fragments) + 1}')
                fragments[part] = label
                choices = '; '.join(f'{_conditions(part.names, values)} → {_json(text)}'
                                    for values, text in part.alternatives)
                definitions.append(f'Insert {label} using the matching input values: {choices}.')
            pieces.append(fragments[part])
    return '\n'.join([''.join(pieces), *definitions, *legends])
