"""Sample new, exactly certified joint profiles without modifying the catalogue.

A successful fresh profile contains a native condition absent from every supplied
catalogue profile. Bounded search failure is explicit; only complete enumeration
of a small declared domain can justify a finite-domain-limited result.
"""
from copy import deepcopy
from functools import lru_cache
from hashlib import sha256
from itertools import combinations, product, zip_longest
import json
import random

from template_dataset.core import _in_domain, validate_parameters
from template_dataset.registry import get_template, solve as atomic_solve
from .profiles import _certify_grid, _parameter_key, get_catalogue, MAX_ARITY


class FreshProfileSearchError(RuntimeError):
    """The bounded search could not establish a fresh certified profile."""

    def __init__(self, source_id, diagnostics):
        self.diagnostics = deepcopy(diagnostics)
        super().__init__('Fresh profile search failed for ' + source_id + ': ' + diagnostics['reason'])


class _RowBudget(Exception):
    pass


@lru_cache(maxsize=1)
def _catalogue():
    return get_catalogue()


def _finite_values(domain, limit):
    """Return a complete declared finite domain only when it fits the limit."""
    if 'choices' in domain:
        choices = domain['choices']
        if not isinstance(choices, (list, tuple)) or len(choices) > limit:
            return None
        return deepcopy(list(choices))
    kind = domain.get('type', 'int')
    if kind in ('int', 'integer'):
        low, high = domain.get('min'), domain.get('max')
        if type(low) is not int or type(high) is not int or high < low or high - low + 1 > limit:
            return None
        return list(range(low, high + 1))
    if kind.startswith('list'):
        low, high = domain.get('min_length'), domain.get('max_length')
        if type(low) is not int or type(high) is not int or not 0 <= low <= high:
            return None
        items = _finite_values(domain.get('items', {'type': 'int'}), limit)
        if items is None:
            return None
        size = 0
        for length in range(low, high + 1):
            size += len(items) ** length
            if size > limit:
                return None
        return [list(deepcopy(values)) for length in range(low, high + 1)
                for values in product(items, repeat=length)]
    # Rational intervals are not finite; a string domain needs explicit choices.
    return None


def _finite_domains(parameters, limit):
    domains, size = [], 1
    for domain in parameters.values():
        values = _finite_values(domain, limit // size)
        if values is None:
            return None, None
        size *= len(values)
        if not size or size > limit:
            return None, None
        domains.append(values)
    return domains, size


class _CheckedRows:
    def __init__(self, source_id, template, limit, info):
        self.source_id, self.template, self.limit, self.info = source_id, template, limit, info
        self.answers, self.rows, self.conditions = {}, {}, {}

    def check(self, parameters):
        try:
            key = _parameter_key(parameters)
            json.dumps(parameters, allow_nan=False)
        except (TypeError, ValueError):
            if self.info['checked_rows'] >= self.limit:
                raise _RowBudget
            self.info['checked_rows'] += 1
            return None
        if key in self.answers:
            self.info['cache_hits'] += 1
            return key if self.answers[key] is not None else None
        if self.info['checked_rows'] >= self.limit:
            raise _RowBudget
        self.info['checked_rows'] += 1
        self.answers[key] = None
        row = deepcopy(parameters)
        if not validate_parameters(self.template, row):
            return None
        self.info['exact_solves'] += 1
        try:
            answer = atomic_solve(self.source_id, deepcopy(row))
            condition = self.template.render(deepcopy(row))
        except (ValueError, ArithmeticError, TypeError, IndexError, KeyError):
            return None
        self.answers[key], self.rows[key], self.conditions[key] = answer, row, condition
        return key

    def grid(self, groups, low_key, high_key):
        low, high = self.rows[low_key], self.rows[high_key]
        if any(not any(low[name] != high[name] for name in group) for group in groups):
            return None
        rows = [{name: deepcopy((high if index & (1 << bit) else low)[name])
                 for bit, group in enumerate(groups) for name in group}
                for index in range(1 << len(groups))]
        unknown = {_parameter_key(row) for row in rows} - self.answers.keys()
        if len(unknown) > self.limit - self.info['checked_rows']:
            return None
        self.info['grid_attempts'] += 1
        for row in rows:
            if self.check(row) is None:
                return None
        # Every row is already cached, so the existing certifier makes no hidden
        # solver calls. It still proves full Cartesian ownership and essentiality.
        return _certify_grid(self.source_id, self.template, groups, low, high, self.answers)


def _prototype_shape(source_id, template, prototype):
    names = list(template.parameters)
    if not isinstance(prototype, dict) or prototype.get('id') != source_id or prototype.get('parameter_names') != names:
        raise ValueError('Prototype source or parameter names do not match the native template')
    groups, rows = prototype.get('groups'), prototype.get('rows')
    if (not isinstance(groups, list) or not 1 <= len(groups) <= MAX_ARITY
            or any(not isinstance(group, list) or not group for group in groups)
            or any(type(name) is not str for group in groups for name in group)
            or sorted(name for group in groups for name in group) != sorted(names)
            or type(prototype.get('arity')) is not int or prototype['arity'] != len(groups)
            or not isinstance(rows, list) or len(rows) != 1 << len(groups)):
        raise ValueError('Invalid prototype group partition or Cartesian row count')
    return names, deepcopy(groups)


def _partitions(groups, names):
    current = deepcopy(groups)
    while True:
        yield current
        if len(current) == 1:
            break
        joined = set(current[-2] + current[-1])
        current = current[:-2] + [[name for name in names if name in joined]]


def _local_proposals(template, anchors, rng, limit=256):
    """Bounded native-domain proposals, never presumed joint-valid.

    Single-coordinate neighbours explore narrow admissible regions. Coherent
    subset scaling also reaches homogeneous integer identities whose individual
    coordinate mutations are invalid. Every result still goes through the full
    native validator, solver and condition renderer.
    """
    names = list(template.parameters)
    bases, seen = [], set()
    for row in [template.original, *anchors]:
        if not isinstance(row, dict) or set(row) != set(names):
            continue
        key = _parameter_key(row)
        if key not in seen:
            seen.add(key)
            bases.append(deepcopy(row))
    rng.shuffle(bases)
    for row in bases:
        yield row
    streams = []
    for base in bases:
        proposals = []
        for name, domain in template.parameters.items():
            value = base[name]
            if 'choices' in domain:
                alternatives = deepcopy(list(domain['choices']))
                rng.shuffle(alternatives)
                alternatives = alternatives[:16]
            elif domain.get('type', 'int') in ('int', 'integer') and type(value) is int:
                alternatives = [value - 2, value - 1, value + 1, value + 2, 2 * value, -value]
                if value % 2 == 0:
                    alternatives.append(value // 2)
                low, high = domain.get('min'), domain.get('max')
                if type(low) is int and type(high) is int and low <= high:
                    alternatives.extend((low, high, rng.randint(low, high)))
                rng.shuffle(alternatives)
            else:
                continue
            for other in alternatives:
                if other != value and _in_domain(other, domain):
                    row = deepcopy(base)
                    row[name] = deepcopy(other)
                    proposals.append(row)
        integer_names = [name for name in names if type(base[name]) is int and
                         template.parameters[name].get('type', 'int') in ('int', 'integer')]
        # At most ten parameters are independently connected in a profile;
        # cap larger source tuples without materializing an exponential domain.
        subsets = [tuple(integer_names)]
        for size in range(2, min(len(integer_names), 10) + 1):
            for subset in combinations(integer_names, size):
                if len(subsets) >= 128:
                    break
                subsets.append(subset)
            if len(subsets) >= 128:
                break
        rng.shuffle(subsets)
        for subset in subsets:
            for numerator, denominator in ((2, 1), (1, 2), (-1, 1)):
                if any(base[name] * numerator % denominator for name in subset):
                    continue
                row = deepcopy(base)
                for name in subset:
                    row[name] = base[name] * numerator // denominator
                if all(_in_domain(row[name], template.parameters[name]) for name in subset):
                    proposals.append(row)
        rng.shuffle(proposals)
        streams.append(proposals)
    count = len(bases)
    for batch in zip_longest(*streams):
        for row in batch:
            if row is None:
                continue
            key = _parameter_key(row)
            if key in seen:
                continue
            seen.add(key)
            if count >= limit:
                return
            count += 1
            yield row


def sample_fresh_profile(source_id, prototype, seed, *, catalogue_profiles=None,
                         max_native_samples=24, max_grid_rows=2048, accept_profile=None):
    """Return ``(ordinary_profile, diagnostics)`` or an explicit bounded failure.

    ``max_grid_rows`` bounds all unique native row checks, including invalid
    hybrids and exhaustive enumeration. Cached checks do not spend it twice.
    The prototype's stored answers and classifier are never trusted. An optional
    readability predicate can reject rich grids; a certified unary result is
    retained even when no candidate satisfies that presentation-only predicate.
    Completed unary selection prefers two unseen conditions for three quarters
    of seeds; the remaining quarter permits mixed pairs with at least one unseen
    condition so a small domain is not frozen by that preference.
    """
    if type(seed) is not int or not 0 <= seed < 2**64:
        raise ValueError('Seed must be an integer in [0, 2**64 - 1]')
    if type(max_native_samples) is not int or max_native_samples < 1:
        raise ValueError('max_native_samples must be a positive integer')
    if type(max_grid_rows) is not int or max_grid_rows < 1:
        raise ValueError('max_grid_rows must be a positive integer')
    if accept_profile is not None and not callable(accept_profile):
        raise TypeError('accept_profile must be callable')
    template = get_template(source_id)
    names, groups = _prototype_shape(source_id, template, prototype)
    profiles = _catalogue().get(source_id, [prototype]) if catalogue_profiles is None else catalogue_profiles
    if not isinstance(profiles, (list, tuple)) or not profiles:
        raise ValueError('catalogue_profiles must contain at least one profile')
    catalogue_rows, catalogue_conditions = set(), set()
    for profile in profiles:
        if not isinstance(profile, dict) or profile.get('id') != source_id or not isinstance(profile.get('rows'), list):
            raise ValueError('Invalid source in catalogue_profiles')
        for row in profile['rows']:
            catalogue_rows.add(_parameter_key(row))
            catalogue_conditions.add(template.render(deepcopy(row)))
    original_rows = frozenset(_parameter_key(row) for row in prototype['rows'])
    domains, finite_size = _finite_domains(template.parameters, max_grid_rows)
    info = {'status': 'failed', 'source_id': source_id, 'seed': str(seed),
            'original_arity': len(groups), 'final_arity': None,
            'native_draws': 0, 'checked_rows': 0, 'exact_solves': 0, 'cache_hits': 0,
            'grid_attempts': 0, 'local_proposals': 0, 'rejected_profiles': 0, 'profile_accepted': None, 'new_rowset': False, 'new_condition': False,
            'new_rows': 0, 'new_conditions': 0, 'distinct_answers': 0,
            'finite_domain_exhausted': False, 'finite_domain_size': finite_size,
            'finite_valid_rows': None, 'finite_enumeration_complete': False,
            'reason': 'native-search-budget'}
    salt = json.dumps([source_id, str(seed), groups, prototype['rows']], sort_keys=True, separators=(',', ':'))
    rng = random.Random(int.from_bytes(sha256(('fresh-profile-1\0' + salt).encode()).digest(), 'big'))
    checked = _CheckedRows(source_id, template, max_grid_rows, info)
    pool = []
    acceptance = {}

    def accepted(profile):
        key = (tuple(tuple(group) for group in profile['groups']),
               tuple(_parameter_key(row) for row in profile['rows']))
        if key not in acceptance:
            acceptance[key] = accept_profile is None or bool(accept_profile(deepcopy(profile)))
            if not acceptance[key]:
                info['rejected_profiles'] += 1
        return acceptance[key]

    def add(parameters):
        key = checked.check(parameters)
        if key is not None and key not in pool:
            pool.append(key)
        return key

    def novel(key):
        return checked.conditions[key] not in catalogue_conditions

    def unary(require_novel, *, diversify=False):
        # Emergency reserves prefer two new conditions. A completed search can
        # occasionally choose a mixed pair, still requiring genuine novelty.
        pairs = sorted(combinations(pool, 2),
                       key=lambda pair: 0 if diversify else -sum(novel(key) for key in pair))
        reserve = None
        for left, right in pairs:
            if checked.answers[left] != checked.answers[right] and (not require_novel or novel(left) or novel(right)):
                result = checked.grid([names], left, right)
                if result is not None:
                    if accepted(result):
                        return result
                    if reserve is None:
                        reserve = result
        return reserve

    def finish(profile, finite_limited=False):
        keys = {_parameter_key(row) for row in profile['rows']}
        conditions = {checked.conditions[key] for key in keys}
        info.update(status='finite-domain-limited' if finite_limited else 'fresh', final_arity=profile['arity'],
                    new_rowset=keys != original_rows, new_condition=bool(conditions - catalogue_conditions),
                    new_rows=len(keys - catalogue_rows), new_conditions=len(conditions - catalogue_conditions),
                    distinct_answers=len(set(profile['answers'])),
                    reason='finite-domain-covered-by-catalogue' if finite_limited else
                           'native-grid' if profile['arity'] == len(groups) else 'coarsened-native-grid')
        info['profile_accepted'] = accepted(profile)
        if not info['profile_accepted']:
            info['reason'] = 'readability-limit'
        if not finite_limited and not (info['new_rowset'] and info['new_condition']):
            raise RuntimeError('Freshness invariant violated')
        return deepcopy(profile), deepcopy(info)

    fallback = None
    try:
        for _ in range(max_native_samples):
            info['native_draws'] += 1
            try:
                row = template.sample(rng)
            except (ValueError, RuntimeError, ArithmeticError, IndexError, StopIteration):
                continue
            add(row)
            if fallback is None:
                fallback = unary(True)
        native_condition_count = len({checked.conditions[key] for key in pool})
        info['native_conditions'] = native_condition_count
        if fallback is None:
            truth = prototype.get('truth_table', [])
            indices = []
            for bit in (0, 1):
                if bit in truth:
                    indices.append(truth.index(bit))
            indices.extend(index for index in range(len(prototype['rows'])) if index not in indices)
            for index in indices:
                add(prototype['rows'][index])
                fallback = unary(True)
                if fallback is not None:
                    break
                if len({checked.answers[key] for key in pool}) > 1 and not any(novel(key) for key in pool):
                    break

        if fallback is None and domains is not None:
            # This is the only route to a finite-limit claim. Every Cartesian
            # tuple is checked against the actual joint validator and solver.
            for values in product(*domains):
                checked.check(dict(zip(names, deepcopy(values))))
            info['finite_enumeration_complete'] = True
            info['finite_valid_rows'] = len(checked.rows)
            enumerated = list(checked.rows)
            rng.shuffle(enumerated)
            enumerated.sort(key=lambda key: not novel(key))
            for key in enumerated:
                if key not in pool:
                    pool.append(key)
                if len(pool) >= max_native_samples + 2 and any(novel(key) for key in pool):
                    break
            fallback = unary(True)
            if fallback is None:
                info['finite_domain_exhausted'] = not any(novel(key) for key in checked.rows)
                if info['finite_domain_exhausted']:
                    limited = unary(False)
                    if limited is not None:
                        return finish(limited, True)

        if fallback is None or native_condition_count <= 2:
            # A sampler with one or two outcomes can hide a larger valid
            # domain. Explore it even with a certified reserve in hand; a fixed
            # preferred pair must not freeze every structure seed.
            anchors = [checked.rows[key] for key in pool[:8]] + prototype['rows'][:8]
            for row in _local_proposals(template, anchors, rng):
                info['local_proposals'] += 1
                add(row)
                if fallback is None:
                    fallback = unary(True)
        if fallback is None:
            raise FreshProfileSearchError(source_id, info)

        # Reconsider completed draws with seeded tie order. Three quarters of
        # seeds prefer two new conditions; one quarter also permits a mixed
        # old/new pair. This avoids freezing a four-value domain to its sole
        # two-new pair while retaining novelty outside the complete catalogue.
        rng.shuffle(pool)
        info['pair_selection'] = 'diverse-fresh' if seed % 4 == 0 else 'prefer-two-new'
        fallback = unary(True, diversify=seed % 4 == 0) or fallback

        # The unary result is already certified before any larger grid spends
        # the remaining budget. Equal diagonal answers are allowed for r > 1.
        pairs = list(combinations(pool, 2))
        pairs.sort(key=lambda pair: (-sum(novel(key) for key in pair),
                                     -sum(checked.rows[pair[0]][name] != checked.rows[pair[1]][name] for name in names)))
        for partition in _partitions(groups, names):
            if len(partition) == 1:
                break
            attempted = 0
            for left, right in pairs:
                if not (novel(left) or novel(right)):
                    continue
                if any(not any(checked.rows[left][name] != checked.rows[right][name] for name in group) for group in partition):
                    continue
                result = checked.grid(partition, left, right)
                attempted += 1
                if result is not None and accepted(result):
                    return finish(result)
                if attempted >= 12:
                    break
        return finish(fallback)
    except _RowBudget:
        if fallback is not None:
            return finish(fallback)
        info['reason'] = 'native-row-budget'
        raise FreshProfileSearchError(source_id, info) from None
