"""Build, instantiate and replay composite MATH programs offline."""
import argparse
import json
from pathlib import Path
import sys

from . import build_schema, instantiate, solve
from .schema import MAX_SCHEMA_BYTES
from composite_dataset.serialization import MAX_JSON_DEPTH, loads_json


def read_json(filename):
    path = Path(filename)
    if path.stat().st_size > MAX_SCHEMA_BYTES:
        raise ValueError('Input JSON exceeds the size limit')
    # Limit the read too: the file may change after stat().
    with path.open('rb') as stream:
        data = stream.read(MAX_SCHEMA_BYTES + 1)
    return loads_json(data, max_bytes=MAX_SCHEMA_BYTES)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    p = sub.add_parser('build')
    p.add_argument('--depth', required=True, type=int)
    p.add_argument('--width', required=True, type=int)
    p.add_argument('--seed', required=True, type=int)
    p.add_argument('--split', choices=['train', 'test'], default='train')
    p.add_argument('--allow-template-reuse', action='store_true')
    p.add_argument('--output')
    for command in ('instantiate', 'solve'):
        p = sub.add_parser(command)
        p.add_argument('--schema', required=True)
        if command == 'instantiate':
            p.add_argument('--seed', required=True, type=int)
            p.add_argument('--prompt-only', action='store_true')
        else:
            p.add_argument('--parameters', required=True, help='JSON file with local leaf ID -> native parameters')
        p.add_argument('--output')
    sub.add_parser('catalogue')
    args = parser.parse_args(argv)
    try:
        if args.command == 'build':
            result = build_schema(args.depth, args.width, args.seed, split=args.split,
                                  allow_template_reuse=args.allow_template_reuse)
        elif args.command == 'instantiate':
            result = instantiate(read_json(args.schema), args.seed)
            if args.prompt_only:
                print(result['problem'])
                return 0
        elif args.command == 'solve':
            result = solve(read_json(args.schema), read_json(args.parameters))
        else:
            from .profiles import get_catalogue, catalogue_exclusions
            catalogue = get_catalogue()
            result = {'supported': len(catalogue),
                      'capabilities': {key: [len(profiles[0]['parameter_names'])]
                                       for key, profiles in catalogue.items()},
                      'certified_axes': {key: [p['arity'] for p in profiles]
                                         for key, profiles in catalogue.items()},
                      'excluded': catalogue_exclusions()}
        output = json.dumps(result, ensure_ascii=False, indent=2) + '\n'
        if getattr(args, 'output', None):
            Path(args.output).write_text(output)
        else:
            print(output, end='')
        return 0
    except (KeyError, ValueError, OSError, RuntimeError) as error:
        print(str(error), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
