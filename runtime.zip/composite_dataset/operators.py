"""Exact arithmetic classifiers and typed unary projections."""
from copy import deepcopy
from fractions import Fraction
import json


_COEFFICIENTS = ('numerator', 'denominator')
_FIELDS = (*_COEFFICIENTS, 'divisor', 'modulus', 'threshold')


def _validated_coefficients(spec):
    if (not isinstance(spec, dict) or set(spec) != {'op', *_FIELDS}
            or spec['op'] != 'floor_mod'
            or any(type(spec[field]) is not int for field in _FIELDS)
            or spec['divisor'] < 1 or not 1 <= spec['threshold'] < spec['modulus']):
        raise ValueError('Invalid floor_mod classifier')
    return tuple(spec[field] for field in _FIELDS)


def _exact_fraction(answer):
    if isinstance(answer, bool) or not isinstance(answer, (int, str, Fraction)):
        raise TypeError('Expected an integer, Fraction, or exact rational string')
    return Fraction(answer)


def _bit(coefficients, n, d):
    a, b, divisor, modulus, threshold = coefficients
    return int(((a * n + b * d) // divisor) % modulus >= threshold)


def classify(spec, answer):
    """Return the bit for an answer given as an exact scalar or decimal digit code."""
    coefficients = _validated_coefficients(spec)
    fraction = _exact_fraction(answer)
    return _bit(coefficients, fraction.numerator, fraction.denominator)


def _value_pair(values):
    if not isinstance(values, (list, tuple)) or len(values) != 2:
        raise ValueError('A projection requires two parameter values')
    return values


def project(spec, values, answer):
    """Apply a unary classifier and return a single typed parameter value."""
    values = _value_pair(values)
    return deepcopy(values[classify(spec, answer)])


def describe_classifier(spec, reference):
    a, b, divisor, modulus, threshold = _validated_coefficients(spec)
    terms = []
    for coefficient, symbol in ((a, 'n'), (b, 'd')):
        if not coefficient:
            continue
        magnitude = symbol if abs(coefficient) == 1 else f'{abs(coefficient)}*{symbol}'
        if terms:
            terms.append(f' {"+" if coefficient > 0 else "-"} {magnitude}')
        else:
            terms.append(magnitude if coefficient > 0 else f'-{magnitude}')
    expression = ''.join(terms) or '0'
    return (
        f'Write the answer {reference} as a reduced fraction n/d with d > 0. '
        'If the answer requests digits in a different base, read the written digits '
        'as a base ten integer code before forming n/d. '
        f'Let r be the least nonnegative remainder of floor(({expression})/{divisor}) '
        f'modulo {modulus}. The bit is 1 when r >= {threshold}, and 0 otherwise.'
    )


def describe_projection(spec, values, reference):
    low, high = _value_pair(values)
    if low == high:
        _validated_coefficients(spec)
        return f'Use {json.dumps(low)} for every answer {reference}.'
    return (
        f'{describe_classifier(spec, reference)} '
        f'Use {json.dumps(low)} for bit 0 or {json.dumps(high)} for bit 1.'
    )
