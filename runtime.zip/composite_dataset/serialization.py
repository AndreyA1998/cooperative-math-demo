"""Bounded, unambiguous JSON decoding for mathematical inputs.

Integers remain Python integers. Finite floats are valid JSON input; consumers
such as composite schema validation impose their stricter exact-value rules.
"""
import json
import math

MAX_JSON_DEPTH = 128


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def _invalid_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def _finite_float(token):
    value = float(token)
    if not math.isfinite(value):
        raise ValueError("Non-finite JSON number: " + token)
    return value


def loads_json(data, *, max_bytes, max_depth=MAX_JSON_DEPTH):
    """Decode one UTF-8 JSON document within byte and container-depth limits.

    A root list or object has depth one. Duplicate object keys, non-finite
    numbers (including overflowing exponents), and invalid UTF-8 are rejected.
    """
    if not isinstance(data, (str, bytes)):
        raise ValueError("JSON input must be text or UTF-8 bytes")
    try:
        if isinstance(data, str):
            size = len(data.encode("utf-8"))
            text = data
        else:
            size = len(data)
            text = None
        if size > max_bytes:
            raise ValueError("Input JSON exceeds the size limit")
        if text is None:
            text = data.decode("utf-8")
        document = json.loads(text, object_pairs_hook=_unique_object,
                              parse_constant=_invalid_constant, parse_float=_finite_float)
    except (RecursionError, UnicodeError) as error:
        raise ValueError("Invalid or excessively nested JSON input") from error

    # Traverse iteratively so the safety check does not add Python recursion.
    levels = [iter((document,))]
    exhausted = object()
    while levels:
        value = next(levels[-1], exhausted)
        if value is exhausted:
            levels.pop()
        elif isinstance(value, (dict, list)):
            if len(levels) > max_depth:
                raise ValueError("Invalid or excessively nested JSON input")
            children = value.values() if isinstance(value, dict) else value
            levels.append(iter(children))
    return document
