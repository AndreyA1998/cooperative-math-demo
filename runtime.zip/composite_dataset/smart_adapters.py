"""Compile domain-safe unary adapters into one exact, printable JSON AST.

Finite target coordinates belong to an independently certified Cartesian box.
The compiler preserves the source certificate's Boolean partition, hence every
certified upstream dependency. Native leaves use a total rational-domain select;
a finite source domain is closed only when the caller proves it is exhaustive.
"""
from copy import deepcopy
from fractions import Fraction
import json

from .operators import classify, _exact_fraction, _validated_coefficients


def _literal(value):
    if type(value) in (int, str):
        return True
    return isinstance(value, list) and all(_literal(item) for item in value)


def _key(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _fraction_text(value):
    return str(_exact_fraction(value))


def _numeric_pair(values):
    if all(type(v) is int for v in values):
        return list(map(Fraction, values)), 'int'
    if all(type(v) is str for v in values):
        try:
            numbers = list(map(Fraction, values))
        except (ValueError, ZeroDivisionError):
            return None
        if all(str(n) == v for n, v in zip(numbers, values)):
            return numbers, 'rational_string'
    return None


def compile_adapter(source_profile, target_values, *, source_closed=False, source_answers=None):
    """Build a total, nonconstant map into a certified two-value target domain.

    ``source_closed`` must only be set for an upper node whose entire reachable
    answer domain is its native Cartesian profile. A leaf can have other native
    answers, so it always uses a select that is defined on every exact rational.
    ``source_answers`` supplies recomputed answers when schema profiles omit them.
    """
    if type(source_closed) is not bool or not isinstance(source_profile, dict):
        raise ValueError('Invalid source domain declaration')
    if (not isinstance(target_values, (list, tuple)) or len(target_values) != 2
            or not all(_literal(v) for v in target_values)
            or _key(target_values[0]) == _key(target_values[1])):
        raise ValueError('A nonconstant adapter requires two distinct typed target values')
    values = deepcopy(list(target_values))
    spec = source_profile.get('classifier')
    _validated_coefficients(spec)
    raw_answers = source_answers if source_answers is not None else source_profile.get('answers')
    answers = None
    if raw_answers is not None:
        if not isinstance(raw_answers, (list, tuple)) or not raw_answers:
            raise ValueError('Source witnesses must be a nonempty exact answer sequence')
        answers = [_fraction_text(a) for a in raw_answers]
        bits = [classify(spec, a) for a in answers]
        truth = source_profile.get('truth_table')
        if (not isinstance(truth, (list, tuple)) or len(truth) != len(bits)
                or any(type(b) is not int or b not in (0, 1) for b in truth)
                or list(truth) != bits or set(bits) != {0, 1}):
            raise ValueError('Source classifier has no valid nonconstant witness certificate')
    elif source_closed:
        raise ValueError('A closed source domain requires recomputed answers')

    distinct = sorted(set(answers or ()), key=Fraction)
    source_domain = ({'kind': 'finite', 'values': distinct} if source_closed
                     else {'kind': 'rational'})
    common = {'source_domain': source_domain,
              'target_domain': {'kind': 'finite', 'values': values}}
    numbers = _numeric_pair(values)
    if source_closed and len(distinct) == 2 and numbers is not None:
        xs = list(map(Fraction, distinct))
        ys = [numbers[0][classify(spec, a)] for a in distinct]
        scale = (ys[1] - ys[0]) / (xs[1] - xs[0])
        offset = ys[0] - scale * xs[0]
        if scale == 1 and offset == 0:
            return dict(common, kind='identity', result_type=numbers[1])
        return dict(common, kind='affine', scale=str(scale), offset=str(offset),
                    result_type=numbers[1])

    classifier = {'kind': 'floor_mod', 'spec': deepcopy(spec)}
    if answers is not None:
        ordered = [(Fraction(a), classify(spec, a)) for a in distinct]
        transitions = [i for i in range(1, len(ordered)) if ordered[i][1] != ordered[i - 1][1]]
        if len(transitions) == 1:
            i = transitions[0]
            classifier = {'kind': 'threshold',
                          'cut': str((ordered[i - 1][0] + ordered[i][0]) / 2),
                          'less_bit': ordered[0][1]}
    return dict(common, kind='select', classifier=classifier)


def _validate(op):
    if not isinstance(op, dict):
        raise ValueError('Adapter must be a JSON object')
    kind = op.get('kind')
    required = {'kind', 'source_domain', 'target_domain'}
    if kind == 'select':
        required.add('classifier')
    elif kind == 'identity':
        required.add('result_type')
    elif kind == 'affine':
        required.update(('scale', 'offset', 'result_type'))
    else:
        raise ValueError('Unknown adapter kind')
    if set(op) != required:
        raise ValueError('Unexpected adapter fields')
    target = op.get('target_domain')
    if (not isinstance(target, dict) or set(target) != {'kind', 'values'}
            or target['kind'] != 'finite' or not isinstance(target['values'], list)
            or len(target['values']) != 2 or not all(_literal(v) for v in target['values'])
            or _key(target['values'][0]) == _key(target['values'][1])):
        raise ValueError('Invalid finite target domain')
    source = op.get('source_domain')
    if not isinstance(source, dict):
        raise ValueError('Invalid source domain')
    if source.get('kind') == 'rational':
        if set(source) != {'kind'} or kind != 'select':
            raise ValueError('An open source requires a total select')
    elif source.get('kind') == 'finite':
        if (set(source) != {'kind', 'values'} or not isinstance(source['values'], list)
                or len(source['values']) < 2 or any(type(v) is not str for v in source['values'])):
            raise ValueError('Invalid closed source domain')
        canonical = [_fraction_text(v) for v in source['values']]
        if canonical != source['values'] or len(set(canonical)) != len(canonical):
            raise ValueError('Source values must be distinct canonical rational strings')
    else:
        raise ValueError('Unknown source domain')
    if kind == 'select':
        classifier = op['classifier']
        if not isinstance(classifier, dict):
            raise ValueError('Invalid classifier AST')
        if classifier.get('kind') == 'floor_mod':
            if set(classifier) != {'kind', 'spec'}:
                raise ValueError('Unexpected classifier fields')
            _validated_coefficients(classifier['spec'])
        elif classifier.get('kind') == 'threshold':
            if (set(classifier) != {'kind', 'cut', 'less_bit'}
                    or type(classifier['less_bit']) is not int or classifier['less_bit'] not in (0, 1)
                    or type(classifier['cut']) is not str
                    or _fraction_text(classifier['cut']) != classifier['cut']):
                raise ValueError('Invalid threshold AST')
        else:
            raise ValueError('Unknown classifier AST')
    else:
        if op['result_type'] not in ('int', 'rational_string'):
            raise ValueError('Invalid numeric result type')
        numeric = _numeric_pair(target['values'])
        if numeric is None or numeric[1] != op['result_type']:
            raise ValueError('Numeric target type mismatch')
        if kind == 'affine':
            if any(type(op[k]) is not str or _fraction_text(op[k]) != op[k] for k in ('scale', 'offset')):
                raise ValueError('Affine coefficients must be canonical rationals')
            if not Fraction(op['scale']):
                raise ValueError('A constant affine map erases its source')
    if source['kind'] == 'finite':
        image = {_key(_apply(op, Fraction(value), target['values'])) for value in source['values']}
        if image != {_key(v) for v in target['values']}:
            raise ValueError('Closed adapter must attain exactly its certified target domain')
    return target['values']


def evaluate_adapter(op, answer):
    """Evaluate the same JSON AST that ``describe_adapter`` prints."""
    values = _validate(op)
    q = _exact_fraction(answer)
    source = op['source_domain']
    if source['kind'] == 'finite' and str(q) not in source['values']:
        raise ValueError('Answer is outside the certified closed source domain')
    return _apply(op, q, values)


def _apply(op, q, values):
    if op['kind'] == 'select':
        classifier = op['classifier']
        if classifier['kind'] == 'threshold':
            bit = classifier['less_bit'] if q < Fraction(classifier['cut']) else 1 - classifier['less_bit']
        else:
            bit = classify(classifier['spec'], q)
        return deepcopy(values[bit])
    result = q if op['kind'] == 'identity' else Fraction(op['scale']) * q + Fraction(op['offset'])
    if op['result_type'] == 'int':
        if result.denominator != 1:
            raise ValueError('Adapter result is not an integer')
        value = result.numerator
    else:
        value = str(result)
    if _key(value) not in {_key(v) for v in values}:
        raise ValueError('Adapter result is outside its certified target domain')
    return value


def describe_adapter(op, reference):
    """Render an expression, without exposing a table of source answers."""
    values = _validate(op)
    if not isinstance(reference, str) or not reference:
        raise ValueError('A source answer reference is required')
    if op['kind'] == 'identity':
        return reference
    if op['kind'] == 'affine':
        scale, offset = Fraction(op['scale']), Fraction(op['offset'])
        expression = reference if scale == 1 else (f'-{reference}' if scale == -1 else f'({scale})*{reference}')
        if offset:
            expression += f' {"+" if offset > 0 else "-"} {abs(offset)}'
        return expression
    classifier = op['classifier']
    if classifier['kind'] == 'threshold':
        bit = classifier['less_bit']
        return f'{_key(values[bit])} if {reference} < {classifier["cut"]}; otherwise {_key(values[1 - bit])}'
    a, b, divisor, modulus, threshold = _validated_coefficients(classifier['spec'])
    terms = []
    for coefficient, variable in ((a, 'n'), (b, 'd')):
        if coefficient:
            term = variable if abs(coefficient) == 1 else f'{abs(coefficient)}*{variable}'
            terms.append(('+' if coefficient > 0 else '-', term))
    expression = ''.join((('' if sign == '+' else '-') if i == 0 else f' {sign} ') + term
                         for i, (sign, term) in enumerate(terms)) or '0'
    return (f'{_key(values[0])} if floor(({expression})/{divisor}) mod {modulus} < {threshold}; '
            f'otherwise {_key(values[1])} ({reference}=n/d reduced, d>0; mod is nonnegative)')
