"""Execute a composite exclusively through the existing exact atomic solvers."""
from copy import deepcopy
import json
import random

from template_dataset.core import validate_parameters
from template_dataset.registry import generate as atomic_generate, get_template, solve as atomic_solve
from .schema import canonical, derived_seed, seed_value, validate_schema


def checked_bottom(schema, bottom_parameters):
    if not isinstance(bottom_parameters, dict):
        raise ValueError('Bottom parameters must map local node IDs to native parameter objects')
    from .patterns import pattern_accepts
    leaves = [n for n in schema['nodes'] if not n['children']]
    if set(bottom_parameters) != {n['node_id'] for n in leaves}:
        raise ValueError('Exactly one parameter object is required for every bottom node')
    for node in leaves:
        if not validate_parameters(get_template(node['source_id']), bottom_parameters[node['node_id']]):
            raise ValueError('Invalid bottom parameters for ' + node['label'])
        if not pattern_accepts(node['source_id'], node['profile'], bottom_parameters[node['node_id']]):
            raise ValueError('Bottom parameters do not fit the visible pattern for ' + node['label'])
    return leaves


def solve(schema, bottom_parameters):
    validate_schema(schema)
    return _solve_validated(schema, bottom_parameters)


def _solve_validated(schema, bottom_parameters):
    """Execute within an operation that already validated its unchanged schema."""
    from .smart_adapters import evaluate_adapter
    checked_bottom(schema, bottom_parameters)
    answers, trace = {}, []
    for node in sorted(schema['nodes'], key=lambda n: (-n['level'], n['number'])):
        if not node['children']:
            params = deepcopy(bottom_parameters[node['node_id']])
        else:
            signals = [evaluate_adapter(binding['operator'], answers[binding['source_node']])
                       for binding in node['bindings']]
            index = sum((sum(signals[i] for i in group) % 2) << g
                        for g, group in enumerate(node['adapter']['groups']))
            params = deepcopy(node['profile']['rows'][index])
        answer = atomic_solve(node['source_id'], params)
        answers[node['node_id']] = answer
        trace.append({'node_id': node['node_id'], 'label': node['label'],
                      'source_id': node['source_id'], 'parameters': params,
                      'parameters_text': json.dumps(params, ensure_ascii=False, sort_keys=True), 'answer': answer})
    return {'answer': answers[schema['root_id']], 'trace': trace, 'schema_id': schema['schema_id']}


def instantiate(schema, seed):
    from .operators import classify
    from .smart_adapters import evaluate_adapter
    from .rendering import _render
    from .patterns import pattern_accepts
    validate_schema(schema)
    seed_value(seed)
    bottom, sampling = {}, {}
    outgoing = {binding['source_node']: binding['operator']
                for parent in schema['nodes'] for binding in parent['bindings']}
    for node in schema['nodes']:
        if node['children']:
            continue
        rng = random.Random(derived_seed(seed, schema['schema_id'], node['node_id']))
        target_bit = rng.randrange(2)
        classifier = node['profile']['classifier']
        params = None
        # Balance the interface labels, retain native variation where available,
        # and keep a certified valid fallback instead of an unbounded retry.
        for attempt in range(8):
            try:
                item = atomic_generate(node['source_id'], derived_seed(seed, schema['schema_id'], node['node_id'], attempt))
            except RuntimeError:
                continue
            op = outgoing.get(node['node_id'])
            branch_matches = (canonical(evaluate_adapter(op, item['answer'])) ==
                              canonical(op['target_domain']['values'][target_bit])) if op else (
                                  classify(classifier, item['answer']) == target_bit)
            if (branch_matches
                    and pattern_accepts(node['source_id'], node['profile'], item['parameters'])):
                params = item['parameters']
                sampling[node['node_id']] = 'native'
                break
        if params is None:
            choices = [row for row, bit in zip(node['profile']['rows'], node['profile']['truth_table']) if bit == target_bit]
            params = deepcopy(rng.choice(choices))
            sampling[node['node_id']] = 'certified-fallback'
        bottom[node['node_id']] = params
    result = _solve_validated(schema, bottom)
    return dict(result, problem=_render(schema, bottom), bottom_parameters=bottom,
                parameter_seed=str(seed), sampling=sampling)


def dependency_witness(schema, leaf_id):
    """Construct two valid inputs differing only at one leaf with different roots.

    Essential Boolean certificates compose exactly on disjoint child subtrees.
    No probabilistic perturbation or numerical sensitivity approximation is used.
    """
    validate_schema(schema)
    by_id = {node['node_id']: node for node in schema['nodes']}
    if leaf_id not in by_id or by_id[leaf_id]['children']:
        raise ValueError('A bottom node ID is required')

    def assignment(node_id, bit):
        node = by_id[node_id]
        profile = node['profile']
        index = profile['truth_table'].index(bit)
        if not node['children']:
            return {node_id: deepcopy(profile['rows'][index])}
        result = {}
        signals = [0] * node['arity']
        for group_index, ports in enumerate(node['adapter']['groups']):
            signals[ports[0]] = (index >> group_index) & 1
        for port, child in enumerate(node['children']):
            result.update(assignment(child, signals[port]))
        return result

    ancestors = {}
    for node in schema['nodes']:
        for group, ports in enumerate(node['adapter'].get('groups', [])):
            for port in ports:
                ancestors[node['children'][port]] = (node['node_id'], group)
    left, right = assignment(leaf_id, 0), assignment(leaf_id, 1)
    current = leaf_id
    left_bit, right_bit = 0, 1
    while current != schema['root_id']:
        parent_id, group = ancestors[current]
        parent = by_id[parent_id]
        truth = parent['profile']['truth_table']
        index = next(i for i in range(len(truth))
                     if not i & (1 << group) and truth[i] != truth[i | (1 << group)])
        signals = [0] * parent['arity']
        for sibling_group, ports in enumerate(parent['adapter']['groups']):
            if sibling_group != group:
                signals[ports[0]] = (index >> sibling_group) & 1
        # All other signals in the target group are zero, so its parity equals
        # the varied child signal. Other groups realize the essentiality context.
        for port, sibling in enumerate(parent['children']):
            if sibling != current:
                fixed = assignment(sibling, signals[port])
                left.update(deepcopy(fixed))
                right.update(deepcopy(fixed))
        left_bit, right_bit = truth[index | (left_bit << group)], truth[index | (right_bit << group)]
        current = parent_id
    left_answer = _solve_validated(schema, left)['answer']
    right_answer = _solve_validated(schema, right)['answer']
    if left_answer == right_answer:
        raise RuntimeError('Native execution contradicted the dependency certificate')
    return {'leaf_id': leaf_id, 'left': left, 'right': right,
            'left_answer': left_answer, 'right_answer': right_answer}
