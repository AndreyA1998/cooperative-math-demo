"""Reusable composite MATH templates with certified joint parameter adapters."""
from .schema import build_schema
from .runtime import instantiate, solve, dependency_witness
from .rendering import render

__all__ = ['build_schema', 'instantiate', 'solve', 'render', 'dependency_witness']
