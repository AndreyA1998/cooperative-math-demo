"""Search for finite compositional profiles and certify every input combination."""
from copy import deepcopy
from fractions import Fraction
from functools import lru_cache
import gzip
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path
import random
import zlib

from template_dataset.core import validate_parameters
from source_dataset.loader import load_corpus
from template_dataset.registry import UnsupportedProblemError, get_template, solve
from .operators import _FIELDS, _bit


CERTIFICATE_VERSION = 1
MAX_ARITY = 10
_ARTIFACT = Path(__file__).with_name('data') / 'profiles.json.gz'
_DEFAULT_SAMPLES = 16
_REFINEMENT_SAMPLES = 256
_MAX_ROWS = 7
_MAX_GRIDS_PER_ARITY = 24


def is_essential(truth_table, arity):
    """Check that toggling each group can change the classifier's bit."""
    if (type(arity) is not int or not 1 <= arity <= MAX_ARITY
            or len(truth_table) != 1 << arity
            or any(type(bit) is not int or bit not in (0, 1) for bit in truth_table)):
        return False
    return all(
        any(truth_table[index] != truth_table[index ^ (1 << axis)]
            for index in range(len(truth_table)) if not index & (1 << axis))
        for axis in range(arity)
    )


def _classifier_candidates(fractions):
    # Each differing integer has a least significant differing bit, even for
    # negative integers. Thus this family separates any distinct unary pair.
    for axis in (0, 1):
        values = [fraction[axis] for fraction in fractions]
        if len(set(values)) == 1:
            continue
        a, b = (1, 0) if axis == 0 else (0, 1)
        divisors = {1 << bit for bit in range(12)}
        for value in values[1:]:
            difference = values[0] ^ value
            if difference:
                divisors.add(difference & -difference)
        for divisor in sorted(divisors):
            yield a, b, divisor, 2, 1
    for a, b in ((1, 1), (1, -1), (1, 0), (0, 1), (2, 1), (1, 2)):
        for modulus in (3, 5, 7, 11):
            for threshold in (modulus // 2, modulus // 2 + 1):
                yield a, b, 1, modulus, threshold


def _choose_classifier(answers, arity):
    if len(set(answers)) < 2:
        return None
    fractions = [(value.numerator, value.denominator) for value in map(Fraction, answers)]
    # Rule order breaks ties deterministically. Prefer balance on the full grid.
    best = None
    imbalance = len(fractions)
    for coefficients in _classifier_candidates(fractions):
        table = [_bit(coefficients, n, d) for n, d in fractions]
        candidate_imbalance = abs(2 * sum(table) - len(table))
        if candidate_imbalance >= imbalance or not is_essential(table, arity):
            continue
        best = {'op': 'floor_mod', **dict(zip(_FIELDS, coefficients))}, table
        imbalance = candidate_imbalance
        if imbalance == 0:
            break
    return best


def _parameter_key(parameters):
    return json.dumps(parameters, sort_keys=True, separators=(',', ':'))


def _checked_answer(problem_id, parameters, known_answers):
    key = _parameter_key(parameters)
    if key not in known_answers:
        try:
            known_answers[key] = solve(problem_id, parameters)
        except ValueError:
            known_answers[key] = None
    return known_answers[key]


def _certify_grid(problem_id, template, groups, low, high, known_answers=None):
    if known_answers is None:
        known_answers = {}
    names = list(template.parameters)
    arity = len(groups)
    if not 1 <= arity <= MAX_ARITY or sorted(name for group in groups for name in group) != sorted(names):
        return None
    if any(not any(low[name] != high[name] for name in group) for group in groups):
        return None

    # Group zero is the least significant bit in a row index.
    rows, answers = [], []
    for index in range(1 << arity):
        parameters = {
            name: (high if index & (1 << axis) else low)[name]
            for axis, group in enumerate(groups) for name in group
        }
        answer = _checked_answer(problem_id, parameters, known_answers)
        if answer is None:
            return None
        rows.append(parameters)
        answers.append(answer)

    certificate = _choose_classifier(answers, arity)
    if certificate is None:
        return None
    classifier, truth_table = certificate
    return {
        'id': problem_id, 'arity': arity, 'parameter_names': names,
        'groups': groups, 'rows': rows, 'answers': answers, 'classifier': classifier,
        'truth_table': truth_table, 'certificate_version': CERTIFICATE_VERSION,
        'fixed_coordinates': [name for name in names if low[name] == high[name]],
    }


def _native_rows(problem_id, template, samples, known_answers, *, refine):
    digest = sha256(f'mathgen.composite.profiles\0{CERTIFICATE_VERSION}\0{problem_id}'.encode()).digest()
    rng = random.Random(int.from_bytes(digest, 'big'))
    original_prompt = template.render(template.original)
    rows, seen, answers = [], set(), set()
    budget = _REFINEMENT_SAMPLES if refine else samples
    for proposal in range(budget):
        if proposal >= samples and len(answers) > 1:
            break
        parameters = template.sample(rng)
        key = _parameter_key(parameters)
        if key in seen:
            continue
        seen.add(key)
        if not validate_parameters(template, parameters) or template.render(parameters) == original_prompt:
            continue
        answer = _checked_answer(problem_id, parameters, known_answers)
        if answer is None:
            continue
        if len(rows) < _MAX_ROWS or answer not in answers:
            rows.append((parameters, answer))
        answers.add(answer)
        if len(rows) >= _MAX_ROWS and (not refine or len(answers) > 1):
            break
    if refine and len(answers) < 2:
        # A sampled constant is not a constant function. Probe exceptional
        # native values deterministically, including the original assignment.
        # Atomic generation still excludes its original prompt; compositional
        # certificates may use any valid native assignment as a witness.
        probes = [deepcopy(template.original)]
        for name, domain in template.parameters.items():
            values = list(domain.get('choices', []))[:32]
            if domain.get('type', 'int') in ('int', 'integer'):
                values += [domain.get('min'), domain.get('max'), 0, 1, -1,
                           template.original[name] - 1, template.original[name] + 1]
            for value in values:
                if value is not None:
                    probes.append(dict(template.original, **{name: value}))
        for parameters in probes:
            key = _parameter_key(parameters)
            if key in known_answers or not validate_parameters(template, parameters):
                continue
            seen.add(key)
            answer = _checked_answer(problem_id, parameters, known_answers)
            if answer is None:
                continue
            if len(rows) < _MAX_ROWS or answer not in answers:
                rows.append((parameters, answer))
            answers.add(answer)
            if len(answers) > 1:
                break
    return rows


def _partitions(names, varying, arity):
    if arity == 1:
        yield [names]
        return
    # Put one varying coordinate in each leading group and keep the remaining
    # coordinates together. Rotate the choice to separate alternative inputs.
    for separate in combinations(varying, arity - 1):
        if len(varying) == arity and varying[-1] in separate:
            continue
        yield [[name] for name in separate] + [[name for name in names if name not in separate]]


def _profiles_for(problem_id, max_arity, samples, *, refine=False):
    try:
        template = get_template(problem_id)
    except UnsupportedProblemError:
        return [], 'unsupported_atomic'
    names = list(template.parameters)
    known_answers = {}
    rows = _native_rows(problem_id, template, samples, known_answers, refine=refine)
    if len(rows) < 2:
        return [], 'fewer_than_two_nonoriginal_rows'
    pairs = []
    for (low, left_answer), (high, right_answer) in combinations(rows, 2):
        if left_answer != right_answer:
            varying = [name for name in names if low[name] != high[name]]
            pairs.append((low, high, varying))
    if not pairs:
        return [], 'constant_on_sampled_rows'

    pairs.sort(key=lambda pair: -len(pair[2]))
    profiles = []
    for arity in range(1, min(4, max_arity, len(pairs[0][2])) + 1):
        tried = 0
        for low, high, varying in pairs:
            if len(varying) < arity or tried >= _MAX_GRIDS_PER_ARITY:
                break
            for groups in _partitions(names, varying, arity):
                profile = _certify_grid(problem_id, template, groups, low, high, known_answers)
                tried += 1
                if profile is not None or tried >= _MAX_GRIDS_PER_ARITY:
                    break
            if profile is not None:
                profiles.append(profile)
                break
    if len(names) <= max_arity and not any(is_strict_profile(p) for p in profiles):
        strict = _strict_profile(problem_id, template, rows, pairs, known_answers)
        if strict is not None:
            profiles.append(strict)
    return profiles, None if profiles else 'no_essential_grid'



def is_strict_profile(profile):
    """Structural eligibility; native rows and essentiality still need verification."""
    if not isinstance(profile, dict):
        return False
    names = profile.get('parameter_names', [])
    groups = profile.get('groups', [])
    return (isinstance(names, list) and bool(names) and all(type(n) is str for n in names)
            and len(set(names)) == len(names) and len(names) <= MAX_ARITY
            and isinstance(groups, list) and type(profile.get('arity')) is int
            and profile.get('arity') == len(names) and len(groups) == len(names)
            and all(isinstance(group, list) and len(group) == 1 and type(group[0]) is str for group in groups)
            and sorted(group[0] for group in groups) == sorted(names)
            and not profile.get('fixed_coordinates', []))


def _strict_profile(problem_id, template, rows, pairs, known_answers):
    """Bounded singleton search: sampled pairs, then valid one-coordinate moves.

    Every returned box is exhaustively solved; search failure is not a proof of
    impossibility. Grouped leaf witnesses never relax singleton ownership.
    """
    names = list(template.parameters)
    if not 1 <= len(names) <= MAX_ARITY:
        return None
    groups = [[name] for name in names]
    seen = set()

    def attempt(low, high):
        if any(low[name] == high[name] for name in names):
            return None
        key = (_parameter_key(low), _parameter_key(high))
        if key in seen:
            return None
        seen.add(key)
        return _certify_grid(problem_id, template, groups, low, high, known_answers)

    for low, high, varying in pairs[:_MAX_GRIDS_PER_ARITY]:
        profile = attempt(low, high)
        if profile is not None:
            return profile
    # Native samplers often correlate values. Recombine single-coordinate moves
    # around valid anchors, then certify the full product rather than assuming it.
    digest = sha256(f'mathgen.composite.singleton\0{problem_id}'.encode()).digest()
    rng = random.Random(int.from_bytes(digest, 'big'))
    proposals = [p for p, answer in rows] + [template.original]
    proposals += [template.sample(rng) for _ in range(16)]
    for anchor in proposals[:3] + [template.original]:
        options = {}
        for name in names:
            candidates = []
            keys = set()
            domain = template.parameters[name]
            raw = [p[name] for p in proposals]
            if domain.get('type', 'int') in ('int', 'integer'):
                raw += list(domain.get('choices', []))[:16]
                if 'min' in domain and 'max' in domain:
                    raw += [anchor[name] - 1, anchor[name] + 1, domain['min'], domain['max']]
            for value in raw:
                key = _parameter_key({'value': value})
                if value == anchor[name] or key in keys:
                    continue
                keys.add(key)
                changed = dict(anchor, **{name: value})
                if validate_parameters(template, changed):
                    candidates.append(value)
            options[name] = candidates
        if any(not values for values in options.values()):
            continue
        for trial in range(6):
            high = {name: (options[name][0] if trial == 0 else rng.choice(options[name])) for name in names}
            profile = attempt(anchor, high)
            if profile is not None:
                return profile
    return None


def _check_options(split, max_arity, samples):
    if split not in (None, 'train', 'test'):
        raise ValueError('split must be train, test, or None')
    if type(max_arity) is not int or not 1 <= max_arity <= MAX_ARITY:
        raise ValueError(f'max_arity must be an integer from 1 to {MAX_ARITY}')
    if type(samples) is not int or samples < 1:
        raise ValueError('samples must be a positive integer')


def _build_catalogue(split, max_arity, samples):
    _check_options(split, max_arity, samples)
    catalogue, exclusions = {}, {}
    for problem_id, row in sorted(load_corpus().items()):
        if split is not None and row['split'] != split:
            continue
        profiles, reason = _profiles_for(problem_id, max_arity, samples,
                                         refine=(samples == _DEFAULT_SAMPLES))
        if profiles:
            catalogue[problem_id] = profiles
        else:
            exclusions[problem_id] = reason
    return catalogue, exclusions


def build_catalogue(*, split=None, max_arity=MAX_ARITY, samples=_DEFAULT_SAMPLES):
    """Build from scratch, refining first-pass misses when using the default budget."""
    return _build_catalogue(split, max_arity, samples)[0]


def _source_fingerprint():
    root = Path(__file__).resolve().parents[1]
    atomic = root / 'template_dataset'
    paths = [atomic / name for name in ('__init__.py', 'core.py', 'registry.py')]
    paths += [root / 'source_dataset' / name for name in ('__init__.py', 'loader.py')]
    paths += list((atomic / 'families').rglob('*.py'))
    paths += [Path(__file__).resolve(), Path(__file__).resolve().with_name('operators.py')]
    paths += [root / 'source_dataset' / split / f'{table}.jsonl'
              for split in ('train', 'test') for table in ('problems', 'answers')]
    manifest = sha256()
    for path in sorted(paths):
        manifest.update(path.relative_to(root).as_posix().encode() + b'\0')
        manifest.update(sha256(path.read_bytes()).digest())
    return manifest.hexdigest()


def _encoded_payload(catalogue, exclusions):
    return json.dumps({'catalogue': catalogue, 'exclusions': exclusions},
                      sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def _write_artifact(path, fingerprint, catalogue, exclusions):
    payload = _encoded_payload(catalogue, exclusions)
    metadata = {
        'certificate_version': CERTIFICATE_VERSION,
        'source_fingerprint': fingerprint,
        'payload_sha256': sha256(payload).hexdigest(),
    }
    header = json.dumps(metadata, sort_keys=True, separators=(',', ':')).encode()
    # Keep both the compression timestamp and the embedded file name stable.
    with path.open('wb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as output:
        output.write(b'{"metadata":' + header + b',"data":' + payload + b'}')


def _load_artifact(path, fingerprint):
    try:
        with gzip.open(path, 'rb') as source:
            artifact = json.load(source)
        if not isinstance(artifact, dict):
            return None
        metadata, data = artifact.get('metadata'), artifact.get('data')
        if (not isinstance(metadata, dict) or metadata.get('certificate_version') != CERTIFICATE_VERSION
                or metadata.get('source_fingerprint') != fingerprint or not isinstance(data, dict)):
            return None
        catalogue, exclusions = data.get('catalogue'), data.get('exclusions')
        if not isinstance(catalogue, dict) or not isinstance(exclusions, dict):
            return None
        if sha256(_encoded_payload(catalogue, exclusions)).hexdigest() != metadata.get('payload_sha256'):
            return None
        return catalogue, exclusions
    except (OSError, EOFError, ValueError, zlib.error):
        return None


def save_catalogue(path=_ARTIFACT):
    """Regenerate the checked default runtime artifact from the atomic corpus."""
    fingerprint = _source_fingerprint()
    catalogue, exclusions = _build_catalogue(None, MAX_ARITY, _DEFAULT_SAMPLES)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    _write_artifact(path, fingerprint, catalogue, exclusions)
    return path


@lru_cache(maxsize=1)
def _default_catalogue():
    artifact = _load_artifact(_ARTIFACT, _source_fingerprint())
    return artifact if artifact is not None else _build_catalogue(None, MAX_ARITY, _DEFAULT_SAMPLES)


def get_catalogue():
    """Return an independent copy of the default full corpus catalogue."""
    return deepcopy(_default_catalogue()[0])


def catalogue_exclusions(*, split=None):
    """Report default search failures without claiming global impossibility."""
    _check_options(split, 4, _DEFAULT_SAMPLES)
    exclusions = _default_catalogue()[1]
    if split is None:
        return dict(exclusions)
    rows = load_corpus()
    return {problem_id: reason for problem_id, reason in exclusions.items()
            if rows[problem_id]['split'] == split}
