"""Sample full-depth ordered trees using exact frontier feasibility."""

from collections import defaultdict
from collections.abc import Mapping, Sequence
from functools import lru_cache
from hashlib import sha256
from math import gcd
from typing import NamedTuple, Optional

MAX_DEPTH = 12
MAX_WIDTH = 128
MAX_NODES = MAX_DEPTH * MAX_WIDTH
MAX_FEASIBILITY_STATES = 200_000


class InfeasibleTopologyError(ValueError):
    """No tree of the specified depth fits the requested width and catalog."""


class TopologyLimitError(ValueError):
    """A topology dimension or the exact search exceeds a supported limit."""


class _TopologyRNG:
    def __init__(self, seed: int):
        self.prefix = b"mathgen/composite/topology/compact-1\0" + seed.to_bytes(8, "big")
        self.counter = 0

    def below(self, count: int) -> int:
        ceiling = (1 << 256) - (1 << 256) % count
        while True:
            block = sha256(self.prefix + self.counter.to_bytes(8, "big")).digest()
            self.counter += 1
            value = int.from_bytes(block, "big")
            if value < ceiling:
                return value % count


class _Frontier(NamedTuple):
    levels: int
    current: int
    following: int
    stock: Optional[tuple[int, ...]]
    budget: Optional[int] = None

    def advance(self, bucket: int, arity: int):
        stock = self.stock
        if stock is not None:
            stock = (*stock[:bucket], stock[bucket] - 1, *stock[bucket + 1:])
        following = self.following + arity
        budget = None if self.budget is None else self.budget - 1
        if self.current == 1:
            return _Frontier(self.levels - 1, following, 0, stock, budget)
        return _Frontier(self.levels, self.current - 1, following, stock, budget)


class _Feasibility:
    def __init__(self, masks: tuple[tuple[int, ...], ...]):
        self.masks = masks
        self.arities = tuple(sorted(set().union(*masks)))
        self.maxima = tuple(mask[-1] if mask else 0 for mask in masks)
        self.largest_first = sorted(range(len(masks)), key=self.maxima.__getitem__, reverse=True)
        mask_sets = tuple(frozenset(mask) for mask in masks)
        self.arity_indices = {arity: index for index, arity in enumerate(self.arities)}
        self.balanced_caps = []
        for index, arity in enumerate(self.arities, 1):
            if arity != index:
                break
            if arity >= 2:
                self.balanced_caps.append(arity)
        self.support = {
            arity: tuple(sorted(
                (index for index, mask in enumerate(masks) if arity in mask),
                key=lambda index: len(masks[index]),
            ))
            for arity in self.arities
        }
        self.subsets = tuple(
            tuple(other for other, subset in enumerate(mask_sets) if subset < mask)
            for mask in mask_sets
        )
        self.width = 0
        self.memo: dict[_Frontier, Optional[tuple[int, ...]]] = {}
        self.checked = 0

    def set_width(self, width: int):
        self.width = width
        self.memo.clear()
        self.geometry_arities = tuple(arity for arity in self.arities if arity <= width)
        self.child_totals = [1]
        self.level_frontiers = [1 << width]
        self.unary_frontiers = [[MAX_NODES + 1] * width + [0]]
        self.unary_memo = {}
        self.geometry_costs = [[MAX_NODES + 1] * width + [0]]
        self.geometry_memo = {}

    def _bound(self, state: _Frontier) -> Optional[bool]:
        levels, current, following, stock = state[:4]
        width = self.width
        assert stock is not None
        if state.budget is not None and state.budget < 0:
            return False
        if levels == 0:
            return current == width and sum(stock) >= width

        arities = tuple(arity for arity in self.arities
                        if any(stock[bucket] for bucket in self.support[arity]))
        if not arities:
            return False
        min_arity, max_arity = arities[0], arities[-1]
        min_next = following + current * min_arity
        max_next = following + current * max_arity
        if not min_next * min_arity ** (levels - 1) <= width <= max_next * max_arity ** (levels - 1):
            return False
        # Each expansion adds arity - 1 to the number of frontier slots.
        excess_gcd = gcd(*(arity - 1 for arity in arities))
        if excess_gcd and (width - current - following) % excess_gcd:
            return False

        available = sum(stock) - width
        internal_budget = min(available, sum(stock[i] for i in self.largest_first if self.maxima[i]))
        if state.budget is not None:
            internal_budget = min(internal_budget, state.budget)
            if self.minimum_cost(state) > state.budget:
                return False
        needed = current
        next_minimum = min_next
        for gap in range(levels - 1, 0, -1):
            descendants = max_arity ** gap
            needed += max(next_minimum, (width + descendants - 1) // descendants)
            next_minimum *= min_arity
        if internal_budget < needed:
            return False

        # A non-unary node consumes at least one unit of the remaining growth.
        # Only sources that support arity 1 can cover the other internal nodes.
        needed_excess = width - current - following
        unary_stock = sum(stock[bucket] for bucket in self.support.get(1, ()))
        if unary_stock < needed and unary_stock < self._minimum_unary(levels, current, following):
            return False

        # Even spending the entire budget on the largest arities must supply
        # enough new slots. This ignores levels, giving an admissible upper bound.
        for bucket in self.largest_first:
            if needed_excess <= 0 or self.maxima[bucket] <= 1 or internal_budget == 0:
                break
            usable = min(internal_budget, stock[bucket])
            needed_excess -= usable * (self.maxima[bucket] - 1)
            internal_budget -= usable
        if needed_excess > 0 or not self._growth_can_reach(state):
            return False
        return None

    def _minimum_unary(self, levels: int, current: int, following: int) -> int:
        key = (levels, current, following)
        if key in self.unary_memo:
            return self.unary_memo[key]
        # Relax non-unary IDs to unlimited stock at every arity >= 2.
        # For m nodes giving t >= m children, the fewest unary nodes is
        # max(0, 2*m-t). Minimize that cost across all full-depth frontiers.
        while len(self.unary_frontiers) < levels:
            previous = self.unary_frontiers[-1]
            self.unary_frontiers.append([MAX_NODES + 1, *(
                min(max(0, 2 * slots - frontier) + previous[frontier]
                    for frontier in range(slots, self.width + 1))
                for slots in range(1, self.width + 1)
            )])
        previous = self.unary_frontiers[levels - 1]
        result = min(max(0, 2 * current + following - frontier) + previous[frontier]
                     for frontier in range(current + following, self.width + 1))
        self.unary_memo[key] = result
        return result

    def _growth_can_reach(self, state: _Frontier) -> bool:
        # Relax to unlimited unary sources and each ID's maximum arity.
        # Moving a larger increment from a later slot into an earlier one
        # only creates extra slots, which can be filled with virtual unary IDs.
        # Thus spending the largest increments first maximizes relaxed width.
        levels, current, following, stock = state[:4]
        assert stock is not None
        increments = iter((self.maxima[bucket] - 1, stock[bucket])
                          for bucket in self.largest_first if self.maxima[bucket] > 1 and stock[bucket])
        growth, count = next(increments, (0, 0))
        while levels:
            frontier = current + following
            while current and growth and frontier < self.width:
                used = min(current, count)
                frontier += growth * used
                current -= used
                count -= used
                if not count:
                    growth, count = next(increments, (0, 0))
            if frontier >= self.width:
                return True
            if not growth:
                return False
            current, following = frontier, 0
            levels -= 1
        return False

    def _successors(self, state: _Frontier):
        stock = state.stock
        assert stock is not None
        capacity = self.arities[-1] ** (state.levels - 1)
        minimum_next = (self.width + capacity - 1) // capacity
        preferred = max(1, (minimum_next - state.following + state.current - 1) // state.current)
        for arity in sorted(self.arities, key=lambda arity: (abs(arity - preferred), arity)):
            for bucket in self.support[arity]:
                # A remaining strict subset can play this arity, and its use
                # preserves a superset that can fill any of its later roles.
                if stock[bucket] and not any(stock[other] and arity in self.masks[other]
                                             for other in self.subsets[bucket]):
                    yield state.advance(bucket, arity), self.arity_indices[arity]

    def _fits_stock(self, demand: tuple[int, ...], stock: tuple[int, ...]) -> bool:
        """Try to assign a geometry witness to the inventory."""
        if sum(stock) < self.width + sum(demand):
            return False
        remaining = list(stock)
        for arity in sorted(self.arities, key=lambda arity: len(self.support[arity])):
            needed = demand[self.arity_indices[arity]]
            for bucket in self.support[arity]:
                if needed == 0:
                    break
                count = min(needed, remaining[bucket])
                remaining[bucket] -= count
                needed -= count
            if needed:
                return False
        return True

    def _balanced_witness(self, state: _Frontier, cap: int) -> Optional[tuple[int, ...]]:
        # All arities 1 through cap are available in the geometry. Delay
        # growth, then split each level between two neighboring arities.
        levels, current, following, _ = state[:4]
        demand = [0] * len(self.arities)
        while levels:
            capacity = cap ** (levels - 1)
            min_next = (self.width + capacity - 1) // capacity
            frontier = max(current + following, min_next)
            average, higher = divmod(frontier - following, current)
            if average + bool(higher) > cap:
                return None
            demand[self.arity_indices[average]] += current - higher
            if higher:
                demand[self.arity_indices[average + 1]] += higher
            current, following = frontier, 0
            levels -= 1
        if current != self.width:
            return None
        return tuple(demand)

    def _prepare_geometry(self, levels):
        if len(self.child_totals) == 1:
            limit = (1 << (self.width + 1)) - 1
            for _ in range(self.width):
                totals = 0
                for arity in self.geometry_arities:
                    totals |= self.child_totals[-1] << arity
                self.child_totals.append(totals & limit)
        while len(self.geometry_costs) <= levels:
            previous = self.geometry_costs[-1]
            costs = [MAX_NODES + 1] * (self.width + 1)
            for count in range(1, self.width + 1):
                possible = self.child_totals[count]
                while possible:
                    bit = possible & -possible
                    frontier = bit.bit_length() - 1
                    costs[count] = min(costs[count], count + previous[frontier])
                    possible -= bit
            self.geometry_costs.append(costs)

    def _best_frontier(self, levels, current, following):
        # Inventory and budget do not affect the relaxed geometric optimum.
        # Cache impossible frontiers too; set_width resets this entire table.
        key = (levels, current, following)
        if key in self.geometry_memo:
            return self.geometry_memo[key]
        self._prepare_geometry(levels - 1)
        if current + following > self.width:
            self.geometry_memo[key] = None
            return None
        possible = (self.child_totals[current] << following) & ((1 << (self.width + 1)) - 1)
        previous = self.geometry_costs[levels - 1]
        candidates = []
        while possible:
            bit = possible & -possible
            frontier = bit.bit_length() - 1
            if previous[frontier] <= MAX_NODES:
                candidates.append(frontier)
            possible -= bit
        result = min(candidates, key=lambda n: (previous[n], n)) if candidates else None
        self.geometry_memo[key] = result
        return result

    def minimum_cost(self, state):
        if state.levels == 0:
            return 0 if state.current == self.width else MAX_NODES + 1
        frontier = self._best_frontier(state.levels, state.current, state.following)
        return (state.current + self.geometry_costs[state.levels - 1][frontier]
                if frontier is not None else MAX_NODES + 1)

    def _geometry_witness(self, state: _Frontier) -> Optional[tuple[int, ...]]:
        if state in self.memo:
            return self.memo[state]
        minimum = self.minimum_cost(state)
        if minimum > MAX_NODES or (state.budget is not None and minimum > state.budget):
            self.memo[state] = None
            return None
        levels, current, following, _ = state[:4]
        demand = [0] * len(self.arities)
        while levels:
            frontier = self._best_frontier(levels, current, following)
            total = frontier - following
            for remaining in range(current - 1, -1, -1):
                arity = min((arity for arity in self.geometry_arities if total >= arity
                             and self.child_totals[remaining] & (1 << (total - arity))),
                            key=lambda arity: (abs(arity * (remaining + 1) - total), arity))
                demand[self.arity_indices[arity]] += 1
                total -= arity
            current, following = frontier, 0
            levels -= 1
        self.memo[state] = tuple(demand)
        return self.memo[state]

    def feasible(self, initial: _Frontier) -> bool:
        if initial in self.memo:
            return self.memo[initial] is not None
        if initial.stock is None:
            return self._geometry_witness(initial) is not None
        bound = self._bound(initial)
        if bound is not None:
            self.memo[initial] = (0,) * len(self.arities) if bound else None
            return bound
        for cap in self.balanced_caps:
            demand = self._balanced_witness(initial, cap)
            if (demand is not None and (initial.budget is None or sum(demand) <= initial.budget)
                    and self._fits_stock(demand, initial.stock)):
                self.memo[initial] = demand
                return True
        # A geometry witness can settle the query if it fits the inventory.
        # Otherwise the exact stocked search explores the remaining choices.
        demand = self._geometry_witness(_Frontier(initial.levels, initial.current, initial.following, None, initial.budget))
        if demand is None or self._fits_stock(demand, initial.stock):
            self.memo[initial] = demand
            return demand is not None
        return self._search(initial) is not None

    @staticmethod
    def _add_arity(demand: tuple[int, ...], index: int) -> tuple[int, ...]:
        return (*demand[:index], demand[index] + 1, *demand[index + 1:])

    def _record_witness(self, stack, demand: tuple[int, ...]) -> tuple[int, ...]:
        while stack:
            state, _, index = stack.pop()
            self.memo[state] = demand
            if index is not None:
                demand = self._add_arity(demand, index)
        return demand

    def _search(self, initial: _Frontier) -> Optional[tuple[int, ...]]:
        if initial in self.memo:
            return self.memo[initial]
        # Stack entries store the frontier, its successor iterator and the
        # arity index of the parent transition. Successful searches cache
        # the complete arity demand from each state along the path.
        stack = [(initial, None, None)]
        while stack:
            state, successors, index = stack[-1]
            if successors is None:
                self.checked += 1
                if self.checked > MAX_FEASIBILITY_STATES:
                    raise TopologyLimitError(
                        f"exact topology search exceeded {MAX_FEASIBILITY_STATES} frontier states"
                    )
                result = self._bound(state)
                if result is True:
                    return self._record_witness(stack, (0,) * len(self.arities))
                if result is False:
                    self.memo[state] = None
                    stack.pop()
                    continue
                successors = self._successors(state)
                stack[-1] = (state, successors, index)

            step = next(successors, None)
            if step is None:
                self.memo[state] = None
                stack.pop()
                continue
            successor, next_index = step
            if successor not in self.memo:
                stack.append((successor, None, next_index))
            elif self.memo[successor] is not None:
                demand = self._add_arity(self.memo[successor], next_index)
                return self._record_witness(stack, demand)
        return None


def _group_sources(capabilities: Mapping[str, Sequence[int]]):
    if not isinstance(capabilities, Mapping):
        raise ValueError("capabilities must map source IDs to supported arities")
    groups = defaultdict(list)
    for source_id, arities in capabilities.items():
        if not isinstance(source_id, str) or not source_id:
            raise ValueError("source IDs must be nonempty strings")
        if not isinstance(arities, Sequence) or not arities or any(
            type(arity) is not int or arity < 0 for arity in arities
        ):
            raise ValueError(f"source {source_id!r} must have nonnegative integer arities")
        if tuple(arities) != tuple(sorted(set(arities))):
            raise ValueError(f"source {source_id!r} arities must be sorted and unique")
        groups[tuple(arity for arity in arities if arity)].append(source_id)
    masks = tuple(sorted(groups))
    return masks, [sorted(groups[mask]) for mask in masks]


def _width_bound(requested: int, depth: int, masks, buckets, reuse: bool) -> int:
    levels = depth - 1
    arities = [arity for mask in masks for arity in mask]
    if levels == 0:
        return 1
    if not arities or min(arities) ** levels > requested:
        return 0
    upper = min(requested, max(arities) ** levels)
    if not reuse:
        # A tree needs at least one internal node per internal level.
        upper = min(upper, sum(map(len, buckets)) - levels)
        if sum(len(bucket) for mask, bucket in zip(masks, buckets) if mask) < levels:
            return 0
        upper = min(upper, 1 + sum(
            (mask[-1] - 1) * len(bucket) for mask, bucket in zip(masks, buckets) if mask
        ))
    return upper


@lru_cache(maxsize=64)
def _minimum_internal_nodes(masks, stock, depth, width):
    oracle = _Feasibility(masks)
    oracle.set_width(width)
    state = _Frontier(depth - 1, 1, 0, stock)
    if not oracle.feasible(state):
        raise AssertionError('minimum budget requested for an infeasible width')
    low = oracle.minimum_cost(state)
    high = sum(oracle.memo[state])
    while low < high:
        middle = (low + high) // 2
        candidate = state._replace(budget=middle)
        if oracle.feasible(candidate):
            high = middle
        else:
            low = middle + 1
    return low


def _choose_source(options, buckets: list[list[str]], rng: _TopologyRNG, reuse: bool):
    ticket = rng.below(sum(len(buckets[bucket]) for bucket, _ in options))
    for bucket, arities in options:
        ids = buckets[bucket]
        if ticket < len(ids):
            source_id = ids[ticket] if reuse else ids.pop(ticket)
            return source_id, bucket, arities[rng.below(len(arities))]
        ticket -= len(ids)
    raise AssertionError("source ticket out of range")


def _assignment_feasible(demand, masks, stock):
    """Exact capacitated bipartite matching; greedy success is only a fast path."""
    remaining = list(stock)
    requested = [(arity, count) for arity, count in sorted(demand.items()) if count]
    supports = {arity: [i for i, mask in enumerate(masks) if arity in mask] for arity, _ in requested}
    for arity, count in sorted(requested, key=lambda item: len(supports[item[0]])):
        for bucket in supports[arity]:
            used = min(count, remaining[bucket])
            count -= used
            remaining[bucket] -= used
        if count:
            break
    else:
        return True
    # Failed greedy matching does not prove infeasibility for overlapping masks.
    source, sink = ('source',), ('sink',)
    residual = defaultdict(dict)
    def edge(left, right, capacity):
        residual[left][right] = capacity
        residual[right][left] = 0
    for arity, count in requested:
        node = ('arity', arity)
        edge(source, node, count)
        for bucket in supports[arity]:
            edge(node, ('bucket', bucket), count)
    for bucket, count in enumerate(stock):
        edge(('bucket', bucket), sink, count)
    needed = sum(count for _, count in requested)
    while needed:
        previous, queue = {source: None}, [source]
        for node in queue:
            for other, capacity in residual[node].items():
                if capacity and other not in previous:
                    previous[other] = node
                    queue.append(other)
            if sink in previous:
                break
        if sink not in previous:
            return False
        amount, node = needed, sink
        while node != source:
            parent = previous[node]
            amount = min(amount, residual[parent][node])
            node = parent
        node = sink
        while node != source:
            parent = previous[node]
            residual[parent][node] -= amount
            residual[node][parent] += amount
            node = parent
        needed -= amount
    return True


def _assign_sources(nodes, masks, buckets, rng, reuse):
    demand = defaultdict(int)
    for node in nodes:
        if node['arity']:
            demand[node['arity']] += 1
    for node in nodes:
        arity = node['arity']
        if arity:
            demand[arity] -= 1
        options = []
        for bucket, mask in enumerate(masks):
            if not buckets[bucket] or (arity and arity not in mask):
                continue
            if arity and not reuse:
                stock = tuple(len(ids) - (i == bucket) for i, ids in enumerate(buckets))
                if not _assignment_feasible(demand, masks, stock):
                    continue
            options.append((bucket, (arity,)))
        node['source_id'], _, _ = _choose_source(options, buckets, rng, reuse)


def sample_tree(
    capabilities: Mapping[str, Sequence[int]],
    depth: int,
    width: int,
    seed: int,
    allow_template_reuse: bool = False,
) -> dict:
    """Build an ordered tree of exact depth at the largest feasible supported width.

    The search is capped at MAX_WIDTH. The result keeps the caller's requested
    width so consumers can report any reduction.

    Width is maximized geometrically with reuse allowed. Requested uniqueness
    is retained if that width has an exact stocked completion; otherwise reuse
    is enabled and reported in the result. Search resource errors propagate.
    The chosen width precedes sampling an internal-node budget between the
    exact minimum and a compact depth-plus-width envelope. Anonymous arity
    choices are uniform among currently stock-and-budget-feasible arities.
    Once the whole shape is fixed, each compatible source ID that permits
    completion gets one ticket. All remaining IDs are eligible at leaves.
    """
    if type(depth) is not int or depth < 1:
        raise ValueError("depth must be a positive integer")
    if type(width) is not int or width < 1:
        raise ValueError("width must be a positive integer")
    if type(seed) is not int or not 0 <= seed < 2**64:
        raise ValueError("seed must be a uint64 integer")
    if type(allow_template_reuse) is not bool:
        raise ValueError("allow_template_reuse must be a boolean")
    if depth > MAX_DEPTH:
        raise TopologyLimitError(f"depth exceeds the supported maximum of {MAX_DEPTH}")

    masks, buckets = _group_sources(capabilities)
    requested_allow_template_reuse = allow_template_reuse
    # Preserve geometric depth and width before enforcing preferred uniqueness.
    # A resource exception from the exact stocked oracle must propagate, not be
    # mistaken for a proof that source reuse is necessary.
    state = _Frontier(depth - 1, 1, 0, None)
    width_limit = min(width, MAX_WIDTH)
    upper = _width_bound(width_limit, depth, masks, buckets, True)

    oracle = _Feasibility(masks)
    for actual_width in range(upper, 0, -1) if buckets else ():
        oracle.set_width(actual_width)
        if oracle.feasible(state):
            break
    else:
        raise InfeasibleTopologyError(
            f"no tree of depth {depth} fits width {width_limit} or less with the available sources"
        )

    if not requested_allow_template_reuse:
        unique_state = state._replace(stock=tuple(map(len, buckets)))
        if oracle.feasible(unique_state):
            state = unique_state
        else:
            allow_template_reuse = True
    stock = state.stock
    minimum = _minimum_internal_nodes(masks, stock, depth, actual_width)
    rng = _TopologyRNG(seed)
    ceiling = max(minimum, min((depth - 1) * actual_width, actual_width + depth - 2))
    budget = minimum + rng.below(ceiling - minimum + 1)
    state = state._replace(budget=budget)
    nodes = []
    next_child = 1
    while state.levels:
        feasible_arities = defaultdict(list)
        for bucket, mask in enumerate(masks):
            count = len(buckets[bucket]) if state.stock is None else state.stock[bucket]
            if count:
                for arity in mask:
                    if oracle.feasible(state.advance(bucket, arity)):
                        feasible_arities[arity].append((bucket, count))
        arities = sorted(feasible_arities)
        arity = arities[rng.below(len(arities))]
        choices = feasible_arities[arity]
        ticket = rng.below(sum(count for _, count in choices))
        for bucket, count in choices:
            if ticket < count:
                break
            ticket -= count
        nodes.append({
            'node_id': f'n{len(nodes)}', 'source_id': '',
            'level': depth - state.levels - 1, 'arity': arity,
            'children': [f'n{index}' for index in range(next_child, next_child + arity)],
        })
        next_child += arity
        state = state.advance(bucket, arity)
    for _ in range(actual_width):
        nodes.append({'node_id': f'n{len(nodes)}', 'source_id': '',
                      'level': depth - 1, 'arity': 0, 'children': []})
    # Anonymous stock choices certify a shape. Actual source IDs are assigned
    # only after the entire shape is fixed, with exact remaining-role matching.
    _assign_sources(nodes, masks, buckets, rng, allow_template_reuse)
    return {
        "nodes": nodes,
        "root_id": "n0",
        "requested_width": width,
        "actual_width": actual_width,
        "depth": depth,
        "allow_template_reuse": allow_template_reuse,
        "requested_allow_template_reuse": requested_allow_template_reuse,
        "sampling_policy": "compact-shape-first-1",
        "minimum_internal_nodes": minimum,
        "internal_node_budget": budget,
    }
