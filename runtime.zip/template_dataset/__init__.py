"""Verified parameterized MATH tasks. Public API loads the registry lazily."""
from .core import VERSION as __version__


def generate(problem_id, seed):
    from .registry import generate as implementation
    return implementation(problem_id, seed)


def describe(problem_id):
    from .registry import describe as implementation
    return implementation(problem_id)


def solve(problem_id, parameters):
    from .registry import solve as implementation
    return implementation(problem_id, parameters)
