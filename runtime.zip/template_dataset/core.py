"""Exact, bounded and reproducible primitives for mathematical templates."""
from dataclasses import dataclass
from copy import deepcopy
from fractions import Fraction
from hashlib import sha256
import random
from typing import Callable, Optional

VERSION = '1.0.0'


@dataclass
class Template:
    family: str
    parameters: dict
    original: dict
    render: Callable
    solve: Callable
    sample: Callable
    validate: Callable
    constraints: list
    reference: Optional[Callable] = None
    adaptation: str = ''


def canonical_answer(value):
    """The source corpus's scalar rational contract, without float rounding."""
    if isinstance(value, bool) or not isinstance(value, (int, str, Fraction)):
        raise TypeError('Answers must be int, Fraction, or an exact rational string')
    return str(Fraction(value))


def _in_domain(value, domain):
    kind = domain.get('type', 'int')
    if kind in ('int', 'integer') and type(value) is not int:
        return False
    if kind in ('str', 'string') and type(value) is not str:
        return False
    if kind in ('rational', 'fraction'):
        if isinstance(value, bool) or not isinstance(value, (int, str, Fraction)):
            return False
        try: value = Fraction(value)
        except (ValueError, ZeroDivisionError): return False
    if kind.startswith('list'):
        if not isinstance(value, list): return False
        if len(value) < domain.get('min_length', 0) or len(value) > domain.get('max_length', 10000): return False
        item_domain = domain.get('items', {'type': 'int'})
        if not all(_in_domain(v, item_domain) for v in value): return False
        if 'choices' in domain and value not in domain['choices']: return False
        return True
    if 'choices' in domain and value not in domain['choices']: return False
    if 'min' in domain and value < domain['min']: return False
    if 'max' in domain and value > domain['max']: return False
    return True


def validate_parameters(template, parameters):
    if not isinstance(parameters, dict) or set(parameters) != set(template.parameters): return False
    try:
        return all(_in_domain(parameters[k], d) for k, d in template.parameters.items()) and bool(template.validate(parameters))
    except (ValueError, TypeError, KeyError, ZeroDivisionError, OverflowError, IndexError):
        return False


def instantiate(row, template, seed):
    if type(seed) is not int or not 0 <= seed < 2**64:
        raise ValueError('seed must be an integer in [0, 2**64 - 1]')
    digest = sha256(f'{VERSION}\0{row["id"]}\0{seed}'.encode()).digest()
    rng = random.Random(int.from_bytes(digest, 'big'))
    original_text = template.render(template.original)
    for _ in range(256):
        params = template.sample(rng)
        if not validate_parameters(template, params): continue
        text = template.render(params)
        if text == original_text: continue
        answer = canonical_answer(template.solve(params))
        return {'id': row['id'], 'split': row.get('split'), 'subject': row.get('subject'),
                'seed': seed, 'generator_version': VERSION, 'family': template.family,
                'parameters': params, 'problem': text, 'answer': answer,
                'source': deepcopy(row.get('source', {})), 'adaptation': template.adaptation}
    raise RuntimeError(f"Cannot sample a non-original valid instance for {row['id']} after 256 attempts")
