"""Gaussian integers and norms; exact source-bound mathematical models."""
from fractions import Fraction as F
from math import isqrt

from template_dataset.families.construction import is_square, sqrt_fraction
from template_dataset.families.intermediate_algebra.callable_bindings import I, bind, polynomial

S=I(-200,200)
P=I(1,1000)


def gaussian(x,y):
    return f'{x}{y:+}i'


def norm2(x,y):
    return x*x+y*y


def quad_norm2(a,b,c,x,y):
    return norm2(a*(x*x-y*y)+b*x+c,(2*a*x+b)*y)


def quad_sample(rng):
    a,x,y = rng.randint(1,5),rng.randint(-10,10),rng.choice([*range(-10,0),*range(1,11)])
    return a,-2*a*x,rng.randint(-100,100),x,y


def norm_quad_prompt(a,b,c,x,y):
    expression = polynomial([c,b,a], r'\omega')
    return rf'Evaluate $|{expression}|$ if $\omega={gaussian(x,y)}$.'


for key,values in [('r341',(1,6,58,9,2)),('t236',(1,2,-8,-1,4)),('t705',(2,-4,-30,1,-5))]:
    bind(key,'gaussian_quadratic_norm','a b c real imag',values,
         (I(1,15),S,I(-500,500),S,S), norm_quad_prompt,
         lambda *args:isqrt(quad_norm2(*args)), sample=quad_sample,
         valid=lambda *args:is_square(quad_norm2(*args)),
         constraints=('The squared complex norm is a perfect square.',))


def rational_modulus2(x,y,a,b,c,d):
    return F(norm2(a*x+b,a*y),norm2(c*x+d,c*y))


def rational_modulus_sample(rng):
    # Choose independent Pythagorean legs for numerator and denominator
    # scaled by the nonzero imaginary coordinate, then remove the chosen real parts.
    m,n = rng.randint(2,6),rng.randint(1,5)
    p,q = rng.randint(2,6),rng.randint(1,5)
    m,n = max(m,n+1),min(n,m-1)
    p,q = max(p,q+1),min(q,p-1)
    x=rng.randint(-4,4)
    y=rng.choice([-3,-2,-1,1,2,3])
    a,c=m*m-n*n,p*p-q*q
    return x,y,a,2*m*n*abs(y)-a*x,c,2*p*q*abs(y)-c*x


bind('t106','gaussian_linear_fraction_modulus','real imag a b c d',(1,1,3,1,5,7),
     (S,S,I(1,50),I(-400,400),I(1,50),I(-400,400)),
     lambda x,y,a,b,c,d:rf'Let $z={gaussian(x,y)}$ and $w=\dfrac{{{polynomial([b,a],"z")}}}{{{polynomial([d,c],"z")}}}$. Find $|w|$.',
     lambda *args:sqrt_fraction(rational_modulus2(*args)), sample=rational_modulus_sample,
     valid=lambda *args:is_square(rational_modulus2(*args)),
     constraints=('The denominator is nonzero and the squared modulus is a rational square.',))


def complex_ratio_imaginary(y,k):
    return F(y*(1+k*k),k)


def complex_ratio_sample(rng):
    k=rng.randint(1,30)
    return k*rng.randint(1,50),k


bind('t313','pure_imaginary_complex_fraction','imag multiplier',(164,4),
     (I(1,4000),I(1,60)),
     lambda y,k:rf'A complex number $z$ with imaginary part {y} and a positive integer $n$ satisfy $\frac{{z}}{{z+n}}={k}i$. Find $n$.',
     complex_ratio_imaginary, sample=complex_ratio_sample,
     valid=lambda y,k:y%k==0, constraints=('The given imaginary part is divisible by the multiplier.',))


def pythagorean(rng):
    m=rng.randint(2,15)
    n=rng.randint(1,m-1)
    return m*m-n*n,2*m*n


def dart_sample(rng):
    x,y=pythagorean(rng)
    a,b=pythagorean(rng)
    return (x,y,a,b) if x*x+y*y>=a*a+b*b else (a,b,x,y)


bind('t443','complex_dart_distance_difference','a b c d',(15,8,3,-4),
     (I(-500,500),)*4,
     lambda a,b,c,d:rf'Sasha and Chloe throw darts on a map of the complex plane, landing at $ {gaussian(a,b)}$ and $ {gaussian(c,d)}$ respectively. How much closer is Chloe’s dart to the origin?',
     lambda a,b,c,d:isqrt(norm2(a,b))-isqrt(norm2(c,d)),
     sample=dart_sample,valid=lambda a,b,c,d:norm2(a,b)>=norm2(c,d) and is_square(norm2(a,b)) and is_square(norm2(c,d)),
     constraints=('Both squared distances are integer squares. Chloe is no farther from the origin than Sasha.',))


bind('t460','complex_product_modulus','real imag norm_b',(21,-20,29),
     (I(-500,500),I(-500,500),P),
     lambda x,y,b:rf'Given $ab={gaussian(x,y)}$ and $|b|={b}$, find $|a|$.',
     lambda x,y,b:F(isqrt(norm2(x,y)),b),
     valid=lambda x,y,b:is_square(norm2(x,y)),sample=lambda r:(*pythagorean(r),r.randint(1,200)),
     constraints=('The squared norm of the product is an integer square.',))


def inverse_norm_sample(rng):
    x,y=pythagorean(rng)
    x*=rng.choice((-1,1))
    y*=rng.choice((-1,1))
    radius=rng.randint(1,500)
    witness=rng.randint(1,radius)
    return radius*radius-witness*witness,x,y,radius*isqrt(norm2(x,y))


bind('r1251','complex_modulus_product_positive_root','imag real_factor imag_factor target',
     (12,6,-4,26),(I(0,250000),I(-500,500),I(-500,500),I(1,1000000)),
     lambda b,x,y,c:rf'Find positive $t$ satisfying $|t+i\sqrt{{{b}}}|\,|{gaussian(x,y)}|={c}$.',
     lambda b,x,y,c:sqrt_fraction(F(c*c,norm2(x,y))-b),
     valid=lambda b,x,y,c:0<F(c*c,norm2(x,y))-b and is_square(F(c*c,norm2(x,y))-b),
     sample=inverse_norm_sample,
     constraints=('The known complex factor is nonzero, and the implied t squared is a positive rational square.',))


def imaginary_square_cube(a):
    return 3*a*a-2*a


bind('t650','equal_gaussian_imaginary_parts','real',(9,), (S,),
     lambda a:rf'Let $z={a}+bi$ with $b>0$. If $z^2$ and $z^3$ have equal imaginary parts, find $b$.',
     lambda a:isqrt(imaginary_square_cube(a)),
     valid=lambda a:imaginary_square_cube(a)>0 and is_square(imaginary_square_cube(a)),
     sample=lambda r:(r.choice([a for a in range(-200,201) if imaginary_square_cube(a)>0 and is_square(imaginary_square_cube(a))]),),
     constraints=('Three times the square of the real part minus twice the real part is a positive square.',))


def i_sum_prompt(n,k):
    return 'Evaluate $'+'+'.join(rf'i^{{{j}}}' for j in range(n,n+k))+'$.'


bind('r1043','consecutive_imaginary_power_sum','start length',(14762,4),(I(1,30000),I(2,16)),
     i_sum_prompt, lambda n,k:((k%4!=0)*(1 if n%4==0 else -1)) if k%4==1 else
     (0 if k%4==0 else (1 if (n+1)%4==0 else -1)),
     valid=lambda n,k:k%4==0 or (k%4 in (1,3) and n%2==(k%4==3)),
     reference=lambda n,k:sum((1,0,-1,0)[j%4] for j in range(n,n+k)),
     constraints=('The sum has zero imaginary part.',))


def unity_sum(n,k):
    counts=[sum(j%3==r for j in range(n,n+k)) for r in range(3)]
    if counts[1]!=counts[2]:
        raise ValueError('The sum depends on the chosen root')
    return counts[0]-counts[2]


bind('r987','consecutive_cube_unity_sum','start length',(97,5),(I(1,1000),I(4,100)),
     lambda n,k:rf'Let $z^2+z+1=0$. Compute $z^{{{n}}}+z^{{{n+1}}}+z^{{{n+2}}}+\cdots+z^{{{n+k-1}}}$.',
     unity_sum,
     valid=lambda n,k:k%3==0 or (k%3==1 and n%3==0) or (k%3==2 and n%3==1),
     constraints=('The counts of exponents congruent to 1 and 2 modulo 3 agree.',))


bind('t654','reciprocal_complex_cube','power',(3,),(I(3,150),),
     lambda n:rf'Let $z$ be a complex number such that $z+1/z=1$. Find $z^{{{n}}}$.',
     lambda n:(-1)**(n//3),valid=lambda n:n%3==0,
     sample=lambda r:(3*r.randint(1,50),),constraints=('The exponent is divisible by 3.',))


bind('t683','reciprocal_sum_ratio_cube','power',(3,),(I(3,150),),
     lambda n:rf'Compute $(r/s)^{{{n}}}$ if nonzero complex numbers $r,s$ satisfy $\frac1{{r+s}}=\frac1r+\frac1s$.',
     lambda n:1,valid=lambda n:n%3==0,sample=lambda r:(3*r.randint(1,50),),
     constraints=('The exponent is divisible by 3.',),
     adaptation='The variables are explicitly complex, as the original reciprocal equation has no real solutions.')


bind('r376','unit_circle_surd_power','imaginary_sign exponent',(1,6),(I(-1,1),I(6,240)),
     lambda s,n:rf'Let $z=(-\sqrt3{"+" if s>0 else "-"}i)/2$. Compute $z^{{{n}}}$.',
     lambda s,n:(-1)**(n//6),
     valid=lambda s,n:s!=0 and n%6==0,sample=lambda r:(r.choice([-1,1]),6*r.randint(1,40)),
     constraints=('The sign is ±1 and the exponent is a multiple of 6.',))


bind('r1065','complex_conjugate_quotient_modulus','p q',(3,4),(I(1,100),)*2,
     lambda p,q:rf'Let $z=\frac{{(-11+13i)^{{{p}}}(24-7i)^{{{q}}}}}{{3+4i}}$ and $w=\overline z/z$. Find $|w|$.',
     lambda p,q:1)
