"""Sums products and logarithms; exact source-bound mathematical models."""
from fractions import Fraction as F
from itertools import permutations
from math import comb, isqrt, prod

from template_dataset.families.intermediate_algebra.callable_bindings import I, bind, integers


def binomial_prompt(n):
    return rf'Find $\binom{{{n}}}{{0}}-\binom{{{n}}}{{1}}+\binom{{{n}}}{{2}}-\dots+(-1)^{{{n}}}\binom{{{n}}}{{{n}}}$.'


bind('r1185', 'alternating_binomial_sum', 'n', (100,), (I(3,300),),
     binomial_prompt, lambda n: 0,
     reference=lambda n: sum((-1)**k*comb(n,k) for k in range(n+1)))


def factorial_product(a,b):
    def side(k,n):
        return rf'(1+{k})\left(1+\frac{{{k}}}{{2}}\right)\left(1+\frac{{{k}}}{{3}}\right)\dotsm\left(1+\frac{{{k}}}{{{n}}}\right)'
    return rf'Compute $\frac{{{side(a,b)}}}{{{side(b,a)}}}$.'


bind('r468', 'symmetric_factorial_products', 'a b', (17,19), (I(4,200),)*2,
     factorial_product, lambda a,b: 1,
     reference=lambda a,b: prod(F(a+k,k) for k in range(1,b+1)) /
     prod(F(b+k,k) for k in range(1,a+1)))


def squares_product(n):
    def side(k):
        return rf'({k}^2-{n-2}^2)({k}^2-{n-3}^2)\dotsm({k}^2-0^2)'
    return rf'Compute $\frac{{{side(n)}}}{{{side(n-1)}}}$.'


bind('t306', 'consecutive_square_product', 'n', (1998,), (I(4,3000),),
     squares_product, lambda n: 2*n,
     reference=lambda n: F(prod(n*n-k*k for k in range(n-1)),
                           prod((n-1)**2-k*k for k in range(n-1))))


bind('r488', 'reciprocal_geometric_double_sum', 'start', (2,), (I(2,100),),
     lambda start: rf'For integers $n\ge2$, let $f(n)=\frac{{1}}{{{start}^n}}+\frac{{1}}{{{start+1}^n}}+\frac{{1}}{{{start+2}^n}}+\dotsb$. Find $\sum_{{n=2}}^\infty f(n)$.',
     lambda start: F(1,start-1),
     adaptation='The definition explicitly starts at n=2, where the series converges.')


bind('r933', 'dyadic_telescope', 'base', (2,), (I(2,500),),
     lambda b: 'Find the sum $'+' + '.join(rf'\frac{{{b}^{k}}}{{{b*b}^{k}-1}}' for k in (1,2,4,8))+r'+\cdots$.',
     lambda b: F(1,b-1))


def alternating_product(b,n):
    def term(k):
        return rf'\frac{{1}}{{{b**k}}}' if k%2 else rf'\frac{{{b**k}}}{{1}}'
    return 'What is the value of $'+r'\cdot'.join([*(term(k) for k in range(1,5)),r'\dotsm',term(n-1),term(n)])+'$?'


def power_product_answer(b,n):
    return F(b**(n//2)) if n%2==0 else F(1,b**(n//2+1))


bind('r1018', 'alternating_power_product', 'base n', (2,10), (I(2,8),I(7,30)),
     alternating_product, power_product_answer,
     reference=lambda b,n: prod(F(b)**(k*(-1)**k) for k in range(1,n+1)))


bind('t66', 'telescope_linear_product', 'base n', (2,9), (I(2,12),I(5,100)),
     lambda m,n: 'Find the product $'+str(n+1)+rf'\cdot\frac{{{2*m}}}{{3}}\cdot\frac{{{3*m}}}{{4}}\cdots\frac{{{n*m}}}{{{n+1}}}$.',
     lambda m,n: 2*m**(n-1),
     reference=lambda m,n: (n+1)*prod(F(m*k,k+1) for k in range(2,n+1)))


bind('t5', 'power_sum_quotient_floor', 'a b n k', (3,2,100,4),
     (I(2,20),I(1,20),I(3,150),I(1,12)),
     lambda a,b,n,k:rf'Find the floor of $\frac{{{a}^{{{n}}}+{b}^{{{n}}}}}{{{a}^{{{n-k}}}+{b}^{{{n-k}}}}}$.',
     lambda a,b,n,k: (a**n+b**n)//(a**(n-k)+b**(n-k)),
     valid=lambda a,b,n,k:n>k, constraints=('n > k.',))


bind('r642', 'reciprocal_power_square_difference', 'base exponent', (2001,1002),
     (I(2,3000),I(1,2000)),
     lambda b,n:rf'Let $x={b}^{{{n}}}-{b}^{{-{n}}}$ and $y={b}^{{{n}}}+{b}^{{-{n}}}$. Find $x^2-y^2$.',
     lambda b,n:-4,
     reference=lambda b,n:(F(b**n)-F(1,b**n))**2-(F(b**n)+F(1,b**n))**2)


bind('r736', 'reciprocal_log_exponents', 'a_base b_base power', (3,4,2),
     (I(2,50),I(2,50),I(1,8)),
     lambda a,b,m:rf'If $a=\log {a**m}$ and $b=\log {b**m}$, compute $' + rf'{b}^{{a/b}}+{a}^{{b/a}}$.',
     lambda a,b,m:a+b)


def reciprocal_log_sum(a,b,c):
    return r'Simplify $'+'+'.join(rf'\frac{{1}}{{\log_{{{x*y}}}{z}+1}}'
                                  for x,y,z in ((b,c,a),(a,c,b),(a,b,c)))+'$.'


bind('r974', 'complementary_log_bases', 'a b c', (2,3,5), (I(2,80),)*3,
     reciprocal_log_sum, lambda a,b,c:2)


def triplet_max(n):
    triples = ((a,b,n//(a*b)) for a in range(1,isqrt(n)+1) if n%a==0 and a**3<n
               for b in range(a+1,1+isqrt(n//a)) if n%(a*b)==0 and b<n//(a*b))
    return max((a+b+c for a,b,c in triples), default=0)


bind('r869', 'distinct_factor_triple_maximum', 'year', (2001,), (I(6,20000),),
     lambda n: rf'Let $I,M,O$ be distinct positive integers with $IMO={n}$. What is the greatest possible value of $I+M+O$?',
     triplet_max, valid=lambda n:bool(triplet_max(n)),
     sample=lambda rng:(rng.randint(2,12)*rng.randint(13,1000),),
     constraints=('The target has a factorization into three distinct positive integers.',),
     adaptation='The historical introduction is omitted from the generated statement.')


bind('t47', 'integer_product_sum_inequality', 'upper', (1000,), (I(1,1000000),),
     lambda u: rf'For how many positive integers $m\le {u}$ is there at least one positive integer $n$ with $mn\le m+n$?',
     lambda u:u)


def weighted_cycle(values):
    return max((a+c)*(b+d) for a,b,c,d in permutations(values))


bind('r1042', 'maximize_four_cycle_product_sum', 'values', ([1,2,3,4],),
     (integers(4,-50,100),),
     lambda values: r'The values of $a,b,c,d$ are $' + ','.join(map(str,values)) + r'$ in some order. Find the largest possible value of $ab+bc+cd+da$.',
     weighted_cycle,
     reference=lambda values:max(a*b+b*c+c*d+d*a for a,b,c,d in permutations(values)))


bind('t718', 'distinct_integer_vieta_maximum', 'minimum maximum', (0,9),
     (I(-30,20),I(2,80)),
     lambda a,b: rf'Let $a,b,c$ be distinct integers from $ {a}$ through $ {b}$ inclusive. What is the maximum value of the sum of the roots of $(x-a)(x-b)+(x-b)(x-c)=0$?',
     lambda lo,hi:F(4*hi-3,2), valid=lambda lo,hi: hi-lo>=2,
     sample=lambda rng:(lo:=rng.randint(-30,20),rng.randint(max(lo+2,2),80)),
     constraints=('The interval contains at least three integers.',),
     reference=lambda lo,hi:max(F(a+2*b+c,2) for a,b,c in permutations(range(max(lo,hi-3),hi+1),3)))


def log_bases_sample(rng):
    c,d,k = (rng.randint(2,25) for _ in range(3))
    return c*d*k*k,c,d


bind('r992', 'nested_log_base_change', 'base first second', (60,3,5),
     (I(4,400000),I(2,100),I(2,100)),
     lambda b,c,d:rf'If $ {b}^a={c}$ and $ {b}^b={d}$, find $\left({b//d}\right)^{{(1-a-b)/(2(1-b))}}$.',
     lambda b,c,d:isqrt(b//(c*d)), sample=log_bases_sample,
     valid=lambda b,c,d:b%(c*d)==0 and b>c*d and isqrt(b//(c*d))**2==b//(c*d),
     constraints=('The base is the product of first, second and an integer square greater than one.',))


def ticket_winners(a,b,total):
    values = [F(x,(total-a*x)//b) for x in range(1,(total-b)//a+1) if (total-a*x)%b==0]
    distance = min((abs(q-1) for q in values), default=None)
    return [q for q in values if abs(q-1)==distance]


def ticket_sample(rng):
    a,b = rng.sample(range(5,80),2)
    x,y = rng.randint(5,120),rng.randint(5,120)
    return a,b,a*x+b*y


bind('r583', 'admission_ratio_closest_to_one', 'adult child total', (25,12,1950),
     (I(1,100),I(1,100),I(2,20000)),
     lambda a,b,t: rf'Admission costs {a} dollars per adult and {b} dollars per child. The receipts were {t} dollars with at least one adult and one child admitted. Which possible adult-to-child ratio is closest to $1$?',
     lambda a,b,t:ticket_winners(a,b,t)[0],
     valid=lambda a,b,t:len(ticket_winners(a,b,t))==1, sample=ticket_sample,
     constraints=('At least one positive count pair exists, and the distance-minimizing ratio is unique.',))


bind('t320', 'dyadic_complement_roster', 'elite', (19,), (I(0,10000),),
     lambda m:rf'For a competition with $N>1$ players, $2^{{1+\lfloor\log_2(N-1)\rfloor}}-N$ players are given elite status. If {m} players receive elite status, find the sum of the two smallest possible values of $N$.',
     lambda m:6*(1<<m.bit_length())-2*m,
     reference=lambda m:sum([n for n in range(2,8*(m+2)) if (1<<(n-1).bit_length())-n==m][:2]))


bind('t769', 'backward_lottery_spending', 'shops multiplier cost', (10,2,1024),
     (I(2,30),I(2,10),I(1,10000)),
     lambda n,k,c: rf'Stacy begins with $d$ dollars. She visits {n} shops, multiplying her money by {k} at a lottery before each visit and then spending {c} dollars at the shop. She always wins and leaves the last shop with zero dollars. What is the minimum possible $d$?',
     lambda n,k,c:F(c,k-1)*(1-F(1,k**n)),
     reference=lambda n,k,c:sum(F(c,k**j) for j in range(1,n+1)))


def geometric_sample(rng):
    k,d = rng.randint(2,15),rng.randint(1,4)
    return rng.randint(1,80),rng.randint(1,80),k+d,k,1+d*rng.randint(1,5)


bind('t830', 'coupled_geometric_sequences', 'first_a first_b index_a index_b target',
     (27,99,15,11,9), (I(1,100),I(1,100),I(2,30),I(1,30),I(2,30)),
     lambda a,b,n,k,j:rf'Two geometric sequences $(a_m)$ and $(b_m)$ share a nonzero common ratio. If $a_1={a}$, $b_1={b}$ and $a_{{{n}}}=b_{{{k}}}$, find $a_{{{j}}}$.',
     lambda a,b,n,k,j:a*F(b,a)**((j-1)//(n-k)),
     sample=geometric_sample, valid=lambda a,b,n,k,j:n!=k and (j-1)%(n-k)==0,
     constraints=('The equality indices differ, and target minus one is a multiple of their difference.',))


def recurrence_period(a,b):
    return (a,b,b-a,-a,-b,a-b)


def recurrence_solve(n,m,k,s,t):
    def coeff(index):
        return sum(recurrence_period(1,0)[:index%6]),sum(recurrence_period(0,1)[:index%6])
    a,b=coeff(n)
    c,d=coeff(m)
    det=a*d-b*c
    first,second=F(s*d-b*t,det),F(a*t-s*c,det)
    if first.denominator!=1 or second.denominator!=1:
        raise ValueError('Integer terms required')
    return sum(recurrence_period(first,second)[:k%6])


def recurrence_valid(*args):
    try:
        recurrence_solve(*args)
    except (ValueError, ZeroDivisionError):
        return False
    return True


def recurrence_sample(rng):
    n,m,k = 6*rng.randint(1,400)+4,6*rng.randint(1,400)+5,rng.randint(1,2500)
    a,b = rng.randint(-1000,1000),rng.randint(-1000,1000)
    values = recurrence_period(a,b)
    return n,m,k,sum(values[:n%6]),sum(values[:m%6])


bind('r435', 'periodic_difference_partial_sum', 'index_a index_b target sum_a sum_b',
     (1492,1985,2001,1985,1492), (I(1,2500),)*3+(I(-10000,10000),)*2,
     lambda n,m,k,s,t: rf'An integer sequence satisfies $a_j=a_{{j-1}}-a_{{j-2}}$ for $j\ge3$. The sums of its first {n} and {m} terms are {s} and {t}, respectively. What is the sum of its first {k} terms?',
     recurrence_solve, valid=recurrence_valid, sample=recurrence_sample,
     constraints=('The two given sums determine unique integer initial terms.',))


def modular_recurrence(a,b,c,k,m,i,j,l):
    seq=[a,b,c]
    for n in range(3,1+max(i,j,l)):
        seq.append(k*sum(seq[-3:])%m)
    return seq[i]*seq[j]*seq[l]


bind('t609', 'three_term_modular_recurrence', 'a b c multiplier modulus i j l',
     (2,5,8,4,11,2018,2020,2022), (I(0,60),)*3+(I(1,20),I(2,61))+(I(3,3000),)*3,
     lambda a,b,c,k,m,i,j,l: rf'Let $a_0={a}$, $a_1={b}$ and $a_2={c}$. For $n>2$, let $a_n$ be the remainder when $ {k}(a_{{n-1}}+a_{{n-2}}+a_{{n-3}})$ is divided by {m}. Find $a_{{{i}}}a_{{{j}}}a_{{{l}}}$.',
     modular_recurrence)


def conjugate_power(a,b,n):
    r,s = 1,0
    for _ in range(n):
        r,s=(a+b)*r+2*a*b*s,2*r+(a+b)*s
    radical = a*b*s*s
    return r+isqrt(radical)-(isqrt(radical)**2==radical)


bind('t736', 'strict_floor_of_binomial_surd', 'a b half_power', (7,5,3),
     (I(1,100),I(1,100),I(1,12)),
     lambda a,b,n: rf'Find the greatest integer strictly less than $(\sqrt{{{a}}}+\sqrt{{{b}}})^{{{2*n}}}$. Do not use a calculator.',
     conjugate_power,
     reference=lambda a,b,n: sum(comb(2*n,k)*a**(n-k//2)*b**(k//2) for k in range(0,2*n+1,2))
     + (lambda u:isqrt(u)-(isqrt(u)**2==u))(a*b*sum(
         comb(2*n,k)*a**(n-(k+1)//2)*b**((k-1)//2) for k in range(1,2*n,2))**2))
