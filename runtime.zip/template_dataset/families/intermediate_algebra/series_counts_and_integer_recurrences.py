"""Series counts and integer recurrences; exact source-bound mathematical models."""
from fractions import Fraction as F
from itertools import product
from math import comb, gcd, isqrt

from template_dataset.families.algebra.real_roots import divisors
from template_dataset.families.construction import choice
from template_dataset.families.intermediate_algebra.callable_bindings import I, bind, integers, tex


bind('r112','minimum_of_reciprocal_products','variables bound',(3,1), (I(2,30),I(1,100)),
     lambda n,a:rf'For real $-{a}<x_i<{a}$ with $i=1,\ldots,{n}$, find the minimum of $\frac{{1}}{{\prod_{{i=1}}^{{{n}}}({a}-x_i)}}+\frac{{1}}{{\prod_{{i=1}}^{{{n}}}({a}+x_i)}}$.',
     lambda n,a:F(2,a**n))

bind('r182','quadratic_support_functional_equation','coefficient',(4,),(I(1,200),),
     lambda c:rf'How many functions $f:\mathbb R\to\mathbb R$ satisfy $f(x+y)f(x-y)=(f(x)+f(y))^2-{c}x^2 f(y)$ for all real $x,y$?',
     lambda c:2)


def weighted_multiplicative_inequality(a,b,c):
    rhs=tex(F((a+b)**2,4*c))
    return rf'How many real functions on $\mathbb R$ satisfy $ {a}f(xy)+{b}f(xz)-{c}f(x)f(yz)\ge {rhs}$ for all real $x,y,z$?'


bind('r387','functional_inequality_at_quadratic_peak','a b c',(1,1,1),(I(1,30),)*3,
     weighted_multiplicative_inequality,lambda a,b,c:1)


def boolean_inequalities(signs):
    names=(('1/a','1/b'),('a^2','b^2'),('a','b'),('a','0'),('b','0'))
    statements=', '.join('$'+l+('<' if s==0 else '>')+r+'$' for (l,r),s in zip(names,signs))
    return f'For nonzero real a and b, consider {statements}. What is the maximum number that can be true simultaneously?'


def max_boolean_inequalities(signs):
    scores=[]
    for a,b in product((-2,-1,1,2),repeat=2):
        differences=(F(1,a)-F(1,b),a*a-b*b,a-b,a,b)
        scores.append(sum((delta>0 if s else delta<0) for s,delta in zip(signs,differences)))
    return max(scores)


bind('r304','maximum_compatible_strict_inequalities','directions',([0,1,0,0,0],),
     (integers(5,0,1),),boolean_inequalities,max_boolean_inequalities,
     adaptation='The variables are explicitly nonzero so that all five statements are defined.')


bind('r611','maximum_compatible_quadratic_inequalities','bound',(1,), (I(-40,40),),
     lambda k:rf'For real $x$, what is the maximum number of these five statements that can hold simultaneously? $0<x^2<1$, $x^2>1$, $-1<x<0$, $0<x<1$, and $0<x-x^2<{k}$.',
     lambda k:2+int(k>0))


def geometric_order_minimum(p,q):
    g=gcd(p,q)
    return (p+q)*q//(g*g)


bind('r726','arithmetic_spacings_and_geometric_permutation','first_gap second_gap',(1,1),
     (I(1,80),)*2,
     lambda p,q:rf'Let $a<b<c$ be integers in an arithmetic progression at index gaps {p} and {q}, respectively, so $(b-a)/{p}=(c-b)/{q}$. If $a,c,b$ is a geometric progression, what is the smallest possible value of $c$?',
     geometric_order_minimum,
     adaptation='Consecutive arithmetic terms are generalized to selected terms at prescribed positive index gaps.')


def longest_trajectory(first):
    # Intersect integer intervals for the successive nonnegative terms.
    lo,hi=1,first
    previous,current=(first,0),(0,1)
    for _ in range(3,65):
        const=previous[0]-current[0]
        slope=previous[1]-current[1]
        new_lo=max(lo,-(const//slope)) if slope>0 else lo
        new_hi=min(hi,const//(-slope)) if slope<0 else hi
        if new_lo>new_hi:
            return lo if lo==hi else None
        lo,hi=new_lo,new_hi
        previous,current=current,(const,slope)
    return None


bind('r1045','longest_positive_difference_recurrence','first',(1000,), (I(2,50000),),
     lambda a:rf'After the first two terms of $ {a},x,{a}-x,\ldots$, each term is the term two places before it minus the preceding term. The sequence ends at its first negative term. Which positive integer $x$ gives the longest sequence?',
     longest_trajectory,valid=lambda a:longest_trajectory(a) is not None,
     constraints=('The nonnegative prefix constraints become infeasible by term 64, with a unique longest trajectory.',))


def ap_gp(n,r):
    q,k=divmod(n,2)
    if k:
        return (1+q*(r-1))**2
    return (1+(q-1)*(r-1))*(1+q*(r-1))


def determine_ratio(index,total):
    for r in range(2,101):
        if ap_gp(index,r)+ap_gp(index+1,r)==total:
            return r
    raise ValueError('Expected an integral second term in [2,100]')


def alternating_ap_gp(index,total,cutoff):
    r=determine_ratio(index,total)
    lo,hi=1,2*isqrt(cutoff)+4
    while hi-lo>1:
        mid=(lo+hi)//2
        if ap_gp(mid,r)<cutoff:
            lo=mid
        else:
            hi=mid
    return lo+ap_gp(lo,r)


def alternating_ap_gp_valid(index,total,cutoff):
    try:
        determine_ratio(index,total)
    except ValueError:
        return False
    return True


def alternating_ap_gp_sample(rng):
    i,r=rng.randint(2,30),rng.randint(2,25)
    return i,ap_gp(i,r)+ap_gp(i+1,r),rng.randint(20,1000000)


bind('t241','alternating_arithmetic_and_geometric_triplets','index total cutoff',(9,646,1000),
     (I(2,50),I(5,10000000),I(2,1000000)),
     lambda i,s,k:rf'In a positive integer sequence $a_1=1$ and $a_{{{i}}}+a_{{{i+1}}}={s}$. For each $j\ge1$, $(a_{{2j-1}},a_{{2j}},a_{{2j+1}})$ is geometric and $(a_{{2j}},a_{{2j+1}},a_{{2j+2}})$ is arithmetic. If $a_n$ is the greatest term less than {k}, find $n+a_n$.',
     alternating_ap_gp,valid=alternating_ap_gp_valid,sample=alternating_ap_gp_sample,
     constraints=('The given adjacent sum is attained by a second term in [2,100], so the sequence is strictly increasing.',))


def binomial_terms_exponent(a,b,c):
    if a*c==0:
        return None
    ratio=F(b*b,a*c)
    if ratio<=F(4,3):
        return None
    n=(9*ratio-8)/(3*ratio-4)
    return n if n.denominator==1 and n>=4 else None


def binomial_terms_sample(rng):
    n,x,a=rng.randint(4,13),rng.randint(1,4),rng.randint(1,4)
    return tuple(comb(n,k)*x**(n-k)*a**k for k in (2,3,4))


bind('r448','exponent_from_three_binomial_terms','third fourth fifth',(84,280,560),
     (I(1,10**11),)*3,
     lambda a,b,c:rf'For some constants $x,a$, the third, fourth and fifth terms of the binomial expansion of $(x+a)^n$ are {a}, {b} and {c}, respectively. Find $n$.',
     binomial_terms_exponent,
     valid=lambda a,b,c:binomial_terms_exponent(a,b,c) is not None,
     sample=binomial_terms_sample,
     constraints=('The term ratio fourth²/(third·fifth) determines an integer exponent n≥4.',))


def odd_even_sums(k):
    N=4*k-1
    return sum((N//d-d-2)//4 for d in divisors(N) if d*d<N
               and (N//d-d-2)%4==0 and (N//d+d)%4==0 and N//d-d>2)


bind('t352','difference_of_odd_and_even_prefix_sums','difference',(212,), (I(2,20000),),
     lambda k:rf'The sum of the first $m$ positive odd integers exceeds the sum of the first $n$ positive even integers by {k}. What is the sum of all possible positive values of $n$?',
     odd_even_sums)


def repeating_prompt(b,d,i):
    runs=['0'*k+str(d)*7+r'\ldots' for k in range(5)]
    notation='' if b==10 else f'All displayed numbers are in base {b}. '
    rows=[f'{i}.{runs[0]}',*(f'0.{s}' for s in runs)]
    return notation+'Find the sum as a common fraction: $'+ '+'.join(rows)+r'+\cdots$, where each successive row after the second has one more leading zero after the point.'


bind('t745','sum_of_shifted_repeating_digits','base digit integer_part',(10,1,1),
     (I(2,10),I(1,9),I(0,9)),repeating_prompt,
     lambda b,d,i:i+F(d,b-1)*(1+F(b,b-1)),
     sample=lambda r:(b:=r.randint(2,10),r.randint(1,b-1),r.randint(0,b-1)),
     valid=lambda b,d,i:d<b and i<b,
     constraints=('Both displayed digits are legal in the indicated base.',))


bind('t290','cubic_and_quadratic_division_with_shared_unknowns','constant_multiplier',(1,), (I(1,100),),
     lambda k:rf'The polynomial $ax^3+bx-{k}c$ is divisible by $x^2+bx+c$, where $a,b,c$ are nonzero reals. Find $ab$.',
     lambda k:k)


bind('t656','count_square_root_domain_equals_range','constant',(0,), (I(-100,100),),
     lambda c:rf'Let $f(x)=\sqrt{{ax^2+bx{c:+}}}$. For how many real values of $a$ is there a positive $b$ for which the real domain of $f$ is nonempty and equals its range?',
     lambda c:2 if c==0 else 0,
     adaptation='The real domain must be nonempty, which already holds in the source case c=0.')


bind('t70','weighted_sine_addition_maximum','a b',(1,1),(I(1,100),)*2,
     lambda a,b:rf'Find the maximum of $ {a}x\sqrt{{1-y^2}}+{b}y\sqrt{{1-x^2}}$ for $-1\le x,y\le1$.',
     max)


bind('t335','minimum_product_of_pairwise_sum_ratios','variables',(3,), (I(3,19),),
     lambda n:(r'For positive $a,b,c$, find the minimum of $(a+b)(a+c)(b+c)/(abc)$.' if n==3 else
       rf'For positive $a_1,\ldots,a_{{{n}}}$, find the minimum of $\frac{{\prod_{{1\le i<j\le {n}}}(a_i+a_j)}}{{(\prod_{{i=1}}^{{{n}}}a_i)^{{{(n-1)//2}}}}}$.'),
     lambda n:2**comb(n,2),valid=lambda n:n%2==1,
     sample=lambda r:(r.randrange(3,20,2),),constraints=('The number of variables is odd.',))


def inequality_integer_candidates(lo,hi):
    lo,hi=F(lo),F(hi)
    if not 1<lo<hi:
        return []
    lower,upper=-1-F(2,lo-1),-1-F(2,hi-1)
    start,stop=lower//1+1,-((-upper)//1)
    return [start] if stop-start==1 else []


def inequality_integer_sample(rng):
    r=rng.randint(-99,-2)
    q=F(r-1,r+1)
    lo=(q+F(r-2,r))/2
    hi=q+1 if r==-2 else (q+F(r,r+2))/2
    return str(lo),str(hi)


bind('r877','integer_ratio_from_mobius_interval','lower upper',(2,5),
     ({'type':'rational','min':1,'max':20},)*2,
     lambda a,b:rf'Let $x,y$ be real numbers such that $ {tex(a)}<\frac{{x-y}}{{x+y}}<{tex(b)}$. If $x/y$ is an integer, find it.',
     lambda a,b:inequality_integer_candidates(a,b)[0],
     sample=inequality_integer_sample,
     valid=lambda a,b:0<len(inequality_integer_candidates(a,b))==1,
     constraints=('The endpoints exceed 1 and the transformed strict interval contains exactly one integer.',))


def exponent_pair_valid(b,a,c):
    p=b.bit_length()-1
    return b==2**p and p*c*c==4*a


def exponent_pair_sample(rng):
    p,c=rng.randint(1,10),2*rng.randint(1,18)
    return 2**p,p*c*c//4,c


bind('r976','equality_at_minimum_of_two_exponential_terms','base quadratic linear',(16,1,1),
     (I(2,1024),I(1,4000),I(1,40)),
     lambda b,a,c:rf'How many real ordered pairs $(x,y)$ satisfy $ {b}^{{{a}x^2+{c}y}}+{b}^{{{c}x+{a}y^2}}=1$?',
     lambda b,a,c:1,valid=exponent_pair_valid,sample=exponent_pair_sample,
     constraints=('The base is 2^p for a positive integer p and p·linear²=4·quadratic.',))


def sixth_power_coefficients(a,b):
    u,v=isqrt(isqrt(a)),isqrt(isqrt(b))
    # Sixth roots by bounded integer search.
    return next(x for x in range(1,u+1) if x**6==a),next(x for x in range(1,v+1) if x**6==b)


def sixth_power_valid(a,b):
    u=next((x for x in range(1,51) if x**6==a),0)
    v=next((x for x in range(1,51) if x**6==b),0)
    return bool(u and v and gcd(u,v)==1)


def sixth_power_sample(rng):
    a,b=rng.randint(2,50),rng.randint(2,50)
    return a**6,b**6


bind('r534','sum_of_coefficients_of_binary_sextic_factors','x_coefficient y_coefficient',(64,729),
     (I(1,50**6),)*2,
     lambda a,b:rf'Factor $ {a}x^6-{b}y^6$ as $(ax+by)(cx^2+dxy+ey^2)(fx+gy)(hx^2+jxy+ky^2)$ with integer coefficients and $a,c,f,h>0$. Find the sum of the ten factor coefficients.',
     lambda a,b:(lambda u,v:2*u+2*u*u+2*v*v)(*sixth_power_coefficients(a,b)),
     valid=sixth_power_valid,sample=sixth_power_sample,
     constraints=('The two positive coefficients are sixth powers of coprime positive integers at most 50.',))


def cube_gap_candidates(a,b,c):
    # For positive t, ratios (t+s)/(t+a+b+c) increase strictly with t.
    for t in range(1,1501):
        if t**3+(t+a)**3+(t+a+b)**3==(t+a+b+c)**3:
            return t+a+b+c
    return None


_CUBE_GAPS=[(1,1,1),(5,2,1),(7,8,1),(2,2,2)]


def cube_gaps_sample(rng):
    a,b,c=rng.choice(_CUBE_GAPS)
    s=rng.randint(1,15)
    return a*s,b*s,c*s


bind('r1254','ordered_positive_cube_sum_with_root_gaps','first second third',(1,1,1),
     (I(1,150),)*3,
     lambda a,b,c:rf'Positive perfect cubes $w^3<x^3<y^3<z^3$ satisfy $w^3+x^3+y^3=z^3$, with $x-w={a}$, $y-x={b}$, and $z-y={c}$. What is the smallest possible value of $z$?',
     cube_gap_candidates,valid=lambda a,b,c:cube_gap_candidates(a,b,c) is not None,
     sample=cube_gaps_sample,
     constraints=('A positive integer w at most 1500 satisfies the cubic relation; it is unique by monotonicity.',),
     adaptation='Consecutive positive cubes are generalized to positive cubes with given consecutive differences between their cube roots.')

_CODOMAINS=(r'\mathbb R',r'[0,\infty)',r'(-\infty,0]',r'(0,\infty)',r'(-\infty,0)',r'\mathbb R\setminus\{0\}')
bind('t146','count_even_and_odd_functions_by_codomain','codomain',(_CODOMAINS[0],),
     (choice(_CODOMAINS),),
     lambda s:rf'How many functions with domain $\mathbb R$ and codomain $ {s}$ are both even and odd?',
     lambda s:int(s in _CODOMAINS[:3]),
     adaptation='The source’s implicit real codomain is stated explicitly and varied.')
