"""Real equations and sequence constraints; exact source-bound mathematical models."""
from fractions import Fraction as F
from math import isqrt

from template_dataset.families.construction import is_square, sqrt_fraction
from template_dataset.families.intermediate_algebra.callable_bindings import I, bind


def nth_floor(v,p):
    lo,hi=0,1
    while hi**p<=v:
        hi*=2
    while hi-lo>1:
        mid=(lo+hi)//2
        if mid**p<=v:
            lo=mid
        else:
            hi=mid
    return lo


def continued_log_root(base,offset):
    # b^k−k increases strictly for positive integer k.
    for k in range(1,31):
        if base**k-k==offset:
            return k
    raise ValueError('No positive integer solution in the stated range')


def continued_log_valid(b,c):
    try:
        continued_log_root(b,c)
    except ValueError:
        return False
    return True


bind('r302','positive_infinite_log_fixed_point','base offset',(2,27),
     (I(2,10),I(2,1000000)),
     lambda b,c:rf'Determine $\log_{{{b}}}({c}+\log_{{{b}}}({c}+\log_{{{b}}}({c}+\cdots)))$, assuming it is positive.',
     continued_log_root,valid=continued_log_valid,
     sample=lambda r:(b:=r.randint(2,10),b**(k:=r.randint(2,6))-k),
     constraints=('The offset equals base^k−k for a positive integer k at most 30.',))


def ordered_operation(a,n):
    return rf'For $a*b=(a-b)/(1-ab)$, compute $1*({a}*({a+1}*(\dotsb*({n-1}*{n})\dotsb)))$.'


bind('r200','nested_fractional_difference','second last',(2,1000),
     (I(2,80),I(5,2000)),ordered_operation,lambda a,n:1,
     valid=lambda a,n:n>=a+3, sample=lambda r:(a:=r.randint(2,80),r.randint(a+3,2000)),
     constraints=('The consecutive integer block after 1 has at least four terms.',),
     reference=lambda a,n:_literal_operation(a,n))


def _literal_operation(a,n):
    out=F(n)
    for k in range(n-1,a-1,-1):
        out=(k-out)/(1-k*out)
    return (1-out)/(1-out)


def progression_sums(gap):
    values=[]
    for d in range(1,gap//3+1):
        k=gap-3*d
        if 0<k<d and d*d%k==0:
            first=d*d//k-d
            values.append(4*first+6*d+k)
    return values


_VALID_GAPS=tuple(gap for gap in range(7,600) if len(progression_sums(gap))==1)


bind('r168','arithmetic_then_geometric_four_terms','gap',(30,),(I(7,2000),),
     lambda d:rf'An increasing sequence of four positive integers starts with three terms in arithmetic progression and ends with three in geometric progression. The first and last terms differ by {d}. Find the sum of the four terms.',
     lambda d:progression_sums(d)[0],
     valid=lambda d:len(progression_sums(d))==1,sample=lambda r:(r.choice(_VALID_GAPS),),
     constraints=('The gap admits exactly one increasing sequence of four positive integers of the required form.',))


def squared_progression(a,b,c):
    d=sqrt_fraction(F(c-2*b+a,2))
    first=F(b-a-d*d,2*d)
    return first*first-a


def squared_progression_valid(a,b,c):
    return a<b<c and is_square(F(c-2*b+a,2)) and c-2*b+a>0 and squared_progression(a,b,c).denominator==1


def squared_progression_sample(rng):
    a,d,k=rng.randint(1,100),rng.randint(1,30),rng.randint(-200,500)
    return tuple((a+d*j)**2-k for j in range(3))


bind('r503','translate_to_squares_of_arithmetic_progression','a b c',(36,300,596),
     (I(-1000,30000),)*3,
     lambda a,b,c:rf'Adding the integer $k$ to {a}, {b}, and {c}, respectively, gives squares of three consecutive terms of an arithmetic progression in that order. Find $k$.',
     squared_progression, valid=squared_progression_valid, sample=squared_progression_sample,
     constraints=('The three givens increase. Half their second difference is a positive rational square and the implied shift is integral.',))


def ap_product_count(a):
    # (a+d)(a+2d)=a+3d.
    discriminant=(3*a-3)**2-8*(a*a-a)
    return 2 if discriminant>0 else int(discriminant==0)


bind('r516','arithmetic_progression_ending_in_product','first',(10,),(I(-1000,1000),),
     lambda k:rf'How many pairs $(a,b)$ of real numbers make $ {k},a,b,ab$ an arithmetic progression?',
     ap_product_count)


def integer_quadratic_count(c,n):
    # b >= ceil(j+c/j) for an integer root candidate x=-j, j>=1.
    limit=c+n+1
    thresholds=sorted(j+(c+j-1)//j for j in range(1,limit+1))
    return 2*(thresholds[n]-thresholds[n-1])


bind('r694','linear_coefficient_given_integer_sublevel_count','constant count',(2,3),
     (I(1,3000),I(1,60)),
     lambda c,n:rf'There are exactly {n} integers $x$ satisfying $x^2+bx+{c}\le0$. How many integer values of $b$ are possible?',
     integer_quadratic_count,
     reference=lambda c,n:quadratic_count_reference(c,n))


def quadratic_count_reference(c,n):
    out=0
    for b in range(1,c+n+2):
        if b*b<4*c:
            continue
        s=isqrt(b*b-4*c)
        # Integer j satisfy |2j−b| ≤ floor(sqrt(b²−4c)).
        out+= (b+s)//2-(b-s+1)//2+1==n
    return 2*out


def cubic_norm_constant(k):
    return nth_floor(k,3)**2


bind('r884','least_norm_under_symmetric_cubic','rhs',(1,), (I(1,1000000),),
     lambda k:rf'For real $x,y,z$ with $x^3+y^3+z^3-3xyz={k}$, find the minimum value of $x^2+y^2+z^2$.',
     cubic_norm_constant,valid=lambda k:nth_floor(k,3)**3==k,sample=lambda r:(r.randint(1,100)**3,),
     constraints=('The positive right-hand side is a perfect cube.',))


def even_root_power(d,c,k):
    # If u+v=sqrt(d), uv=c, the pair u²,v² has sum d−2c and product c².
    u,v=2,d-2*c
    for _ in range(1,k):
        u,v=v,(d-2*c)*v-c*c*u
    return v


bind('r931','even_power_sum_of_quadratic_roots','radicand constant half_power',(5,1,4),
     (I(1,200),I(-40,40),I(1,18)),
     lambda d,c,k:rf'Let $r,s$ be the two real roots of $x^2-x\sqrt{{{d}}}{c:+}=0$. Find $r^{{{2*k}}}+s^{{{2*k}}}$.',
     even_root_power,valid=lambda d,c,k:d>4*c,
     constraints=('The discriminant is positive.',))


bind('r1197','count_translation_function_equations','constant',(0,), (I(-100,100),),
     lambda c:rf'How many functions $f:\mathbb R\to\mathbb R$ satisfy $f(x+f(y))=x+y{c:+}$ for all real $x,y$?',
     lambda c:1)


def nested_cuberoot(c):
    k=nth_floor(c,3)
    if k**3+k*k>c:
        k-=1
    if k**3+k*k!=c:
        raise ValueError('No integer root of the reduced equation')
    return -k**3


bind('t363','cube_root_plus_shifted_square_root','shift',(12,),(I(2,30000),),
     lambda c:rf'Solve $\sqrt[3]{{x}}+\sqrt{{x+{c}}}=0$.',
     nested_cuberoot,valid=lambda c:any(j**3+j*j==c for j in range(1,32)),
     sample=lambda r:((k:=r.randint(1,30))**3+k*k,),
     constraints=('The shift equals k³+k² for an integer k between 1 and 31.',))


def geometric_sum_prompt(k):
    return rf'Let $-{k}<x<y<{k}$. Let $G$ and $G^\prime$ be the sums of infinite geometric series with first terms $x,y$ and common ratios $y/{k},x/{k}$, respectively. If $G=G^\prime$, find $x+y$.'


bind('t340','equal_cross_ratio_geometric_sums','bound',(1,),(I(1,100),),
     geometric_sum_prompt,lambda k:k)


def number_from_two_logs(base,k):
    return F(k+isqrt(k*k+4*base*base),2)


def two_logs_sample(rng):
    u=rng.randint(2,30)
    v=rng.randint(1,u-1)
    return u*v,u*u-v*v


bind('t826','log_pair_with_variable_base','base multiplier',(6,5),
     (I(2,1000),I(1,1000)),
     lambda b,k:rf'If $\log_{{{b}}}(x-y)+\log_{{{b}}}(x+y)=2$ and $\log_y({k}x)=2$, find $x$.',
     number_from_two_logs, valid=lambda b,k:is_square(k*k+4*b*b),sample=two_logs_sample,
     constraints=('multiplier²+4·base² is an integer square.',))


def sum_alternating_complex(x,y):
    # In a four-term block the changes are +2 in the real part and −2 in the imaginary part.
    candidates=[]
    for k in range(4):
        if k==0:
            q=F(x,2)
            yy=-2*q
        elif k==1:
            q=F(x,2)
            yy=2*q+1
        elif k==2:
            q=F(-x-2,2)
            yy=2*q+1
        else:
            q=F(-x-2,2)
            yy=-2*q-2
        n=4*q+k
        if q.denominator==1 and q>=0 and yy==y and n>0:
            candidates.append(n)
    return candidates


def complex_weighted_sample(rng):
    n=rng.randint(1,1800)
    return sum(k*(1,0,-1,0)[k%4] for k in range(1,n+1)),sum(k*(0,1,0,-1)[k%4] for k in range(1,n+1))


bind('t196','inverse_weighted_consecutive_imaginary_powers','real imag',(48,49),
     (I(-1000,1000),)*2,
     lambda x,y:rf'For what positive integer $n$ does $i+2i^2+3i^3+\cdots+ni^n={x}{y:+}i$?',
     lambda x,y:sum_alternating_complex(x,y)[0],
     valid=lambda x,y:len(sum_alternating_complex(x,y))==1,sample=complex_weighted_sample,
     constraints=('The target has one positive integer preimage under the weighted partial sum.',))


bind('t628','reciprocal_sum_pair_minimum','variables',(3,),(I(3,25),),
     lambda n: (r'Let $a,b,c>0$. Find the minimum of '
        r'$\frac{1/a+1/b+1/c}{1/(a+b)+1/(a+c)+1/(b+c)}$.' if n==3 else
        rf'Let $a_1,\dots,a_{{{n}}}>0$. Find the minimum of $\frac{{\sum_{{i=1}}^{{{n}}}1/a_i}}{{\sum_{{1\le i<j\le {n}}}1/(a_i+a_j)}}$.'),
     lambda n:F(4,n-1))


bind('r1075','minimum_sum_of_all_ordered_ratios','variables',(3,),(I(3,30),),
     lambda n: (r'Let $a,b,c>0$. Find the minimum of $\frac{a+b}{c}+\frac{a+c}{b}+\frac{b+c}{a}$.' if n==3 else
        rf'Let $a_1,\dots,a_{{{n}}}>0$. Find the minimum of $\sum_{{i=1}}^{{{n}}}\frac{{\sum_{{j\ne i}}a_j}}{{a_i}}$.'),
     lambda n:n*(n-1))


bind('t691','quadratic_lagrange_leading_coefficient','scale shift',(1,0),(I(1,60),I(-100,100)),
     lambda m,s:rf'Let $a,b,c$ be distinct real numbers. Simplify $\frac{{({m}x+a{s:+})^2}}{{(a-b)(a-c)}}+\frac{{({m}x+b{s:+})^2}}{{(b-a)(b-c)}}+\frac{{({m}x+c{s:+})^2}}{{(c-a)(c-b)}}$.',
     lambda m,s:1)
