"""Exact mathematical models for intermediate algebra."""
