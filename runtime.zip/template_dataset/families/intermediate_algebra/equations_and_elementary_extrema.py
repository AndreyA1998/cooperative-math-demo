"""Equations and elementary extrema; exact source-bound mathematical models."""
from fractions import Fraction as F
from itertools import product
from math import isqrt

from template_dataset.families.construction import is_square, sqrt_fraction
from template_dataset.families.intermediate_algebra.callable_bindings import I, bind, polynomial


def inverse_sample(rng):
    a,c=rng.randint(1,8),rng.randint(1,8)
    t,b=rng.randint(-20,30),rng.randint(-20,30)
    d=(a-c)*t+b+rng.randint(0,25)
    return a,b,c,d,t,a*t+b-rng.randint(1,50),c*t+d+rng.randint(0,50)


bind('r345','piecewise_affine_inverse_sum','a b c d threshold u v',(1,3,2,-2,20,7,46),
     (I(1,20),I(-100,100),I(1,20),I(-250,250),I(-30,40),I(-400,400),I(-400,600)),
     lambda a,b,c,d,t,u,v:rf'Let $f(x)=\begin{{cases}}{polynomial([b,a])}&x<{t},\\{polynomial([d,c])}&x\ge {t}.\end{{cases}}$ Find $f^{{-1}}({u})+f^{{-1}}({v})$.',
     lambda a,b,c,d,t,u,v:F(u-b,a)+F(v-d,c),
     valid=lambda a,b,c,d,t,u,v:a*t+b<=c*t+d and u<a*t+b and v>=c*t+d,
     sample=inverse_sample,
     constraints=('The increasing branch images do not overlap. u is in the first image and v in the second.',))


def odd_preimages(a,n,target):
    candidates={target}
    for _ in range(n):
        candidates={x for y in candidates for x in (y-a,2*y) if
                    (x%2 and x+a==y) or (x%2==0 and x//2==y)}
    return [x for x in candidates if x%2]


def parity_step_prompt(a,n,t):
    expression='k'
    for _ in range(n):
        expression=f'f({expression})'
    return rf'For integers $n$ let $f(n)=\begin{{cases}}n+{a}&n\text{{ odd}},\\n/2&n\text{{ even}}.\end{{cases}}$ If $k$ is odd and $ {expression}={t}$, find $k$.'


bind('r487','odd_preimage_under_parity_map','increment iterations target',(3,3,27),
     (I(1,75),I(2,8),I(-1000,1000)),parity_step_prompt,
     lambda a,n,t:odd_preimages(a,n,t)[0],
     valid=lambda a,n,t:len(odd_preimages(a,n,t))==1,
     constraints=('Exactly one odd integer has the prescribed image under the given number of iterations.',))


def absolute_linear_sums(a,b):
    answers=set()
    for sx,sy in product((-1,1),repeat=2):
        p,q=1+sx,sy-1
        y=F(a-p*b,1-p*q)
        x=b-q*y
        if x*sx>=0 and y*sy>=0:
            answers.add(x+y)
    return answers


bind('r1059','linear_absolute_value_system','first second',(10,12),(I(-200,200),)*2,
     lambda a,b:rf'If $|x|+x+y={a}$ and $x+|y|-y={b}$, find $x+y$.',
     lambda a,b:next(iter(absolute_linear_sums(a,b))),
     valid=lambda a,b:len(absolute_linear_sums(a,b))==1,
     constraints=('At least one real pair exists and all real pairs give the same sum.',))


def weighted_intersection(a,b,c,d,e,f):
    det=a*e-b*d
    return F(c*e-b*f+a*f-c*d,det)


def intersection_valid(a,b,c,d,e,f):
    det=a*e-b*d
    return det!=0 and (e-d)*det>=0 and (a-b)*det>=0


bind('r1051','maximum_sum_under_two_halfplanes','a b c d e f',(3,2,7,2,4,8),
     (I(1,30),I(1,30),I(-200,200),I(1,30),I(1,30),I(-200,200)),
     lambda a,b,c,d,e,f:rf'If $ {a}x+{b}y\le {c}$ and $ {d}x+{e}y\le {f}$, find the largest possible value of $x+y$ for real $x,y$.',
     weighted_intersection,valid=intersection_valid,
     constraints=('The boundary lines are independent, and the objective normal lies in their closed nonnegative cone.',))


def equal_moduli_radical(c,d):
    return sqrt_fraction(1-(F(d*d,c*c)-1)**2)


def equal_moduli_valid(c,d):
    q=F(d*d,c*c)-1
    return 0<=q<1 and is_square(1-q*q)


def paired_radical_sample(rng):
    m=rng.randint(2,9)
    n=rng.randint(1,m-1)
    return m*m+n*n,m*m+2*m*n-n*n


bind('r1006','sum_of_paired_radicals','multiplier right_multiplier',(5,7),
     (I(1,150),I(1,200)),
     lambda c,d:rf'Find the positive real $x$ such that $ {c}\sqrt{{1+x}}+{c}\sqrt{{1-x}}={d}\sqrt2$.',
     equal_moduli_radical,valid=equal_moduli_valid,sample=paired_radical_sample,
     constraints=('The inferred square root of 1−x² is in [0,1), and the inferred x² is a rational square.',))


def inner_radical_candidate(a,b,c):
    return F(c**4+4*b,4*(c*c-a))


def nested_sum_valid(a,b,c):
    if c*c==a:
        return False
    x=inner_radical_candidate(a,b,c)
    return 0<=x<=F(c*c,2) and x*x>=a*x+b>=0


def nested_sum_sample(rng):
    c=rng.randrange(4,22,2)
    x=rng.randint(c*c//4,c*c//2)
    a=rng.randint(0,max(0,c*c-(c**4//4+x-1)//x))
    b=(c*c-a)*x-c**4//4
    return a,b,c


bind('t8','sum_of_nested_radicals','linear constant target',(3,6,6),
     (I(0,300),I(0,40000),I(2,30)),
     lambda a,b,c:rf'Solve $\sqrt{{x+\sqrt{{{polynomial([b,a])}}}}}+\sqrt{{x-\sqrt{{{polynomial([b,a])}}}}}={c}$.',
     inner_radical_candidate,valid=nested_sum_valid,sample=nested_sum_sample,
     constraints=('The linear equation after squaring is nonsingular and its candidate satisfies x in [0,target²/2] and x² ≥ linear*x+constant ≥ 0.',))


def rational_log_sample(rng):
    a,b=rng.sample(range(2,31),2)
    c=rng.randint(1,10)
    return a,b,rng.randint(2,10),c,c+1


bind('t495','equal_logs_with_variable_bases','a b common exponent_a exponent_b',(3,2,2,2,3),
     (I(1,100),I(1,100),I(2,12),I(1,12),I(2,13)),
     lambda a,b,k,c,d:rf'Find the positive solution of $\log_{{{a}x}}{k**c}=\log_{{{b}x}}{k**d}$ with both bases different from 1.',
     lambda a,b,k,c,d:F(b**c,a**d),sample=rational_log_sample,
     valid=lambda a,b,k,c,d:a!=b and d==c+1,
     constraints=('The base multipliers differ and the second argument exponent is one larger than the first.',))


def log_cancel_sample(rng):
    b,m=rng.randint(2,7),rng.randint(1,4)
    x=rng.randint(2,15)
    return b,rng.randint(0,x-1),x**3-b**m,m


def integer_cube(n):
    lo,hi=0,max(1,n+1)
    while hi-lo>1:
        mid=(lo+hi)//2
        if mid**3<=n:
            lo=mid
        else:
            hi=mid
    return lo


bind('r1280','opposite_logs_cancel','base shift cube_shift half_rhs',(5,2,2,2),
     (I(2,12),I(0,30),I(-3000,10000),I(1,5)),
     lambda b,c,d,m:rf'Find the positive $x$ satisfying $\log_{{{b}}}({polynomial([-c,1])})+\log_{{\sqrt{{{b}}}}}({polynomial([-d,0,0,1])})+\log_{{1/{b}}}({polynomial([-c,1])})={2*m}$.',
     lambda b,c,d,m:integer_cube(b**m+d),sample=log_cancel_sample,
     valid=lambda b,c,d,m:b**m+d>c**3 and integer_cube(b**m+d)**3==b**m+d,
     constraints=('base^half_rhs + cube_shift is an integer cube whose root exceeds shift.',))


def rational_form_sample(rng):
    u,v,k=rng.randint(1,15),rng.randint(1,15),rng.randint(1,4)
    c=rng.randint(0,min(50,k*u*v-1))
    return c+k*u*u,c+k*v*v,c


bind('t668','minimum_of_shifted_rational_product','a b c',(5,2,1),
     (I(1,1000),I(1,1000),I(0,50)),
     lambda a,b,c:rf'Find the minimum of $\frac{{(x+{a})(x+{b})}}{{x+{c}}}$ for $x>0$.',
     lambda a,b,c:2*isqrt((a-c)*(b-c))+a+b-2*c,
     valid=lambda a,b,c:a>c and b>c and (a-c)*(b-c)>c*c and is_square((a-c)*(b-c)),
     sample=rational_form_sample,
     constraints=('Both a−c and b−c are positive, and their product is a perfect square greater than c².',))


bind('r908','sum_under_two_real_root_constraints','scale_a scale_b',(1,2),(I(1,20),)*2,
     lambda a,b:rf'Let $a,b>0$ and suppose $x^2+{a}ax+{b}b=0$ and $x^2+{b}bx+{a}a=0$ both have real roots. Find the smallest value of $a+b$.',
     lambda a,b:F(4,a)+F(4,b))
