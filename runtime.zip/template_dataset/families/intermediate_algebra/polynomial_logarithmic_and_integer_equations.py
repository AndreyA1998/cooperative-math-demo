"""Polynomial logarithmic and integer equations; exact source-bound mathematical models."""
from fractions import Fraction as F
from itertools import combinations, permutations
from math import comb, gcd, isqrt, prod

from template_dataset.families.construction import choice
from template_dataset.families.intermediate_algebra.format_bindings import I, _bind, _square


def _poly_product(a,b):
    out = [0]*(len(a)+len(b)-1)
    for i,c in enumerate(a):
        for j,d in enumerate(b):
            out[i+j] += c*d
    return out


def _numbered_fields(count, prefix='c'):
    return [f'{prefix}{i}' for i in range(count)]


def _poly_term_string(fields):
    return '+'.join('({'+name+'})'+('' if k==0 else 'x' if k==1 else 'x^'+str(k))
                    for k,name in reversed(list(enumerate(fields))))


def _polynomial_from_construction(rng, factors, names):
    coefficients = [1]
    for factor in factors:
        coefficients = _poly_product(coefficients, factor(rng))
    return dict(zip(names,coefficients))


def _divide_linear(coefficients, root):
    reversed_coefficients = iter(reversed(coefficients))
    q = [next(reversed_coefficients)]
    for c in reversed_coefficients:
        q.append(c+q[-1]*root)
    return tuple(reversed(q[:-1])),q[-1]


_fields = _numbered_fields(4)
_bind('r292','polynomial_quotient_hole',' '.join(_fields+['root']),
      (18,21,8,1,-2),(I(-8000,8000),I(-8000,8000),I(-8000,8000),I(1,20),I(-25,25)),
      r'Simplify \(y=\frac{{'+_poly_term_string(_fields)+r'}}{{x-({root})}}\) to \(y=Ax^2+Bx+C\) with one excluded \(x\)-value \(D\). Find \(A+B+C+D\).',
      lambda c,b,a,d,r:sum(_divide_linear((c,b,a,d),r)[0])+r,
      valid=lambda p:_divide_linear(tuple(p[f'c{k}'] for k in range(4)),p['root'])[1]==0,
      sample=lambda r:_sample_quotient(r),
      constraints=('The cubic numerator is divisible by the specified linear denominator.',))


def _sample_quotient(rng):
    root = rng.randint(-25,25)
    coefficients = _poly_product((-root,1), (rng.randint(-80,80),rng.randint(-80,80),rng.randint(1,20)))
    return dict(zip(_numbered_fields(4),coefficients),root=root)


_bind('s586','partial_fraction_sum_linear','numerator_slope numerator_constant pole',
      (7,-2,2),(I(-120,120),I(-200,200),I(1,80)),
      r'By partial fractions, \(\frac{{({numerator_slope})x+({numerator_constant})}}{{x^2-{pole}^2}}=\frac{{A}}{{x-{pole}}}+\frac{{B}}{{x+{pole}}}\). Find \(A+B\).',
      lambda a,b,r:a,
      reference=lambda a,b,r:F(a*r+b,2*r)+F(-a*r+b,-2*r))

_bind('r299','partial_fraction_residue_product','quadratic linear constant first second third',
      (1,0,-19,1,-2,3),(I(1,40),I(-80,80),I(-100,100),I(-20,20),I(-20,20),I(-20,20)),
      r'Write \(\frac{{{quadratic}x^2+({linear})x+({constant})}}{{(x-({first}))(x-({second}))(x-({third}))}}'
      r'=\frac{{A}}{{x-({first})}}+\frac{{B}}{{x-({second})}}+\frac{{C}}{{x-({third})}}\). Find \(ABC\).',
      lambda a,b,c,*roots:prod(F(a*r*r+b*r+c,prod(r-s for s in roots if s!=r)) for r in roots),
      valid=lambda p:len({p[k] for k in ('first','second','third')})==3,
      sample=lambda r:dict(zip(('first','second','third'),r.sample(range(-20,21),3)),
                           quadratic=r.randint(1,40),linear=r.randint(-80,80),constant=r.randint(-100,100)),
      constraints=('The three poles specified by the denominator factors are distinct.',),
      adaptation='Writes the denominator in factored form, already specified by the partial fractions.')

_bind('r573','linear_factor_unknown_linear','u v a b d',(2,7,6,19,35),
      (I(1,40),I(1,90),I(1,40),I(-80,80),I(-120,120)),
      r'If \({u}x+{v}\) divides \({a}x^3+({b})x^2+cx+({d})\), find \(c\).',
      lambda u,v,a,b,d:_unknown_linear_coefficient(F(-v,u),a,b,d))

_bind('s706','monic_factor_unknown_linear','root quadratic constant',(3,-3,27),(I(1,80),I(-80,80),I(-300,300)),
      r'Find \(t\) such that \(x-{root}\) divides \(x^3+({quadratic})x^2+tx+({constant})\).',
      lambda r,b,d:_unknown_linear_coefficient(r,1,b,d))


def _unknown_linear_coefficient(r,a,b,d):
    return F(-a*r**3-b*r*r-d,r)


_bind('r1157','factor_unknown_cubic_linear','root quadratic multiplier constant',(7,19,-3,35),
      (I(2,50),I(-80,80),I(-80,80),I(-100,100)),
      r'Find \(c\) so that \(x+{root}\) is a factor of \(cx^3+({quadratic})x^2+({multiplier})cx+({constant})\).',
      lambda r,b,m,d:F(b*r*r+d,r*(r*r+m)),
      valid=lambda p:p['root']**2+p['multiplier']!=0,
      sample=lambda r:{'root':(n:=r.randint(2,50)),'quadratic':r.randint(-80,80),
                       'multiplier':r.choice([m for m in range(-80,81) if m!=-n*n]),
                       'constant':r.randint(-100,100)},
      constraints=('The coefficient of c at the root is nonzero.',))

_bind('r954','even_quartic_conjugate_factor','linear constant',(2,5),(I(1,60),I(1,160)),
      r'If \(x^2+{linear}x+{constant}\) divides \(x^4+Px^2+Q\), find \(P+Q\).',
      lambda b,c:2*c-b*b+c*c)

_bind('s653','sum_of_cubes_bivariate_quotient','x_multiplier y_multiplier',(2,3),(I(1,60),I(1,60)),
      r'Write \(\frac{{{x_multiplier}^3 x^3+{y_multiplier}^3 y^3}}{{{x_multiplier}x+{y_multiplier}y}}\) as \(ax^2+bxy+cy^2\). Find \(a+b+c\).',
      lambda a,b:a*a-a*b+b*b,
      reference=lambda a,b:F(a**3+b**3,a+b))

for _key,_a,_b,_sign in (('r46',9,2,1),('s437',2,3,-1)):
    _factor_sign = '+' if _sign==1 else '-'
    _bind(_key,'primitive_cube_factorization','a b',(_a,_b),(I(1,80),I(1,80)),
          r'Factor \({a}^3x^3'+_factor_sign+r'{b}^3\) as \((Ax+B)(Cx^2+Dx+E)\) with integer coefficients, \(A>0\), and primitive linear factor (its coefficients are relatively prime). Find \(A+B+C+D+E\).',
          lambda a,b,s=_sign:a+s*b+a*a-s*a*b+b*b,
          valid=lambda p:gcd(p['a'],p['b'])==1,
          sample=lambda r:{'a':(a:=r.randint(1,80)), 'b':r.choice([b for b in range(1,81) if gcd(a,b)==1])},
          constraints=('The positive cube bases are relatively prime.',),
          adaptation='Requires the linear factor to be primitive, making its normalization unique.')


_bind('r577','polynomial_remainder_evaluation','b c d',(2,8,4),(I(-90,90),I(1,150),I(-100,100)),
      r'Evaluate \(x^3-({b})x^2-{c}x+({d})\), where \(x>0\) satisfies \(x^2-({b})x-{c}=0\).',
      lambda b,c,d:d)

_bind('r948','factored_numeric_polynomial','x rhs',(101,101000),(I(2,400),I(-1000000,1000000)),
      r'If \(x={x}\) and \(x^3y-2x^2y+xy={rhs}\), find \(y\).',
      lambda x,z:F(z,x*(x-1)**2),reference=lambda x,z:F(z,x**3-2*x*x+x))

_bind('r1047','shifted_perfect_cube_equation','shift',(1,),(I(-50,50),),
      r'Solve \(-x^2=\frac{{3\cdot ({shift})^2x+({shift})^3}}{{x+3\cdot ({shift})}}\) over the reals.',
      lambda a:-a,valid=lambda p:p['shift']!=0,
      sample=lambda r:{'shift':r.choice(tuple(range(-50,0))+tuple(range(1,51)))},
      constraints=('The shift is nonzero, so the cubic root is outside the original pole.',))


_bind('r180','reciprocal_logs_product','first second third target',
      (2,3,4,1),(I(2,50),I(2,50),I(2,50),I(1,4)),
      r'Find \(a>0,\ a\ne1\) satisfying \(1/\log_{{{first}}}a+1/\log_{{{second}}}a+1/\log_{{{third}}}a=1/{target}\).',
      lambda a,b,c,d:(a*b*c)**d)

_bind('r52','logarithmic_product','first second third base exponent',
      (11,13,14,2002,2),(I(2,50),I(2,50),I(2,50),I(8,125000),I(1,12)),
      r'Let \(f(n)=\log_{{{base}}}(n^{{{exponent}}})\). Compute \(f({first})+f({second})+f({third})\).',
      lambda a,b,c,q,d:d,
      valid=lambda p:p['first']*p['second']*p['third']==p['base'],
      sample=lambda r:dict(first=(a:=r.randint(2,50)),second=(b:=r.randint(2,50)),third=(c:=r.randint(2,50)),
                           base=a*b*c,exponent=r.randint(1,12)),
      constraints=('The product of the three arguments is the logarithm base.',))

_bind('r596','nested_exponent_equality','base exponent',
      (2,4),(I(2,20),I(2,20)),
      r'Solve \(b^{{(b^k)^x}}=(b^k)^{{b^x}}\) for \(x\), where \(b={base}\) and \(k={exponent}\). Give your answer using logarithms if needed.',
      lambda a,b:F(_power_index(a,b),b-1),
      valid=lambda p:_power_index(p['base'],p['exponent'])>0,
      sample=lambda r:{'base':(a:=r.randint(2,12)),'exponent':a**r.randint(1,_max_power_exponent(a,20))},
      constraints=('The outer base exponent is a positive integer power of the base, ensuring a rational solution.',),
      adaptation='Uses named constants b and k to preserve the two related exponential bases.')


def _power_index(a,b):
    count = 0
    while b>1 and b%a==0:
        b //= a
        count += 1
    return count if b==1 else 0


def _max_power_exponent(a,b):
    exponent=0
    while a**(exponent+1)<=b:
        exponent+=1
    return exponent


_bind('s208','logarithmic_chain','first second third fourth last',
      (4,5,6,7,8),(I(2,1000),I(2,80),I(2,80),I(2,80),I(2,1000)),
      r'Suppose \({first}^a={second}\), \({second}^b={third}\), \({third}^c={fourth}\), and \({fourth}^d={last}\). Find \(abcd\).',
      lambda a,b,c,d,e:_rational_log(a,e),
      valid=lambda p:_rational_log(p['first'],p['last']) is not None,
      sample=lambda r:_sample_log_chain(r),
      constraints=('The first and last bases are positive integral powers of a common integer, giving a rational result.',))


def _rational_log(a,b):
    for base in range(2,min(a,b)+1):
        i,j = _power_index(base,a),_power_index(base,b)
        if i and j:
            return F(j,i)
    return None


def _sample_log_chain(r):
    base=r.randint(2,25)
    power_limit=_max_power_exponent(base,1000)
    return dict(first=base**r.randint(1,power_limit),second=r.randint(2,80),
                third=r.randint(2,80),fourth=r.randint(2,80),last=base**r.randint(1,power_limit))


_bind('s434','nested_logs_power_relation','base power',(2,3),(I(2,30),I(2,25)),
      r'Find \((\log_b x)^{{k-1}}\) if \(\log_b(\log_{{b^k}}x)=\log_{{b^k}}(\log_b x)\), where \(b={base}\) and \(k={power}\).',
      lambda b,k:k**k)

_bind('s14','logarithmic_reciprocal_min','base coefficient numerator_exponent',
      (10,2,2),(I(2,30),I(1,100),I(1,100)),
      r'For \(x>1\), find the minimum of \({coefficient}\log_{{{base}}}x-\log_x(1/{base}^{{{numerator_exponent}}})\).',
      lambda b,a,e:2*isqrt(a*e),
      valid=lambda p:_square(p['coefficient']*p['numerator_exponent']),
      sample=lambda r:_sample_log_min(r),
      constraints=('The product of the coefficient and numerator exponent is a perfect square.',))


def _sample_log_min(r):
    factor=r.randint(1,20)
    max_square=isqrt(100//factor)
    return dict(base=r.randint(2,30),coefficient=factor*r.randint(1,max_square)**2,
                numerator_exponent=factor*r.randint(1,max_square)**2)


_bind('s637','infinite_nested_radical_parameter','target',(8,),(I(1,100),),
      r'Find the positive \(x\) for which \(\sqrt{{\frac{{x}}{{1+\sqrt{{\frac{{x}}{{1+\sqrt{{\frac{{x}}{{1+\cdots}}}}}}}}}}}}={target}\).',
      lambda t:t*t*(1+t))

_bind('r793','weighted_geometric_series_inverse','rhs',(9,),(I(2,10000),),
      r'Find the real \(x\) for which \(1+2x+3x^2+4x^3+\cdots={rhs}\).',
      lambda b:1-F(1,isqrt(b)),
      valid=lambda p:_square(p['rhs']),
      sample=lambda r:{'rhs':r.randint(2,100)**2},
      constraints=('The right-hand side is a perfect square.',))

_bind('s404 s873','prime_log_rational_independence','base rhs p q r s',
      (10,2005,2,3,5,7),(choice([2,3,5,6,7,10,14,15,21,22,26,30]),I(-5000,5000),
                          choice([2,3,5,7,11,13]),choice([2,3,5,7,11,13]),
                          choice([2,3,5,7,11,13]),choice([2,3,5,7,11,13])),
      r'How many rational quadruples \((a,b,c,d)\) satisfy \(a\log_{{{base}}}{p}+b\log_{{{base}}}{q}+c\log_{{{base}}}{r}+d\log_{{{base}}}{s}={rhs}\)?',
      lambda b,n,*p:int(n==0 or all(b%q!=0 for q in (2,3,5,7,11,13) if q not in p)),
      valid=lambda p:len({p[k] for k in 'pqrs'})==4,
      sample=lambda r:dict(zip('pqrs',r.sample((2,3,5,7,11,13),4)),
                           base=r.choice((2,3,5,6,7,10,14,15,21,22,26,30)),rhs=r.randint(-5000,5000)),
      constraints=('The four logarithm arguments are distinct primes.',))

_bind('s343','vertical_asymptote_repeated_linear','a b c d',(-1,3,-3,1),
      (I(-64000,64000),I(0,4800),I(-120,120),I(1,15)),
      r'How many vertical asymptotes does \(y=1/[{d}x^3+({c})x^2+({b})x+({a})]\) have?',
      lambda a,b,c,d:_real_cubic_root_count(a,b,c,d),
      sample=lambda r:_sample_cubic_asymptotes(r))


def _real_cubic_root_count(a,b,c,d):
    disc = c*c*b*b-4*d*b**3-4*c**3*a-27*d*d*a*a+18*d*c*b*a
    if disc:
        return 3 if disc>0 else 1
    return 1 if c*c==3*d*b else 2


def _sample_cubic_asymptotes(r):
    if r.randrange(2):
        roots=[r.randint(-8,8) for _ in range(3)]
        if r.randrange(2):
            roots[1]=roots[0]
        if r.randrange(2):
            roots[2]=roots[1]
        a,b,c,d=_poly_product(_poly_product((-roots[0],1),(-roots[1],1)),(-roots[2],1))
        if b>=0:
            return dict(a=a,b=b,c=c,d=d)
    return dict(a=r.randint(-100,100),b=r.randint(0,120),c=r.randint(-20,20),d=r.randint(1,15))


_bind('s87','factorized_quintic_real_root_count','quartic cubic',(1,72),
      (I(-90,90),I(-200,200)),
      r'For how many distinct real \(x\) does \(x^5=({quartic})x^4+({cubic})x^3\)?',
      lambda a,b:1+_real_quadratic_root_count(a,b)-int(b==0),
      reference=lambda a,b:_reference_polynomial_count((0,0,0,-b,-a,1)))


def _real_quadratic_root_count(a,b):
    disc=a*a+4*b
    return 2 if disc>0 else 1 if disc==0 else 0


def _reference_polynomial_count(coefficients):
    from template_dataset.families.algebra.real_roots import real_root_count

    return real_root_count(tuple(map(F,coefficients)))


_bind('s765','integer_cubic_roots_count','leading linear',(3,12),
      (I(1,80),I(-1000,1000)),
      r'How many integers \(n\) satisfy \({leading}n^3-({linear})n=0\)?',
      lambda a,b:1+2*int(b>0 and b%a==0 and _square(b//a)),
      sample=lambda r:{'leading':(a:=r.randint(1,40)), 'linear':a*r.randint(1,5)**2 if r.randrange(2) else r.randint(-1000,1000)},
      reference=lambda a,b:sum(a*n**3-b*n==0 for n in range(-32,33)))

_bind('s548','quartic_consecutive_spaced_min','start step',(0,1),
      (I(-60,60),I(1,60)),
      r'Find the minimum of \((x+({start}))(x+({start})+{step})(x+({start})+2\cdot {step})(x+({start})+3\cdot {step})\) over real \(x\).',
      lambda a,d:-d**4)

_bind('s868','consecutive_integer_product_square','rhs',(379**2,),(I(1,10**12),),
      r'If \(x\) is a positive integer and \(x(x+1)(x+2)(x+3)+1={rhs}\), find \(x\).',
      lambda z:(isqrt(5+4*isqrt(z))-3)//2,
      valid=lambda p:_valid_quartic_product_rhs(p['rhs']),
      sample=lambda r:{'rhs':((x:=r.randint(1,900))**2+3*x+1)**2},
      constraints=('The right-hand side is a square and five plus four times its square root is an odd square at least 25.',),
      reference=lambda z:next(x for x in range(1,1001) if x*(x+1)*(x+2)*(x+3)+1==z))


def _valid_quartic_product_rhs(z):
    return _square(z) and (y:=5+4*isqrt(z))>=25 and _square(y)


_bind('s886','common_ratio_triple_relation','first second',(2,3),(I(1,120),I(1,120)),
      r'If real \(x,y\) satisfy \({first}/x=y/{second}=x/y\), determine \(x^3\).',
      lambda a,b:a*a*b)

_bind('s377 s867','rational_involution','slope constant',(2,3),(I(1,80),I(1,80)),
      r'Let \(f(x)=cx/({slope}x+{constant})\) on its natural real domain. Find \(c\) so that \(f^{{-1}}=f\).',
      lambda a,b:-b,
      adaptation='States the self-inverse condition explicitly, which is equivalent to the original composition requirement.')

_bind('s664','diagonal_recurrence_weight','weight',(1,),(I(1,100),),
      r'For positive integers \(m,n\), \(f(m,1)=f(1,n)=1\), and otherwise \(f(m,n)=f(m-1,n)+f(m,n-1)+{weight}f(m-1,n-1)\). '
      r'Let \(S(k)=\sum_{{a+b=k,\ a,b\ge1}}f(a,b)\). If \(S(k+2)=pS(k+1)+qS(k)\) for all \(k\ge2\), find \(pq\).',
      lambda w:2*w,reference=lambda w:_diagonal_recurrence_reference(w))


def _diagonal_recurrence_reference(w):
    values={(1,1):1}
    sums={2:1}
    for n in range(3,7):
        for a in range(1,n):
            b=n-a
            values[a,b]=1 if a==1 or b==1 else values[a-1,b]+values[a,b-1]+w*values[a-1,b-1]
        sums[n]=sum(values[a,n-a] for a in range(1,n))
    p=F(sums[5]-sums[3]*sums[4],sums[4]-sums[3]**2)
    return p*(sums[4]-sums[3]*p)


def _pair_sum_reference(*given):
    def possible(total):
        known = list(given)
        pairs = []
        while known:
            first = known.pop()
            complement = total-first
            if complement in known:
                known.remove(complement)
            pairs.append((first,complement))
        if len(pairs)>3:
            return False
        while len(pairs)<3:
            large = 10000*(1+len(pairs))
            pairs.append((large,total-large))
        incident = [a for a,b in pairs]
        origin = F(sum(incident)-total,2)
        return len({origin,*(s-origin for s in incident)})==4

    totals = (a+b for a,b in combinations(given,2))
    return max(3*t-sum(given) for t in totals if possible(t))


_bind('r86','four_element_pair_sum_max','a b c d',
      (189,320,287,234),(I(-600,600),)*4,
      r'Four distinct real numbers have six pairwise sums. Four of those sums are {a}, {b}, {c}, and {d}. Find the greatest possible sum of the two remaining pairwise sums.',
      lambda *given:3*sum(sorted(given)[-2:])-sum(given),
      valid=lambda p:len(set(p.values()))==4,
      sample=lambda r:dict(zip('abcd',r.sample(range(-600,601),4))),
      reference=_pair_sum_reference,
      constraints=('The four known pairwise sums are distinct.',))


def _turnpike_largest_values(total,*distances):
    known=sorted(distances)
    span=known[-1]
    candidates = set(known[:-1])
    for a,b in combinations(sorted(candidates-{span}),2):
        if sorted((a,b,span,b-a,span-a,span-b))==known:
            base,remainder=divmod(total-a-b-span,4)
            if remainder==0:
                yield base+span


def _sample_turnpike(rng):
    points=sorted(rng.sample(range(-45,46),4))
    differences=sorted(b-a for a,b in combinations(points,2))
    return dict(zip(_numbered_fields(6,'d'),differences),total=sum(points))


_bind('r622','four_element_positive_differences','total '+' '.join(_numbered_fields(6,'d')),
      (44,1,3,4,5,6,9),(I(-180,180),)+(I(1,90),)*6,
      r'Four distinct integers \(w>x>y>z\) have sum {total}. The multiset of their positive pairwise differences is {d0}, {d1}, {d2}, {d3}, {d4}, {d5}. Find the sum of all possible values of \(w\).',
      lambda s,*d:sum(set(_turnpike_largest_values(s,*d))),
      valid=lambda p:any(True for _ in _turnpike_largest_values(p['total'],*(p[k] for k in _numbered_fields(6,'d')))),
      sample=_sample_turnpike,
      constraints=('The multiset is realizable by four distinct integers with the specified sum.',))


_bind('r571','integer_reciprocal_product_min','multiplier denominator',(2,7),
      (I(1,80),I(1,200)),
      r'For positive integers \(x,y\) satisfying \(1/x+1/({multiplier}y)=1/{denominator}\), find the smallest possible value of \(xy\).',
      lambda a,b:min(_unit_fraction_products(a,b)),
      valid=lambda p:any(True for _ in _unit_fraction_products(p['multiplier'],p['denominator'])),
      sample=lambda r:{'multiplier':(a:=r.randint(1,30)), 'denominator':a*r.randint(1,200//a)},
      constraints=('At least one positive integer pair solves the equation.',))


def _divisors(n):
    for d in range(1,isqrt(n)+1):
        if n%d==0:
            yield d
            if d*d!=n:
                yield n//d


def _unit_fraction_products(a,b):
    for d in _divisors(b*b):
        t=b+b*b//d
        if t%a==0:
            yield (b+d)*(t//a)


_bind('r305','unique_shifted_factor_pair','rhs',(80,),(I(5,100000),),
      r'Integers \(x>y>0\) satisfy \(x+y+xy={rhs}\). Find \(x\).',
      lambda n:next(x-1 for x in _shifted_factor_large_members(n)),
      valid=lambda p:sum(1 for _ in _shifted_factor_large_members(p['rhs']))==1,
      sample=lambda r:{'rhs':_sample_unique_composite(r)-1},
      constraints=('One more than the right-hand side has exactly one unordered pair of distinct factors both larger than 1.',))


def _shifted_factor_large_members(n):
    return (x for x in _divisors(n+1) if 1<(n+1)//x<x)


def _sample_unique_composite(r):
    primes=(2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71)
    if r.randrange(2):
        a,b=r.sample(primes,2)
        return a*b
    return r.choice((2,3,5,7,11,13,17))**4


_bind('s897','linear_diophantine_difference_min','first second rhs',
      (3,4,100),(I(1,120),I(1,120),I(-10000,10000)),
      r'If integers \(m,n\) satisfy \({first}m+{second}n={rhs}\), what is the smallest possible value of \(|m-n|\)?',
      lambda a,b,c:_diophantine_min(a,b,c),
      valid=lambda p:p['rhs']%gcd(p['first'],p['second'])==0,
      sample=lambda r:{'first':(a:=r.randint(1,120)), 'second':(b:=r.randint(1,120)),
                       'rhs':(g:=gcd(a,b))*r.randint(-10000//g+1,10000//g)},
      constraints=('The right-hand side is divisible by the greatest common divisor of the two coefficients.',),
      reference=lambda a,b,c:next(d for d in range(a+b) if (c-a*d)%(a+b)==0 or (c+a*d)%(a+b)==0))


def _diophantine_min(a,b,c):
    g=gcd(a,b)
    period=(a+b)//g
    residue=(c//g)*pow(a//g,-1,period)%period
    return min(residue,period-residue)


_bind('r623','digit_power_iteration','start exponent index',(2005,3,2005),
      (I(1,10000),I(2,5),I(1,25000)),
      r'The first term of a sequence is {start}; each subsequent term is the sum of the {exponent}th powers of the decimal digits of the preceding term. Find term {index}.',
      lambda a,e,n:_digit_power_iterate(a,e,n),
      reference=lambda a,e,n:_digit_power_direct(a,e,n))


def _digit_power_iterate(value,exponent,index):
    states=[]
    seen={}
    while value not in seen:
        if len(states)==index-1:
            return value
        seen[value]=len(states)
        states.append(value)
        value=sum(int(d)**exponent for d in str(value))
    start=seen[value]
    return states[start+(index-1-start)%(len(states)-start)]


def _digit_power_direct(value,exponent,index):
    for _ in range(1,index):
        value=sum(int(d)**exponent for d in str(value))
    return value


_bind('r1136','second_order_recurrence_interpolation','coefficient third sixth',(2,9,128),
      (I(1,50),I(-300,300),I(-300,300)),
      r'Let a sequence satisfy \(u_{{n+2}}={coefficient}u_{{n+1}}+u_n\) for all \(n\ge1\). If \(u_3={third}\) and \(u_6={sixth}\), find \(u_5\).',
      lambda a,b,c:F(a*c+b,a*a+1))

_bind('s635','arithmetic_sequence_product_interpolation','first second third target',
      (1440,1716,1848,8),(I(-10000,10000),I(-10000,10000),I(-10000,10000),I(4,200)),
      r'The first three terms of a sequence are {first}, {second}, {third}. Each term is the product of the corresponding terms of two real arithmetic sequences. Find term {target}.',
      lambda a,b,c,n:a+(n-1)*(b-a)+comb(n-1,2)*(c-2*b+a),
      valid=lambda p:_sequence_product_valid(p['first'],p['second'],p['third']),
      sample=lambda r:_sample_sequence_product(r),
      constraints=('The quadratic in the index interpolating the first three terms has nonnegative discriminant whenever it is of degree two.',))


def _sequence_product_valid(a,b,c):
    quadratic=F(c-2*b+a,2)
    linear=b-a-quadratic
    return linear**2>=4*a*quadratic


def _sample_sequence_product(r):
    a,b,c,d=(r.randint(-30,30) for _ in range(4))
    return dict(first=a*c,second=(a+b)*(c+d),third=(a+2*b)*(c+2*d),target=r.randint(4,200))


_bind('s592','mean_of_digit_permutations','a b c d e',(1,3,5,7,8),(I(1,9),)*5,
      r'Find the mean of the five-digit numbers formed by using each of the digits {a}, {b}, {c}, {d}, and {e} exactly once.',
      lambda *digits:F(11111*sum(digits),5),
      valid=lambda p:len(set(p.values()))==5,
      sample=lambda r:dict(zip('abcde',r.sample(range(1,10),5))),
      constraints=('The five digits are distinct and nonzero.',),
      reference=lambda *digits:F(sum(sum(d*10**i for i,d in enumerate(p)) for p in permutations(digits)),120))

_bind('s847','product_of_four_radical_sums','first second third',(5,6,7),(I(1,100),)*3,
      r'Evaluate \((\sqrt{{{first}}}+\sqrt{{{second}}}+\sqrt{{{third}}})(-\sqrt{{{first}}}+\sqrt{{{second}}}+\sqrt{{{third}}})'
      r'(\sqrt{{{first}}}-\sqrt{{{second}}}+\sqrt{{{third}}})(\sqrt{{{first}}}+\sqrt{{{second}}}-\sqrt{{{third}}})\).',
      lambda a,b,c:4*a*b-(a+b-c)**2)
