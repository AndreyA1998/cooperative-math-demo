"""Callable bindings; exact source-bound mathematical models."""
from fractions import Fraction
from template_dataset.families.algebra.equations_and_expressions import _tex_polynomial as polynomial
from template_dataset.families.construction import integer as I, integers, template

_BINDINGS = {}


def bind(key, name, fields, original, domains, prompt, solve, *, sample=None,
         valid=None, constraints=(), reference=None, adaptation=''):
    names = fields.split()
    if len(names) != len(original) or len(names) != len(domains):
        raise ValueError(name)
    split = 'train' if key.startswith('r') else 'test'
    problem_id = f'intermediate_algebra/{split}/{key[1:]}'
    if problem_id in _BINDINGS:
        raise ValueError(problem_id)

    def unpack(function):
        return lambda p: function(*(p[k] for k in names))

    def sampler(rng):
        return dict(zip(names, sample(rng)))

    _BINDINGS[problem_id] = template(
        f'intermediate_algebra.round3.{name}', dict(zip(names, domains)),
        dict(zip(names, original)), unpack(prompt) if callable(prompt) else
        lambda p: prompt.format(**p), unpack(solve),
        sample=None if sample is None else sampler,
        valid=(lambda p: True) if valid is None else unpack(valid),
        constraints=constraints, adaptation=adaptation,
        reference=None if reference is None else unpack(reference),
    )


def build(row):
    return _BINDINGS.get(row['id'])


def tex(value):
    q = Fraction(value)
    if q.denominator == 1:
        return str(q.numerator)
    sign = '-' if q < 0 else ''
    return rf'{sign}\frac{{{abs(q.numerator)}}}{{{q.denominator}}}'
