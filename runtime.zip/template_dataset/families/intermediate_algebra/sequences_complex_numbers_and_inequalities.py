"""Sequences complex numbers and inequalities; exact source-bound mathematical models."""
from fractions import Fraction as F
from math import comb, isqrt, prod

from template_dataset.families.construction import choice
from template_dataset.families.intermediate_algebra.format_bindings import I, _bind, _pythagorean_sample, _square


def _alternating(a,d,n,sign):
    return sign*(-d*(n//2) + (a+(n-1)*d)*(n%2))


for _key,_a,_d,_n,_s in (
    ('r30',1,1,10000,-1), ('r1020',1,3,19,1),
    ('s271',1,1,2007,1), ('s679',1,2,25,1), ('s863',100,-1,100,1),
):
    _descending = _d < 0
    _bind(_key,'alternating_progression','start step count sign',
          (_a,_d,_n,_s),(I(21,200) if _descending else I(1,100),
                        I(-10,-1) if _descending else I(1,40),
                        I(3,20000),choice([-1,1])),
          r'An arithmetic progression starts at {start}, has common difference {step}, and has {count} terms. '
          r'Give successive terms alternating signs, with first sign {sign}. Compute the resulting sum.',
          _alternating, reference=lambda a,d,n,s:sum(s*(-1)**k*(a+k*d) for k in range(n)),
          valid=lambda p:p['start']+(p['count']-1)*p['step']>0,
          sample=(lambda r: {'start':(a:=r.randint(21,200)), 'step':(d:=-r.randint(1,10)),
                             'count':r.randint(3,(a-1)//(-d)+1),
                             'sign':r.choice([-1,1])}) if _descending else None,
          constraints=('All unsigned progression terms are positive.',))


_bind('r960','alternating_units','start count',(1,2006),(I(1,400),I(3,20000)),
      r'Find the sum of $(-1)^k$ over the {count} consecutive integers starting at \(k={start}\).',
      lambda a,n:(-1)**a*(n%2),reference=lambda a,n:sum((-1)**k for k in range(a,a+n)))


for _key,_s,_c,_op in (('r42',7,91,'+'),('r84 s214',4,28,'-')):
    def _cube_sample(rng, op=_op):
        s = rng.randint(1,80)
        c = rng.randint((s**3+3)//4, 4*s**3)
        return {'linear':s,'cubic':c}

    _bind(_key,'cubic_symmetric_product','linear cubic',(_s,_c),(I(1,80),I(1,4*80**3)),
          r'For real numbers \(x,y\), \(x'+_op+r'y={linear}\) and \(x^3'+_op+r'y^3={cubic}\). Find $xy$.',
          lambda s,c,op=_op:F(c-s**3,(3 if op=='-' else -3)*s),
          valid=lambda p:4*p['cubic']>=p['linear']**3,sample=_cube_sample,
          constraints=('Four times the cubic value is at least the cube of the linear value, ensuring real solutions.',))


def _ordered_indices(rng, lo, start_max, end_max, **extra):
    a = rng.randint(lo,start_max)
    return dict(start=a,end=rng.randint(a+1,end_max),**extra)


def _ordered(p):
    return p['start']<p['end']


_ORDERED = ('The last index is strictly larger than the first.',)


for _key,_last in (('r55',50),('r548',100),('r803',2007)):
    _bind(_key,'telescoping_complements','start end',(2,_last),(I(2,250),I(3,4000)),
          r'Compute the product of $1-1/k$ over the integers \({start}\le k\le {end}\).',
          lambda a,b:F(a-1,b),valid=_ordered,sample=lambda r:_ordered_indices(r,2,250,4000),
          constraints=_ORDERED,reference=lambda a,b:prod(F(k-1,k) for k in range(a,b+1)))


for _key,_last in (('r231',5),('r889',9),('s734',99)):
    _bind(_key,'telescoping_reciprocals','start end',(1,_last),(I(1,30),I(2,600)),
          r'Compute the sum of $1/[k(k+1)]$ over the integers \({start}\le k\le {end}\).',
          lambda a,b:F(1,a)-F(1,b+1),valid=_ordered,sample=lambda r:_ordered_indices(r,1,30,600),
          constraints=_ORDERED,reference=lambda a,b:sum(F(1,k*(k+1)) for k in range(a,b+1)))


_bind('r273','rising_factorial_ratio','start end offset',(1,50,3),(I(1,30),I(2,250),I(1,20)),
      r'Compute the product of \(k/(k+{offset})\) for the consecutive integers from {start} to {end}.',
      lambda a,b,d:F(comb(a+d-1,d),comb(b+d,d)),valid=_ordered,constraints=_ORDERED,
      sample=lambda r:_ordered_indices(r,1,30,250,offset=r.randint(1,20)),
      reference=lambda a,b,d:prod(F(k,k+d) for k in range(a,b+1)))

_bind('r904','scaled_telescoping_ratio','scale start end',(3,1,667),(I(1,40),I(1,30),I(2,2000)),
      r'Compute the product of \(\frac{{{scale}k}}{{{scale}(k+1)}}\) for the integers from {start} to {end}.',
      lambda _,a,b:F(a,b+1),valid=_ordered,constraints=_ORDERED,
      sample=lambda r:_ordered_indices(r,1,30,2000,scale=r.randint(1,40)),
      reference=lambda d,a,b:prod(F(d*k,d*(k+1)) for k in range(a,b+1)))

_bind('s776','successive_ratio_product','start end',(2,8),(I(1,40),I(2,2000)),
      r'Compute the product of $k/(k+1)$ for the integers from {start} to {end}.',
      lambda a,b:F(a,b+1),valid=_ordered,constraints=_ORDERED,
      sample=lambda r:_ordered_indices(r,1,40,2000),reference=lambda a,b:prod(F(k,k+1) for k in range(a,b+1)))

_bind('r355','integer_square_root_sum','end',(16,),(I(2,30000),),
      r'Find \(\sum_{{k=1}}^{{{end}}}\lfloor\sqrt k\rfloor\).',
      lambda n:(q:=isqrt(n))*(n+1)-q*(q+1)*(2*q+1)//6,
      reference=lambda n:sum(isqrt(k) for k in range(1,n+1)))

_bind('r397','ceil_squares','ceiling',(11,),(I(1,30000),),
      r'For real \(x\) with \(\lceil x\rceil={ceiling}\), how many distinct values can \(\lceil x^2\rceil\) take?',
      lambda n:n*n-(n-1)**2)

_bind('s20','floor_scaled_interval','floor multiplier',(-9,5),(I(-100,100),I(2,400)),
      r'For real \(x\) satisfying \(\lfloor x\rfloor={floor}\), how many values can \(\lfloor {multiplier}x\rfloor\) take?',
      lambda _,m:m,reference=lambda a,m:len({(m*a+k) for k in range(m)}))

_bind('s509','integer_sign_sum','negative positive',(10,20),(I(1,1000),I(1,1000)),
      r'Find \(\sum_{{k=-{negative}}}^{{{positive}}}\operatorname{{sgn}}(k)\), where the sign function is \(-1\), \(0\), or \(1\) according as its argument is negative, zero, or positive.',
      lambda a,b:b-a,reference=lambda a,b:sum((k>0)-(k<0) for k in range(-a,b+1)))

_bind('r1201','modular_last_digits','base exponent digits',(9,105,3),(I(2,200),I(2,1200),I(2,6)),
      r'What number is represented by the final {digits} decimal digits of \({base}^{{{exponent}}}\)?',
      lambda a,n,d:pow(a,n,10**d),reference=lambda a,n,d:a**n%10**d)

_bind('r725','average_with_variable','end multiplier',(99,100),(I(2,2000),I(1,2000)),
      r'The arithmetic mean of \(1,2,\ldots,{end},x\) equals \({multiplier}x\). Find \(x\).',
      lambda n,k:F(n*(n+1)//2,k*(n+1)-1),reference=lambda n,k:F(sum(range(1,n+1)),k*(n+1)-1))

_bind('r839','cesaro_prepend','length average prefix',(99,1000,1),(I(2,500),I(-3000,3000),I(-100,100)),
      r'The Cesaro sum of a sequence is the arithmetic mean of its nonempty prefix sums. '
      r'A sequence of length {length} has Cesaro sum {average}. What is the Cesaro sum after prepending {prefix}?',
      lambda n,s,a:a+F(n*s,n+1))

_bind('r906','layered_candle','height rate fraction',(119,10,2),(I(2,500),I(1,300),I(2,12)),
      r'A candle is {height} cm tall. Its \(k\)th centimeter from the top burns at a constant rate and takes \({rate}k\) seconds. '
      r'What is its height in centimeters after \(1/{fraction}\) of its total burning time has elapsed?',
      lambda n,r,d:n-(k:=(isqrt(1+4*(n*(n+1)//d))-1)//2)-F(n*(n+1)-d*k*(k+1),2*d*(k+1)))


def _collatz_reference(n):
    count = 0
    for start in range(1,n+1):
        x = start
        for _ in range(3):
            x = x//2 if x%2==0 else 3*x+1
            if x<=start:
                break
        else:
            count += 1
    return count


_bind('r169','collatz_initial_increase','limit',(2008,),(I(3,20000),),
      r'Start with a positive integer \(a_1\le {limit}\). Each next term halves the preceding term if it is even and triples it then adds \(1\) if it is odd. For how many starts do \(a_2,a_3,a_4\) all exceed \(a_1\)?',
      lambda n:(n+1)//4,reference=_collatz_reference)


for _key,_a,_b,_mode in (
    ('r864',13,2,'conjugate'), ('s689',5,2,'power'),
    ('s788',6,4,'quotient'), ('s862',7,4,'product'),
    ('s299',2,5,'sum'), ('s792',2,5,'difference'),
):
    _prompts = {
        'power': r'If \(|z|={a}\), find \(|\overline{{z}}^{{{b}}}|\).',
        'quotient': r'If \(|z|={a}\) and \(|w|={b}\), find \(|z/w|\).',
        'product': r'If \(|z|={a}\) and \(|w|={b}\), find \(|zw|\).',
        'sum': r'If \(|z|={a}\) and \(|w|={b}\), find the largest possible value of \(|z+w|\).',
        'difference': r'If \(|z|={a}\) and \(|w|={b}\), find the smallest possible value of \(|w-z|\).',
    }
    if _mode == 'conjugate':
        _bind(_key,'complex_conjugate_product','radius',(_a,),(I(1,100),),
              r'If \(|z|={radius}\), find \(z\overline{{z}}\).',lambda a:a*a)
        continue
    _solvers = {'power':pow, 'quotient':F, 'product':lambda a,b:a*b,
                'sum':lambda a,b:a+b, 'difference':lambda a,b:abs(b-a)}
    _bind(_key,'complex_modulus_'+_mode,'a b',(_a,_b),(I(1,100),I(1,16 if _mode=='power' else 100)),
          _prompts[_mode],_solvers[_mode])


for _key,_a,_b in (('s105',5,-12),('r61',780,1040)):
    _bind(_key,'complex_coordinate_norm','real imaginary',(_a,_b),(I(1,3000),I(-3000,3000)),
          (r'Find the magnitude of the complex number \(({real})+({imaginary})i\).' if _key=='s105'
           else r'A distance-preserving map of America places Los Angeles at the origin and Knoxville at \(({real})+({imaginary})i\) in the complex plane. How far apart are they?'),
          lambda a,b:isqrt(a*a+b*b),
          valid=lambda p:p['imaginary']!=0 and _square(p['real']**2+p['imaginary']**2),
          sample=lambda r:{'real':(p:=_pythagorean_sample(r,'real','imaginary',scale=6))['real'],
                           'imaginary':p['imaginary']*r.choice([-1,1])},
          constraints=('Both coordinates are nonzero and their sum of squares is a perfect square.',))


for _key,_a,_radicand in (('r1053',6,100),('r1109',-4,52),('r1112',3,90)):
    _bind(_key,'unknown_imaginary_coordinate','real norm_squared',(_a,_radicand),(I(-250,250),I(2,100000)),
          r'For what positive value of \(t\) is \(|({real})+ti|=\sqrt{{{norm_squared}}}\)?',
          lambda a,n:isqrt(n-a*a),
          valid=lambda p:p['real']!=0 and p['norm_squared']>p['real']**2 and _square(p['norm_squared']-p['real']**2),
          sample=lambda r:{'real':(a:=r.choice([-1,1])*r.randint(1,250)), 'norm_squared':a*a+r.randint(1,150)**2},
          constraints=('The real part is nonzero and the squared norm minus its square is a positive perfect square.',))


for _key,_a,_b,_c in (('r980',2,3,4),('s32',3,7,1)):
    _bind(_key,'imaginary_coordinate_count','real radius denominator',(_a,_b,_c),(I(1,80),I(1,80),I(1,20)),
          r'For how many real values of \(c\) is \(\left|{real}/{denominator}-ci\right|={radius}/{denominator}\)?',
          lambda a,b,_:0 if a>b else 1 if a==b else 2)


_bind('r563','pure_imaginary_product','real imag',(2,7),(I(1,120),I(1,120)),
      r'If \(a,b\) are nonzero reals and \(({real}-{imag}i)(a+bi)\) is purely imaginary, find \(a/b\).',
      lambda a,b:F(-b,a))

_bind('r582','complex_reciprocal_sum','first second resultant',(1,3,2),(I(1,80),I(1,80),I(1,160)),
      r'If \(|z|={first}\), \(|w|={second}\), and \(|z+w|={resultant}\), find \(\left|1/z+1/w\right|\).',
      lambda a,b,c:F(c,a*b),
      valid=lambda p:abs(p['first']-p['second'])<=p['resultant']<=p['first']+p['second'],
      sample=lambda r:{'first':(a:=r.randint(1,80)),'second':(b:=r.randint(1,80)),
                       'resultant':r.randint(max(1,abs(a-b)),a+b)},
      constraints=('The given resultant satisfies the triangle and reverse triangle inequalities.',))

_bind('r28','mobius_circle_identity','radius',(1,),(I(1,50),),
      r'Let \(\alpha,\beta\) be complex numbers, with \(|\beta|={radius}\) and \({radius}^2-\overline{{\alpha}}\beta\ne0\). '
      r'Find the maximum value of \(\left|\frac{{\beta-\alpha}}{{{radius}^2-\overline{{\alpha}}\beta}}\right|\).',
      lambda a:F(1,a))


_bind('r93','reciprocal_pair_circle','radius',(1,),(I(1,60),),
      r'Let \(s\) be a real number with \(|s|<2\cdot {radius}\). If the complex number \(z\) satisfies \(z+{radius}^2/z=s\), find \(|z|\).',
      lambda a:a)

_bind('r951','complex_root_modulus_count','linear constant',(8,37),(I(-40,40),I(-80,600)),
      r'How many different values can \(|z|\) take if \(z^2-({linear})z+({constant})=0\)?',
      lambda b,c:1 if b==0 or b*b<=4*c else 2)

_bind('s75','complex_even_norm_power','real imaginary exponent',(1,-1,8),(I(1,30),I(-30,-1),I(2,40)),
      r'Compute \(\left|(({real})+({imaginary})i)^{{{exponent}}}\right|\).',
      lambda a,b,e:(a*a+b*b)**(e//2),
      valid=lambda p:p['exponent']%2==0,
      sample=lambda r:{'real':r.randint(1,30),'imaginary':-r.randint(1,30),'exponent':2*r.randint(1,20)},
      constraints=('The exponent is even.',))


def _max_quadratic_ratio(a,b,c,d):
    peak = 1+F(4*a*d,4*a*c-b*b)
    return peak.numerator//peak.denominator


_bind('r271','quadratic_ratio_integer_max','leading linear constant gap',
      (3,9,7,10),(I(1,30),I(-80,80),I(1,1700),I(1,300)),
      r'Over real \(x\), what is the largest integer value attained by '
      r'\(\frac{{{leading}x^2+({linear})x+({constant})+{gap}}}{{{leading}x^2+({linear})x+({constant})}}\)?',
      _max_quadratic_ratio,
      valid=lambda p:0<4*p['leading']*p['constant']-p['linear']**2<=4*p['leading']*p['gap'],
      sample=lambda r:{'leading':(a:=r.randint(1,30)), 'linear':(b:=r.randint(-80,80)),
                       'gap':(d:=r.randint(1,100)), 'constant':r.randint(b*b//(4*a)+1,b*b//(4*a)+d)},
      constraints=('The denominator is always positive and its minimum is at most the numerator gap, so an integer of at least 2 is attained.',))

_bind('r272','double_root_parameter_sum','leading offset constant',(4,8,9),(I(1,100),I(-120,120),I(1,200)),
      r'There are two values of \(a\) for which \({leading}x^2+ax+({offset})x+{constant}=0\) has exactly one real root. Find their sum.',
      lambda a,b,c:-2*b)

_bind('r311','shifted_polynomial_coefficient_sum','a b c shift',(2,-1,7,4),(I(1,40),I(-50,50),I(-90,90),I(-50,50)),
      r'Shift the graph of \(y={a}x^2+({b})x+({c})\) horizontally by signed displacement {shift} (positive to the right). Find the sum of the coefficients of the resulting quadratic.',
      lambda a,b,c,d:a*(1-d)**2+b*(1-d)+c,
      reference=lambda a,b,c,d:sum((a,b-2*a*d,a*d*d-b*d+c)))

_bind('r863','slant_asymptote_coefficients','a b c root',(2,3,-7,3),(I(1,40),I(-80,80),I(-80,80),I(-30,30)),
      r'If the slant asymptote of \(y=\frac{{{a}x^2+({b})x+({c})}}{{x-({root})}}\) is \(y=mx+b\), find \(m+b\).',
      lambda a,b,c,r:a+b+a*r)

_bind('r806','horizontal_asymptote_ratio','a b c d e f g h i j',
      (12,4,9,5,3,3,2,8,3,1),(I(1,80),I(-20,20),I(-20,20),I(-20,20),I(-20,20),
                               I(1,80),I(-20,20),I(-20,20),I(-20,20),I(-20,20)),
      r'Find the horizontal asymptote of \(y=\frac{{{a}x^4+({b})x^3+({c})x^2+({d})x+({e})}}{{{f}x^4+({g})x^3+({h})x^2+({i})x+({j})}}\). Give its \(y\)-coordinate.',
      lambda a,b,c,d,e,f,g,h,i,j:F(a,f))

_bind('s81','horizontal_asymptote_lower_numerator','a b c d e f g',
      (27,9,3,27,9,3,1),(I(1,80),I(-20,20),I(-20,20),I(1,80),I(-20,20),I(-20,20),I(-20,20)),
      r'Find the \(y\)-coordinate of the horizontal asymptote of \(y=\frac{{{a}x^2+({b})x+({c})}}{{{d}x^3+({e})x^2+({f})x+({g})}}\).',
      lambda *args:0)

_bind('s204','removable_pole_multiplicity','numerator other pole multiplicity',
      (-3,1,7,5),(I(-20,-1),I(0,4),I(5,40),I(1,40)),
      r'For how many positive integers \(n\) does the graph of \(y=\frac{{(x-({numerator}))(x-{pole})^{{{multiplicity}}}}}{{(x-{other})(x-{pole})^n}}\) have a hole at \(x={pole}\)?',
      lambda a,b,c,n:n,
      reference=lambda a,b,c,n:sum(k<=n for k in range(1,2*n+1)))

_bind('r754','vieta_cancellation','first second',(3,-2),(I(2,80),I(-79,-1)),
      r'Two roots of \(ax^3+bx^2+cx+d=0\), with \(a\ne0\), are {first} and {second}. Given that these roots sum to 1, find \((b+c)/a\).',
      lambda a,b:a*b-1, valid=lambda p:p['first']+p['second']==1,
      sample=lambda r:{'first':(a:=r.randint(2,80)),'second':1-a},
      constraints=('The two specified roots sum to 1, eliminating dependence on the third root.',))

_bind('s399','translated_cubic_root_sum','quadratic linear constant shift',
      (-49,623,-2015,5),(I(-80,80),I(-1000,1000),I(-4000,4000),I(-30,30)),
      r'Let \(f(x)=x^3+({quadratic})x^2+({linear})x+({constant})\), and \(g(x)=f(x+({shift}))\). Find the sum of all complex roots of \(g\), counted with multiplicity.',
      lambda a,b,c,d:-a-3*d,
      adaptation='The sum is explicitly over complex roots counted with multiplicity, as in Vieta’s formula.')

_bind('r1132','quadratic_roots_peak','left right peak',(-2,4,54),(I(-60,0),I(2,60),I(1,400)),
      r'The quadratic \(y=ax^2+bx+c\) has maximum {peak} and passes through \(({left},0)\) and \(({right},0)\). Find \(a+b+c\).',
      lambda l,r,p:F(-4*p*(1-l)*(1-r),(r-l)**2))

_bind('r1170','parabola_diagonal_vertex','intercept vertex',(1,1),(I(-20,20),I(-20,20)),
      r'A parabola \(y=ax^2+bx+c\) has vertex \((p,{vertex}p)\) and \(y\)-intercept \((0,-({intercept})p)\), where \(p\ne0\). Find \(b\).',
      lambda c,v:2*(c+v),
      valid=lambda p:p['intercept']+p['vertex']!=0,
      sample=lambda r:{'intercept':(c:=r.randint(-20,20)), 'vertex':r.choice([v for v in range(-20,21) if v!=-c])},
      constraints=('The two height multipliers give different heights for nonzero p.',))

_bind('r110','quadratic_linear_continuity','quadratic vertical slope intercept',
      (1,2,2,5),(I(1,20),I(-20,20),I(-80,80),I(-80,160)),
      r'Let \(f(x)={quadratic}x^2+({vertical})\) if \(x<n\), and \(f(x)=({slope})x+({intercept})\) if \(x\ge n\). '
      r'Find the sum of all possible values of \(n\) for which \(f\) is continuous.',
      lambda a,b,c,d:F(c,a),
      valid=lambda p:p['slope']**2>4*p['quadratic']*(p['vertical']-p['intercept']),
      sample=lambda r:{'quadratic':r.randint(1,20),'vertical':(b:=r.randint(-20,20)),
                       'slope':r.randint(-80,80),'intercept':r.randint(b+1,160)},
      constraints=('The matching quadratic has strictly positive discriminant.',))

_bind('s273','linear_piecewise_continuity','first_slope first_constant second_slope second_constant',
      (4,3,7,-12),(I(-40,40),I(-100,100),I(-40,40),I(-100,100)),
      r'Let \(f(x)=({first_slope})x+({first_constant})\) for \(x<a\), and \(f(x)=({second_slope})x+({second_constant})\) for \(x\ge a\). '
      r'Find \(a\) so that \(f\) is continuous.',
      lambda a,b,c,d:F(d-b,a-c),
      valid=lambda p:p['first_slope']!=p['second_slope'],
      sample=lambda r:{'first_slope':(a:=r.randint(-40,40)), 'first_constant':r.randint(-100,100),
                       'second_slope':r.choice([c for c in range(-40,41) if c!=a]),
                       'second_constant':r.randint(-100,100)},
      constraints=('The slopes are distinct.',))

_bind('r53','inverse_and_reciprocal','slope intercept',(2,1),(I(1,50),I(-100,100)),
      r'Let \(f(x)={slope}x+({intercept})\). Find the sum of all real \(x\) satisfying \(f^{{-1}}(x)=f(1/x)\).',
      lambda a,b:(a+1)*b)


_bind('r570','recursive_range_max','threshold step offset',(10,5,10),(I(2,200),I(1,199),I(-90,90)),
      r'On positive integers, \(f(n)=n+({offset})\) for \(n<{threshold}\), and \(f(n)=f(n-{step})\) otherwise. Find the maximum value of \(f\).',
      lambda n,d,c:n-1+c,valid=lambda p:p['step']<p['threshold'],
      sample=lambda r:{'threshold':(n:=r.randint(2,200)), 'step':r.randint(1,n-1),'offset':r.randint(-90,90)},
      constraints=('The recursive step is smaller than the threshold, so every argument stays positive.',))

_bind('r262','common_factor_linear_value','constant multiplier',(5,2),(I(1,120),I(1,120)),
      r'If positive real \(x,y\) satisfy \({constant}x^2+{constant}\cdot {multiplier}xy=x^3+{multiplier}x^2y\), find \(x\).',
      lambda a,b:a)

_bind('r360','symmetric_system_power_sum','product weighted_sum',(6,63),(I(1,60),I(3,5000)),
      r'If real \(x,y\) satisfy \(xy={product}\) and \(x^2y+xy^2+x+y={weighted_sum}\), find \(x^2+y^2\).',
      lambda a,b:F(b,a+1)**2-2*a,
      valid=lambda p:p['weighted_sum']**2>=4*p['product']*(p['product']+1)**2,
      sample=lambda r:{'product':(a:=r.randint(1,60)),
                       'weighted_sum':r.randint(isqrt(4*a*(a+1)**2-1)+1,5000)},
      constraints=('The inferred sum and specified product yield a quadratic with real roots.',))

_bind('r69','real_triple_boundary_count','linear product',(2,1),(I(-100,100),I(-3000,3000)),
      r'How many ordered triples of real numbers \(x,y,z\) satisfy \(x+y={linear}\) and \(xy-z^2={product}\)? Enter 0 if there are none.',
      lambda a,b:int(a*a==4*b),
      valid=lambda p:4*p['product']>=p['linear']**2,
      sample=lambda r:{'linear':(a:=2*r.randint(-50,50)),
                       'product':a*a//4+r.choice([0,0,r.randint(1,400)])},
      constraints=('The prescribed product bound is at least one quarter of the squared sum, so the count is finite.',),
      adaptation='Explicitly allows answer zero when the constraints have no solution.')

_bind('r161','paired_radical_sum','large small difference',(49,25,3),(I(2,10000),I(1,10000),I(1,80)),
      r'If a real number \(x\) satisfies \(\sqrt{{{large}-x^2}}-\sqrt{{{small}-x^2}}={difference}\), find the sum of the two radicals.',
      lambda a,b,d:F(a-b,d),
      valid=lambda p:(d:=p['difference'])**2<= (gap:=p['large']-p['small'])
                    and (gap-d*d)**2<=4*d*d*p['small'],
      sample=lambda r:{'small':(b:=(v:=r.randint(1,35))**2+(s:=r.randint(0,2500))),
                       'difference':(d:=r.randint(1,45)), 'large':(v+d)**2+s},
      constraints=('The larger radicand constant exceeds the smaller by at least the square of the difference.',
                   'The inferred smaller radical does not exceed the square root of its radicand constant.'))

_bind('r945','sum_shifted_radicals','shift sum',(2,10),(I(1,900),I(2,100)),
      r'Find the real root of \(\sqrt x+\sqrt{{x+{shift}}}={sum}\).',
      lambda d,s:F(s*s-d,2*s)**2,
      valid=lambda p:p['shift']<=p['sum']**2,
      sample=lambda r:{'sum':(s:=r.randint(2,100)), 'shift':r.randint(1,min(900,s*s))},
      constraints=('The sum is at least the square root of the shift.',))

_bind('s852','difference_shifted_radicals','shift squared_difference',(7,3),(I(1,1200),I(1,1200)),
      r'Find \(x\), given that \(\sqrt{{x+{shift}}}-\sqrt x=\sqrt{{{squared_difference}}}\).',
      lambda d,s:F((d-s)**2,4*s),
      valid=lambda p:p['squared_difference']<=p['shift'],
      sample=lambda r:{'shift':(d:=r.randint(1,1200)), 'squared_difference':r.randint(1,d)},
      constraints=('The squared difference is at most the shift.',))

_bind('r367','reciprocal_root_sum','given_sum',(98,),(I(2,10000),),
      r'Let \(x>0\) satisfy \(x+1/x={given_sum}\). Find \(\sqrt x+1/\sqrt x\).',
      lambda n:isqrt(n+2),valid=lambda p:_square(p['given_sum']+2),
      sample=lambda r:{'given_sum':r.randint(2,100)**2-2},
      constraints=('The given sum plus 2 is a perfect square.',))

_bind('r1278','reciprocal_cube_difference','difference',(4,),(I(-100,100),),
      r'Given \(x-1/x={difference}\), find \(x^3-1/x^3\).',
      lambda n:n**3+3*n)

_bind('r1072','quadratic_radical_conjugates','sum product',(-4,1),(I(-60,60),I(-900,890)),
      r'The sum and product of \(a+\sqrt b\) and \(a-\sqrt b\) are respectively {sum} and {product}. Find \(a+b\).',
      lambda s,p:F(s,2)+F(s,2)**2-p,
      valid=lambda p:4*p['product']<=p['sum']**2,
      sample=lambda r:{'sum':(s:=r.randint(-60,60)), 'product':r.randint(-900,min(890,s*s//4))},
      constraints=('The product does not exceed one quarter of the squared sum, so b is nonnegative.',))

_bind('s301','two_axis_lines_distance','horizontal vertical',(3,5),(I(-100,100),I(-100,100)),
      r'If real \(x,y\) satisfy \((x+({horizontal}))(y-({vertical}))=0\), find the minimum value of \(x^2+y^2\).',
      lambda a,b:min(a*a,b*b))

_bind('s853','linear_form_square_on_circle','radius_squared first second',(1,1,1),(I(1,250),I(1,50),I(1,50)),
      r'If \(x^2+y^2={radius_squared}\), find the maximum of \(({first}x+{second}y)^2\) over real \(x,y\).',
      lambda r,a,b:r*(a*a+b*b))

_bind('s737','linear_form_on_sphere','radius_squared first second third',
      (1,3,4,12),(I(1,10000),I(1,150),I(1,150),I(1,200)),
      r'If real \(x,y,z\) satisfy \(x^2+y^2+z^2={radius_squared}\), find the maximum of \({first}x+{second}y+{third}z\).',
      lambda r,a,b,c:isqrt(r*(a*a+b*b+c*c)),
      valid=lambda p:_square(p['radius_squared']*(p['first']**2+p['second']**2+p['third']**2)),
      sample=lambda r:_sample_integer_sphere(r),
      constraints=('The radius squared times the sum of squared linear coefficients is a perfect square.',))

_bind('s265','inscribed_rectangle_max','radius',(1,),(I(1,80),),
      r'A rectangle is inscribed in a circle of radius {radius}. Find its maximum possible area.',
      lambda r:2*r*r)

for _key,_n,_s,_kind in (('r790',12,1,'inverse'),('r802',2,10,'inverse'),
                        ('r1055',3,1,'inverse'),('s793',4,1,'min_squares'),
                        ('s801',12,1,'real_min_squares'),('s255',4,1,'max_squares')):
    _qs = {
        'inverse': ('positive real','minimum',r'1/a_1+\cdots+1/a_n',lambda n,s:F(n*n,s)),
        'min_squares': ('nonnegative real','minimum',r'a_1^2+\cdots+a_n^2',lambda n,s:F(s*s,n)),
        'real_min_squares': ('real','minimum',r'a_1^2+\cdots+a_n^2',lambda n,s:F(s*s,n)),
        'max_squares': ('nonnegative real','maximum',r'a_1^2+\cdots+a_n^2',lambda n,s:s*s),
    }
    _domain,_extreme,_expr,_solve = _qs[_kind]
    _bind(_key,'fixed_sum_'+_kind,'count total',(_n,_s),(I(2,50),I(1,160)),
          r'Let \(n={count}\), and let \(a_1,\ldots,a_n\) be '+_domain+
          r' numbers with sum {total}. Find the '+_extreme+r' of \('+_expr+r'\).',_solve)

_bind('s135','reciprocal_sum_product_min','count',(4,),(I(2,50),),
      r'For \(n={count}\), find the minimum of \((a_1+\cdots+a_n)(1/a_1+\cdots+1/a_n)\) over positive real \(a_1,\ldots,a_n\).',
      lambda n:n*n)

_bind('s692','complement_ratio_sum_min','count total',(4,1),(I(2,50),I(1,160)),
      r'Let \(n={count}\) and \(a_1,\ldots,a_n>0\) have sum \(S={total}\). Find the minimum of \(\sum_{{i=1}}^n a_i/(S-a_i)\).',
      lambda n,s:F(n,n-1))

_bind('r1070','minimum_dimension_quadratic_budget','sum bound_numerator bound_denominator',(1,1,100),
      (I(1,80),I(1,80),I(1,120)),
      r'Nonnegative reals \(x_1,\ldots,x_n\) have sum {sum} and their squares sum to at most \({bound_numerator}/{bound_denominator}\). Find the smallest positive integer \(n\) for which this is possible.',
      lambda s,a,b:(s*s*b+a-1)//a)

_bind('r296','sum_inverse_pair_sums','total',(1,),(I(1,160),),
      r'For positive real \(x,y,z\) with sum {total}, find the minimum of \(1/(x+y)+1/(x+z)+1/(y+z)\).',
      lambda s:F(9,2*s))

_bind('r773','sum_quadratic_pair_ratios','total',(6,),(I(1,160),),
      r'For positive real \(x,y,z\) with sum {total}, find the minimum of '
      r'\((x^2+y^2)/(x+y)+(x^2+z^2)/(x+z)+(y^2+z^2)/(y+z)\).',
      lambda s:s)

_bind('r988','sum_cyclic_reciprocals','total weight',(1,2),(I(1,160),I(1,120)),
      r'For positive real \(a,b,c\) with sum {total}, find the minimum of \(1/(a+{weight}b)+1/(b+{weight}c)+1/(c+{weight}a)\).',
      lambda s,k:F(9,s*(k+1)))

_bind('r759','cubic_sum_on_sphere','radius dimension',(2,4),(I(1,100),I(2,30)),
      r'Let \(n={dimension}\). If the real numbers \(a_1,\ldots,a_n\) satisfy \(\sum_{{i=1}}^n a_i^2={radius}^2\), find the maximum of \(\sum_{{i=1}}^n a_i^3\).',
      lambda r,n:r**3)

_bind('r194','simplex_power_max','total first_power second_power',(1,2,3),(I(1,60),I(2,12),I(2,12)),
      r'Nonnegative real numbers \(x,y,z\) satisfy \(x+y+z={total}\). Find the maximum of \(x+y^{{{first_power}}}+z^{{{second_power}}}\).',
      lambda s,a,b:s**max(a,b))

_bind('r878','symmetric_product_with_cancelled_term','linear_coefficient',(1,),(I(1,100),),
      r'Let \(x,y,z\) be positive real numbers such that \(xy+{linear_coefficient}z=(x+z)(y+z)\). Find the maximum of \(xyz\).',
      lambda s:F(s**3,27))

_bind('r835','integer_simplex_product','total',(12,),(I(0,180),),
      r'Nonnegative integers \(A,M,C\) sum to {total}. Find the maximum of \(AMC+AM+MC+CA\).',
      lambda n:(q:=n//3)**3+3*q*q+(n%3)*(q*q+2*q)+(n%3==2)*(q+1),
      reference=lambda n:max(a*b*(n-a-b)+a*b+(a+b)*(n-a-b)
                             for a in range(n+1) for b in range(n-a+1)))

_bind('r403','rectangle_rational_max','xlo xhi ylo yhi',(-4,-2,2,4),(I(-150,-2),I(-149,-1),I(1,149),I(2,150)),
      r'For \({xlo}\le x\le{xhi}\) and \({ylo}\le y\le{yhi}\), find the maximum of \((x+y)/x\).',
      lambda a,b,c,d:1+F(c,a),
      valid=lambda p:p['xlo']<p['xhi'] and p['ylo']<p['yhi'],
      sample=lambda r:{'xlo':(a:=r.randint(-150,-2)),'xhi':r.randint(a+1,-1),
                       'ylo':(c:=r.randint(1,149)), 'yhi':r.randint(c+1,150)},
      constraints=('The two intervals have strictly ordered endpoints.',),reference=lambda a,b,c,d:max(F(x+y,x) for x in (a,b) for y in (c,d)))


_bind('r718','weighted_ratio_square_max','xweight yweight',(1,1),(I(1,50),I(1,50)),
      r'For positive real \(x,y\), find the maximum of \(({xweight}x+{yweight}y)^2/(x^2+y^2)\).',
      lambda a,b:a*a+b*b)

_bind('r628','sum_and_reciprocal_min','numerator reciprocal_weight',(1,1),(I(1,100),I(1,400)),
      r'For \(x>0\), find the minimum of \(x+{numerator}/x+{reciprocal_weight}/(x+{numerator}/x)\).',
      lambda a,b:2*isqrt(b) if b>=4*a else 2*isqrt(a)+F(b,2*isqrt(a)),
      valid=lambda p:_square(p['reciprocal_weight']) if p['reciprocal_weight']>=4*p['numerator']
                    else _square(p['numerator']),
      sample=lambda r:{'numerator':(a:=r.randint(1,10)**2),'reciprocal_weight':r.randint(1,4*a-1)}
                     if r.randrange(2) else {'numerator':(a:=r.randint(1,100)),
                        'reciprocal_weight':r.randint(isqrt(4*a-1)+1,20)**2},
      constraints=('If the weight is at least four times the numerator, the weight is a perfect square. Otherwise the numerator is a perfect square.',))

_bind('s80','geometric_series_second_term_min','second',(1,),(I(1,200),),
      r'A convergent infinite geometric series has positive sum \(S\) and second term {second}. Find the minimum possible \(S\).',
      lambda a:4*a)

_bind('s176','period_two_series','base first second',(7,1,2),(I(2,50),I(-90,90),I(-90,90)),
      r'Find \({first}/{base}+({second})/{base}^2+({first})/{base}^3+({second})/{base}^4+\cdots\), with coefficients alternating periodically.',
      lambda b,a,c:F(a*b+c,b*b-1))

_bind('s626','index_weighted_geometric_sum','base',(10,),(I(2,90),),
      r'Find the sum of \(\sum_{{n=1}}^\infty n/{base}^n\).',
      lambda b:F(b,(b-1)**2))

_bind('s139','arithmetic_weighted_geometric_sum','first step base',(1,2,3),(I(1,60),I(1,60),I(2,50)),
      r'Find \(\sum_{{k=0}}^\infty ({first}+{step}k)/{base}^k\).',
      lambda a,d,b:F(a*b,b-1)+F(d*b,(b-1)**2))

_bind('s267','reciprocal_arithmetic_recurrence','initial increment index',(6,1,100),(I(1,50),I(1,30),I(1,2000)),
      r'Let \(a_0={initial}\), and for \(n\ge1\) let \(a_n=a_{{n-1}}/(1+{increment}a_{{n-1}})\). Find \(a_{{{index}}}\).',
      lambda a,d,n:F(a,1+d*n*a),
      reference=lambda a,d,n:_iterative_reciprocal(a,d,n))


def _iterative_reciprocal(a,d,n):
    a = F(a)
    for _ in range(n):
        a = a/(1+d*a)
    return a


_bind('s60','alternating_reciprocal_recurrence_product','initial count',(97,8),(I(1,500),I(2,100)),
      r'Let \(x_1={initial}\) and \(x_n=n/x_{{n-1}}\) for \(n>1\). Find \(x_1x_2\cdots x_{{{count}}}\).',
      lambda a,n:prod(range(2,n+1,2)) if n%2==0 else a*prod(range(3,n+1,2)),
      reference=lambda a,n:_reciprocal_product(a,n))


def _reciprocal_product(a,n):
    x = total = F(a)
    for k in range(2,n+1):
        x = k/x
        total *= x
    return total


_bind('s249','telescope_integrality','minimum maximum',(2,2010),(I(2,300),I(2,5000)),
      r'For how many integers \(n\) with \({minimum}\le n\le {maximum}\) is \(\prod_{{k=2}}^n(1+1/k)\) an integer?',
      lambda a,b:(b+1)//2-a//2,
      valid=lambda p:p['minimum']<=p['maximum'],
      sample=lambda r:{'minimum':(a:=r.randint(2,300)), 'maximum':r.randint(a,5000)},
      constraints=('The minimum does not exceed the maximum.',),
      reference=lambda a,b:sum((n+1)%2==0 for n in range(a,b+1)))

_bind('r844','weighted_cards_mean_inversion','average',(2017,),(I(3,9999),),
      r'A collection contains exactly \(k\) cards marked \(k\) for every integer \(1\le k\le n\), and no others. If their mean is {average}, find \(n\).',
      lambda a:(3*a-1)//2,
      valid=lambda p:p['average']%2==1,
      sample=lambda r:{'average':2*r.randint(1,4999)+1},
      constraints=('The integer mean is odd, so the implied number of labels is integral.',))

_bind('s476','piecewise_tent_max','first_slope second_slope cutoff',(2,2,2),(I(1,50),I(1,50),I(1,50)),
      r'Let \(f(x)={first_slope}x\) for \(0\le x<{cutoff}\), and \(f(x)={first_slope}\cdot {cutoff}-{second_slope}(x-{cutoff})\) for \({cutoff}\le x\le2\cdot {cutoff}\). Find the maximum of \(f\).',
      lambda a,b,c:a*c)

_bind('r127','piecewise_rational_evaluation','threshold first_x first_y second_x second_y',
      (3,2,1,2,4),(I(2,80),I(1,70),I(1,70),I(1,70),I(1,70)),
      r'Define \(f(a,b)=(ab-a+2)/(2a)\) if \(a+b\le {threshold}\) and \(f(a,b)=(ab-b-2)/(-2b)\) otherwise. '
      r'Find \(f({first_x},{first_y})+f({second_x},{second_y})\).',
      lambda t,a,b,c,d:_piecewise_value(t,a,b)+_piecewise_value(t,c,d))


def _piecewise_value(t,a,b):
    return F(a*b-a+2,2*a) if a+b<=t else F(a*b-b-2,-2*b)


_bind('r1049','integer_reciprocal_objective','linear_denominator numerator',(2,18),(I(1,100),I(1,4000)),
      r'For which positive integer \(n\) does \(n/{linear_denominator}+{numerator}/n\) attain its minimum?',
      lambda d,a:isqrt(d*a)+(d*a>isqrt(d*a)*(isqrt(d*a)+1)),
      valid=lambda p:(m:=isqrt(v:=p['linear_denominator']*p['numerator']))*(m+1)!=v,
      sample=lambda r:{'linear_denominator':(d:=r.randint(1,50)),
                       'numerator':r.choice([a for a in range(1,201)
                                             if (m:=isqrt(a*d))*(m+1)!=a*d])},
      constraints=('The product of the coefficients shown is not the product of two consecutive positive integers, avoiding a tie.',),
      reference=lambda d,a:min(range(1,isqrt(d*a)+2),key=lambda n:F(n,d)+F(a,n)))


def _sample_integer_sphere(rng):
    if rng.randrange(2):
        a,b,c = (rng.randint(1,50) for _ in range(3))
        radius_squared = a*a+b*b+c*c
    else:
        u = rng.randint(3,8)
        v,w = rng.randint(1,u//2), rng.randint(1,u//2)
        coefficients = [2*u*v,2*u*w,u*u-v*v-w*w]
        rng.shuffle(coefficients)
        a,b,c = coefficients
        radius_squared = rng.randint(1,100)**2
    return dict(radius_squared=radius_squared,first=a,second=b,third=c)
