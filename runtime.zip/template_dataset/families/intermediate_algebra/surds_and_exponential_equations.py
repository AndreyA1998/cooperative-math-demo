"""Surds and exponential equations; exact source-bound mathematical models."""
from fractions import Fraction as F
from math import isqrt

from template_dataset.families.algebra.real_roots import divisors
from template_dataset.families.construction import is_square, sqrt_fraction
from template_dataset.families.intermediate_algebra.real_equations_and_sequence_constraints import nth_floor
from template_dataset.families.intermediate_algebra.callable_bindings import I, bind, tex


def denest_cubed(a,b,d):
    diff=a*a-b*b*d
    if diff<=0 or not is_square(diff) or is_square(d):
        raise ValueError('Expected distinct positive conjugate radicands')
    u=F(a-isqrt(diff),2)
    v=F(a+isqrt(diff),2)
    if u<=0 or not is_square(u) or is_square(v):
        raise ValueError('Expected a rational smaller component and an irrational larger component')
    return 2*sqrt_fraction(u)*(u+3*v)


def denest_cubed_valid(*args):
    try:
        denest_cubed(*args)
    except ValueError:
        return False
    return True


def denest_cubed_sample(rng):
    u,v=rng.randint(1,7),rng.randint(1,5)
    d=rng.choice([j for j in range(2,80) if not is_square(j) and v*v*j>u*u])
    return u*u+v*v*d,2*u*v,d


bind('t559','difference_of_cubed_conjugate_surds','constant coefficient radicand',(52,6,43),
     (I(1,5000),I(1,500),I(2,100)),
     lambda a,b,d:rf'Find $({a}+{b}\sqrt{{{d}}})^{{3/2}}-({a}-{b}\sqrt{{{d}}})^{{3/2}}$.',
     denest_cubed,valid=denest_cubed_valid,sample=denest_cubed_sample,
     constraints=('The two conjugates are distinct positive squares of the form (v±u)² with 0<u<v, u rational and v an irrational square root of a rational.',))


def denest_difference(a,b):
    a,b=F(a),F(b)
    if b<=0 or a<=0 or a*a<b:
        raise ValueError('Nonnegative nested radicals required')
    return -sqrt_fraction(2*a-2*sqrt_fraction(a*a-b))


def denest_difference_valid(*args):
    try:
        denest_difference(*args)
    except ValueError:
        return False
    return True


def denest_difference_sample(rng):
    k,s=rng.randint(1,15),rng.randint(2,15)
    d=rng.randint(k*k+1,k*k+100)
    return str(F(k*k+d,s*s)),str(F(4*k*k*d,s**4))


bind('t858','difference_of_nested_square_roots','outer inner',('3/4','1/2'),
     ({'type':'rational','min':0,'max':1000},)*2,
     lambda a,b:rf'Express in simplest form $\sqrt{{{tex(a)}-\sqrt{{{tex(b)}}}}}-\sqrt{{{tex(a)}+\sqrt{{{tex(b)}}}}}$.',
     denest_difference,valid=denest_difference_valid,sample=denest_difference_sample,
     constraints=('The two nested radicals are real and the square of their difference is a rational square.',))


def radical_expansion(a,b,c,d):
    x=sqrt_fraction(F(a*b,2*c))
    y=sqrt_fraction(F(a*c,2*b))
    z=sqrt_fraction(F(b*c,2*a))
    if any(t.denominator!=1 for t in (x,y,z)) or 2*x*x+3*y*y+5*z*z!=d:
        raise ValueError('Expected a positive integral decomposition')
    return x*y*z


def radical_expansion_valid(*args):
    try:
        radical_expansion(*args)
    except ValueError:
        return False
    return True


def radical_expansion_sample(rng):
    x,y,z=[rng.randint(1,22) for _ in range(3)]
    return 2*x*y,2*x*z,2*y*z,2*x*x+3*y*y+5*z*z


bind('t775','three_surd_coefficients_from_squared_expansion','p q r constant',(104,468,144,2006),
     (I(1,2000),)*3+(I(1,8000),),
     lambda p,q,r,c:rf'Write $\sqrt{{{p}\sqrt6+{q}\sqrt{{10}}+{r}\sqrt{{15}}+{c}}}=a\sqrt2+b\sqrt3+c\sqrt5$ for positive integers $a,b,c$. Find $abc$.',
     radical_expansion,valid=radical_expansion_valid,sample=radical_expansion_sample,
     constraints=('There is a decomposition with three positive integer coefficients, verified by squaring.',))


bind('t785','cubic_surd_product','radicand',(2,), (I(2,500),),
     lambda n:rf'Evaluate $(\sqrt[3]{{{n}^2}}+\sqrt[3]{{{n}}})({n}-{n}\sqrt[3]{{{n}}}-\sqrt[3]{{{n}^2}})$.',
     lambda n:-n*(n+1))


bind('t800','nearest_integer_of_central_fourth_root_difference','base offset',(5,1),
     (I(4,100),I(1,20000)),
     lambda b,d:rf'Find the nearest integer to $\frac{{1}}{{\sqrt[4]{{{b}^4+{d}}}-\sqrt[4]{{{b}^4-{d}}}}}$.',
     lambda b,d:2*b**3//d,
     valid=lambda b,d:d<b**4 and 2*b**3%d==0,
     sample=lambda r:(lambda b:(b,r.choice([d for d in divisors(2*b**3) if d<=20000])))(r.randint(4,40)),
     constraints=('The offset is less than the fourth power and divides twice the cube of the base.',))


def exponential_difference_root(a,b,c):
    for n in range(1,20):
        if b**n-a**(2*n)==c:
            return n
    raise ValueError('Expected a positive integer solution in range')


def exponential_difference_valid(a,b,c):
    if b<=a*a:
        return False
    try:
        exponential_difference_root(a,b,c)
    except ValueError:
        return False
    return True


def exponential_difference_sample(rng):
    a,n=rng.randint(2,8),rng.randint(1,5)
    b=rng.randint(a*a+1,a*a+20)
    return a,b,b**n-a**(2*n)


bind('t497','solve_positive_difference_of_exponentials','a b constant',(3,10,19),
     (I(2,15),I(2,250),I(1,10**10)),
     lambda a,b,c:rf'Solve $ {a}^{{2x}}+{c}={b}^x$ for real $x$.',
     exponential_difference_root,valid=exponential_difference_valid,sample=exponential_difference_sample,
     constraints=('The second base exceeds the square of the first, and a positive integer solution less than 20 exists.',))


bind('t515','zeros_of_difference_quotient_operator','exponent operand',(3,1),
     (I(2,30),I(-100,100)),
     lambda n,b:rf'If $a@b=(a^{{{n}}}-b^{{{n}}})/(a-b)$, for how many real values of $a$ does $a@({b})=0$?',
     lambda n,b:int(n%2==0 and b!=0))


def geometric_log_mean_sample(rng):
    p,q,k=[rng.randint(1,15) for _ in range(3)]
    return rng.randint(2,25),k*p**4,k*q**4


bind('t42','arithmetic_progression_of_five_logs','base first last',(12,162,1250),
     (I(2,100),I(1,1000000),I(1,1000000)),
     lambda b,a,c:rf'The sequence $\log_{{{b}}}{a},\log_{{{b}}}x,\log_{{{b}}}y,\log_{{{b}}}z,\log_{{{b}}}{c}$ is arithmetic. Find $x$.',
     lambda b,a,c:nth_floor(a**3*c,4),
     valid=lambda b,a,c:nth_floor(a**3*c,4)**4==a**3*c,sample=geometric_log_mean_sample,
     constraints=('The cube of the first argument times the last argument is an integer fourth power.',))


def norm_power(a,b,n):
    return nth_floor(a*a+b*b,2*n)


def norm_power_sample(rng):
    # Raise a small Gaussian integer to n and retain only rational norms.
    u,v=rng.choice([(3,4),(5,12),(4,3),(8,15),(0,2)])
    n=rng.randint(2,5)
    a,b=1,0
    for _ in range(n):
        a,b=a*u-b*v,a*v+b*u
    return a,b,n


bind('t323','modulus_from_complex_power','real imag exponent',(100,75,3),
     (I(-2000000,2000000),I(-2000000,2000000),I(2,18)),
     lambda a,b,n:rf'Suppose $z^{{{n}}}={a}{b:+}i$ for a complex number $z$. Find $|z|$.',
     norm_power,valid=lambda a,b,n:norm_power(a,b,n)**(2*n)==a*a+b*b,
     sample=norm_power_sample,
     constraints=('The sum of the squares of the given real and imaginary parts is a perfect 2·exponent power.',))


def arithmetic_surd_reduction(a,b,c):
    # Set y=(c+sqrt(x))^(1/3) and specialize b-c=a².
    # After squaring, y²(y²-y-2a)=0 with y²≥a.
    y=F(1+isqrt(1+8*a),2)
    return (y**3-c)**2


def arithmetic_surd_valid(a,b,c):
    if b-c!=a*a or not is_square(1+8*a):
        return False
    y=F(1+isqrt(1+8*a),2)
    return y**3>=c and y*y>=a


def arithmetic_surd_sample(rng):
    k=rng.randint(2,10)
    a=k*(k-1)//2
    c=rng.randint(1,k**3)
    return a,c+a*a,c


bind('r1036','nested_radical_reduction_to_quadratic','outer inner right',(1,2,1),
     (I(1,70),I(1,4000),I(1,1000)),
     lambda a,b,c:rf'Solve $\sqrt{{{a}+\sqrt{{{b}+\sqrt x}}}}=\sqrt[3]{{{c}+\sqrt x}}$.',
     arithmetic_surd_reduction,valid=arithmetic_surd_valid,sample=arithmetic_surd_sample,
     constraints=('The inner minus right constant is the square of the outer constant; 1+8·outer is a square, and the positive quadratic root satisfies both radical sign constraints.',))


def normalized_symmetric_cubic_powers(a,b):
    # For p=xy and s=x+y: a=p^4*s, b=p^3*(s^3-3*p*s).
    ratio=3+F(b,a)
    cube=F(a*a,ratio)
    n,d=nth_floor(cube.numerator,3),nth_floor(cube.denominator,3)
    if ratio<4 or F(n,d)**3!=cube:
        raise ValueError('Expected a feasible pair and rational (xy)^3')
    p3=F(n,d)
    return p3+2*F(b,p3)


def normalized_symmetric_valid(a,b):
    try:
        normalized_symmetric_cubic_powers(a,b)
    except ValueError:
        return False
    return True


def normalized_symmetric_sample(rng):
    x,y=rng.randint(1,20),rng.randint(1,20)
    return (x*y)**4*(x+y),(x*y)**3*(x**3+y**3)


bind('t43','symmetric_high_degree_system_cubic_value','first second',(810,945),
     (I(1,10**13),)*2,
     lambda a,b:rf'For real $x,y$ with $x^4y^5+y^4x^5={a}$ and $x^3y^6+y^3x^6={b}$, evaluate $2x^3+(xy)^3+2y^3$.',
     normalized_symmetric_cubic_powers, valid=normalized_symmetric_valid,sample=normalized_symmetric_sample,
     constraints=('3+second/first ≥ 4, and first²/(3+second/first) is a rational cube.',))


def reciprocal_power_reduction(s,power):
    # Return coefficients in 1 and T for T²=s, T=r+1/r.
    before,current=(2,0),(0,1)
    for _ in range(1,power):
        before,current=current,(s*current[1]-before[0],current[0]-before[1])
    return current


bind('r1147','reciprocal_power_with_given_square_of_trace','square exponent',(3,3),
     (I(0,100),I(2,60)),
     lambda s,n:rf'Let $r$ be a nonzero complex number and suppose $(r+1/r)^2={s}$. Find $r^{{{n}}}+1/r^{{{n}}}$.',
     lambda s,n:reciprocal_power_reduction(s,n)[0],
     valid=lambda s,n:s==0 or reciprocal_power_reduction(s,n)[1]==0,
     sample=lambda r:(r.randint(0,100),2*r.randint(1,30)),
     constraints=('The reciprocal power sum is independent of the sign of the trace r+1/r.',),
     adaptation='The variable is explicitly complex, since the original square of the trace is below 4 and has no real solution.')


def positive_three_means(a,g,h):
    a,g,h=map(F,(a,g,h))
    return 3*a,3*g**3/h,g**3


def positive_means_valid(a,g,h):
    s,p,v=positive_three_means(a,g,h)
    return s*s*p*p-4*p**3-4*s**3*v-27*v*v+18*s*p*v>=0


def positive_means_sample(rng):
    x,y,z=[rng.randint(1,18) for _ in range(3)]
    nums=[x**3,y**3,z**3]
    return str(F(sum(nums),3)),x*y*z,str(3/sum(F(1,t) for t in nums))


bind('r1068','sum_of_squares_from_three_means','arithmetic geometric harmonic',(8,5,3),
     ({'type':'rational','min':1,'max':1000000},)*3,
     lambda a,g,h:rf'The arithmetic, geometric and harmonic means of positive numbers $a,b,c$ are $ {tex(a)}, {tex(g)}, {tex(h)}$, respectively. Find $a^2+b^2+c^2$.',
     lambda a,g,h:(lambda s,p,v:s*s-2*p)(*positive_three_means(a,g,h)),
     valid=positive_means_valid,sample=positive_means_sample,
     constraints=('The cubic determined by the three elementary symmetric sums has nonnegative discriminant. All means are positive, which then ensures positive roots.',),
     adaptation='The usual positive-number domain of the three means is stated explicitly.')


def closest_log_hundredth(a,b):
    # For k hundredths, use exact comparisons at the half-hundredths.
    target=b**200
    lo,hi=0,1000
    while hi-lo>1:
        mid=(lo+hi)//2
        if a**(2*mid-1)<=target:
            lo=mid
        else:
            hi=mid
    return lo


def log_approximation_sample(rng):
    a,b=rng.randint(2,80),rng.randint(2,80)
    return a,b,rng.randint(2,6),100+closest_log_hundredth(a,b)


bind('t328','log_ratio_rounded_by_exact_base_change','base factor power hundredths',(3,2,2,163),
     (I(2,100),I(2,100),I(2,8),I(100,1000)),
     lambda a,b,n,k:rf'If $\log_{{{a}}}{a*b}\approx {k//100}.{k%100:02d}$ to the nearest hundredth, what is $\log_{{{a**n}}}{b**n}$ accurate to two decimal places?',
     lambda a,b,n,k:F(k-100,100), sample=log_approximation_sample,
     valid=lambda a,b,n,k:k==100+closest_log_hundredth(a,b),
     constraints=('The stated approximation is the exact nearest-hundredth rounding.',),
     adaptation='The precision of the supplied approximation is made explicit.')
