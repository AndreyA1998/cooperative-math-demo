"""Symbolic invariants; exact source-bound mathematical models."""
from fractions import Fraction as F
from math import isqrt

from template_dataset.families.construction import is_square
from template_dataset.families.intermediate_algebra.callable_bindings import I, bind, polynomial


bind('r293','nonzero_difference_multiplicativity','point',(3,),(I(-500,500),),
     lambda a:rf'For a real function $f$ that never vanishes, suppose $f(x-y)=f(x)f(y)$ for all real $x,y$. Find $f({a})$.',
     lambda a:1)


bind('r547','nonzero_at_zero_multiplicativity','point',(10,),(I(-500,500),),
     lambda a:rf'For a real function $f$ with $f(0)\ne0$, suppose $f(xy)=f(x)f(y)$ for all real $x,y$. Find $f({a})$.',
     lambda a:1)


bind('r730','reciprocal_power_function','base',(2,),(I(2,100),),
     lambda b:rf'A real function satisfies $f({b}^x)+xf({b}^{{-x}})=1$ for all real $x$. Find $f({b})$.',
     lambda b:0)


def parity_recurrence(n):
    value=1
    for _ in range(1,n):
        value=1-value
    return value if n else 0


bind('r905','parity_from_additive_multiplicative_recurrence','point',(1986,),(I(0,5000),),
     lambda n:rf'For all nonnegative integers $a,b$, suppose $f(a+b)=f(a)+f(b)-2f(ab)$ and $f(1)=1$. Find $f({n})$.',
     lambda n:n%2,reference=parity_recurrence)


def exponential_function_sample(rng):
    q,m=rng.randint(2,9),rng.randint(1,5)
    return m,q**m,rng.randint(1,12)


bind('t371','additive_exponential_function_values','given_index given_value target_index',(2,9,5),
     (I(1,15),I(1,60000),I(1,40)),
     lambda n,c,k:rf'Suppose $f(x+y)=f(x)f(y)$ for all real $x,y$, and $f({n})={c}$. Find $f({k})$.',
     lambda n,c,k:integer_nth(c,n)**k,
     valid=lambda n,c,k:integer_nth(c,n)**n==c,sample=exponential_function_sample,
     constraints=('The positive given value is an integer power of degree given_index.',))


def integer_nth(value,n):
    lo,hi=1,value+1
    while hi-lo>1:
        mid=(hi+lo)//2
        if mid**n<=value:
            lo=mid
        else:
            hi=mid
    return lo


def functional_count(a):
    return 2


bind('t699','multiplicative_function_with_nonzero_offset','offset',(2,),(I(1,1000),),
     lambda a:rf'How many real-valued functions on the positive reals satisfy $f(xy)=f(x)f(y)-{a}$ for all positive real $x,y$?',
     functional_count)


bind('r888','fixed_circle_conjugation','radius',(5,),(I(1,100),),
     lambda r:rf'Let $f(z)=i\overline z$, where $\overline z$ denotes complex conjugation. How many $z$ satisfy $|z|={r}$ and $f(z)=z$?',
     lambda r:2)


bind('r935','functional_equation_at_zero','point',(2,),(I(-500,500),),
     lambda a:rf'Let $f:\mathbb R\to\mathbb R$ satisfy $f(x)f(y)-f(xy)=x+y$ for all real $x,y$. If $n$ is the number of possible values of $f({a})$ and $s$ is their sum, find $n s$.',
     lambda a:a+1)


bind('r922','sum_of_cubes_to_reciprocal_ratios','coefficient',(1,),(I(1,100),),
     lambda k:rf'Let $a,b>0$ satisfy $a^3+b^3={k}(a+b)$. Simplify $\frac ab+\frac ba-\frac{{{k}}}{{ab}}$.',
     lambda k:1)


bind('t192','reciprocal_ratio_from_product_difference','coefficient',(1,),(I(1,100),),
     lambda k:rf'Two nonzero reals $a,b$ satisfy $ {k}ab=a-b$. Find all possible values of $\frac ab+\frac ba-{k*k}ab$.',
     lambda k:2)


bind('r797','range_width_of_triangle_ratio','a b',(1,1),(I(1,100),)*2,
     lambda a,b:rf'For nonzero reals $x,y$, let $m,M$ be the minimum and maximum of $\frac{{|{a}x+{b}y|}}{{{a}|x|+{b}|y|}}$. Find $M-m$.',
     lambda a,b:1)


bind('t555','largest_mean_under_first_second_moment_relation','coefficient',(1,),(I(1,100),),
     lambda k:rf'For a nonempty list of real numbers, the sum of the squares equals {k} times the sum of the numbers. Find the largest possible arithmetic mean.',
     lambda k:k)


bind('t580','minimum_norm_under_quadratic_relation','coefficient',(4,),(I(-100,100),),
     lambda k:rf'Find the minimum of $x^2+y^2$ for real $x,y$ satisfying $x^2+y^2={k}xy$.',
     lambda k:0)


bind('t768','maximum_fraction_from_product_bound','bound',(1,),(I(1,100),),
     lambda k:rf'For $0\le a,b\le {k}$, find the largest value of $\frac{{a+b}}{{ab+1}}$.',
     lambda k:k)


bind('r1005','optimal_cylinder_height_radius','volume',(1,),(I(1,100),),
     lambda v:rf'A cylinder of fixed volume $V={v}$ has minimum total surface area, including both circular ends, at radius $R$ and height $H$. Find $H/R$.',
     lambda v:2,
     adaptation='The arbitrary fixed positive volume is specialized to a numeric positive volume.')


bind('r1158','sum_of_even_monotone_equation_roots','base linear target',(2,3,18),
     (I(2,50),I(1,100),I(2,1000)),
     lambda b,c,t:rf'Find the sum of all real solutions of $ {b}^{{|x|}}+{c}|x|={t}$.',
     lambda b,c,t:0)


bind('t731','circle_hyperbola_integer_nonintersection','coefficient',(1,),(I(1,100),),
     lambda a:rf'For how many integer $k$ do the graphs of $x^2+y^2=k^2$ and $xy={a}k$ fail to intersect?',
     lambda a:4*a-2,
     reference=lambda a:sum(k*k<2*a*abs(k) for k in range(-2*a,2*a+1)))


bind('t743','domain_of_log_squared_linear','shift',(0,),(I(-100,100),),
     lambda a:rf'The domain of $\log[({polynomial([-a,1])})^2]$ is $x<u$ or $x>v$. Find $u+v$.',
     lambda a:2*a)


def mean_sample(rng):
    k,n,m=rng.randint(1,100),rng.randint(1,12),rng.randint(1,12)
    return k*max(n,m)**2,k*min(n,m)**2


bind('t644','geometric_mean_from_arithmetic_and_harmonic','arithmetic harmonic',(2700,75),
     (I(1,15000),)*2,
     lambda a,h:rf'Two positive numbers have arithmetic mean {a} and harmonic mean {h}. Find their geometric mean.',
     lambda a,h:isqrt(a*h),sample=mean_sample,
     valid=lambda a,h:a>=h and is_square(a*h),
     constraints=('The arithmetic mean is at least the harmonic mean and their product is a square.',))


def sign_safe_log_identity(b,e,f,g):
    return F(b)**((e+f+g)//3)


def product_log_prompt(b,e,f,g):
    return rf'Let $A,R,M,L>0$ satisfy $\log_{{{b}}}(AL)+\log_{{{b}}}(AM)={e}$, $\log_{{{b}}}(ML)+\log_{{{b}}}(MR)={f}$, and $\log_{{{b}}}(RA)+\log_{{{b}}}(RL)={g}$. Find $ARML$.'


bind('r574','symmetric_log_product_system','base first second third',(10,2,3,4),
     (I(2,50),)+(I(-30,30),)*3,product_log_prompt,sign_safe_log_identity,
     valid=lambda b,e,f,g:(e+f+g)%3==0,
     constraints=('The sum of the three right-hand sides is divisible by three.',))


def factorial_log_inputs():
    for k in range(3,1001):
        target=k*k*(k-1)
        for exponent in range(1,6):
            base=integer_nth(target,exponent)
            if 2<=base<=4000 and base**exponent==target:
                yield base,exponent


_FACTORIAL_LOG_INPUTS=tuple(factorial_log_inputs())


def factorial_target(k,e):
    lo,hi=2,1001
    while hi-lo>1:
        mid=(lo+hi)//2
        if mid*mid*(mid-1)<=k**e:
            lo=mid
        else:
            hi=mid
    return lo


bind('r892','log_factorial_integer_argument','base correction',(10,2),
     (I(2,4000),I(1,5)),
     lambda b,e:rf'Find the integer $k>2$ satisfying $\log_{{{b}}}((k-2)!)+\log_{{{b}}}((k-1)!)+{e}=2\log_{{{b}}}(k!)$.',
     factorial_target,sample=lambda r:r.choice(_FACTORIAL_LOG_INPUTS),
     valid=lambda b,e:(k:=factorial_target(b,e))>2 and k*k*(k-1)==b**e,
     constraints=('The power base^correction equals k²(k−1) for an integer 3 ≤ k ≤ 1000.',))


bind('t229','linear_function_identity_special_input','rhs_constant',(0,),(I(-100,100),),
     lambda c:rf'For all real $x$, suppose $f(x)+f(2x)+f(2-x)+f(x+1)={polynomial([c,1])}$. Find $f(0)$.',
     lambda c:F(c-1,4))
