"""Parameterized word problems with exact rates, proportions, counts and costs."""
from fractions import Fraction as F
from math import isqrt
import re

from template_dataset.core import Template


_CASES = {}
_LITERAL = re.compile(r'-?\d+(?:(?:,\\?!?\d{3})+|\.\d+)?')


def _register(subject, ids, family, fields, solver, *, domains=None, valid=None,
              sample=None, constraint='', reference=None, edits=()):
    for short_id in ids.split():
        problem_id = f'{subject}/{short_id}'
        if problem_id in _CASES:
            raise ValueError(f'Duplicate word template: {problem_id}')
        _CASES[problem_id] = (family, fields.split(), solver, domains or {},
                              valid, sample, constraint, reference, edits)


def _algebra(ids, family, fields, solver, **kwargs):
    _register('algebra', ids, family, fields, solver, **kwargs)


def _prealgebra(ids, family, fields, solver, **kwargs):
    _register('prealgebra', ids, family, fields, solver, **kwargs)


def _geometry(ids, family, fields, solver, **kwargs):
    _register('geometry', ids, family, fields, solver, **kwargs)


def build(row):
    case = _CASES.get(row['id'])
    if case is None:
        return None
    family, fields, solver, bounds, joint, sampler, constraint, reference, edits = case
    problem = row['problem']
    for old, new in edits:
        if old not in problem:
            raise ValueError(f"Missing expected literal for {row['id']}: {old}")
        problem = problem.replace(old,new,1)
    matches = list(_LITERAL.finditer(problem))
    if len(matches) != len(fields):
        raise ValueError(f"Unexpected literals for {row['id']}: {[m[0] for m in matches]}")
    original, widths = {}, {}
    for match, field in zip(matches, fields):
        if field == '_':
            continue
        name, _, precision = field.partition(':')
        width = int(precision) if precision else 0
        value = F(match[0].replace(',', '').replace(r'\!', '')) * 10**width
        if value.denominator != 1 or (name in original and original[name] != value):
            raise ValueError(f"Inconsistent literal for {row['id']}: {field} = {value}")
        original[name] = int(value)
        widths[name] = width
    domains = {
        name: bounds.get(name, (min(1,value),max(100,value)))
        for name,value in original.items()
    }
    parameters = {
        name: ({'type':'int','min':domain[0],'max':domain[1]} if isinstance(domain,tuple)
               else {'type':'int','choices':domain})
        for name,domain in domains.items()
    }

    def validate(p):
        if not isinstance(p,dict) or p.keys() != domains.keys():
            return False
        for name,domain in domains.items():
            n = p[name]
            if type(n) is not int:
                return False
            if isinstance(domain,tuple):
                if not domain[0] <= n <= domain[1]:
                    return False
            elif n not in domain:
                return False
        return joint is None or joint(**p)

    def sample(rng):
        if sampler:
            return sampler(rng)
        for _ in range(128):
            params = {
                name:(rng.randint(*domain) if isinstance(domain,tuple) else rng.choice(domain))
                for name,domain in domains.items()
            }
            if validate(params):
                return params
        return dict(original)

    def render(p):
        pieces = []
        offset = 0
        for match,field in zip(matches,fields):
            name = field.split(':')[0]
            if name == '_':
                continue
            n, width = p[name], widths[name]
            digits = str(abs(n)).zfill(width+1)
            value = digits[:-width] + '.' + digits[-width:] if width else digits
            if n < 0:
                value = '-' + value
            if match.start() and problem[match.start()-1]=='^' and len(value)>1:
                value = '{' + value + '}'
            pieces.extend((problem[offset:match.start()],value))
            offset = match.end()
        return ''.join(pieces) + problem[offset:]

    constraints = [constraint] if constraint else []
    constraints += [f'{name} is displayed after division by {10**width}.'
                    for name,width in widths.items() if width]
    return Template(
        family='word.' + family, parameters=parameters, original=original,
        render=render, solve=lambda p:solver(**p), sample=sample, validate=validate,
        constraints=constraints, reference=None if reference is None else lambda p:reference(**p),
        adaptation='Equivalent source wording: ' + ', '.join(
            repr(old) + ' → ' + repr(new) for old,new in edits
        ) + '.' if edits else '',
    )


def _round(value, places=0):
    unit = 10**places
    return F((2*value*unit+1)//2,unit)


def _rate(quantity, old, new):
    return F(quantity*new,old)


def _inverse(quantity, old, new):
    return F(quantity*old,new)


def _round_rate(quantity, old, new):
    return _round(_inverse(quantity,old,new),1)


def _ceil_div(n,d):
    return (n+d-1)//d


def _floor_cents(budget, unit):
    return budget//unit


# Direct and inverse rates.
_algebra('train/131','direct-proportion-charge','old quantity new',_rate,
         valid=lambda quantity,old,new:100*quantity*new%old==0,
         constraint='The proportional fare is a whole number of cents.',
         reference=lambda quantity,old,new:F(quantity,old)*new)
_algebra('train/1224','whole-box-purchase','old quantity new',_rate,
         domains={'new':(1,600)},
         valid=lambda quantity,old,new:new%old==0,
         sample=lambda rng:(lambda old,n:{'old':old,'quantity':rng.randint(1,100),'new':old*n})(
             rng.randint(1,30),rng.randint(1,20)),
         constraint='The desired quantity can be bought as a whole number of boxes.',
         reference=lambda quantity,old,new:quantity*(new//old))
_algebra('train/1054','direct-proportion-charge','quantity new',
         lambda quantity,new:_rate(quantity,12,new),
         valid=lambda quantity,new:100*quantity*new%12==0,
         constraint='The proportional bouquet price is a whole number of cents.')
_algebra('train/1094','unit-rate','quantity old',lambda quantity,old:F(quantity,old))
_algebra('test/567','unit-conversion-speed','_ _ speed',
         lambda speed:_round(F(22*speed,15),1))
_algebra('train/435','rate-time','speed distance',lambda speed,distance:F(60*distance,speed))
_algebra('test/498','rate-time','speed distance',lambda speed,distance:F(60*distance,speed))
_algebra('train/346','reading-time-difference','fast slow pages',
         lambda fast,slow,pages:60*pages*(F(1,slow)-F(1,fast)),
         valid=lambda fast,slow,pages:fast>slow,
         constraint='The first reading rate is strictly faster.')
_algebra('train/428','inverse-workforce-time','quantity old new',_inverse,
         valid=lambda quantity,old,new:new<old,
         constraint='The alternative workforce is smaller.')
_algebra('train/153','inverse-workforce-time-rounded','old quantity new',_round_rate)
_algebra('test/246','inverse-workforce-time','old quantity:1 new',
         lambda quantity,old,new:F(quantity*old,10*new),
         edits=(('Six construction workers','6 construction workers'),))
_algebra('train/948','inverse-workforce-time','old quantity new',_inverse,
         edits=(('Four people','4 people'),('six hours','6 hours'),('three people','3 people')))
_algebra('train/976','inverse-rate','old quantity new',_inverse)
_algebra('train/575 test/23','inverse-pressure-volume','old:3 quantity new:3',_inverse)
_algebra('train/157 train/556','equal-earnings-weekly-hours','h a income b income',
         lambda h,a,b,income:F(h*a,b),
         domains={'a':(1,14),'b':(1,52)},
         valid=lambda h,a,b,income:h*a<=168*b,
         constraint='The summer job lasts at most 14 weeks, the school-year job lasts at most 52 weeks, and the required work fits within the 168 hours in a week.',
         reference=lambda h,a,b,income:F(income,1)/(F(income,h*a)*b))
_algebra('train/384','remaining-weekly-hours','h total goal missed',
         lambda h,total,goal,missed:F(h*total,total-missed),
         domains={'total':(2,14),'missed':(1,13)},
         valid=lambda h,total,goal,missed:0<missed<total and h*total<=168*(total-missed),
         edits=(('first two weeks','first 2 weeks'),),
         constraint='At least one working week remains, and the required weekly work does not exceed 168 hours.')
_algebra('train/648 test/79','equal-distance-revolutions','old quantity new',_inverse)
_algebra('train/1617','direct-proportion','old quantity new:1',
         lambda old,quantity,new:F(quantity*new,10*old))
_algebra('train/1069','equal-cycling-distance','speed duration:1 target',
         lambda speed,duration,target:F(speed*duration,10*target),
         edits=(('three and a half hours','3.5 hours'),))
_algebra('train/1609','total-distance-from-average-speed','out back speed',
         lambda out,back,speed:F((out+back)*speed,60))
_algebra('train/744','work-fraction','whole spent',
         lambda whole,spent:F(spent,whole),valid=lambda whole,spent:spent<whole,
         constraint='The elapsed time is shorter than the full job.')
_algebra('train/1169','remaining-work-fraction','other whole spent',
         lambda other,whole,spent:1-F(spent,whole),
         valid=lambda other,whole,spent:spent<whole,
         edits=(('in four hours','in 4 hours'),),
         constraint='Tom has not yet completed the job.')
_algebra('test/409','inverse-current-resistance','quantity old new',_inverse)
_algebra('train/839 test/160','inverse-price-demand','quantity old new',_inverse,
         domains={'quantity':(1,120),'old':(1,3000),'new':(1,3000)},
         valid=lambda quantity,old,new:quantity*old%new==0,
         sample=lambda rng:(lambda unit,a,b,k:{'old':unit*a,'new':unit*b,'quantity':b*k})(
             rng.randint(1,100),rng.randint(1,15),rng.randint(1,10),rng.randint(1,12)),
         constraint='The inverse-proportion model yields a whole number of customers.')

_prealgebra('train/364','direct-proportion-charge','quantity old new',_rate,
            valid=lambda quantity,old,new:100*quantity*new%old==0,
            constraint='The proportional charge is a whole number of cents.',
            edits=(('per five pounds','per 5 pounds'),))
_prealgebra('train/677','direct-proportion','quantity old new',_rate)
_prealgebra('train/825','direct-proportion','new old quantity',_rate,
            valid=lambda quantity,old,new:old<new,
            constraint='The appraised coins form a proper subset of the collection.')
_prealgebra('test/214','direct-proportion','quantity old new',
            lambda quantity,old,new:_rate(quantity,old,12*new),
            valid=lambda quantity,old,new:1200*quantity*new%old==0,
            constraint='The proportional purchase price is a whole number of cents.',
            edits=(('four doughnuts','4 doughnuts'),('four dozen','4 dozen')))
_prealgebra('test/41','rate-from-distance-and-time','distance time:1',
            lambda distance,time:F(10*distance,time))
_prealgebra('train/383','distance-from-rate-and-time','speed time:1',
            lambda speed,time:_round(F(speed*time,10),1))
_prealgebra('train/649','rate-in-other-time-unit','rate time',lambda rate,time:F(rate*time,60))
_prealgebra('test/10','unit-conversion-rate','rate _',lambda rate:88*rate)
_prealgebra('test/65','height-from-constant-rate','start rate time',lambda start,rate,time:start+rate*time)
_prealgebra('test/239','rate-time','old:1 new',
            lambda old,new:F(5*new,old))
_prealgebra('test/389','travel-time-difference','miles fast slow miles',
            lambda miles,fast,slow:miles*(F(1,slow)-F(1,fast)),
            valid=lambda miles,fast,slow:fast>slow,
            constraint='Bill travels faster than Sam.')
_prealgebra('train/779','pace-time-difference','fast slow distance',
            lambda fast,slow,distance:(slow-fast)*distance,
            valid=lambda fast,slow,distance:fast<slow,
            constraint='Malcolm takes fewer minutes per mile.')
_prealgebra('train/1146','travel-time-difference','speed short long',
            lambda speed,short,long:F(60*(long-short),speed),
            valid=lambda speed,short,long:short<long,
            constraint='The first trip is shorter.')
_prealgebra('train/693','round-printing-time','rate pages',
            lambda rate,pages:_round(F(pages,rate)))
_prealgebra('test/542','unit-conversion-rate','n sec',lambda n,sec:F(n*sec,60))
_prealgebra('train/781','unit-conversion-time','time:1',lambda time:6*time)
_prealgebra('test/728','unit-conversion-time','days',lambda days:F(days,7))
_prealgebra('test/749','unit-conversion-rate','amount:1 minutes hours',
            lambda amount,minutes,hours:F(6*amount*hours,minutes))
_prealgebra('test/654','map-scale','n d miles actual',
            lambda n,d,miles,actual:F(n*actual,d*miles))
_prealgebra('train/1028 test/841','map-scale','map_dist scale:1 km',
            lambda map_dist,scale,km:F(10*map_dist*km,scale))

# Percentages, decimal currency and whole-item constraints.
_algebra('train/1064','percent-equivalence','a b x',
         lambda a,b,x:F(b*x,a))
_algebra('train/1413','percent-increase','value rate',
         lambda value,rate:F(value*(100+rate),100),
         reference=lambda value,rate:value+F(value*rate,100))
_algebra('test/1','percent-difference','a x b y',
         lambda a,x,b,y:F(abs(a*x-b*y),100),
         valid=lambda a,x,b,y:a*x!=b*y,
         constraint='The two percentages yield different amounts.')
_algebra('test/102','nested-percent','rate n d value',
         lambda rate,n,d,value:F(rate*n*value,100*d))
_algebra('test/431','nested-percent','a b value',
         lambda a,b,value:F(a*b*value,10000))
_prealgebra('test/226','nested-percent','a b value',
            lambda a,b,value:F(a*b*value,10000))
_prealgebra('test/777','percent-of-same-base','a value b',
            lambda a,value,b:F(value*b,a))
_prealgebra('train/1186','percent-equivalence','a b x',
            lambda a,b,x:F(a*x,b))
_algebra('test/673','whole-from-percent','part percent',
         lambda part,percent:F(100*part,percent))
_algebra('train/254','whole-from-percent','part percent',
         lambda part,percent:F(100*part,percent),edits=(('Sixteen','16'),))
_algebra('train/715','whole-from-percent','percent part',
         lambda part,percent:F(100*part,percent),
         edits=(('Eleven percent','11 percent'),('seventy-seven','77')))
_prealgebra('train/399','whole-from-percent','percent part:1',
            lambda percent,part:F(10*part,percent))
_prealgebra('train/270','successive-discounts','price a b',
            lambda price,a,b:F(price*(100-a)*(100-b),10000),
            domains={'a':(1,99),'b':(1,99)},
            valid=lambda price,a,b:price*(100-a)*(100-b)%100==0,
            constraint='The final price is a whole number of cents.',
            reference=lambda price,a,b:(price-F(price*a,100))*F(100-b,100))
_prealgebra('train/1074','percent-increase','rate miles',
            lambda rate,miles:F((100+rate)*miles,100))
_algebra('train/825','successive-late-charges','rate _ rate _ price',
         lambda rate,price:F(price*(100+rate)**2,10000),
         valid=lambda rate,price:price*(100+rate)**2%100==0,
         constraint='The final bill is a whole number of cents.',
         reference=lambda rate,price:sum([price,F(2*price*rate,100),F(price*rate**2,10000)]))
_prealgebra('test/12','tip-percent','bill:2 paid:2',
            lambda bill,paid:F(100*(paid-bill),bill),
            domains={'bill':(1,4000),'paid':(1,5000)},valid=lambda bill,paid:paid>bill,
            constraint='The payment exceeds the bill.')
_prealgebra('test/316','price-before-discount','price percent price percent price',
            lambda price,percent:F(100*price,100-percent),
            domains={'percent':(1,99)},
            valid=lambda price,percent:10000*price%(100-percent)==0,
            constraint='The original price is a whole number of cents.')
_algebra('train/595','max-test-misses','percent count',
         lambda percent,count:count-_ceil_div(percent*count,100),
         reference=lambda percent,count:max(m for m in range(count+1) if 100*(count-m)>=percent*count))
_prealgebra('train/57','min-correct-test','count percent',
            lambda percent,count:_ceil_div(count*percent,100),
            reference=lambda percent,count:next(n for n in range(count+1) if 100*n>=count*percent))
_prealgebra('train/312','minimum-sales-to-break-even','fixed sale cost',
            lambda fixed,sale,cost:_ceil_div(fixed,sale-cost),
            valid=lambda fixed,sale,cost:sale>cost,
            constraint='Each delivery has positive net earnings.',
            reference=lambda fixed,sale,cost:-(-fixed//(sale-cost)))
_algebra('test/194','minimum-sales-for-profit','fixed cost:2 sale:2',
         lambda fixed,sale,cost:100*fixed//(sale-cost)+1,
         domains={'fixed':(1,1500),'sale':(1,1000),'cost':(1,999)},
         valid=lambda fixed,sale,cost:sale>cost,
         constraint='The selling price exceeds the variable cost and profit must be strictly positive.',
         reference=lambda fixed,sale,cost:next(n for n in range(1,1+100*fixed+1)
                                               if n*(sale-cost)>100*fixed))
_prealgebra('train/758','maximum-purchases','unit:2 budget:2',_floor_cents,
            domains={'unit':(1,2000),'budget':(1,15000)})
_prealgebra('train/940','maximum-purchases','budget:2 unit:2',_floor_cents,
            domains={'unit':(1,2000),'budget':(1,15000)})
_prealgebra('train/933','maximum-purchases','unit budget:2',_floor_cents,
            domains={'unit':(1,100),'budget':(1,15000)})
_prealgebra('test/778','minimum-capacity-containers','n capacity',
            lambda n,capacity:_ceil_div(n,capacity),
            reference=lambda n,capacity:divmod(n,capacity)[0]+int(n%capacity!=0))
_prealgebra('train/673','maximum-purchases-mixed-cents','d c ud uc',
            lambda d,c,ud,uc:(100*d+c)//(100*ud+uc),
            domains={'c':(0,99),'uc':(0,99),'ud':(1,10)})
_prealgebra('test/291','remaining-purchase-cost','unit:2 total:2',
            lambda unit,total:F(total-2*unit,100),
            domains={'unit':(1,2000),'total':(1,10000)},
            valid=lambda unit,total:total>2*unit,
            constraint='The total covers both shirts and a positive sweatshirt price.')
_algebra('test/287','ride-count-from-total-price','entry:2 ride:2 total:2',
         lambda entry,ride,total:(total-entry)//ride,
         domains={'entry':(1,1000),'ride':(1,1000),'total':(2,30000)},
         valid=lambda entry,ride,total:total>entry and (total-entry)%ride==0,
         sample=lambda rng:(lambda e,r,n:{'entry':e,'ride':r,'total':e+n*r})(
             rng.randint(10,500),rng.randint(10,500),rng.randint(1,30)),
         constraint='After the entrance fee the cost pays for a positive whole number of rides.')
_algebra('train/944','two-prices-from-sum-and-difference','sum_c:2 delta:2',
         lambda sum_c,delta:F(sum_c+delta,200),
         domains={'sum_c':(2,5000),'delta':(1,4000)},
         valid=lambda sum_c,delta:sum_c>delta and (sum_c-delta)%2==0,
         sample=lambda rng:(lambda a,d:{'sum_c':2*a+d,'delta':d})(
             rng.randint(1,500),rng.randint(1,500)),
         constraint='Both prices are positive whole numbers of cents.')

# Ratios with integral totals and group membership.
def _split_sample(rng, parts):
    amounts = {part:rng.randint(1,12) for part in parts}
    return dict(amounts,total=sum(amounts.values())*rng.randint(1,20))


_prealgebra('test/48','whole-group-ratio','a b total',
            lambda a,b,total:total*a//(a+b),
            domains={'total':(2,1000)},valid=lambda a,b,total:total*a%(a+b)==0,
            sample=lambda rng:_split_sample(rng,'ab'),
            constraint='The displayed ratio allocates whole numbers of dogs and cats.')
_prealgebra('test/593','whole-group-ratio','a b total',
            lambda a,b,total:total*b//(a+b),
            domains={'total':(2,1000)},valid=lambda a,b,total:total*b%(a+b)==0,
            sample=lambda rng:_split_sample(rng,'ab'),
            constraint='The displayed ratio allocates whole numbers of marbles to both colors.')
_prealgebra('train/212','whole-group-ratio','total a b c',
            lambda a,b,c,total:total*c//(a+b+c),
            domains={'total':(3,1000)},
            valid=lambda a,b,c,total:all(total*x%(a+b+c)==0 for x in (a,b,c)),
            sample=lambda rng:_split_sample(rng,'abc'),
            constraint='All three groups have integral counts.')
_prealgebra('test/622','whole-group-ratio','total a b c d',
            lambda a,b,c,d,total:total*(b+c)//(a+b+c+d),
            domains={'total':(4,1000)},
            valid=lambda a,b,c,d,total:all(total*x%(a+b+c+d)==0 for x in (a,b,c,d)),
            sample=lambda rng:_split_sample(rng,'abcd'),
            constraint='All four shares have integral counts.')
_prealgebra('train/21','whole-group-ratio','a b known',
            lambda a,b,known:known*b//a,
            domains={'known':(1,500)},valid=lambda a,b,known:known*b%a==0,
            sample=lambda rng:(lambda a,b,k:{'a':a,'b':b,'known':a*k})(
                rng.randint(1,20),rng.randint(1,20),rng.randint(1,25)),
            constraint='The ratio and known count give a whole-number count for the other color.')
_prealgebra('train/108','ratio-preserving-count-increase','a b old added',
            lambda a,b,old,added:a*(old+added)//b,
            domains={'old':(1,400),'added':(1,400)},
            valid=lambda a,b,old,added:old*a%b==0 and added*a%b==0,
            sample=lambda rng:(lambda a,b,m,n:{'a':a,'b':b,'old':b*m,'added':b*n})(
                rng.randint(1,20),rng.randint(1,20),rng.randint(1,20),rng.randint(1,20)),
            constraint='Both the starting and the final garden have whole numbers of irises.')
_prealgebra('train/49','recipe-total-from-ratio','a b c known',
            lambda a,b,c,known:F(known*(a+b+c),c))
_prealgebra('train/878','recipe-component-from-ratio','a b c known',
            lambda a,b,c,known:F(known*b,c))
_prealgebra('train/335','split-area-by-ratio','a b total',
            lambda a,b,total:F(total*b,a+b),domains={'total':(1,1500)})
_prealgebra('test/479','split-money-by-ratio','total a b c',
            lambda a,b,c,total:F(a*total,a+b+c),
            domains={'total':(3,1000)},
            valid=lambda a,b,c,total:all(100*total*x%(a+b+c)==0 for x in (a,b,c)),
            sample=lambda rng:_split_sample(rng,'abc'),
            constraint='All three shares are whole numbers of cents.')
_prealgebra('train/1024','reconstruct-total-from-ratio','a b c share',
            lambda a,b,c,share:F((a+b+c)*share,a),
            valid=lambda a,b,c,share:100*share*b%a==0 and 100*share*c%a==0,
            sample=lambda rng:(lambda a:{'a':a,'b':rng.randint(1,100),'c':rng.randint(1,100),
                                        'share':a*rng.randint(1,5)})(rng.randint(1,20)),
            constraint='All three shares are whole numbers of cents.')
_prealgebra('test/188','ages-in-ratio','a b age',
            lambda a,b,age:age*a//b, domains={'a':(1,20),'b':(1,20),'age':(1,100)},
            valid=lambda a,b,age:age*a%b==0 and age*a<=100*b,
            sample=lambda rng:(lambda a,b,k:{'a':a,'b':b,'age':b*k})(
                rng.randint(1,10),rng.randint(1,10),rng.randint(1,10)),
            constraint='Both ages are whole numbers of years between 1 and 100.')
_prealgebra('train/268','complementary-angle-ratio','a b',
            lambda a,b:F(90*min(a,b),a+b),
            valid=lambda a,b:a!=b,constraint='The two angles differ.')
_prealgebra('train/698','triangle-angle-ratio','a b c',
            lambda a,b,c:F(180*min(a,b,c),a+b+c),
            valid=lambda a,b,c:len({a,b,c})==3,
            constraint='The angles are positive and pairwise distinct.')
_prealgebra('test/834','triangle-angle-ratio','a b c',
            lambda a,b,c:F(180*max(a,b,c),a+b+c),
            valid=lambda a,b,c:len({a,b,c})==3,
            constraint='The angles are positive and pairwise distinct.')
_algebra('train/955','integer-ratio-from-sum','total a b c',
         lambda a,b,c,total:total*min(a,b,c)//(a+b+c),
         domains={'total':(3,1000)},
         valid=lambda a,b,c,total:all(total*x%(a+b+c)==0 for x in (a,b,c)),
         sample=lambda rng:_split_sample(rng,'abc'),
         constraint='All three terms are positive integers.')

# Means, scores, ages and remaining fractions.
for ids, fields, n in (
    ('train/29','a b c d e f g',7),
    ('train/394 train/795','a b c d e',5),
    ('test/43','a b c d e f',6),
):
    _prealgebra(ids,'mean-of-scores',fields,lambda n=n,**p:F(sum(p.values()),n),
                reference=lambda n=n,**p:sum(F(v,n) for v in p.values()))
_prealgebra('train/62','mean-score-change','a b c d',
            lambda a,b,c,d:F(a+b+c+d,4)-F(a+b+c,3),
            valid=lambda a,b,c,d:3*d>a+b+c,
            constraint='The last score raises the mean.')
_prealgebra('train/80','equal-means-solve','a b c d',
            lambda a,b,c,d:F(2*(a+b+c),3)-d)
_prealgebra('train/91','equal-means-solve','a b c d',
            lambda a,b,c,d:F(2*(a+b+c),3)-d,
            edits=(('$5,8$','$5$, $8$'),))
_prealgebra('train/173','missing-score-from-mean','a b mean',
            lambda a,b,mean:3*mean-a-b)
_prealgebra('train/585','missing-value-from-set-mean','mean a b c d',
            lambda a,b,c,d,mean:5*mean-a-b-c-d,
            valid=lambda a,b,c,d,mean:len({a,b,c,d,5*mean-a-b-c-d})==5,
            edits=(('of the set $','of the five-element set $'),),
            constraint='All five set elements are distinct.')
_prealgebra('test/566','missing-score-from-mean','a b c mean',
            lambda a,b,c,mean:4*mean-a-b-c)
_prealgebra('test/843','missing-score-from-mean','mean:1 a b c d',
            lambda a,b,c,d,mean:F(mean,2)-a-b-c-d)
_prealgebra('test/201','ordered-set-equal-mean-and-median','a b',
            lambda a,b:F(a+b,2),valid=lambda a,b:a<b,
            constraint='The two given endpoints are in increasing order.')
_prealgebra('test/56','minimum-final-score-for-mean','a b c d mean',
            lambda a,b,c,d,mean:5*mean-a-b-c-d,
            valid=lambda a,b,c,d,mean:0<=5*mean-a-b-c-d<=100,
            constraint='The required score lies between zero and 100.')
_prealgebra('train/816','weighted-mean-of-two-groups','a x b y total',
            lambda a,x,b,y,total:F(a*x+b*y,total),
            domains={'a':(1,70),'b':(1,70),'x':(1,90),'y':(1,90),'total':(2,140)},
            valid=lambda a,x,b,y,total:total==a+b,
            sample=lambda rng:(lambda a,b:{'a':a,'b':b,'total':a+b,
                'x':rng.randint(1,90),'y':rng.randint(1,90)})(rng.randint(1,70),rng.randint(1,70)),
            constraint='The stated total is the sum of the two group sizes.',
            reference=lambda a,x,b,y,total:F(sum([x]*a+[y]*b),total))
_prealgebra('train/393','weighted-mean-of-two-groups','x y',
            lambda x,y:F(5*x+6*y,11),reference=lambda x,y:F(sum([x]*5+[y]*6),11))
_prealgebra('train/144','mean-of-ages','a b c',
            lambda a,b,c:F(3*a+b+c,5),domains=dict.fromkeys('abc',(1,21)))
_prealgebra('train/204','smallest-integer-from-mean-and-median','mean med delta',
            lambda mean,med,delta:3*mean-2*med-delta,
            valid=lambda mean,med,delta:0<3*mean-2*med-delta<=med,
            constraint='The inferred integer is positive and at most the median.')
_prealgebra('train/556','mean-of-lengths','a:1 b:1',lambda a,b:F(a+b,20))
_prealgebra('train/511','sum-from-mean','mean:1',lambda mean:F(6*mean,10))
for ids,direction in (('train/668',-1),('test/623',1)):
    _algebra(ids,'age-from-sum-and-difference','d total',
             lambda d,total,direction=direction:(total+direction*d)//2,
             domains={'d':(13,75),'total':(3,160)},
             valid=lambda d,total:total>d and (total-d)%2==0 and (total+d)<=220,
             sample=lambda rng:(lambda a,d:{'d':d,'total':2*a+d})(rng.randint(1,40),rng.randint(13,65)),
             constraint='Both ages are positive integers, and the older person is at most 110.')
_algebra('train/263','age-from-percent','less percent older',
         lambda less,percent,older:100*(older+less)//percent,
         domains={'less':(1,30),'older':(1,100),'percent':(100,500)},
         valid=lambda less,percent,older:100*(older+less)%percent==0,
         sample=lambda rng:(lambda a,k,d:{'less':d,'percent':100*k,'older':a*k-d})(
             rng.randint(6,20),rng.randint(2,5),rng.randint(1,10)),
         constraint='The given percentage relation yields a positive integral age.')
_algebra('train/1497','ages-from-sum-and-multiple','total',
         lambda total:2*total//3, domains={'total':list(range(3,151,3))},
         constraint='The sum of the ages is divisible by three.')
_algebra('train/1031','ages-from-sum-and-offset','offset total',
         lambda offset,total:2*(total+offset)//3-offset,
         valid=lambda offset,total:(total+offset)%3==0 and 2*total>offset,
         constraint='The two inferred ages are positive integers.')
_prealgebra('train/61','fraction-of-fraction','a b c d',
            lambda a,b,c,d:F(a*c,b*d),
            valid=lambda a,b,c,d:a<b and c<d,
            constraint='The container and portion fractions are proper.')
_prealgebra('train/567','fractional-time','time a b',
            lambda time,a,b:F(time*a,b),valid=lambda time,a,b:a<b,
            constraint='Bob takes a proper fraction of Alice’s time.')
_prealgebra('train/181','difference-of-fractions','a b c d',
            lambda a,b,c,d:F(a,b)-F(c,d),
            valid=lambda a,b,c,d:a<=b and c<=d and a*d>b*c,
            constraint='Each student eats at most one pie, and the first student eats more.')
_prealgebra('test/365','remaining-fraction','a b c d',
            lambda a,b,c,d:1-F(a,b)-F(c,d),
            valid=lambda a,b,c,d:a*d+c*b<=b*d,
            constraint='Together the two people eat at most one whole cookie.')
_prealgebra('test/375','fraction-times-relative-portion','a b c d',
            lambda a,b,c,d:F(a*c,b*d),
            valid=lambda a,b,c,d:a<=b and a*c<=b*d,
            constraint='Neither person eats more than their whole sandwich.')
_prealgebra('train/631 train/1019 test/141','remaining-liquid','whole n d',
            lambda whole,n,d:whole-F(n,d),
            valid=lambda whole,n,d:whole*d>n,
            constraint='The amount used is strictly smaller than the amount available.')
_prealgebra('train/958','fractional-mass-split','a b n',
            lambda a,b,n:F(a,b*n),domains={'n':(2,40)})
_algebra('train/1205','container-capacity-from-fill-levels','a b add c d',
         lambda a,b,add,c,d:F(add*b*d,c*b-a*d),
         valid=lambda a,b,add,c,d:0<F(a,b)<F(c,d)<1,
         edits=(('three liters','3 liters'),),
         constraint='The final fill fraction is larger and both fill levels are between empty and full.',
         reference=lambda a,b,add,c,d:F(add,1)/(F(c,d)-F(a,b)))
_algebra('train/1640','acid-solution-dilution','volume source target',
         lambda volume,source,target:F(volume*(source-target),target),
         valid=lambda volume,source,target:0<target<source<=100,
         constraint='Adding water lowers the percentage of acid.',
         reference=lambda volume,source,target:F(volume*source,target)-volume)
_prealgebra('test/208','alloy-components','copper zinc known',
            lambda copper,zinc,known:F(known*zinc,copper),
            valid=lambda copper,zinc,known:copper+zinc==100,
            sample=lambda rng:(lambda c:{'copper':c,'zinc':100-c,'known':rng.randint(1,100)})(
                rng.randint(1,99)),
            constraint='The two alloy percentages add to 100.')
_geometry('test/73','scale-recipe-pan-depth','a b scale:1 c d',
          lambda a,b,scale,c,d:_round(F(a*b*scale,10*c*d),2))
_geometry('train/750','similarity-area-to-height','a b h',
          lambda a,b,h:F(h*_root_square_ratio(a,b),a),
          domains={'a':(1,30),'b':(2,400)},
          valid=lambda a,b,h:b>a and _root_square_ratio(a,b)**2==a*b,
          sample=lambda rng:(lambda a,k:{'a':a,'b':a*k*k,'h':rng.randint(1,30)})(
              rng.randint(1,6),rng.randint(2,8)),
          constraint='The larger area exceeds the smaller, and the ratio is a rational square.')


def _root_square_ratio(a,b):
    return isqrt(a*b)


# Construct paired observations from prices, head counts and discrete quantities.
def _cost_pair(rows, target):
    (a,b),(c,d) = rows
    determinant = a*d-b*c

    def prices(bill_one,bill_two):
        return F(d*bill_one-b*bill_two,determinant), F(a*bill_two-c*bill_one,determinant)

    def solve(bill_one,bill_two):
        x,y = prices(bill_one,bill_two)
        return F(target[0]*x+target[1]*y,target[2])

    def sample(rng):
        x,y = rng.randint(5,400),rng.randint(5,400)
        return {'bill_one':a*x+b*y,'bill_two':c*x+d*y}

    def valid(bill_one,bill_two):
        return all(p>0 and p.denominator==1 for p in prices(bill_one,bill_two))

    return solve, sample, valid


for ids, rows, target in (
    ('train/215',((2,1),(1,2)),(0,1,1)),
    ('train/779',((5,1),(1,2)),(2,1,100)),
    ('train/1079',((4,3),(2,5)),(0,1,1)),
    ('train/1332',((3,2),(2,1)),(1,0,1)),
):
    solve,sample,valid = _cost_pair(rows,target)
    _algebra(ids,'two-purchase-price-system','bill_one:2 bill_two:2',
             solve, sample=sample, valid=valid,
             domains={'bill_one':(1,4000),'bill_two':(1,4000)},
             constraint='Both per-item prices are positive whole numbers of cents.')


_algebra('train/4','paid-days-and-penalty','days wage penalty days pay',
         lambda days,wage,penalty,pay:(days*wage-pay)//(wage+penalty),
         domains={'days':(2,50),'wage':(10,100),'penalty':(1,80),'pay':(1,5000)},
         valid=lambda days,wage,penalty,pay:days*wage>pay and (days*wage-pay)%(wage+penalty)==0,
         sample=lambda rng:_wage_sample(rng),
         constraint='The net pay is positive and corresponds to an integral, positive number of days missed.')


def _wage_sample(rng):
    days,wage,penalty = rng.randint(10,50),rng.randint(30,100),rng.randint(1,40)
    missed = rng.randint(1,(days*wage-1)//(wage+penalty))
    return dict(days=days,wage=wage,penalty=penalty,pay=days*wage-missed*(wage+penalty))


_algebra('train/19','same-rate-faucet-fill-time','a old minutes b new',
         lambda a,old,minutes,b,new:F(60*a*minutes*new,b*old),
         edits=(('Three faucets','3 faucets'),('six faucets','6 faucets')),
         reference=lambda a,old,minutes,b,new:F(new,1)/(F(old,60*a*minutes)*b))
_algebra('train/190','total-distance-with-overlapping-days','a avg c d',
         lambda a,avg,c,d:a+c,
         valid=lambda a,avg,c,d:min(_hike_days(a,avg,c,d))>0,
         constraint='The four givens imply strictly positive distances on all four days.',
         reference=lambda a,avg,c,d:sum(_hike_days(a,avg,c,d)))


def _hike_days(a,avg,c,d):
    third = F(2*avg+d-a,2)
    second = 2*avg-third
    return a-second,second,third,c-third


_algebra('train/339','penny-nickel-count','value:2 count',
         lambda value,count:(value-count)//4,
         domains={'value':(1,600),'count':(1,200)},
         valid=lambda value,count:count<=value<=5*count and (value-count)%4==0,
         sample=lambda rng:(lambda a,b:{'value':a+5*b,'count':a+b})(
             rng.randint(1,80),rng.randint(1,80)),
         constraint='The amount and coin count can be made with pennies and nickels.',
         reference=lambda value,count:next(n for n in range(count+1) if count+4*n==value))
_algebra('train/980','one-dollar-bill-count','value count',
         lambda value,count:2*count-value,
         domains={'value':(3,360),'count':(2,240)},
         valid=lambda value,count:count<value<2*count,
         sample=lambda rng:(lambda a,b:{'value':a+2*b,'count':a+b})(
             rng.randint(1,120),rng.randint(1,120)),
         constraint='There are positive counts of both denominations.')
_algebra('test/579','nickel-count','count value',
         lambda value,count:(10*count-value)//5,
         domains={'value':(10,600),'count':(2,80)},
         valid=lambda value,count:5*count<value<10*count and value%5==0,
         sample=lambda rng:(lambda a,b:{'value':5*a+10*b,'count':a+b})(
             rng.randint(1,40),rng.randint(1,40)),
         edits=(('eleven coins','11 coins'),),
         constraint='There are positive whole numbers of both denominations.')
_algebra('test/544','regular-battery-pack-count','count small large total',
         lambda count,small,large,total:(large*count-total)//(large-small),
         domains={'small':(1,12),'large':(2,20),'count':(2,80),'total':(2,1600)},
         valid=lambda count,small,large,total:small<large and small*count<total<large*count
             and (large*count-total)%(large-small)==0,
         sample=lambda rng:(lambda a,b,s,l:{'count':a+b,'small':s,'large':s+l,'total':a*s+b*(s+l)})(
             rng.randint(1,40),rng.randint(1,40),rng.randint(1,12),rng.randint(1,8)),
         edits=(('contain four batteries','contain 4 batteries'),('contain six batteries','contain 6 batteries')),
         constraint='Both pack counts are positive integers and regular packs contain fewer batteries.')
_algebra('train/1052','tables-and-stools-leg-count','stools stool table total',
         lambda stools,stool,table,total:total//(stools*stool+table),
         domains={'stools':(1,20),'stool':(3,4),'table':(3,4),'total':(1,6000)},
         valid=lambda stools,stool,table,total:total%(stools*stool+table)==0,
         sample=lambda rng:(lambda n,s,l,t:{'stools':s,'stool':l,'table':t,'total':n*(s*l+t)})(
             rng.randint(1,60),rng.randint(1,20),rng.randint(3,4),rng.randint(3,4)),
         constraint='The total is a multiple of the legs for one table and its stools.')
_algebra('train/234','total-seats-from-three-class-allocation','first percent c d',
         lambda first,percent,c,d:int(F(first,1)/(1-F(percent,100)-F(c,d))),
         domains={'first':(1,1500),'percent':(1,98),'c':(1,30),'d':(2,30)},
         valid=lambda **p:_seat_count_valid(**p),
         sample=lambda rng:(lambda b,c,k:{'first':k*(100-b-5*c),'percent':b,'c':c,'d':20})(
             rng.randint(5,40),rng.randint(3,10),rng.randint(1,15)),
         constraint='All classes have a positive integral number of seats.')


def _seat_count_valid(first,percent,c,d):
    rest = 1-F(percent,100)-F(c,d)
    if rest<=0:
        return False
    total = F(first,1)/rest
    return all(x.denominator==1 for x in (total*F(percent,100),total*F(c,d)))


_algebra('train/242','initial-jellybeans-before-two-days','percent remaining',
         lambda percent,remaining:int(F(10000*remaining,(100-percent)**2)),
         domains={'percent':(1,99),'remaining':(1,10000)},
         valid=lambda percent,remaining:_two_days_integer(percent,remaining),
         sample=lambda rng:(lambda ratio,k:{'percent':100-5*ratio,'remaining':ratio**2*k})(
             rng.randint(1,19),rng.randint(1,15)),
         constraint='The initial and intermediate jellybean counts are both integers.')


def _two_days_integer(percent,remaining):
    ratio = F(100-percent,100)
    return (remaining/ratio).denominator==1 and (remaining/ratio**2).denominator==1


_algebra('train/186 train/1388','first-bounce-below-threshold','start _',
         lambda start:start.bit_length(),domains={'start':(2,2000)},
         reference=lambda start:next(n for n in range(20) if F(start,2**n)<1))
_algebra('train/1104','additional-workers-for-shorter-job','old h target',
         lambda old,h,target:old*h//target-old,
         domains={'old':(1,50),'h':(2,80),'target':(1,79)},
         valid=lambda old,h,target:h>target and old*h%target==0,
         sample=lambda rng:(lambda a,b,k:{'old':a,'h':b*k,'target':a*k})(
             *sorted(rng.sample(range(1,11),2)),rng.randint(1,8)),
         edits=(('Four people','4 people'),),
         constraint='The shorter duration requires a greater whole number of workers.')
_algebra('test/294','parallel-workers-multiple-houses','old orig days new target',
         lambda old,orig,days,new,target:old*days*new//(orig*target),
         domains={'old':(1,80),'orig':(1,40),'days':(1,70),'new':(1,50),'target':(1,70)},
         valid=lambda old,orig,days,new,target:old*days*new%(orig*target)==0,
         sample=lambda rng:(lambda a,b,c,d,k:{'old':a*b,'orig':a,'days':c*d,'new':k,'target':d})(
             *(rng.randint(1,8) for _ in range(5))),
         edits=(('Five workers','5 workers'),('four houses','4 houses'),('six days','6 days'),
                ('three days','3 days')),
         constraint='The target workload requires a whole number of workers.')
_algebra('train/1076','repetitions-to-lift-equal-weight','old quantity new',
         lambda old,quantity,new:old*quantity//new,
         valid=lambda old,quantity,new:old*quantity%new==0,
         sample=lambda rng:(lambda a,b,n:{'old':a,'new':b,'quantity':b*n})(
             rng.randint(2,40),rng.randint(2,10),rng.randint(1,10)),
         constraint='Equal cumulative weight requires a whole number of lifts.')
_algebra('train/782','increasing-flight-times','start step n',
         lambda start,step,n:n*start+step*n*(n-1)//2,
         domains={'n':(2,40)},edits=(('first five flights','first 5 flights'),),
         reference=lambda start,step,n:sum(start+step*k for k in range(n)))
_algebra('train/1051 train/1593','distinct-positive-gifts','people stock',
         lambda people,stock:max(0,people*(people+1)//2-stock),
         domains={'people':(2,60),'stock':(1,1800)},
         reference=lambda people,stock:max(0,sum(range(1,people+1))-stock))
_algebra('test/187','largest-weight-from-combined-weight','total d',
         lambda total,d:F(total+2*d,3),domains={'total':(3,300),'d':(1,100)},
         valid=lambda total,d:total>d,constraint='All three dogs have positive weights.')
_algebra('train/1319','compound-interest-rounded','start rate n',
         lambda start,rate,n:_round(start*F(100+rate,100)**n),
         domains={'start':(1,20000),'rate':(1,25),'n':(1,20)},
         edits=(('five years','5 years'),),
         reference=lambda start,rate,n:_round(_compound_loop(start,rate,n)))
_algebra('test/1019','compound-interest-rounded','start rate n',
         lambda start,rate,n:_round(start*F(100+rate,100)**n),
         domains={'start':(1,20000),'rate':(1,25),'n':(1,20)},
         reference=lambda start,rate,n:_round(_compound_loop(start,rate,n)))


def _compound_loop(start,rate,n):
    balance = F(start)
    for _ in range(n):
        balance += balance*F(rate,100)
    return balance


_algebra('train/847','equal-rates-with-integer-sample','a b c',
         lambda a,b,c:c*a//b,
         domains={'a':(1,100),'b':(2,120),'c':(2,160)},
         valid=lambda a,b,c:a<b and c*a%b==0,
         sample=lambda rng:(lambda a,b,k,m:{'a':k*a,'b':k*b,'c':m*b})(
             *sorted(rng.sample(range(1,13),2)),rng.randint(1,8),rng.randint(1,12)),
         constraint='The proportion yields a whole number of students in both classes.')
_algebra('test/254','sample-to-school-population','a b c',
         lambda a,b,c:c*a//b,
         domains={'a':(1,100),'b':(2,120),'c':(2,1000)},
         valid=lambda a,b,c:a<b and c>b and c*a%b==0,
         sample=lambda rng:(lambda a,b,k,m:{'a':k*a,'b':k*b,'c':(k+m)*b})(
             *sorted(rng.sample(range(1,13),2)),rng.randint(1,8),rng.randint(1,30)),
         constraint='The class is a proper subset of the school and the estimate is a whole number.')

_geometry('train/16','right-triangle-affine-leg-and-area','d area',
          lambda d,area:_triangle_hypotenuse(d,area),
          domains={'d':(1,100),'area':(1,2000)},
          valid=lambda d,area:_triangle_leg(d,area) is not None,
          sample=lambda rng:_sample_triangle_area(rng),
          edits=(('$1$ foot shorter','$1$ ft shorter'),),
          constraint='The positive integer legs satisfy the given order, difference and area and have integer hypotenuse.',
          reference=lambda d,area:next(
              isqrt(x*x+(2*x-d)**2) for x in range(1,100) if x*(2*x-d)==2*area))


def _triangle_leg(d,area):
    root = isqrt(d*d+16*area)
    if root*root!=d*d+16*area or (d+root)%4:
        return None
    leg = (d+root)//4
    other = 2*leg-d
    hyp2 = leg*leg+other*other
    return leg if leg<other and isqrt(hyp2)**2==hyp2 else None


def _triangle_hypotenuse(d,area):
    leg = _triangle_leg(d,area)
    return isqrt(leg*leg+(2*leg-d)**2)


_RIGHT_TRIANGLES = [
    (a,b,isqrt(a*a+b*b))
    for a in range(1,50) for b in range(a+1,60)
    if isqrt(a*a+b*b)**2==a*a+b*b
]


def _sample_triangle_area(rng):
    a,b,_ = rng.choice([(a,b,c) for a,b,c in _RIGHT_TRIANGLES if b<2*a])
    return {'d':2*a-b,'area':a*b//2}


_geometry('test/432','triangle-area-after-similarity-scale','a b c percent',
          lambda a,b,c,percent:F(isqrt(_heron(a,b,c)),4)*F(100+percent,100)**2,
          domains={'a':(1,80),'b':(1,80),'c':(1,80),'percent':(1,100)},
          valid=lambda a,b,c,percent:_heron(a,b,c)>0 and isqrt(_heron(a,b,c))**2==_heron(a,b,c),
          sample=lambda rng:dict(zip('abc',rng.choice(_RIGHT_TRIANGLES)),percent=rng.randint(1,100)),
          edits=((', as shown',''),),
          constraint='The original sides form a nondegenerate triangle with rational area.')


def _heron(a,b,c):
    return (a+b+c)*(a+b-c)*(a-b+c)*(-a+b+c)


_prealgebra('train/119','rate-times-race-duration','rate distance pace',
            lambda rate,distance,pace:rate*distance*pace)
_prealgebra('test/531','reading-two-different-rates','fiction history time pages',
            lambda fiction,history,time,pages:pages*time*(F(1,fiction)+F(1,history)),
            edits=(('five pages','5 pages'),('two pages','2 pages'),
                   ('seven minutes','7 minutes'),('thirty pages','30 pages')))
_prealgebra('train/151','complete-chair-row-removals','row stock students',
            lambda row,stock,students:stock-row*_ceil_div(students,row),
            domains={'row':(2,40),'stock':(2,2400),'students':(1,2400)},
            valid=lambda row,stock,students:stock%row==0 and students<=stock,
            sample=lambda rng:(lambda row,n:{'row':row,'stock':row*n,
                'students':rng.randint(1,row*n)})(rng.randint(2,40),rng.randint(2,60)),
            constraint='The existing chairs form complete rows, and there are enough chairs for the students.')
_prealgebra('train/219','combined-percentages-for-equal-groups','total a b',
            lambda total,a,b:total*(a+b)//200,
            domains={'total':(2,4000),'a':(1,100),'b':(1,100)},
            valid=lambda total,a,b:total%2==0 and total*a%200==0 and total*b%200==0,
            sample=lambda rng:{'total':200*rng.randint(1,20),'a':rng.randint(1,100),
                               'b':rng.randint(1,100)},
            constraint='There are equal whole-number groups, and both percentages give whole counts.')
_prealgebra('test/826','neither-course-from-intersection','total a b both',
            lambda total,a,b,both:total-a-b+both,
            domains={'total':(2,100),'a':(1,100),'b':(1,100),'both':(1,100)},
            valid=lambda total,a,b,both:0<both<=min(a,b) and a+b-both<=total,
            sample=lambda rng:_course_counts(rng),
            constraint='The intersection is no larger than either group, and the union fits within the class.',
            reference=lambda total,a,b,both:total-((a-both)+(b-both)+both))


def _course_counts(rng):
    only_a,only_b,both,neither = (rng.randint(1,25) for _ in range(4))
    return {'total':only_a+only_b+both+neither,'a':only_a+both,'b':only_b+both,'both':both}


_prealgebra('train/692','count-from-complementary-fraction','a b total',
            lambda a,b,total:total*(b-a)//b,
            domains={'a':(1,20),'b':(2,30),'total':(2,900)},
            valid=lambda a,b,total:a<b and total*a%b==0,
            sample=lambda rng:(lambda b:{'a':rng.randint(1,b-1),'b':b,
                                        'total':b*rng.randint(1,30)})(rng.randint(2,20)),
            edits=(('Three-fourths','3/4'),),
            constraint='The fraction is proper and gives integral counts for both colors.')
_prealgebra('train/384','initial-contest-count','cut a b left',
            lambda cut,a,b,left:int(F(100*left*b,(100-cut)*a)),
            domains={'cut':(1,99),'a':(1,25),'b':(2,30),'left':(1,1000)},
            valid=lambda cut,a,b,left:a<b and F(left*b,a).denominator==1
                 and F(100*left*b,(100-cut)*a).denominator==1,
            sample=lambda rng:(lambda cut,b,k:{'cut':cut,'a':1,'b':b,
                                               'left':(100-cut)*k})(
                 rng.randint(5,95),rng.randint(2,30),rng.randint(1,10)),
            constraint='All three rounds have positive integral contestant counts and both eliminations are nonempty.')
_prealgebra('test/789','complete-portions-from-fractional-stock','a b c d',
            lambda a,b,c,d:(b*c)//(a*d),
            valid=lambda a,b,c,d:a<b and c<d,
            constraint='Both the portion and remaining amount are proper fractions.')
_prealgebra('train/1168','average-excluding-childless-families','total avg empty',
            lambda total,avg,empty:_round(F(total*avg,total-empty),1),
            domains={'total':(2,60),'avg':(1,10),'empty':(1,59)},
            valid=lambda total,avg,empty:empty<total,
            edits=(('Ten families','10 families'),('exactly two','exactly 2')),
            constraint='At least one family has children.')
_algebra('test/370','drips-per-liter','a b _ _',
         lambda a,b:F(1000*b,a),
         valid=lambda a,b:a<b and 1000*b%a==0,
         constraint='A single drip is smaller than one milliliter, and a liter contains a whole number of drips.')
_algebra('train/1484','age-offsets-across-time','difference ahead factor before',
         lambda difference,ahead,factor,before:2*_younger_age(difference,ahead,factor,before)+difference,
         domains={'difference':(1,40),'ahead':(1,20),'factor':(2,10),'before':(1,15)},
         valid=lambda difference,ahead,factor,before:_younger_age(difference,ahead,factor,before)>before
            and _younger_age(difference,ahead,factor,before).denominator==1
            and _younger_age(difference,ahead,factor,before)+difference<=100,
         edits=(('six years older','6 years older'),('Eight years from now','8 years from now'),
                ('four times as old','4 times as old'),('four years before','4 years before')),
         constraint='Both current ages are positive integers, and Louise was already alive at the earlier time.')


def _younger_age(difference,ahead,factor,before):
    return F(difference+ahead+factor*before,factor-1)


_algebra('test/115','parent-age-from-earlier-sum','factor before total',
         lambda factor,before,total:(total+2*before)//(factor+1),
         domains={'factor':(2,12),'before':(1,12),'total':(2,130)},
         valid=lambda factor,before,total:(total+2*before)%(factor+1)==0
             and (total+2*before)//(factor+1)>before
             and 13<=(factor-1)*(total+2*before)//(factor+1)
             and factor*(total+2*before)//(factor+1)<=110,
         edits=(('five times','5 times'),('three years ago','3 years ago')),
         constraint='Both ages are positive integers, the son was already alive, and the father is at least 13 years older.')
_algebra('train/1712','grandparent-age-multiple','factor birth',
         lambda factor,birth:birth//(factor-1),
         domains={'factor':(2,14),'birth':(26,95)},
         valid=lambda factor,birth:birth%(factor-1)==0 and birth+birth//(factor-1)<=110,
         edits=(('twelve times','12 times'),),
         constraint='The ages are whole years, and the grandfather is at most 110 years old.')
_geometry('train/671','square-pyramid-frustum-volume','a h b k',
          lambda a,h,b,k:F(a*a*h-b*b*k,3),
          domains={'a':(1,60),'h':(1,60),'b':(1,40),'k':(1,40)},
          valid=lambda a,h,b,k:a>b and h>k and a*k==b*h,
          sample=lambda rng:(lambda a,h,m,n:{'a':a*n,'h':h*n,'b':a*m,'k':h*m})(
              rng.randint(1,10),rng.randint(1,10),*sorted(rng.sample(range(1,6),2))),
          constraint='The smaller pyramid is strictly smaller and similar to the original pyramid.',
          reference=lambda a,h,b,k:F((h-k)*(a*a+a*b+b*b),3))
