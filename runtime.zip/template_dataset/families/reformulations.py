"""Explicit, authorized reformulations of constant-answer source questions.

The original builders and patched corpus remain untouched. These replacements
ask a different, nonconstant mathematical question in the same source setting;
metadata records both questions and answers. No non-allowlisted ID is changed."""
from copy import deepcopy
from fractions import Fraction as Q
from math import comb, factorial, gcd, isqrt, prod

from template_dataset.core import Template, canonical_answer

_BUILDERS = {}


def I(lo, hi):
    return {'type': 'int', 'min': lo, 'max': hi}


def L(n, lo, hi):
    return {'type': 'list[int]', 'min_length': n, 'max_length': n, 'items': I(lo, hi)}


def _draw(rng, domain):
    if 'choices' in domain:
        return deepcopy(rng.choice(domain['choices']))
    if domain.get('type', '').startswith('list'):
        return [_draw(rng, domain['items']) for _ in range(rng.randint(domain['min_length'], domain['max_length']))]
    return rng.randint(domain['min'], domain['max'])


def case(*ids):
    def decorate(fn):
        for pid in ids:
            _BUILDERS[pid] = fn
        return fn
    return decorate


def _make(base, render, solve, *, proof, rationale, reference=None, parameters=None,
          original=None, valid=None, sample=None, constraints=None):
    reuse = parameters is None
    parameters = deepcopy(base.parameters if reuse else parameters)
    original = deepcopy(base.original if original is None else original)
    inherit_constraints = reuse and valid is None
    if valid is None:
        valid = base.validate if reuse else lambda p: True
    if sample is None:
        sample = base.sample if reuse else lambda rng: {k: _draw(rng, d) for k, d in parameters.items()}
    result = Template('reformulated.' + base.family, parameters, original, render, solve,
                      sample, valid, list(dict.fromkeys((base.constraints if inherit_constraints else []) + list(constraints or ()))), reference,
                      'Authorized reformulation of a constant-answer question. ' + rationale)
    result.reformulation = {
        'version': 1, 'source_family': base.family, 'source_original_parameters': deepcopy(base.original),
        'source_original_rendered': base.render(base.original),
        'source_original_answer': canonical_answer(base.solve(base.original)),
        'reformulated_original_parameters': deepcopy(original),
        'reformulated_original_rendered': render(original),
        'reformulated_original_answer': canonical_answer(solve(original)),
        'proof': proof, 'rationale': rationale,
    }
    return result


def _det3(a):
    return (a[0][0]*(a[1][1]*a[2][2]-a[1][2]*a[2][1])
            - a[0][1]*(a[1][0]*a[2][2]-a[1][2]*a[2][0])
            + a[0][2]*(a[1][0]*a[2][1]-a[1][1]*a[2][0]))


def _cross(a, b):
    return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]


@case('algebra/test/101')
def mirrored(base):
    return _make(base,
        lambda p: base.render(p).split(' Evaluate ')[0] + f" Evaluate f({p['center']+p['distance']}).",
        lambda p: (p['distance']**2-p['inner_radius']**2)*(p['distance']**2-p['outer_radius']**2),
        reference=lambda p: prod(p['center']+p['distance']-r for r in
                                [p['center']-p['outer_radius'],p['center']-p['inner_radius'],
                                 p['center']+p['inner_radius'],p['center']+p['outer_radius']]),
        proof='Mirrored probes have equal values because the polynomial is even about its center.',
        rationale='Evaluate one probe rather than subtracting two equal probe values.')


@case('algebra/test/318')
def symmetric_squares(base):
    return _make(base,
        lambda p: f"Find the sum of the squares of the real solutions of x^2+{p['left_1']}^2={p['right_2']}^2.",
        lambda p: 2*(p['right_2']**2-p['left_1']**2),
        valid=lambda p: p['right_2']>p['left_1'],
        proof='The two real roots are opposites, so their sum is zero.',
        rationale='Query the second power sum, retaining the same quadratic equation.',
        constraints=['The right positive constant is greater than the left one.'])


@case('algebra/train/1087')
def nonzero_root(base):
    return _make(base,lambda p:f"Find the nonzero real solution of x^2=-{p['right_1']}x.",
                 lambda p:-p['right_1'],
                 proof='For every positive coefficient only the zero root is nonnegative.',
                 rationale='Ask for the other root instead of the invariant nonnegative root count.')


@case('algebra/train/115')
def symmetric_radical(base):
    return _make(base,
        lambda p:f"If sqrt({p['left_1']}x^2+{p['left_2']})=sqrt({p['right_3']}), find the sum of the squares of all real solutions.",
        lambda p:Q(2*(p['right_3']-p['left_2']),p['left_1']),
        valid=lambda p:p['right_3']>p['left_2'],
        proof='Both possible roots are opposites and have zero average.',
        rationale='Replace the zero average with the second power sum.',
        constraints=['The right radicand exceeds the constant left radicand.'])


@case('algebra/train/1379')
def sideways(base):
    return _make(base,
        lambda p:f"For the parabola x={p['quadratic_coefficient']}y^2+({p['linear_coefficient']})y+({p['constant']}), find the x-coordinate of its vertex.",
        lambda p:Q(p['constant'])-Q(p['linear_coefficient']**2,4*p['quadratic_coefficient']),
        reference=lambda p:(lambda y:p['quadratic_coefficient']*y*y+p['linear_coefficient']*y+p['constant'])(Q(-p['linear_coefficient'],2*p['quadratic_coefficient'])),
        proof='Setting y=0 always yields exactly one x-intercept.',
        rationale='Ask for the vertex coordinate of the same sideways parabola.')


@case('algebra/train/1429')
def circle_roots(base):
    return _make(base,
        lambda p:f"Find the sum of the squared x-coordinates of the intersections of y={p['fixed_y']} and x^2+y^2={p['squared_radius']}.",
        lambda p:2*(p['squared_radius']-p['fixed_y']**2),
        valid=lambda p:p['squared_radius']>p['fixed_y']**2,
        proof='The x-coordinates are opposite, so their sum is zero.',
        rationale='Query squared distances from the y-axis instead of their cancelling signed sum.',
        constraints=['The horizontal line cuts the circle in two distinct points.'])


@case('algebra/train/33')
def reciprocal_equation(base):
    return _make(base,
        lambda p:f"Find the product of all real solutions of ({p['left_1']}x)/{p['left_2']}={p['right_3']}/x.",
        lambda p:Q(-p['left_2']*p['right_3'],p['left_1']),
        proof='Multiplication by x gives two opposite nonzero roots.',
        rationale='Use the product of the same two roots instead of their zero sum.')


@case('algebra/train/39')
def integer_roots(base):
    return _make(base,
        lambda p:f"The square of an integer is {p['increment']} greater than the integer itself. Find the larger possible integer.",
        lambda p:(1+isqrt(1+4*p['increment']))//2,
        reference=lambda p:next(n for n in range(1,isqrt(p['increment'])+3) if n*n-n==p['increment']),
        proof='The two roots of x^2-x-increment have sum one by Vieta.',
        rationale='Ask for the larger integer root instead of the invariant sum.')


@case('counting_and_probability/test/186')
def binomial_sum(base):
    return _make(base,lambda p:rf"Compute $\binom{{{p['n']}}}{{{p['k']}}}+\binom{{{p['n']}}}{{{p['n']-p['k']}}}$.",
        lambda p:2*comb(p['n'],p['k']),reference=lambda p:comb(p['n'],p['k'])+comb(p['n'],p['n']-p['k']),
        proof='Complementary binomial coefficients are equal.',rationale='Add the complementary counts rather than subtracting them.')


@case('counting_and_probability/train/141','counting_and_probability/train/495','counting_and_probability/train/649')
def binomial_adjacent(base):
    return _make(base,lambda p:rf"Compute $\binom{{{p['n']}}}{{{p['n']-1}}}$.",
        lambda p:p['n'],reference=lambda p:comb(p['n'],p['n']-1),
        proof='Both boundary binomial coefficients equal one.',
        rationale='Move one step inside Pascal\'s triangle and count all-but-one selections.')


@case('geometry/train/735')
def right_triangle_area(base):
    domains=deepcopy(base.parameters);domains['u']=I(31,100)
    original=dict(base.original,u=31)
    return _make(base,
        lambda p:f"A triangle has side lengths sqrt({p['coefficient']*p['u']-p['offset']}), sqrt({p['coefficient']*p['u']+p['offset']}), sqrt({2*p['coefficient']*p['u']}). Find the square of its area.",
        lambda p:Q((p['coefficient']*p['u'])**2-p['offset']**2,4),parameters=domains,original=original,
        proof='The largest side square is the sum of the other two, so its opposite angle is always 90 degrees.',
        rationale='Specify u and ask for the squared area of the same right triangle.',
        constraints=['u>=31 guarantees both leg radicands are positive.'])


@case('geometry/train/804')
def other_sine(base):
    return _make(base,
        lambda p:f"Right triangle ABC has A=90 degrees, AB={p['leg']} and BC={p['hypotenuse']}. Find sin(C).",
        lambda p:Q(p['leg'],p['hypotenuse']),valid=lambda p:0<p['leg']<p['hypotenuse'],
        proof='The sine of the specified right angle is always one.',rationale='Ask for the sine of the opposite acute angle using the given sides.',constraints=['The leg is shorter than the hypotenuse.'])


@case('intermediate_algebra/test/164')
def quartic_all_root_squares(base):
    return _make(base,
        lambda p:f"Let z1,z2,z3,z4 be all complex roots, with multiplicity, of z^4-{p['left_1']}z^2-{p['left_2']}={p['right_3']}. Find z1^2+z2^2+z3^2+z4^2.",
        lambda p:2*p['left_1'],proof='The quadratic in x^2 has one positive and one negative root, hence exactly two real x roots.',
        rationale='Ask for the second Newton sum of all roots instead of the constant real-root count.')


@case('intermediate_algebra/test/243')
def cubic_power_sum(base):
    return _make(base,
        lambda p:f"Let z1,z2,z3 be all complex roots of z^3+{p['left_1']}z+{p['left_2']}={p['right_3']}. Find z1^3+z2^3+z3^3.",
        lambda p:3*(p['right_3']-p['left_2']),proof='The cubic derivative is strictly positive, so the real-root count is one.',
        rationale='Use the third Newton sum of the same cubic.')


@case('intermediate_algebra/train/128')
def quartic_product(base):
    return _make(base,
        lambda p:f"Let z1,z2,z3,z4 be all complex roots of z^4-{p['left_1']}z^2+{p['left_2']}={p['right_3']}. Find z1*z2*z3*z4.",
        lambda p:p['left_2']-p['right_3'],proof='Every integer root of an even polynomial is paired with its negative.',
        rationale='Ask for the Vieta product of all complex roots instead of the cancelling integer-root sum.')


@case('intermediate_algebra/train/858')
def degree_ten_power_sum(base):
    return _make(base,
        lambda p:f"Let z1,...,z10 be all complex roots with multiplicity of z^10+{p['left_1']}z^9+{p['left_2']}z^8+{p['left_3']}z^7-{p['left_4']}z^6={p['right_5']}. Find the sum of their squares.",
        lambda p:p['left_1']**2-2*p['left_2'],proof='The nonzero coefficient sign sequence has one change, so exactly one positive root exists.',
        rationale='Compute the second Newton sum of the original polynomial rather than its invariant positive-root count.')


@case('intermediate_algebra/test/192')
def reciprocal_difference(base):
    return _make(base,
        lambda p:f"Nonzero real a,b satisfy {p['coefficient']}*a*b=a-b. Find (1/b-1/a)^2.",
        lambda p:p['coefficient']**2,
        proof='Squaring a-b=k ab yields a/b+b/a-k^2 ab=2.',
        rationale='Query the reciprocal difference determined by the same relation.')


@case('intermediate_algebra/test/278')
def amgm_product(base):
    return _make(base,
        lambda p:f"Positive x,y,z satisfy (x+{p['a']}/y)(y+{p['b']}/z)(z+{p['c']}/x)={8*isqrt(p['a']*p['b']*p['c'])}. Find xyz.",
        lambda p:isqrt(p['a']*p['b']*p['c']),
        proof='Equality in all three AM-GM bounds forces xy=a,yz=b,zx=c and gives exactly one positive triple.',
        rationale='Ask for the product of that unique triple rather than its count.')


@case('intermediate_algebra/test/580')
def positive_norm(base):
    return _make(base,
        lambda p:f"For positive real x,y with xy={p['product']}, find the minimum of x^2+y^2.",
        lambda p:2*p['product'],parameters={'product':I(1,1000)},original={'product':4},
        proof='The original homogeneous relation admits x=y=0, making the norm minimum zero.',
        rationale='Exclude the trivial zero solution by fixing a positive product and retain the norm minimization.',
        )


@case('intermediate_algebra/test/683')
def reciprocal_roots(base):
    return _make(base,
        lambda p:f"Nonzero complex r,s satisfy 1/(r+s)=1/r+1/s. Find (r/s)^{p['power']}+(s/r)^{p['power']}.",
        lambda p:2 if p['power']%3==0 else -1,
        parameters={'power':I(1,150)},original={'power':3},
        reference=lambda p:_cube_root_power_sum(p['power']),
        proof='r/s is a primitive cube root of unity, and the original exponent was constrained to multiples of 3.',
        rationale='Use a conjugate-symmetric power sum, which is rational for every integer exponent, and allow all exponents.')


@case('intermediate_algebra/test/691')
def lagrange_leading(base):
    return _make(base,
        lambda p:f"For distinct real a,b,c, evaluate (({p['scale']}a+{p['shift']})^2)/((a-b)(a-c))+(({p['scale']}b+{p['shift']})^2)/((b-a)(b-c))+(({p['scale']}c+{p['shift']})^2)/((c-a)(c-b)).",
        lambda p:p['scale']**2,
        reference=lambda p:sum(Q((p['scale']*a+p['shift'])**2,prod(a-b for b in (0,1,3) if b!=a)) for a in (0,1,3)),
        proof='Original interpolation is in the node variable with leading coefficient 1.',
        rationale='Apply the existing scale to the interpolation nodes, so interpolation recovers a variable leading coefficient.')


@case('intermediate_algebra/test/699')
def functional_offset(base):
    return _make(base,
        lambda p:f"Consider all real-valued functions on positive reals satisfying f(xy)=f(x)f(y)-{p['offset']}. Find the product of their possible values at 1.",
        lambda p:-p['offset'],proof='Associativity with nonzero offset forces a constant function; its value solves t^2-t-offset=0, givingtwo functions.',
        rationale='Ask for the product of the two possible function values, rather than the invariant count.')


@case('intermediate_algebra/test/81')
def scaled_asymptote(base):
    return _make(base,
        lambda p:f"For f(x)=({p['a']}x^2+({p['b']})x+({p['c']}))/({p['d']}x^3+({p['e']})x^2+({p['f']})x+({p['g']})), find lim as x tends to positive infinity of x*f(x).",
        lambda p:Q(p['a'],p['d']),proof='The numerator degree is less than the denominator degree, so the horizontal asymptote is 0.',
        rationale='Measure the leading decay coefficient instead of the zero limit.')


@case('intermediate_algebra/train/1005')
def cylinder(base):
    return _make(base,
        lambda p:f"A closed circular cylinder of volume {p['volume']} has least total surface area at radius R and height H. Find pi*R^3.",
        lambda p:Q(p['volume'],2),proof='Surface-area minimization always gives H=2R.',
        rationale='Ask for a rational volume-related size of the minimizing cylinder rather than its invariant aspect ratio.')


@case('intermediate_algebra/train/1065')
def complex_norm(base):
    return _make(base,
        lambda p:f"Let z=((-11+13i)^{p['p']}*(24-7i)^{p['q']})/(3+4i). Find |z|^2.",
        lambda p:Q(290**p['p']*625**p['q'],25),
        proof='A nonzero complex number and its conjugate have equal modulus.',
        rationale='Find the squared modulus of z itself rather than the unit modulus conjugate quotient.')


@case('intermediate_algebra/train/1158')
def even_equation(base):
    return _make(base,
        lambda p:f"Find the sum of the squares of the real solutions of {p['base']}^|x|+{p['linear']}|x|={p['base']**p['root']+p['linear']*p['root']}.",
        lambda p:2*p['root']**2,
        parameters={'base':I(2,20),'linear':I(1,30),'root':I(1,12)},original={'base':2,'linear':3,'root':3},
        proof='The function of |x| is strictly increasing, giving an opposite pair whose sum vanishes.',
        rationale='Construct an exact integral root and ask for its second power sum.',
        reference=lambda p:sum(x*x for x in range(-12,13) if p['base']**abs(x)+p['linear']*abs(x)==p['base']**p['root']+p['linear']*p['root']))


@case('intermediate_algebra/train/1185')
def binomial_alternating_partial(base):
    return _make(base,
        lambda p:rf"Compute $\sum_{{j=0}}^{{{p['last']}}}(-1)^j\binom{{{p['n']}}}{{j}}$.",
        lambda p:(-1)**p['last']*comb(p['n']-1,p['last']),
        parameters={'n':I(3,100),'last':I(1,99)},original={'n':100,'last':50},valid=lambda p:p['last']<p['n'],
        sample=lambda r:(lambda n:{'n':n,'last':r.randint(1,n-1)})(r.randint(3,100)),
        reference=lambda p:sum((-1)**j*comb(p['n'],j) for j in range(p['last']+1)),
        proof='The original full binomialsum is (1-1)^n=0.',
        rationale='Stop the alternating sum at an independently chosen interior term.',constraints=['1<=last<n.'])


@case('intermediate_algebra/train/1197')
def translation_function(base):
    return _make(base,
        lambda p:f"A real function satisfies f(x+f(y))=x+y+{p['constant']} for all real x,y. Find f(0).",
        lambda p:Q(p['constant'],2),proof='The equation has exactly one solutionf(x)=x+constant/2.',
        rationale='Evaluate the unique solution rather than count it.')


@case('intermediate_algebra/train/182')
def quadratic_function(base):
    return _make(base,
        lambda p:f"Among all real functions satisfying f(x+y)f(x-y)=(f(x)+f(y))^2-{p['coefficient']}x^2*f(y), find the sum of their possible values at x=1.",
        lambda p:Q(p['coefficient'],4),proof='The only solutions are f=0 and f(x)=coefficient*x^2/4.',
        rationale='Ask for the sum of the two solution values rather than the invariant number of functions.')


@case('intermediate_algebra/train/200')
def nested_operation(base):
    def evaluate(p):
        out=Q(p['last'])
        for k in range(p['last']-1,p['second']-1,-1):
            out=Q(k-out,1-k*out)
        return out
    return _make(base,
        lambda p:f"For a*b=(a-b)/(1-ab), compute {p['second']}*(({p['second']+1})*(...*({p['last']-1}*{p['last']}))). The consecutive block is associated from the right.",
        evaluate,reference=lambda p:_nested_reference(p['second'],p['last']),
        parameters={'second':I(2,30),'last':I(5,50)},original={'second':2,'last':8},
        valid=lambda p:p['last']>=p['second']+3,
        sample=lambda r:(lambda a:{'second':a,'last':r.randint(a+3,50)})(r.randint(2,30)),
        proof='The original outer factor1 sends every defined inner value to1.',
        rationale='Remove that absorbing outer factor and evaluate the original nested inner operation.',
        constraints=['The integer block has at leastfour terms.'])


@case('intermediate_algebra/train/293','intermediate_algebra/train/547')
def normalized_function(base):
    difference=base.family.endswith('nonzero_difference_multiplicativity')
    operation='x-y' if difference else 'xy'
    condition='never vanishes' if difference else 'has f(0) nonzero'
    return _make(base,
        lambda p:f"A real function f that {condition} satisfies f({operation})=f(x)f(y)/{p['normalization']} for all real x,y. Find f({p['point']}).",
        lambda p:p['normalization'],parameters={'point':I(-500,500),'normalization':I(1,100)},
        original={'point':base.original['point'],'normalization':2},
        proof='The original equation and nonvanishing condition force the constant function 1.',
        rationale='Generalize the multiplicative normalization inside the functional equation; its unique constant solution changes.')


@case('intermediate_algebra/train/387')
def functional_peak(base):
    return _make(base,
        lambda p:f"A real function satisfies {p['a']}f(xy)+{p['b']}f(xz)-{p['c']}f(x)f(yz)>={Q((p['a']+p['b'])**2,4*p['c'])} for all real x,y,z. Find f(0).",
        lambda p:Q(p['a']+p['b'],2*p['c']),proof='At x=y=z=0 the concave quadratic reaches its maximum; the original admits exactly one constant function.',
        rationale='Recover the function value forced by the quadratic maximum.')


@case('intermediate_algebra/train/468')
def factorial_product(base):
    return _make(base,
        lambda p:f"Compute the product (1+{p['a']}/1)(1+{p['a']}/2)...(1+{p['a']}/{p['b']}).",
        lambda p:comb(p['a']+p['b'],p['b']),reference=lambda p:prod(Q(j+p['a'],j) for j in range(1,p['b']+1)),
        proof='Both original numerator and denominator equal the same symmetric binomial coefficient.',
        rationale='Evaluate one product instead of dividing two equal products.')


@case('intermediate_algebra/train/567')
def partial_residue(base):
    return _make(base,
        lambda p:base.render(p).replace('Find $A+B+C+D+E$.','Find A.'),
        lambda p:Q(1,prod(v-p['shifts'][0] for v in p['shifts'][1:])),
        proof='The coefficient of 1/x at infinity vanishes because the denominator has degree 5, so the residues sum to 0.',
        rationale='Find the first individual partial fraction residue.')


@case('intermediate_algebra/train/642')
def reciprocal_power_sum(base):
    return _make(base,
        lambda p:f"Let x={p['base']}^{p['exponent']}-{p['base']}^(-{p['exponent']}) and y={p['base']}^{p['exponent']}+{p['base']}^(-{p['exponent']}). Find x^2+y^2.",
        lambda p:2*(Q(p['base']**(2*p['exponent']))+Q(1,p['base']**(2*p['exponent']))),
        parameters={'base':I(2,30),'exponent':I(1,12)},original={'base':3,'exponent':4},
        reference=lambda p:(Q(p['base']**p['exponent'])-Q(1,p['base']**p['exponent']))**2+(Q(p['base']**p['exponent'])+Q(1,p['base']**p['exponent']))**2,
        proof='The original difference of squares equals -4 independently of the power.',
        rationale='Use the sum of squares, withbounded powers to keep exact answers compact.')


@case('intermediate_algebra/train/730')
def reciprocal_function(base):
    return _make(base,
        lambda p:f"A real function on positive reals satisfies f({p['base']}^x)+x*f({p['base']}^(-x))=1 for all real x. Find f({p['base']}^{p['exponent']}).",
        lambda p:Q(1-p['exponent'],1+p['exponent']**2),
        parameters={'base':I(2,100),'exponent':I(2,30)},original={'base':2,'exponent':2},
        proof='Using x=1 and x=-1 forces f(base)=0.',
        rationale='Evaluate at a variable exponent using the two linear equations for opposite exponents.')


@case('intermediate_algebra/train/797')
def triangle_ratio(base):
    return _make(base,
        lambda p:f"For real x,y not both zero, find the maximum of |{p['a']}x+{p['b']}y|/(|x|+|y|).",
        lambda p:max(p['a'],p['b']),proof='In the original normalized ratio the triangle inequality boundsare0 and1.',
        rationale='Use an unweighted denominator, obtaining the operator norm of the weighted linear form.')


@case('intermediate_algebra/train/888')
def fixed_complex(base):
    return _make(base,
        lambda p:f"Let f(z)=i*conjugate(z). Find the sum of (Re z)^2 over all z with |z|={p['radius']} and f(z)=z.",
        lambda p:p['radius']**2,proof='The fixedset is the lineRe z=Im z, intersecting every positive-radius circle in two points.',
        rationale='Measure the squared real coordinates of the same two fixed points.')


@case('intermediate_algebra/train/922')
def cube_ratio(base):
    return _make(base,
        lambda p:f"Positive a,b satisfy a^3+b^3={p['coefficient']}(a+b). Find a^2-ab+b^2.",
        lambda p:p['coefficient'],proof='Dividing the sum of cubes relationbya+b makes the original quotient expression equal 1.',
        rationale='Recover the quadratic form determined by the original sum of cubes relation.')


@case('intermediate_algebra/train/974')
def logarithm_ratio(base):
    return _make(base,
        lambda p:f"Compute 1/(1+log_({p['base']}^{p['q']+p['r']})({p['base']}^{p['p']})).",
        lambda p:Q(p['q']+p['r'],p['p']+p['q']+p['r']),
        parameters={'base':I(2,20),'p':I(1,20),'q':I(1,20),'r':I(1,20)},original={'base':2,'p':1,'q':2,'r':3},
        proof='The three original reciprocal terms sum to 2*(log a+log b+log c)/log(abc)=2.',
        rationale='Evaluate one of the complementary logarithm terms, using common-base powers for an exact rational answer.')


@case('intermediate_algebra/train/976')
def exponential_minimum(base):
    return _make(base,
        lambda p:f"Real x,y satisfy {p['base']}^({p['quadratic']}x^2+{p['linear']}y)+{p['base']}^({p['linear']}x+{p['quadratic']}y^2)=1. Find x+y.",
        lambda p:Q(-p['linear'],p['quadratic']),
        proof='The joint constraint makes the minimum exactly 1, attained uniquely at x=y=-linear/(2*quadratic).',
        rationale='Find the coordinate sum of the minimizing pair rather than count it.')


@case('number_theory/train/533')
def prime_valuation(base):
    def valuation(p):
        n=p['base']**(p['exponent']+1)-p['base']**p['exponent'];v=0
        while n%2==0:v+=1;n//=2
        return v
    return _make(base,
        lambda p:f"Find the largest integer k such that 2^k divides {p['base']}^{p['exponent']+1}-{p['base']}^{p['exponent']}.",
        lambda p:p['exponent']*_v2(p['base'])+_v2(p['base']-1),reference=valuation,
        proof='The power difference is base^exponent*(base-1), always even, so its least prime factor is 2.',
        rationale='Ask for the exact2-adic valuation instead of the invariant smallest prime.')


def _v2(n):
    count=0
    while n%2==0:count+=1;n//=2
    return count


@case('prealgebra/test/503')
def consecutive_first(base):
    return _make(base,
        lambda p:f"The sum of {p['count']} consecutive whole numbers is {p['total']}. Find the smallest number.",
        lambda p:p['total']//p['count']-p['count']//2,
        reference=lambda p:next(a for a in range(p['total']//p['count']+1) if sum(range(a,a+p['count']))==p['total']),
        proof='An odd arithmetic progression has equalmean and median.',rationale='Recover the first term of the same progression.')


@case('prealgebra/test/606')
def reciprocal_product(base):
    return _make(base,
        lambda p:'Compute '+'*'.join(f"({a}/{b})" for a,b in zip(p['numerators'],p['denominators']))+'.',
        lambda p:Q(prod(p['numerators']),prod(p['denominators'])),
        reference=lambda p:prod(Q(a,b) for a,b in zip(p['numerators'],p['denominators'])),
        proof='Every original factoris cancelled by its reciprocal.',rationale='Evaluate the three original fractions without appending their cancelling reciprocals.')


@case('prealgebra/train/1076')
def finite_common_multiple(base):
    return _make(base,
        lambda p:f"Find the least positive integer divisible by every number in {p['base_divisor']}, {2*p['base_divisor']}, ..., {p['count']*p['base_divisor']}.",
        lambda p:p['base_divisor']*_lcm_range(p['count']),
        parameters={'base_divisor':I(1,100),'count':I(2,12)},original={'base_divisor':1,'count':6},
        proof='Only zero is divisible by all positive multiples in an unbounded set.',
        rationale='Use a finite initial segment and ask for its least positive common multiple.')


def _lcm_range(n):
    value=1
    for j in range(1,n+1):value=value*j//gcd(value,j)
    return value


@case('prealgebra/train/741')
def odd_power_difference(base):
    return _make(base,
        lambda p:f"Subtract the sum (-1)^{p['odd_power']}+...+(-{p['last_base']})^{p['odd_power']} from 1^{p['odd_power']}+...+{p['last_base']}^{p['odd_power']}.",
        lambda p:2*sum(j**p['odd_power'] for j in range(1,p['last_base']+1)),
        reference=lambda p:sum(j**p['odd_power']-(-j)**p['odd_power'] for j in range(1,p['last_base']+1)),
        proof='The positive and negative odd powers cancel term by term in the original sum.',
        rationale='Take the difference of the same two power sums.')


@case('prealgebra/train/82')
def triangle_angles(base):
    return _make(base,
        lambda p:f"A triangle has an angle of {p['obtuse_angle_degrees']} degrees. Find the sum in degrees of its other two angles.",
        lambda p:180-p['obtuse_angle_degrees'],proof='A triangle with an obtuse angle has exactly oneobtuse angle.',
        rationale='Ask for the remaining angle sum rather than the invariant obtuse angle count.')


@case('precalculus/test/119')
def cube_root_product_norm(base):
    return _make(base,
        lambda p:f"Let u,v,w be the three complex roots with multiplicity of z^3={p['rhs_real']}+({p['rhs_imaginary']})i. Find |uvw|^2.",
        lambda p:p['rhs_real']**2+p['rhs_imaginary']**2,
        proof='The pairwise product sum is the zero linear coefficient in Vieta\'s formulas.',
        rationale='Ask for the squared modulus of the root product instead.')


@case('precalculus/test/171')
def skew_shift(base):
    def matrix(p):
        a,b,c=p['points'];s=p['shift']
        return [[s,b-a,c-a],[a-b,s,c-b],[a-c,b-c,s]]
    return _make(base,
        lambda p:f"For a,b,c={p['points']}, compute the determinant of {matrix(p)}.",
        lambda p:p['shift']*(p['shift']**2+sum((p['points'][j]-p['points'][i])**2 for i,j in ((0,1),(0,2),(1,2)))),
        reference=lambda p:_det3(matrix(p)),parameters={'points':L(3,-20,20),'shift':I(1,20)},original={'points':[0,1,3],'shift':1},
        proof='An odd-order skew-symmetric matrix has determinant zero.',
        rationale='Evaluate a diagonal shift of the same skew-difference matrix at specified numeric points.')


@case('precalculus/test/198')
def cross_component(base):
    return _make(base,
        lambda p:f"Let a=({p['a_numeric_entries'][0]},sqrt(pi),{p['a_numeric_entries'][1]}) and b={p['b_entries']}. Find the second coordinate of a cross b.",
        lambda p:p['a_numeric_entries'][1]*p['b_entries'][0]-p['a_numeric_entries'][0]*p['b_entries'][2],
        reference=lambda p:_cross([p['a_numeric_entries'][0],0,p['a_numeric_entries'][1]],p['b_entries'])[1],
        proof='A vector is orthogonal to its cross product with every vector.',
        rationale='Recover a rational component of the original cross product rather than dotting it with an orthogonal vector.')


@case('precalculus/test/268')
def phasor_norm(base):
    return _make(base,
        lambda p:f"Let z=cos({p['first_angle']} degrees)+i*sin({p['first_angle']} degrees)+cos({p['first_angle']+p['separation']} degrees)+i*sin({p['first_angle']+p['separation']} degrees). Find |z^{p['exponent']}|^2.",
        lambda p:{60:3,90:2,120:1}[p['separation']]**p['exponent'],
        parameters={'first_angle':I(-180,180),'separation':{'type':'int','choices':[60,90,120]},'exponent':I(2,12)},
        original={'first_angle':12,'separation':60,'exponent':6},
        proof='The original domain couples the phase and exponent so that the powered phasor sum is real.',
        rationale='Ask for its squared magnitude and use angular separations with rational cosine.')


def _determinant(matrix):
    a=[list(map(Q,row)) for row in matrix];out=Q(1)
    for i in range(len(a)):
        pivot=next((j for j in range(i,len(a)) if a[j][i]),None)
        if pivot is None:return Q(0)
        if pivot!=i:a[pivot],a[i]=a[i],a[pivot];out=-out
        value=a[i][i];out*=value
        for j in range(i+1,len(a)):
            factor=a[j][i]/value
            for k in range(i+1,len(a)):a[j][k]-=factor*a[i][k]
    return out


@case('precalculus/test/272')
def logarithm_rank_one(base):
    return _make(base,
        lambda p:f"Let x1,...,x{p['dimension']} be positive and different from 1. Set M_ij=log_(xi)(xj). Find det(I+{p['shift']}M), where I is the {p['dimension']} by {p['dimension']} identity matrix.",
        lambda p:1+p['dimension']*p['shift'],
        parameters={'dimension':I(2,6),'shift':I(1,30)},original={'dimension':3,'shift':2},
        reference=lambda p:_determinant([[int(i==j)+p['shift']*Q(j+1,i+1) for j in range(p['dimension'])] for i in range(p['dimension'])]),
        proof='Change of base expresses the logarithm matrix as a rank-one outer product.',
        rationale='Shift the rank-one logarithm matrix by the identity, preserving its nonzero eigenvalue.')


@case('precalculus/test/280')
def cyclotomic_norm(base):
    return _make(base,
        lambda p:f"Let zeta=exp(2*pi*i/{p['prime']}). Compute the product of (1-zeta^j) over j=1,...,{p['prime']-1}.",
        lambda p:p['prime'],parameters={'prime':{'type':'int','choices':[2,3,5,7,11,13,17,19,23,29,31,37,41,43]}},original={'prime':17},
        proof='Exhaustive cyclotomic reduction modulo the 5th and 17th cyclotomic polynomials gives 1 for all rational-valued original cases; sign folding and Galois automorphisms cover the declared domain.',
        rationale='Replace the invariant mixed-root product with the classical variable-order cyclotomic norm.')


@case('precalculus/test/30')
def weighted_reciprocal_tangents(base):
    return _make(base,
        lambda p:f"Given tan(x)={p['tangent']}, compute 2/(1-{p['coefficient']}tan(x)^2)+1/(1-cot(x)^2/{p['coefficient']}).",
        lambda p:Q(2-p['coefficient']*p['tangent']**2,1-p['coefficient']*p['tangent']**2),
        parameters={'coefficient':I(1,20),'tangent':I(2,20)},original={'coefficient':1,'tangent':2},
        reference=lambda p:Q(2,1-p['coefficient']*p['tangent']**2)+1/(1-Q(1,p['coefficient']*p['tangent']**2)),
        proof='The original reciprocal pair 1/(1-u)+1/(1-1/u) equals 1.',
        rationale='Give a rational tangent and weight the first summand differently, preventing the structural cancellation.')


@case('precalculus/test/366')
def tangent_pair_sums(base):
    return _make(base,
        lambda p:f"Acute angles a_j have tangents {p['tangents']}. Compute the product over j of (tan(a_j)+tan(90 degrees-a_j)).",
        lambda p:prod(Q(t*t+1,t) for t in p['tangents']),
        parameters={'tangents':{'type':'list[int]','min_length':2,'max_length':8,'items':I(1,20)}},original={'tangents':[1,2,3,4]},
        reference=lambda p:prod(Q(t)+Q(1,t) for t in p['tangents']),
        proof='Each original tangent is paired multiplicatively with its reciprocal.',
        rationale='Add complementary tangents within each pair and then multiply the pair sums.')


@case('precalculus/test/398','precalculus/test/502')
def triple_angle_expression(base):
    first=base.family.endswith('triple_angle_sine_cosine_cancellation')
    def value(p):
        s=Q(p['sine_numerator'],p['sine_denominator'])
        return 8*(1-s*s)-1/s if first else Q(1,2)/s-2+4*s*s
    expression='8*cos(theta)^2-1/sin(theta)' if first else '(1/2)/sin(theta)-2*sin(90 degrees-2*theta)'
    return _make(base,
        lambda p:f"Given an acute angle theta with sin(theta)={p['sine_numerator']}/{p['sine_denominator']}, compute {expression}.",value,
        parameters={'sine_numerator':I(1,29),'sine_denominator':I(2,30)},original={'sine_numerator':1,'sine_denominator':2},
        valid=lambda p:p['sine_numerator']<p['sine_denominator'],
        sample=lambda r:(lambda d:{'sine_numerator':r.randint(1,d-1),'sine_denominator':d})(r.randint(2,30)),
        proof='The original renderer couples the reciprocal numerator to the actual triple-angle sine, so the triple-angle identity makes every valid expression invariant.',
        rationale='Retain the queried trigonometric expression but prescribe a general exact rational sine.',constraints=['0<sine_numerator<sine_denominator.'])


@case('precalculus/test/443')
def sine_equation_ratio(base):
    return _make(base,
        lambda p:f"If sin(theta)^2+{p['linear_sine_coefficient']}sin(theta)=1, find cos(theta)^4/sin(theta)^2.",
        lambda p:p['linear_sine_coefficient']**2,
        proof='The original expression reduces to sin(theta)^2+coefficient*sin(theta)=1.',
        rationale='Ask for the squared ratio determined by cos(theta)^2=coefficient*sin(theta).')


@case('precalculus/test/480')
def cosine_maximizer_count(base):
    return _make(base,
        lambda p:f"How many x in [0,2*pi) satisfy "+'+'.join(f"cos({m}x)" for m in p['frequencies'])+f"={len(p['frequencies'])}?",
        lambda p:gcd(*p['frequencies']),
        reference=lambda p:sum(all((m*j)%p['frequencies'][0]==0 for m in p['frequencies']) for j in range(p['frequencies'][0])),
        proof='At the maximum every cosine equals 1 and every corresponding sine is 0.',
        rationale='Count the common maximizing angles rather than sum their zero sine values.')


@case('precalculus/test/55')
def secant_difference(base):
    def value(p):
        n=p['half_angle_denominator'];t=Q(2*n,n*n-1);s=Q(n*n+1,n*n-1);h=p['shift']
        return Q(h*h-1)/(t*(s+h))
    return _make(base,
        lambda p:f"For an acute angle x with tan(x)={2*p['half_angle_denominator']}/{p['half_angle_denominator']**2-1}, compute tan(x)/(sec(x)+{p['shift']})-(sec(x)-{p['shift']})/tan(x).",value,
        parameters={'half_angle_denominator':I(2,30),'shift':I(0,20)},original={'half_angle_denominator':2,'shift':2},
        reference=lambda p:(lambda t,s: t/(s+p['shift'])-(s-p['shift'])/t)(Q(2*p['half_angle_denominator'],p['half_angle_denominator']**2-1),Q(p['half_angle_denominator']**2+1,p['half_angle_denominator']**2-1)),
        proof='The original renderer adjusts the tangent/cotangent numerator to the secant scale and shift so that the Pythagorean identity cancels the expression.',
        rationale='Use a rational parametrization of the acute angle and allow an independent denominator shift.')


@case('precalculus/train/125')
def difference_cross_component(base):
    def vectors(p):
        a=p['a_entries'];b=[p['b_numeric_entries'][0],0,p['b_numeric_entries'][1]];c=p['c_entries']
        return [b[i]-c[i] for i in range(3)],[c[i]-a[i] for i in range(3)]
    return _make(base,
        lambda p:f"Let a={p['a_entries']}, b=({p['b_numeric_entries'][0]},pi,{p['b_numeric_entries'][1]}) and c={p['c_entries']}. Find the second coordinate of (b-c) cross(c-a).",
        lambda p:(p['b_numeric_entries'][1]-p['c_entries'][2])*(p['c_entries'][0]-p['a_entries'][0])-(p['b_numeric_entries'][0]-p['c_entries'][0])*(p['c_entries'][2]-p['a_entries'][2]),
        reference=lambda p:_cross(*vectors(p))[1],proof='The three difference vectors sum to zero, so their scalar triple product vanishes.',
        rationale='Recover a rational cross-product component before the cancelling final dot product.')


@case('precalculus/train/137')
def shifted_skew_roots(base):
    return _make(base,
        lambda p:f"Let z1,z2,z3 be all complex roots of det([[x-{p['diagonal_shift']},{p['c_coefficient']},{-p['b_coefficient']}],[{-p['c_coefficient']},x-{p['diagonal_shift']},{p['a_coefficient']}],[{p['b_coefficient']},{-p['a_coefficient']},x-{p['diagonal_shift']}]])=0. Find z1^2+z2^2+z3^2.",
        lambda p:3*p['diagonal_shift']**2-2*sum(p[k]**2 for k in ('a_coefficient','b_coefficient','c_coefficient')),
        proof='A real skew-symmetric 3x3 matrix has one real eigenvalue 0 and one nonreal conjugate pair when its entries are nonzero.',
        rationale='Specify numeric skew entries and ask for the second power sum of the shifted characteristic roots.')


@case('precalculus/train/174')
def half_angle_nonconstant(base):
    return _make(base,
        lambda p:f"Given tan(theta)={p['tangent']}, evaluate (1-cos(2theta))/(1+cos(2theta)).",
        lambda p:p['tangent']**2,
        reference=lambda p:(1-Q(1-p['tangent']**2,1+p['tangent']**2))/(1+Q(1-p['tangent']**2,1+p['tangent']**2)),
        proof='Both original summands are the same half-angle tangent.',
        rationale='Use the half-angle quotient at the doubled angle instead of subtracting two identical expressions.')


@case('precalculus/train/210')
def cosine_grid_shift(base):
    def matrix(p):
        cosine={0:1,90:0,180:-1,270:0}
        return [[int(i==j)*p['shift']+cosine[((i+j)*p['step_degrees'])%360] for j in range(3)] for i in range(3)]
    return _make(base,
        lambda p:f"Compute the determinant of the 3x3 matrix with entry {p['shift']}*delta_ij+cos((i+j)*{p['step_degrees']} degrees), indexed i,j=0,1,2. Here delta_ij is 1 when i=j and 0 otherwise.",
        lambda p:p['shift']*(p['shift']+2)*(p['shift']-1) if p['step_degrees']==90 else p['shift']**2*(p['shift']+3),
        reference=lambda p:_det3(matrix(p)),parameters={'step_degrees':{'type':'int','choices':[90,180]},'shift':I(1,20)},original={'step_degrees':90,'shift':2},
        proof='The original cosine grid is a sum of two outer products and has rank at most2.',
        rationale='Shift the cosine grid by a scalar identity and use exact quarter-turn angular steps.')


@case('precalculus/train/225')
def rotation_order(base):
    return _make(base,
        lambda p:f"Let R be the plane rotation matrix through {p['angle']} degrees. Find the smallest positive integer n such that R^n=I.",
        lambda p:360//gcd(p['angle'],360),
        reference=lambda p:next(n for n in range(1,361) if n*p['angle']%360==0),
        proof='Every plane rotation has determinant1.',
        rationale='Ask for the finite order of the same rotation instead of its determinant.')


@case('precalculus/train/233')
def trig_skew_norm(base):
    domains=deepcopy(base.parameters);domains['tangent']=I(1,20)
    original=dict(base.original,tangent=2)
    return _make(base,
        lambda p:f"Let tan(alpha)={p['tangent']}. Find the sum of squares of all entries of [[0,{p['sine_alpha_coefficient']}sin(alpha),-{p['cosine_alpha_coefficient']}cos(alpha)],[-{p['sine_alpha_coefficient']}sin(alpha),0,{p['sine_beta_coefficient']}sin(alpha)],[{p['cosine_alpha_coefficient']}cos(alpha),-{p['sine_beta_coefficient']}sin(alpha),0]].",
        lambda p:Q(2*((p['sine_alpha_coefficient']**2+p['sine_beta_coefficient']**2)*p['tangent']**2+p['cosine_alpha_coefficient']**2),1+p['tangent']**2),
        parameters=domains,original=original,proof='The original odd-order skew-symmetric determinant is zero.',
        rationale='Ask for the squared Frobenius norm, specifying the trigonometric arguments through an exact tangent.')


@case('precalculus/train/252')
def inverse_equation_quadratic(base):
    return _make(base,
        lambda p:f"Starting from sin(arccos({p['inside_multiplier']}tan(arcsin(x))))={p['right_multiplier']}x, square and clear denominators, then set u=x^2. Find the sum of the two algebraic roots of the resulting quadratic in u, including any root extraneous to the original equation.",
        lambda p:Q(p['inside_multiplier']**2+p['right_multiplier']**2+1,p['right_multiplier']**2),
        proof='The original nested expression is strictly decreasing on its positive real domain while the right side increases, producing one intersection.',
        rationale='Query the exact Vieta sum of the algebraic squared-variable equation, explicitly including its extraneous root.')


@case('precalculus/train/273')
def trig_derivative(base):
    return _make(base,
        lambda p:f"Let f(x)={p['sine_coefficient']}sin(x)+{p['cosine_coefficient']}cos(x)+{p['tangent_coefficient']}tan(x), with x in radians. Find f'(0).",
        lambda p:p['sine_coefficient']+p['tangent_coefficient'],
        proof='The original joint constraints place the first positive root in the same unit interval.',
        rationale='Compute the local rate of change of the same trigonometric function instead of a constant floor statistic.')


@case('precalculus/train/361')
def finite_cosine_squares(base):
    return _make(base,
        lambda p:f"Compute the sum of cos(k*pi/{2*p['terms']+1})^2 for k=1,...,{p['terms']}.",
        lambda p:Q(2*p['terms']-1,4),parameters={'terms':I(1,100)},original={'terms':3},
        proof='The original cosecant-minus-cosine series cancels by a finite geometric-series identity.',
        rationale='Use a related finite cosine-square sum whose exact value grows with the number of terms.')


@case('precalculus/train/427')
def polar_intersection_distance(base):
    return _make(base,
        lambda p:f"The polar curves r={p['a']}cos(theta) and r={p['b']}sin(theta) intersect at two distinct points. Find the square of the distance between them.",
        lambda p:Q(p['a']**2*p['b']**2,p['a']**2+p['b']**2),
        reference=lambda p:Q(p['a']*p['b']**2,p['a']**2+p['b']**2)**2+Q(p['a']**2*p['b'],p['a']**2+p['b']**2)**2,
        proof='The two circles always share the origin and one nonzero intersection for positive a,b.',
        rationale='Measure their intersection separation instead of merely countingtwo points.')


@case('precalculus/train/451')
def balanced_harmonic_count(base):
    return _make(base,
        lambda p:f"Three angles x,y,z satisfy cos(x)+cos(y)+cos(z)=sin(x)+sin(y)+sin(z)=0. For how many positive integers j<={p['limit']} must both cos(jx)+cos(jy)+cos(jz) and sin(jx)+sin(jy)+sin(jz) equal zero?",
        lambda p:p['limit']-p['limit']//3,parameters={'limit':I(1,150)},original={'limit':20},
        reference=lambda p:sum(j%3!=0 for j in range(1,p['limit']+1)),
        proof='The three unit vectors form a rotated equilateral triple; harmonics not divisible by 3 vanish.',
        rationale='Count all vanishing harmonics up to a variable bound rather than fixing a harmonic known to vanish.')


@case('precalculus/train/512')
def intercept_sphere_radius(base):
    return _make(base,
        lambda p:f"In R^{p['dimension']}, a sphere passes through the origin and the coordinate-axis intercepts at distances {p['intercepts']}, one per axis. Find its squared radius.",
        lambda p:Q(sum(a*a for a in p['intercepts']),4),
        parameters={'dimension':I(2,6),'intercepts':{'type':'list[int]','min_length':2,'max_length':6,'items':I(1,30)}},
        original={'dimension':3,'intercepts':[2,4,6]},valid=lambda p:len(p['intercepts'])==p['dimension'],
        sample=lambda r:(lambda n:{'dimension':n,'intercepts':[r.randint(1,30) for _ in range(n)]})(r.randint(2,6)),
        reference=lambda p:sum(Q(a,2)**2 for a in p['intercepts']),
        proof='The original center coordinates are half the intercept coordinates and the hyperplane equation forces theratiosum to 2.',
        rationale='Prescribe the intercepts and ask for the size of their circumsphere.',constraints=['There is exactly one positive intercept per coordinate axis.'])


@case('precalculus/train/52')
def roots_unity_distances(base):
    return _make(base,
        lambda p:f"For the n={p['n']} roots z_j=exp(2*pi*i*j/{p['n']}), j=0,...,{p['n']-1}, compute the sum of |1-z_j|^2.",
        lambda p:2*p['n'],proof='The original sum of all nontrivial roots of unity equals -1.',
        rationale='Sum squared distances of all roots from 1, retaining the roots-of-unity cancellation in a nonconstant geometric quantity.')


@case('precalculus/train/536')
def tangent_square_difference(base):
    return _make(base,
        lambda p:f"Given tan(theta)={p['tangent']}, evaluate tan(theta)^2-sin(theta)^2.",
        lambda p:Q(p['tangent']**4,1+p['tangent']**2),parameters={'tangent':I(1,89)},original={'tangent':2},
        reference=lambda p:p['tangent']**2-Q(p['tangent']**2,1+p['tangent']**2),
        proof='The original denominator exactly equals its numerator by the Pythagorean identity.',
        rationale='Evaluate the numerator using an exact rational tangent instead of dividing it by itself.')


@case('precalculus/train/557')
def logarithm_scaled_grid(base):
    domains=deepcopy(base.parameters);domains['power']=I(1,12)
    return _make(base,
        lambda p:f"Compute sum for k=1,...,{p['n']-1} of log_{p['base']}({p['base']}^{p['power']}*tan(k*pi/{2*p['n']})).",
        lambda p:(p['n']-1)*p['power'],parameters=domains,original=dict(base.original,power=2),
        proof='Complementary tangent factors multiply to 1, so the unscaled logarithms sum to 0.',
        rationale='Scale each positive tangent argument by a common base power, making the finite log sum depend on its length and scale.')


@case('precalculus/train/566')
def gram_shift(base):
    def matrix(p):
        a,b,c=p['first_radius'],p['second_radius'],p['third_radius']
        return [[1+a*a,0,-a*c],[0,1+b*b,0],[-a*c,0,1+c*c]]
    return _make(base,
        lambda p:f"Vectors u=({p['first_radius']},0), v=(0,{p['second_radius']}), w=(-{p['third_radius']},0) have Gram matrix G_ij equal to their pairwise dot products. Find det(I+G).",
        lambda p:(1+p['first_radius']**2+p['third_radius']**2)*(1+p['second_radius']**2),
        reference=lambda p:_det3(matrix(p)),proof='Three vectors in the plane have a singular Gram matrix.',
        rationale='Shift the Gram matrix by the identity and specify exact axis directions, retaining its radius parameters.')


@case('precalculus/train/598')
def signed_trig_product(base):
    def ingredients(p):
        n=p['half_angle_denominator'];s=Q(2*n,n*n+1);c=Q(n*n-1,n*n+1)
        return s,c
    def value(p):
        s,c=ingredients(p)
        return (1+p['cotangent_sign']*c/s+p['cosecant_sign']/s)*(1+s/c+1/c)
    return _make(base,
        lambda p:f"For an acute angle A with tan(A/2)=1/{p['half_angle_denominator']}, compute (1+({p['cotangent_sign']})cot(A)+({p['cosecant_sign']})csc(A))*(1+tan(A)+sec(A)).",value,
        parameters={'cotangent_sign':{'type':'int','choices':[-1,1]},'cosecant_sign':{'type':'int','choices':[-1,1]},'half_angle_denominator':I(2,30)},
        original={'cotangent_sign':1,'cosecant_sign':1,'half_angle_denominator':2},
        proof='The original renderer couples signs in both factors so that the product is 2 for every allowed sign pair.',
        rationale='Specify the angle by a rational half-angle tangent and allow all sign combinations, yielding exact nonconstant values.')


@case('precalculus/train/610')
def sine_addition_quotient(base):
    return _make(base,
        lambda p:f"Angles a,b,c,d satisfy sin(a+b)={p['first_numerator']}/{p['first_denominator']} and sin(c+d)={p['second_numerator']}/{p['second_denominator']}. Evaluate (sin(a)*cos(b)+cos(180 degrees-a)*cos(90 degrees+b))/(sin(c)*cos(d)+cos(180 degrees-c)*cos(90 degrees+d)).",
        lambda p:Q(p['first_numerator']*p['second_denominator'],p['first_denominator']*p['second_numerator']),
        parameters={'first_numerator':I(1,20),'first_denominator':I(21,40),'second_numerator':I(1,20),'second_denominator':I(21,40)},
        original={'first_numerator':1,'first_denominator':21,'second_numerator':2,'second_denominator':21},
        proof='Original constraints equate the angle sums, so both sine-addition expressions coincide.',
        rationale='Give independently chosen exact sines of the two angle sums instead of requiring equality.')


@case('precalculus/train/742')
def triangle_trig_minor(base):
    return _make(base,
        lambda p:f"In triangle ABC, A and B are acute with tan(A)={p['tan_a']} and tan(B)={p['tan_b']}. Compute the determinant [[sin(A)^2,cot(A)],[sin(B)^2,cot(B)]].",
        lambda p:Q(p['tan_a']**2,p['tan_b']*(1+p['tan_a']**2))-Q(p['tan_b']**2,p['tan_a']*(1+p['tan_b']**2)),
        parameters={'tan_a':I(1,12),'tan_b':I(1,12)},original={'tan_a':2,'tan_b':3},
        proof='For triangle angles the original three rows are linearly dependent by the cotangent and double-angle identities.',
        rationale='Evaluate a 2x2 minor of the same trigonometric matrix using exact rational tangents.')


@case('precalculus/train/315')
def complementary_tangent_sum(base):
    return _make(base,
        lambda p:f"For an acute angle theta with tan(theta)={p['tangent']}, compute (1+tan(theta))*(1+tan(90 degrees-theta)).",
        lambda p:Q((p['tangent']+1)**2,p['tangent']),
        parameters={'tangent':I(1,44)},original={'tangent':2},
        reference=lambda p:(1+Q(p['tangent']))*(1+Q(1,p['tangent'])),
        proof='The original two tangent arguments add to 45 degrees, forcing the product to 2.',
        rationale='Use complementary acute angles and specify an exact tangent, replacing the special45-degree cancellation.')


def _cube_root_power_sum(n):
    a,b=2,-1
    for _ in range(n):
        a,b=b,-a-b
    return a


def _nested_reference(m,n):
    if (n-m+1)%2:
        return Q(2*m*n+m-n,m+n)
    return Q(n+1-m,2*m*n+m-n-1)


REFORMULATED_IDS = frozenset(_BUILDERS)


def reformulate(problem_id, template):
    """Return the exact same object outside the explicit authorized allowlist."""
    if problem_id not in _BUILDERS:
        return template
    result = _BUILDERS[problem_id](template)
    result.reformulation['id'] = problem_id
    return result
