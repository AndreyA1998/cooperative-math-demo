"""Exact mathematical models for geometry."""
