"""Physical quantities; exact source-bound mathematical models."""

from functools import partial
from fractions import Fraction as F
from math import gcd, isqrt, lcm
from template_dataset.families.word_problems.decimal_arithmetic import ALG, PRE, add, ceildiv, decimal, rounded

CASES = {}
pre = partial(add, CASES, PRE)
alg = partial(add, CASES, ALG)


def product_pair(total, difference):
    discriminant = difference*difference + 4*total
    root = isqrt(discriminant)
    if root*root == discriminant and (root-difference) % 2 == 0:
        return ((root-difference)//2, (root+difference)//2)
    return (0, 0)


def draw_pair(rng):
    a, d = rng.randint(1, 30), rng.randint(1, 20)
    return a*(a+d), d


pre('train/34', 'product-difference',
    dict(product=(18, 2, 1500), difference=(3, 1, 20)),
    'The product of two positive integers is {product}. Their positive difference is {difference}. What is their sum?',
    lambda total, d: sum(product_pair(total, d)),
    check=lambda total, d: product_pair(total,d)[0] > 0, draw=draw_pair,
    reference=lambda total, d: next(2*x+d for x in range(1, isqrt(total)+1) if x*(x+d)==total),
    constraint='The product and positive difference must be realized by a pair of positive integers.')

alg('train/597', 'product-difference-larger',
    dict(product=(135, 2, 1500), difference=(6, 1, 20)),
    'Two positive integers differ by {difference} and their product is {product}. What is the larger integer?',
    lambda total, d: product_pair(total,d)[1],
    check=lambda total, d: product_pair(total,d)[0] > 0, draw=draw_pair,
    reference=lambda total, d: next(x+d for x in range(1,isqrt(total)+1) if x*(x+d)==total),
    constraint='The product and difference must be realized by two positive integers.')

pre('train/539', 'hexagon-sides',
    dict(short=(5, 1, 20), long=(6, 2, 30), perimeter=(34, 10, 170)),
    'Convex hexagon $ABCDEF$ has exactly two distinct side lengths. Side $AB$ measures {short} units, and side $BC$ measures {long} units. The perimeter is {perimeter} units. How many sides measure {long} units?',
    lambda a,b,t: (t-6*a)//(b-a),
    check=lambda a,b,t: a<b and t>2*b and t in {6*a+(b-a)*k for k in range(1,6)},
    draw=lambda r: (lambda a,b,k:(a,b,6*a+(b-a)*k))(r.randint(5,12),r.randint(13,22),r.randint(1,5)),
    reference=lambda a,b,t: next(k for k in range(1,6) if a*(6-k)+b*k==t),
    constraint='Both lengths occur. The perimeter determines an integer number of long sides and exceeds twice the longest side, so a convex hexagon is possible.')

for suffix, pair, query, heads, legs in (
    ('train/555', ('acrobats', 'elephants'), 0, 15, 40),
    ('test/618', ('clowns', 'horses'), 1, 10, 30),
):
    two, four = pair
    alg(suffix, 'heads-and-legs',
        dict(heads=(heads, 2, 80), legs=(legs, 6, 300)),
        f'I counted some {two} and {four}. I counted {{legs}} legs and {{heads}} heads. How many {pair[query]} did I see?',
        (lambda h,l: 2*h-l//2) if query == 0 else (lambda h,l: l//2-h),
        check=lambda h,l:l % 2 == 0 and 2*h<l<4*h,
        draw=lambda r:(lambda a,b:(a+b,2*a+4*b))(r.randint(1,30),r.randint(1,30)),
        reference=(lambda h,l,q=query: next((a,h-a)[q] for a in range(1,h) if 2*a+4*(h-a)==l)),
        constraint='Both species occur: the total leg count is even and lies strictly between two and four times the head count.')


def team_boys(total, attended, divisor):
    return F(attended*divisor-total,divisor-1)


alg('train/573', 'partial-attendance',
    dict(total=(26,3,180),attended=(16,2,100),divisor=(2,2,6)),
    'A chess team has {total} members. Only {attended} members attended the last meeting: 1/{divisor} of the girls attended and all of the boys attended. How many boys are on the team?',
    team_boys,
    check=lambda t,a,d: 0<team_boys(t,a,d)<a and team_boys(t,a,d).denominator==1,
    draw=lambda r:(lambda b,k,d:(b+k*d,b+k,d))(r.randint(1,50),r.randint(1,15),r.randint(2,6)),
    reference=lambda t,a,d:next(b for b in range(1,a) if (a-b)*d==t-b),
    constraint='Both groups are nonempty and the number of girls attending must be a positive whole number.')


def correct_answers(total, correct, penalty, attempted, score):
    return F(score+attempted*penalty,correct+penalty)


alg('test/534', 'scored-questions',
    dict(questions=(100,10,150),correct_points=(5,1,10),penalty=(2,1,10),
         attempted=(80,2,150),score=(232,-1400,1400)),
    'An aptitude test has {questions} questions. Each correct answer scores {correct_points} points, each incorrect answer scores minus {penalty} points, and each unanswered question scores zero. Frank answered {attempted} questions and scored {score} points. How many questions did he answer correctly?',
    correct_answers,
    check=lambda n,c,w,a,s: a<=n and 0<=correct_answers(n,c,w,a,s)<=a and correct_answers(n,c,w,a,s).denominator==1,
    draw=lambda r:(lambda n,c,w,x,y:(n,c,w,x+y,c*x-w*y))(
        r.randint(70,150),r.randint(1,10),r.randint(1,10),r.randint(1,35),r.randint(1,35)),
    reference=lambda n,c,w,a,s:next(k for k in range(a+1) if c*k-w*(a-k)==s),
    constraint='Attempted questions cannot exceed total; the score gives an integral feasible number of correct and incorrect answers.')


def quarters_second(total, fewer, more, multiple):
    return F(total+fewer+more,3+multiple)


for suffix, original in (
    ('test/804',(27,5,4,3)),
    ('test/1045',(20,3,2,2)),
):
    total, fewer, more, multiple = original
    alg(suffix, 'four-piles',
        dict(total=(total,8,280),fewer=(fewer,1,12),more=(more,1,12),multiple=(multiple,2,6)),
        'There are {total} quarters in four piles. The first has {fewer} fewer than the second. The second has {more} more than the third. The fourth has {multiple} times as many as the second. How many quarters are in the fourth?',
        lambda t,f,d,m:m*quarters_second(t,f,d,m),
        check=lambda t,f,d,m:quarters_second(t,f,d,m)>max(f,d) and quarters_second(t,f,d,m).denominator==1,
        draw=lambda r:(lambda f,d,m,x:((3+m)*x-f-d,f,d,m))(
            r.randint(1,12),r.randint(1,12),r.randint(2,6),r.randint(13,30)),
        reference=lambda t,f,d,m:next(m*x for x in range(max(f,d)+1,t) if (x-f)+x+(x-d)+m*x==t),
        constraint='The total and comparisons give positive integer sizes for all four piles.')


def bacteria(suffix, init, period, elapsed, unit, start, end, *, algebra=True):
    register = alg if algebra else pre
    register(suffix, 'repeated-growth',
             dict(initial=(init,1,1000),period=(period,1,12),elapsed=(elapsed,1,24 if unit=='hours' else 120)),
             lambda n,p,e:f'A bacteria population contains {n} bacteria at the start of observation. It doubles every {p} {unit}. How many bacteria are present exactly {e} {unit} after the observation began?',
             lambda n,p,e:n*2**(e//p),
             check=lambda n,p,e:e%p==0,
             draw=lambda r:(lambda n,p,k:(n,p,p*k))(r.randint(5,150),r.randint(1,4 if unit=='hours' else 12),r.randint(2,6)),
             reference=lambda n,p,e: repeated(n,2,e//p),
             constraint='The observation duration is a positive whole number of doubling intervals.',
             adaptation=f'Replaced the clock times {start} and {end} by their elapsed duration.')


def repeated(n, multiplier, count):
    for _ in range(count):
        n *= multiplier
    return n


bacteria('train/250',20,3,15,'minutes','3:00 p.m.','3:15 p.m.')
bacteria('test/675',600,4,12,'hours','noon','midnight')
bacteria('test/597',10,1,8,'hours','1:00 p.m.','9:00 p.m.',algebra=False)


def linear_sequence(a,d,n):
    return [a+k*d for k in range(n)]


alg('train/166', 'stack-rows', dict(bottom=(12,2,50),top=(3,1,35)),
    'A stack of logs has {bottom} logs in the bottom row and one less in each higher row, ending with {top} logs at the top. How many logs are in the stack?',
    lambda b,t:(b+t)*(b-t+1)//2,
    check=lambda b,t:b>t,
    draw=lambda r:(lambda t,n:(t+n,t))(r.randint(1,25),r.randint(1,20)),
    reference=lambda b,t:sum(range(t,b+1)),
    constraint='The bottom row is longer than the top row.')

alg('train/710', 'pebble-collection',dict(first=(1,1,25),difference=(1,1,8),days=(12,3,30)),
    'Murtha collects {first} pebbles on the first day. Each subsequent day she collects {difference} more than on the previous day. How many pebbles will she have collected after {days} days?',
    lambda a,d,n:n*(2*a+(n-1)*d)//2,
    reference=lambda a,d,n:sum(linear_sequence(a,d,n)),
    adaptation='The second-day example is omitted; it repeats what the stated daily increment already determines.')

alg('train/953', 'daily-count-from-total',
    dict(total=(100,6,1300),days=(5,3,15),increase=(6,1,12),query=(3,2,14)),
    'Joann ate {total} lollipops in {days} days. Each day after the first she ate {increase} more than on the preceding day. How many lollipops did she eat on day {query}?',
    lambda s,n,d,q:F(s,n)+F((2*q-n-1)*d,2),
    check=lambda s,n,d,q:q<n and (a:=F(s,n)-F((n-1)*d,2))>0 and a.denominator==1,
    draw=lambda r:(lambda a,d,n:(n*(2*a+(n-1)*d)//2,n,d,r.randint(2,n-1)))(
        r.randint(1,30),r.randint(1,10),r.randint(3,12)),
    reference=lambda s,n,d,q:next(a+(q-1)*d for a in range(1,s) if sum(linear_sequence(a,d,n))==s),
    constraint='The requested day is interior to the interval, and the daily sequence starts at a positive integer.')


def proportion(a,b,c):
    return F(b*c,a)


def rate_counts(a,b,c):
    return proportion(a,b,c).denominator==1


def draw_rate_counts(r):
    a,c=r.randint(2,25),r.randint(2,36)
    b=r.randint(1,12)*a//gcd(a,c)
    return a,b,c


for suffix,fields,text in (
    ('train/290',dict(first=(2,1,25),yield_=(18,2,500),second=(3,1,36)),
     'Lee can bake {yield_} cookies with {first} cups of flour. At the same rate, how many cookies can he bake with {second} cups?'),
    ('train/482',dict(first=(16,1,25),yield_=(50,2,500),second=(48,1,55)),
     'A box of {first} cubic centimeters can hold {yield_} paperclips. Assuming capacity is directly proportional to volume, how many paperclips can a box of {second} cubic centimeters hold?'),
    ('test/350',dict(first=(20,1,25),yield_=(10,2,500),second=(12,1,36)),
     'Raymond normally eats {yield_} crackers, each containing {second} calories. How many cookies containing {first} calories each give him the same total?'),
    ('test/473',dict(first=(250,25,650),yield_=(10,1,600),second=(400,25,650)),
     'My usual workout is {yield_} laps around a {second}-meter track. How many laps around a {first}-meter track cover the same distance?'),
    ('test/643',dict(first=(9,3,15),yield_=(42,10,65),second=(6,3,15)),
     'A normal shoe size of {first} corresponds to a climbing shoe size of {yield_}. If climbing size is directly proportional to normal size, what climbing size corresponds to normal size {second}?'),
):
    if suffix in {'test/473','test/643'}:
        def draw(r,s=suffix):
            if s=='test/473':
                a,c=(r.randint(8,25)*25 for _ in range(2))
                return a,r.randint(1,12)*a//gcd(a,c),c
            # Choose from a finite admissible set, rather than retry internally.
            return r.choice([(a,b,c) for a in range(3,16) for b in range(30,53)
                             for c in range(3,16)
                             if a!=c and b*c%a==0 and 24<=b*c//a<=62])
    else:
        draw=draw_rate_counts
    alg(suffix,'integer-proportional-quantity',fields,text,proportion,
        check=(lambda a,b,c:rate_counts(a,b,c) and 10<=proportion(a,b,c)<=65)
              if suffix=='test/643' else rate_counts,draw=draw,
        reference=lambda a,b,c:next(x for x in range(1,b*c+1) if x*a==b*c),
        constraint=('The required quantity is a whole number in the stated units.'
                    + (' The requested climbing size is between 10 and 65, inclusive.'
                       if suffix=='test/643' else '')))


alg('train/855','map-scale',
    dict(map_first=(12,1,35),real_first=(72,5,350),map_query=(17,1,35)),
    'On a map, {map_first} centimeters represent {real_first} kilometers. How many kilometers do {map_query} centimeters represent?',
    proportion)

pre('train/1016','scale-per-inch',
    dict(height=(60,4,100),model=(4,1,36)),
    'A statue is {height} feet tall. Its scale model is {model} inches tall. How many feet of the statue does one inch on the model represent?',
    lambda h,m:F(h,m),
    adaptation='Generalized the real statue to an unnamed statue so that the height can vary.')


def volume_from_change(a,b,c,d,used):
    return F(used)/(F(a,b)-F(c,d))


def tank_valid(a,b,c,d,used):
    return 0<F(c,d)<F(a,b)<=1


def tank_draw(r):
    b,d=r.randint(3,12),r.randint(2,12)
    a,c=r.randint(2,b),r.randint(1,d-1)
    if F(a,b)<F(c,d):
        a,b,c,d=c,d,a,b
    if F(a,b)==F(c,d):
        a=b
    return a,b,c,d,r.randint(1,75)


alg('train/619','tank-capacity',
    dict(start_n=(7,1,12),start_d=(8,2,12),end_n=(1,1,12),end_d=(2,2,12),used=(12,1,75)),
    lambda a,b,c,d,u:f'A tank is {a}/{b} full. After {u} gallons are used, it is {c}/{d} full. What is its full capacity in gallons?',
    volume_from_change,check=tank_valid,draw=tank_draw,
    constraint='Both fractions denote physical fill levels; the ending level is lower than the starting level.')


def min_bushes(yield_,in_,out,target):
    return ceildiv(ceildiv(target,out)*in_,yield_)


alg('train/524','barter-batches',
    dict(containers=(8,2,15),trade_in=(5,2,10),trade_out=(2,1,8),target=(48,6,90)),
    'Each blueberry bush yields {containers} containers. In each trade Natalie gives {trade_in} containers and receives {trade_out} zucchinis. What is the minimum number of bushes she needs to pick to obtain at least {target} zucchinis?',
    min_bushes,
    reference=lambda y,o,i,t:next(k for k in range(1,t*o+1) if (k*y//o)*i>=t),
    adaptation='Specified whole trades and that the target is a minimum, so rounded-up instances are unambiguous.')


alg('test/440','fish-volume-minimum',
    dict(capacity=(8,2,24),fish=(600,25,900)),
    'At most {capacity} fish of a certain species can live in each cubic meter of water without overcrowding. What minimum volume, in cubic meters, is needed for {fish} fish?',
    lambda c,f:F(f,c))


alg('test/466','recipe-scale',dict(original_pounds=(2,1,8),cup_tenths=(15,5,70),cakes=(2,1,6),new_pounds=(5,2,9)),
    lambda a,c,n,b:f'A recipe for a {a}-pound cake uses {decimal(c,1)} cups of flour. At the same rate, how many cups are needed for {n} cakes of {b} pounds each?',
    lambda a,c,n,b:F(c*n*b,10*a))


def fraction_size(n,d,total):
    return F(total,d+n)*(d-n)


pre('test/242','fraction-from-digit-sum',
    dict(numerator=(5,1,18),denominator=(8,2,25),sum=(91,3,900)),
    'A fraction is equivalent to {numerator}/{denominator}. Its numerator and denominator are positive integers that sum to {sum}. What is the denominator minus the numerator?',
    fraction_size,
    check=lambda n,d,s:n<d and (F(n*s,n+d)).denominator==1,
    draw=lambda r:(lambda n,d,k:(n,d,(n+d)*k))(r.randint(1,10),r.randint(11,25),r.randint(1,22)),
    reference=lambda n,d,s:next(s-2*k for k in range(1,s) if F(k,s-k)==F(n,d)),
    constraint='The ratio is proper and the sum determines an integer numerator and denominator.')


def angle_sum(n):
    return 180*(n-2)


for suffix,fields,text,solve in (
    ('train/140',dict(multiplier=(8,2,16)),'Angles A and B are supplementary, and A is {multiplier} times B. What is A in degrees?',lambda m:F(180*m,m+1)),
    ('train/501',dict(sides=(6,3,25)),'What is the measure in degrees of one interior angle of a regular polygon with {sides} sides?',lambda n:F(angle_sum(n),n)),
    ('train/720',dict(angle=(42,1,89)),'What is the supplement of the complement of a {angle}-degree angle, in degrees?',lambda a:90+a),
    ('test/183',dict(angle=(50,1,179)),'What is the supplement of an angle measuring {angle} degrees, in degrees?',lambda a:180-a),
    ('test/356',dict(complement=(10,1,89)),'An angle has a complement of {complement} degrees. What is the original angle, in degrees?',lambda a:90-a),
    ('test/507',dict(multiplier=(2,2,15)),'In a convex quadrilateral, two angles are right angles and the largest angle is {multiplier} times the smallest. How many degrees are in the largest angle?',lambda m:F(180*m,m+1)),
    ('test/851',dict(second=(2,1,12),third=(5,1,12)),
     'The angles of a triangle are x degrees, {second}x degrees, and {third}x degrees. What is x to the nearest tenth?',lambda b,c:rounded(F(180,1+b+c),1)),
):
    pre(suffix,'angle-relations',fields,text,solve)


pre('train/654','regular-polygon-from-angle',dict(angle=(120,60,179)),
    'A regular polygon has interior angles of {angle} degrees. How many sides does it have?',
    lambda a:360//(180-a),
    check=lambda a:360%(180-a)==0,draw=lambda r:(180-360//r.choice([k for k in range(3,61) if 360%k==0]),),
    constraint='The exterior angle is a positive divisor of 360 degrees.')


def polygon_equal(n,right):
    return F(angle_sum(n)-90*right,n-right)


pre('test/848','polygon-right-and-equal',
    dict(sides=(5,4,12),right=(3,1,4)),
    'A convex {sides}-sided polygon has {right} right angles. All other angles have the same measure. How many degrees are in each of the other angles?',
    polygon_equal,
    check=lambda n,r:r<n-1 and 90<polygon_equal(n,r)<180,
    draw=lambda r:(r.randint(5,12),r.randint(1,3)),
    constraint='There are at least two congruent angles and their measure is strictly between 90 and 180 degrees.')


pre('train/459','equal-perimeters',
    dict(first=(3,3,14),second=(4,3,14),perimeter=(12,3,125)),
    'Two regular polygons, with {first} sides and {second} sides respectively, each have perimeter {perimeter} inches. What is the ratio of their side lengths, first to second?',
    lambda a,b,p:F(b,a),
    reference=lambda a,b,p:F(p,a)/F(p,b),
    adaptation='Generalized the equilateral triangle and square to regular polygons; equal perimeters still determine the side ratio.')


pre('test/107','regular-polygon-angle-ratio',
    dict(first=(3,3,14),second=(4,3,14)),
    'What is the ratio of one interior angle of a regular {first}-gon to one interior angle of a regular {second}-gon?',
    lambda a,b:F(angle_sum(a),a)/F(angle_sum(b),b),
    adaptation='Generalized the two regular polygons while preserving the ratio of interior angles.')


def equal_edge(a,b,c,d):
    return F(a*d-b*c,a+c)


pre('train/473','equal-expressions-for-square-side',
    dict(left_scale=(4,1,12),left_subtract=(15,1,100),right_offset=(20,2,140),right_scale=(3,1,12)),
    'The side length of a square is given by both ${left_scale}x-{left_subtract}$ and ${right_offset}-{right_scale}x$ meters. What is its area in square meters?',
    lambda a,b,c,d:equal_edge(a,b,d,c)**2,
    check=lambda a,b,c,d:equal_edge(a,b,d,c)>0,
    draw=lambda r:draw_equal_edge(r),
    constraint='Equating the two side length expressions gives a strictly positive side length.')


def draw_equal_edge(r):
    a,d=r.randint(1,12),r.randint(1,12)
    # Positive edge is equivalent to a*c>b*d; leave at least one possible c.
    b=r.randint(1,min(70,(140*a-1)//d))
    c=r.randint(max(2,b*d//a+1),140)
    return a,b,c,d


pre('train/1185','triangle-square-equal-perimeters',
    dict(a=(61,10,200),b=(82,10,200),c=(97,10,200)),
    lambda a,b,c:f'A square and a triangle have equal perimeters. The triangle’s sides are {decimal(a,1)}, {decimal(b,1)}, and {decimal(c,1)} cm. What is the square’s area in square centimeters?',
    lambda a,b,c:F(a+b+c,40)**2,
    check=lambda a,b,c:2*max(a,b,c)<a+b+c,
    draw=lambda r:(lambda a,b:(a,b,r.randint(max(10,abs(a-b)+1),min(a+b-1,200))))(r.randint(10,150),r.randint(10,150)),
    constraint='The positive side lengths satisfy the strict triangle inequalities.')


pre('test/502','coin-stack-height',
    dict(initial_coins=(8,2,25),height_tenths=(5,1,35),target_feet=(1,1,5)),
    lambda n,h,t:f'A stack of {n} identical coins is {decimal(h,1)} inches high. How many such coins will make a stack exactly {t} feet high?',
    lambda n,h,t:F(120*n*t,h),
    check=lambda n,h,t:120*n*t%h==0 and F(1,50)<=F(h,10*n)<=F(1,5),
    draw=lambda r:(lambda n,t:(n,r.choice([h for h in range(1,36)
                                          if 120*n*t%h==0 and F(1,50)<=F(h,10*n)<=F(1,5)]),t))(r.randint(2,25),r.randint(1,5)),
    constraint='The height ratio gives a whole number of coins; each coin is between 1/50 and 1/5 inch thick, inclusive.',
    adaptation='Use identical unspecified coins so the given thickness may vary.')


pre('test/857','height-difference',
    dict(tall_feet=(7,5,8),tall_inches=(5,0,11),short_feet=(5,4,7),short_inches=(5,0,11)),
    'Two basketball players are {tall_feet} feet {tall_inches} inches and {short_feet} feet {short_inches} inches tall. How many inches taller is the first player?',
    lambda a,b,c,d:12*(a-c)+b-d,
    check=lambda a,b,c,d:12*a+b>12*c+d,
    draw=lambda r:(lambda s:(r.randint(s+1,8),r.randint(0,11),s,r.randint(0,11)))(r.randint(4,7)),
    constraint='The first player is strictly taller.',
    adaptation='Replaced the named athletes with generic players so that measured heights can vary.')
