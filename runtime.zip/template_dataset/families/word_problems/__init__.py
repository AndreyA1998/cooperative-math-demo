"""Exact mathematical models for word problems."""
