"""Arithmetic story models; exact source-bound mathematical models."""

from dataclasses import dataclass
from fractions import Fraction as F
from itertools import combinations, product
from math import comb, gcd, isqrt, lcm, prod

import re
from typing import Callable, Optional

from template_dataset.core import Template, _in_domain


_LITERAL = re.compile(r"-?\d+(?:,\\?!?\d{3})*(?:\.\d+)?")


@dataclass(frozen=True)
class Case:
    family: str
    fields: tuple
    solve: Callable
    bounds: dict
    valid: Optional[Callable]
    draw: Optional[Callable]
    constraint: str
    reference: Optional[Callable]
    edits: tuple


_CASES = {}
_SPECIAL = {}


def _register(subject, ids, family, fields, solve, *, bounds=None, valid=None,
              draw=None, constraint='', reference=None, edits=()):
    if (valid is None) != (draw is None) or bool(constraint) != (valid is not None):
        raise ValueError('A joint domain requires a constructive sampler and documentation')
    case = Case(family, tuple(fields.split()), solve, bounds or {}, valid,
                draw, constraint, reference, edits)
    for suffix in ids.split():
        problem_id = f'{subject}/{suffix}'
        if problem_id in _CASES or problem_id in _SPECIAL:
            raise ValueError(f'Duplicate word template {problem_id}')
        _CASES[problem_id] = case


def pre(*args, **kwargs):
    _register('prealgebra', *args, **kwargs)


def alg(*args, **kwargs):
    _register('algebra', *args, **kwargs)


def build(row):
    special = _SPECIAL.get(row['id'])
    if special is not None:
        return special
    case = _CASES.get(row['id'])
    if case is None:
        return None
    problem = row['problem']
    for before, after in case.edits:
        if problem.count(before) != 1:
            raise ValueError(f"Expected one occurrence of {before!r} in {row['id']}")
        problem = problem.replace(before, after, 1)

    literals = list(_LITERAL.finditer(problem))
    if len(literals) != len(case.fields):
        raise ValueError(f"Unexpected literals in {row['id']}: {[m[0] for m in literals]}")

    original = {}
    slots = []
    constraints = [case.constraint] if case.constraint else []
    for literal, field in zip(literals, case.fields):
        if field == '_':
            continue
        name, _, precision = field.partition(':')
        places = int(precision or 0)
        scale = 10**places
        value = F(literal[0].replace(',', '').replace(r'\!', '')) * scale
        if value.denominator != 1 or (name in original and original[name] != value):
            raise ValueError(f"Invalid literal {literal[0]!r} for {field} in {row['id']}")
        if places and name not in original:
            constraints.append(f'{name} is displayed after division by {scale}.')
        original[name] = int(value)
        slots.append((literal, name, places))

    parameters = {}
    for name, value in original.items():
        domain = case.bounds.get(name, (min(value, 2), max(100, 2 * value)))
        if isinstance(domain, tuple):
            parameters[name] = {'type': 'int', 'min': domain[0], 'max': domain[1]}
        else:
            parameters[name] = {'type': 'int', 'choices': domain}

    def render(p):
        parts = []
        start = 0
        for match, name, places in slots:
            parts.append(problem[start:match.start()])
            value = p[name]
            if value == original[name]:
                parts.append(match[0])
            elif places:
                whole, decimal = divmod(abs(value), 10**places)
                sign = '-' if value < 0 else ''
                parts.append(f'{sign}{whole}.{decimal:0{places}d}')
            else:
                parts.append(str(value))
            start = match.end()
        parts.append(problem[start:])
        return ''.join(parts)

    def sample(rng):
        if case.draw is not None:
            return dict(zip(original, case.draw(rng)))
        return {
            name: rng.choice(domain['choices']) if 'choices' in domain
            else rng.randint(domain['min'], domain['max'])
            for name, domain in parameters.items()
        }

    def joint(p):
        if not isinstance(p, dict) or p.keys() != parameters.keys():
            return False
        return all(_in_domain(p[name], domain) for name, domain in parameters.items()) and (
            case.valid is None or case.valid(**p)
        )

    return Template(
        family='word.' + case.family,
        parameters=parameters,
        original=original,
        render=render,
        solve=lambda p: case.solve(**p),
        sample=sample,
        validate=joint,
        constraints=constraints,
        reference=None if case.reference is None else lambda p: case.reference(**p),
        adaptation=('Digit notation and equivalent wording: ' +
                    '; '.join(f'{before!r} → {after!r}' for before, after in case.edits)
                    + '.') if case.edits else '',
    )


# Disjoint cells are sampled first, then the reported group sizes are assembled.
def _cells(rng):
    return tuple(rng.randint(2, 18) for _ in range(4))


def _neither_draw(rng):
    only_a, only_b, both, neither = _cells(rng)
    return only_a + only_b + both + neither, only_a + both, only_b + both, both


def _valid_groups(total, a, b, both):
    return 0 <= both <= min(a, b) and a + b - both <= total


def _outside_reference(total, a, b, both):
    first = set(range(a))
    second = set(range(a - both, a - both + b))
    return len(set(range(total)) - first - second)


_GROUPS = 'The four disjoint membership counts are nonnegative.'
pre('train/136 train/550 train/689 train/959 train/1150 test/31 test/738',
    'set-neither', 'total a b both', lambda total, a, b, both: total - a - b + both,
    valid=_valid_groups, draw=_neither_draw, constraint=_GROUPS, reference=_outside_reference)
pre('test/302', 'set-neither', 'total a b total both',
    lambda total, a, b, both: total - a - b + both,
    valid=_valid_groups, draw=_neither_draw, constraint=_GROUPS, reference=_outside_reference)
pre('train/663', 'set-neither', 'total a b both', lambda total, a, b, both: total - a - b + both,
    valid=_valid_groups, draw=_neither_draw, constraint=_GROUPS, reference=_outside_reference,
    edits=(('twelve businessmen', '12 businessmen'), ('ten businessmen', '10 businessmen'),
           ('Five businessmen', '5 businessmen')))
pre('train/995', 'set-neither', 'total a b both', lambda total, a, b, both: total - a - b + both,
    valid=_valid_groups, draw=_neither_draw, constraint=_GROUPS, reference=_outside_reference,
    edits=(('Seven students', '7 students'), ('including four', 'including 4')))


def _intersection_draw(rng):
    total, a, b, both = _neither_draw(rng)
    return total, a, b, total - a - b + both


def _intersection_valid(total, a, b, neither):
    return neither >= 0 and _valid_groups(total, a, b, a + b + neither - total)


def _intersection_reference(total, a, b, neither):
    active = total - neither
    return len(set(range(a)) & set(range(active - b, active)))


pre('train/432 test/155', 'set-intersection', 'total a b neither',
    lambda total, a, b, neither: a + b + neither - total,
    valid=_intersection_valid, draw=_intersection_draw, constraint=_GROUPS,
    reference=_intersection_reference)
pre('test/101', 'set-intersection', 'total a b neither',
    lambda total, a, b, neither: a + b + neither - total,
    valid=_intersection_valid, draw=_intersection_draw, constraint=_GROUPS,
    reference=_intersection_reference,
    edits=(('twenty boxes', '20 boxes'), ('Thirteen of', '13 of'), ('nine of', '9 of'),
           ('three of', '3 of')))
pre('test/114', 'set-intersection', 'total a b neither',
    lambda total, a, b, neither: a + b + neither - total,
    valid=_intersection_valid, draw=_intersection_draw, constraint=_GROUPS,
    reference=_intersection_reference, edits=(('Fifty students', '50 students'),))


def _full_intersection_draw(rng):
    _, a, b, both = _neither_draw(rng)
    return a + b - both, a, b


def _full_intersection(ids, edits=()):
    pre(ids, 'set-intersection-exhaustive', 'total a b',
        lambda total, a, b: a + b - total,
        valid=lambda total, a, b: _intersection_valid(total, a, b, 0),
        draw=_full_intersection_draw, constraint=_GROUPS,
        reference=lambda total, a, b: _intersection_reference(total, a, b, 0),
        edits=edits)


_full_intersection('test/847')
_full_intersection('train/264', (('A 12-slice pizza', 'A pizza with 12 slices'),
                                ('Only six slices', 'Only 6 slices'),
                                ('exactly ten slices', 'exactly 10 slices')))
_full_intersection('train/1131', (('An 18-slice pizza', 'A pizza with 18 slices'),
                                 ('Exactly ten slices', 'Exactly 10 slices'),
                                 ('exactly ten slices', 'exactly 10 slices')))


def _union_draw(rng):
    _, a, b, both = _neither_draw(rng)
    return a, b, both


def _union_valid(a, b, both):
    return 0 <= both <= min(a, b)


def _union_reference(a, b, both):
    return len(set(range(a)) | set(range(a - both, a - both + b)))


pre('train/117', 'set-union', 'a b both both a b', lambda a, b, both: a + b - both,
    valid=_union_valid, draw=_union_draw, constraint=_GROUPS, reference=_union_reference)
pre('test/770', 'set-union', 'a b both', lambda a, b, both: a + b - both,
    valid=_union_valid, draw=_union_draw, constraint=_GROUPS, reference=_union_reference)
pre('test/198', 'set-union', 'both a b', lambda a, b, both: a + b - both,
    valid=_union_valid, draw=lambda rng: _union_draw(rng)[::-1],
    constraint=_GROUPS, reference=_union_reference)


def _max_disjoint(total, a, b):
    return max(0, a + b - total)


def _minimum_overlap_draw(rng):
    total = rng.randint(20, 100)
    return total, rng.randint(2, total), rng.randint(2, total)


def _minimum_overlap_reference(total, a, b):
    return len(set(range(a)) & set(range(total - b, total)))


pre('train/642', 'minimum-intersection', 'total a b', _max_disjoint,
    valid=lambda total, a, b: max(a, b) <= total, draw=_minimum_overlap_draw,
    constraint='Each group is no larger than the surveyed population.',
    reference=_minimum_overlap_reference, edits=(('One hundred people', '100 people'),))
pre('test/245', 'minimum-intersection', 'total a b', _max_disjoint,
    valid=lambda total, a, b: max(a, b) <= total, draw=_minimum_overlap_draw,
    constraint='Each group is no larger than the cat population.',
    reference=_minimum_overlap_reference,
    edits=(('Seventeen of', '17 of'), ('Ten of', '10 of')))


def _ratio_total_draw(rng):
    a, b, unit = (rng.randint(2, 10) for _ in range(3))
    return a, b, (a + b) * unit


def _ratio_total_valid(girls, boys, total):
    return girls * total % (girls + boys) == 0


def _ratio_total_reference(girls, boys, total):
    return next(count for count in range(total + 1) if count * boys == (total - count) * girls)


pre('train/303 train/507', 'ratio-share', 'girls boys total',
    lambda girls, boys, total: F(girls * total, girls + boys),
    valid=_ratio_total_valid, draw=_ratio_total_draw, bounds={'total': (4, 300)},
    constraint='The ratio and total imply whole-number counts for both groups.',
    reference=_ratio_total_reference)
pre('test/442', 'ratio-share', 'girls boys total',
    lambda girls, boys, total: F(girls * total, girls + boys),
    valid=_ratio_total_valid, draw=_ratio_total_draw, bounds={'total': (4, 300)},
    constraint='The ratio and total imply whole-number counts for both garment types.',
    reference=_ratio_total_reference, edits=(('three\tdresses', '3 dresses'), ('five shirts', '5 shirts')))


def _age_draw(rng):
    youngest = rng.randint(2, 8)
    middle = rng.randint(youngest + 1, youngest + 4)
    max_gap = 19 - middle
    first_gap = middle - youngest
    candidates = [gap for gap in range(1, max_gap + 1) if (gap - first_gap) % 3 == 0]
    oldest = middle + rng.choice(candidates)
    return (youngest + middle + oldest) // 3, youngest, middle


def _oldest(mean, a, b):
    return 3 * mean - a - b


pre('train/471', 'mean-oldest-child', 'mean a b', _oldest,
    bounds={name: (1, 19) for name in ('mean', 'a', 'b')},
    valid=lambda mean, a, b: a < b < _oldest(mean, a, b) <= 19,
    draw=_age_draw, constraint='All ages are positive integers in increasing order up to 19 years.',
    reference=lambda mean, a, b: next(c for c in range(b + 1, 3 * mean)
                                     if F(a + b + c, 3) == mean))


def _mean(*values):
    return F(sum(values), len(values))


def _median(values):
    ordered = sorted(values)
    n = len(ordered)
    return F(ordered[(n - 1) // 2] + ordered[n // 2], 2)


def _ceil_div(a, b):
    return (a + b - 1) // b


def _divisor_common(*values):
    return max(d for d in range(1, min(values) + 1) if all(value % d == 0 for value in values))


def _count_multiple(*values):
    return next(n for n in range(max(values), prod(values) + 1)
                if all(n % v == 0 for v in values))


pre('train/148', 'greatest-equal-package', 'a b', lambda a, b: gcd(a, b),
    reference=lambda a, b: _divisor_common(a, b))
pre('train/482 test/324', 'greatest-equal-cut', 'a b c', lambda a, b, c: gcd(a, b, c),
    reference=lambda a, b, c: _divisor_common(a, b, c))
pre('test/713', 'greatest-equal-cut', 'a b', lambda a, b: gcd(a, b),
    reference=lambda a, b: _divisor_common(a, b))
pre('train/610 test/120', 'minimum-common-multiple', 'a b', lambda a, b: lcm(a, b),
    bounds={'a': (2, 40), 'b': (2, 60)}, reference=lambda a, b: _count_multiple(a, b))
pre('train/1013 test/439', 'minimum-common-multiple', 'a b c', lambda a, b, c: lcm(a, b, c),
    bounds={key: (2, 18) for key in 'abc'}, reference=lambda a, b, c: _count_multiple(a, b, c))
pre('train/655', 'minimum-common-multiple', 'a b c d e', lambda a, b, c, d, e: lcm(a, b, c, d, e),
    bounds={key: (2, 12) for key in 'abcde'}, reference=lambda a, b, c, d, e: _count_multiple(a, b, c, d, e))
pre('train/138 train/310', 'simultaneous-tutors', 'a b c d', lambda a, b, c, d: lcm(a, b, c, d),
    bounds={key: (2, 15) for key in 'abcd'}, reference=lambda a, b, c, d: _count_multiple(a, b, c, d),
    edits=(('every third school day', 'every 3 school days'),
           ('every fourth school day', 'every 4 school days'),
           ('every sixth school day', 'every 6 school days'),
           ('every seventh school day', 'every 7 school days')))
pre('train/196', 'minimum-buses', 'capacity students',
    lambda capacity, students: _ceil_div(students, capacity),
    reference=lambda capacity, students: next(n for n in range(1, students + 1)
                                             if n * capacity >= students))
pre('test/281', 'maximum-equal-candy-groups', 'candy minimum',
    lambda candy, minimum: candy // minimum,
    bounds={'minimum': (2, 20), 'candy': (20, 120)},
    reference=lambda candy, minimum: sum(n * minimum <= candy for n in range(1, candy + 1)))
def _class_group_draw(rng):
    limit, students = sorted(rng.sample(range(2, 51), 2))
    return students, limit


pre('train/790', 'minimum-equal-class-groups', 'students limit',
    lambda students, limit: students // max(d for d in range(1, limit + 1) if students % d == 0),
    valid=lambda students, limit: limit < students, draw=_class_group_draw,
    constraint='The group size limit is smaller than the class size, so at least two groups are needed.',
    reference=lambda students, limit: next(n for n in range(1, students + 1)
                                           if students % n == 0 and students // n <= limit))
pre('train/1012', 'maximum-whole-books', 'speed pages hours',
    lambda speed, pages, hours: speed * hours // pages,
    reference=lambda speed, pages, hours: len(range(pages, speed * hours + 1, pages)),
    bounds={'speed': (40, 120), 'pages': (100, 300), 'hours': (6, 12)},
    edits=(('six hours', '6 hours'),))


def _two_group_product(a, b):
    return a * b


def _two_group_reference(a, b):
    return len(list(product(range(a), range(b))))


pre('train/116', 'choose-outfit', 'a b', _two_group_product, reference=_two_group_reference)
pre('train/697', 'choose-outfit', 'a b', _two_group_product, reference=_two_group_reference,
    edits=(('three shirts', '3 shirts'), ('four pairs', '4 pairs')))
pre('test/142', 'cross-group-handshakes', 'a b', _two_group_product,
    reference=_two_group_reference, edits=(('Six witches', '6 witches'), ('ten sorcerers', '10 sorcerers')))
pre('test/755', 'cross-group-handshakes', 'a b', _two_group_product, reference=_two_group_reference,
    edits=(('of the six members from', 'of the 6 members from'),
           ('of the six members of', 'of the 6 members of')))
pre('train/235', 'choose-wrapping', 'a b c', lambda a, b, c: a * b * c,
    bounds={key: (2, 20) for key in 'abc'},
    reference=lambda a, b, c: sum(1 for _ in product(range(a), range(b), range(c))),
    edits=(('eight varieties', '8 varieties'), ('three colors', '3 colors'), ('four types', '4 types')))
pre('train/1090', 'choose-outfit', 'a b c', lambda a, b, c: a * b * c,
    bounds={key: (2, 20) for key in 'abc'},
    reference=lambda a, b, c: sum(1 for _ in product(range(a), range(b), range(c))),
    edits=(('four pairs', '4 pairs'), ('seven shirts', '7 shirts'), ('three jackets', '3 jackets')))
pre('test/689', 'choose-outfit', 'a b c', lambda a, b, c: a * b * c,
    bounds={key: (2, 20) for key in 'abc'},
    reference=lambda a, b, c: sum(1 for _ in product(range(a), range(b), range(c))))
pre('test/683', 'choose-meal', 'a b c', lambda a, b, c: a * b * c,
    bounds={key: (2, 20) for key in 'abc'},
    reference=lambda a, b, c: sum(1 for _ in product(range(a), range(b), range(c))),
    edits=(('five appetizers', '5 appetizers'), ('eight entrees', '8 entrees'),
           ('four desserts', '4 desserts')))
pre('test/458', 'choose-different-color-outfit', 'colors', lambda colors: colors * (colors - 1),
    bounds={'colors': (2, 30)},
    reference=lambda colors: sum(a != b for a, b in product(range(colors), repeat=2)))
pre('train/160', 'choose-pizza-toppings', 'choices picks', lambda choices, picks: comb(choices, picks),
    bounds={'choices': (3, 15), 'picks': (2, 10)},
    valid=lambda choices, picks: picks <= choices,
    draw=lambda rng: (lambda n: (n, rng.randint(2, min(10, n))))(rng.randint(3, 15)),
    constraint='There are at least as many toppings available as required in each combination.',
    reference=lambda choices, picks: sum(1 for _ in combinations(range(choices), picks)),
    edits=(('Five toppings', '5 toppings'), ('of two different toppings', 'of 2 different toppings')))
pre('test/790', 'count-houses-on-streets', 'streets houses',
    lambda streets, houses: 2 * streets * houses,
    reference=lambda streets, houses: sum(houses for _ in product(range(streets), range(2))),
    edits=(('six streets', '6 streets'),))


# Ratios of continuous quantities can be fractional; counts are checked separately.
def _proportion(quantity, old, new):
    return F(quantity * new, old)


def _whole_proportion(quantity, old, new):
    return old != new and quantity * new % old == 0


def _whole_draw(rng):
    unit, q = (rng.randint(2, 8) for _ in range(2))
    a, b = rng.sample(range(2, 9), 2)
    return q * a, unit * a, unit * b


_WHOLE = 'The two bases differ and the proportional model yields a whole number of items.'


def _bases_draw(rng, old_bounds, new_bounds):
    old = rng.randint(*old_bounds)
    new = rng.choice([n for n in range(new_bounds[0], new_bounds[1] + 1) if n != old])
    return old, new


def _bases_differ(quantity, old, new):
    return old != new
pre('train/168', 'direct-volume-proportion', 'quantity old new', _proportion,
    bounds={'quantity': (2, 150), 'old': (10, 500), 'new': (10, 1500)},
    valid=_bases_differ, draw=lambda rng: (rng.randint(2, 150), *_bases_draw(rng, (10, 500), (10, 1500))),
    constraint='The two flour volumes differ.',
    reference=lambda quantity, old, new: F(quantity, old) * new)
pre('train/185', 'direct-count-proportion', 'quantity old new', _proportion,
    valid=_whole_proportion, draw=_whole_draw, constraint=_WHOLE,
    reference=lambda quantity, old, new: F(quantity, old) * new)
pre('test/92', 'direct-volume-proportion', 'quantity old new', _proportion,
    bounds={'quantity': (2, 12), 'old': (8, 40), 'new': (8, 70)},
    valid=_bases_differ, draw=lambda rng: (rng.randint(2, 12), *_bases_draw(rng, (8, 40), (8, 70))),
    constraint='The desired number of cookies differs from the recipe quantity.',
    reference=lambda quantity, old, new: F(quantity, old) * new)
pre('train/662', 'direct-count-proportion', 'quantity old new', _proportion,
    valid=_whole_proportion, draw=_whole_draw, constraint=_WHOLE,
    reference=lambda quantity, old, new: F(quantity, old) * new,
    edits=(('eleven lassis', '11 lassis'), ('two mangoes', '2 mangoes'), ('twelve mangoes', '12 mangoes')))
pre('train/974', 'direct-count-proportion', 'quantity old new', _proportion,
    valid=_whole_proportion, draw=_whole_draw, constraint=_WHOLE,
    reference=lambda quantity, old, new: F(quantity, old) * new,
    edits=(('two pies', '2 pies'), ('nine apples', '9 apples'), ('twenty-seven apples', '27 apples')))
pre('train/327', 'direct-count-proportion', 'old quantity new new', _proportion,
    valid=_whole_proportion, draw=lambda rng: (lambda q, o, n: (o, q, n))(*_whole_draw(rng)),
    constraint=_WHOLE, reference=lambda quantity, old, new: F(quantity, old) * new)
def _step_draw(rng):
    stride_ratio = rng.randint(2, 6)
    short_walk = rng.randint(2, 5)
    longer_walk = rng.randint(short_walk + 1, 12)
    return (stride_ratio + rng.randint(1, 6)) * short_walk, stride_ratio * short_walk, stride_ratio * longer_walk


pre('test/524', 'direct-count-proportion', 'quantity old new', _proportion,
    valid=lambda quantity, old, new: quantity > old and new > old and _whole_proportion(quantity, old, new),
    draw=_step_draw,
    constraint='Max takes more steps than his dad over the same distance. The hall is longer and the result is a whole step count.',
    reference=lambda quantity, old, new: F(quantity, old) * new,
    edits=(('as three of', 'as 3 of'),))
pre('train/223', 'equal-group-weight', 'old new quantity', _proportion,
    reference=lambda quantity, old, new: F(quantity, old) * new,
    edits=(('Seven identical', '7 identical'), ('three identical', '3 identical')))
def _andrea_shadow_draw(rng):
    ratio = rng.randint(2, 5)
    shadow = rng.randint(5, 18)
    person_shadow = rng.randint(max(8, _ceil_div(36, ratio)), min(48, 84 // ratio))
    return ratio * shadow, shadow, person_shadow


pre('train/341', 'similar-shadow-heights', 'quantity old new', _proportion,
    bounds={'quantity': (10, 100), 'old': (3, 30), 'new': (8, 48)},
    valid=lambda quantity, old, new: 36 <= _proportion(quantity, old, new) <= 84,
    draw=_andrea_shadow_draw,
    constraint='Andrea’s inferred height is between 36 and 84 inches.',
    reference=lambda quantity, old, new: F(quantity, old) * new)
pre('test/565', 'similar-shadow-lengths', 'new old quantity', _proportion,
    bounds={'old': (4, 7)}, reference=lambda quantity, old, new: F(quantity, old) * new,
    edits=(('a 20-foot flagpole', 'a flagpole that is 20 feet tall'), ('is nine feet', 'is 9 feet'),))
pre('test/700', 'similar-shadow-lengths', 'new old quantity', _proportion,
    bounds={'old': (4, 7)}, reference=lambda quantity, old, new: F(quantity, old) * new,
    edits=(('a 15-foot flagpole', 'a flagpole that is 15 feet tall'), ('is six feet', 'is 6 feet'),))
pre('test/736', 'similar-shadow-heights', 'quantity old new', _proportion,
    bounds={'quantity': (4, 7), 'old': (2, 20), 'new': (30, 240)},
    reference=lambda quantity, old, new: F(quantity, old) * new,
    edits=(('A woman 5-feet tall casts an 8-foot shadow.', 'A woman who is 5 feet tall casts a shadow 8 feet long.'),))
def _rectangle_draw(rng):
    old, new = rng.sample(range(2, 31), 2)
    return old, rng.randint(2, 30), new


pre('test/376', 'proportional-rectangle', 'old quantity new', _proportion,
    valid=_bases_differ, draw=_rectangle_draw,
    constraint='The new rectangle has a different length.',
    reference=lambda quantity, old, new: F(quantity, old) * new)
pre('train/445', 'proportional-logo', 'old quantity:1 new',
    lambda quantity, old, new: _proportion(quantity, old, new) / 10,
    bounds={'new': (3, 12), 'old': (2, 8), 'quantity': (10, 60)},
    valid=lambda quantity, old, new: old < new,
    draw=lambda rng: (lambda old: (old, rng.randint(10, 40), rng.randint(old + 1, 12)))(
        rng.randint(2, 8)),
    constraint='The new logo is wider than the original so the change is an enlargement.',
    reference=lambda quantity, old, new: F(quantity, 10) / old * new)
def _dozen_recipe_draw(rng):
    dozens = rng.randint(2, 12)
    old = rng.choice([n for n in range(6, 85) if n != 12 * dozens])
    return old, rng.randint(2, 12), dozens


pre('train/374', 'scaled-cookie-recipe', 'old quantity dozens',
    lambda old, quantity, dozens: _proportion(quantity, old, 12 * dozens),
    valid=lambda old, quantity, dozens: old != 12 * dozens, draw=_dozen_recipe_draw,
    constraint='The requested number of cookies (12 per dozen) differs from the recipe yield.',
    reference=lambda old, quantity, dozens: F(quantity, old) * 12 * dozens,
    edits=(('two cups', '2 cups'), ('five dozen', '5 dozen')))
pre('train/306', 'scaled-cookie-recipe', 'old quantity _ new',
    lambda old, quantity, new: _proportion(2 * quantity, old, new),
    valid=_bases_differ, draw=_rectangle_draw,
    constraint='The requested number of cookies differs from the recipe yield.',
    reference=lambda old, quantity, new: F(quantity, old) * new * 2)
pre('train/279', 'cost-per-piece', 'cents count',
    lambda cents, count: F(cents * count, 100),
    reference=lambda cents, count: F(sum([cents] * count), 100),
    bounds={'cents': (1, 30), 'count': (2, 1500)},
    edits=(('The cost of 1 piece of gum is 1 cent.', 'The cost per piece of gum, in cents, is 1.'),))


def _typist_draw(rng):
    workers, days, new_workers, new_days, speed = (rng.randint(2, 6) for _ in range(5))
    return workers, workers * days * speed, days, new_workers, new_days


def _typist_valid(workers, memos, days, new_workers, new_days):
    return memos * new_workers * new_days % (workers * days) == 0


pre('test/467', 'workers-time-production', 'workers memos days new_workers new_days',
    lambda workers, memos, days, new_workers, new_days: F(memos * new_workers * new_days, workers * days),
    bounds={'memos': (1, 2500), 'new_days': (1, 14)},
    valid=_typist_valid, draw=_typist_draw, constraint='The proportional output is a whole number of memos.',
    reference=lambda workers, memos, days, new_workers, new_days: F(memos, days) / workers * new_days * new_workers,
    edits=(('Four typists', '4 typists'), ('in three days', 'in 3 days'),
           ('can three typists type in one day', 'can 3 typists type if their work period, in days, is 1')))


# Averages and order statistics.
pre('train/182', 'consecutive-integer-mean', 'a b', lambda a, b: F(a + b, 2),
    bounds={'a': (-80, -1), 'b': (1, 80)},
    reference=lambda a, b: _mean(*range(a, b + 1)))
pre('train/464', 'initial-integer-median', 'count',
    lambda count: F(count + 1, 2),
    edits=(('first ten', 'first 10'),),
    reference=lambda count: _median(range(1, count + 1)))
pre('train/222', 'two-value-mean-difference', 'a mean a _',
    lambda a, mean: abs(2 * (mean - a)),
    bounds={'a': (-50, 100), 'mean': (-50, 100)},
    valid=lambda a, mean: a != mean,
    draw=lambda rng: tuple(rng.sample(range(-50, 101), 2)),
    constraint='The two numbers are distinct so their difference is positive.',
    reference=lambda a, mean: abs(a - next(x for x in range(-300, 301) if F(a + x, 2) == mean)))


def _mean_median_gap(**values):
    return abs(_mean(*values.values()) - sorted(values.values())[2])


def _coaster_draw(rng):
    a, b, c, d = (rng.randint(45, 195) for _ in range(4))
    e = rng.randint(220, 390)
    if _mean_median_gap(a=a, b=b, c=c, d=d, e=e) == 0:
        e += 1
    return a, b, c, d, e


pre('train/637', 'mean-median-difference', 'a b c d e', _mean_median_gap,
    bounds={name: (20, 420) for name in 'abcde'},
    valid=lambda **p: _mean_median_gap(**p) > 0,
    draw=_coaster_draw, constraint='The mean and the median differ so the requested difference is positive.',
    reference=lambda **values: abs(F(sum(values.values()), 5) - _median(values.values())))
pre('train/1165', 'sample-mean', '_ a b c d e f g _',
    lambda **values: _mean(*values.values()),
    bounds={key: (-20, 30) for key in 'abcdefg'})
pre('train/1020', 'arithmetic-progression-mean', 'first increase days',
    lambda first, increase, days: first + F(increase * (days - 1), 2),
    reference=lambda first, increase, days: _mean(*(first + d * increase for d in range(days))))
pre('test/601', 'consecutive-smallest-from-mean', 'count mean count',
    lambda count, mean: mean - count // 2,
    bounds={'count': [3, 5, 7, 9, 11]},
    reference=lambda count, mean: next(a for a in range(mean - count, mean + 1)
                                       if _mean(*range(a, a + count)) == mean),
    edits=(('five consecutive', '5 consecutive'), ('of the five', 'of the 5')))
pre('train/494', 'shifted-set-mean', 'a b c d center',
    lambda a, b, c, d, center: center + _mean(0, a, b, c, d) - sorted((0, a, b, c, d))[2],
    bounds={key: (1, 32) for key in 'abcd'},
    valid=lambda a, b, c, d, center: len({a, b, c, d}) == 4,
    draw=lambda rng: (*sorted(rng.sample(range(1, 33), 4)), rng.randint(2, 40)),
    constraint='The five offsets, including 0, are distinct so the set has five members.',
    reference=lambda a, b, c, d, center: _mean(*(center + x - _median((0, a, b, c, d))
                                                 for x in (0, a, b, c, d))))


def _score_draw(rng, count, low=40, high=100):
    mean = rng.randint(low, high)
    scores = []
    remainder = mean * count
    for slots in range(count - 1, 0, -1):
        score = rng.randint(max(low, remainder - high * slots),
                            min(high, remainder - low * slots))
        scores.append(score)
        remainder -= score
    return mean, [*scores, remainder]


def _missing_score_6(a, b, c, d, e, mean):
    return 6 * mean - sum((a, b, c, d, e))


def _six_score_draw(rng):
    mean, scores = _score_draw(rng, 6)
    return (*scores[:-1], mean)


pre('train/486', 'missing-quiz-score', 'a b c d e mean', _missing_score_6,
    bounds={key: (0, 100) for key in ('a', 'b', 'c', 'd', 'e', 'mean')},
    valid=lambda **p: 0 <= _missing_score_6(**p) <= 100, draw=_six_score_draw,
    constraint='All six quiz scores are integers from 0 to 100.',
    reference=lambda a, b, c, d, e, mean: next(f for f in range(101)
                                                if _mean(a, b, c, d, e, f) == mean))


def _missing_score_5(mean, a, b, c, d):
    return 5 * mean - sum((a, b, c, d))


def _five_score_draw(rng):
    mean, scores = _score_draw(rng, 5)
    return (mean, *scores[:-1])


pre('test/327', 'missing-quiz-percentage', 'mean a b c d', _missing_score_5,
    bounds={key: (0, 100) for key in ('mean', 'a', 'b', 'c', 'd')},
    valid=lambda **p: 0 <= _missing_score_5(**p) <= 100, draw=_five_score_draw,
    constraint='All five percentage scores are integers from 0 to 100.',
    reference=lambda a, b, c, d, mean: next(e for e in range(101)
                                             if _mean(a, b, c, d, e) == mean))


def _required_next_scores(a, b, c, d, e, f, g, mean):
    return 10 * mean - sum((a, b, c, d, e, f, g))


def _ten_score_draw(rng):
    mean, scores = _score_draw(rng, 10, 0, 25)
    return (*scores[:7], mean)


pre('test/253', 'next-quiz-sum', 'a b c d e f g mean', _required_next_scores,
    bounds={key: (0, 100) for key in (*'abcdefg', 'mean')},
    valid=lambda **p: 0 <= _required_next_scores(**p) <= 300, draw=_ten_score_draw,
    constraint='Three scores from 0 to 100 can attain the required sum.',
    reference=lambda a, b, c, d, e, f, g, mean: next(q for q in range(301)
                                                    if _mean(a, b, c, d, e, f, g, q, 0, 0) == mean))


def _two_score_draw(rng):
    lower = rng.randint(70, 140)
    half_gap = rng.randint(1, 35)
    return 2 * half_gap, lower + half_gap


pre('train/1183', 'higher-bowling-score', 'gap mean _',
    lambda gap, mean: mean + F(gap, 2),
    bounds={'gap': (2, 150), 'mean': (1, 300)},
    valid=lambda gap, mean: gap % 2 == 0 and 0 <= mean - gap // 2 <= mean + gap // 2 <= 300,
    draw=_two_score_draw, constraint='Both bowling scores are integers from 0 to 300.',
    reference=lambda gap, mean: next(high for high in range(gap, 301)
                                     if _mean(high, high - gap) == mean))


def _basketball_draw(rng):
    other_avg = rng.randint(20, 70)
    star = rng.randint(45, 85)
    other_avg -= other_avg % 5
    return star + 6 * other_avg // 10, other_avg


pre('train/466', 'basketball-points-from-average', 'total avg:1',
    lambda total, avg: total - F(6 * avg, 10),
    bounds={'total': (8, 200), 'avg': (5, 100)},
    valid=lambda total, avg: (6 * avg % 10 == 0 and total - 6 * avg // 10 > _ceil_div(avg, 10)),
    draw=_basketball_draw,
    constraint='The others have a whole-number score total and can each score fewer points than Vanessa.',
    reference=lambda total, avg: next(score for score in range(1, total + 1)
                                    if F(total - score, 6) == F(avg, 10)))


def _ages_progression_draw(rng):
    count = rng.choice((3, 5, 7))
    gap = rng.randint(2, 3)
    start = rng.randint(1, min(4, 19 - (count - 1) * gap))
    return count, start + (count // 2) * gap, gap


def _ages_progression(mean, count, gap):
    return mean + F((count - 1) * gap, 2)


pre('train/984', 'oldest-equally-spaced-children', 'count mean gap', _ages_progression,
    bounds={'count': (3, 7), 'mean': (2, 15), 'gap': (2, 6)},
    valid=lambda count, mean, gap: ((count - 1) * gap % 2 == 0
                                    and 0 < 2 * mean - (count - 1) * gap
                                    and _ages_progression(mean, count, gap) <= 19),
    draw=_ages_progression_draw,
    constraint='The equally spaced ages are positive integers, and the oldest is at most 19.',
    edits=(('of five children', 'of 5 children'), ('of two years', 'of 2 years')),
    reference=lambda count, mean, gap: next(start + (count - 1) * gap for start in range(1, mean)
                                             if _mean(*range(start, start + count * gap, gap)) == mean))


def _test_average_draw(rng):
    a, b, c = (rng.randint(2, 24) for _ in range(3))
    return a + b + c, a, rng.randint(60, 80), b, rng.randint(81, 95), c, rng.randint(96, 100)


pre('test/785', 'frequency-weighted-mean', 'total a first b second c third',
    lambda total, a, first, b, second, c, third: F(a * first + b * second + c * third, total),
    bounds={'first': (0, 100), 'second': (0, 100), 'third': (0, 100)},
    valid=lambda total, a, first, b, second, c, third: total == a + b + c and first < second < third,
    draw=_test_average_draw,
    constraint='The three score categories are distinct and exhaustive.',
    reference=lambda total, a, first, b, second, c, third: _mean(
        *([first] * a + [second] * b + [third] * c)))


# Percentages and fractional allocations of integer totals.
def _partition(rng, total, count):
    cuts = (0, *sorted(rng.sample(range(1, total), count - 1)), total)
    return tuple(right - left for left, right in zip(cuts, cuts[1:]))


def _sales_draw(rng):
    return 100 * rng.randint(2, 6), *_partition(rng, 100, 4)[:3]


def _sales_valid(total, a, b, c):
    return a + b + c < 100 and all(total * part % 100 == 0 for part in (a, b, c))


pre('train/150', 'remaining-sales-percentage', 'total a b c',
    lambda total, a, b, c: F(total * (100 - a - b - c), 100),
    bounds={'total': (20, 600), **{name: (1, 97) for name in 'abc'}},
    valid=_sales_valid, draw=_sales_draw,
    constraint='Every model count is integral and Honda has a positive share.',
    reference=lambda total, a, b, c: total - sum(total * rate // 100 for rate in (a, b, c)))


def _drink_draw(rng):
    soda, milk, _ = _partition(rng, 100, 3)
    return soda, milk, soda * rng.randint(2, 5)


def _drink_valid(soda, milk, count):
    return soda + milk <= 100 and all(count * part % soda == 0 for part in (100, milk))


pre('train/438', 'proportion-between-percentages', 'soda milk count',
    lambda soda, milk, count: F(count * milk, soda),
    bounds={'soda': (1, 99), 'milk': (1, 99), 'count': (1, 500)},
    valid=_drink_valid, draw=_drink_draw,
    constraint='The percentages are disjoint, and the total and both beverage counts are whole students.',
    reference=lambda soda, milk, count: (100 * count // soda) * milk // 100)


def _remainder_percent_draw(rng):
    percent = rng.randint(5, 75)
    return percent, (100 - percent) * rng.randint(2, 6)


def _remainder_valid(percent, remainder):
    return 100 * remainder % (100 - percent) == 0


pre('train/578', 'total-from-percent-remainder', 'percent remainder',
    lambda percent, remainder: F(100 * remainder, 100 - percent),
    bounds={'percent': (1, 99), 'remainder': (1, 600)},
    valid=_remainder_valid, draw=_remainder_percent_draw,
    constraint='The total order and both subgroups are whole item counts.',
    reference=lambda percent, remainder: remainder + F(percent * remainder, 100 - percent))
pre('test/205', 'wins-from-losses-and-percent', 'percent remainder',
    lambda percent, remainder: F(percent * remainder, 100 - percent),
    bounds={'percent': (1, 99), 'remainder': (1, 600)},
    valid=_remainder_valid, draw=_remainder_percent_draw,
    constraint='The total games and both win/loss counts are whole numbers.',
    reference=lambda percent, remainder: F(100 * remainder, 100 - percent) - remainder)


def _known_total_percent_draw(rng):
    return 100 * rng.randint(2, 9), rng.randint(1, 99)


pre('test/346', 'count-from-complement-percentage', 'total percent',
    lambda total, percent: F(total * (100 - percent), 100),
    bounds={'total': (20, 1200), 'percent': (1, 99)},
    valid=lambda total, percent: total * percent % 100 == 0,
    draw=_known_total_percent_draw, constraint='Both score groups contain whole student counts.',
    reference=lambda total, percent: total - total * percent // 100)


def _fraction_draw(rng):
    den = rng.randint(3, 20)
    return rng.randint(1, den - 1), den


def _alien_draw(rng):
    num, den = _fraction_draw(rng)
    return num, den, den * rng.randint(2, 30)


def _proper_count(num, den, total):
    return 0 < num < den and total * num % den == 0


pre('test/516', 'fraction-of-alien-population', 'num den total _ _',
    lambda num, den, total: F(num * total, den),
    bounds={'num': (1, 39), 'den': (2, 40), 'total': (2, 700)},
    valid=_proper_count, draw=_alien_draw,
    constraint='A proper fraction of the population represents a whole number of aliens.',
    reference=lambda num, den, total: len(range(num * total // den)))


def _alien_eyes_draw(rng):
    num, den, total = _alien_draw(rng)
    few, many = sorted(rng.sample(range(2, 10), 2))
    return num, den, total, few, many


pre('test/582', 'fraction-weighted-eye-count', 'num den total few many total',
    lambda num, den, total, few, many: total * (F(num * few, den) + F((den - num) * many, den)),
    bounds={'num': (1, 30), 'den': (2, 35), 'total': (2, 700),
            'few': (2, 8), 'many': (3, 9)},
    valid=lambda num, den, total, few, many: _proper_count(num, den, total) and few < many,
    draw=_alien_eyes_draw,
    constraint='The two groups contain whole alien counts and have distinct eye counts.',
    reference=lambda num, den, total, few, many: sum(
        few if i < num * total // den else many for i in range(total)))


def _proper_fraction_draw(rng):
    num, den = _fraction_draw(rng)
    return num, den, rng.randint(2, 12)


pre('train/460', 'equal-fractional-shares', 'num den count',
    lambda num, den, count: F(num, den * count),
    bounds={'num': (1, 25), 'den': (2, 30), 'count': (2, 20)},
    valid=lambda num, den, count: num < den, draw=_proper_fraction_draw,
    constraint='The wrapping paper used is a proper fraction of one roll.',
    reference=lambda num, den, count: F(num, den) / count,
    edits=(('three presents', '3 presents'),))
pre('train/272', 'equal-fractional-shares', 'num den people',
    lambda num, den, people: F(num, people * den),
    bounds={'num': (1, 25), 'den': (2, 30), 'people': (3, 12)},
    valid=lambda num, den, people: num < den,
    draw=lambda rng: (*_fraction_draw(rng), rng.randint(3, 12)),
    constraint='The leftover pie is a proper fraction, and at least the three named friends share it.',
    reference=lambda num, den, people: F(num, den) / people,
    edits=(('Louie, Duey and Huey split the pie, with each taking home the same amount of leftover pie.',
            'Louie, Duey and Huey belong to a group of 3 friends who share the leftover pie equally.'),))


def _pie_draw(rng):
    den = rng.randint(3, 20)
    a, b, _ = _partition(rng, den, 3)
    return a, den, b, den


pre('test/169', 'total-fraction-eaten', 'a b c d',
    lambda a, b, c, d: F(a, b) + F(c, d),
    bounds={'a': (1, 20), 'b': (2, 20), 'c': (1, 20), 'd': (2, 20)},
    valid=lambda a, b, c, d: F(a, b) + F(c, d) <= 1,
    draw=_pie_draw, constraint='The combined amount eaten cannot exceed one pie.',
    reference=lambda a, b, c, d: F(a * d + c * b, b * d))


def _cone_draw(rng):
    noon_num, noon_den = _fraction_draw(rng)
    end_num, end_den = _fraction_draw(rng)
    initial = noon_den * end_den * rng.randint(1, 4)
    return initial, noon_num, noon_den, end_num, end_den


def _cone_valid(total, noon_num, noon_den, end_num, end_den):
    noon, remainder = divmod(total * noon_num, noon_den)
    return noon_num < noon_den and end_num < end_den and not remainder and noon * end_num % end_den == 0


pre('test/788', 'successive-fractional-remaining-count', 'total noon_num noon_den end_num end_den',
    lambda total, noon_num, noon_den, end_num, end_den: total * F(noon_num, noon_den) * F(end_num, end_den),
    bounds={'total': (2, 1600), 'noon_num': (1, 20), 'noon_den': (2, 20),
            'end_num': (1, 20), 'end_den': (2, 20)},
    valid=_cone_valid, draw=_cone_draw,
    constraint='Both fractions are proper and both elapsed checkpoints have whole cone counts.',
    reference=lambda total, noon_num, noon_den, end_num, end_den:
    (total * noon_num // noon_den) * end_num // end_den)


# Time, rates, wages and unit prices.
alg('test/418', 'distance-rate-time', 'speed time',
    lambda speed, time: speed * time,
    bounds={'speed': (2, 13), 'time': (4, 60)},
    reference=lambda speed, time: sum(speed for _ in range(time)))
alg('test/676', 'distance-rate-seconds', 'speed time',
    lambda speed, time: F(speed * time, 3600),
    bounds={'speed': (2, 18), 'time': (5, 240)},
    reference=lambda speed, time: time * F(speed, 60) / 60)
def _wrench_draw(rng):
    old, new = _bases_draw(rng, (2, 24), (2, 30))
    return old, rng.randint(25, 400), new


alg('train/393', 'inverse-force-leverage', 'old force new',
    lambda old, force, new: F(old * force, new),
    bounds={'old': (2, 24), 'new': (2, 30)},
    valid=lambda old, force, new: old != new, draw=_wrench_draw,
    constraint='The two wrench handle lengths differ.',
    reference=lambda old, force, new: force / F(new, old))
alg('test/945', 'scaled-hiking-water', 'quantity:1 old new',
    lambda quantity, old, new: F(quantity * new, 10 * old),
    bounds={'quantity': (5, 40), 'old': (2, 12), 'new': (2, 12)},
    valid=_bases_differ, draw=lambda rng: (rng.randint(5, 40), *rng.sample(range(2, 13), 2)),
    constraint='The two walking distances differ.',
    reference=lambda quantity, old, new: F(quantity, 10) / old * new)
alg('test/349', 'exercise-week-calories', 'baseline_minutes calories daily_minutes',
    lambda baseline_minutes, calories, daily_minutes: F(7 * calories * daily_minutes, baseline_minutes),
    bounds={'baseline_minutes': (10, 90), 'calories': (25, 400), 'daily_minutes': (10, 90)},
    reference=lambda baseline_minutes, calories, daily_minutes:
    sum(F(calories, baseline_minutes) * daily_minutes for _ in range(7)))
alg('train/881', 'distance-per-hour', '_ minutes seconds _',
    lambda minutes, seconds: F(3600, 60 * minutes + seconds),
    bounds={'minutes': (1, 4), 'seconds': (2, 59)},
    reference=lambda minutes, seconds: 1 / (F(minutes, 60) + F(seconds, 3600)),
    edits=(('1 mile in 1 minute 30 seconds', '1 mile in 1 min 30 seconds'),))


def _popsicle_draw(rng):
    minutes = rng.choice((5, 10, 15, 20, 30))
    hours = rng.randint(2, 7)
    extras = minutes * rng.randint(1, 59 // minutes)
    return minutes, hours, extras


alg('train/577', 'repeated-consumption-time', 'interval hours extra',
    lambda interval, hours, extra: (60 * hours + extra) // interval,
    bounds={'interval': (2, 45), 'hours': (2, 8), 'extra': (2, 59)},
    valid=lambda interval, hours, extra: (60 * hours + extra) % interval == 0,
    draw=_popsicle_draw, constraint='The elapsed time is a whole number of consumption intervals.',
    reference=lambda interval, hours, extra: len(range(interval, 60 * hours + extra + 1, interval)))


def _camp_draw(rng):
    original = rng.randint(3, 16)
    added = rng.randint(2, 8)
    days = (original + added) * rng.randint(1, 3) // gcd(original, original + added)
    return original, days, added


alg('test/96', 'camp-inverse-workforce', 'old days old extra',
    lambda old, days, extra: F(old * days, old + extra),
    bounds={'old': (2, 30), 'days': (2, 90), 'extra': (2, 12)},
    valid=lambda old, days, extra: old * days % (old + extra) == 0,
    draw=_camp_draw,
    constraint='The supplies last a whole number of days.',
    reference=lambda old, days, extra: F(days, 1 + F(extra, old)),
    edits=(('Twelve people', '12 people'), ('a ten-day', 'a 10-day'),
           ('of the twelve', 'of the 12'), ('by three more', 'by 3 more')))


def _mow_draw(rng):
    workers = rng.randint(2, 12)
    short = rng.randint(2, 8)
    return workers, short * rng.randint(2, 5), short


def _mow_extra(workers, hours, short):
    return F(workers * hours, short) - workers


alg('test/746', 'extra-workers-for-shorter-time', 'workers hours short',
    _mow_extra,
    bounds={'workers': (2, 20), 'hours': (2, 48), 'short': (2, 16)},
    valid=lambda workers, hours, short: short < hours and workers * hours % short == 0,
    draw=_mow_draw,
    constraint='The shorter time requires a whole number of workers at the same rate.',
    reference=lambda workers, hours, short: next(extra for extra in range(workers * hours)
                                                 if (workers + extra) * short == workers * hours),
    edits=(('Five people', '5 people'),))


def _bricks_draw(rng):
    rate = rng.randint(12, 50)
    multiplier = rng.randint(2, 5)
    total = rate * rng.randint(2, 10) * (1 + multiplier)
    return rate, multiplier, total


alg('test/653', 'work-shared-by-time-ratio', 'rate multiplier total',
    lambda rate, multiplier, total: F(total, multiplier + 1),
    bounds={'rate': (5, 60), 'multiplier': (2, 8), 'total': (6, 5000)},
    valid=lambda rate, multiplier, total: total % (multiplier + 1) == 0,
    draw=_bricks_draw, constraint='The ratio assigns an integer brick count to each worker.',
    reference=lambda rate, multiplier, total: rate * F(total, rate * (multiplier + 1)),
    edits=(('worked three times', 'worked 3 times'),))


def _weight_group(heavy_count, light_count, known_count, weight):
    return F(light_count * weight, known_count * heavy_count)


def _weight_group_draw(rng):
    heavy = rng.randint(5, 14)
    light = rng.randint(2, 5)
    known = rng.randint(2, light)
    return heavy, light, known, known * rng.randint(15, 35)


def _register_weight_group(ids, edits):
    alg(ids, 'equal-group-weight-with-multiple-known', 'heavy_count light_count known_count weight',
        _weight_group,
        bounds={'heavy_count': (2, 20), 'light_count': (2, 8), 'known_count': (2, 8),
                'weight': (10, 200)},
        valid=lambda heavy_count, light_count, known_count, weight: known_count <= light_count,
        draw=_weight_group_draw, constraint='The known subset includes at most all the canoes.',
        reference=lambda heavy_count, light_count, known_count, weight:
        F(weight, known_count) * light_count / heavy_count, edits=edits)


_register_weight_group('train/755', (('Seven identical', '7 identical'), ('four identical', '4 identical'),
                                     ('three of the canoes', '3 of the canoes')))
_register_weight_group('train/1152', (('Seven identical', '7 identical'), ('three identical', '3 identical'),
                                      ('two of the canoes', '2 of the canoes')))


def _unit_price_draw(rng):
    pencils = rng.randint(3, 14)
    pens = rng.randint(2, 8)
    bought = rng.randint(2, 8)
    pen_price = pencils * rng.randint(2, 12)
    return pencils, pens, bought, pen_price * bought


def _pencil_price(pencils, pens, bought, bill):
    return F(pens * bill, pencils * bought)


alg('test/146', 'price-equality-cents', 'pencils pens bought bill:2',
    _pencil_price,
    bounds={'bill': (1, 2000)},
    valid=lambda pencils, pens, bought, bill: bill % bought == 0
    and _pencil_price(pencils, pens, bought, bill).denominator == 1,
    draw=_unit_price_draw,
    constraint='A pencil and a pen each cost a whole number of cents.',
    reference=lambda pencils, pens, bought, bill: F(bill, bought) * pens / pencils,
    edits=(('Eleven pencils', '11 pencils'), ('as three pens', 'as 3 pens'),
           ('If seven pens', 'If 7 pens')))


def _two_prices_draw(rng):
    first, second = sorted(rng.sample(range(2, 12), 2))
    pencil = rng.randint(3, 60)
    eraser = rng.randint(5, 80)
    return first, first * pencil + eraser, second, second * pencil + eraser


def _two_price_pencil(first, bill_first, second, bill_second):
    return F(bill_second - bill_first, second - first)


alg('test/840', 'unit-price-from-two-purchases', 'first bill_first:2 second bill_second:2',
    _two_price_pencil,
    bounds={'first': (2, 12), 'second': (2, 12), 'bill_first': (1, 1000), 'bill_second': (1, 1000)},
    valid=lambda first, bill_first, second, bill_second: first < second and
    0 < (pencil := _two_price_pencil(first, bill_first, second, bill_second)) < F(bill_first, first)
    and pencil.denominator == 1,
    draw=_two_prices_draw,
    constraint='The purchases are distinct and both unit prices are positive whole cents.',
    reference=lambda first, bill_first, second, bill_second: next(
        price for price in range(1, bill_first // first + 1)
        if bill_first - first * price == bill_second - second * price),
    edits=(('Three pencils', '3 pencils'), ('Five pencils', '5 pencils')))


def _electricity_draw(rng):
    rent = rng.randint(1000, 6000)
    rate = rng.randint(55, 245)
    use = rng.randint(500, 8000)
    return rent, rate, 100 * rent + rate * use


alg('test/758', 'electricity-bill', 'rent rate:2 bill:2',
    lambda rent, rate, bill: F(bill - rent * 100, rate),
    bounds={'rent': (200, 10000), 'rate': (1, 400), 'bill': (20001, 3000000)},
    valid=lambda rent, rate, bill: bill > 100 * rent and (bill - rent * 100) % rate == 0,
    draw=_electricity_draw, constraint='The bill exceeds rent and yields a whole number of kilowatt-hours.',
    reference=lambda rent, rate, bill: next(use for use in range(1, (bill - 100 * rent) // rate + 1)
                                           if 100 * rent + use * rate == bill))


alg('test/632', 'salary-plus-commission', 'salary percent sales',
    lambda salary, percent, sales: salary + F(percent * sales, 100),
    bounds={'salary': (100, 5000), 'percent': (1, 40), 'sales': (100, 80000)},
    reference=lambda salary, percent, sales: F(100 * salary + percent * sales, 100))


def _shoe_draw(rng):
    price = rng.randint(12, 80)
    percent = rng.randint(10, 90)
    discount = rng.choice([d for d in range(2, price) if 100 * d != percent * price])
    return percent, discount, price


def _promotion_difference(percent, discount, price):
    return abs(F(percent * price, 100) - discount)


pre('train/495', 'compare-shoe-promotions', 'percent discount price _ _ _ _ _',
    _promotion_difference,
    bounds={'percent': (1, 99), 'discount': (1, 80), 'price': (2, 100)},
    valid=lambda percent, discount, price: discount < price and 100 * discount != percent * price,
    draw=_shoe_draw,
    constraint='The dollar discount is below the shoe price and the two promotions give different savings.',
    reference=lambda percent, discount, price: abs(
        price + F((100 - percent) * price, 100) - (2 * price - discount)),
    edits=(('get the second pair for half the price.', r'get a $50\%$ discount on the second pair.'),))


def _bake_draw(rng):
    group = rng.randint(2, 5)
    batches = rng.randint(6, 18)
    cookies_price = rng.randint(1, 3)
    cupcakes = rng.randint(10, 30)
    cupcake_price = rng.randint(1, 5)
    brownies = rng.randint(10, 30)
    brownie_price = rng.randint(1, 5)
    cost = rng.randint(2, 20)
    return group * batches, group, cookies_price, cupcakes, cupcake_price, brownies, brownie_price, cost


def _bake_profit(cookies, group, cookies_price, cupcakes, cupcake_price, brownies, brownie_price, cost):
    return F(cookies * cookies_price, group) + cupcakes * cupcake_price + brownies * brownie_price - cost


pre('test/525', 'bake-sale-profit', 'cookies group cookies_price cupcakes cupcake_price brownies brownie_price cost',
    _bake_profit, bounds={'cookies': (2, 100), 'cupcake_price': (1, 30)},
    valid=lambda **p: p['cookies'] % p['group'] == 0 and _bake_profit(**p) > 0,
    draw=_bake_draw,
    constraint='All cookies are sold in whole bundles and the sale has a positive profit.',
    reference=lambda cookies, group, cookies_price, cupcakes, cupcake_price, brownies, brownie_price, cost:
    sum([cookies_price] * (cookies // group) + [cupcake_price] * cupcakes + [brownie_price] * brownies) - cost,
    edits=(('at three for', 'at 3 for'),))


# Ratios before and after changing two integer counts.
def _marble_scale(a, b, remove, add, c, d):
    return F(d * remove + c * add, a * d - b * c)


def _marble_valid(a, b, remove, add, c, d):
    if a * d == b * c:
        return False
    scale = _marble_scale(a, b, remove, add, c, d)
    blue = a * scale
    yellow = b * scale
    return (blue.denominator == yellow.denominator == 1
            and blue > 0 and yellow > 0 and blue > remove and yellow + add > 0)


def _marble_draw(rng, increase_blue):
    a, b = (rng.randint(2, 9) for _ in range(2))
    scale = rng.randint(3, 8)
    if increase_blue:
        added = rng.randint(2, 15)
        removed = rng.randint(2, b * scale - 1)
        new_blue, new_yellow = a * scale + added, b * scale - removed
    else:
        removed = rng.randint(2, a * scale - 1)
        added = rng.randint(2, 15)
        new_blue, new_yellow = a * scale - removed, b * scale + added
    divisor = gcd(new_blue, new_yellow)
    changes = (added, removed) if increase_blue else (removed, added)
    return (a, b, *changes, new_blue // divisor, new_yellow // divisor)


def _marble_reference(a, b, remove, add, c, d):
    for blue in range(max(1, remove + 1), abs(d * remove + c * add) * a + 1):
        yellow, residue = divmod(blue * b, a)
        if residue == 0 and yellow > 0 and yellow + add > 0:
            if F(blue - remove, yellow + add) == F(c, d):
                return blue
    raise ValueError('No feasible initial count')


_MARBLE_BOUNDS = {'a': (1, 12), 'b': (1, 12), 'remove': (1, 80),
                  'add': (1, 80), 'c': (1, 100), 'd': (1, 100)}
_MARBLE_CONSTRAINT = 'Both ratios define a unique solution with positive whole counts before and after the exchange.'
alg('train/1039', 'ratio-after-marble-exchange', 'a b remove add c d',
    lambda **p: p['a'] * _marble_scale(**p),
    bounds=_MARBLE_BOUNDS, valid=_marble_valid, draw=lambda rng: _marble_draw(rng, False),
    constraint=_MARBLE_CONSTRAINT, reference=_marble_reference)


def _reverse_marble_signs(a, b, remove, add, c, d):
    return dict(a=a, b=b, remove=-remove, add=-add, c=c, d=d)


alg('test/1058', 'ratio-after-marble-exchange', 'a b remove add c d',
    lambda **p: p['a'] * _marble_scale(**_reverse_marble_signs(**p)),
    bounds=_MARBLE_BOUNDS, valid=lambda **p: _marble_valid(**_reverse_marble_signs(**p)),
    draw=lambda rng: _marble_draw(rng, True),
    constraint=_MARBLE_CONSTRAINT, reference=lambda **p: _marble_reference(**_reverse_marble_signs(**p)))


def _change_age_draw(rng):
    factor = rng.randint(2, 6)
    age = rng.randint(2, 12)
    return factor, age * (factor - 1)


alg('train/273', 'age-from-twin-ratio', 'factor difference',
    lambda factor, difference: F(difference, factor - 1),
    bounds={'factor': (2, 6), 'difference': (2, 60)},
    valid=lambda factor, difference: difference % (factor - 1) == 0,
    draw=_change_age_draw,
    constraint='The age ratio and age gap give a positive whole-number age in years.',
    reference=lambda factor, difference: next(age for age in range(1, difference + 1)
                                             if factor * age == age + difference),
    edits=(('three times', '3 times'), ('six years', '6 years')))


alg('test/711', 'age-from-grandparent-ratio', 'factor difference',
    lambda factor, difference: F(difference, factor - 1),
    bounds={'factor': (2, 15), 'difference': (35, 100)},
    valid=lambda factor, difference: difference % (factor - 1) == 0
    and factor * difference // (factor - 1) <= 120,
    draw=lambda rng: (lambda factor: (factor, (factor - 1) * rng.randint(
        _ceil_div(35, factor - 1), min(12, 120 // factor))))(rng.randint(5, 9)),
    constraint='Andrew has a positive integer age, and his grandfather is no older than 120.',
    reference=lambda factor, difference: next(age for age in range(1, 121)
                                             if factor * age == age + difference),
    edits=(('eight times', '8 times'),))


def _older_brother(early_factor, years, late_factor):
    return F(early_factor * years * (late_factor - 1), early_factor - late_factor)


def _brother_draw(rng):
    late = rng.randint(2, 4)
    early = late + rng.randint(1, 3)
    unit = rng.randint(2, 4)
    return early, (early - late) * unit, late


pre('test/703', 'age-after-changing-ratio', 'early_factor years late_factor',
    _older_brother,
    bounds={'early_factor': (3, 8), 'years': (2, 20), 'late_factor': (2, 5)},
    valid=lambda early_factor, years, late_factor: early_factor > late_factor
    and years * (late_factor - 1) % (early_factor - late_factor) == 0
    and _older_brother(early_factor, years, late_factor) + years <= 110,
    draw=_brother_draw,
    constraint='The older brother remains older, both ages are integers, and the later age is at most 110.',
    reference=lambda early_factor, years, late_factor: next(
        early_factor * age for age in range(1, 110) if early_factor * age + years == late_factor * (age + years)),
    edits=(('Six years', '6 years'), ('twice as old as I will be', '2 times as old as I will be')))


def _four_person_ages_draw(rng):
    chad = rng.randint(5, 25)
    eduardo_gap = rng.randint(4, 8)
    diana_gap = rng.randint(2, 8)
    faye_gap = rng.randint(2, 8)
    return diana_gap, eduardo_gap, faye_gap, chad + eduardo_gap - diana_gap


alg('train/1727', 'age-difference-chain', 'younger older faye diana',
    lambda younger, older, faye, diana: diana + younger - older + faye,
    bounds={name: (1, 55) for name in ('younger', 'older', 'faye', 'diana')},
    valid=lambda younger, older, faye, diana: diana + younger > older,
    draw=_four_person_ages_draw,
    constraint='Diana, Eduardo, Chad and Faye all have positive whole-number ages.',
    reference=lambda younger, older, faye, diana: next(c + faye for c in range(1, 111)
                                                      if c + older - younger == diana),
    edits=(('three years younger', '3 years younger'), ('four years older', '4 years older'),
           ('three years older', '3 years older')))


def _hike_draw(rng):
    first, second, third, fourth = (2 * rng.randint(2, 10) for _ in range(4))
    return first + second, (second + third) // 2, third + fourth, first + third


def _hike_total(first_pair, middle_mean, last_pair, first_third):
    return first_pair + last_pair


def _hike_distances(first_pair, middle_mean, last_pair, first_third):
    third = F(first_third + 2 * middle_mean - first_pair, 2)
    return first_third - third, 2 * middle_mean - third, third, last_pair - third


alg('test/721', 'hiking-paired-daily-distances', 'first_pair middle_mean last_pair first_third',
    _hike_total, valid=lambda **p: min(_hike_distances(**p)) > 0, draw=_hike_draw,
    constraint='The overlapping sums imply a positive mileage on each day.',
    reference=lambda **p: sum(_hike_distances(**p)))


def _weights_draw(rng):
    a, b, c, d = (rng.randint(65, 210) for _ in range(4))
    return a + b, b + c, c + d


alg('train/1633 test/857', 'weight-pair-cancellation', 'ab bc cd',
    lambda ab, bc, cd: ab + cd - bc,
    bounds={key: (50, 600) for key in ('ab', 'bc', 'cd')},
    valid=lambda ab, bc, cd: bc <= ab + cd - 2,
    draw=_weights_draw,
    constraint='All three pair weights can come from four strictly positive whole-pound individual weights.',
    reference=lambda ab, bc, cd: next(ab - b + cd - (bc - b)
                                      for b in range(1, min(ab, bc)) if 0 < bc - b < cd))


def _runner_draw(rng):
    race = rng.randint(3, 12) * 50
    lead = rng.randint(2, 12)
    beatrice = lead + rng.randint(race // 8, race // 4)
    target = rng.randint(2, 12) * 10
    return race, lead, beatrice, target


alg('test/1034', 'race-finish-time-proportion', 'race lead beatrice target',
    lambda race, lead, beatrice, target: F((beatrice - lead) * target, race),
    bounds={'race': (50, 650), 'lead': (1, 20), 'beatrice': (2, 200), 'target': (2, 120)},
    valid=lambda race, lead, beatrice, target: beatrice > lead and target < race,
    draw=_runner_draw,
    constraint='Alice has a positive race time, and the target distance is shorter than the race.',
    reference=lambda race, lead, beatrice, target: target / F(race, beatrice - lead))


def _refund_draw(rng):
    susan_count = rng.randint(2, 5)
    pam_count = susan_count + rng.randint(1, 3)
    return rng.randint(10, 35), susan_count, rng.randint(20, 35), pam_count, rng.randint(10, 24)


def _discount_difference(price, susan_count, susan_off, pam_count, pam_off):
    return F(price * (pam_count * (100 - pam_off) - susan_count * (100 - susan_off)), 100)


alg('test/738', 'compare-ticket-coupons', 'price susan_count susan_off pam_count pam_off',
    _discount_difference,
    bounds={'price': (2, 100), 'susan_count': (2, 10), 'pam_count': (2, 15),
            'susan_off': (1, 99), 'pam_off': (1, 99)},
    valid=lambda **p: _discount_difference(**p) > 0,
    draw=_refund_draw, constraint='Pam pays more than Susan and each discount is strictly below 100 percent.',
    reference=lambda price, susan_count, susan_off, pam_count, pam_off:
    pam_count * (price - F(price * pam_off, 100)) - susan_count * (price - F(price * susan_off, 100)))


def _latest_score_draw(rng):
    factor = rng.randint(1, 3)
    first = 25 * factor
    extra = 100 - first
    score = factor * rng.randint(1, 24)
    new_score = rng.randint(score * extra // first + 1, extra)
    return first, 100 * score // first, extra, score + new_score


def _last_shots(first, before, extra, after):
    return F((first + extra) * after - first * before, 100)


alg('train/711', 'basketball-shooting-percentages', 'first before extra after extra',
    _last_shots,
    bounds={'first': (1, 100), 'before': (1, 99), 'extra': (1, 100), 'after': (1, 99)},
    valid=lambda first, before, extra, after: before < after and first * before % 100 == 0
    and (first + extra) * after % 100 == 0 and 0 < _last_shots(first, before, extra, after) <= extra,
    draw=_latest_score_draw,
    constraint='The shooting percentage improves and both observed success totals are integral and attainable.',
    reference=lambda first, before, extra, after: next(
        new for new in range(extra + 1) if F(first * before // 100 + new, first + extra) == F(after, 100)))


def _class_test_draw(rng):
    a, b, c = (5 * rng.randint(2, 8) for _ in range(3))
    p, q, r = (20 * rng.randint(1, 3) for _ in range(3))
    return a + b + c, a, b, c, p, q, r, rng.randint(65, 90)


def _needed_right(total, a, b, c, p, q, r, passing):
    return _ceil_div(total * passing, 100) - (a * p + b * q + c * r) // 100


def _class_test_valid(total, a, b, c, p, q, r, passing):
    return a + b + c == total and all(n * score % 100 == 0 for n, score in ((a, p), (b, q), (c, r))) and (
        _needed_right(total, a, b, c, p, q, r, passing) > 0
    )


pre('train/437', 'more-questions-to-pass', 'total a b c p q r passing passing',
    _needed_right,
    bounds={'total': (6, 150), **{k: (2, 60) for k in 'abc'},
            **{k: (1, 100) for k in ('p', 'q', 'r', 'passing')}},
    valid=_class_test_valid, draw=_class_test_draw,
    constraint='The sections exhaust the test, each correctly answered count is integral, and the student fell short.',
    reference=lambda total, a, b, c, p, q, r, passing: next(
        delta for delta in range(total + 1) if F(a * p + b * q + c * r + 100 * delta, total) >= passing))


def _fraction_multiple_draw(rng):
    num, den = _fraction_draw(rng)
    return num, den, num * rng.randint(2, 20)


pre('test/574', 'whole-count-from-fraction-and-part', 'num den count',
    lambda num, den, count: F(den * count, num),
    bounds={'num': (1, 20), 'den': (2, 20), 'count': (2, 1200)},
    valid=lambda num, den, count: num < den and den * count % num == 0,
    draw=_fraction_multiple_draw,
    constraint='The proper fraction and partial count imply an integral student population.',
    reference=lambda num, den, count: next(total for total in range(count, count * den + 1)
                                          if F(num * total, den) == count),
    edits=(('Two-thirds of', 'A fraction 2/3 of'),))


def _people_from_empty_chairs(seated_num, seated_den, filled_num, filled_den, empty):
    return F(empty * filled_num * seated_den, (filled_den - filled_num) * seated_num)


def _chair_valid(seated_num, seated_den, filled_num, filled_den, empty):
    return (seated_num < seated_den and filled_num < filled_den
            and empty * filled_den % (filled_den - filled_num) == 0
            and _people_from_empty_chairs(seated_num, seated_den, filled_num, filled_den, empty).denominator == 1)


def _chair_draw(rng):
    seated_num, seated_den = _fraction_draw(rng)
    filled_num, filled_den = _fraction_draw(rng)
    empty = (filled_den - filled_num) * seated_num * rng.randint(1, 4)
    return seated_num, seated_den, filled_num, filled_den, empty


alg('train/292', 'people-from-chair-occupancy', 'seated_num seated_den filled_num filled_den empty',
    _people_from_empty_chairs,
    bounds={key: (1, 20) for key in ('seated_num', 'seated_den', 'filled_num', 'filled_den')}
    | {'empty': (1, 1600)},
    valid=_chair_valid, draw=_chair_draw,
    constraint='Both proper fractions give whole counts of chairs and people.',
    reference=lambda seated_num, seated_den, filled_num, filled_den, empty:
    (F(empty, 1 - F(filled_num, filled_den)) - empty) / F(seated_num, seated_den),
    edits=(('Two-thirds of', 'A fraction 2/3 of'), ('in three-fourths of', 'in a fraction 3/4 of')))


def _cd_purchase_draw(rng):
    first, second = rng.sample(range(2, 11), 2)
    return first, first * rng.randint(3, 22), second


pre('train/679', 'scaled-purchase-cost', 'first price second',
    lambda first, price, second: F(price * second, first),
    bounds={'first': (2, 10), 'price': (2, 250), 'second': (2, 10)},
    valid=lambda first, price, second: first != second and 100 * price % first == 0,
    draw=_cd_purchase_draw,
    constraint='The two purchase quantities differ and each CD costs a whole number of cents.',
    reference=lambda first, price, second: F(price, first) * second,
    edits=(('Two identical CDs', '2 identical CDs'), ('dollars of five', 'dollars of 5')))


pre('train/314', 'affordable-rental-area', 'rate:2 budget',
    lambda rate, budget: F(100 * budget, rate),
    bounds={'rate': (5, 500), 'budget': (20, 4000)},
    edits=(('largest apartment, in square feet, she should consider', 'largest floor area in square feet she can afford'),),
    reference=lambda rate, budget: F(budget, F(rate, 100)))


def _coin_bundle_value(dimes, quarters):
    return 5 + 10 * dimes + 25 * dimes * quarters


def _coins_draw(rng):
    dimes, quarters = (rng.randint(1, 4) for _ in range(2))
    return rng.randint(2, 12) * _coin_bundle_value(dimes, quarters), dimes, quarters


pre('test/695', 'coins-from-denomination-count-ratios', 'cents:2 dimes quarters',
    lambda cents, dimes, quarters: (1 + dimes + dimes * quarters) * (cents // _coin_bundle_value(dimes, quarters)),
    bounds={'cents': (40, 5500), 'dimes': (1, 5), 'quarters': (1, 5)},
    valid=lambda cents, dimes, quarters: cents % _coin_bundle_value(dimes, quarters) == 0,
    draw=_coins_draw,
    constraint='The total value gives a whole number of nickels under the two coin-count ratios.',
    reference=lambda cents, dimes, quarters: next(
        n + n * dimes + n * dimes * quarters for n in range(1, cents // 5 + 1)
        if 5 * n + 10 * n * dimes + 25 * n * dimes * quarters == cents),
    edits=(('For each nickel she has one dime and for each dime she has one quarter.',
            'The dime count is 1 times the nickel count, and the quarter count is 1 times the dime count.'),))


def _coin_value_draw(rng):
    return 25 * rng.randint(2, 35), 5 * rng.randint(2, 35), rng.randint(2, 200)


def _coin_valid(quarter, nickel, penny):
    return quarter % 25 == nickel % 5 == 0


pre('train/1136', 'coin-probability-from-value', '_ _ _ quarter:2 nickel:2 penny:2',
    lambda quarter, nickel, penny: F(quarter // 25, quarter // 25 + nickel // 5 + penny),
    bounds={name: (1, 1200) for name in ('quarter', 'nickel', 'penny')},
    valid=_coin_valid, draw=_coin_value_draw,
    constraint='Each subtotal corresponds to a positive whole number of coins of that denomination.',
    reference=lambda quarter, nickel, penny:
    F(quarter, 25) / (F(quarter, 25) + F(nickel, 5) + penny))


def _dough_draw(rng):
    cookie = F(rng.randint(1, 5), rng.randint(7, 24))
    total = cookie * rng.randint(3, 14)
    # Both fractions have independent display scales, retaining some cancellable cases.
    total_scale = rng.randint(1, min(3, 70 // max(total.numerator, total.denominator)))
    cookie_scale = rng.randint(1, min(3, 70 // max(cookie.numerator, cookie.denominator)))
    return (total_scale * total.numerator, total_scale * total.denominator,
            cookie_scale * cookie.numerator, cookie_scale * cookie.denominator)


pre('test/633', 'cookies-from-fractional-dough', 'a b c d',
    lambda a, b, c, d: F(a * d, b * c),
    bounds={key: (1, 70) for key in 'abcd'},
    valid=lambda a, b, c, d: c < d and a * d % (b * c) == 0,
    draw=_dough_draw,
    constraint='Each cookie uses a proper fraction of a pound and the dough divides into whole cookies.',
    reference=lambda a, b, c, d: next(n for n in range(1, a * d + 1) if n * F(c, d) == F(a, b)))


def _copy_draw(rng):
    cents = rng.choice((2, 4, 5, 10, 20, 25))
    return cents, rng.randint(2, 12), rng.randint(2, 30)


pre('train/1161', 'pages-from-copy-budget', 'cents pages budget',
    lambda cents, pages, budget: F(100 * budget * pages, cents),
    bounds={'cents': (1, 50), 'pages': (2, 20), 'budget': (1, 60)},
    valid=lambda cents, pages, budget: 100 * budget * pages % cents == 0,
    draw=_copy_draw, constraint='The budget covers a whole number of copies at the stated rate.',
    reference=lambda cents, pages, budget: F(100 * budget, F(cents, pages)))


def _marble_target_added(total, blue, num, den):
    return F(num * total - den * blue, den - num)


def _marble_target_draw(rng):
    blue = rng.randint(2, 35)
    other = rng.randint(2, 35)
    added = rng.randint(2, 35)
    return blue + other, blue, blue + added, blue + other + added


pre('test/759', 'extra-marbles-for-probability', 'total blue num den',
    _marble_target_added,
    bounds={key: (1, 110) for key in ('total', 'blue', 'num', 'den')},
    valid=lambda total, blue, num, den: blue < total and num < den
    and _marble_target_added(total, blue, num, den) > 0
    and _marble_target_added(total, blue, num, den).denominator == 1,
    draw=_marble_target_draw,
    constraint='The new fraction is proper and attainable by adding a positive whole number of blue marbles.',
    reference=lambda total, blue, num, den: next(extra for extra in range(1, num * total + 1)
                                                if F(blue + extra, total + extra) == F(num, den)),
    edits=(('five of them', '5 of them'),))


pre('test/276', 'odd-numbered-chairs', 'rows each _ each',
    lambda rows, each: rows * _ceil_div(each, 2),
    reference=lambda rows, each: sum(n % 2 for _ in range(rows) for n in range(1, each + 1)))
pre('test/295', 'inch-foot-fraction', 'feet inches',
    lambda feet, inches: F(inches, 12 * feet),
    bounds={'feet': (2, 100), 'inches': (2, 23)},
    reference=lambda feet, inches: F(inches, 12) / feet)


def _survey_table_draw(rng):
    a, b, c, d = _cells(rng)
    return a, d, a + c, b + d


def _survey_table_valid(male_yes, female_no, total_yes, total_no):
    return male_yes <= total_yes and female_no <= total_no


pre('train/32', 'partial-contingency-table', 'male_yes female_no total_yes total_no',
    lambda male_yes, female_no, total_yes, total_no: total_yes - male_yes,
    valid=_survey_table_valid, draw=_survey_table_draw,
    constraint='Both missing cells of the survey table are nonnegative integers.',
    reference=lambda male_yes, female_no, total_yes, total_no: next(
        female_yes for female_yes in range(total_yes + 1) if male_yes + female_yes == total_yes))


def _raisins_draw(rng):
    factor = rng.randint(2, 5)
    return (factor - 1) * rng.randint(3, 18), factor


def _raisins_received(gap, factor):
    return F(gap * factor, factor - 1)


pre('train/35', 'count-from-gap-and-ratio', 'gap _ factor',
    _raisins_received,
    bounds={'gap': (1, 100), 'factor': (2, 8)},
    valid=lambda gap, factor: gap % (factor - 1) == 0,
    draw=_raisins_draw, constraint='Both children receive a positive whole number of raisins.',
    reference=lambda gap, factor: next(a for a in range(gap + 1, gap * factor + 1)
                                       if a == factor * (a - gap)),
    edits=(('half the number', r'$\frac{1}{2}$ of the number'),))


pre('train/65', 'fractional-pay-for-cleaning', 'rate_num rate_den rooms_num rooms_den',
    lambda rate_num, rate_den, rooms_num, rooms_den: F(rate_num * rooms_num, rate_den * rooms_den),
    bounds={key: (2, 20) for key in ('rate_num', 'rate_den', 'rooms_num', 'rooms_den')},
    reference=lambda rate_num, rate_den, rooms_num, rooms_den:
    F(rate_num, rate_den) * F(rooms_num, rooms_den))


def _hoodie_draw(rng):
    bills = rng.randint(2, 5)
    quarters = rng.randint(2, 12)
    cost = 1000 * bills + 25 * quarters + rng.randint(1, 1400)
    return cost, bills, quarters


pre('train/76', 'minimum-dimes-to-afford-price', 'cost:2 bills _ quarters',
    lambda cost, bills, quarters: _ceil_div(cost - 1000 * bills - 25 * quarters, 10),
    bounds={'cost': (1000, 7500), 'bills': (2, 6), 'quarters': (2, 20)},
    valid=lambda cost, bills, quarters: cost > 1000 * bills + 25 * quarters,
    draw=_hoodie_draw, constraint='At least one dime is needed and overpaying by up to nine cents is allowed.',
    reference=lambda cost, bills, quarters: next(d for d in range(cost + 1)
                                                 if d * 10 + 1000 * bills + 25 * quarters >= cost),
    edits=(('three $', '3 $'), ('eight quarters', '8 quarters')))


def _lunchbox_draw(rng):
    total, a, b = _minimum_overlap_draw(rng)
    return a, b, total


pre('train/444', 'minimum-intersection', 'a b total', _max_disjoint,
    valid=lambda total, a, b: max(a, b) <= total, draw=_lunchbox_draw,
    constraint='Neither subgroup exceeds the class size.',
    reference=_minimum_overlap_reference,
    edits=(('Twelve students', '12 students'), ('Twenty students', '20 students')))


def _exclusive_draw(rng):
    only_a, only_b, both, _ = _cells(rng)
    return both, only_a + both, only_b


def _exclusive_reference(both, all_a, only_b):
    a = set(range(all_a))
    b = set(range(all_a - both, all_a + only_b))
    return len(a ^ b)


pre('train/448', 'exclusive-group-membership', 'both all_a only_b',
    lambda both, all_a, only_b: all_a - both + only_b,
    valid=lambda both, all_a, only_b: both <= all_a,
    draw=_exclusive_draw, constraint='The shared group is a subset of the first group.',
    reference=_exclusive_reference,
    edits=(('Ten students', '10 students'),))


pre('train/1077', 'exclusive-group-membership', 'both all_a only_b',
    lambda both, all_a, only_b: all_a - both + only_b,
    valid=lambda both, all_a, only_b: both <= all_a,
    draw=_exclusive_draw, constraint='The shared albums are part of Andrew’s collection.',
    reference=_exclusive_reference,
    edits=(('share nine', 'share 9'), ('has seventeen', 'has 17'), ('Six albums', '6 albums')))


def _band_draw(rng):
    total, a, b, neither = _intersection_draw(rng)
    return total, a, b, total - neither


pre('train/738', 'intersection-from-union', 'total a b union',
    lambda total, a, b, union: a + b - union,
    valid=lambda total, a, b, union: union <= total and _intersection_valid(union, a, b, 0),
    draw=_band_draw, constraint='The union is a subset of the school and the group counts are feasible.',
    reference=lambda total, a, b, union: _intersection_reference(union, a, b, 0),
    edits=(('Seventy of the students', '70 of the students'),))


def _math_club_draw(rng):
    girls = rng.randint(4, 16)
    boys = rng.randint(2, girls - 1)
    return 2 * girls + boys, girls


def _possible_boys(total, divisor):
    return [total - girls for girls in range(divisor, total + 1, divisor) if 2 * girls > total]


pre('test/868', 'majority-and-multiple', 'total divisor',
    lambda total, divisor: total % divisor,
    bounds={'total': (5, 90), 'divisor': (2, 30)},
    valid=lambda total, divisor: len(_possible_boys(total, divisor)) == 1,
    draw=_math_club_draw, constraint='Exactly one positive multiple gives more girls than boys.',
    reference=lambda total, divisor: _possible_boys(total, divisor)[0],
    edits=(('Thirty-five students', '35 students'),))


pre('train/472', 'block-walking-distance', 'east north _ den',
    lambda east, north, den: F(east + north, den),
    bounds={'east': (2, 40), 'north': (2, 40), 'den': (2, 15)},
    reference=lambda east, north, den: F(east, den) + F(north, den),
    edits=(('six blocks', '6 blocks'), ('one-third of a mile', '1/3 of a mile')))


def _marble_ratio_draw(rng):
    a, b, c, scale = (rng.randint(2, 12) for _ in range(4))
    return a, b, c, c * scale


pre('train/532', 'three-group-ratio-total', 'a b c green',
    lambda a, b, c, green: F(green * (a + b + c), c),
    bounds={'a': (1, 20), 'b': (1, 20), 'c': (1, 20), 'green': (2, 150)},
    valid=lambda a, b, c, green: green * a % c == green * b % c == 0,
    draw=_marble_ratio_draw, constraint='The ratio determines whole counts for all three colors.',
    reference=lambda a, b, c, green: sum((green, green * a // c, green * b // c)))


def _calculator_draw(rng):
    boys = rng.randint(8, 35)
    girls_with = rng.randint(2, 35)
    boys_with = rng.randint(2, boys)
    return boys, girls_with + boys_with, girls_with


pre('train/555', 'remaining-boys-without-calculators', 'boys all_with girls_with',
    lambda boys, all_with, girls_with: boys - (all_with - girls_with),
    valid=lambda boys, all_with, girls_with: 0 <= all_with - girls_with <= boys,
    draw=_calculator_draw, constraint='The implied number of boys with calculators is feasible.',
    reference=lambda boys, all_with, girls_with: next(
        without for without in range(boys + 1) if boys - without + girls_with == all_with))


def _passenger_draw(rng):
    percent_women = rng.choice((20, 40, 50, 60, 80))
    percent_first = rng.choice((10, 20, 25, 40, 50))
    return percent_women, percent_first, 200 * rng.randint(1, 5)


pre('train/360', 'percentage-within-percentage', 'percent_women percent_first total',
    lambda percent_women, percent_first, total: F(total * percent_women * percent_first, 10000),
    bounds={'percent_women': (1, 99), 'percent_first': (1, 99), 'total': (2, 1000)},
    valid=lambda percent_women, percent_first, total: total * percent_women % 100 == 0
    and total * percent_women * percent_first % 10000 == 0,
    draw=_passenger_draw, constraint='The two percentages imply whole numbers of passengers.',
    reference=lambda percent_women, percent_first, total: (total * percent_women // 100) * percent_first // 100,
    edits=(('Sixty percent', '60 percent'), ('ten percent', '10 percent')))


def _decimal_marble_draw(rng):
    total = rng.choice((5, 10, 20, 25, 40, 50))
    return _partition(rng, total, 3)


pre('train/604', 'jelly-bean-probability', 'red green yellow blue',
    lambda red, green, yellow, blue: F(blue, red + green + yellow + blue),
    reference=lambda red, green, yellow, blue: 1 / (1 + F(red + green + yellow, blue)))
pre('train/767', 'ball-color-probability', 'white black',
    lambda white, black: F(white, white + black),
    reference=lambda white, black: 1 / (1 + F(black, white)))
pre('train/843', 'two-marble-colors-probability', 'red blue yellow',
    lambda red, blue, yellow: F(red + blue, red + blue + yellow),
    bounds={key: (1, 50) for key in ('red', 'blue', 'yellow')},
    valid=lambda red, blue, yellow: 1000 * (red + blue) % (red + blue + yellow) == 0,
    draw=_decimal_marble_draw,
    constraint='The probability is an exact terminating decimal with at most three decimal places.',
    reference=lambda red, blue, yellow: 1 - F(yellow, red + blue + yellow))


def _pairof_prices(a, b, c, d, price_ab, price_cd):
    det = a * d - b * c
    return F(d * price_ab - b * price_cd, det), F(a * price_cd - c * price_ab, det)


def _metals_draw(rng):
    a = rng.randint(3, 12)
    c = a + rng.randint(2, 8)
    b = rng.randint(2, 6)
    d = rng.choice([ounces for ounces in range(2, 7) if a * ounces != b * c])
    feather = rng.randint(2, 8)
    gold = rng.randint(300, 550)
    return a, b, a * feather + b * gold, c, d, c * feather + d * gold, rng.randint(2, 8), rng.randint(2, 8)


def _metals_valid(a, b, price_ab, c, d, price_cd, e, f):
    if a * d == b * c:
        return False
    prices = _pairof_prices(a, b, c, d, price_ab, price_cd)
    return all(price > 0 and (100 * price).denominator == 1 for price in prices)


def _metals_cost(a, b, price_ab, c, d, price_cd, e, f):
    feather, gold = _pairof_prices(a, b, c, d, price_ab, price_cd)
    return e * feather + f * gold


alg('test/30', 'two-component-purchase', 'a b price_ab c d price_cd e f',
    _metals_cost, bounds={'price_ab': (1, 4000), 'price_cd': (1, 4000)},
    valid=_metals_valid, draw=_metals_draw,
    constraint='The two purchases uniquely determine positive unit prices in whole cents.',
    reference=lambda a, b, price_ab, c, d, price_cd, e, f:
    F((e * d - f * c) * price_ab + (f * a - e * b) * price_cd, a * d - b * c),
    edits=(('Eight pounds', '8 pounds'), ('and two ounces', 'and 2 ounces'),
           ('Fourteen pounds', '14 pounds'), ('and three ounces', 'and 3 ounces'),
           ('of five pounds', 'of 5 pounds'), ('and five ounces', 'and 5 ounces')))


def _drive_minutes(start_h, start_m, end_h, end_m):
    return 60 * (end_h + 12 - start_h) + end_m - start_m


def _drive_draw(rng):
    start_h = rng.randint(8, 11)
    start_m = 15 * rng.randint(0, 3)
    end_h = rng.randint(1, 4)
    end_m = 15 * rng.randint(0, 3)
    minutes = _drive_minutes(start_h, start_m, end_h, end_m)
    return start_h, start_m, end_h, end_m, minutes * rng.randint(2, 4) // 3


def _driving_speed(start_h, start_m, end_h, end_m, miles):
    return F(60 * miles, _drive_minutes(start_h, start_m, end_h, end_m))


alg('train/41', 'average-driving-speed-across-noon', 'start_h start_m end_h end_m miles',
    _driving_speed,
    bounds={'start_h': (7, 11), 'start_m': (0, 59), 'end_h': (1, 5), 'end_m': (0, 59), 'miles': (2, 800)},
    valid=lambda **p: 15 <= _driving_speed(**p) <= 85, draw=_drive_draw,
    constraint='The elapsed time is positive across noon, and the average speed is between 15 and 85 miles per hour.',
    reference=lambda start_h, start_m, end_h, end_m, miles: miles / (
        F(12 - start_h) - F(start_m, 60) + end_h + F(end_m, 60)),
    edits=(('9:40 a.m. until 1:20 p.m.', '9 h 40 min after midnight until 1 h 20 min after noon'),))


alg('train/453', 'puppy-and-cats-weight', 'total factor',
    lambda total, factor: F(total * (factor - 1), 2 * (factor + 1)),
    bounds={'total': (4, 60), 'factor': (2, 6)},
    edits=(('exactly twice as much', 'exactly 2 times as much'),),
    reference=lambda total, factor: F(total, 2) - F(total, factor + 1))


def _share_money_draw(rng):
    num, den = _fraction_draw(rng)
    return (num + den) * rng.randint(2, 18), num, den


def _share_money_diff(total, num, den):
    return F(total * (den - num), den + num)


alg('test/979', 'money-difference-from-total-and-fraction', 'total num den',
    _share_money_diff,
    bounds={'total': (2, 800), 'num': (1, 25), 'den': (2, 30)},
    valid=lambda total, num, den: num < den and 100 * total * num % (num + den) == 0,
    draw=_share_money_draw, constraint='Lenny has more money, and both amounts are whole numbers of cents.',
    reference=lambda total, num, den: total - 2 * F(total * num, den + num),
    edits=(('two-fifths of', 'a fraction 2/5 of'),))


def _cookie_pans_draw(rng):
    students = rng.randint(35, 180)
    yield_per_pan = rng.randint(8, 30)
    butter = rng.randint(2, 6)
    return students, yield_per_pan, butter, students * 2


def _pan_sticks(students, batch, butter, demand):
    return _ceil_div(_ceil_div(demand, batch) * butter, 8)


alg('test/781', 'full-cookie-pans-and-sticks-of-butter', 'students _ batch _ _ _ _ butter _ _ _ demand _',
    _pan_sticks,
    bounds={'students': (2, 220), 'batch': (2, 30), 'butter': (2, 6), 'demand': (4, 440)},
    valid=lambda students, batch, butter, demand: students * 2 == demand,
    draw=_cookie_pans_draw, constraint='Cookie demand equals twice the student count, with only full pans and butter sticks purchased.',
    reference=lambda students, batch, butter, demand: next(
        sticks for sticks in range(1, demand + 1) if (sticks * 8 // butter) * batch >= demand))


# The special forms render derived quantities or variable-length data.
def _int_domain(low, high):
    return {'type': 'int', 'min': low, 'max': high}


def _special(ids, family, original, domains, render, solve, draw, *, valid=None,
             constraint='', reference=None, adaptation):
    if (valid is None) != (not constraint):
        raise ValueError('Every joint domain needs a documented constraint')
    parameters = {
        name: _int_domain(*domain) if isinstance(domain, tuple) else domain
        for name, domain in domains.items()
    }

    def validate(p):
        return isinstance(p, dict) and p.keys() == parameters.keys() and all(
            _in_domain(p[name], domain) for name, domain in parameters.items()
        ) and (valid is None or valid(**p))

    def sample(rng):
        return dict(zip(original, draw(rng)))

    template = Template(
        family='word.' + family, parameters=parameters, original=original,
        render=lambda p: render(**p), solve=lambda p: solve(**p),
        sample=sample, validate=validate, constraints=[constraint] if constraint else [],
        reference=None if reference is None else lambda p: reference(**p), adaptation=adaptation,
    )
    for source_id in ids.split():
        if source_id in _SPECIAL or source_id in _CASES:
            raise ValueError(f'Duplicate word template {source_id}')
        _SPECIAL[source_id] = template


def _hotel_draw(rng):
    rooms = rng.randint(5, 80)
    a, b = sorted(rng.sample(range(1, rooms + 1), 2))
    return rooms, a, b


def _hotel_median(rooms, a, b):
    def label(rank):
        if rank >= a:
            rank += 1
        if rank >= b:
            rank += 1
        return rank

    remaining = rooms - 2
    return F(label((remaining + 1) // 2) + label(remaining // 2 + 1), 2)


_special('prealgebra/train/105', 'hotel-room-median', dict(rooms=21, a=12, b=13),
         {'rooms': (3, 100), 'a': (1, 100), 'b': (1, 100)},
         lambda rooms, a, b: f'At a state contest, {rooms} Mathletes each have a different hotel room, numbered '
         f'1 through {rooms}. Everyone arrives except the Mathletes in rooms {a} and {b}. '
         f'What is the median room number of the {rooms - 2} who arrived?',
         _hotel_median, _hotel_draw,
         valid=lambda rooms, a, b: a < b <= rooms,
         constraint='Two distinct absent room numbers are listed in increasing order and lie within the hotel room range.',
         reference=lambda rooms, a, b: _median([n for n in range(1, rooms + 1) if n not in (a, b)]),
         adaptation='The number of arrivals is derived from the number of assigned rooms and the two absences.')


def _rounded(value, unit):
    return unit * ((2 * value + unit) // (2 * unit))


def _rounding_draw(rng):
    unit = rng.choice((10, 100, 1000))
    if rng.randrange(2):
        low, high = unit // 2, _ceil_div(3 * unit, 4) - 1
    else:
        low, high = _ceil_div(unit, 4), unit // 2 - 1
    a, b = [rng.randint(1, 40) * unit + rng.randint(low, high) for _ in range(2)]
    return a, b, unit


def _rounding_story(left, right, unit):
    a, b = _rounded(left, unit), _rounded(right, unit)
    return (f'Van was asked to add {left} and {right} and round the result to the nearest multiple of {unit}. '
            f'He rounded the numbers first, getting {a} and {b}, then added them to get ${a}+{b}={a+b}$. '
            'His answer is incorrect. What is the correct answer? Round halfway cases up.')


_special('prealgebra/train/187', 'round-before-or-after-addition',
         dict(left=46, right=37, unit=10),
         {'left': (10, 41000), 'right': (10, 41000), 'unit': {'type': 'int', 'choices': [10, 100, 1000]}},
         _rounding_story, lambda left, right, unit: _rounded(left + right, unit), _rounding_draw,
         valid=lambda left, right, unit: _rounded(left + right, unit) != _rounded(left, unit) + _rounded(right, unit),
         constraint='Rounding before adding gives a different result from rounding the sum.',
         reference=lambda left, right, unit: min(
             range(0, left + right + unit + 1, unit), key=lambda n: (abs(n - left - right), -n)),
         adaptation='The incorrectly rounded operands and result are derived and the rounding place may vary.')


def _simultaneous_sales(book_period, shoe_period, shoe_day):
    divisor = gcd(book_period, shoe_period)
    if shoe_day % divisor:
        return 0
    reduced_period = shoe_period // divisor
    index = shoe_day // divisor * pow(book_period // divisor, -1, reduced_period) % reduced_period
    first = book_period * (index or reduced_period)
    return max(0, (31 - first) // lcm(book_period, shoe_period) + 1)


def _sale_draw(rng):
    a, b = rng.sample(range(2, 16), 2)
    return a, b, rng.randint(1, 31)


_special('prealgebra/train/536', 'overlapping-monthly-sale-dates',
         dict(book_period=5, shoe_period=6, shoe_day=3),
         {'book_period': (2, 20), 'shoe_period': (2, 20), 'shoe_day': (1, 31)},
         lambda book_period, shoe_period, shoe_day: f'A bookstore has a sale on dates that are multiples of '
         f'{book_period}. A shoe store has a sale every {shoe_period} days and has one on July {shoe_day}. '
         'On how many dates in July do both stores have sales?',
         _simultaneous_sales, _sale_draw,
         reference=lambda book_period, shoe_period, shoe_day: sum(
             (day - shoe_day) % shoe_period == 0 for day in range(book_period, 32, book_period)),
         adaptation='The parenthetical sample dates are omitted. The anchor fixes the phase of the second sale schedule.')


def _clock_angle(hour, minute):
    diff = (60 * hour - 11 * minute) % 720
    return F(min(diff, 720 - diff), 2)


def _clock_reference(hour, minute):
    hour_angle = F(30 * (hour % 12)) + F(minute, 2)
    minute_angle = 6 * minute
    direct = abs(hour_angle - minute_angle)
    return min(direct, 360 - direct)


for source_id, clock_hour in (('prealgebra/train/794', 11), ('prealgebra/test/14', 8)):
    _special(source_id, 'smaller-clock-hand-angle', dict(hour=clock_hour, minute=0),
             {'hour': (1, 12), 'minute': (0, 59)},
             lambda hour, minute: f'An analog clock reads {hour}:{minute:02d}. How many degrees are in the '
             'smaller angle between its minute and hour hands?',
             _clock_angle, lambda rng: (rng.randint(1, 12), rng.randint(0, 59)),
             reference=_clock_reference,
             adaptation='The displayed time includes a variable number of minutes past the hour.')


def _time_label(minutes):
    hour, minute = divmod(minutes, 60)
    return f'{hour % 12 or 12}:{minute:02d} {"a.m." if hour < 12 else "p.m."}'


def _tour_draw(rng):
    interval = rng.randint(2, 12) * 5
    start = rng.randint(7 * 12, 11 * 12) * 5
    first_count = _ceil_div(13 * 60 - start, interval)
    last_count = (21 * 60 - start) // interval
    return interval, start, start + interval * rng.randint(first_count, last_count)


_special('algebra/test/932', 'inclusive-tour-schedule',
         dict(interval=20, start=540, end=1080),
         {'interval': (5, 90), 'start': (360, 719), 'end': (780, 1260)},
         lambda interval, start, end: f'Suppose Luray Caverns runs tours every {interval} minutes. In April the first '
         f'tour each day starts at {_time_label(start)} and the last starts at {_time_label(end)} '
         'How many tours run per day in April?',
         lambda interval, start, end: (end - start) // interval + 1, _tour_draw,
         valid=lambda interval, start, end: (end - start) % interval == 0,
         constraint='The last tour starts a whole number of periods after the first; both are counted.',
         reference=lambda interval, start, end: len(range(start, end + 1, interval)),
         adaptation='Start and end times are parameters in minutes since midnight, rendered as clock times.')


_special('algebra/test/1046', 'minimum-periodic-walking-distance',
         dict(miles=4, interval=3, days=28),
         {'miles': (2, 15), 'interval': (2, 10), 'days': {'type': 'int', 'choices': [28, 29]}},
         lambda miles, interval, days: f'Suzanne walks {miles} miles every {interval} days. '
         f'What is the fewest number of miles she can walk in a February with {days} days?',
         lambda miles, interval, days: miles * (days // interval),
         lambda rng: (rng.randint(2, 15), rng.randint(2, 10), rng.choice((28, 29))),
         reference=lambda miles, interval, days: miles * min(
             len(range(first, days + 1, interval)) for first in range(1, interval + 1)),
         adaptation='The number of days in February is explicit; the phase of the walking schedule is unspecified.')


def _next_mean_term(first, second, position):
    previous, current = F(first), F(second)
    for _ in range(2, position):
        previous, current = current, (previous + current) / 2
    return current


_special('prealgebra/test/716', 'successive-pair-average', dict(first=32, second=8, position=5),
         {'first': (-30, 80), 'second': (-30, 80), 'position': (3, 16)},
         lambda first, second, position: f'A sequence begins {first}, {second}. Each later term is the mean of '
         f'the preceding two terms. What is the term in position {position}, counting from 1?',
         _next_mean_term, lambda rng: (*rng.sample(range(-30, 81), 2), rng.randint(3, 16)),
         valid=lambda first, second, position: first != second,
         constraint='The two starting values differ, so the sequence is nonconstant.',
         reference=lambda first, second, position: F(first + 2 * second, 3)
         + F(2 * (first - second), 3) * F(-1, 2)**(position - 1),
         adaptation='The final queried position varies while the average-of-two rule is unchanged.')


_special('prealgebra/test/249', 'specified-fair-coin-sequence', dict(sequence=[1, 0, 1]),
         {'sequence': {'type': 'list[int]', 'min_length': 2, 'max_length': 10, 'items': _int_domain(0, 1)}},
         lambda sequence: f'Lucia flips a fair coin {len(sequence)} times independently. What is the probability '
         'that she gets ' + ', '.join('Head' if side else 'Tail' for side in sequence)
         + ', in that order? Express your answer as a common fraction.',
         lambda sequence: F(1, 2**len(sequence)),
         lambda rng: ([rng.randrange(2) for _ in range(rng.randint(2, 10))],),
         reference=lambda sequence: F(sum(tuple(sequence) == outcomes
                                          for outcomes in product((0, 1), repeat=len(sequence))), 2**len(sequence)),
         adaptation='The ordered list and flip count vary together. A one represents heads and a zero represents tails.')


def _marble_chain(a, b, c, total):
    return F(total, 1 + a + a * b + a * b * c)


def _marble_chain_draw(rng):
    a, b, c = (rng.randint(2, 6) for _ in range(3))
    return a, b, c, (1 + a + a * b + a * b * c) * rng.randint(1, 7)


pre('train/284', 'four-person-count-chain', 'a b c total', _marble_chain,
    bounds={'total': (15, 2000)},
    valid=lambda a, b, c, total: _marble_chain(a, b, c, total).denominator == 1,
    draw=_marble_chain_draw, constraint='The linked multipliers give whole positive counts for all four children.',
    reference=lambda a, b, c, total: next(n for n in range(1, total + 1)
                                          if n + a * n + b * a * n + c * b * a * n == total),
    edits=(('twice as many', '2 times as many'), ('three times', '3 times'), ('five times', '5 times')))


pre('train/197', 'printed-house-digits', 'last _ last digit',
    lambda last, digit: sum(str(n).count(str(digit)) for n in range(1, last + 1)),
    bounds={'last': (20, 2000), 'digit': (0, 9)},
    reference=lambda last, digit: sum(sum(int(d) == digit for d in str(n)) for n in range(1, last + 1)),
    edits=(('How many 9s are painted?', 'How many occurrences of the digit 9 are painted?'),))


pre('train/114', 'mean-from-fractional-sum', 'count _ den count',
    lambda count, den: F(1, den * count),
    bounds={'count': (2, 20), 'den': (2, 25)},
    reference=lambda count, den: F(1, den) / count,
    edits=(('The sum of four', 'The sum of 4'), ('one-half', '1/2'), ('the four numbers', 'the 4 numbers')))


def _allergy_draw(rng):
    den = rng.randint(2, 15)
    num = rng.randint(1, den - 1)
    return num, den, den * rng.randint(5, 40)


pre('train/321', 'expected-count-from-prevalence', 'num den population',
    lambda num, den, population: F(num * population, den),
    bounds={'num': (1, 15), 'den': (2, 16), 'population': (10, 800)},
    valid=lambda num, den, population: 0 < num < den and population * num % den == 0,
    draw=_allergy_draw, constraint='The hypothetical proportion is proper and gives a whole expected count.',
    reference=lambda num, den, population: F(num, den) * population,
    edits=(('One out of every five Americans suffers from allergies.',
            'Suppose 1 out of every 5 Americans suffers from allergies.'),))


pre('train/367', 'height-conversion-rounded', 'height _ _',
    lambda height: F((127 * height + 2) // 5, 10),
    bounds={'height': (36, 84)},
    reference=lambda height: (lambda centimeters, floor: min(
        (F(floor, 10), F(floor + 1, 10)), key=lambda candidate: abs(candidate - centimeters)))(
            F(254 * height, 100), 254 * height // 10))


pre('train/401', 'angle-from-complement-ratio', 'multiple',
    lambda multiple: F(90 * multiple, 1 + multiple),
    bounds={'multiple': (2, 15)},
    reference=lambda multiple: 90 - F(90, multiple + 1),
    edits=(('is double the measure', 'is 2 times the measure'),))


def _handedness_draw(rng):
    left_jazz, left_other, right_jazz, right_other = _cells(rng)
    return left_jazz + left_other + right_jazz + right_other, left_jazz + left_other, left_jazz + right_jazz, right_other


def _left_jazz(total, left, jazz, right_other):
    return left + jazz + right_other - total


pre('train/453', 'contingency-table-from-marginals', 'total left jazz right_other', _left_jazz,
    valid=lambda total, left, jazz, right_other:
    _valid_groups(total, left, jazz, _left_jazz(total, left, jazz, right_other)),
    draw=_handedness_draw, constraint='All four disjoint handedness and music preference counts are nonnegative.',
    reference=lambda total, left, jazz, right_other: _intersection_reference(total, left, jazz, right_other))


def _trade_chain(first, middle_first, middle_second, last, quantity):
    return F(quantity * middle_first * last, first * middle_second)


def _trade_chain_draw(rng):
    a, b, c, d = (rng.randint(2, 9) for _ in range(4))
    scale = a * c // gcd(a * c, b * d)
    return a, b, c, d, scale * rng.randint(2, 8)


def _register_trade(subject, ids, edits=()):
    _register(subject, ids, 'two-linked-price-equivalences', 'first middle_first middle_second last quantity',
              _trade_chain, bounds={'quantity': (2, 700)},
              valid=lambda **p: _trade_chain(**p).denominator == 1,
              draw=_trade_chain_draw, constraint='The final price equivalence is a whole number of items.',
              reference=lambda first, middle_first, middle_second, last, quantity:
              quantity * F(middle_first, first) / F(middle_second, last), edits=edits)


_register_trade('prealgebra', 'train/755')
_register_trade('algebra', 'train/486', (('eight apples', '8 apples'), ('four bananas', '4 bananas'),
                                          ('two bananas', '2 bananas'), ('three cucumbers', '3 cucumbers')))
_register_trade('algebra', 'test/471', (('six cookies', '6 cookies'), ('four brownies', '4 brownies'),
                                        ('eighteen cookies', '18 cookies')))


def _set_mean_draw(rng):
    known = rng.sample(range(10, 61), 5)
    last = rng.choice([x for x in range(10, 61) if x not in known and (sum(known) + x) % 3 == 0])
    return (*known, 5 * (sum(known) + last) // 3)


def _median_from_mean(a, b, c, d, e, mean):
    known = (a, b, c, d, e)
    last = F(3 * mean, 5) - sum(known)
    return known, last


def _mean_set_valid(**p):
    known, last = _median_from_mean(**p)
    return len(set((*known, last))) == 6


pre('train/782', 'median-after-missing-value-from-mean', 'a b c d e mean:1',
    lambda **p: _median((*_median_from_mean(**p)[0], _median_from_mean(**p)[1])),
    bounds={'mean': (50, 950)}, valid=_mean_set_valid, draw=_set_mean_draw,
    constraint='The implied unknown is distinct from the other five numbers.',
    reference=lambda **p: (lambda values: (values[2] + values[3]) / F(2))(
        sorted((*_median_from_mean(**p)[0], _median_from_mean(**p)[1]))))


def _score_partition_draw(rng):
    a, b = (rng.randint(30, 100) for _ in range(2))
    c = rng.choice([value for value in range(30, 101) if (a + b + value) % 3 == 0])
    scores = [a, b, c, *(rng.randint(25, 100) for _ in range(3))]
    rng.shuffle(scores)
    return (*scores, (a + b + c) // 3)


def _score_partition_valid(mean, **p):
    return any(sum(group) == 3 * mean for group in combinations(p.values(), 3))


pre('train/1080', 'complementary-three-score-mean', 'a b c d e f mean',
    lambda mean, **scores: F(sum(scores.values()), 3) - mean,
    bounds={key: (0, 100) for key in (*'abcdef', 'mean')},
    valid=_score_partition_valid, draw=_score_partition_draw,
    constraint='At least one three-score subset has the stated mean; all scores are from 0 through 100.',
    reference=lambda mean, **p: next(_mean(*(v for i, v in enumerate(p.values()) if i not in indices))
                                     for indices in combinations(range(6), 3)
                                     if sum(list(p.values())[i] for i in indices) == 3 * mean))


def _grade_draw(rng):
    rate = rng.randint(5, 18)
    old, new = rng.sample(range(1, 6), 2)
    return rng.randint(max(rate * old, rate * new), 130), rate * old, old, new


def _grade_valid(cap, score, old, new):
    return old != new and score <= cap and F(score * new, old).denominator == 1 and score * new <= old * cap


pre('train/1096', 'test-score-proportional-to-study', 'cap score old new',
    lambda cap, score, old, new: F(score * new, old),
    bounds={'cap': (10, 150), 'score': (1, 150), 'old': (1, 12), 'new': (1, 12)},
    valid=_grade_valid, draw=_grade_draw,
    constraint='Study times differ and both scores are integral and within the stated test maximum.',
    reference=lambda cap, score, old, new: next(result for result in range(cap + 1)
                                                if F(result, new) == F(score, old)),
    edits=(('3 hours preparing', '3 h preparing'), ('4 hours preparing', '4 h preparing')))


def _egg_basket_choices(red, orange, minimum):
    return [size for size in range(minimum, gcd(red, orange) + 1)
            if red % size == orange % size == 0 and red // size >= 3]


def _egg_draw(rng):
    size = rng.choice((3, 5, 7, 11))
    a = rng.randint(3, 7)
    b = rng.choice([n for n in range(2, 9) if gcd(a, n) == 1])
    return size * a, size * b, rng.randint(2, size)


pre('train/1174', 'unique-common-basket-size', 'red orange minimum',
    lambda red, orange, minimum: _egg_basket_choices(red, orange, minimum)[0],
    valid=lambda red, orange, minimum: len(_egg_basket_choices(red, orange, minimum)) == 1,
    draw=_egg_draw,
    constraint='Exactly one common basket size at or above the minimum leaves no eggs and fills at least three green baskets.',
    reference=lambda red, orange, minimum: next(
        red // baskets for baskets in range(3, red + 1)
        if red % baskets == 0 and red // baskets >= minimum and orange % (red // baskets) == 0))


def _odd_median_draw(rng):
    low = 2 * rng.randint(-15, 50) + 1
    gaps = rng.randint(1, 30)
    return low + gaps, low + 2 * gaps


pre('train/981', 'least-of-consecutive-odd-integers', 'center greatest',
    lambda center, greatest: 2 * center - greatest,
    bounds={'center': (-35, 160), 'greatest': (-30, 190)},
    valid=lambda center, greatest: greatest % 2 == 1 and center < greatest,
    draw=_odd_median_draw,
    constraint='The greatest term is odd and strictly exceeds the median, so at least two terms occur.',
    reference=lambda center, greatest: next(
        low for low in range(2 * center - greatest - 4, greatest, 2)
        if _median(list(range(low, greatest + 1, 2))) == center))


pre('train/1001', 'three-distinct-numbers-with-equal-mean-and-median', 'center minimum',
    lambda center, minimum: 2 * (center - minimum),
    bounds={'center': (-50, 100), 'minimum': (-100, 99)},
    valid=lambda center, minimum: minimum < center,
    draw=lambda rng: tuple(sorted(rng.sample(range(-50, 100), 2), reverse=True)),
    constraint='The minimum is strictly below the common mean and median.',
    reference=lambda center, minimum: next(
        n - minimum for n in range(center + 1, 301) if _mean(minimum, center, n) == center))


pre('train/1203', 'product-of-equal-unknown-observations', 'mean a b',
    lambda mean, a, b: F(4 * mean - a - b, 2)**2,
    bounds={'mean': (-20, 80), 'a': (-20, 80), 'b': (-20, 80)},
    reference=lambda mean, a, b: next(
        F(two_x, 2)**2 for two_x in range(-240, 361) if _mean(a, b, F(two_x, 2), F(two_x, 2)) == mean))


def _blake_draw(rng):
    first_up = rng.randint(2, 20)
    second_down = rng.randint(2, 25)
    late_up = rng.randint(2, 20)
    a = rng.randint(45, 100 - first_up)
    b = rng.randint(second_down, 100)
    c = rng.randint(45, 100 - late_up)
    d = rng.choice([n for n in range(45, 101 - late_up) if (a + b + c + n) % 4 == 0])
    return (a + b + c + d) // 4, first_up, second_down, late_up


def _blake_valid(mean, first_up, second_down, late_up):
    return second_down <= 4 * mean <= 400 - first_up - 2 * late_up


pre('test/61', 'mean-of-four-tests-after-score-changes', '_ mean first_up second_down late_up',
    lambda mean, first_up, second_down, late_up: abs(F(first_up - second_down + 2 * late_up, 4)),
    bounds={'mean': (0, 100), 'first_up': (1, 100), 'second_down': (1, 100), 'late_up': (1, 100)},
    valid=_blake_valid, draw=_blake_draw,
    constraint='Four whole scores from 0 to 100 can attain Blake’s mean and remain in range after Jenny’s changes.',
    reference=lambda mean, first_up, second_down, late_up:
    abs(F(4 * mean + first_up - second_down + 2 * late_up, 4) - mean))


def _pies_range(min_mean, center, mode):
    pair_sum = 5 * min_mean - center - 2 * mode
    low = max(1, pair_sum - center + 1)
    high = (pair_sum - 1) // 2
    return low, high


def _mode_draw(rng):
    center = rng.randint(4, 22)
    a, b = rng.choice(((center - 2, center - 1), (1, 2), (1, 3)))
    mode = rng.choice([m for m in range(center + 1, center + 16) if (a + b + center + 2 * m) % 5 == 0])
    return (a + b + center + 2 * mode) // 5, center, mode


def _mode_unique(mean, center, mode):
    lower, upper = _pies_range(mean, center, mode)
    return mode > center and lower == upper and 1 <= lower < 5 * mean - center - 2 * mode - lower < center


pre('test/773', 'range-from-five-observations-with-unique-mode', 'mean center mode',
    lambda mean, center, mode: mode - _pies_range(mean, center, mode)[0],
    bounds={'mean': (2, 65), 'center': (4, 50), 'mode': (5, 80)},
    valid=_mode_unique, draw=_mode_draw,
    constraint='Mode exceeds the median and exactly one increasing pair below the median can attain the mean.',
    reference=lambda mean, center, mode: next(
        mode - a for a, b in combinations(range(1, center), 2)
        if _mean(a, b, center, mode, mode) == mean),
    edits=(('a set of five positive integers', 'a list of five positive integers'),
           ('integers in the set', 'integers in the list')))


def _shoes_draw(rng):
    shops = rng.randint(3, 14)
    sellers = rng.randint(1, shops - 1)
    old, new = rng.sample(range(2, 9), 2)
    return sellers * old, shops * old, sellers * new


pre('test/802', 'total-mall-size-from-proportional-subset', 'old_sellers old_total new_sellers',
    lambda old_sellers, old_total, new_sellers: F(old_total * new_sellers, old_sellers),
    bounds={'old_sellers': (1, 130), 'old_total': (3, 150), 'new_sellers': (1, 130)},
    valid=lambda old_sellers, old_total, new_sellers:
    old_sellers < old_total and old_sellers != new_sellers and old_total * new_sellers % old_sellers == 0,
    draw=_shoes_draw, constraint='The shoe-store counts differ and are proper integral subgroups of their malls.',
    reference=lambda old_sellers, old_total, new_sellers:
    new_sellers / F(old_sellers, old_total))


pre('test/635', 'sum-of-positive-days-household-percentages', '_ _ a _ _ b _ _ c _ none',
    lambda a, b, c, none: a + b + c,
    bounds={key: (1, 97) for key in ('a', 'b', 'c', 'none')},
    valid=lambda a, b, c, none: a + b + c + none == 100,
    draw=lambda rng: _partition(rng, 100, 4),
    constraint='The four categories are disjoint and their percentages sum to 100.',
    reference=lambda a, b, c, none: 100 - none)


pre('test/692', 'maximum-reordered-team-score', 'sarah matthew james',
    lambda sarah, matthew, james: sarah * james - matthew,
    bounds={'sarah': (1, 25), 'matthew': (-25, -1), 'james': (1, 25)},
    reference=lambda sarah, matthew, james: max(
        values[0] * values[1] - values[2]
        for values in ((sarah, matthew, james), (sarah, james, matthew), (matthew, james, sarah))))


def _square_area_draw(rng):
    return tuple(rng.randint(2, 16)**2 for _ in range(3))


pre('train/1006', 'mean-square-side-length', 'a b c',
    lambda a, b, c: _mean(isqrt(a), isqrt(b), isqrt(c)),
    bounds={key: (1, 400) for key in 'abc'},
    valid=lambda a, b, c: all(isqrt(area)**2 == area for area in (a, b, c)),
    draw=_square_area_draw, constraint='Each area is a perfect square.',
    reference=lambda a, b, c: F(sum(next(x for x in range(1, 21) if x*x == area)
                                    for area in (a, b, c)), 3))


pre('train/836', 'painted-cube-face-probability', 'blue red',
    lambda blue, red: F(blue, blue + red),
    bounds={'blue': (1, 5), 'red': (1, 5)},
    valid=lambda blue, red: blue + red == 6,
    draw=lambda rng: (lambda blue: (blue, 6 - blue))(rng.randint(1, 5)),
    constraint='All six faces are either red or blue, with both colors represented.',
    reference=lambda blue, red: 1 - F(red, 6),
    edits=(('with 4 blue faces and 2 red faces.', 'with 4 faces painted blue and 2 painted red.'),))


pre('train/961', 'missing-jelly-bean-color-probability', 'red:2 orange:2',
    lambda red, orange: F(100 - red - orange, 100),
    bounds={'red': (1, 98), 'orange': (1, 98)},
    valid=lambda red, orange: red + orange < 100,
    draw=lambda rng: _partition(rng, 100, 3)[:2],
    constraint='There are three colors with positive probabilities summing to one.',
    reference=lambda red, orange: F(len(range(red + orange, 100)), 100))


def _exchange_draw(rng):
    namibia = rng.randint(2, 20)
    yuan = rng.randint(2, 15)
    return namibia, yuan, namibia * rng.randint(2, 50)


pre('train/815', 'two-currency-conversions', 'namibia yuan price',
    lambda namibia, yuan, price: F(price * yuan, namibia),
    bounds={'namibia': (1, 25), 'yuan': (1, 25), 'price': (2, 1500)},
    valid=lambda namibia, yuan, price: 100 * price * yuan % namibia == 0,
    draw=_exchange_draw, constraint='The converted price is an integral number of yuan cents.',
    reference=lambda namibia, yuan, price: F(price, namibia) * yuan,
    edits=(('One US dollar is the equivalent of', 'Suppose one US dollar is the equivalent of'),))


pre('train/833', 'approximate-liter-pint-conversion', '_ _ target:1',
    lambda target: F(_rounded(21 * target, 10), 100),
    bounds={'target': [n for n in range(2, 201) if n != 5]},
    reference=lambda target: F((21 * target + 5) // 10, 10),
    edits=(('how many pints are in one liter?', 'how many pints are in a volume of 1 L?'),))


pre('test/165', 'wrong-subtraction-versus-division', 'amount amount wrong amount amount',
    lambda amount, wrong: F(wrong + amount, amount),
    reference=lambda amount, wrong: 1 + F(wrong, amount))


pre('test/608', 'shorter-yarn-piece', 'length multiple',
    lambda length, multiple: F(length, multiple + 1),
    bounds={'length': (5, 200), 'multiple': (2, 12)},
    reference=lambda length, multiple: length - F(length * multiple, multiple + 1),
    edits=(('five times', '5 times'),))


pre('test/427', 'rectangular-garden-shared-side', 'width area',
    lambda width, area: F(area, width),
    bounds={'width': (2, 35), 'area': (20, 500)},
    reference=lambda width, area: F(area, width),
    edits=(('eight feet', '8 feet'),))


pre('test/367', 'equal-area-triangle-legs', 'height base leg',
    lambda height, base, leg: F(height * base, leg),
    bounds={key: (2, 40) for key in ('height', 'base', 'leg')},
    reference=lambda height, base, leg: F(height * base, 2) / F(leg, 2))


def _larger_square_draw(rng):
    old, new = sorted(rng.sample(range(2, 21), 2))
    return old, new**2 - old**2


pre('test/42', 'square-side-after-area-increase', 'side side added',
    lambda side, added: isqrt(side * side + added),
    bounds={'side': (2, 25), 'added': (1, 450)},
    valid=lambda side, added: isqrt(side * side + added)**2 == side * side + added,
    draw=_larger_square_draw, constraint='The expanded square has an integral side length.',
    reference=lambda side, added: next(n for n in range(side + 1, 34) if n*n - side*side == added),
    edits=(('A 2 inch by 2 inch square', 'A square measuring 2 inches by 2 inches'),))


def _rectangular_field_draw(rng):
    m = rng.randint(2, 9)
    n = rng.randint(1, m - 1)
    scale = rng.randint(2, 8)
    return tuple(sorted((scale * (m*m - n*n), scale * 2*m*n)))


pre('test/158', 'field-diagonal-versus-sides', 'width length',
    lambda width, length: width + length - isqrt(width*width + length*length),
    bounds={'width': (2, 1500), 'length': (2, 1500)},
    valid=lambda width, length: width < length and isqrt(width*width + length*length)**2 == width*width + length*length,
    draw=_rectangular_field_draw, constraint='Length exceeds width and the diagonal is a whole number of feet.',
    reference=lambda width, length: next(width + length - walk for walk in range(length + 1, width + length)
                                         if walk*walk - width*width == length*length))


def _tiling_draw(rng):
    feet = rng.randint(1, 6)
    size = rng.choice([d for d in range(2, 13) if 12 * feet % d == 0])
    return size, feet


pre('test/172', 'square-area-tiled-with-whole-tiles', 'tile feet feet',
    lambda tile, feet: (12 * feet // tile)**2,
    bounds={'tile': (2, 24), 'feet': (1, 12)},
    valid=lambda tile, feet: 12 * feet % tile == 0,
    draw=_tiling_draw, constraint='The room side in inches is divisible by the tile side.',
    reference=lambda tile, feet: len(list(product(range(0, feet * 12, tile), repeat=2))))


def _mixed_draw(rng):
    num, den = _fraction_draw(rng)
    return rng.randint(2, 8), num, den


def _mixed_valid(whole, num, den):
    return num < den


pre('test/469 test/660', 'mixed-yards-to-inches', 'whole num den',
    lambda whole, num, den: 36 * (whole + F(num, den)),
    bounds={'whole': (1, 12), 'num': (1, 20), 'den': (2, 20)},
    valid=_mixed_valid, draw=_mixed_draw, constraint='The fractional part is proper.',
    reference=lambda whole, num, den: 36 * whole + 3 * F(12 * num, den))


pre('test/99', 'mixed-gallons-to-pints', 'whole num den',
    lambda whole, num, den: 8 * (whole + F(num, den)),
    bounds={'whole': (1, 12), 'num': (1, 20), 'den': (2, 20)},
    valid=_mixed_valid, draw=_mixed_draw, constraint='The fractional part is proper.',
    reference=lambda whole, num, den: 2 * (4 * whole + F(4 * num, den)))


pre('test/861', 'area-covered-by-rectangular-pictures', 'count width height',
    lambda count, width, height: count * width * height,
    bounds={'count': (2, 30), 'width': (2, 18), 'height': (2, 20)},
    reference=lambda count, width, height: sum(width * height for _ in range(count)),
    edits=(('Eleven rectangular', '11 rectangular'), ('pictures hang', 'pictures hang without overlap')))


pre('test/867', 'minimum-distance-with-known-two-legs', 'a b',
    lambda a, b: abs(a - b),
    valid=lambda a, b: a != b, draw=lambda rng: tuple(rng.sample(range(2, 61), 2)),
    constraint='The given lengths differ so the minimum is positive.',
    reference=lambda a, b: min(abs(x) for x in (a + b, a - b, b - a, -a - b)))


def _apple_picking_draw(rng):
    hours = rng.randint(3, 10)
    return hours * rng.randint(500, 2000), hours, rng.randint(2, hours - 1)


pre('test/67', 'apple-picking-part-of-time', 'weight hours partial',
    lambda weight, hours, partial: F(weight * partial, hours),
    bounds={'weight': (1500, 21000), 'hours': (3, 14), 'partial': (2, 13)},
    valid=lambda weight, hours, partial: partial < hours,
    draw=_apple_picking_draw, constraint='The queried time is shorter than the full picking time.',
    reference=lambda weight, hours, partial: F(weight, hours) * partial,
    edits=(('For a world record, George Adrian', 'In a timed apple-picking event, George'),))


def _mistake_draw(rng):
    a = rng.randint(2, 30)
    b = a + rng.randint(2, 15)
    return b - a, a * b


def _addition_from_mistakes(difference, product):
    return isqrt(difference*difference + 4*product)


alg('train/1118', 'sum-from-difference-and-product', 'difference product', _addition_from_mistakes,
    bounds={'difference': (1, 30), 'product': (2, 1500)},
    valid=lambda difference, product: _addition_from_mistakes(difference, product)**2 == difference*difference + 4*product,
    draw=_mistake_draw, constraint='The discriminant is square and both integers are positive.',
    reference=lambda difference, product: next(
        2*n + difference for n in range(1, isqrt(product) + 1) if n * (n + difference) == product))


alg('train/1176', 'minimum-sugar-from-flour-inequalities', 'gap num den upper',
    lambda gap, num, den, upper: F(gap, upper - F(num, den)),
    bounds={'gap': (2, 25), 'num': (1, 20), 'den': (2, 20), 'upper': (2, 10)},
    valid=lambda gap, num, den, upper: num < den,
    draw=lambda rng: (rng.randint(2, 25), *_fraction_draw(rng), rng.randint(2, 8)),
    constraint='The lower linear coefficient is proper and the upper coefficient is at least two.',
    reference=lambda gap, num, den, upper: F(gap * den, upper * den - num),
    edits=(('half the amount', '1/2 of the amount'), ('twice the amount', '2 times the amount')))


def _bus_fraction_draw(rng):
    den = rng.randint(2, 4)
    num = rng.randint(1, den - 1)
    stops = rng.randint(2, 3)
    return den**stops * rng.randint(1, 96 // den**stops), num, den, stops


def _bus_remain(total, num, den, stops):
    return total * F(den - num, den)**stops


_special('algebra/train/1500', 'successive-school-bus-departures',
         dict(total=48, num=1, den=2, stops=3),
         {'total': (4, 120), 'num': (1, 6), 'den': (2, 7), 'stops': (2, 6)},
         lambda total, num, den, stops: f'A school bus starts with {total} students. At each of its first {stops} '
         f'stops, {num}/{den} of the students still on board get off. How many remain after these stops?',
         _bus_remain, _bus_fraction_draw,
         valid=lambda total, num, den, stops: num < den and _bus_remain(total, num, den, stops).denominator == 1,
         constraint='The departure fraction is proper. The reduced remaining fraction to the stated power gives a whole student count at every stop.',
         reference=lambda total, num, den, stops: (lambda step: next(
             end for end in range(1, total + 1) if end * step.denominator**stops == total * step.numerator**stops))(
                 F(den - num, den)),
         adaptation='The number of stops and fraction who get off vary, with the fraction tied across all stops.')


alg('train/1726', 'combined-weight-and-relative-difference', 'total _ den',
    lambda total, den: F(den * total, 2 * den - 1),
    bounds={'total': (80, 400), 'den': (2, 9)},
    reference=lambda total, den: F(total, 2 - F(1, den)),
    edits=(('half of Bob', '1/2 of Bob'),))


def _friend_meal_draw(rng):
    a, b = sorted(rng.sample(range(2, 8), 2))
    multiple = rng.randint(1, 4)
    return a * b * multiple, b*b * multiple


alg('test/361', 'whole-shared-meals-from-serving-ratio', 'people covered people',
    lambda people, covered: F(people**2, covered),
    bounds={'people': (2, 180), 'covered': (3, 200)},
    valid=lambda people, covered: covered > people and people**2 % covered == 0,
    draw=_friend_meal_draw, constraint='The original meals feed more than the party and the party needs a whole number of meals.',
    reference=lambda people, covered: F(people, F(covered, people)),
    edits=(('Twelve friends', '12 friends'),))


def _orange_draw(rng):
    old, new = sorted(rng.sample(range(2, 10), 2))
    return (new // gcd(old, new)) * rng.randint(2, 14), old, new


alg('test/485', 'item-count-after-price-increase', 'count old new',
    lambda count, old, new: F(count * old, new),
    bounds={'count': (2, 150), 'old': (2, 12), 'new': (3, 15)},
    valid=lambda count, old, new: old < new and count * old % new == 0,
    draw=_orange_draw, constraint='The price rises and the fixed budget is an exact multiple of the new price.',
    reference=lambda count, old, new: next(n for n in range(1, count) if n * new == count * old))


def _capture_draw(rng):
    whole, num, den = _mixed_draw(rng)
    return den * rng.randint(1, 4), whole, num, den


alg('test/497', 'whole-count-from-mixed-duration', 'rate whole num den',
    lambda rate, whole, num, den: rate * (whole + F(num, den)),
    bounds={'rate': (2, 85), 'whole': (1, 12), 'num': (1, 20), 'den': (2, 20)},
    valid=lambda rate, whole, num, den: num < den and rate * num % den == 0,
    draw=_capture_draw, constraint='The fractional hour is proper and total captures are integral.',
    reference=lambda rate, whole, num, den: rate * whole + F(rate * num, den))


alg('test/921', 'party-cost-after-two-multipliers', '_ _ price_factor people_factor _ _',
    lambda price_factor, people_factor: F(1, price_factor * people_factor),
    bounds={'price_factor': (2, 12), 'people_factor': (2, 12)},
    reference=lambda price_factor, people_factor: F(10 * 30, price_factor * 10 * people_factor * 30),
    edits=(('cost per person doubled', 'cost per person became 2 times its previous value'),
           ('number of people attending the party also doubled',
            'number of people attending the party became 2 times its previous value')))


alg('test/943', 'mean-with-two-relative-offsets', 'mean lower upper',
    lambda mean, lower, upper: mean + F(lower + 2 * upper, 3),
    bounds={'mean': (-50, 80), 'lower': (1, 40), 'upper': (1, 40)},
    reference=lambda mean, lower, upper: F(3 * mean + lower - upper, 3) + upper,
    edits=(('six less than', '6 less than'), ('three more than', '3 more than')))


def _groom_draw(rng):
    den = rng.randint(2, 5)
    bride = den * rng.randint(_ceil_div(18, den), 44 // den)
    groom = rng.randint(max(18, bride // den + 1), 48)
    return groom - bride // den, den, bride + groom


def _groom_age(extra, den, total):
    return F(total + den * extra, den + 1)


def _wedding_valid(extra, den, total):
    groom = _groom_age(extra, den, total)
    return groom.denominator == 1 and 18 <= groom <= 80 and 18 <= total - groom <= 80


alg('test/1133', 'adult-ages-from-sum-and-affine-ratio', 'extra _ den total',
    _groom_age,
    bounds={'extra': (1, 70), 'den': (2, 9), 'total': (36, 160)},
    valid=_wedding_valid, draw=_groom_draw,
    constraint='The bride and groom both have integral ages from 18 through 80.',
    reference=lambda extra, den, total: next(groom for groom in range(18, 81)
                                              if groom == extra + F(total - groom, den)),
    edits=(('fifteen years more', '15 years more'), ('half the bride', '1/2 of the bride')))


def _reversed_age_draw(rng):
    tens = rng.randint(4, 8)
    units = rng.randint(max(1, tens - 6), tens - 2)
    return 9 * (tens - units), tens + units


def _reverse_digits_valid(difference, digit_sum):
    delta, remainder = divmod(difference, 9)
    return not remainder and (digit_sum + delta) % 2 == 0 and 1 <= (digit_sum - delta) // 2 < (digit_sum + delta) // 2 <= 9


alg('test/1141', 'father-age-from-reversed-digits', 'difference digit_sum',
    lambda difference, digit_sum: (11 * digit_sum + difference) // 2,
    bounds={'difference': (18, 72), 'digit_sum': (3, 17)},
    valid=_reverse_digits_valid, draw=_reversed_age_draw,
    constraint='The difference and sum determine two nonzero digits, with father at least 18 years older.',
    reference=lambda difference, digit_sum: next(
        n for n in range(11, 100) if '0' not in str(n) and sum(map(int, str(n))) == digit_sum
        and n - int(str(n)[::-1]) == difference))


_special('prealgebra/test/662', 'simultaneous-backups', dict(interval_a=5, interval_b=2, hours=24),
         {'interval_a': (2, 35), 'interval_b': (2, 35), 'hours': (2, 72)},
         lambda interval_a, interval_b, hours: f'Two computers count time from the start of a {hours}-hour period. '
         f'One backs up every {interval_a} minutes and the other every {interval_b} minutes. Neither backs up at '
         'the start. How many times do they back up simultaneously during the period, including its end?',
         lambda interval_a, interval_b, hours: 60 * hours // lcm(interval_a, interval_b),
         lambda rng: (*rng.sample(range(2, 31), 2), rng.randint(2, 72)),
         valid=lambda interval_a, interval_b, hours: interval_a != interval_b,
         constraint='The two periods differ, start from the same time origin, and omit the initial simultaneous event.',
         reference=lambda interval_a, interval_b, hours: len(
             set(range(interval_a, 60 * hours + 1, interval_a)) & set(range(interval_b, 60 * hours + 1, interval_b))),
         adaptation='Both backup intervals are variable; the original first and final endpoint conventions are explicit.')


_special('prealgebra/train/534', 'sample-mean',
         dict(counts=[8, 10, 12, 15, 16, 17, 20]),
         {'counts': {'type': 'list[int]', 'min_length': 3, 'max_length': 14, 'items': _int_domain(1, 50)}},
         lambda counts: f'Billy opens {len(counts)} packages and counts the cookies in each. The counts are '
         + ', '.join(map(str, counts)) + '. What is the average number of cookies per package?',
         lambda counts: _mean(*counts), lambda rng: ([rng.randint(2, 50) for _ in range(rng.randint(3, 14))],),
         adaptation='The package count is derived from the length of the list of cookie counts.')


_special('prealgebra/train/626', 'sample-median',
         dict(scores=[6, 18, 15, 14, 19, 12, 19, 15]),
         {'scores': {'type': 'list[int]', 'min_length': 3, 'max_length': 14, 'items': _int_domain(0, 35)}},
         lambda scores: f'A basketball player’s counts of successful free throws in {len(scores)} successive '
         'games are ' + ', '.join(map(str, scores)) + '. What is the median number of successful free throws?',
         lambda scores: _median(scores), lambda rng: ([rng.randint(0, 35) for _ in range(rng.randint(3, 14))],),
         reference=lambda scores: F(sum(
             next(value for value in range(36) if sum(score <= value for score in scores) >= rank)
             for rank in ((len(scores) + 1) // 2, len(scores) // 2 + 1)), 2),
         adaptation='The sample size varies and is derived from the list. Equal values remain valid observations.')
