"""Place values and numbers; exact source-bound mathematical models."""

from functools import lru_cache, partial
from itertools import permutations
from math import factorial, gcd, isqrt, lcm, prod
from template_dataset.families.word_problems.decimal_arithmetic import PRE, add, ceildiv, factors, is_prime, listed, prime_factors

CASES={}
pre=partial(add,CASES,PRE)


def only(search,*args):
    return search(*args)[0]


def unique(search,*args):
    return len(search(*args))==1


def witness_interval(r,search,extra,low,high,closed=False):
    candidates=search(low,high,*extra)
    j=r.randrange(len(candidates))
    n=candidates[j]
    lo=(candidates[j-1]+closed) if j else low
    hi=(candidates[j+1]-closed) if j+1<len(candidates) else high
    return r.randint(lo,n-1+closed),r.randint(n+1-closed,hi),*extra


def both_multiples(lo,hi,a,b):
    d=lcm(a,b)
    return list(range((lo//d+1)*d,hi,d))


def draw_both(r):
    a,b=r.randint(8,125),r.randint(8,125)
    d=lcm(a,b)
    n=d*r.randint(2,6)
    return n-r.randint(1,d),n+r.randint(1,d),a,b


pre('train/126','multiple-in-interval',
    dict(lower=(800,1,110000),upper=(2000,2,110000),factor=(125,2,125),multiple=(30,2,125)),
    'John is thinking of a number. It has {factor} as a factor, is a multiple of {multiple}, and is strictly between {lower} and {upper}. What is the number?',
    partial(only,both_multiples),check=partial(unique,both_multiples),draw=draw_both,
    constraint='The open interval contains exactly one common multiple.')


def penny_array(lo,hi,k,a):
    return [n for n in range(lo+1,hi) if (len(factors(n))+1)//2==k and is_prime(n+a)]


@lru_cache(maxsize=1)
def penny_pool():
    return [(k,a) for k in range(2,6) for a in range(1,11) if penny_array(8,451,k,a)]


def twin(lo,hi,a):
    return [n for n in range(lo+1,hi) if is_prime(n) and is_prime(n+a)]


def primes_closed(lo,hi):
    return [n for n in range(lo,hi+1) if is_prime(n)]


def multiple_except(lo,hi,a,b):
    return [n for n in range(lo+1,hi) if n%a==0 and n%b!=0]


def square_interval(lo,hi,d):
    return [k*k for k in range(isqrt(lo)+1,isqrt(max(0,hi-1))+1) if k*k%d==0]


def gcd_interval(lo,hi,a,g):
    return [n for n in range(lo+1,hi) if gcd(n,a)==g]


for suffix,fields,text,search,draw,description in (
    ('test/420',dict(lower=(40,8,450),upper=(50,9,451),layouts=(3,2,6),extra=(2,1,16)),
     'Betty has strictly between {lower} and {upper} pennies. They form a rectangular array in exactly {layouts} ways, counting rotations only once. If she adds {extra} pennies, the new total can only form a straight line. How many pennies did she originally have?',
     penny_array,lambda r:witness_interval(r,penny_array,r.choice(penny_pool()),8,451),
     'Exactly one count has the stated number of factor pairs and becomes prime after adding the extra pennies.'),
    ('test/769',dict(lower=(30,6,450),upper=(50,7,451),extra=(2,1,12)),
     'An archery class has strictly between {lower} and {upper} students. It is impossible to split them into at least two equal groups with at least two in each group. The same is true if {extra} instructors join. How many students are in the class?',
     twin,lambda r:witness_interval(r,twin,(r.choice((2,4,6,8,10,12)),),6,451),
     'Exactly one count is prime and remains prime after adding the instructors.'),
    ('test/489',dict(lower=(20,8,350),upper=(28,8,350)),
     'Jon has at least {lower} and at most {upper} students. They can fill a rectangular grid with no gaps only if the grid is a single straight line. How many students are there?',
     primes_closed,lambda r:witness_interval(r,primes_closed,(),8,350,closed=True),
     'The closed interval contains exactly one prime.'),
    ('test/812',dict(lower=(20,2,224),upper=(30,3,225),required=(7,2,22),excluded=(3,2,25)),
     'What number strictly between {lower} and {upper} is a multiple of {required}, but not a multiple of {excluded}?',
     multiple_except,lambda r:witness_interval(r,multiple_except,(r.randint(2,22),r.choice((23,25))),2,225),
     'Exactly one integer in the open interval is a multiple of the required divisor but not the excluded divisor.'),
    ('train/601',dict(lower=(39,0,800),upper=(80,1,900),divisor=(4,2,40)),
     'Find the perfect square divisible by {divisor} and strictly between {lower} and {upper}.',
     square_interval,lambda r:witness_interval(r,square_interval,(r.randint(2,28),),1,900),
     'The open interval contains exactly one perfect square divisible by the given divisor.'),
    ('train/835',dict(lower=(50,1,219),upper=(60,2,220),given=(21,2,150),gcd=(7,1,150)),
     'The greatest common divisor of {given} and a number strictly between {lower} and {upper} is {gcd}. What is the number?',
     gcd_interval,lambda r:draw_gcd(r),
     'Exactly one integer in the open interval has the specified greatest common divisor.'),
):
    pre(suffix,'unique-integer-in-interval',fields,text,partial(only,search),
        check=partial(unique,search),draw=draw,constraint=description,
        adaptation=('Explicitly excluded singleton groups and a single group.' if suffix=='test/769' else ''))


def draw_gcd(r):
    a,n=r.randint(10,150),r.randint(20,190)
    return witness_interval(r,gcd_interval,(a,gcd(a,n)),1,220)


def primes_after(lo,k):
    result=[]
    while len(result)<k:
        lo+=1
        if is_prime(lo):
            result.append(lo)
    return result


for suffix,fields,text,solve in (
    ('train/71',dict(index=(2,2,12)),'What is the cube of the square of the prime in position {index} when primes are listed in increasing order?',lambda k:primes_after(1,k)[-1]**6),
    ('train/559',dict(count=(5,2,12)),'What is the remainder when the sum of the first {count} primes is divided by the next prime?',lambda k:sum(primes_after(1,k))%primes_after(1,k+1)[-1]),
    ('train/891',dict(count=(4,2,12)),'What is the least positive integer divisible by {count} distinct primes?',lambda k:prod(primes_after(1,k))),
    ('train/882',dict(lower=(20,3,130),count=(2,2,5)),'What is the least possible product of {count} distinct primes, each strictly greater than {lower}?',lambda lo,k:prod(primes_after(lo,k))),
    ('test/221',dict(count=(5,2,10),divisor=(42,3,120)),'What is the remainder when the product of the {count} smallest primes is divided by {divisor}?',lambda k,d:prod(primes_after(1,k))%d),
    ('test/664',dict(count=(2,2,4),digits=(3,1,4)),'Let n be the product of the {count} smallest {digits}-digit primes. Find the sum of the digits of n.',lambda k,d:sum(map(int,str(prod(primes_after(10**(d-1)-1,k)))))),
    ('test/471',dict(first=(1,1,4),second=(2,1,4)),'What is the smallest product of {first} distinct one-digit primes and {second} distinct two-digit primes?',lambda a,b:prod(primes_after(1,a))*prod(primes_after(9,b))),
):
    pre(suffix,'ordered-primes',fields,text,solve)


for suffix,lo,hi,p in [('train/1084',1,10,True),('train/1111',10,20,True),('test/757',10,20,False)]:
    pre(suffix,'prime-or-composite-sum',dict(lower=(lo,1,120),upper=(hi,2,180)),
        'What is the sum of all '+('prime' if p else 'composite')+' numbers strictly between {lower} and {upper}?',
        lambda a,b,p=p:sum(n for n in range(max(2,a+1),b) if is_prime(n)==p),
        check=lambda a,b:a<b,draw=lambda r:(lambda a:(a,a+r.randint(6,55)))(r.randint(1,120)),
        constraint='The endpoints are increasing.')


pre('test/135','prime-difference',dict(difference=(17,1,97)),
    'Two prime numbers have positive difference {difference}. What is their sum?',
    lambda d:d+4,check=lambda d:d%2==1 and is_prime(d+2),
    draw=lambda r:(r.choice([p-2 for p in primes_closed(3,99)]),),
    reference=lambda d:next(2*a+d for a in range(2,d+3) if is_prime(a) and is_prime(a+d)),
    constraint='The difference is odd and two more than the difference is prime, so the smaller prime must be 2.')


for suffix,a,b,query,op in (
    ('train/208',50,15,'sum of the positive common divisors',sum),
    ('test/428',14,42,'number of positive common divisors',len),
    ('test/567',100,150,'number of positive two-digit common divisors',lambda xs:sum(10<=x<100 for x in xs)),
):
    pre(suffix,'common-divisors',dict(first=(a,4,250),second=(b,4,250)),
        'What is the '+query+' of {first} and {second}?',
        lambda a,b,op=op:op(factors(gcd(a,b))),
        reference=lambda a,b,op=op:op([n for n in range(1,min(a,b)+1) if a%n==0 and b%n==0]))


pre('train/1128','bounded-common-divisor',dict(first=(372,20,520),second=(72,12,400),limit=(50,2,150)),
    'What is the greatest positive divisor shared by {first} and {second} that is strictly smaller than {limit}?',
    lambda a,b,m:max(x for x in factors(gcd(a,b)) if x<m),
    reference=lambda a,b,m:next(x for x in range(m-1,0,-1) if a%x==0 and b%x==0))


def draw_common_prime(r):
    p=r.choice(primes_closed(2,23))
    return p*r.randint(2,10),p*r.choice((1,11))


pre('test/53','unique-common-divisor',dict(first=(9,2,300),second=(12,2,300)),
    'A positive integer other than 1 divides both {first} and {second}. What is that integer?',
    gcd,check=lambda a,b:is_prime(gcd(a,b)),draw=draw_common_prime,
    constraint='The greatest common divisor is prime, so exactly one common divisor other than 1 exists.')


for suffix,fields,text,solve,ref in (
    ('test/687',dict(n=(10,3,240)),'Find the product of the positive divisors of {n}.',lambda n:prod(factors(n)),lambda n:prod(k for k in range(1,n+1) if n%k==0)),
    ('train/483',dict(n=(24,3,240)),'What is the least positive integer that has every prime factor of {n} as a prime factor?',lambda n:prod(prime_factors(n)),None),
    ('test/378',dict(a=(117,4,360),b=(119,4,360)),'How many distinct prime factors does the product of {a} and {b} have?',lambda a,b:len(set(prime_factors(a))|set(prime_factors(b))),lambda a,b:len(prime_factors(a*b))),
    ('train/910',dict(a=(4,2,40),b=(14,2,55)),'Find the least positive integer that is a multiple of both {a} and {b}.',lcm,lambda a,b:next(x for x in range(a,a*b+1,a) if x%b==0)),
    ('train/907',dict(a=(2,2,20),b=(3,2,20)),'What is the least positive perfect square divisible by both {a} and {b}?',lambda a,b:next(k*k for k in range(1,lcm(a,b)+1) if k*k%lcm(a,b)==0),None),
    ('test/373',dict(k=(4,2,11)),'What is the least positive integer divisible by each of the {k} smallest positive odd integers?',lambda k:lcm(*range(1,2*k,2)),None),
    ('train/680',dict(a=(5,2,15),b=(7,2,15)),'What is the greatest common divisor of {a}! and {b}!?',lambda a,b:factorial(min(a,b)),lambda a,b:gcd(factorial(a),factorial(b))),
    ('test/717',dict(n=(5,2,18)),'What is the greatest odd integer that is a factor of {n}!?',lambda n:(lambda f:f//(f&-f))(factorial(n)),lambda n:prod(k//(k&-k) for k in range(1,n+1))),
):
    pre(suffix,'factors-and-multiples',fields,text,solve,reference=ref)


pre('test/515','largest-factorial-prime',dict(bound=(100,8,150),n=(97,5,149)),
    '{n} is the largest prime below {bound}. What is the largest prime factor of {n}!?',
    lambda b,n:n,check=lambda b,n:n==max(primes_closed(2,b-1)),
    draw=lambda r:(lambda b:(b,max(primes_closed(2,b-1))))(r.randint(8,150)),
    constraint='The factorial argument is the largest prime below the bound.')


for suffix,lo,hi,p,odd in [('train/1153',20,150,2,False),('train/1157',100,900,3,False),('test/676',5,211,2,True)]:
    pre(suffix,'perfect-powers-in-interval',dict(lower=(lo,1,400),upper=(hi,2,1800)),
        'How many '+('odd ' if odd else '')+'perfect '+('squares' if p==2 else 'cubes')+' are strictly between {lower} and {upper}?',
        lambda a,b,p=p,o=odd:sum(a<k**p<b and (not o or k%2) for k in range(1,b)),
        check=lambda a,b:a<b,draw=lambda r:(lambda a:(a,a+r.randint(20,700)))(r.randint(1,400)),
        constraint='The endpoints are increasing.')


for suffix,n in [('train/766',87),('test/126',17),('test/280',2004)]:
    pre(suffix,'nth-positive-odd',dict(index=(n,2,3000)),
        'What is the positive odd integer in position {index}, when the positive odd integers are listed in increasing order?',
        lambda n:2*n-1)


pre('train/1063','multiples-exclusion-count',dict(limit=(250,15,650),a=(5,2,15),b=(10,2,25)),
    'How many positive integers less than {limit} are multiples of {a}, but are not multiples of {b}?',
    lambda n,a,b:(n-1)//a-(n-1)//lcm(a,b),
    reference=lambda n,a,b:sum(x%a==0 and x%b!=0 for x in range(1,n)))


for suffix,fields,statement,solve in (
    ('test/746',dict(a=(7,1,30),b=(13,1,30)),'If $a={a}$ and $b={b}$, how many positive even integers are strictly less than $ab$?',lambda a,b:(a*b-1)//2),
    ('test/588',dict(first_count=(20,2,55),first_base=(3,2,20),second_count=(10,2,55),second_base=(6,2,20)),
     'Enrico lists the first {first_count} positive multiples of {first_base}. Marie lists the first {second_count} positive multiples of {second_base}. How many numbers are on both lists?',lambda n,a,m,b:min(n*a,m*b)//lcm(a,b)),
    ('test/108',dict(digits=(3,2,10)),'How many positive integers have exactly {digits} decimal digits?',lambda n:9*10**(n-1)),
    ('train/258',dict(length=(4,2,10),first=(2,1,9)),'How many positive {length}-digit integers have leading digit {first}?',lambda n,d:10**(n-1)),
    ('train/492',dict(a=(25,2,3000),b=(240,2,3000)),'How many trailing zeroes does the integer product of {a} and {b} have?',lambda a,b:len(str(a*b))-len(str(a*b).rstrip('0'))),
    ('train/1121',dict(divisor=(5,2,50)),'Erich likes positive integers divisible by {divisor}. How many different last digits can occur among the numbers Erich likes?',lambda n:10//gcd(10,n)),
    ('test/228',dict(sum=(7,1,18)),'How many two-digit positive integers have digits that sum to {sum}?',lambda s:max(0,min(9,s)-max(1,s-9)+1)),
    ('test/526',dict(ratio=(4,2,9)),'What is the sum of the positive two-digit integers in which one digit is {ratio} times the other?',lambda r:11*(r+1)*sum(range(1,9//r+1))),
    ('test/727',dict(limit=(200,35,450),digit=(2,0,9),divisor=(4,2,12)),'How many positive integers from 1 through {limit} have units digit {digit} and are divisible by {divisor}?',lambda n,d,m:sum(k%m==0 for k in range(d or 10,n+1,10))),
):
    pre(suffix,'integer-and-digit-counts',fields,statement,solve)


for suffix,a,b,text,solve,low,high in (
    ('train/1101',202,405,'How many even integers are strictly between {lower} and {upper}?',lambda a,b:(b-1)//2-a//2,0,1000),
    ('test/364',2000,8000,'How many four-digit positive integers are strictly between {lower} and {upper}?',lambda a,b:b-a-1,1000,9999),
):
    pre(suffix,'count-open-interval',dict(lower=(a,low,high-1),upper=(b,low+1,high)),
        text,solve,check=lambda a,b:a<b,
        draw=lambda r,lo=low,hi=high:(lambda a:(a,r.randint(a+1,hi)))(r.randint(lo,hi-1)),
        constraint='The endpoints are increasing.')


def long_division_digit(n,d,k):
    rem=n%d
    for _ in range(k):
        digit,rem=divmod(10*rem,d)
    return digit


for suffix,n,d,k in (('train/820',4,7,125),('train/973',5,33,92),('train/1124',13,90,100),('test/710',4,15,1000)):
    pre(suffix,'decimal-digit',dict(n=(n,1,120),d=(d,2,160),position=(k,1,2000)),
        r'What digit is in position {position} to the right of the decimal point in the decimal expansion of $\frac{{{n}}}{{{d}}}$?',
        lambda n,d,k:10*((n*pow(10,k-1,d))%d)//d,reference=long_division_digit)


pre('train/911','greatest-digit-product',dict(product=(8,1,81)),
    'What is the greatest two-digit positive integer whose digits have product {product}?',
    lambda p:next(n for n in range(99,9,-1) if n//10*(n%10)==p),
    check=lambda p:any(p%x==0 and 1<=p//x<=9 for x in range(1,10)),
    draw=lambda r:(r.randint(1,9)*r.randint(1,9),),
    constraint='At least one two-digit integer has the required digit product.')


def middle_candidates(u,h,d):
    return [100*h+10*k+u for k in range(10) if (100*h+10*k+u)%d==0]


pre('train/876','middle-digit',
    dict(units=(2,0,9),hundreds=(4,1,9),divisor=(9,8,13)),
    'What three-digit number with units digit {units} and hundreds digit {hundreds} is divisible by {divisor}?',
    partial(only,middle_candidates),check=partial(unique,middle_candidates),
    draw=lambda r:r.choice([(u,h,d) for u in range(10) for h in range(1,10) for d in range(8,14) if unique(middle_candidates,u,h,d)]),
    constraint='Exactly one possible middle digit produces a multiple.')


def substitutions(pattern,divisor):
    return [d for d in range(10) if int(pattern.replace('X',str(d)))%divisor==0]


def digit_template(suffix,pattern,divisor,mode):
    choices=(7,8,9,11,13) if mode=='unique' else (3,6,7,9)
    originals=[int(c) for c in pattern if c!='X']

    def compose(ds):
        it=iter(ds)
        return ''.join('X' if c=='X' else str(next(it)) for c in pattern)

    def possibilities(ds,d):
        return substitutions(compose(ds),d)

    def valid(ds,d):
        xs=possibilities(ds,d)
        return ds[0]>0 and (len(xs)==1 if mode=='unique' else len(xs)>=2)

    def draw(r):
        for _ in range(100):
            ds=[r.randint(1,9)]+[r.randint(0,9) for _ in originals[1:]]
            d=r.choice(choices)
            if valid(ds,d):
                return ds,d
        return originals,divisor

    def render(ds,d):
        phrase={'unique':'What digit can replace X','sum':'What is the sum of all digits that can replace X',
                'product':'What is the product of all digits that can replace X'}[mode]
        return f'{phrase} in {compose(ds)} so that the result is divisible by {d}?'

    op={'unique':lambda xs:xs[0],'sum':sum,'product':prod}[mode]
    pre(suffix,'unknown-digit-divisibility',dict(digits=listed(originals,0,9),divisor=(divisor,2,13)),
        render,lambda ds,d:op(possibilities(ds,d)),check=valid,draw=draw,
        constraint='The leading digit is nonzero; '+('exactly one replacement works.' if mode=='unique' else 'at least two replacements work.'))


for suffix,pattern,divisor,mode in (
    ('train/475','3XX1',9,'unique'),('train/964','83X5',9,'unique'),
    ('train/1181','246X8',9,'unique'),('train/1052','24X38',6,'sum'),
    ('test/275','3414X7',3,'product'),('test/497','42789X37',3,'sum'),
):
    digit_template(suffix,pattern,divisor,mode)


def least_palindrome(n,d):
    for k in range(10**((n-1)//2),10**((n+1)//2)):
        s=str(k)
        x=int(s+(s[:-1] if n%2 else s)[::-1])
        if x%d==0:
            return x


def least_repdigit(n,d):
    k=int('1'*n)
    return next((k*j for j in range(1,10) if k*j%d==0),None)


for suffix,n,d,low,high,largest,text,fn in (
    ('train/1002',4,4,3,6,15,'What is the smallest positive {length}-digit palindrome divisible by {divisor}? A palindrome reads the same in both directions.',least_palindrome),
    ('test/818',3,9,2,9,20,'What is the smallest positive {length}-digit integer with every digit equal that is divisible by {divisor}?',least_repdigit),
):
    pre(suffix,'repeated-digit-multiple',dict(length=(n,low,high),divisor=(d,2,largest)),text,fn,
        check=lambda n,d,fn=fn:fn(n,d) is not None,
        draw=lambda r,fn=fn,lo=low,hi=high,m=largest:r.choice([(n,d) for n in range(lo,hi+1) for d in range(2,m+1) if fn(n,d) is not None]),
        constraint='A number of the given length and digit pattern satisfies the divisibility requirement.')


def min_digit_multiple(ds,d):
    for p in permutations(sorted(ds)):
        if p[0]:
            v=int(''.join(map(str,p)))
            if v%d==0:
                return v


def draw_digit_multiple(r):
    for _ in range(100):
        ds,d=sorted(r.sample(range(10),r.randint(3,6))),r.randint(2,18)
        if min_digit_multiple(ds,d) is not None:
            return ds,d
    return [0,2,5],2


pre('train/809','least-digit-permutation-multiple',
    dict(digits=listed([1,2,3,4,5],0,9,min_len=3,max_len=6),divisor=(6,2,18)),
    lambda ds,d:f'Luna writes all {len(ds)}-digit integers using each digit from '+', '.join(map(str,ds))+f' once. What is the least number in her list divisible by {d}?',
    min_digit_multiple,check=lambda ds,d:len(set(ds))==len(ds) and min_digit_multiple(ds,d) is not None,
    draw=draw_digit_multiple,
    constraint='The digits are distinct, no leading zero is allowed, and at least one permutation is divisible by the divisor.')


def draw_nonmultiple(r):
    d=r.randint(3,16)
    values=[d*k for k in r.sample(range(ceildiv(1000,d),9999//d+1),4)]
    values.append(d*r.randint(ceildiv(1000,d),9999//d-1)+r.randint(1,d-1))
    r.shuffle(values)
    return values,d


pre('train/711','one-nonmultiple',dict(numbers=listed([3544,3554,3564,3572,3576],1000,9999),divisor=(4,3,16)),
    lambda xs,d:'Exactly one of '+', '.join(map(str,xs))+f' is not divisible by {d}. What is the product of that number’s tens digit and units digit?',
    lambda xs,d:(lambda x:x//10%10*(x%10))(next(x for x in xs if x%d)),
    check=lambda xs,d:len(set(xs))==len(xs) and sum(x%d!=0 for x in xs)==1,draw=draw_nonmultiple,
    constraint='The five numbers are distinct and exactly one is not a multiple.')
