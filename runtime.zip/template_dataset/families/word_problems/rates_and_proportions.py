"""Rates and proportions; exact source-bound mathematical models."""

from fractions import Fraction as F
from functools import partial
from math import isqrt
from template_dataset.families.word_problems.decimal_arithmetic import ALG, add, ceildiv, decimal, rounded

CASES={}
alg=partial(add,CASES,ALG)


def invest(initial,years,rate):
    return F(initial)*F(100+rate,100)**years


def principal(years,rate,balance):
    return F(balance)/F(100+rate,100)**years


def draw_investment(r):
    rate=r.choice([5,8,10,12,15,20,25])
    years=r.randint(2,4)
    base=F(100+rate,100).denominator**years
    return years,rate,int(invest(base*r.randint(1,20),years,rate))


alg('train/707','compound-interest',
    dict(years=(4,2,5),rate_percent=(10,5,25),balance_cents=(43923,1,10**11)),
    lambda y,r,b:f'{y} years ago you invested money at {r}% annual interest, compounded yearly. You now have {decimal(b)} dollars. Assuming the balances at each year-end were exact whole cents, how many dollars did you initially invest?',
    lambda y,r,b:principal(y,r,b)/100,
    check=lambda y,r,b:(p:=principal(y,r,b)).denominator==1 and all(invest(p,k,r).denominator==1 for k in range(1,y)),
    draw=draw_investment,
    reference=lambda y,r,b:uncompound(y,r,b)/100,
    constraint='There is a positive principal in whole cents and every year-end balance is an exact number of cents.',
    adaptation='Made the exact whole-cent convention explicit to avoid any ambiguity from rounding interest.')


def uncompound(years,rate,balance):
    b=F(balance)
    for _ in range(years):
        b*=F(100,100+rate)
    return b


def al_principal(total,final,loss,mult):
    return F(mult*total-final-loss,mult-1)


def investment_valid(t,f,l,m):
    a=al_principal(t,f,l,m)
    if a.denominator!=1 or a<=l or a>=t-2:
        return False
    # In a positive split of the other dollars, exclude equality with Al and with each other.
    return any(b!=t-a-b and b!=a and t-a-b!=a for b in range(1,min(t-int(a),5)))


def draw_split(r):
    a,b,c=r.sample(range(120,700),3)
    m,l=r.randint(2,6),r.randint(10,a-1)
    return a+b+c,a-l+m*(b+c),l,m


alg('train/787','three-investors',
    dict(initial_total=(1000,12,2500),final_total=(1500,1,10000),loss=(100,1,700),other_multiplier=(2,2,6)),
    'Al, Betty, and Clare split {initial_total} whole dollars into three different positive amounts. Betty and Clare each ended with {other_multiplier} times their own initial amount. Al lost {loss} dollars. They ended with {final_total} dollars in total. What was Al’s initial portion in dollars?',
    al_principal,check=investment_valid,draw=draw_split,
    reference=lambda t,f,l,m:next(a for a in range(l+1,t-1) if a-l+m*(t-a)==f),
    constraint='The inferred initial amount is a whole dollar amount exceeding the loss, and the other two investors can receive positive whole dollar amounts distinct from each other and from Al.',
    adaptation='Specify the whole-dollar scale of each initial share, preserving the original aggregate investment model.')


def elapsed_age(child,earlier,later):
    return F(child*(earlier-later),later-1)


def age_valid(child,year,earlier,later):
    t=elapsed_age(child,earlier,later)
    return t.denominator==1 and 0<t and 18<=(earlier-1)*child<=55 and earlier*child+t<=105


def draw_age(r):
    for _ in range(200):
        a,y,e,l=r.randint(5,15),r.randint(1990,2025),r.randint(3,8),r.randint(2,5)
        if age_valid(a,y,e,l):
            return a,y,e,l
    return 8,2004,4,3


alg('train/878','age-ratio-birthdays',
    dict(age=(8,5,15),year=(2004,1980,2035),earlier=(4,3,8),later=(3,2,6)),
    'On Marika’s birthday in {year}, she turned {age} and her father was {earlier} times her age. In what later calendar year will her father be {later} times her age on her birthday?',
    lambda a,y,e,l:y+elapsed_age(a,e,l),check=age_valid,draw=draw_age,
    reference=lambda a,y,e,l:next(y+t for t in range(1,106) if e*a+t==l*(a+t)),
    constraint='The future ratio occurs at a positive integer elapsed year, the age gap is 18–55 years, and the father is at most 105 then.')


def payroll(a,b,c,d,k):
    return F(c*d-a*b,k*d+c-b-k*a)


def payroll_valid(a,b,c,d,k):
    if k*d+c-b-k*a==0:
        return False
    t=payroll(a,b,c,d,k)
    return 0<t-a<=24 and 0<k*t-c<=24 and k*t>b and t>d


def draw_payroll(r):
    for _ in range(500):
        args=tuple(r.randint(1,14) for _ in range(4))+(r.randint(2,5),)
        if payroll_valid(*args):
            return args
    return 6,5,8,5,2


alg('train/996','equal-pay-for-a-day',
    dict(hours_offset=(6,1,14),wage_offset=(5,1,14),other_hours_offset=(8,1,14),
         other_wage_offset=(5,1,14),shared_scale=(2,2,5)),
    'On Monday, I worked $t-{hours_offset}$ hours at ${shared_scale}t-{wage_offset}$ dollars per hour. Andrew worked ${shared_scale}t-{other_hours_offset}$ hours at $t-{other_wage_offset}$ dollars per hour. We earned the same amount. What is $t$?',
    payroll,check=payroll_valid,draw=draw_payroll,
    constraint='The quadratic terms cancel; the linear coefficient must be nonzero. At the solution, work durations are positive and at most 24 hours, and both hourly wages are positive.')


def utility(a,b,c):
    return F(b*c,a+c-b)


def utility_valid(a,b,c):
    if a+c<=b:
        return False
    t=utility(a,b,c)
    return 0<t<min(a,b) and b+c<=24


def draw_utility(r):
    # For positive a,b,c, the recovered t lies in (0,min(a,b)) iff a>b.
    a=r.randint(3,15)
    return a,r.randint(1,min(10,a-1)),r.randint(1,10)


alg('train/1250','equal-activity-products',
    dict(monday_total=(8,3,15),tuesday_frisbee_offset=(2,1,10),tuesday_math_offset=(3,1,10)),
    'Samson’s daily utility is hours of math times hours of frisbee. On Monday he plays frisbee for $t$ hours and does math for ${monday_total}-t$ hours. On Tuesday he plays frisbee for ${tuesday_frisbee_offset}-t$ hours and does math for $t+{tuesday_math_offset}$ hours. The utilities are equal. Find $t$.',
    utility,check=utility_valid,draw=draw_utility,
    constraint='The linear coefficient after cancellation is nonzero, and every activity has positive duration at the solution.')


def growth_exponent(initial,final):
    if final%initial:
        return -1
    q=final//initial
    return q.bit_length()-1 if q>1 and q&(q-1)==0 else -1


alg('train/1427','elapsed-growth',
    dict(initial=(500,2,1000),period=(4,1,12),final=(32000,4,10000000)),
    'The bacteria in a dish double in number every {period} hours. If there are {initial} bacteria now, in how many hours will there be exactly {final}?',
    lambda n,p,f:p*growth_exponent(n,f),
    check=lambda n,p,f:growth_exponent(n,f)>=1,
    draw=lambda r:(lambda n:(n,r.randint(1,12),n*2**r.randint(1,12)))(r.randint(2,1000)),
    reference=lambda n,p,f:next(k*p for k in range(1,30) if n*2**k==f),
    constraint='The final count is a strictly higher power-of-two multiple of the initial count.')


alg('test/954','initial-free-throws',
    dict(practices=(5,2,8),factor=(2,2,5),final=(48,2,1500000)),
    'Jenny made {factor} times as many free throws at each basketball practice as at the previous one. At practice {practices}, she made {final}. How many did she make at her first practice?',
    lambda n,m,f:f//m**(n-1),
    check=lambda n,m,f:f%m**(n-1)==0,
    draw=lambda r:(lambda n,m:(n,m,r.randint(1,18)*m**(n-1)))(r.randint(2,8),r.randint(2,5)),
    constraint='The first-practice count and hence all intermediate counts are positive integers.')


def geometric(n,m):
    return (m**n-1)//(m-1)


alg('test/938','first-day-pages',
    dict(days=(5,2,8),ratio=(2,2,5),pages=(248,3,300000)),
    'Lara took {days} days to read a novel. Each day after the first she read exactly 1/{ratio} as many pages as the day before. The novel had {pages} pages. How many pages did she read on the first day?',
    lambda n,m,p:p//geometric(n,m)*m**(n-1),
    check=lambda n,m,p:p%geometric(n,m)==0,
    draw=lambda r:(lambda n,m:(n,m,geometric(n,m)*r.randint(1,12)))(r.randint(2,7),r.randint(2,4)),
    reference=lambda n,m,p:next(p-sum(d*m**j for j in range(n-1)) for d in range(1,p) if sum(d*m**j for j in range(n))==p),
    constraint='The last-day count and therefore all the preceding counts must be positive integers.')


alg('train/610','monthly-canoes',
    dict(initial=(3,1,35),factor=(2,2,5),months=(3,2,8)),
    'BoatWorks built {initial} canoes in January. Each following month it built {factor} times as many as the previous month. How many canoes did it build in the first {months} months, including January?',
    lambda a,m,n:a*geometric(n,m),
    reference=lambda a,m,n:sum(a*m**k for k in range(n)))


def stopping_distance(a,d):
    n=ceildiv(a,d)
    return n*(2*a-(n-1)*d)//2


alg('train/1636','braking-distance',
    dict(first=(28,2,100),decrement=(7,1,15)),
    'During the first second of braking a car travels {first} feet. Each later second it travels {decrement} fewer feet than in the previous second, stopping once the next distance would be zero. How far does it travel while braking?',
    stopping_distance,
    check=lambda a,d:d<a and a%d==0,
    draw=lambda r:(lambda d:(d*r.randint(2,6),d))(r.randint(1,15)),
    reference=lambda a,d:sum(range(a,0,-d)),
    constraint='The first-second distance exceeds and is divisible by the decrement, so the distances reach exactly zero.')


def boxes(b,r,w):
    return F(r*w,10*b)


for suffix,fields,text,solve in (
    ('train/1312',dict(scale=(800,40,1600),map_hundredths=(475,125,1150)),
     lambda s,d:f'A scale drawing shows that one inch represents {s} feet. How many feet does a segment measuring {decimal(d)} inches represent?',lambda s,d:F(s*d,100)),
    ('test/181',dict(initial=(12,3,40),annual_inches=(18,6,30),target=(36,4,60)),
     'A tree is {initial} feet tall and grows {annual_inches} inches a year. In how many years will it be {target} feet tall?',lambda a,r,b:F(12*(b-a),r)),
    ('test/848',dict(blue=(2,1,10),red=(3,1,10),red_tenths=(152,10,450)),
     lambda b,r,w:f'{b} identical blue boxes together weigh as much as {r} identical red boxes together. Each red box weighs {decimal(w,1)} ounces. How many ounces does one blue box weigh?',boxes),
    ('train/683',dict(cubic_yards=(3,1,25)),
     'How many cubic feet are in {cubic_yards} cubic yards?',lambda n:n*27),
    ('test/83',dict(n=(1,1,9),d=(4,2,15),salt=(2,1,12)),
     'A recipe uses {n}/{d} teaspoon of salt per quart of water. How many quarts of water are needed for {salt} teaspoons of salt?',lambda n,d,s:F(s*d,n)),
    ('test/962',dict(base=(30,10,90),height_tenths=(65,10,160)),
     lambda b,h:f'The volume of a cone is $V=Bh/3$. Its base area is {b} square units and its height is {decimal(h,1)} units. What is its volume in cubic units?',lambda b,h:F(b*h,30)),
    ('test/1146',dict(age=(12,2,25)),
     'On each birthday, Jo gives Aiden as many toy cars as his age in years. How many cars has Aiden received in total after his birthday at age {age}?',lambda n:n*(n+1)//2),
):
    if suffix=='test/181':
        alg(suffix,'constant-growth-height',fields,text,solve,
            check=lambda a,r,b:a<b,
            draw=lambda r:(lambda a:(a,r.randint(6,30),r.randint(a+1,60)))(r.randint(3,40)),
            constraint='The target height is above the initial height.')
    else:
        alg(suffix,'physical-unit-proportion',fields,text,solve)


alg('test/698','staffing-budget',
    dict(cost=(265,30,1000),budget=(2800,100,10000)),
    'A company has {budget} dollars. Each worker it hires reduces this balance by {cost} dollars. What is the greatest number it can hire while keeping its balance strictly positive?',
    lambda c,b:(b-1)//c,
    reference=lambda c,b:next(k-1 for k in range(1,b+1) if b-k*c<=0),
    adaptation='Clarified that a zero balance is disallowed.')


def games_total(n,d,loss_margin):
    return F(loss_margin*d,d-2*n)


def games_valid(n,d,margin):
    return d>2*n and (t:=games_total(n,d,margin)).denominator==1 and (t*n/d).denominator==1


def draw_games(r):
    d=r.randint(3,20)
    n=r.randint(1,(d-1)//2)
    return n,d,r.randint(1,10)*(d-2*n)


alg('test/766','wins-and-losses',
    dict(win_numerator=(2,1,12),win_denominator=(9,3,24),loss_margin=(15,1,200)),
    'A baseball team won {win_numerator}/{win_denominator} of its games, and lost every other game. It lost {loss_margin} more games than it won. How many games did it play?',
    games_total,check=games_valid,draw=draw_games,
    reference=lambda n,d,m:next(2*w+m for w in range(1,m*n+1) if F(w,2*w+m)==F(n,d)),
    constraint='The winning fraction is below one half, and the givens produce whole numbers of wins and games.',
    adaptation='Explicitly excluded tied games.')


def lemon_count(total,multiple,excess):
    return (F(total*multiple,multiple+1)-excess)/2


def lemon_valid(t,m,d):
    l=lemon_count(t,m,d)
    return l>0 and l.denominator==1 and t-2*l-d>=2


alg('test/735','grouped-candy-counts',
    dict(total=(15,5,260),multiplier=(2,2,6),excess=(8,1,55)),
    'A store carries {total} candies in four flavors: chocolate, vanilla, peppermint, and lemon. Peppermint and lemon together number {multiplier} times as many as chocolate and vanilla together. There are {excess} more peppermint candies than lemon candies. How many lemon candies are there?',
    lemon_count,check=lemon_valid,draw=lambda r:draw_lemon(r),
    reference=lambda t,m,d:next(l for l in range(1,t) if 2*l+d==m*(t-2*l-d)),
    constraint='Every flavor can have a positive whole count, and the two equations determine a unique lemon count.')


def draw_lemon(r):
    m=r.randint(2,6)
    for _ in range(150):
        t=(m+1)*r.randint(3,30)
        d=r.randint(1,55)
        if lemon_valid(t,m,d):
            return t,m,d
    return 15,2,8


def other_attendance(t,a,d):
    return F((t-a)*d,d-1)


alg('train/1233','partial-attendance-girls',
    dict(total=(26,3,180),attended=(16,2,100),divisor=(2,2,6)),
    'A chess team has {total} members. Only {attended} attended the last meeting: 1/{divisor} of the girls and all the boys. How many girls are on the team?',
    other_attendance,
    check=lambda t,a,d:0<other_attendance(t,a,d)<t and (other_attendance(t,a,d)/d).denominator==1,
    draw=lambda r:(lambda b,k,d:(b+k*d,b+k,d))(r.randint(1,50),r.randint(1,15),r.randint(2,6)),
    reference=lambda t,a,d:next(g for g in range(1,t) if F(g,d)+t-g==a),
    constraint='The numbers of boys, girls, and attending girls are all positive integers.')
