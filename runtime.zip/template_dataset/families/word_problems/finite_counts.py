"""Finite counts; exact source-bound mathematical models."""

from collections import Counter
from functools import partial
from fractions import Fraction as F
from itertools import permutations, product
from math import factorial, prod
from string import ascii_uppercase
from template_dataset.families.word_problems.decimal_arithmetic import ALG, PRE, add, decimal, listed, rounded

CASES = {}
pre = partial(add, CASES, PRE)
alg = partial(add, CASES, ALG)


def digit_ways(digits, length, repeat=False):
    if repeat:
        return (len(digits)-(0 in digits))*len(digits)**(length-1)
    return (len(digits)-(0 in digits))*prod(range(len(digits)-length+1,len(digits)))


def digit_ways_reference(digits,length,repeat=False):
    tuples = product(digits, repeat=length) if repeat else permutations(digits,length)
    return sum(t[0]!=0 for t in tuples)


for suffix, digits, length, repeat in (
    ('train/36',[2,4,7],2,False),
    ('train/686',[2,4,6,7],2,False),
    ('train/718',[1,2,3,4],3,False),
    ('test/632',[2,4,6,7],2,True),
):
    pre(suffix,'digit-arrangements',
        dict(digits=listed(digits,0,9,min_len=2,max_len=7),length=(length,2,5)),
        lambda ds,n,r=repeat:f'Using only the digits {", ".join(map(str,ds))}, how many positive {n}-digit integers can be formed if a digit {"may" if r else "may not"} be repeated?',
        lambda ds,n,r=repeat:digit_ways(ds,n,r),
        check=lambda ds,n,r=repeat:len(set(ds))==len(ds) and (r or n<=len(ds)),
        draw=lambda g,r=repeat:(lambda k:(sorted(g.sample(range(10),k)),g.randint(2,5 if r else min(5,k))))(g.randint(2,7)),
        reference=lambda ds,n,r=repeat:digit_ways_reference(ds,n,r),
        constraint='The allowed digits are distinct; without repetition there must be at least as many allowed digits as positions.')


def word_permutations(word):
    return factorial(len(word))//prod(factorial(n) for n in Counter(word).values())


for suffix, word in [('train/188','MONKEY'),('train/257','DOG'),('train/687','BASIC')]:
    pre(suffix,'letter-arrangements',
        dict(word=(word,{'type':'str','choices':sorted({word,'PIG','CAMP','MELON','FLOWER','JACKPOT','MAGNETS','BLUEJAYS'})})),
        'How many distinct arrangements are there of the letters in the word “{word}”?',
        word_permutations,
        reference=lambda word:len(set(permutations(word))))


def ordered_choices(n,k):
    return prod(range(n-k+1,n+1))


def placement_draw(rng, maximum):
    n=rng.randint(3,maximum)
    return n,rng.randint(2,n-1)


pre('train/552','race-placements',dict(racers=(5,3,10),places=(3,2,9)),
    'A race has {racers} participants and no ties. How many different ordered finishes for the first {places} places are possible?',
    ordered_choices,
    check=lambda n,k:k<n, draw=lambda r:placement_draw(r,10),
    reference=lambda n,k:sum(1 for _ in permutations(range(n),k)),
    constraint='There are more racers than requested places.')

pre('train/243','lock-arrangements',dict(dials=(3,2,7),digits=(10,3,10)),
    'A suitcase lock has {dials} dials, each with the same {digits} distinct digit choices starting from 0. How many settings are possible if the digits on the dials must all be different?',
    lambda n,d:ordered_choices(d,n),
    check=lambda n,d:n<=d,draw=lambda r:(lambda d:(r.randint(2,min(7,d)),d))(r.randint(3,10)),
    reference=lambda n,d:sum(1 for _ in permutations(range(d),n)),
    constraint='The number of dials cannot exceed the number of digit choices.')

for suffix, field, n, text, offset in (
    ('train/288','attractions',4,'Javier plans to visit {attractions} particular attractions before lunch, each exactly once. In how many orders can he visit them?',0),
    ('train/572','flavors',4,'An ice cream cone has one scoop each of {flavors} different flavors. In how many orders can the scoops be stacked vertically?',0),
    ('train/716','runners',4,'Jordan is on a relay team of {runners} runners. Each runner runs exactly one leg. Jordan runs the last leg. In how many different orders can the team run?',1),
    ('train/376','digits',3,'Sami remembers the {digits} distinct digits that make up her numeric access code, but she cannot recall their order. How many possibilities are there?',0),
):
    pre(suffix,'orderings-with-fixed-slots', {field:(n,2 if not offset else 3,8)},
        text,lambda n,o=offset:factorial(n-o),
        reference=lambda n,o=offset:sum(1 for _ in permutations(range(n-o))),
        adaptation='Recast the area code as an access code to avoid fixed real-world numbering rules.' if suffix=='train/376' else '')

for suffix, fields, statement in (
    ('train/672',dict(colors=(3,2,12),patterns=(4,2,12)),
     'A designer can choose from {colors} fabric colors and {patterns} patterns. Each dress design requires one of each. How many different dress designs are possible?'),
    ('train/787',dict(colors=(4,2,12),methods=(3,2,12)),
     'Marty can choose from {colors} paint colors and {methods} ways to apply paint. How many color and application combinations are possible?'),
    ('train/828',dict(entrees=(4,2,12),drinks=(2,2,12),desserts=(2,2,12)),
     'Crystal can choose from {entrees} distinct entrees, {drinks} distinct drinks, and {desserts} distinct desserts. If she picks one of each, how many different meals can she buy?'),
    ('test/277',dict(first=(2,2,8),second=(4,2,8),third=(2,2,8)),
     'A survey offers {first} choices for its first question, {second} for its second question, and {third} for its third question. Each respondent must select exactly one choice per question. How many answer combinations are possible?'),
    ('test/748',dict(letters=(26,2,26),digits=(10,2,10)),
     'A bicycle license plate consists of one letter followed by one digit. There are {letters} permitted letters and {digits} permitted digits. How many plates are possible?'),
    ('train/1178',dict(colors=(4,2,12)),
     'Chandra has one bowl and one glass in each of {colors} distinct colors. She chooses one bowl and one glass. They do not have to match. How many pairings are possible?'),
):
    match = suffix=='train/1178'
    pre(suffix,'product-choices',fields,statement,
        (lambda k:k*k) if match else (lambda *choices:prod(choices)),
        reference=(lambda k:sum(1 for _ in product(range(k),repeat=2))) if match else
        (lambda *choices:sum(1 for _ in product(*(range(x) for x in choices)))),
        adaptation='List the number of distinct options in each group rather than naming each option.' if suffix in {'train/672','train/787','train/828','test/277','train/1178'} else '')


for suffix, success, adaptation in (
    ('train/165',1,'The named die face is represented by a designated face.'),
    ('train/905',2,'The winning faces are specified as the first several labels of the die.'),
    ('test/819',2,'The winning faces are specified as the highest labels of the die.'),
):
    coin = suffix=='train/165'
    low = suffix=='train/905'
    if coin:
        fields = dict(sides=(6,4,20),face=(2,1,20))
        pre(suffix,'coin-and-die',fields,
            'I flip a fair coin and roll a fair {sides}-sided die numbered from 1 through {sides}. What is the probability of heads and a roll of {face}?',
            lambda n,k:F(1,2*n),check=lambda n,k:k<=n,
            draw=lambda r:(lambda n:(n,r.randint(1,n)))(r.randint(4,20)),
            reference=lambda n,k:F(sum(h and d==k for h,d in product((False,True),range(1,n+1))),2*n),
            constraint='The designated face must exist.')
    else:
        pre(suffix,'designated-die-faces',dict(sides=(6,4,20),winning=(success,1,10)),
            (lambda n,k,lo=low:f'A fair {n}-sided die is numbered 1 through {n}. What is the probability of rolling one of its {k} {"lowest" if lo else "highest"} numbers?'),
            lambda n,k:F(k,n),check=lambda n,k:k<n,
            draw=lambda r:(lambda n:(n,r.randint(1,min(10,n-1))))(r.randint(4,20)),
            adaptation=adaptation,constraint='The event is nonempty and does not contain every face.')

pre('test/556','two-dice',
    dict(red_sides=(6,4,20),green_sides=(6,4,20),red_face=(2,1,20),green_face=(5,1,20)),
    'A fair red {red_sides}-sided die and a fair green {green_sides}-sided die are rolled independently. Each die is numbered starting at 1. What is the probability of a red {red_face} and a green {green_face}?',
    lambda r,g,a,b:F(1,r*g),check=lambda r,g,a,b:a<=r and b<=g,
    draw=lambda r:(lambda a,b:(a,b,r.randint(1,a),r.randint(1,b)))(r.randint(4,20),r.randint(4,20)),
    reference=lambda r,g,a,b:F(sum(x==a and y==b for x,y in product(range(1,r+1),range(1,g+1))),r*g),
    constraint='Each designated outcome must be a face of its own die.')

for suffix, kind in [('train/967','rank'),('train/1130','card'),('test/40','faces')]:
    fields = dict(ranks=(13,5,24),suits=(4,2,8))
    if kind=='faces':
        fields['face_ranks']=(3,1,4)
    query = {'rank':'has a particular rank','card':'has a particular rank and suit',
             'faces':'belongs to one of {face_ranks} designated face ranks'}[kind]
    pre(suffix,'deck-top-card',fields,
        'A deck has {ranks} ranks and {suits} suits, with exactly one card of each rank-suit combination. The deck is shuffled uniformly. What is the probability that the top card '+query+'?',
        {'rank':lambda r,s:F(1,r),'card':lambda r,s:F(1,r*s),
         'faces':lambda r,s,k:F(k,r)}[kind],
        adaptation='Generalized the deck dimensions and described the designated card or ranks by their roles.')


pre('train/922','alphabet-letter',
    dict(word=('PROBABILITY',{'type':'str','choices':['PROBABILITY','EXPERIMENT','STATISTICS','MATHEMATICS','ALPHABET','COMBINATORICS','GRAPH','ALGORITHM','CALCULATOR','VARIANCE']})),
    'Jeff chooses a letter uniformly from the 26-letter English alphabet. What is the probability that it occurs in “{word}”?',
    lambda s:F(len(set(s)),26),
    reference=lambda s:F(sum(c in s for c in ascii_uppercase),26))


def median(data):
    data = sorted(data)
    n = len(data)
    return F(data[n//2]+data[(n-1)//2],2)


pre('train/184','largest-median',
    dict(multiplier=(2,1,10),a=(3,-15,30),b=(2,-15,30),c=(5,-15,30)),
    'What is the largest possible median of the five entries $x, {multiplier}x, {a}, {b}, {c}$ if $x$ is an integer?',
    lambda k,a,b,c:max(a,b,c),
    reference=lambda k,a,b,c:max(median([x,k*x,a,b,c]) for x in range(-31,32)),
    adaptation='Called the five entries a list instead of a set, so coincidences between their values do not reduce its cardinality.')


def envelope_statement(lo,hi,lens,heights):
    columns = r'\begin{array}{c|cc}\text{Envelope}&\text{Length (in.)}&\text{Height (in.)}\\\hline '
    rows = r'\\'.join(f'{letter}&{l}&{h}' for letter,l,h in zip('ABCD',lens,heights))
    return (f'A postal service charges extra if the length-to-height ratio of an envelope is below ${decimal(lo,1)}$ '
            f'or above ${decimal(hi,1)}$. How many of the following envelopes incur the extra charge? '
            + '\\['+columns+rows+r'\end{array}\]')


pre('train/535','envelope-ratios',
    dict(lower=(13,10,19),upper=(25,20,32),lengths=listed([6,9,6,11],1,24),heights=listed([4,3,6,4],1,24)),
    envelope_statement,
    lambda lo,hi,ls,hs:sum(not lo*h<=10*l<=hi*h for l,h in zip(ls,hs)),
    reference=lambda lo,hi,ls,hs:sum(F(l,h)<F(lo,10) or F(l,h)>F(hi,10) for l,h in zip(ls,hs)),
    adaptation='Removed the amount of the surcharge because only its applicability is asked; the threshold rule and all four envelope dimensions are retained.')


def mode_statement(maximum,data):
    stems = {}
    for value in sorted(data):
        stem, leaf = divmod(value,10)
        stems.setdefault(stem, []).append(leaf)
    rows = r'\\'.join(f'{stem}&'+r'\;'.join(map(str,leaves)) for stem,leaves in stems.items())
    return (f'A {maximum}-point test produced the following stem-and-leaf plot. '
            r'The entry $9\mid 6$ would represent 96 points. What is the mode? '
            +r'\[\begin{array}{r|l}'+rows+r'\end{array}\]')


def has_mode(maximum,data):
    counts = sorted(Counter(data).values(),reverse=True)
    return max(data)<=maximum and (len(counts)==1 or counts[0]>counts[1])


def draw_mode(r):
    maximum = r.randint(80,150)
    winner, *others = r.sample(range(maximum+1),r.randint(7,16))
    copies = r.randint(4,7)
    data = [winner]*copies
    for other in others:
        data.extend([other]*r.randint(1,3))
    return maximum,data


pre('train/978','stem-and-leaf-mode',
    dict(maximum=(110,70,150),scores=listed([50,50,63,77,78,82,86,87,89,89,89,89,91,94,94,94,96,100,100,100],0,150,min_len=6,max_len=52)),
    mode_statement, lambda n,x:Counter(x).most_common(1)[0][0],
    check=has_mode,draw=draw_mode,
    reference=lambda n,x:max(set(x),key=x.count),
    constraint='All scores must be at most the maximum score; the most frequent score is unique.')


def county_statement(year, data):
    names = ('Aiken','Bamberg','Barnwell','Berkeley','Calhoun','Cherokee','Chesterfield','Colleton')
    rows = r'\\'.join(r'\text{'+name+'}&'+'&'.join(map(str,data[i:i+5]))
                      for name,i in zip(names,range(0,40,5)))
    return (f'In the hypothetical data for the eight counties listed below, what was the median number of students in {year}? '
            +r'\[\begin{array}{l|ccccc}\text{County}&2001&2002&2003&2004&2005\\\hline '
            +rows+r'\end{array}\]')


pre('test/505','table-median',
    dict(year=(2005,2001,2005),counts=listed([124,141,130,143,136,17,15,15,14,11,25,22,26,28,29,583,557,554,553,524,15,12,10,18,11,19,13,18,13,19,46,18,13,22,29,64,49,52,46,41],1,650)),
    county_statement,lambda y,x:median(x[y-2001::5]),
    reference=lambda y,x:rank_median(x[y-2001::5]),
    adaptation='The table is explicitly hypothetical so varied counts do not assert new historical facts about the named counties.')


def rank_median(data):
    n=len(data)
    def at(rank):
        return next(x for x in data if sum(y<x for y in data)<=rank<sum(y<=x for y in data))
    return F(at(n//2)+at((n-1)//2),2)


pre('test/423','median-of-averages',
    dict(averages=listed([250,243,241,238,234],150,350)),
    lambda data:'Five kick return averages, in yards, were '+', '.join(decimal(x,1) for x in data)+'. What is the median to the nearest tenth?',
    lambda data:rounded(median(data)/10,1),
    reference=lambda data:rank_median(data)/10,
    adaptation='Describe the five averages as recorded values rather than as historical records.')


pre('train/1122','median-of-moon-counts',
    dict(moons=listed([0,0,1,2,16,23,15,2,5],0,40,min_len=5,max_len=12)),
    lambda data:'The numbers of moons around the planets in an imaginary planetary system are '+', '.join(map(str,data))+'. What is the median number of moons per planet?',
    median,reference=rank_median,
    adaptation='Used an imaginary planetary system so the counts and number of planets can vary without false astronomy claims.')


def smallest_candidates(mean,count,largest):
    """Possible smallest entries in increasing lists with the prescribed sum."""
    remaining=mean*count-largest
    k=count-1
    # For each first entry, the remaining distinct integers form a fixed-size
    # subset of a consecutive interval. Every sum between the extremes occurs.
    return [n for n in range(1,largest-k+1)
            if k*n + k*(k-1)//2 <= remaining <= n+(k-1)*largest-k*(k-1)//2]


def draw_smallest(r):
    for _ in range(100):
        count,largest=r.randint(3,6),r.randint(7,45)
        low=(largest+count*(count-1)//2+count-1)//count
        mean=r.randint(low,largest-1)
        if len(smallest_candidates(mean,count,largest))==1:
            return mean,count,largest
    return 5,4,13


def smallest_reference(mean,count,largest):
    from itertools import combinations
    return next(t[0] for t in combinations(range(1,largest),count-1)
                if sum(t)==mean*count-largest)


pre('test/719','smallest-entry-from-mean',
    dict(mean=(5,2,45),count=(4,3,6),largest=(13,4,45)),
    'The mean of {count} distinct positive integers is {mean}. The largest is {largest}. What is the smallest?',
    lambda m,n,x:smallest_candidates(m,n,x)[0],
    check=lambda m,n,x:len(smallest_candidates(m,n,x))==1,draw=draw_smallest,
    reference=smallest_reference,
    constraint='There must be exactly one feasible value for the smallest entry among distinct positive integer lists with the given mean and maximum.')


def ingredients_statement(dozens,numerators,denominators):
    ingredients=('chocolate','marshmallows','cayenne','salted soy nuts')
    facts=', '.join(r'$\frac{'+str(n)+'}{'+str(d)+'}$ contain '+food
                    for n,d,food in zip(numerators,denominators,ingredients))
    return (f'Dave’s sister baked {dozens} dozen pies. Of all the pies, '+facts
            +'. A pie may contain several of these ingredients. What is the smallest possible number of pies containing none of them?')


def ingredient_sizes(dozens,ns,ds):
    return [F(12*dozens*n,d) for n,d in zip(ns,ds)]


def ingredient_valid(dozens,ns,ds):
    sizes=ingredient_sizes(dozens,ns,ds)
    return all(1<=n<12*dozens and n.denominator==1 for n in sizes)


def draw_ingredients(r):
    z=r.randint(2,12)
    ds=[r.choice([d for d in range(2,25) if (12*z)%d==0]) for _ in range(4)]
    ns=[r.randint(1,d-1) for d in ds]
    reduced=[F(n,d) for n,d in zip(ns,ds)]
    return z,[q.numerator for q in reduced],[q.denominator for q in reduced]


pre('test/15','ingredient-union-bound',
    dict(dozens=(3,1,12),numerators=listed([1,1,1,1],1,23),denominators=listed([3,4,6,12],2,24)),
    ingredients_statement,lambda z,ns,ds:max(0,12*z-sum(ingredient_sizes(z,ns,ds))),
    check=ingredient_valid,draw=draw_ingredients,
    reference=lambda z,ns,ds:uncovered_pies(z,ns,ds),
    constraint='Each ingredient count must be a positive integer strictly below the total. Pies may contain more than one listed ingredient.')


def uncovered_pies(z,ns,ds):
    total=12*z
    covered=set()
    start=0
    for n in ingredient_sizes(z,ns,ds):
        covered.update(i%total for i in range(start,start+int(n)))
        start+=int(n)
    return total-len(covered)


def nearest_fraction(w,total,denominators):
    ds=sorted(denominators,key=lambda d:abs(F(w,total)-F(1,d)))
    return ds[0], ds[1]


def medal_valid(w,t,ds):
    if w>=t or len(set(ds))!=len(ds):
        return False
    a,b=nearest_fraction(w,t,ds)
    return abs(F(w,t)-F(1,a))!=abs(F(w,t)-F(1,b))


def draw_medals(r):
    for _ in range(100):
        total=r.randint(35,220)
        won=r.randint(2,total-1)
        choices=r.sample(range(2,22),5)
        if medal_valid(won,total,choices):
            return won,total,choices
    return 17,100,[4,5,6,7,8]


pre('train/777','nearest-unit-fraction',
    dict(won=(17,1,220),total=(100,35,220),denominators=listed([4,5,6,7,8],2,22)),
    lambda w,t,ds:f'A team won {w} out of {t} available medals. Which of '+', '.join('1/'+str(d) for d in ds)+' is closest to the fraction of medals it won?',
    lambda w,t,ds:F(1,nearest_fraction(w,t,ds)[0]),
    check=medal_valid,draw=draw_medals,
    constraint='Fewer medals were won than available, all options differ, and the nearest option is unique.')


pre('train/465','odd-choices-even-product',dict(count=(5,2,25)),
    'Alice chose {count} positive integers and their product was even. What is the maximum number of odd integers she could have chosen?',
    lambda n:n-1)

pre('test/319','minimum-mean-distinct-multiples',dict(count=(4,2,22),divisor=(2,2,10)),
    'What is the smallest possible average of {count} distinct positive multiples of {divisor}?',
    lambda n,d:F(d*(n+1),2),
    reference=lambda n,d:F(sum(range(d,d*(n+1),d)),n))


def powers_partition_min(numbers):
    from functools import lru_cache
    @lru_cache(None)
    def choices(lo,hi):
        if hi-lo==1:return (numbers[lo],)
        return {a+(-1 if cut==3 else 1)*b
                for cut in range(lo+1,hi) for a in choices(lo,cut) for b in choices(cut,hi)}
    return min(choices(0,len(numbers)))


pre('test/453','parenthesis-minimum',
    dict(numbers=listed([1,2,3,4,5,6],1,30)),
    lambda x:'Insert parentheses in the expression '+f'{x[0]} + {x[1]} + {x[2]} - {x[3]} + {x[4]} + {x[5]}'
              +' to make its value as small as possible. Keep the numbers and operations in order, and do not create new operations. What is the minimum?',
    lambda x:sum(x[:3])-sum(x[3:]),reference=powers_partition_min)
