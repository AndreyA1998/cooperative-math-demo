"""Decimal arithmetic; exact source-bound mathematical models."""

from fractions import Fraction as F
from math import isqrt
from template_dataset.families.construction import integer, integers, template

PRE = 'prealgebra'
ALG = 'algebra'


def add(cases, subject, ids, family, fields, statement, solve, *, check=None,
        draw=None, reference=None, constraint='', adaptation=''):
    """Bind a hand-audited statement to its published quantities.

    Each field specifies its source value and public domain. The optional sampler
    returns the *givens* in field order, never the witness used to construct them.
    """
    if (check is None) != (draw is None) or bool(constraint) != (check is not None):
        raise ValueError('Joint domains require a documented constructive sampler')
    names = tuple(fields)
    domains = {k: integer(v[1], v[2]) if len(v) == 3 else v[1]
               for k, v in fields.items()}
    original = {k: v[0] for k, v in fields.items()}

    def unpack(p):
        return [p[k] for k in names]

    model = template(
        'word-' + family, domains, original,
        lambda p: statement(*unpack(p)) if callable(statement) else statement.format(**p),
        lambda p: solve(*unpack(p)),
        valid=(lambda p: check(*unpack(p))) if check else lambda p: True,
        sample=(lambda rng: dict(zip(names, draw(rng)))) if draw else None,
        reference=(lambda p: reference(*unpack(p))) if reference else None,
        constraints=(constraint,) if constraint else (), adaptation=adaptation,
    )
    for suffix in ids.split():
        key = f'{subject}/{suffix}'
        if key in cases:
            raise ValueError(f'Duplicate binding: {key}')
        cases[key] = model


def listed(values, lo, hi, *, min_len=None, max_len=None):
    return values, integers(len(values), lo, hi, min_length=min_len, max_length=max_len)


def ceildiv(a, b):
    return -((-a)//b)


def rounded(x, places=0):
    unit = F(10) ** -places
    scaled = abs(F(x))/unit + F(1, 2)
    return (1 if x >= 0 else -1) * (scaled.numerator//scaled.denominator) * unit


def decimal(scaled, places=2):
    base = 10**places
    n, rem = divmod(abs(scaled), base)
    return ('-' if scaled < 0 else '') + (f'{n}.{rem:0{places}d}' if places else str(n))


def fmt(x):
    return f'${x}$'


def is_prime(n):
    return n >= 2 and not any(n % k == 0 for k in range(2, isqrt(n)+1))


def factors(n):
    small = [k for k in range(1, isqrt(n)+1) if n % k == 0]
    return small + [n//k for k in reversed(small) if k*k != n]


def prime_factors(n):
    result = []
    k = 2
    while k*k <= n:
        if n % k == 0:
            result.append(k)
            while n % k == 0:
                n //= k
        k += 1
    return result + ([n] if n > 1 else [])
