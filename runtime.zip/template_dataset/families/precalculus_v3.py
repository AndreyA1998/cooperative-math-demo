"""Second expansion: coupled geometric constraints and exact branch-aware counts."""
from fractions import Fraction as F
from math import isqrt
from template_dataset.families.precalculus_v2 import T as base_template,I,L,sq,root,dot,cross,det2,vec,nice_vectors


def T(*args,**kwargs):
    t=base_template(*args,**kwargs)
    t.family=t.family.replace('precalculus_v2.','precalculus_v3.',1)
    return t

def norm(v):return dot(v,v)
def sub(a,b):return [x-y for x,y in zip(a,b)]
def sin_roots(p):
    d=isqrt(p['b']**2-4*p['a']*p['c'])
    return {F(0),F(-p['b']+d,2*p['a']),F(-p['b']-d,2*p['a'])}
def count_sine(p):
    n=p['periods']
    return sum((2*n+1 if s==0 else n if abs(s)==1 else 2*n) for s in sin_roots(p) if abs(s)<=1)
def count_sine_reference(p):
    rs=sin_roots(p);vals=[0,1,0,-1];n=4*p['periods']
    endpoints=sum(vals[k%4] in rs for k in range(n+1))
    interiors=sum(min(vals[k%4],vals[(k+1)%4])<s<max(vals[k%4],vals[(k+1)%4]) for k in range(n) for s in rs)
    return endpoints+interiors

def build(row):
    key=row['id']
    special={'precalculus/train/178':('sec',-300),'precalculus/train/615':('sec',120),'precalculus/train/655':('cot',45),'precalculus/test/200':('csc',330),'precalculus/test/476':('cot',90)}
    if key in special:
        from template_dataset.families.geometry import _exact_trig
        return _exact_trig(*special[key])
    if key in ('precalculus/train/102','precalculus/train/436'):
        original=dict(a=[0,7,10],b=[-1,6,6],c=[-4,9,6]) if key.endswith('/102') else dict(a=[6,5,3],b=[3,3,1],c=[15,11,9])
        def sample(r):
            a=[r.randint(-10,10) for _ in range(3)];u=[r.randint(1,20),0,0];v=[r.randint(-10,10),r.randint(1,20),0]
            shift=r.randrange(3);u=u[shift:]+u[:shift];v=v[shift:]+v[:shift]
            return dict(a=a,b=[x+y for x,y in zip(a,u)],c=[x+y for x,y in zip(a,v)])
        def reference(p):
            u,v=sub(p['b'],p['a']),sub(p['c'],p['a'])
            return root(norm(u)*norm(v)-dot(u,v)**2)/2
        return T('triangle_area_3d',original,{k:L(3,-50,50) for k in 'abc'},
          lambda p:f"Find the area of the triangle with vertices {vec(p['a'])}, {vec(p['b'])}, {vec(p['c'])}. Collinear vertices have area zero.",
          lambda p:root(norm(cross(sub(p['b'],p['a']),sub(p['c'],p['a']))))/2,
          lambda p:sq(norm(cross(sub(p['b'],p['a']),sub(p['c'],p['a'])))),sample,reference,
          ['The squared cross-product norm is a perfect square; degenerate triangles are allowed, matching the zero-area source.'])
    if key in ('precalculus/train/124','precalculus/test/448'):
        y_unknown=key.endswith('/124')
        original=dict(P=[3,5],u=[4,-7],Q=[2,-2],known=-1) if y_unknown else dict(P=[0,6],u=[4,-6],Q=[1,-7],known=9)
        idx=0 if y_unknown else 1
        return T('parallel_distinct_lines',original,{'P':L(2),'u':L(2),'Q':L(2),'known':I(-30,30)},
          lambda p:f"The lines P+t u and Q+s v, for real s,t, have no common point. P={vec(p['P'])}, u={vec(p['u'])}, Q={vec(p['Q'])}, v="+(vec([p['known'],'k']) if y_unknown else vec(['k',p['known']]))+". Find k.",
          lambda p:F(p['u'][1-idx]*p['known'],p['u'][idx]),
          lambda p:p['u'][idx]!=0 and p['known']!=0 and det2(sub(p['Q'],p['P']),p['u'])!=0,
          constraints=['The known coordinate of each direction is nonzero and Q-P is not parallel to u.'])
    if key=='precalculus/test/168':
        return T('coincident_lines',dict(P=[4,-1],u=[5,2],Qx=8,multiple=-3),{'P':L(2),'u':L(2),'Qx':I(-30,30),'multiple':I(-10,10)},
          lambda p:f"The equation {vec(p['P'])}+t{vec(p['u'])}=({p['Qx']},k)+s{vec([p['multiple']*x for x in p['u']])} has infinitely many real solutions (s,t). Find k.",
          lambda p:p['P'][1]+F(p['u'][1]*(p['Qx']-p['P'][0]),p['u'][0]),
          lambda p:p['u'][0]!=0 and p['multiple']!=0,
          constraints=['u_x and the direction multiple are nonzero.'])
    if key=='precalculus/test/456':
        def coefficient(p):return dot(sub(p['Q'],p['P']),cross([0,1,0],p['v']))
        def constant(p):return dot(sub(p['Q'],p['P']),cross([p['ux'],0,p['uz']],p['v']))
        return T('coplanar_space_lines',dict(P=[-1,-3,-5],Q=[2,4,6],v=[1,4,7],ux=3,uz=7),{'P':L(3),'Q':L(3),'v':L(3),'ux':I(-20,20),'uz':I(-20,20)},
          lambda p:f"Find k such that the lines {vec(p['P'])}+t({p['ux']},k,{p['uz']}) and {vec(p['Q'])}+s{vec(p['v'])} lie in one plane.",
          lambda p:F(-constant(p),coefficient(p)),lambda p:coefficient(p)!=0 and (p['ux']!=0 or p['uz']!=0),
          constraints=['The scalar triple product has a nonzero coefficient of k; both line directions are nonzero.'])
    projections={'precalculus/train/284':([0,3],[-3,5,-1],12,35,2),
                 'precalculus/train/348':([-8],[2,1],-13,5,1),
                 'precalculus/test/252':([2,-5],[1,-2,1],5,6,1),
                 'precalculus/test/255':([7],[-1,4],26,17,0)}
    if key in projections:
        known,direction,num,den,index=projections[key];dim=len(direction)
        def vector(p,value):
            v=list(p['known']);v.insert(index,value);return v
        return T('projection_missing_coordinate',dict(known=known,direction=direction,numerator=num,denominator=den),{'known':L(dim-1),'direction':L(dim),'numerator':I(-100,100),'denominator':I(1,100)},
          lambda p:f"The orthogonal projection of {vec(vector(p,'x'))} onto {vec(p['direction'])} equals {F(p['numerator'],p['denominator'])} times {vec(p['direction'])}. Find x.",
          lambda p:(F(p['numerator'],p['denominator'])*norm(p['direction'])-dot(vector(p,0),p['direction']))/p['direction'][index],
          lambda p:p['direction'][index]!=0,
          constraints=['The direction coordinate multiplying the unknown is nonzero; all other given coordinates are independent.'])
    if key=='precalculus/train/287':
        def planes(p):
            n=p['normal'];return (' + '.join(f'({a}){v}' for a,v in zip(n,'xyz'))+f"+({p['offset1']})=0",' + '.join(f"({p['multiple']*a}){v}" for a,v in zip(n,'xyz'))+f"+({p['offset2']})=0")
        return T('parallel_plane_distance',dict(normal=[1,2,-2],multiple=2,offset1=1,offset2=5),{'normal':L(3),'multiple':I(-10,10),'offset1':I(-30,30),'offset2':I(-30,30)},
          lambda p:'Find the distance between the planes $'+planes(p)[0]+'$ and $'+planes(p)[1]+'$.',
          lambda p:abs(F(p['offset2'],p['multiple'])-p['offset1'])/root(norm(p['normal'])),
          lambda p:p['multiple']!=0 and norm(p['normal'])>0 and sq(norm(p['normal'])) and p['offset2']!=p['multiple']*p['offset1'],
          lambda r:dict(normal=list(r.choice(nice_vectors(3))),multiple=r.choice([-3,-2,-1,1,2,3]),offset1=r.randint(-10,10),offset2=r.randint(-20,20)),
          constraints=['Nonzero integer normal with integer norm; proportional distinct planes; multiple != 0.'])
    if key=='precalculus/train/472':
        return T('angle_between_planes',dict(a=[2,1,-2],b=[6,3,2],c=3,d=-5),{'a':L(3),'b':L(3),'c':I(-30,30),'d':I(-30,30)},
          lambda p:'Find the cosine of the acute or right angle between the planes $'+'+'.join(f'({x}){v}' for x,v in zip(p['a'],'xyz'))+f"+({p['c']})=0$ and $"+'+'.join(f'({x}){v}' for x,v in zip(p['b'],'xyz'))+f"+({p['d']})=0$; the angle is zero for parallel planes.",
          lambda p:F(abs(dot(p['a'],p['b'])))/root(norm(p['a'])*norm(p['b'])),
          lambda p:norm(p['a'])*norm(p['b'])>0 and sq(norm(p['a'])*norm(p['b'])),
          lambda r:dict(a=list(r.choice(nice_vectors(3))),b=list(r.choice(nice_vectors(3))),c=r.randint(-30,30),d=r.randint(-30,30)),
          reference=lambda p:root(1-F(norm(cross(p['a'],p['b'])),norm(p['a'])*norm(p['b']))),
          constraints=['Normals are nonzero and the product of squared norms is a perfect square.'])
    if key=='precalculus/train/483':
        return T('two_reflections_line_order',dict(a=70,b=54,slope_numerator=19,slope_denominator=92),{'a':I(3,100),'b':I(3,100),'slope_numerator':I(1,100),'slope_denominator':I(1,100)},
          lambda p:rf"Lines l1,l2 through the origin make angles $\pi/{p['a']}$ and $\pi/{p['b']}$ with the positive x-axis. R reflects a line first in l1 then in l2. For the unoriented line $y=({F(p['slope_numerator'],p['slope_denominator'])})x$, find the least positive m with R^m(l)=l.",
          lambda p:(2*(F(1,p['b'])-F(1,p['a']))).denominator,lambda p:p['a']!=p['b'],
          constraints=['a,b>=3 are distinct; unoriented lines are periodic modulo pi, not 2*pi.'])
    if key=='precalculus/train/560':
        def sample(r):
            n1,n2=r.randint(-8,8),r.randint(-8,8);d1,d2=r.randint(1,6),r.randint(1,6)
            return dict(a=d1*d2,b=-(n1*d2+n2*d1),c=n1*n2,periods=r.randint(1,10))
        return T('cubic_sine_root_count',dict(a=2,b=-5,c=2,periods=1),{'a':I(1,40),'b':I(-100,100),'c':I(-100,100),'periods':I(1,20)},
          lambda p:rf"Count distinct real solutions of ${p['a']}\sin^3x+({p['b']})\sin^2x+({p['c']})\sin x=0$ on $[0,{2*p['periods']}\pi]$.",count_sine,
          lambda p:sq(p['b']**2-4*p['a']*p['c']),sample,count_sine_reference,
          ['The residual quadratic has nonnegative perfect-square discriminant. Duplicate sine roots are counted once, and interval endpoints are included.'])
    if key=='precalculus/test/210':
        def m_for(k):
            lo,hi=1,101
            while lo+1<hi:
                m=(lo+hi)//2
                if m*(m*m-1)<=k:lo=m
                else:hi=m
            return lo
        def ref(p):
            lo,hi=0,p['coefficient']+1
            while lo+1<hi:
                y=(lo+hi)//2
                if y*y*(1+y)<=p['coefficient']**2:lo=y
                else:hi=y
            assert lo*lo*(1+lo)==p['coefficient']**2
            return lo
        return T('trigonometric_log_equation',dict(coefficient=24),{'coefficient':I(1,999900)},
          lambda p:rf"For $x\in[0,\pi/2]$, $\log_{{{p['coefficient']}\sin x}}({p['coefficient']}\cos x)=3/2$. Find cot²(x).",
          lambda p:m_for(p['coefficient'])**2-1,
          lambda p:(lambda m:m>=2 and m*(m*m-1)==p['coefficient'])(m_for(p['coefficient'])),
          lambda r:(lambda m:dict(coefficient=m*(m*m-1)))(r.randint(2,50)),ref,
          ['coefficient=m(m²-1) for integer 2<=m<=100. Both log arguments are positive and the base m²-1 is greater than one.'])
    if key=='precalculus/train/470':
        def answer(p):
            n=p['B']//p['b'];return F(p['T']-n*(n-1)//2*p['b']*p['c'],n)
        def sample(r):
            n,b,c,a=r.randint(1,20),r.randint(1,10),r.randint(1,10),r.randint(-20,20)
            return dict(b=b,c=c,B=n*b,C=n*c,T=n*a+n*(n-1)//2*b*c)
        def ref(p):
            n=p['B']//p['b'];a=answer(p)
            m=[[1,p['b'],a],[0,1,p['c']],[0,0,1]];v=[[1,0,0],[0,1,0],[0,0,1]]
            for _ in range(n):v=[[sum(v[i][k]*m[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
            assert v==[[1,p['B'],p['T']],[0,1,p['C']],[0,0,1]]
            return a+n
        return T('unipotent_matrix_power',dict(b=2,c=4,B=18,C=36,T=2007),{'b':I(1,20),'c':I(1,20),'B':I(1,400),'C':I(1,400),'T':I(-1000,100000)},
          lambda p:rf"For positive integer n, $\begin{{pmatrix}}1&{p['b']}&a\\0&1&{p['c']}\\0&0&1\end{{pmatrix}}^n=\begin{{pmatrix}}1&{p['B']}&{p['T']}\\0&1&{p['C']}\\0&0&1\end{{pmatrix}}$. Find a+n.",
          lambda p:answer(p)+p['B']//p['b'],lambda p:p['B']%p['b']==0 and p['C']%p['c']==0 and p['B']//p['b']==p['C']//p['c']<=20,sample,ref,
          ['B/b=C/c is an integer between 1 and 20; top-right entry determines a uniquely.'])
    if key in ('geometry/test/229','geometry/test/437'):
        sphere=key.endswith('/229');o=dict(ratio=1) if sphere else dict(ratio=1,height=6)
        domains={'ratio':I(1,30)}
        if not sphere:domains['height']=I(1,50)
        return T('volume_surface_radius_sphere' if sphere else 'volume_surface_radius_cylinder',o,domains,
          lambda p:(f"The numerical volume of a sphere in cubic units is {p['ratio']} times its surface area in square units. Find the radius in units." if sphere else f"A cylindrical can is {p['height']} inches high. Its numerical volume in cubic inches is {p['ratio']} times the square-inch area of a label covering its lateral surface. Find its radius in inches."),
          lambda p:(3 if sphere else 2)*p['ratio'])
    if key=='geometry/train/366':
        def sample(r):
            u,v=r.choice([x for x in nice_vectors(2) if min(x)>0]);k=r.randint(2,10)
            return dict(small_area=u*v//2,large_area=u*v//2*k*k,hypotenuse=isqrt(u*u+v*v))
        return T('similar_right_triangle_leg_sum',dict(small_area=6,large_area=150,hypotenuse=5),{'small_area':I(1,500),'large_area':I(2,50000),'hypotenuse':I(1,100)},
          lambda p:f"Two similar right triangles have areas {p['small_area']} and {p['large_area']} square inches. The smaller triangle's hypotenuse is {p['hypotenuse']} inches. Find the sum of the larger triangle's leg lengths in inches.",
          lambda p:root(F(p['large_area'],p['small_area'])*(p['hypotenuse']**2+4*p['small_area'])),
          lambda p:p['large_area']>p['small_area'] and p['hypotenuse']**2>=4*p['small_area'] and sq(F(p['large_area'],p['small_area'])*(p['hypotenuse']**2+4*p['small_area'])),sample,
          constraints=['0 < small_area < large_area; hypotenuse² >= 4*small_area; squared target leg sum is a rational square.'])
    if key=='geometry/train/128':
        def cube(v):
            n=0
            while (n+1)**3<=v:n+=1
            return n
        def sample(r):
            a,b,c,x,y=(r.randint(1,10) for _ in range(5));return dict(AB=a*x+b,coefficient=c,linear=a,offset=b,AD=c*y**3)
        return T('parallelogram_opposite_sides',dict(AB=38,coefficient=3,linear=2,offset=4,AD=24),{'AB':I(1,300),'coefficient':I(1,20),'linear':I(1,20),'offset':I(0,30),'AD':I(1,20000)},
          lambda p:rf"In parallelogram ABCD, AB={p['AB']} cm, $BC={p['coefficient']}y^3$ cm, $CD={p['linear']}x+{p['offset']}$ cm, AD={p['AD']} cm. Find xy.",
          lambda p:F(p['AB']-p['offset'],p['linear'])*cube(F(p['AD'],p['coefficient'])),
          lambda p:p['AB']>p['offset'] and F(p['AD'],p['coefficient'])==cube(F(p['AD'],p['coefficient']))**3,sample,
          constraints=['AB > offset; AD/coefficient is a positive perfect cube. Opposite sides determine x,y uniquely.'])
    if key=='geometry/train/267':
        def vertices(p):
            return [[p['top_x'],p['top_y']],[p['bottom_x'],p['bottom_y']],
                    [p['bottom_x']-p['width'],p['bottom_y']],[p['top_x']-p['width'],p['top_y']]]
        def area(v):
            return abs(sum(det2(a,b) for a,b in zip(v,v[1:]+v[:1])))/2 if v else F(0)
        def ref(p):
            polygon=[[F(x),F(y)] for x,y in vertices(p)];clipped=[];h=p['threshold']
            for a,b in zip(polygon,polygon[1:]+polygon[:1]):
                ina,inb=a[1]<=h,b[1]<=h
                if ina:clipped.append(a)
                if ina!=inb:
                    t=F(h-a[1],b[1]-a[1]);clipped.append([a[0]+t*(b[0]-a[0]),F(h)])
            return area(clipped)/area(polygon)
        def sample(r):
            bottom=r.randint(-20,5);top=bottom+r.randint(2,30)
            return dict(top_x=r.randint(-30,30),bottom_x=r.randint(-30,30),top_y=top,bottom_y=bottom,width=r.randint(1,30),threshold=r.randint(bottom+1,top-1))
        return T('parallelogram_cut_probability',dict(top_x=3,bottom_x=-3,top_y=3,bottom_y=-3,width=6,threshold=0),
          {'top_x':I(-30,30),'bottom_x':I(-30,30),'top_y':I(-40,40),'bottom_y':I(-40,40),'width':I(1,30),'threshold':I(-40,40)},
          lambda p:f"A point is selected uniformly from the parallelogram with consecutive vertices {', '.join(vec(v) for v in vertices(p))}. Find the probability that its y-coordinate is at most {p['threshold']}.",
          lambda p:F(p['threshold']-p['bottom_y'],p['top_y']-p['bottom_y']),
          lambda p:p['bottom_y']<p['threshold']<p['top_y'],sample,ref,
          ['Bottom < threshold < top; equal positive horizontal base widths preserve a nondegenerate parallelogram.'])
    if key=='geometry/train/681':
        def cube(n):
            lo,hi=0,n+1
            while lo+1<hi:
                m=(lo+hi)//2
                if m*m*m<=n:lo=m
                else:hi=m
            return lo
        def ratio(p):return F(p['percent_numerator'],100*p['percent_denominator'])
        def sample(r):
            d=r.randint(2,12);n=r.randint(1,d-1);percent=100*F(n,d)**3
            return dict(volume_coefficient=r.randint(1,1000),percent_numerator=percent.numerator,percent_denominator=percent.denominator)
        return T('sphere_volume_radius_ratio',dict(volume_coefficient=288,percent_numerator=25,percent_denominator=2),
          {'volume_coefficient':I(1,10000),'percent_numerator':I(1,200000),'percent_denominator':I(1,2000)},
          lambda p:rf"A large sphere has volume ${p['volume_coefficient']}\pi$ cubic units. A smaller sphere's volume is $\frac{{{p['percent_numerator']}}}{{{p['percent_denominator']}}}\%$ of that volume. Find the ratio of the smaller radius to the larger radius.",
          lambda p:F(cube(ratio(p).numerator),cube(ratio(p).denominator)),
          lambda p:0<ratio(p)<1 and cube(ratio(p).numerator)**3==ratio(p).numerator and cube(ratio(p).denominator)**3==ratio(p).denominator,sample,
          constraints=['Percent/100 lies strictly in (0,1) and its reduced numerator and denominator are perfect cubes.'])
    if key=='geometry/test/420':
        return T('right_triangle_symmetric_side_coefficients',dict(coefficient=1),{'coefficient':I(1,30)},
          lambda p:rf"A right triangle has side lengths $x$, $x+{p['coefficient']}y$ and $x-{p['coefficient']}y$, where $0<{p['coefficient']}y<x$. Find y/x.",
          lambda p:F(1,4*p['coefficient']))
    if key=='geometry/test/456':
        def angle(p):return F(90*p['r1']*p['b'],p['a']*p['r2']+p['b']*p['r1'])
        def sample(r):
            a,b,c,x=r.randint(1,5),r.randint(1,5),r.randint(1,8),r.randint(1,89);den=r.randint(1,4)
            return dict(a=a,b=b,c_numerator=c,c_denominator=den,r1=den*a*x,r2=den*b*(90-x),r3=c*(180-x))
        return T('angle_complement_supplement_ratio',dict(a=3,b=4,c_numerator=1,c_denominator=2,r1=3,r2=14,r3=4),
          {'a':I(1,10),'b':I(1,10),'c_numerator':I(1,10),'c_denominator':I(1,10),'r1':I(1,2000),'r2':I(1,2000),'r3':I(1,2000)},
          lambda p:f"All angles are in degrees. The ratio of {p['a']} times angle A to {p['b']} times its complement to {F(p['c_numerator'],p['c_denominator'])} times its supplement is {p['r1']}:{p['r2']}:{p['r3']}. Find the complement of A.",
          lambda p:90-angle(p),
          lambda p:0<angle(p)<90 and F(p['c_numerator'],p['c_denominator'])*(180-angle(p))*p['r1']==p['r3']*p['a']*angle(p),sample,
          constraints=['All three ratio components must agree on the unique acute angle determined by the first two.'])
    if key=='geometry/train/804':
        return T('right_angle_sine_with_lengths',dict(leg=16,hypotenuse=24),{'leg':I(1,100),'hypotenuse':I(2,200)},
          lambda p:f"Right triangle ABC has angle A=90 degrees, AB={p['leg']} and BC={p['hypotenuse']}. Find sin(A).",
          lambda p:1,lambda p:p['leg']<p['hypotenuse'],
          sample=lambda r:(lambda leg:dict(leg=leg,hypotenuse=r.randint(leg+1,200)))(r.randint(1,100)),
          constraints=['0 < leg < hypotenuse, so a nondegenerate right triangle exists; the queried right angle remains structural.'])
    if key=='geometry/train/735':
        return T('symbolic_pythagorean_sides',dict(coefficient=2,offset=1),{'coefficient':I(1,30),'offset':I(1,30)},
          lambda p:rf"A triangle has sides $\sqrt{{{p['coefficient']}u-{p['offset']}}}$, $\sqrt{{{p['coefficient']}u+{p['offset']}}}$ and $\sqrt{{{2*p['coefficient']}u}}$, where ${p['coefficient']}u>{p['offset']}$. Find its largest angle in degrees.",
          lambda p:90)
    if key=='geometry/train/314':
        from itertools import product
        def coefficient(q):
            for d in (1,2,5):
                if q%d==0 and sq(q//d):return isqrt(q//d)
            return None
        def good(p):
            a,b,c,d,h=(p[k] for k in ('left','rise','top','notch','height'))
            return all(coefficient(q) is not None for q in (a*a+b*b,d*d+h*h,(a+c)**2+h*h))
        def polygon(p):
            a,b,c,d,h=(p[k] for k in ('left','rise','top','notch','height'));x,y=p['origin']
            return [[x,y+h],[x+a,y+h+b],[x+a+c,y+h+b],[x+a+c,y+h],[x+a+c+d,y+h],[x+a+c,y]]
        def solve(p):
            v=polygon(p)
            return sum(coefficient(norm(sub(a,b))) for a,b in zip(v,v[1:]+v[:1]))
        # The catalogue is shared by source bindings and repeated generation through the module cache.
        def sample(r):
            if not hasattr(build,'polygon_shapes'):
                build.polygon_shapes=[dict(zip(('left','rise','top','notch','height'),v)) for v in product(range(1,7),repeat=5) if good(dict(zip(('left','rise','top','notch','height'),v)))]
            p=dict(r.choice(build.polygon_shapes));p['origin']=[r.randint(-20,20),r.randint(-20,20)];return p
        return T('polygon_radical_perimeter',dict(left=1,rise=1,top=1,notch=1,height=1,origin=[0,0]),
          dict({k:I(1,12) for k in ('left','rise','top','notch','height')},origin=L(2,-30,30)),
          lambda p:'A hexagon has consecutive vertices '+', '.join(vec(v) for v in polygon(p))+r'. Its perimeter is $a+b\sqrt2+c\sqrt5$ where a,b,c are whole numbers. Find a+b+c.',
          solve,good,sample,
          constraints=['All five shape lengths are positive. Each sloped edge has squared length d*k² with d in {1,2,5} and integer k; the displayed polygon is simple.'])
    if key=='geometry/train/200':
        t=T('minimum_progression_triangle_perimeter',dict(step=1),{'step':I(1,50)},
          lambda p:f"A triangle has three positive integer side lengths in an increasing arithmetic progression with common difference {p['step']}. Find its smallest possible perimeter in units.",
          lambda p:6*p['step']+3,
          reference=lambda p:min(3*x+3*p['step'] for x in range(1,2*p['step']+2) if x+(x+p['step'])>x+2*p['step']))
        t.adaptation='Consecutive integer side lengths are the original common-difference-one case; larger positive integer steps extend the same triangle-inequality optimization.'
        return t
    if key=='geometry/train/229':
        return T('regular_polygon_neighbor_triangle_angle',dict(sides=6),{'sides':I(3,40)},
          lambda p:rf"A regular polygon has {p['sides']} vertices $A_0,A_1,\ldots,A_{{{p['sides']-1}}}$ in cyclic order. Find the angle $A_0A_1A_{{{p['sides']-1}}}$ in degrees.",
          lambda p:F(180,p['sides']),reference=lambda p:(180-F(180*(p['sides']-2),p['sides']))/2)
    if key=='geometry/train/323':
        def ref(p):
            t=F(p['numerator'],p['denominator']);D=[t,0];E=[1-t,t];G=[0,1-t]
            return abs(det2(sub(E,D),sub(G,D)))
        t=T('cyclic_side_division_area_ratio',dict(numerator=1,denominator=2),{'numerator':I(1,29),'denominator':I(2,30)},
          lambda p:rf"Triangle ABC has area T. Points D,E,F lie on AB,BC,CA respectively, with AD/AB=BE/BC=CF/CA={F(p['numerator'],p['denominator'])}. Joining D,E,F gives area M. Find M/T.",
          lambda p:1-3*F(p['numerator'],p['denominator'])+3*F(p['numerator'],p['denominator'])**2,
          lambda p:p['numerator']<p['denominator'],reference=ref,
          constraints=['The common directed side fraction lies strictly between zero and one.'])
        t.adaptation='Midpoints correspond to the original common fraction 1/2. The cyclic side-division fraction is made dynamic; the original area-ratio question is retained.'
        return t
    return None
