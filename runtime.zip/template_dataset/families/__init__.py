"""Strict source bindings and exact mathematical template families."""
