"""Root identities and vertex queries derived directly from source coefficients."""
from fractions import Fraction
from math import gcd

from template_dataset.families.algebra import _MATH_BLOCK, _math_body, _poly_add, _poly_mul, _tex_polynomial
from template_dataset.families.algebra_v2 import _Bindings, _horner

from .algebra_equations import (
    EquationParser, _find_nodes, quadratic_roots, rational_form, real_root_count, variables,
)
from .common import draw, integer, template


def polynomial_parameters(coefficients, leading_range=18):
    return {
        f"c{i}": integer(min(int(c), -max(18, abs(int(c)) + 3)),
                        max(int(c), max(18, abs(int(c)) + 3), leading_range if i == len(coefficients) - 1 else 0))
        for i, c in enumerate(coefficients)
    }


def polynomial_original(coefficients):
    return {f"c{i}": int(c) for i, c in enumerate(coefficients)}


def polynomial_values(p, degree):
    return tuple(Fraction(p[f"c{i}"]) for i in range(degree + 1))


def extract_polynomial(row, *, bare=False):
    bindings = _Bindings(row["problem"])
    if not bare:
        parsed = _find_nodes(row, bindings)
        if not parsed:
            return None
        nodes, variable = parsed
        forms = [rational_form(tree, bindings.values(keys, bindings.original), variable)
                 for tree, keys in nodes]
        (a, b, _), (c, d, _) = forms
        if len(b) != 1 or len(d) != 1:
            return None
        return variable, _poly_add(tuple(x / b[0] for x in a), tuple(x / d[0] for x in c), -1)

    for block in _MATH_BLOCK.finditer(row["problem"]):
        source, offset = _math_body(block)
        source = source.split("=")[-1]
        try:
            node, keys = bindings.parse(source, offset + len(_math_body(block)[0]) - len(source),
                                        EquationParser)
            names = variables(node)
        except ValueError:
            continue
        if len(names) != 1:
            continue
        variable = next(iter(names))
        numerator, denominator, _ = rational_form(node, bindings.values(keys, bindings.original), variable)
        if len(denominator) == 1 and len(numerator) == 3:
            return variable, tuple(c / denominator[0] for c in numerator)
    return None


VERTICES = {
    "algebra/train/34": ("min", "position"),
    "algebra/train/441": ("min", "value"),
    "algebra/train/462": ("min", "position"),
    "algebra/train/1607": ("max", "value"),
    "algebra/test/60": ("min", "position"),
    "algebra/test/924": ("min", "value"),
    "algebra/test/1151": ("min", "value"),
}


def _vertex(row, extremum, query):
    parsed = extract_polynomial(row, bare=True)
    if not parsed:
        return None
    variable, coefficients = parsed
    parameters = polynomial_parameters(coefficients)
    original = polynomial_original(coefficients)

    def solve(p):
        c, b, a = polynomial_values(p, 2)
        return -b / (2 * a) if query == "position" else c - b * b / (4 * a)

    def reference(p):
        c, b, a = polynomial_values(p, 2)
        # The midpoint of any equal-height pair is the symmetry axis.
        x0 = Fraction(0)
        x1 = -b / a
        midpoint = (x0 + x1) / 2
        return midpoint if query == "position" else _horner((c, b, a), midpoint)

    direction = "minimum" if extremum == "min" else "maximum"

    def render(p):
        formula = _tex_polynomial(polynomial_values(p, 2), variable)
        if query == "position":
            return f"For which real value of ${variable}$ does ${formula}$ attain its {direction}?"
        return f"What is the {direction} value of ${formula}$ over all real ${variable}$?"

    valid = (lambda p: p["c2"] > 0) if extremum == "min" else (lambda p: p["c2"] < 0)
    return template(
        "extensions.algebra.quadratic_vertex", parameters, original, render, solve,
        valid=valid, reference=reference,
        constraints=(f"The leading coefficient has the sign required for a {direction}.",),
        adaptation="Write the quadratic in general form, allowing the linear coefficient to vary from zero.",
    )


# The complete named-root prompts are curated by ID and then parsed as polynomials.
VIETA = {
    "algebra/train/470": ("ordered", ("a", "b")),
    "algebra/train/1371": ("ordered", ("p", "q")),
    "algebra/train/1598": ("shift_product", ("d", "e")),
    "algebra/test/307": ("ordered", ("a", "b")),
    "algebra/test/311": ("shift_product", ("d", "e")),
    "algebra/test/436": ("shift_product", ("p", "q")),
    "intermediate_algebra/train/509": ("product", ("r", "s", "t")),
    "intermediate_algebra/train/510": ("mixed_powers", ("a", "b")),
    "intermediate_algebra/train/859": ("pair_ratios", ("r", "s", "t")),
    "intermediate_algebra/train/1007": ("e2", ("a", "b", "c")),
    "intermediate_algebra/test/118": ("product", ("a", "b", "c")),
    "intermediate_algebra/test/198": ("e3", ("p", "q", "r", "s")),
    "intermediate_algebra/test/351": ("sum_product", ("a", "b", "c")),
    "intermediate_algebra/test/447": ("real_reciprocals", ("a", "b", "c", "d")),
    "intermediate_algebra/test/543": ("squares", ("r", "s", "t")),
    "intermediate_algebra/test/645": ("sum", ("a", "b", "c", "d")),
    "intermediate_algebra/test/678": ("sum", ("a", "b", "c")),
    "intermediate_algebra/test/805": ("reciprocals", ("a", "b", "c")),
    "intermediate_algebra/test/834": ("subset_products", ("a", "b", "c")),
}

ORDERED_WEIGHTS = {"algebra/train/470": (2, 1), "algebra/test/307": (2, -3),
                   "algebra/train/1371": (1, -1)}


def _vieta(row, mode, names):
    parsed = extract_polynomial(row)
    degree = len(names)
    if not parsed or len(parsed[1]) != degree + 1 or any(c.denominator != 1 for c in parsed[1]):
        return None
    variable, coefficients = parsed
    domains = polynomial_parameters(coefficients)
    original = polynomial_original(coefficients)

    if mode == "ordered":
        original["high_weight"], original["low_weight"] = ORDERED_WEIGHTS[row["id"]]
        domains.update(high_weight=integer(-8, 8), low_weight=integer(-8, 8))
    if mode in ("ordered", "shift_product"):
        # The initial root equations name real, distinct roots.
        if mode == "shift_product":
            original["shift"] = 1 if row["id"] == "algebra/test/436" else -1
            domains["shift"] = integer(-12, 12)
    if mode == "real_reciprocals":
        domains.update({f"c{i}": integer(-220, 220) for i in range(4)})
    if mode == "subset_products":
        original["offset"] = 1
        domains["offset"] = integer(-8, 12)

    def elementary(coeffs):
        return [Fraction(1)] + [(-1)**i * coeffs[degree - i] / coeffs[-1]
                                for i in range(1, degree + 1)]

    def solve(p):
        coeffs = polynomial_values(p, degree)
        e = elementary(coeffs)
        if mode == "ordered":
            low, high = sorted(root[0] for root in quadratic_roots(coeffs))
            return p["high_weight"] * high + p["low_weight"] * low
        if mode == "shift_product":
            shift = p["shift"]
            return e[2] + e[1] * shift + shift**2
        if mode == "mixed_powers":
            return e[1]**3 - 3 * e[1] * e[2] + e[2]**2 * (e[1]**2 - 2 * e[2])
        if mode == "pair_ratios":
            return (e[2]**2 - 2 * e[1] * e[3]) / e[3]
        if mode in ("reciprocals", "real_reciprocals"):
            return e[-2] / e[-1]
        if mode == "squares":
            return e[1]**2 - 2 * e[2]
        if mode == "sum_product":
            return e[1] + e[-1]
        if mode == "subset_products":
            return sum(e[1:]) + p["offset"]
        return e[{"sum": 1, "product": degree, "e2": 2, "e3": 3}[mode]]

    def reference(p):
        coeffs = polynomial_values(p, degree)
        if mode == "shift_product":
            return _horner(coeffs, -p["shift"]) / coeffs[-1]
        if mode == "subset_products":
            return (-1)**degree * _horner(coeffs, -1) / coeffs[-1] - 1 + p["offset"]
        if mode in ("reciprocals", "real_reciprocals"):
            # For P = A prod(x-r), logarithmic differentiation at zero.
            return -coeffs[1] / coeffs[0]
        if mode in ("mixed_powers", "squares"):
            # Trace of the companion matrix powers gives the power sums.
            matrix = [[Fraction(int(i == j + 1)) for j in range(degree)]
                      for i in range(degree)]
            for i in range(degree):
                matrix[i][-1] = -coeffs[i] / coeffs[-1]
            squared = [[sum(matrix[i][k] * matrix[k][j] for k in range(degree))
                        for j in range(degree)] for i in range(degree)]
            sum_two = sum(squared[i][i] for i in range(degree))
            if mode == "squares":
                return sum_two
            sum_three = sum(squared[i][k] * matrix[k][i] for i in range(degree)
                            for k in range(degree))
            determinant = matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0]
            return sum_three + determinant**2 * sum_two
        raise ValueError("no alternate identity for this query")

    def valid(p):
        coeffs = polynomial_values(p, degree)
        if not coeffs[-1]:
            return False
        if mode in ("reciprocals", "real_reciprocals", "pair_ratios") and not coeffs[0]:
            return False
        if mode == "real_reciprocals":
            return real_root_count(coeffs) == degree
        if mode in ("ordered", "shift_product"):
            roots = quadratic_roots(coeffs)
            if len(roots) != 2:
                return False
            if mode == "ordered":
                return all(not root[1] for root in roots) and (p["high_weight"] or p["low_weight"])
        return True

    def sample(rng):
        p = {k: draw(rng, d) for k, d in domains.items()}
        if mode in ("ordered", "real_reciprocals"):
            roots = rng.sample([i for i in range(-4, 5) if i], degree)
            if mode == "ordered":
                denominator = rng.randint(1, 3)
                roots = [Fraction(r, denominator) for r in roots]
                leading = denominator**2 * rng.choice((-2, -1, 1, 2))
            else:
                leading = rng.choice((-2, -1, 1, 2))
            poly = (Fraction(leading),)
            for root in roots:
                poly = _poly_mul(poly, (-root, Fraction(1)))
            p.update(polynomial_original(poly))
        return p

    def render(p):
        coeffs = polynomial_values(p, degree)
        equation = _tex_polynomial(coeffs, variable) + " = 0"
        a, b, *tail = names
        c = tail[0] if tail else ""
        names_tex = ", ".join(names)
        kind = "distinct real " if mode in ("ordered", "shift_product", "real_reciprocals") else "complex "
        order = f" with ${a}>{b}$" if mode == "ordered" else ""
        base = f"Let ${names_tex}$ be the {kind}roots of ${equation}${order}. Find "
        if mode == "ordered":
            expression = _tex_polynomial((0, p["high_weight"]), a)
            low = p["low_weight"]
            expression += ((" + " if low > 0 else " - ") + _tex_polynomial((0, abs(low)), b)) if low else ""
        elif mode == "shift_product":
            expression = "".join("(" + _tex_polynomial((p["shift"], 1), name) + ")" for name in names)
        elif mode == "mixed_powers":
            expression = f"{a}^3+{a}^4{b}^2+{a}^2{b}^4+{b}^3"
        elif mode == "pair_ratios":
            expression = " + ".join(r"\frac{" + left + right + "}{" + div + "}"
                                    for left, right, div in ((a, b, c), (b, c, a), (c, a, b)))
        elif mode in ("reciprocals", "real_reciprocals"):
            expression = " + ".join(r"\frac{1}{" + name + "}" for name in names)
        elif mode == "squares":
            expression = " + ".join(name + "^2" for name in names)
        elif mode == "sum_product":
            expression = " + ".join(("".join(names), *names))
        elif mode == "subset_products":
            expression = f"{a}{b}{c}+{a}{b}+{a}{c}+{b}{c}+{a}+{b}+{c}"
            if p["offset"]:
                expression += (" + " if p["offset"] > 0 else " - ") + str(abs(p["offset"]))
        elif mode == "sum":
            expression = " + ".join(names)
        elif mode == "product":
            expression = "".join(names)
        elif mode == "e2":
            expression = f"{a}{b}+{a}{c}+{b}{c}"
        else:
            d = names[-1]
            expression = f"{a}{b}{c}+{a}{b}{d}+{a}{c}{d}+{b}{c}{d}"
        return base + f"${expression}$."

    reference_modes = {"shift_product", "subset_products", "reciprocals", "real_reciprocals", "mixed_powers", "squares"}
    constraints = ["The leading coefficient is nonzero and the degree is fixed."]
    if mode in ("ordered", "shift_product", "real_reciprocals"):
        constraints.append("The stated number of distinct real roots must exist.")
    if mode == "ordered":
        constraints.append("The two ordered roots are rational and the query weights are not both zero.")
    if mode in ("reciprocals", "real_reciprocals", "pair_ratios"):
        constraints.append("The constant coefficient is nonzero, so no root is a denominator zero.")
    result = template(
        "extensions.algebra.named_polynomial_roots", domains, original, render, solve,
        valid=valid, sample=sample, reference=reference if mode in reference_modes else None,
        constraints=constraints,
        adaptation="State the equation in standard polynomial form and make coefficient slots explicit. "
                   "Unqualified polynomial roots are taken over the complex numbers with multiplicity.",
    )
    return result if valid(original) else None


def build(row):
    key = row["id"]
    if key in VERTICES:
        return _vertex(row, *VERTICES[key])
    if key in VIETA:
        return _vieta(row, *VIETA[key])
    return None
