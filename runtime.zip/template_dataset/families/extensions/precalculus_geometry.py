"""Constructive Euclidean domains and exact geometry solvers."""
from fractions import Fraction as F
from functools import lru_cache
from itertools import combinations
from .common import integer as I, integers as L, choice, template, is_square, sqrt_fraction
from template_dataset.families.precalculus_v2 import nice_vectors
def norm(v):return sum(x*x for x in v)
def sub(a,b):return [x-y for x,y in zip(a,b)]
def frac(p,k):return F(p[k+'_num'],p[k+'_den'])
def T(name,*args,**kw):return template('extensions.precalculus.'+name,*args,**kw)
def altitude(p):
    t=frac(p,'tan');u,v=p['u'],p['v']
    return (u+v+sqrt_fraction((u+v)**2+4*t*t*u*v))/(2*t)
def altitude_sample(r):
    u,v=r.randint(1,20),r.randint(1,20);h=r.randint(max(u,v)+1,max(u,v)+30)
    t=F(h*(u+v),h*h-u*v)
    return dict(u=u,v=v,tan_num=t.numerator,tan_den=t.denominator)
def altitude_reference(p):
    h=altitude(p);u,v=p['u'],p['v']
    ab2=h*h+u*u;ac2=h*h+v*v;bc2=(u+v)**2
    return sqrt_fraction(4*ab2*ac2-(ab2+ac2-bc2)**2)/4
@lru_cache(None)
def cosine_triangles():
    return tuple((a,b,c) for a in range(1,41) for b in range(1,41) for c in (60,90,120)
                 if is_square(a*a+b*b-{60:1,90:0,120:-1}[c]*a*b))
def bisector_squared(p):return 2*p['b']**2*p['c']**2*(1+frac(p,'cos'))/(p['b']+p['c'])**2
def bisector_sample(r):
    b,c=r.randint(1,30),r.randint(1,30);l=r.randint(1,max(1,(2*b*c-1)//(b+c)))
    co=F(l*l*(b+c)**2,2*b*b*c*c)-1
    return dict(b=b,c=c,cos_num=co.numerator,cos_den=co.denominator)
def bisector_reference(p):
    b,c=p['b'],p['c'];a2=b*b+c*c-2*b*c*frac(p,'cos')
    return sqrt_fraction(b*c*(1-a2/F((b+c)**2)))
@lru_cache(None)
def intercepts():
    return tuple((a,b,c) for a in range(1,21) for b in range(1,21) for c in range(1,21)
                 if is_square((a*b)**2+(a*c)**2+(b*c)**2))
def clip(poly,a,b,c):
    out=[]
    for v,w in zip(poly,poly[1:]+poly[:1]):
        fv=a*v[0]+b*v[1]-c;fw=a*w[0]+b*w[1]-c
        if fv>=0:out.append(v)
        if fv*fw<0:
            t=fv/(fv-fw);out.append((v[0]+t*(w[0]-v[0]),v[1]+t*(w[1]-v[1])))
    return out
def twice_area(poly):
    return abs(sum(v[0]*w[1]-v[1]*w[0] for v,w in zip(poly,poly[1:]+poly[:1]))) if poly else F(0)
def simplex_reference(p):
    x,y,z=[F(p[k],p['den']) for k in 'abc'];total=F(0)
    for missing in range(3):
        poly=[(F(0),F(0)),(F(1),F(0)),(F(0),F(1))]
        for i,(a,b,c) in enumerate(((1,0,x),(0,1,y),(-1,-1,z-1))):
            if i==missing:a,b,c=-a,-b,-c
            poly=clip(poly,a,b,c)
        total+=twice_area(poly)
    return total
def build(row):
    pid=row['id']
    if pid=='precalculus/train/34':
        return T('triangle_trig_equality',{'q':choice([1,2]),'a':I(1,100),'radicand':choice([1,2])},dict(q=2,a=4,radicand=1),
          lambda p:rf"In triangle $ABC$, $\cos({p['q']}A-B)+\sin(A+B)=2$ and $AB={p['a']}\sqrt{{{p['radicand']}}}$. Find $BC$.",
          lambda p:F(p['a'],p['q']),valid=lambda p:p['radicand']==(2 if p['q']==1 else 1),
          constraints=['q=1 requires radicand=2; q=2 requires radicand=1. Equality forces A+B=90 degrees and B=q*A.'])
    if pid=='precalculus/train/199':
        def squared(p):return p['a']**2+p['b']**2-{60:1,90:0,120:-1}[p['angle']]*p['a']*p['b']
        return T('law_cosines_rational',{'a':I(1,40),'b':I(1,40),'angle':choice([60,90,120])},dict(a=7,b=8,angle=120),
          lambda p:rf"Two sides of a triangle have lengths {p['a']} and {p['b']}; their included angle is $ {p['angle']}^\circ$. Find the third side.",
          lambda p:sqrt_fraction(squared(p)),valid=lambda p:is_square(squared(p)),
          sample=lambda r:dict(zip(('a','b','angle'),r.choice(cosine_triangles()))),
          constraints=['The squared third side from the cosine rule is a perfect square.'])
    if pid=='precalculus/train/276':
        def sample(r):
            a=[r.randint(-30,30) for _ in range(3)];v=r.choice(nice_vectors(3))
            return dict(a=a,b=[x+y for x,y in zip(a,v)],r1=r.randint(1,100),r2=r.randint(1,100))
        return T('farthest_spheres',{'a':L(3,-100,100),'b':L(3,-100,100),'r1':I(1,100),'r2':I(1,100)},
          dict(a=[-2,-10,5],b=[12,8,-16],r1=19,r2=87),
          lambda p:f"Find the largest distance between points on spheres centered at {tuple(p['a'])} and {tuple(p['b'])}, with respective radii {p['r1']} and {p['r2']}.",
          lambda p:sqrt_fraction(norm(sub(p['a'],p['b'])))+p['r1']+p['r2'],
          valid=lambda p:is_square(norm(sub(p['a'],p['b']))),sample=sample,
          constraints=['The squared center distance is a perfect square; coincident centers are allowed.'])
    if pid=='precalculus/train/427':
        return T('polar_circle_intersections',{'a':I(1,100),'b':I(1,100)},dict(a=4,b=8),
          lambda p:rf"How many distinct points belong to both polar graphs $r={p['a']}\cos\theta$ and $r={p['b']}\sin\theta$?",
          lambda p:2,constraints=['Positive coefficients give two circles meeting at the origin and one distinct point.'])
    if pid=='precalculus/train/448':
        def solve(p):
            a,b,c=[F(p[k],p['den']) for k in 'abc']
            return sum(max(F(0),1-x-y)**2 for x,y in combinations((a,b,c),2))-3*max(F(0),1-a-b-c)**2
        def sample(r):
            d=r.randint(3,60);return dict(den=d,**{k:r.randint(1,d-1) for k in 'abc'})
        return T('simplex_exactly_two',{'den':I(2,60),**{k:I(1,59) for k in 'abc'}},dict(den=6,a=3,b=2,c=1),
          lambda p:rf"In $\mathcal T=\{{(x,y,z)\ge0:x+y+z=1\}}$, let $\mathcal S$ contain points satisfying exactly two of $x\ge {p['a']}/{p['den']}$, $y\ge {p['b']}/{p['den']}$, $z\ge {p['c']}/{p['den']}$. Find area(S)/area(T).",
          solve,valid=lambda p:all(p[k]<p['den'] for k in 'abc'),sample=sample,reference=simplex_reference,
          constraints=['Each threshold is strictly between zero and one. Their sum need not be one.'])
    if pid=='precalculus/train/507':
        return T('angle_bisector',{'b':I(1,30),'c':I(1,30),'cos_num':I(-2000000,2000000),'cos_den':I(1,2000000)},dict(b=3,c=6,cos_num=1,cos_den=8),
          lambda p:rf"In triangle $ABC$, $AB={p['b']}$, $AC={p['c']}$ and $\cos A={frac(p,'cos')}$. Find the length of the internal angle bisector from $A$.",
          lambda p:sqrt_fraction(bisector_squared(p)),valid=lambda p:-1<frac(p,'cos')<1 and is_square(bisector_squared(p)),
          sample=bisector_sample,reference=bisector_reference,constraints=['-1 < cosine < 1; bisector squared is a rational square.'])
    if pid=='precalculus/test/74':
        return T('plane_intercept_distance',{k:I(-20,20) for k in 'abc'},dict(a=-5,b=2,c=-7),
          lambda p:f"A plane has x-, y-, z-axis intercepts {p['a']}, {p['b']}, {p['c']}. Find its distance from the origin.",
          lambda p:F(abs(p['a']*p['b']*p['c']))/sqrt_fraction(sum((p[a]*p[b])**2 for a,b in combinations('abc',2))),
          valid=lambda p:all(p[k]!=0 for k in 'abc') and is_square(sum((p[a]*p[b])**2 for a,b in combinations('abc',2))),
          sample=lambda r:dict(zip('abc',[x*r.choice([-1,1]) for x in r.choice(intercepts())])),
          reference=lambda p:1/sqrt_fraction(sum(F(1,p[k]**2) for k in 'abc')),
          constraints=['Nonzero intercepts; sum of squared pairwise products is a perfect square.'])
    if pid=='precalculus/test/117':
        def solve(p):
            a,c=F(p['p']),F(p['p'],p['q']);return (a*a+c*c-1)/(2*a*c)
        return T('triangle_sum_squares',{'p':I(1,12),'q':I(1,12)},dict(p=2,q=1),
          lambda p:rf"Positive triangle side lengths $a,b,c$ satisfy $2a^2+{p['p']**2}b^2+{p['q']**2}c^2={2*p['p']}ab+{2*p['q']}ac$. Find the cosine of the angle opposite $b$.",
          solve,valid=lambda p:abs(p['p']-F(p['p'],p['q']))<1<p['p']+F(p['p'],p['q']),
          constraints=['Forced side ratio a:b:c=p:1:p/q satisfies strict triangle inequalities.'])
    if pid in ('precalculus/test/314','precalculus/test/439'):
        original=dict(u=3,v=17,tan_num=22,tan_den=7) if pid.endswith('/314') else dict(u=2,v=3,tan_num=1,tan_den=1)
        return T('altitude_from_tangent',{'u':I(1,30),'v':I(1,30),'tan_num':I(1,10000),'tan_den':I(1,10000)},original,
          lambda p:rf"In acute triangle $ABC$, altitude $AD$ meets $BC$ at $D$, where $BD={p['u']}$ and $CD={p['v']}$. If $\tan A={frac(p,'tan')}$, find its area.",
          lambda p:(p['u']+p['v'])*altitude(p)/2,
          valid=lambda p:is_square((p['u']+p['v'])**2+4*frac(p,'tan')**2*p['u']*p['v']),
          sample=altitude_sample,reference=altitude_reference,
          constraints=['Positive tangent; discriminant (u+v)^2+4*tangent^2*u*v is a rational square.'],
          adaptation=('The tangent and both altitude segments vary; the positive tangent and internal altitude already imply an acute triangle.'
                      if pid.endswith('/314') else
                      'A given 45-degree angle is equivalently expressed by tangent 1; tangent and both altitude segments vary.'))
    if pid=='precalculus/test/393':
        def distances(p):return [norm(sub(p[a],p[b])) for a,b in combinations('PQR',2)]
        def sample(r):
            a=[r.randint(-20,20) for _ in range(3)];s=r.randint(1,20)
            pts=[[a[0]+s,a[1]+s,a[2]],[a[0]+s,a[1],a[2]+s],[a[0],a[1]+s,a[2]+s]]
            r.shuffle(pts);return dict(zip('PQR',pts))
        return T('cube_equilateral_vertices',{k:L(3,-40,40) for k in 'PQR'},dict(P=[7,12,10],Q=[8,8,1],R=[11,3,9]),
          lambda p:f"Three vertices of a cube are P={tuple(p['P'])}, Q={tuple(p['Q'])}, R={tuple(p['R'])}. Find the cube's side length.",
          lambda p:sqrt_fraction(F(distances(p)[0],2)),
          valid=lambda p:len(set(distances(p)))==1 and distances(p)[0]>0 and is_square(F(distances(p)[0],2)),sample=sample,
          constraints=['Equal positive pairwise squared distances; half this value is a rational square. Equal cube-vertex distances must be face diagonals.'])
