"""Exact polynomial quotients, roots and graphs of rational functions."""
from fractions import Fraction as F
from math import gcd, isqrt

from template_dataset.families.algebra import _poly_divmod, _poly_gcd
from .algebra_equations import rational_roots, real_root_count
from .common import is_square, sqrt_fraction
from .round3_intermediate_common import I, bind, integers, polynomial


def _poly_mul(left,right):
    result = [0]*(len(left)+len(right)-1)
    for i,a in enumerate(left):
        for j,b in enumerate(right):
            result[i+j] += a*b
    return result


def linear_identity(a,b,c,d):
    return rf'Find $x$ such that $ {polynomial([0,a],"x")}y+{b}y+{polynomial([d,c],"x")}=0$ for all $y$.'.replace('+-','-')


bind('r519','linear_identity_for_all_inputs','a b c d',(8,-12,2,-3),
     (I(1,300),I(-900,900),I(1,80),I(-900,900)),
     linear_identity,lambda a,b,c,d:F(-b,a),
     valid=lambda a,b,c,d:b*c==a*d,
     sample=lambda r:(lambda x,y,m,n:(m*y,-m*x,n*y,-n*x))(
         r.randint(-15,15),r.randint(1,10),r.randint(1,20),r.randint(1,20)),
     constraints=('The two coefficients as functions of x vanish at the same x.',))


def repeated_cubic_root(values):
    derivative=[i*c for i,c in enumerate(values) if i]
    common=_poly_gcd(list(map(F,values)),list(map(F,derivative)))
    if len(common)==2:
        return -F(common[0],common[1])
    if len(common)==3 and common[1]**2==4*common[0]*common[2]:
        return -F(common[1],2*common[2])
    raise ValueError('Expected one repeated root')


def repeated_cubic_sample(rng):
    a,b,c,d=rng.randint(1,8),rng.randint(-12,12),rng.randint(1,8),rng.randint(-12,12)
    return (_poly_mul(_poly_mul([b,a],[b,a]),[d,c]),)


def has_repeated_root(values):
    if not values[-1]:
        return False
    try:
        repeated_cubic_root(values)
    except ValueError:
        return False
    return True


bind('r564','unique_repeated_cubic_root','coefficients',([45,-42,-4,8],),
     (integers(4,-4000,4000),),
     lambda c:rf'For some real $r$, $ {polynomial(c)}$ is divisible by $(x-r)^2$. Find $r$.',
     repeated_cubic_root,valid=has_repeated_root,sample=repeated_cubic_sample,
     constraints=('The polynomial is cubic and has a repeated root.',))


def residues(c):
    result=F(0)
    for x in c:
        factor=1
        for y in c:
            if y!=x:
                factor*=y-x
        result+=F(1,factor)
    return result


def partial_fraction_prompt(shifts):
    labels='ABCDE'
    denominators=[polynomial([shift,1]) for shift in shifts]
    product=''.join(rf'\left({q}\right)' for q in denominators)
    right='+'.join(rf'\frac{{{a}}}{{{q}}}' for a,q in zip(labels,denominators))
    return rf'By partial fractions, $\frac{{1}}{{{product}}}={right}$. Find $A+B+C+D+E$.'


bind('r567','partial_fraction_sum_of_residues','shifts',([0,1,2,3,4],),
     (integers(5,-100,100),),partial_fraction_prompt,lambda c:0,
     sample=lambda r:(r.sample(range(-100,101),5),),
     valid=lambda c:len(set(c))==5,reference=residues,
     constraints=('The five shifts are distinct.',))


def quotient_polynomial(coefficients,divisor):
    quotient,remainder=_poly_divmod(list(map(F,coefficients)),list(map(F,divisor)))
    if not divisor[-1] or any(remainder):
        raise ValueError('Expected a polynomial quotient')
    return quotient


def polynomial_product_sample(rng, degree_a, degree_b, limit):
    a=[rng.randint(-limit,limit) for _ in range(degree_a)]+[rng.randint(1,limit)]
    b=[rng.randint(-limit,limit) for _ in range(degree_b)]+[rng.randint(1,limit)]
    return _poly_mul(a,b),a


def sum_quotient(c,d):
    q=quotient_polynomial(c,d)
    return sum(q)


def quotient_valid(c,d):
    return bool(c[-1] and d[-1]) and not any(_poly_divmod(list(map(F,c)),list(map(F,d)))[1])


def quotient_at_one(numerator, divisor):
    # Repeatedly remove a common factor of x-1 by differentiating at x=1.
    while not sum(divisor):
        numerator = [i*c for i,c in enumerate(numerator) if i]
        divisor = [i*c for i,c in enumerate(divisor) if i]
    return F(sum(numerator),sum(divisor))


bind('t90','sum_of_polynomial_quotient_coefficients','numerator divisor',
     ([0]*14+[108,-24,-18,23]+[0]*5+[1],[9,-2,-3,0,1]),
     (integers(24,-500,500,min_length=6,max_length=30),integers(5,-20,20)),
     lambda c,d:rf'If $P(x)$ is a polynomial and $ {polynomial(c)}=({polynomial(d)})P(x)$ for all $x$, find the sum of the coefficients of $P(x)$.',
     sum_quotient, valid=quotient_valid,
     sample=lambda r:polynomial_product_sample(r,4,r.randint(2,25),6),
     reference=quotient_at_one,
     constraints=('Both arrays are in ascending powers, with nonzero leading coefficients and exact polynomial divisibility.',))


def third_root(c,d):
    quotient=quotient_polynomial(d,c)
    return -F(quotient[0],quotient[1])


def third_valid(c,d):
    if not quotient_valid(d,c) or not real_root_count(c)==2:
        return False
    x=third_root(c,d)
    return sum(v*x**i for i,v in enumerate(c))!=0


def third_sample(rng):
    u,v,w=rng.sample(range(-10,11),3)
    f=_poly_mul([-u,1],[-v,1])
    return f,_poly_mul(f,[-w,rng.randint(1,4)])


bind('t601','additional_cubic_root','quadratic cubic',([4,3,-1],[-12,-1,9,-2]),
     (integers(3,-300,300),integers(4,-3000,3000)),
     lambda f,g:rf'Let $f(x)={polynomial(f)}$ and $g(x)={polynomial(g)}$. Every root of $f$ is a root of $g$. Find the third root of $g$, which is not a root of $f$.',
     third_root,sample=third_sample,valid=third_valid,
     constraints=('Both lists use ascending powers. The quadratic has two distinct real roots; the cubic is exactly divisible by the quadratic and its third root is distinct.',))


def common_root(a,b):
    roots=_poly_gcd(list(map(F,a)),list(map(F,b)))
    if len(roots)!=2:
        raise ValueError('Expected one common root')
    return -F(roots[0],roots[1])


def common_sample(rng):
    a,b,c=rng.sample(range(-20,21),3)
    return [-a*b,a+b,-1],[-a*c,a+c,-1]


bind('t547','intersection_of_two_quadratic_zeros','left right',([8,-6,1],[-6,1,1]),
     (integers(3,-500,500),)*2,
     lambda a,b:rf'What real value of $x$ is excluded from the domain of $f(x)=\frac{{1}}{{|{polynomial(a)}|+|{polynomial(b)}|}}$?',
     common_root,sample=common_sample,
     valid=lambda a,b:bool(a[-1] and b[-1]) and len(_poly_gcd(list(map(F,a)),list(map(F,b))))==2,
     constraints=('Coefficients are in ascending powers. Both polynomials are quadratic and their gcd is linear.',))


def exp_factors(roots,powers):
    return ''.join(rf'({polynomial([-x,1])})^{{{p}}}' for x,p in zip(roots,powers) if p)


def vertical_count(roots,powers_num,powers_den):
    return sum(a<b for a,b in zip(powers_num,powers_den))


def rational_graph_sample(rng,n):
    roots=rng.sample(range(-30,31),n)
    numerator=[rng.randint(0,8) for _ in roots]
    denominator=[rng.randint(int(p==0),8) for p in numerator]
    numerator[0]=max(1,numerator[0])
    denominator[-1]=max(1,denominator[-1])
    return roots,numerator,denominator


def rational_graph_valid(roots,a,b):
    return len(set(roots))==len(roots) and any(a) and any(b) and all(x+y>0 for x,y in zip(a,b))


for key,x,y,z in [
    ('t62',[-8,-5,-1,0,3,-7,4],[1,2,3,5,2,0,0],[0,2,1,1,3,1,1]),
    ('t856',[-3,-2,-1,7,0],[5,8,4,2,0],[11,6,4,0,2]),
]:
    n=len(x)
    bind(key,'factored_rational_vertical_asymptotes','roots numerator_powers denominator_powers',(x,y,z),
         (integers(n,-30,30),integers(n,0,12),integers(n,0,12)),
         lambda x,y,z:rf'Find the number of vertical asymptotes of $y=\frac{{{exp_factors(x,y)}}}{{{exp_factors(x,z)}}}$.',
         vertical_count,sample=lambda r,n=n:rational_graph_sample(r,n),
         valid=rational_graph_valid,
         constraints=('The listed roots are distinct. Each appears in at least one product, and both numerator and denominator have positive degree.',))


def asymptote_sample(rng,n):
    u,v=rng.sample(range(-10,11),2)
    c=_poly_mul([-u,1],[-v,1])
    q=[rng.randint(-12,12) for _ in range(n-2)]+[rng.randint(1,7)]
    return _poly_mul([-u,1],q),c,*rng.sample(range(1,15),4)


for key,c,d in [('t160',[0,3,1],[3,4,1]),('t881',[0,1,-1,1],[0,-9,6])]:
    bind(key,'rational_graph_weighted_features','numerator denominator w x y z',(c,d,1,2,3,4),
         (integers(len(c),-500,500),integers(len(d),-500,500))+(I(1,20),)*4,
         lambda c,d,w,x,y,z:rf'For the graph of $\frac{{{polynomial(c)}}}{{{polynomial(d)}}}$, let $a,b,c,d$ respectively count holes, vertical asymptotes, horizontal asymptotes and oblique asymptotes. Find $ {polynomial([0,w],"a")}+{polynomial([0,x],"b")}+{polynomial([0,y],"c")}+{polynomial([0,z],"d")}$.' ,
         lambda c,d,w,x,y,z:weighted_asymptotes(c,d,(w,x,y,z)),
         valid=lambda c,d,*weights:c[-1]!=0 and d[-1]!=0,
         sample=lambda r,n=len(c):asymptote_sample(r,n),
         constraints=('Both lists use ascending powers and have nonzero leading coefficients.',))


def weighted_asymptotes(numerator,denominator,weights):
    common=_poly_gcd(list(map(F,numerator)),list(map(F,denominator)))
    reduced=quotient_polynomial(denominator,common)
    vertical=real_root_count(reduced)
    holes=real_root_count(common)-real_root_count(_poly_gcd(common,reduced))
    delta=len(numerator)-len(denominator)
    return sum(a*b for a,b in zip(weights,(holes,vertical,delta<=0,delta==1)))


def integer_cubic_roots(values):
    return [r for r in rational_roots(values) if r.denominator==1]


def integer_cubic_sample(rng):
    u=rng.randint(-18,18)
    a,b=rng.randint(-12,12),rng.randint(1,40)
    return (_poly_mul([-u,1],[b,a,1]),)


bind('t695','unique_integer_root_of_monic_cubic','coefficients',([72,18,-14,1],),
     (integers(4,-1000,1000),),
     lambda c:rf'The polynomial $g(x)={polynomial(c)}$ has exactly one integer root. What is it?',
     lambda c:integer_cubic_roots(c)[0],sample=integer_cubic_sample,
     valid=lambda c:c[-1]==1 and len(integer_cubic_roots(c))==1,
     constraints=('Coefficients are in ascending powers. The cubic is monic and has one distinct integer root.',))


def rational_root_count(a,b,n):
    def divisors(k):
        return [x for x in range(1,k+1) if k%x==0]
    return 2*sum(gcd(p,q)==1 for p in divisors(b) for q in divisors(a))


bind('t194','possible_rational_roots_by_extreme_coefficients','leading constant degree',(2,1,4),
     (I(1,300),I(1,300),I(3,30)),
     lambda a,b,n:rf'A polynomial with integer coefficients has the form $ {a}x^{{{n}}}+a_{{{n-1}}}x^{{{n-1}}}+\cdots+a_1 x+{b}$. Across choices of the unspecified coefficients, how many different rational roots are possible?',
     rational_root_count,
     constraints=('The interior coefficients are arbitrary integers.',))


def positive_integer_cubic_constant(total,pairs):
    def prime(x):
        return x>=2 and all(x%k for k in range(2,isqrt(x)+1))
    found=[]
    primes=[x for x in range(2,total) if prime(x)]
    for a in primes:
        if 3*a>=total:
            break
        for b in primes:
            c=total-a-b
            if a<b<c and a*b+b*c+c*a==pairs and prime(c):
                found.append(a*b*c)
    return found


def prime_sample(rng):
    a,b,c=rng.sample([2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59],3)
    return a+b+c,a*b+b*c+c*a


bind('t22','prime_roots_from_two_symmetric_sums','sum pairs',(52,581),
     (I(10,250),I(1,20000)),
     lambda s,t:rf'The roots of $ {polynomial([0,t,-s,1])}-k$ are distinct primes. Find $k$.',
     lambda s,t:positive_integer_cubic_constant(s,t)[0],
     sample=prime_sample,valid=lambda s,t:len(positive_integer_cubic_constant(s,t))==1,
     constraints=('There is exactly one unordered triple of distinct primes with the stated elementary symmetric sums.',))


def integral_quadratic_divisor(u,v,k):
    # x² = -ux-v, x³ = (u²-v)x+uv modulo the divisor.
    a,b=F(-u*k,v*v),F((v-u*u)*k,v*v)
    if a.denominator!=1 or b.denominator!=1:
        raise ValueError('Both coefficients must be integers')
    return b


def integral_quadratic_valid(u,v,k):
    return v!=0 and (u*k)%(v*v)==0 and ((v-u*u)*k)%(v*v)==0


bind('r1105','unknown_integral_cubic_coefficients','linear constant target_constant',
     (-1,-1,1),(I(-20,20),I(-20,20),I(1,2000)),
     lambda u,v,k:rf'If integers $a,b$ satisfy that $ {polynomial([v,u,1])}$ is a factor of $ax^3+bx^2+{k}$, find $b$.',
     integral_quadratic_divisor,valid=integral_quadratic_valid,
     sample=lambda r:(r.randint(-20,20),v:=r.choice([*range(-20,0),*range(1,21)]),v*v*r.randint(1,5)),
     constraints=('The divisor constant is nonzero and both unknown coefficients obtained by division are integers.',))


def conjugate_cubic_a(x,m,d,k):
    # Irrational conjugate pair has sum 2x and product x²-m²d.
    return F(k,x*x-m*m*d)-2*x


bind('r1292','rational_cubic_with_surd_root','real coefficient radicand constant',
     (-1,4,2,31),(I(-20,20),I(1,20),I(2,60),I(-1000,1000)),
     lambda x,m,d,k:rf'Given that $ {x}-{m}\sqrt{{{d}}}$ is a root of $x^3+ax^2+bx+{k}=0$ with $a,b$ rational, find $a$.'.replace('+-','-'),
     conjugate_cubic_a,valid=lambda x,m,d,k:not is_square(d),
     constraints=('The radicand is not a square, so the conjugate must also be a root.',))


def known_product_coefficient(a,b,c,d,e):
    # Compare the two leading coefficients of the product.
    return F(e-b*F(d,a),a)


def coefficient_sample(rng):
    a,b,c,x,y,z=[rng.randint(1,12) for _ in range(6)]
    return [c,b,a],_poly_mul([c,b,a],[z,y,x])


bind('r176','unknown_quadratic_product_coefficient','divisor product',
     ([7,-9,15],[14,-25,60,-42,45]),(integers(3,-200,200),integers(5,-500,500)),
     lambda d,c:rf'Find the constant $b$ such that $\left({polynomial([F(x,3) for x in d])}\right)(ax^2+bx+c)={polynomial([F(x,3) for x in c])}$.',
     lambda d,c:known_product_coefficient(d[2],d[1],d[0],c[4],c[3]),
     valid=lambda d,c:quotient_valid(c,d),sample=coefficient_sample,
     constraints=('Both coefficient lists are in ascending powers, encoded as numerators over 3. The product is exactly divisible by the known factor, and both leading coefficients are nonzero.',))


def root_from_cubes(a,b,c,d):
    numerator=_poly_mul(_poly_mul([a,1],[a,1]),[a,1])
    for h,sign in ((b,1),(c,1),(d,-1)):
        term=[h**3,3*h*h,3*h,1]
        numerator=[p+sign*q for p,q in zip(numerator,term)]
    roots=rational_roots(numerator)
    if len(roots)!=1 or real_root_count(numerator)!=1:
        raise ValueError('Expected one real rational root')
    return next(iter(roots))


def cube_valid(*args):
    try:
        root_from_cubes(*args)
    except ValueError:
        return False
    return True


bind('r333','single_real_root_of_shifted_cube_sum','a b c d',(0,1,2,3),(I(-50,50),)*4,
     lambda a,b,c,d:rf'Find all real solutions to $({polynomial([a,1])})^3+({polynomial([b,1])})^3+({polynomial([c,1])})^3=({polynomial([d,1])})^3$.',
     root_from_cubes,valid=cube_valid,
     sample=lambda r:(a:=r.randint(-12,12),a+(k:=r.randint(1,12)),a+2*k,a+3*k),
     constraints=('The cubic difference has exactly one distinct real root, and that root is rational.',))


def palindromic_threshold(c):
    return 3*c


bind('t3','all_real_palindromic_cubic_threshold','leading',(1,),(I(1,80),),
     lambda c:rf'Let $a>0$ and suppose all roots of $ {polynomial([c,0,0,c])}+ax^2+ax=0$ are real. Find the smallest possible value of $a$.',
     palindromic_threshold)


bind('t113','positive_cubic_roots_log_sum','base sum',(2,5),
     (I(2,8),I(1,8)),
     lambda b,k:rf'The cubic $ {b**3}x^3+{b*b}ax^2+{b}bx+a=0$ has three distinct positive roots. If the sum of their base-{b} logarithms is {k}, find $a$.',
     lambda b,k:-b**(k+3),
     constraints=('The log sum is positive, ensuring three distinct positive roots can be chosen with their required sum and product.',))


def quadratic_factor_sums(c):
    const,linear,square,cube,leading=c
    if leading!=1 or const==0:
        return set()
    possible=set()
    for magnitude in range(1,abs(const)+1):
        if const%magnitude:
            continue
        for b in (magnitude,-magnitude):
            d=const//b
            if b==d:
                discriminant=cube*cube-4*(square-b-d)
                if cube*b==linear and is_square(discriminant) and (cube+isqrt(discriminant))%2==0:
                    possible.add(cube+b+d)
                continue
            a=F(linear-cube*b,d-b)
            if a.denominator==1 and a*(cube-a)+b+d==square:
                possible.add(cube+b+d)
    return possible


def quartic_factor_sample(rng):
    a,b,c,d=[rng.choice([*range(-12,0),*range(1,13)]) for _ in range(4)]
    return (_poly_mul([b,a,1],[d,c,1]),)


bind('r377','sum_of_integer_quadratic_factor_coefficients','coefficients',([-5,17,-2,1,1],),
     (integers(5,-2000,2000),),
     lambda c:rf'For integers $a,b,c,d$, $(x^2+ax+b)(x^2+cx+d)={polynomial(c)}$. Find $a+b+c+d$.',
     lambda c:next(iter(quadratic_factor_sums(c))),
     valid=lambda c:len(quadratic_factor_sums(c))==1,sample=quartic_factor_sample,
     constraints=('The list is ascending by power, monic of degree four with nonzero constant. At least one integral monic quadratic factorization exists, and all give the same requested sum.',))


def lcm_system_sums(k,c):
    if c[-1]!=1 or not quotient_valid(c,[k,1]):
        return set()
    q=quotient_polynomial(c,[k,1])
    roots=rational_roots(q)
    if len(roots)!=2 or any(t.denominator!=1 for t in roots):
        return set()
    out=set()
    for x in roots:
        y=-q[1]-x
        u,v=-x,-y
        if k*u==k+v:
            out.add(k+u+k*u+k*v)
    return out


def lcm_sample(rng):
    k=rng.randint(-5,5)
    u=rng.randint(-12,12)
    v=k*u-k
    return k,_poly_mul(_poly_mul([k,1],[u,1]),[v,1])


bind('r636','linear_gcd_and_cubic_lcm_of_linked_quadratics','shift coefficients',
     (1,[6,1,-4,1]), (I(-10,10),integers(4,-10000,10000)),
     lambda k,c:rf'For integers $a,b,c$, the monic gcd of $x^2+ax+b$ and $x^2+bx+c$ is $ {polynomial([k,1])}$ and their monic lcm is $ {polynomial(c)}$. Find $a+b+c$.',
     lambda k,c:next(iter(lcm_system_sums(k,c))),
     valid=lambda k,c:len(lcm_system_sums(k,c))==1,sample=lcm_sample,
     constraints=('The lcm coefficients are in ascending powers and define a monic cubic. At least one linked integral pair exists, and all pairs give the same requested sum.',))


def real_quadratic_rational_roots(a,b):
    discriminant=a*a-4*b
    if not is_square(discriminant):
        return []
    d=isqrt(discriminant)
    return [F(-a+d,2),F(-a-d,2)]


def rational_at_root(r):
    return (r**3-1)/(r**5+r**4-r**3-r**2)


def rational_at_valid(a,b):
    roots=real_quadratic_rational_roots(a,b)
    return len(roots)==2 and all(r not in (-1,0,1) for r in roots)


def rational_at_sample(rng):
    u,v=rng.sample([*range(-24,-1),*range(2,25)],2)
    return -u-v,u*v


bind('t536','largest_rational_function_at_quadratic_roots','linear constant',(2,-15),
     (I(-80,80),I(-600,600)),
     lambda a,b:rf'If $r$ is a root of $ {polynomial([b,a,1])}=0$, what is the greatest possible value of $\frac{{r^3-1}}{{r^5+r^4-r^3-r^2}}$? Express your answer as a common fraction.',
     lambda a,b:max(map(rational_at_root,real_quadratic_rational_roots(a,b))),
     valid=rational_at_valid,sample=rational_at_sample,
     constraints=('All quadratic roots are rational, and none equals −1, 0 or 1, the poles of the expression.',))


def rational_three_term_roots(h,a,b,c):
    if len({a,b,c})!=3 or a+b==2*c:
        return []
    y=F(2*a*b-c*(a+b),a+b-2*c)
    disc=h*h+4*y
    if not is_square(disc):
        return []
    root=sqrt_fraction(disc)
    return sorted({z for z in (F(h+root,2),F(h-root,2)) if z>0})


def rational_three_term_sample(rng):
    h=rng.randint(2,30)
    k=rng.randint(1,20)
    x=h+rng.randint(1,20)
    y=x*x-h*x
    # Make the three denominators at x equal to 6k, 3k and 4k.
    return h,y-6*k,y-3*k,y-4*k


bind('t571','three_reciprocal_terms_shared_quadratic','linear first second third',(10,29,45,69),
     (I(-50,50),)+(I(-1000,3000),)*3,
     lambda h,a,b,c:rf'Find the positive solution of $\frac1{{{polynomial([-a,-h,1])}}}+\frac1{{{polynomial([-b,-h,1])}}}-\frac2{{{polynomial([-c,-h,1])}}}=0$.',
     lambda h,a,b,c:rational_three_term_roots(h,a,b,c)[0],
     valid=lambda h,a,b,c:len(rational_three_term_roots(h,a,b,c))==1,
     sample=rational_three_term_sample,
     constraints=('The three denominator constants are distinct, and clearing denominators gives one positive rational solution.',))


def weighted_root_power(u,v,a,b):
    # Monic x²−u*x+v gives x³=(u²−v)x−uv and x⁴=(u³−2uv)x+v²−u²v.
    c,d=u*(u*u-2*v),u*u-v
    if c*a!=d*b or u*u<=4*v:
        raise ValueError('Expected two distinct real roots with cancelled linear terms')
    return a*c*u+a*(v*v-u*u*v)-b*u*v


def weighted_root_valid(u,v,a,b):
    return u*u>4*v and a*u*(u*u-2*v)==b*(u*u-v)


def weighted_root_sample(rng):
    u,v=rng.randint(1,20),-rng.randint(1,30)
    c,d=u*(u*u-2*v),u*u-v
    g=gcd(c,d)
    return u,v,d//g,c//g


bind('r1169','weighted_conjugate_powers_reduce_to_rational','sum product first second',(2,-1,5,12),
     (I(1,30),I(-50,50),I(1,30000),I(1,30000)),
     lambda u,v,a,b:rf'Given that $\alpha,\beta$ are the roots of $ {polynomial([v,-u,1])}=0$, find $ {a}\alpha^4+{b}\beta^3$.',
     weighted_root_power,valid=weighted_root_valid,sample=weighted_root_sample,
     constraints=('There are two distinct real roots. The linear terms in the cubic and quartic root reductions cancel when expressed using their sum.',))
