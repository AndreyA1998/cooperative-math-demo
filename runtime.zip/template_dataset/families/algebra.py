"""Exact templates for algebra and intermediate algebra statements."""

from fractions import Fraction
from math import isqrt, prod
import re

from template_dataset.core import Template


def _integer_domain(low, high):
    return {"type": "int", "min": low, "max": high}


def _template(family, original, parameters, render, solve, reference=None,
              check=lambda p: True, constraints=(), sample=None, adaptation=""):
    def validate(p):
        if not isinstance(p, dict) or p.keys() != parameters.keys():
            return False
        for key, domain in parameters.items():
            value = p[key]
            if type(value) is not int:
                return False
            if "choices" in domain:
                if value not in domain["choices"]:
                    return False
            elif not domain["min"] <= value <= domain["max"]:
                return False
        return check(p)

    def random_parameters(rng):
        for _ in range(128):
            proposal = {
                key: rng.choice(domain["choices"]) if "choices" in domain
                else rng.randint(domain["min"], domain["max"])
                for key, domain in parameters.items()
            }
            if validate(proposal):
                return proposal
        return dict(original)

    return Template(
        family=family, parameters=parameters, original=original, render=render,
        solve=solve, reference=reference, sample=sample or random_parameters,
        validate=validate, constraints=list(constraints), adaptation=adaptation,
    )


_COORDINATE_CASES = {
    # ID: task, signed numbers in the order shown in the original coordinates.
    "train/117": ("midpoint_sum", (8, 5, 2, -1)),
    "train/307": ("other_sum", (4, 4, 8, 4)),
    "train/343": ("other_sum", (6, -10, 8, 0)),
    "train/440": ("midpoint_product", (2, 3, -6, 5)),
    "train/491": ("midpoint_sum", (2, 5, 4, 9)),
    "train/534": ("other_product", (2, 5, 3, 1)),
    "train/564": ("midpoint_sum", (6, 12, 0, -6)),
    "train/912": ("slope", (-3, 5, 2, -5)),
    "train/988": ("midpoint_sum", (2, 3, 8, 15)),
    "train/1088": ("other_sum", (2, 9, 4, 3)),
    "train/1564": ("other_product", (3, 5, 1, 8)),
    "train/1581": ("other_sum", (3, 7, 9, 3)),
    "test/13": ("midpoint_sum", (1, 4, 1, 10)),
    "test/218": ("other_sum", (1, -6, -2, 1)),
    "test/310": ("midpoint_sum", (3, 1, 5, 1)),
    "test/633": ("other_sum", (1, 1, 6, 8)),
    "test/780": ("other_sum", (1, 2, 3, 9)),
    "test/818": ("slope_intercept_sum", (7, 8, 9, 0)),
    "test/936": ("perpendicular_slope", (-1, 2, 1, -2)),
    "test/975": ("midpoint_sum", (5, 4, -9, 8)),
    "test/1072": ("midpoint_product", (1, 1, -7, 5)),
}

_LINE_CASES = {
    "train/209": (2, 3, 6, True),
    "train/796": (2, -4, 9, False),
    "train/981": (2, 4, -17, False),
    "train/1285": (3, 5, 20, False),
}


def _coordinate_template(problem, task, values):
    names = ("x1", "y1", "x2", "y2")
    original = dict(zip(names, values))
    parameters = {name: _integer_domain(-25, 25) for name in names}
    point_expression = re.compile(r"\(\s*(-?\d+)\s*,\s*(-?\d+)\s*\)")
    slots = list(point_expression.finditer(problem))
    displayed = tuple(int(group) for slot in slots for group in slot.groups())
    flip = task.startswith("other_") and displayed == values[2:] + values[:2]
    if len(slots) != 2 or displayed != (values[2:] + values[:2] if flip else values):
        return None

    def render(p):
        pairs = [(p["x1"], p["y1"]), (p["x2"], p["y2"])]
        if flip:
            pairs.reverse()
        replacements = iter(f"({x}, {y})" for x, y in pairs)
        return point_expression.sub(lambda _: next(replacements), problem)

    def check(p):
        if task in ("slope", "slope_intercept_sum"):
            return p["x1"] != p["x2"]
        if task == "perpendicular_slope":
            return p["y1"] != p["y2"]
        return (p["x1"], p["y1"]) != (p["x2"], p["y2"])

    def solve(p):
        x, y, u, v = (p[name] for name in names)
        if task == "perpendicular_slope":
            return Fraction(x - u, v - y)
        if task.startswith("slope"):
            slope = Fraction(v - y, u - x)
            return slope if task == "slope" else slope + y - slope * x
        if task.startswith("midpoint"):
            a, b = Fraction(x + u, 2), Fraction(y + v, 2)
        else:
            a, b = 2 * x - u, 2 * y - v
        return a + b if task.endswith("_sum") else a * b

    def reference(p):
        x, y, u, v = (p[name] for name in names)
        if task.startswith("midpoint"):
            return (Fraction(x + y + u + v, 2) if task.endswith("_sum")
                    else Fraction(x * y + x * v + u * y + u * v, 4))
        if task.startswith("other"):
            return (2 * (x + y) - (u + v) if task.endswith("_sum")
                    else 4 * x * y - 2 * (x * v + y * u) + u * v)
        if task == "perpendicular_slope":
            return Fraction(u - x, y - v)
        return (Fraction(y - v, x - u) if task == "slope"
                else Fraction(v - y + y * u - x * v, u - x))

    constraint = {
        "slope": "x1 != x2",
        "slope_intercept_sum": "x1 != x2",
        "perpendicular_slope": "y1 != y2",
    }.get(task, "The given points are distinct.")
    return _template("algebra.coordinate." + task, original, parameters, render,
                     solve, reference, check, [constraint])


def _line_template(problem, values):
    a, b, c, perpendicular = values
    original = dict(a=a, b=b, c=c)
    parameters = {key: _integer_domain(-30, 30) for key in original}

    def render(p):
        equation = f'${p["a"]}x {"-" if p["b"] < 0 else "+"} {abs(p["b"])}y = {p["c"]}$'
        return re.sub(r"\$[^$]+\$", lambda _: equation, problem, count=1)

    def solve(p):
        return Fraction(p["b"], p["a"]) if perpendicular else Fraction(-p["a"], p["b"])

    def reference(p):
        x_intercept = Fraction(p["c"], p["a"])
        y_intercept = Fraction(p["c"], p["b"])
        return x_intercept / y_intercept if perpendicular else -y_intercept / x_intercept

    def check(p):
        return all(p.values())

    return _template(
        "algebra.line.slope", original, parameters, render, solve, reference, check,
        ["All three coefficients are nonzero, so both intercepts and requested slopes are defined."],
    )


class _ParseError(ValueError):
    pass


class _MathParser:
    """Parse the supported TeX arithmetic, recording each variable numeric literal."""

    _spacing = re.compile(r"\s+|~|\\(?:left|right|displaystyle|,|!|;| )")
    _number = re.compile(r"(?:[0-9]+(?:\.[0-9]+)?|\.[0-9]+)")
    _operators = {"+": (1, "+"), "-": (1, "-"), "*": (2, "*"), "/": (2, "/"),
                  r"\times": (2, "*"), r"\cdot": (2, "*"), r"\div": (2, "/")}

    def __init__(self, source):
        self.source = source
        self.offset = 0
        self.literals = []

    def _skip(self):
        while True:
            match = self._spacing.match(self.source, self.offset)
            if match is None:
                return
            self.offset = match.end()

    def _peek(self):
        self._skip()
        if self.offset == len(self.source):
            return ""
        if self.source[self.offset] == "\\":
            match = re.match(r"\\[A-Za-z]+", self.source[self.offset:])
            if match:
                return match.group()
        return self.source[self.offset]

    def _take(self, token):
        if self._peek() != token:
            raise _ParseError(token)
        self.offset += len(token)

    def _number_node(self, freeze, single=False):
        start = self.offset
        match = self._number.match(self.source, start)
        if not match:
            raise _ParseError("number")
        self.offset = start + 1 if single else match.end()
        source = self.source[start:self.offset]
        value = Fraction(source)
        if freeze:
            return ("const", value)
        self.literals.append((start, self.offset, value, single))
        return ("literal", len(self.literals) - 1)

    def _argument(self, freeze):
        symbol = self._peek()
        if symbol == "{":
            self._take("{")
            node = self._expr(0, freeze)
            self._take("}")
            return node
        if symbol in "0123456789" and symbol:
            return self._number_node(freeze, single=True)
        if len(symbol) == 1 and symbol.isascii() and symbol.isalpha():
            self._take(symbol)
            return ("var", symbol)
        raise _ParseError("unsupported TeX argument")

    def _atom(self, freeze):
        symbol = self._peek()
        if symbol in ("+", "-"):
            self._take(symbol)
            child = self._expr(3, freeze)
            return child if symbol == "+" else ("neg", child)
        if symbol in ("(", "{", "["):
            self._take(symbol)
            node = self._expr(0, freeze)
            self._take({"(": ")", "{": "}", "[": "]"}[symbol])
        elif symbol in (r"\frac", r"\dfrac", r"\tfrac"):
            self._take(symbol)
            node = ("/", self._argument(freeze), self._argument(freeze))
        elif symbol == r"\sqrt":
            self._take(symbol)
            node = ("sqrt", self._argument(freeze))
        elif symbol and (symbol[0].isdigit() or symbol == "."):
            node = self._number_node(freeze)
        elif len(symbol) == 1 and symbol.isascii() and symbol.isalpha():
            self._take(symbol)
            if symbol in "fgh" and self._peek() == "(":
                self._take("(")
                node = ("call", symbol, self._expr(0, freeze))
                self._take(")")
            else:
                node = ("var", symbol)
        else:
            raise _ParseError("unsupported token")
        return self._powered(node)

    def _powered(self, node):
        if self._peek() == "^":
            self._take("^")
            exponent = self._argument(True)
            if exponent[0] == "neg" and exponent[1][0] == "const":
                exponent = ("const", -exponent[1][1])
            if exponent[0] != "const" or exponent[1].denominator != 1 or abs(exponent[1]) > 12:
                raise _ParseError("unsupported power")
            node = ("^", node, exponent)
        return node

    def _expr(self, min_priority, freeze):
        node = self._atom(freeze)
        while True:
            symbol = self._peek()
            implicit = (symbol in ("(", "{", "[", r"\frac", r"\dfrac", r"\tfrac", r"\sqrt")
                        or len(symbol) == 1 and symbol.isascii() and symbol.isalpha())
            if not implicit and symbol not in self._operators:
                break
            if symbol in (r"\frac", r"\dfrac", r"\tfrac") and node[0] in ("const", "literal"):
                raise _ParseError("ambiguous mixed fraction")
            priority, operator = (2, "*") if implicit else self._operators[symbol]
            if priority < min_priority:
                break
            if not implicit:
                self._take(symbol)
            node = (operator, node, self._expr(priority + 1, freeze))
        return node

    def parse(self):
        node = self._expr(0, False)
        if self._peek():
            raise _ParseError("trailing input")
        return node, self.literals


def _evaluate(node, values, variables, functions):
    op = node[0]
    if op == "const":
        return node[1]
    if op == "literal":
        return values[node[1]]
    if op == "var":
        return variables[node[1]]
    if op == "call":
        variable, definition, literals = functions[node[1]]
        argument = _evaluate(node[2], values, variables, functions)
        return _evaluate(definition, literals, {variable: argument}, {})
    a = _evaluate(node[1], values, variables, functions)
    if op == "neg":
        return -a
    if op == "sqrt":
        n, d = isqrt(a.numerator), isqrt(a.denominator)
        if n * n != a.numerator or d * d != a.denominator:
            raise ValueError("irrational square root")
        return Fraction(n, d)
    b = _evaluate(node[2], values, variables, functions)
    if op == "+":
        return a + b
    if op == "-":
        return a - b
    if op == "*":
        return a * b
    if op == "/":
        return a / b
    if op == "^":
        return a ** int(b)
    raise AssertionError(op)


_MATH_BLOCK = re.compile(r"\$\$([^$]+)\$\$|\$([^$]+)\$|\\\[([\s\S]+?)\\\]")
_PREFIX = r"(?:if|given(?: that| the two functions)?|suppose(?: that)?|let|define|consider the function)"
_JOIN = r"\s*(?:,\s*)?(?:and\s*(?:let\s+)?)?"
_QUERY = (
    r"(?:what is(?: the (?:numerical )?value of)?|"
    r"(?:find|evaluate|compute)(?: the (?:numerical )?value of)?)"
)
_SUFFIX = (
    r"\s*[.?!]?\s*(?:Express your answer (?:as a (?:simplified )?common fraction|"
    r"as a fraction|in simplest form)\s*\.)?\s*"
)
_DEFINITION_WRAPPER = re.compile(
    rf"(?i)(?:{_PREFIX}\s+)?(@(?:{_JOIN}@){{0,3}})\s*[.,]?\s*(?:then\s+)?{_QUERY}\s+@{_SUFFIX}"
)
_REVERSE_DEFINITION = re.compile(
    rf"(?i){_QUERY}\s+@\s+(?:if|given(?: that)?)\s+@(?:{_JOIN}@){{0,3}}{_SUFFIX}"
)
_NAMED_DEFINITION = re.compile(
    rf"(?i)the function @ is defined by @\s*[.,]\s*{_QUERY}\s+@{_SUFFIX}"
)
_SOLVE_PREFIX = re.compile(rf"(?i)solve for @\s*:\s*@{_SUFFIX}")
_SOLVE_SUFFIX = re.compile(rf"(?i)solve(?: the equation)?\s*@\s*for @(?:[.?])?{_SUFFIX}")
_EQUATION_LAST = re.compile(
    rf"(?i)(?:solve for @ in the equation|what is the value of @ in the equation|"
    rf"find the value of @ (?:such that|that satisfies(?: the equation)?)|"
    rf"for what value of @ is(?: the following equation true:)?|"
    rf"solve for @ and express as a common fraction:)\s+@{_SUFFIX}"
)
_SINGLE_VARIABLE = re.compile(r"\s*([a-zA-Z])\s*[.,]?\s*")


def _math_body(block):
    group = next(group for group in block.groups() if group is not None)
    cleaned = group.rstrip().rstrip(".,?").rstrip()
    return cleaned, block.start(next(i for i, value in enumerate(block.groups(), 1)
                                     if value is not None))


_LITERAL_TIES = {
    "algebra/train/566": (1, 2, 3),
    "algebra/train/464": (2, 4, 6),
    "algebra/train/938": (2, 4, 5),
    "algebra/train/1326": (4, 5),
    "algebra/train/1410": (2, 4, 6),
    "algebra/train/1521": (2, 3),
    "algebra/train/1711": (4, 5),
}


class _LiteralParameters:
    def __init__(self, tied=()):
        groups = (tied,) if tied and isinstance(tied[0], int) else tied
        self.tied = {position: group[0] for group in groups for position in group}
        self.original = {}
        self.parameters = {}
        self.spans = []

    def parse(self, source, offset, parser=_MathParser):
        tree, literals = parser(source).parse()
        encoded = []
        for start, end, value, single in literals:
            raw = source[start:end]
            places = len(raw.split(".")[1]) if "." in raw else 0
            scale = 10 ** places
            mantissa = int(value * scale)
            position = len(self.spans) + 1
            name = f"literal_{self.tied.get(position, position)}"
            maximum = max(12 * scale, mantissa * 2)
            minimum = 1 if mantissa else 0
            if single:
                # A single-digit literal can be an unbraced TeX argument.
                maximum = min(9, maximum)
            if name in self.original and self.original[name] != mantissa:
                raise _ParseError("inconsistent tied literals")
            self.original[name] = mantissa
            self.parameters[name] = _integer_domain(minimum, maximum)
            self.spans.append((offset + start, offset + end, name, places))
            encoded.append((name, scale))
        return tree, encoded

    @staticmethod
    def values(encoded, p):
        return tuple(Fraction(p[name], scale) for name, scale in encoded)

    def render(self, problem, p):
        for start, end, name, places in sorted(self.spans, reverse=True):
            number = str(p[name])
            if places:
                number = number.zfill(places + 1)
                number = number[:-places] + "." + number[-places:]
            problem = problem[:start] + number + problem[end:]
        return problem


def _function_or_substitution(problem, tied):
    blocks = list(_MATH_BLOCK.finditer(problem))
    if len(blocks) < 2:
        return None
    skeleton = _MATH_BLOCK.sub("@", problem)
    if _NAMED_DEFINITION.fullmatch(skeleton):
        if _math_body(blocks[0])[0].replace(" ", "") != _math_body(blocks[1])[0].split("=")[0].replace(" ", ""):
            return None
        blocks = blocks[1:]
    elif _REVERSE_DEFINITION.fullmatch(skeleton):
        blocks = blocks[1:] + blocks[:1]
    elif not _DEFINITION_WRAPPER.fullmatch(skeleton):
        return None
    functions, givens, equations = {}, {}, []
    parameters = _LiteralParameters(tied)
    try:
        for block in blocks[:-1]:
            source, offset = _math_body(block)
            left, right = source.split("=")
            function = re.fullmatch(r"\s*([fgh])\s*\(\s*([a-zA-Z])\s*\)\s*", left)
            if function:
                name, variable = function.groups()
                if name in functions:
                    return None
                functions[name] = (variable, *parameters.parse(right, offset + len(left) + 1))
                continue
            single = re.fullmatch(r"\s*([a-zA-Z])\s*", left)
            if single:
                if single.group(1) in givens:
                    return None
                givens[single.group(1)] = parameters.parse(right, offset + len(left) + 1)
            equations.append((left, right, offset))
        if functions and equations:
            return None
        source, offset = _math_body(blocks[-1])
        question = parameters.parse(source, offset)
    except (ValueError, RecursionError):
        return None

    if equations and len(givens) != len(equations):
        affine = _linear_system(problem, equations, query_block=blocks[-1], tied=tied)
        if affine is not None or len(equations) != 1:
            return affine
        return _rational_equation(problem, equations[0], blocks[-1], tied)

    def solve(p):
        bindings = {name: _evaluate(tree, parameters.values(nums, p), {}, {})
                    for name, (tree, nums) in givens.items()}
        definitions = {name: (variable, tree, parameters.values(nums, p))
                       for name, (variable, tree, nums) in functions.items()}
        tree, nums = question
        return _evaluate(tree, parameters.values(nums, p), bindings, definitions)

    family = "algebra.function_evaluation" if functions else "algebra.expression_substitution"
    return _expression_template(family, problem, parameters, solve)


def _expression_template(family, problem, parameters, solve, reference=None, constraints=(),
                         arithmetic_constraint="Every denominator must be nonzero and every evaluated square root must be rational."):
    if not parameters.original or not any(
        domain["min"] != domain["max"] for domain in parameters.parameters.values()
    ):
        return None

    def check(p):
        try:
            solve(p)
        except (ArithmeticError, ValueError, KeyError, RecursionError):
            return False
        return True

    if not check(parameters.original):
        return None
    decimal_scales = [
        f"{name} is displayed divided by {10 ** places}."
        for _, _, name, places in parameters.spans if places
    ]
    return _template(
        family, parameters.original, parameters.parameters,
        lambda p: parameters.render(problem, p), solve, reference, check,
        [arithmetic_constraint, *decimal_scales, *constraints],
    )


def _affine(node, values, names):
    op = node[0]
    zero = (Fraction(0),) * len(names)
    if not _variables(node):
        return zero + (_evaluate(node, values, {}, {}),)
    if op == "var":
        return tuple(Fraction(name == node[1]) for name in names) + (Fraction(0),)
    a = _affine(node[1], values, names)
    if op == "neg":
        return tuple(-term for term in a)
    if op in ("sqrt", "call"):
        raise ValueError("unsupported affine expression")
    b = _affine(node[2], values, names)
    if op in ("+", "-"):
        sign = 1 if op == "+" else -1
        return tuple(x + sign * y for x, y in zip(a, b))
    if op == "*":
        if not any(a[:-1]):
            return tuple(a[-1] * term for term in b)
        if not any(b[:-1]):
            return tuple(b[-1] * term for term in a)
    if op == "/" and not any(b[:-1]):
        return tuple(term / b[-1] for term in a)
    raise ValueError("non-affine expression")


def _variables(node):
    op = node[0]
    if op == "var":
        return {node[1]}
    if op in ("const", "literal"):
        return set()
    if op == "call":
        raise ValueError("unexpected function")
    if op in ("neg", "sqrt"):
        return _variables(node[1])
    return _variables(node[1]) | _variables(node[2])


def _determinant(rows):
    if len(rows) == 1:
        return rows[0][0]
    return sum(
        (-1) ** column * entry
        * _determinant([row[:column] + row[column + 1:] for row in rows[1:]])
        for column, entry in enumerate(rows[0])
    )


def _linear_system(problem, equations, query_block, tied):
    parameters = _LiteralParameters(tied)
    parsed = []
    names = set()
    try:
        for left, right, offset in equations:
            lhs = parameters.parse(left, offset)
            rhs = parameters.parse(right, offset + len(left) + 1)
            names |= _variables(lhs[0]) | _variables(rhs[0])
            parsed.append((lhs, rhs))
        question = parameters.parse(*_math_body(query_block))
        if not _variables(question[0]) <= names:
            return None
    except (ValueError, RecursionError):
        return None
    names = sorted(names)
    if len(names) != len(parsed) or len(parsed) not in (1, 2, 3, 4):
        return None

    def matrix(p):
        rows = []
        for (left, left_nums), (right, right_nums) in parsed:
            a = _affine(left, parameters.values(left_nums, p), names)
            b = _affine(right, parameters.values(right_nums, p), names)
            rows.append(tuple(x - y for x, y in zip(a, b)))
        return rows

    def output(solutions, p):
        tree, nums = question
        return _evaluate(tree, parameters.values(nums, p), dict(zip(names, solutions)), {})

    def solve(p):
        rows = [list(row) for row in matrix(p)]
        for column in range(len(rows)):
            pivot = next((k for k in range(column, len(rows)) if rows[k][column]), None)
            if pivot is None:
                raise ValueError("singular system")
            rows[column], rows[pivot] = rows[pivot], rows[column]
            denominator = rows[column][column]
            rows[column] = [term / denominator for term in rows[column]]
            for index, row in enumerate(rows):
                if index != column:
                    coefficient = row[column]
                    rows[index] = [a - coefficient * b for a, b in zip(row, rows[column])]
        return output([-row[-1] for row in rows], p)

    def reference(p):
        rows = matrix(p)
        coefficients = [row[:-1] for row in rows]
        determinant = _determinant(coefficients)
        result = []
        for column in range(len(rows)):
            replaced = [row[:column] + (-row[-1],) + row[column + 1:-1] for row in rows]
            result.append(_determinant(replaced) / determinant)
        return output(result, p)

    return _expression_template(
        "algebra.linear_equation" if len(parsed) == 1 else "algebra.linear_system",
        problem, parameters, solve, reference,
        ["The affine coefficient matrix is nonsingular."],
    )


def _solve_statement(problem, tied):
    blocks = list(_MATH_BLOCK.finditer(problem))
    if len(blocks) != 2:
        return None
    skeleton = _MATH_BLOCK.sub("@", problem)
    if _SOLVE_PREFIX.fullmatch(skeleton) or _EQUATION_LAST.fullmatch(skeleton):
        variable_block, equation_block = blocks
    elif _SOLVE_SUFFIX.fullmatch(skeleton):
        equation_block, variable_block = blocks
    else:
        return None
    variable = _SINGLE_VARIABLE.fullmatch(_math_body(variable_block)[0])
    equation, offset = _math_body(equation_block)
    if not variable or equation.count("=") != 1:
        return None
    left, right = equation.split("=")
    givens = (left, right, offset)
    return (_linear_system(problem, [givens], query_block=variable_block, tied=tied)
            or _rational_equation(problem, givens, variable_block, tied))


# Each entry gives one displayed value (as a rational), an arithmetic step,
# and the indices of the two givens and requested term.
_ARITHMETIC_ANCHORS = {
    "train/31": (5, 2, 1, 13, 50),
    "train/77": (1, 9, 1, 2, 21),
    "train/177": (1, 3, 1, 2, 15),
    "train/481": (2, 3, 1, 20, 5),
    "train/545": (8, 2, 16, 17, 2),
    "train/775": (2, 3, 1, 2, 25),
    "train/1159": (17, 11, 3, 5, 7),
    "train/1204": (17, Fraction(2, 3), 2, 5, 8),
    "train/1239": (Fraction(2, 3), Fraction(1, 3), 1, 2, 8),
    "test/5": (6, 4, 1, 2, 100),
    "test/577": (5, -2, 3, 6, 12),
    "test/1119": (200, 75, 4, 8, 6),
}

# First term, common ratio, index of second given, requested term.
_GEOMETRIC_ANCHORS = {
    "train/84": (3, 4, 4, 3),
    "train/86": (2, 3, 5, 6),
    "train/529": (3, Fraction(3, 2), 2, 8),
    "train/574": (9, Fraction(1, 3), 2, 10),
    "train/1264": (6, -1, 2, 205),
    "train/1515": (2, Fraction(1, 8), 2, 5),
}

_GEOMETRIC_SUMS = {
    "train/660": (Fraction(1, 3), Fraction(1, 3), 1, 5),
    "train/1707": (Fraction(1, 2), Fraction(1, 2), 1, 6),
    "test/1036": (1, Fraction(1, 2), 5, 2),
}


def _arithmetic_anchor(case, finite=False):
    anchor, step, i, j, k = case
    anchor, step = Fraction(anchor), Fraction(step)
    original = dict(
        anchor_numerator=anchor.numerator, anchor_denominator=anchor.denominator,
        step_numerator=step.numerator, step_denominator=step.denominator,
        first_index=i, second_index=j, target_index=k,
    )
    parameters = {
        "anchor_numerator": _integer_domain(-30, max(30, anchor.numerator)),
        "anchor_denominator": _integer_domain(1, 8),
        "step_numerator": _integer_domain(-20, max(20, step.numerator)),
        "step_denominator": _integer_domain(1, 8),
        "first_index": _integer_domain(1, 1 if finite else 30),
        "second_index": _integer_domain(3 if finite else 2, 40),
        "target_index": _integer_domain(2 if finite else 1, 39 if finite else 100),
    }

    def given(p):
        a = Fraction(p["anchor_numerator"], p["anchor_denominator"])
        d = Fraction(p["step_numerator"], p["step_denominator"])
        i, j, k = (p[key] for key in ("first_index", "second_index", "target_index"))
        return a, a + (j - i) * d, i, j, k

    def render(p):
        a, b, i, j, k = given(p)
        if finite:
            return (f"An arithmetic sequence has {j} terms. Its first and last terms are "
                    f"${_tex(a)}$ and ${_tex(b)}$. What is term {k}? Give the exact value.")
        return (f"In an arithmetic sequence, term {i} is ${_tex(a)}$ and term {j} is "
                f"${_tex(b)}$. What is term {k}? Give the exact value.")

    def solve(p):
        a, b, i, j, k = given(p)
        return a + Fraction(k - i, j - i) * (b - a)

    def reference(p):
        a, b, i, j, k = given(p)
        step = (b - a) / (j - i)
        terms = [a]
        for _ in range(abs(k - i)):
            terms.append(terms[-1] + (step if k > i else -step))
        return terms[-1]

    def check(p):
        return (p["first_index"] < p["second_index"]
                and p["target_index"] not in (p["first_index"], p["second_index"])
                and p["step_numerator"] != 0
                and (not finite or p["first_index"] < p["target_index"] < p["second_index"]))

    constraints = ["The two given indices are increasing, the target index differs from both, "
                   "and the common difference is nonzero."]
    if finite:
        constraints.append("The given indices are the endpoints of the finite sequence. "
                           "The requested term is strictly between them.")
    return _template(
        "algebra.arithmetic_sequence.term", original, parameters, render, solve, reference,
        check, constraints,
        adaptation="Equivalent index notation; only two known terms are displayed "
                   "when the source lists redundant terms.",
    )


def _tex(value):
    value = Fraction(value)
    if value.denominator == 1:
        return str(value.numerator)
    sign = "-" if value < 0 else ""
    return rf"{sign}\frac{{{abs(value.numerator)}}}{{{value.denominator}}}"


def _geometric_anchor(case, positive_integers):
    first, ratio, j, k = case
    first, ratio = Fraction(first), Fraction(ratio)
    if positive_integers:
        ratio_choices = list(range(2, 7))
        denominator_choices = [1]
    elif k == 205:
        ratio_choices = [-1, 1]
        denominator_choices = [1]
    else:
        ratio_choices = [-5, -4, -3, -2, -1, 1, 2, 3, 4, 5]
        denominator_choices = list(range(1, 9))
    original = dict(
        first_numerator=first.numerator, first_denominator=first.denominator,
        ratio_numerator=ratio.numerator, ratio_denominator=ratio.denominator,
        second_index=j, target_index=k,
    )
    parameters = {
        "first_numerator": _integer_domain(1, 20),
        "first_denominator": _integer_domain(1, 1 if positive_integers else 8),
        "ratio_numerator": {"type": "int", "choices": ratio_choices},
        "ratio_denominator": {"type": "int", "choices": denominator_choices},
        "second_index": _integer_domain(2, 6 if positive_integers else 2),
        "target_index": _integer_domain(2, 205 if k == 205 else 12),
    }

    def given(p):
        a = Fraction(p["first_numerator"], p["first_denominator"])
        r = Fraction(p["ratio_numerator"], p["ratio_denominator"])
        return a, r, p["second_index"], p["target_index"]

    def render(p):
        a, r, j, k = given(p)
        description = "a geometric sequence" + (" of positive integers" if positive_integers else "")
        return (f"In {description}, the first term is ${_tex(a)}$ and term {j} "
                f"is ${_tex(a * r ** (j - 1))}$. What is term {k}? Give the exact value.")

    def solve(p):
        a, r, _, k = given(p)
        return a * r ** (k - 1)

    def reference(p):
        a, r, j, k = given(p)
        second = a * r ** (j - 1)
        candidates = (Fraction(n, d) for n in ratio_choices for d in denominator_choices)
        inferred = next(q for q in candidates if a * q ** (j - 1) == second)
        result = a
        for _ in range(k - 1):
            result *= inferred
        return result

    return _template(
        "algebra.geometric_sequence.term", original, parameters, render, solve, reference,
        lambda p: p["target_index"] != p["second_index"],
        ["The target term differs from both given terms. The ratio is uniquely determined "
         "by the stated positivity or by adjacent given terms."],
        adaptation="Equivalent index notation; redundant prefix terms are omitted.",
    )


def _geometric_sum(case):
    first, ratio, start, count = case
    original = dict(
        first_numerator=first.numerator, first_denominator=first.denominator,
        ratio_numerator=ratio.numerator, ratio_denominator=ratio.denominator,
        start=start, count=count,
    )
    parameters = {
        "first_numerator": _integer_domain(1, 9),
        "first_denominator": _integer_domain(1, 9),
        "ratio_numerator": _integer_domain(-3, 3),
        "ratio_denominator": _integer_domain(1, 7),
        "start": _integer_domain(1, 8),
        "count": _integer_domain(2, 10),
    }

    def given(p):
        return (Fraction(p["first_numerator"], p["first_denominator"]),
                Fraction(p["ratio_numerator"], p["ratio_denominator"]),
                p["start"], p["count"])

    def render(p):
        a, r, i, n = given(p)
        return (rf"A geometric sequence begins ${_tex(a)}, {_tex(a*r)}, {_tex(a*r*r)}, \ldots$. "
                f"Find the sum of terms {i} through {i + n - 1} inclusive.")

    def solve(p):
        a, r, i, n = given(p)
        factor = n if r == 1 else (1 - r**n) / (1 - r)
        return a * r**(i - 1) * factor

    def reference(p):
        a, r, i, n = given(p)
        return sum(a * r**k for k in range(i - 1, i + n - 1))

    return _template(
        "algebra.geometric_sequence.sum", original, parameters, render, solve, reference,
        lambda p: p["ratio_numerator"] != 0,
        ["The common ratio is nonzero."],
        adaptation="The requested block of terms is given by its inclusive indices.",
    )


def build(row):
    """Bind a complete recognized statement or a curated source ID."""
    problem = row["problem"]
    subject, short_id = row["id"].split("/", 1)
    if subject == "algebra":
        if short_id in _INVERSE_PROPORTIONS:
            return _inverse_proportion(_INVERSE_PROPORTIONS[short_id])
        if short_id in _EXPONENTIAL_EQUATIONS:
            return _exponential_equation(_EXPONENTIAL_EQUATIONS[short_id])
        if short_id in _COORDINATE_CASES:
            return _coordinate_template(problem, *_COORDINATE_CASES[short_id])
        if short_id in _LINE_CASES:
            return _line_template(problem, _LINE_CASES[short_id])
        if short_id in _ARITHMETIC_ANCHORS:
            return _arithmetic_anchor(_ARITHMETIC_ANCHORS[short_id], finite=short_id == "train/481")
        if short_id in _GEOMETRIC_ANCHORS:
            return _geometric_anchor(_GEOMETRIC_ANCHORS[short_id], short_id in ("train/84", "train/86"))
        if short_id in _GEOMETRIC_SUMS:
            return _geometric_sum(_GEOMETRIC_SUMS[short_id])
    tied = _LITERAL_TIES.get(row["id"], ())
    return (_curated_polynomial(row["id"]) or _function_or_substitution(problem, tied)
            or _solve_statement(problem, tied))


def _trim(polynomial):
    while polynomial and polynomial[-1] == 0:
        polynomial.pop()
    return tuple(polynomial)


def _poly_add(a, b, sign=1):
    return _trim([
        (a[i] if i < len(a) else 0) + sign * (b[i] if i < len(b) else 0)
        for i in range(max(len(a), len(b)))
    ])


def _poly_mul(a, b):
    if not a or not b:
        return ()
    if len(a) + len(b) > 26:
        raise ValueError("degree bound exceeded")
    result = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            result[i + j] += x * y
    return _trim(result)


def _poly_divmod(a, b):
    if not b:
        raise ZeroDivisionError
    quotient = [0] * max(0, len(a) - len(b) + 1)
    while len(a) >= len(b):
        index = len(a) - len(b)
        coefficient = Fraction(a[-1], b[-1])
        quotient[index] = coefficient
        a = _poly_add(a, (0,) * index + tuple(coefficient * term for term in b), -1)
    return _trim(quotient), a


def _poly_gcd(a, b):
    while b:
        _, remainder = _poly_divmod(a, b)
        a, b = b, remainder
    return a


def _poly_power(a, exponent):
    product = (Fraction(1),)
    for _ in range(exponent):
        product = _poly_mul(product, a)
    return product


def _rational_polynomials(node, values, variable):
    op = node[0]
    one = (Fraction(1),)
    if not _variables(node):
        scalar = _evaluate(node, values, {}, {})
        return ((scalar,) if scalar else ()), one
    if op == "var":
        if node[1] != variable:
            raise ValueError("additional variable")
        return (Fraction(0), Fraction(1)), one
    a, b = _rational_polynomials(node[1], values, variable)
    if op == "neg":
        return tuple(-term for term in a), b
    if op == "sqrt":
        raise ValueError("unsupported nested radical")
    if op == "^":
        exponent = int(node[2][1])
        if exponent < 0:
            a, b = b, a
        return _poly_power(a, abs(exponent)), _poly_power(b, abs(exponent))
    c, d = _rational_polynomials(node[2], values, variable)
    if op in ("+", "-"):
        if b == d:
            return _poly_add(a, c, 1 if op == "+" else -1), b
        return _poly_add(_poly_mul(a, d), _poly_mul(b, c), 1 if op == "+" else -1), _poly_mul(b, d)
    if op == "*":
        return _poly_mul(a, c), _poly_mul(b, d)
    if op == "/":
        return _poly_mul(a, d), _poly_mul(b, c)
    raise ValueError("unsupported rational expression")


def _rational_square_root(value):
    a, b = isqrt(value.numerator), isqrt(value.denominator)
    if a * a != value.numerator or b * b != value.denominator:
        raise ValueError("square root is irrational")
    return Fraction(a, b)


def _rational_equation(problem, givens, query_block, tied):
    left, right, offset = givens
    parameters = _LiteralParameters(tied)
    variable = _SINGLE_VARIABLE.fullmatch(_math_body(query_block)[0])
    if variable is None:
        return None
    variable = variable[1]
    try:
        lhs, lhs_num = parameters.parse(left, offset)
        rhs, rhs_num = parameters.parse(right, offset + len(left) + 1)
        if _variables(lhs) | _variables(rhs) != {variable}:
            return None
    except (ValueError, RecursionError):
        return None

    # Squaring is used only for an isolated radical with a variable-free right side.
    # Substitution into the original equality rejects extraneous roots and holes.
    radical = lhs[0] == "sqrt" and not _variables(rhs)

    def equation(p):
        lvalues = parameters.values(lhs_num, p)
        rvalues = parameters.values(rhs_num, p)
        if radical:
            a, b = _rational_polynomials(lhs[1], lvalues, variable)
            c = (_evaluate(rhs, rvalues, {}, {}) ** 2,)
            d = (Fraction(1),)
        else:
            a, b = _rational_polynomials(lhs, lvalues, variable)
            c, d = _rational_polynomials(rhs, rvalues, variable)
        if not b or not d:
            raise ZeroDivisionError
        denominator = _poly_mul(b, d)
        numerator = _poly_add(_poly_mul(a, d), _poly_mul(c, b), -1)
        if not numerator:
            raise ValueError("identity")
        while True:
            common = _poly_gcd(numerator, denominator)
            if len(common) < 2:
                return numerator, lvalues, rvalues
            numerator, _ = _poly_divmod(numerator, common)

    def solve(p):
        numerator, lvalues, rvalues = equation(p)
        if len(numerator) == 2:
            c, b = numerator
            candidates = {-c / b}
        elif len(numerator) == 3:
            c, b, a = numerator
            root = _rational_square_root(b * b - 4 * a * c)
            candidates = {(-b + root) / (2 * a), (-b - root) / (2 * a)}
        else:
            raise ValueError("unsupported polynomial degree")
        solutions = []
        for candidate in candidates:
            bindings = {variable: candidate}
            try:
                if _evaluate(lhs, lvalues, bindings, {}) == _evaluate(rhs, rvalues, bindings, {}):
                    solutions.append(candidate)
            except (ArithmeticError, ValueError):
                continue
        if len(solutions) != 1:
            raise ValueError("the original equation lacks a unique rational solution")
        return solutions[0]

    return _expression_template(
        "algebra.isolated_radical_equation" if radical else "algebra.rational_equation",
        problem, parameters, solve, constraints=[
            "After clearing denominators and excluding poles, the polynomial is linear "
            "or quadratic. Exactly one rational candidate satisfies the original equation."
        ],
    )


def _bounded_case(family, entries, render, solve, reference=None,
                  check=lambda p: True, constraints=(), adaptation=""):
    return _template(
        family,
        {key: value for key, value, _, _ in entries},
        {key: _integer_domain(low, high) for key, _, low, high in entries},
        render, solve, reference, check, constraints, adaptation=adaptation,
    )


def _tex_polynomial(coefficients, variable="x"):
    pieces = []
    for exponent, coefficient in reversed(list(enumerate(coefficients))):
        if not coefficient:
            continue
        magnitude = abs(coefficient)
        term = _tex(magnitude) if exponent == 0 or magnitude != 1 else ""
        if exponent:
            term += variable + (f"^{{{exponent}}}" if exponent > 1 else "")
        sign = " - " if coefficient < 0 else " + "
        pieces.append((sign if pieces else "-" if coefficient < 0 else "") + term)
    return "".join(pieces) or "0"


def _factored_quadratic(product):
    def render(p):
        a, b, c = (p[k] for k in ("a", "b", "c"))
        operation = "product" if product else "sum"
        return (f"If $({_tex_polynomial([a, 1])})({_tex_polynomial([b, 1])})={c}$, "
                f"find the {operation} of the possible real values of $x$.")

    def discriminant(p):
        return (p["a"] - p["b"]) ** 2 + 4 * p["c"]

    def solve(p):
        return p["a"] * p["b"] - p["c"] if product else -p["a"] - p["b"]

    def reference(p):
        d = isqrt(discriminant(p))
        a, b = p["a"], p["b"]
        if d * d == discriminant(p):
            x = Fraction(-a - b + d, 2)
            y = Fraction(-a - b - d, 2)
            return x * y if product else x + y
        center = Fraction(-a - b, 2)
        return center * center - Fraction(discriminant(p), 4) if product else 2 * center

    return _bounded_case(
        "algebra.quadratic.factored_vieta", [
            ("a", 2, -12, 12), ("b", -3, -12, 12), ("c", 14, -20, 30),
        ], render, solve, reference, lambda p: discriminant(p) > 0,
        ["The displayed quadratic has two distinct real roots."],
    )


def _quadratic_two_sides(case, difference):
    b, c, d, e = case

    def coefficients(p):
        return p["b"] - p["d"], p["c"] - p["e"]

    def discriminant(p):
        a, c = coefficients(p)
        return a * a - 4 * c

    def check(p):
        delta = discriminant(p)
        return delta > 0 and (not difference or isqrt(delta) ** 2 == delta)

    def render(p):
        left = _tex_polynomial([p["c"], p["b"], 1])
        right = _tex_polynomial([p["e"], p["d"]])
        query = "positive difference between" if difference else "sum of"
        return f"The quadratic ${left}={right}$ has two real solutions. What is the {query} these solutions?"

    def solve(p):
        return isqrt(discriminant(p)) if difference else p["d"] - p["b"]

    def reference(p):
        b, c = coefficients(p)
        center = Fraction(-b, 2)
        if difference:
            half_width = _rational_square_root(center * center - c)
            return (center + half_width) - (center - half_width)
        return 2 * center

    return _bounded_case(
        "algebra.quadratic.two_sides", [
            ("b", b, -12, 12), ("c", c, -20, 30),
            ("d", d, -12, 12), ("e", e, -20, 50),
        ], render, solve, reference, check,
        ["The discriminant is positive." + (" It is a perfect square." if difference else "")],
    )


def _parabola_intercepts(case):
    a, b, c = case

    def render(p):
        poly = _tex_polynomial([p["c"], p["b"], p["a"]], "y")
        return f"How many $y$-intercepts does the graph of the parabola $x={poly}$ have?"

    def solve(p):
        delta = p["b"] ** 2 - 4 * p["a"] * p["c"]
        return 2 if delta > 0 else 1 if delta == 0 else 0

    def reference(p):
        a, b, c = (p[key] for key in ("a", "b", "c"))
        vertex = c - Fraction(b * b, 4 * a)
        return 1 if vertex == 0 else 0 if a * vertex > 0 else 2

    return _bounded_case(
        "algebra.parabola.intercepts", [
            ("a", a, -7, 7), ("b", b, -12, 12), ("c", c, -12, 12),
        ], render, solve, reference, lambda p: p["a"] != 0,
        ["The quadratic coefficient is nonzero."],
    )


def _square_binomial(a, b):
    def render(p):
        terms = _tex_polynomial([0, p["b"], p["a"]])
        return f"For which value of $c$ is ${terms}+c$ the square of a real binomial?"

    def solve(p):
        return Fraction(p["b"] ** 2, 4 * p["a"])

    return _bounded_case(
        "algebra.quadratic.binomial_square", [
            ("a", a, 1, 20), ("b", b, -100, 100),
        ], render, solve, check=lambda p: p["b"] != 0,
        constraints=["The linear coefficient is nonzero."],
    )


def _completed_square(case, task):
    a, b, c = case

    def render(p):
        terms = _tex_polynomial([p["c"], p["b"], p["a"]])
        if task == "vertex":
            return f"The vertex of $y={terms}$ is $(m,n)$. What is $m$?"
        if task == "isolated":
            return (f"After completing the square in ${terms}=0$, the equation is "
                    "$(x+u)^2=v$. What is $v$?")
        if task == "linear_coefficient":
            return (f"Rewrite ${terms}$ as $(ux+v)^2+w$ with integer coefficients. "
                    "What is $uv$?")
        return f"Write ${terms}$ in the form $(x+u)^2+v$. What is $u+v$?"

    def solve(p):
        half = Fraction(p["b"], 2)
        if task == "vertex":
            return -half / p["a"]
        if task == "isolated":
            return half * half - p["c"]
        if task == "linear_coefficient":
            return half
        return half + p["c"] - half * half

    def check(p):
        return task != "linear_coefficient" or p["b"] % 2 == 0

    a_domain = (1, 12) if task == "vertex" else (1, 1)
    return _bounded_case(
        "algebra.quadratic.complete_square", [
            ("a", a, *a_domain), ("b", b, -22, 22), ("c", c, -60, 70),
        ], render, solve, check=check,
        constraints=["b must be even so the square has integer coefficients."]
        if task == "linear_coefficient" else [],
    )


def _conjugate_root(case, cubic):
    center, radicand, sign, probe = case

    def render(p):
        root = rf'{p["center"]} {"+" if sign > 0 else "-"} \sqrt{{{p["radicand"]}}}'
        if cubic:
            return (f"The polynomial equation $x^3+bx+c=0$, where $b,c$ are rational, "
                    f"has ${root}$ as a root. Find its integer root.")
        return (f"An integer-coefficient quadratic polynomial $P$ has ${root}$ as a root. "
                rf'Compute $\frac{{P({p["probe"]})}}{{P({p["center"]})}}$.')

    def solve(p):
        a, b = p["center"], p["radicand"]
        return -2 * a if cubic else Fraction(b - (p["probe"] - a) ** 2, b)

    def reference(p):
        a, d = p["center"], p["radicand"]
        poly = (a * a - d, -2 * a, 1)
        if cubic:
            return next(
                x for x in range(-30, 31)
                if x ** 3 + (-3 * a * a - d) * x + 2 * a * (a * a - d) == 0
            )
        numerator = sum(coef * p["probe"]**k for k, coef in enumerate(poly))
        denominator = sum(coef * a**k for k, coef in enumerate(poly))
        return Fraction(numerator, denominator)

    def check(p):
        return isqrt(p["radicand"]) ** 2 != p["radicand"]

    entries = [("center", center, -12, 12), ("radicand", radicand, 2, 40)]
    if not cubic:
        entries.append(("probe", probe, -12, 12))
    return _bounded_case(
        "algebra.polynomial.conjugate_root", entries, render, solve, reference, check,
        ["The radicand is not a perfect square."],
    )


def _tangent_parabola(case, task):
    a, b, c = case

    def render(p):
        a, c = p["a"], p["c"]
        if task == "coefficient":
            line = _tex_polynomial([0, a])
            return (f"The parabola $y=ux^2+{c}$ is tangent to the line $y={line}$. "
                    "Find $u$.")
        if task == "general_line":
            b = p["b"]
            line = _tex_polynomial([0, a]) + f"{'+' if b > 0 else '-'}{abs(b)}y"
            return f"Find $k$ such that the line ${line}+k=0$ is tangent to $y^2={c}x$."
        line = _tex_polynomial([0, a])
        return f"The line $y={line}+k$ is tangent to $y^2={c}x$. Find $k$."

    def solve(p):
        a, c = p["a"], p["c"]
        if task == "coefficient":
            return Fraction(a * a, 4 * c)
        if task == "general_line":
            return Fraction(c * p["b"] ** 2, 4 * a)
        return Fraction(c, 4 * a)

    def reference(p):
        a, c = p["a"], p["c"]
        if task == "coefficient":
            x = Fraction(2 * c, a)
            return Fraction(a * x - c, x * x)
        if task == "general_line":
            b = p["b"]
            y = Fraction(-c * b, 2 * a)
            return -a * y * y / c - b * y
        y = Fraction(c, 2 * a)
        return y - a * y * y / c

    return _bounded_case(
        "algebra.parabola.tangency", [
            ("a", a, -12, 12),
            *([("b", b, -12, 12)] if task == "general_line" else []),
            ("c", c, 1, 40),
        ], render, solve, reference,
        lambda p: p["a"] != 0 and (task != "general_line" or p["b"] != 0),
        ["The displayed line coefficients and the focal parameter are nonzero."],
    )


def _factor_pair():
    def render(p):
        return (f"Find the smallest positive integer $b$ for which $x^2+bx+{p['product']}$ "
                "factors as a product of two linear polynomials with integer coefficients.")

    def solve(p):
        n = p["product"]
        lower = next(a for a in range(isqrt(n), 0, -1) if n % a == 0)
        return lower + n // lower

    def reference(p):
        n = p["product"]
        return min(a + n // a for a in range(1, n + 1) if n % a == 0)

    return _bounded_case(
        "algebra.quadratic.factor_pair", [("product", 2008, 2, 4000)],
        render, solve, reference,
    )


def _prime_pair():
    def render(p):
        return (f"Both roots of $x^2-{p['sum']}x+k=0$ are prime numbers. "
                "Find the number of possible values of $k$.")

    def is_prime(n):
        return n > 1 and all(n % d for d in range(2, isqrt(n) + 1))

    def solve(p):
        n = p["sum"]
        return sum(is_prime(a) and is_prime(n - a) for a in range(2, n // 2 + 1))

    def reference(p):
        n = p["sum"]
        composite = {a * b for a in range(2, n) for b in range(2, n // a + 1)}
        primes = set(range(2, n)) - composite
        return len({a * (n - a) for a in primes if n - a in primes})

    return _bounded_case(
        "algebra.quadratic.prime_pair", [("sum", 63, 4, 160)],
        render, solve, reference,
    )


def _mixed_fraction_equation():
    def render(p):
        return (rf'Solve for $w$ and express as a common fraction: '
                rf'$\frac{{{p["whole"]}+\frac{{{p["numerator"]}}}{{{p["denominator"]}}}}}{{w}}'
                rf'=\frac{{{p["right_numerator"]}}}{{{p["right_denominator"]}}}$.')

    def solve(p):
        numerator = p["whole"] + Fraction(p["numerator"], p["denominator"])
        return numerator / Fraction(p["right_numerator"], p["right_denominator"])

    def reference(p):
        a, b, c = (p[key] for key in ("whole", "numerator", "denominator"))
        return Fraction((a * c + b) * p["right_denominator"], c * p["right_numerator"])

    return _bounded_case(
        "algebra.rational_equation.mixed_number", [
            ("whole", 1, 1, 10), ("numerator", 1, 1, 10), ("denominator", 6, 2, 12),
            ("right_numerator", 42, 1, 60), ("right_denominator", 3, 1, 12),
        ], render, solve, reference, adaptation="The mixed number is written explicitly as a sum.",
    )


def _curated_polynomial(problem_id):
    factories = {
        "algebra/train/29": (_factored_quadratic, False),
        "algebra/train/472": (_factored_quadratic, True),
        "algebra/train/733": (_expanded_rational, False),
        "algebra/test/101": (_symmetric_quartic,),
        "algebra/test/1037": (_expanded_rational, True),
        "algebra/train/492": (_square_binomial, 4, -12),
        "algebra/train/1096": (_square_binomial, 1, 100),
        "algebra/train/268": (_completed_square, (1, 8, -1), "isolated"),
        "algebra/train/1192": (_quadratic_two_sides, (-3, 9, 1, 41), True),
        "algebra/train/1700": (_quadratic_two_sides, (-4, -14, 3, 16), False),
        "algebra/test/44": (_mixed_fraction_equation,),
        "algebra/test/128": (_completed_square, (2, -4, 4), "vertex"),
        "algebra/test/172": (_quadratic_two_sides, (-4, -14, 3, 16), True),
        "algebra/test/233": (_completed_square, (1, -6, 66), "sum"),
        "algebra/test/386": (_completed_square, (1, -8, -49), "linear_coefficient"),
        "algebra/test/538": (_parabola_intercepts, (-1, 4, -4)),
        "algebra/test/909": (_parabola_intercepts, (1, -4, -1)),
        "intermediate_algebra/train/291": (_conjugate_root, (5, 2, -1, None), True),
        "intermediate_algebra/train/899": (_conjugate_root, (3, 7, -1, None), True),
        "intermediate_algebra/test/56": (_conjugate_root, (4, 11, -1, 3), False),
        "intermediate_algebra/test/726": (_conjugate_root, (3, 7, 1, 2), False),
        "intermediate_algebra/train/541": (_tangent_parabola, (1, 0, 6), "coefficient"),
        "intermediate_algebra/train/781": (_tangent_parabola, (3, 5, 24), "general_line"),
        "intermediate_algebra/train/1032": (_tangent_parabola, (2, 0, 8), "intercept"),
        "intermediate_algebra/train/450": (_factor_pair,),
        "intermediate_algebra/train/633": (_prime_pair,),
    }
    if problem_id not in factories:
        return None
    factory, *arguments = factories[problem_id]
    return factory(*arguments)


# Common base, powers defining the displayed bases, two affine exponents,
# number of factors on the left, and the source variable name.
_EXPONENTIAL_EQUATIONS = {
    "train/336": (2, 1, 2, 1, -3, 1, 1, 1, "x"),
    "train/358": (3, 3, 2, 0, 8, 1, 0, 1, "q"),
    "train/1002": (2, 2, 3, 0, 6, 1, 0, 1, "n"),
    "train/1027": (2, 3, 6, 1, 0, 0, 3, 3, "n"),
    "train/1181": (10, 2, 1, 0, 3, 1, 0, 1, "x"),
    "train/1289": (2, 1, 4, 0, 8, 1, 0, 1, "x"),
    "train/1721": (2, 1, 2, 1, -3, 0, 2, 1, "x"),
    "train/1722": (3, 2, 4, 1, 0, 0, 4, 4, "n"),
    "test/4": (2, 1, 2, 0, 8, 1, 0, 1, "x"),
    "test/35": (3, 2, 3, 18, 0, 0, 24, 1, "n"),
}


def _exponential_equation(case):
    _, _, _, c, d, e, f, repeat, variable = case
    names = ("base", "left_power", "right_power", "left_coefficient", "left_offset",
             "right_coefficient", "right_offset", "left_factors")
    values = case[:-1]
    limits = (
        (2, 10), (1, 6), (1, 6), (0, 0) if c == 0 else (1, 18),
        (0, 0) if d == 0 else (-24, 24), (0, 0) if e == 0 else (1, 8),
        (0, 0) if f == 0 else (-24, 24), (1, 1) if repeat == 1 else (2, 5),
    )

    def inputs(p):
        return tuple(p[name] for name in names)

    def render(p):
        base, a, b, c, d, e, f, repeat = inputs(p)
        lhs_factor = f"{base**a}^{{{_tex_polynomial([d, c], variable)}}}"
        rhs = f"{base**b}^{{{_tex_polynomial([f, e], variable)}}}"
        lhs = r" \cdot ".join([lhs_factor] * repeat)
        return f"Solve for ${variable}$: ${lhs}={rhs}$."

    def solve(p):
        _, a, b, c, d, e, f, repeat = inputs(p)
        return Fraction(b * f - repeat * a * d, repeat * a * c - b * e)

    def reference(p):
        base, a, b, c, d, e, f, repeat = inputs(p)
        left, right = base**a, base**b
        factor = next(i for i in range(2, base + 1) if base % i == 0)

        def valuation(n):
            exponent = 0
            while n % factor == 0:
                n //= factor
                exponent += 1
            return exponent

        lval, rval = valuation(left), valuation(right)
        at_zero = repeat * lval * d - rval * f
        at_one = repeat * lval * (c + d) - rval * (e + f)
        return Fraction(-at_zero, at_one - at_zero)

    def check(p):
        _, a, b, c, _, e, _, repeat = inputs(p)
        return repeat * a * c != b * e

    return _bounded_case(
        "algebra.exponential_equation", [
            (name, value, *bound) for name, value, bound in zip(names, values, limits)
        ], render, solve, reference, check,
        ["The displayed bases are positive powers of one integer greater than one. "
         "The resulting linear equation in the exponent has a nonzero coefficient."],
    )


_INVERSE_PROPORTIONS = {
    "train/565": (r"\alpha", r"\beta", 4, 9, -72, 1, False),
    "train/975": ("a", "b", 9, 2, 3, 2, False),
    "train/1036": (r"\alpha", r"\beta", -3, -6, 8, 1, False),
    "train/1201": ("p", "q", 25, 6, 15, 1, False),
    "test/72": ("j", "k", 16, 21, 14, 1, False),
    "test/201": ("j", "k", 42, 56, 32, 1, True),
    "test/402": ("p", "q", 28, 7, 49, 1, False),
    "test/425": ("d", "c", 8, 9, 6, 1, False),
}


def _inverse_proportion(case):
    a, b, response, initial, target, exponent, rounded = case

    def render(p):
        divisor = b if exponent == 1 else f"{b}^{{{exponent}}}"
        result = (f"${a}$ varies inversely with ${divisor}$. If ${a}={p['response']}$ "
                  f"when ${b}={p['initial']}$, find ${a}$ when ${b}={p['target']}$.")
        if rounded:
            result += " Round to the nearest tenth, rounding halves up."
        return result

    def round_answer(value):
        if not rounded:
            return value
        shifted = value * 10 + Fraction(1, 2)
        return Fraction(shifted.numerator // shifted.denominator, 10)

    def solve(p):
        factor = Fraction(p["initial"], p["target"]) ** exponent
        return round_answer(p["response"] * factor)

    def reference(p):
        constant = p["response"] * p["initial"] ** exponent
        return round_answer(Fraction(constant, p["target"] ** exponent))

    lower = 1 if rounded else -80
    return _bounded_case(
        "algebra.inverse_proportion", [
            ("response", response, lower, 80), ("initial", initial, lower, 80),
            ("target", target, lower, 80),
        ], render, solve, reference,
        lambda p: all(p.values()) and abs(p["initial"]) != abs(p["target"]),
        ["The known values are nonzero and the initial and target magnitudes differ."],
        adaptation="Half-up rounding is stated explicitly." if rounded else "",
    )


def _symmetric_quartic():
    def values(p):
        center, r, s, d = (p[key] for key in ("center", "inner_radius", "outer_radius", "distance"))
        return center, (center - s, center - r, center + r, center + s), d

    def render(p):
        center, roots, d = values(p)
        factors = "".join(f"({_tex_polynomial([-root, 1])})" for root in roots)
        return f"Define $f(x)={factors}$. Evaluate $f({center + d})-f({center - d})$."

    def reference(p):
        center, roots, d = values(p)
        return prod(center + d - root for root in roots) - prod(center - d - root for root in roots)

    return _bounded_case(
        "algebra.polynomial.mirrored_probes", [
            ("center", 5, -15, 15), ("inner_radius", 2, 1, 7),
            ("outer_radius", 4, 2, 14), ("distance", 1, 1, 15),
        ], render, lambda p: 0, reference,
        lambda p: p["inner_radius"] < p["outer_radius"]
        and p["distance"] not in (p["inner_radius"], p["outer_radius"]),
        ["The four roots form two distinct mirrored pairs. Neither probe is a root."],
    )


def _expanded_rational(factored):
    entries = [
        ("denominator_slope", 2, 1, 9),
        ("denominator_offset", -7 if factored else 37, -15, 45),
        ("quotient_slope", 3, 1, 9),
        ("right_offset", -3 if factored else 1, -12, 12),
    ]
    if factored:
        entries.extend([("quotient_offset", 1, -12, 12), ("right_slope", 4, 1, 9)])
    else:
        entries.append(("numerator_offset", 1, -12, 12))

    def polynomials(p):
        a, b, c, e = (p[key] for key in (
            "denominator_slope", "denominator_offset", "quotient_slope", "right_offset",
        ))
        if factored:
            d, f = p["quotient_offset"], p["right_slope"]
            return (b * d, a * d + b * c, a * c), (b, a), (e, f)
        return (p["numerator_offset"], b * c, a * c), (b, a), (e, c)

    def render(p):
        variable = "r" if factored else "x"
        numerator, denominator, right = (
            _tex_polynomial(poly, variable) for poly in polynomials(p)
        )
        return rf"Solve for ${variable}$: $\frac{{{numerator}}}{{{denominator}}}={right}$."

    def solve(p):
        if factored:
            return Fraction(p["right_offset"] - p["quotient_offset"],
                            p["quotient_slope"] - p["right_slope"])
        return (Fraction(p["numerator_offset"], p["right_offset"]) - p["denominator_offset"]
                ) / p["denominator_slope"]

    def reference(p):
        numerator, denominator, rhs = polynomials(p)
        cleared = _poly_add(numerator, _poly_mul(denominator, rhs), -1)
        if factored:
            cleared, _ = _poly_divmod(cleared, denominator)
        return Fraction(-cleared[0], cleared[1])

    def check(p):
        if factored and p["quotient_slope"] == p["right_slope"]:
            return False
        if not factored and not (p["right_offset"] and p["numerator_offset"]):
            return False
        return p["denominator_offset"] + p["denominator_slope"] * solve(p) != 0

    return _bounded_case(
        "algebra.rational_equation.expanded_product", entries, render, solve, reference, check,
        ["The coefficients preserve the source cancellation pattern. The resulting linear "
         "equation is nonsingular and its solution does not make the denominator zero."],
    )
