"""Exact templates for counting, probability, and number theory."""

import ast
import re
from collections import Counter
from fractions import Fraction
from functools import lru_cache
from itertools import combinations, combinations_with_replacement, permutations, product
from math import comb, factorial, gcd, isqrt, lcm, perm, prod

from template_dataset.core import Template


def _template(family, domains, render, solve, reference, *, allowed=None,
              constraints=(), adaptation=""):
    """Build a family with finite integer intervals or finite named choices."""
    original = {name: spec[0] for name, spec in domains.items()}
    parameters = {}
    for name, spec in domains.items():
        if len(spec) == 3:
            _, lower, upper = spec
            parameters[name] = {"type": "int", "min": lower, "max": upper}
        else:
            value, choices = spec
            parameters[name] = {"type": type(value).__name__, "choices": list(choices)}

    def validate(values):
        if not isinstance(values, dict) or values.keys() != parameters.keys():
            return False
        for name, domain in parameters.items():
            value = values[name]
            if type(value) is not type(original[name]):
                return False
            if "choices" in domain:
                if value not in domain["choices"]:
                    return False
            elif not domain["min"] <= value <= domain["max"]:
                return False
        return allowed is None or allowed(**values)

    def sample(rng):
        for _ in range(2000):
            values = {
                name: rng.choice(domain["choices"]) if "choices" in domain
                else rng.randint(domain["min"], domain["max"])
                for name, domain in parameters.items()
            }
            if validate(values):
                return values
        # Sparse joint constraints can exhaust a random search for some seeds.
        # Try a bounded, deterministic move from the known admissible input.
        for name, domain in parameters.items():
            candidates = (domain["choices"] if "choices" in domain
                          else range(domain["min"], domain["max"] + 1))
            for candidate in candidates:
                if candidate == original[name]:
                    continue
                values = dict(original, **{name: candidate})
                if validate(values) and render(**values) != render(**original):
                    return values
        return dict(original)

    return Template(
        family=family, parameters=parameters, original=original,
        render=lambda p: render(**p), solve=lambda p: solve(**p), sample=sample,
        validate=validate, constraints=list(constraints),
        reference=lambda p: reference(**p), adaptation=adaptation,
    )


def _choose(n, k):
    """Independent binomial evaluation via coefficient recurrence."""
    value = 1
    for j in range(min(k, n - k)):
        value = value * (n - j) // (j + 1)
    return value


def _binomial(body):
    atom = r"\\(?:d?binom)\{(?P<n>\d+)\}\{(?P<k>\d+)\}"
    match = re.fullmatch(r"Compute \$(?:\\displaystyle )?" + atom + r"\$\.", body)
    if match:
        n, k = map(int, match.groups())
        if k == 0 or n == k:
            return _template(
                "discrete.binomial_edge", {"n": (n, 1, max(50, n))},
                lambda n: rf"Compute $\binom{{{n}}}{{{0 if k == 0 else n}}}$.",
                lambda n: 1,
                lambda n: _choose(n, 0 if k == 0 else n),
            )
        return _template(
            "discrete.binomial", {"n": (n, 3, max(n, 48)), "k": (k, 1, max(k, 14))},
            lambda n, k: rf"Compute $\binom{{{n}}}{{{k}}}$.",
            lambda n, k: comb(n, k), _choose, allowed=lambda n, k: k < n,
            constraints=("1 <= k < n",),
        )

    double = re.fullmatch(
        r"Compute \$\\d?binom\{(\d+)\}\{(\d+)\}(\+|\\times ?|-)"
        r"\\d?binom\{(\d+)\}\{(\d+)\}\$\.", body
    )
    if double:
        n, k, operator, m, j = double.groups()
        n, k, m, j = map(int, (n, k, m, j))
        if n == m and k + j == n and operator in {"+", "-"}:
            return _template(
                "discrete.symmetric_binomials", {"n": (n, 4, 35), "k": (k, 1, 15)},
                lambda n, k: rf"Compute $\binom{{{n}}}{{{k}}}{operator}\binom{{{n}}}{{{n-k}}}$.",
                lambda n, k: 2 * comb(n, k) if operator == "+" else 0,
                lambda n, k: _choose(n, k) + (1 if operator == "+" else -1) * _choose(n, n - k),
                allowed=lambda n, k: k < n, constraints=("k < n",),
            )
        return _template(
            "discrete.binomial_product",
            {"n": (n, 3, 28), "k": (k, 1, 8), "m": (m, 3, 28), "j": (j, 1, 8)},
            lambda n, k, m, j: rf"Compute $\binom{{{n}}}{{{k}}}{operator}\binom{{{m}}}{{{j}}}$.",
            lambda n, k, m, j: comb(n, k) * comb(m, j),
            lambda n, k, m, j: _choose(n, k) * _choose(m, j),
            allowed=lambda n, k, m, j: k <= n and j <= m,
            constraints=("k <= n", "j <= m"),
        ) if operator.startswith("\\times") else None
    return None


_WORDS = (
    "RADII", "MADAM", "TOOT", "TARTAR", "ALABAMA", "PROOF", "ELLIPSE",
    "NINE", "ELEVEN", "PAPA", "PARABOLA", "CEASE", "GAMMAS", "TEPEE",
    "THAT", "HAWAII", "CIRCLE", "BANANA", "LETTER", "BALLOON", "ASSESS",
    "BOOKKEEPER", "DEED", "AREA", "MEMO", "BERRY", "CIVIC", "CACTUS",
)


def _arrange_word(body, split, index):
    match = re.fullmatch(r"Determine the number of ways to arrange the letters of the word ([A-Z]+)\.", body)
    if match:
        word = match[1]
    elif (split, index) == ("test", 161):
        word = "PAPA"
    elif (split, index) == ("test", 392):
        word = "HAWAII"
    else:
        return None
    # Preserve the mathematical task while limiting the reference to permutations
    # of at most eight indices.
    choices = tuple(candidate for candidate in _WORDS if len(candidate) <= 8)
    if word not in choices:
        return None
    return _template(
        "discrete.multiset_word", {"word": (word, choices)},
        lambda word: f"How many distinct arrangements of the letters in {word} are possible?",
        lambda word: factorial(len(word)) // prod(factorial(n) for n in Counter(word).values()),
        _multiset_word_reference,
    )


@lru_cache(maxsize=64)
def _multiset_word_reference(word):
    # Build each distinct arrangement from its prefix, without permuting equal indices.
    if not word:
        return 1
    return sum(_multiset_word_reference(word.replace(letter, "", 1)) for letter in set(word))


def _selection(total, selected, context):
    return _template(
        "discrete.unordered_selection", {"total": (total, 4, max(total, 28)),
                                          "selected": (selected, 1, max(selected, 9))},
        context, lambda total, selected: comb(total, selected),
        lambda total, selected: _choose(total, selected),
        allowed=lambda total, selected: selected <= total,
        constraints=("selected <= total",),
    )


_SELECTIONS = {
    ("train", 45): (12, 3, "How many triangles can be formed using vertices of a regular {total}-sided polygon?"),
    ("train", 56): (5, 3, "A group of {total} friends wants to ride a roller coaster. How many different groups of {selected} can they form to ride together in one car?"),
    ("train", 88): (8, 3, "In how many ways can Michael choose {selected} out of {total} math classes to take?"),
    ("train", 147): (6, 4, "In how many ways can {selected} books be selected from a shelf of {total} books if the order in which the books are selected does not matter?"),
    ("train", 148): (8, 3, "How many triangles can be formed using vertices of a regular {total}-sided polygon?"),
    ("train", 152): (8, 2, "In how many ways can I choose {selected} cooks on a backpacking trip with {total} people?"),
    ("train", 160): (6, 4, "A pizza parlor offers {total} toppings. How many different pizzas with {selected} different toppings can be made?"),
    ("train", 224): (11, 3, "In how many ways can I choose {selected} captains from a team of {total} people?"),
    ("train", 281): (6, 2, "An ice cream shop offers {total} kinds of ice cream. How many distinct sundaes made with {selected} different kinds can be made?"),
    ("train", 292): (8, 3, "I won a trip for myself and {selected} friends to the Super Bowl. I have {total} friends. How many different groups of friends can I take?"),
    ("train", 295): (12, 4, "There are {total} different-colored crayons in a box. How many ways can Karl select {selected} crayons if the order does not matter?"),
    ("train", 504): (7, 3, "Johnny has {total} marbles of different colors. In how many ways can he choose {selected} different marbles?"),
    ("train", 518): (9, 4, "In how many ways can I choose a {selected}-person committee from a club of {total} people?"),
    ("train", 523): (10, 4, "{total} distinct points are identified on a circle. How many convex quadrilaterals have their vertices among these points?"),
    ("train", 564): (14, 6, "A math club has {total} members. In how many ways can the club select a team of {selected} members with no restrictions?"),
    ("train", 577): (7, 2, "In how many ways can George choose {selected} out of {total} colors to paint his room?"),
    ("train", 586): (6, 4, "From a group of {total} students, how many different {selected}-student committees can be chosen?"),
    ("train", 606): (7, 3, "{total} distinct points are identified on a circle. How many triangles have their vertices among these points?"),
    ("train", 612): (5, 3, "A drawer contains {total} distinct socks. In how many ways can {selected} socks be chosen if order does not matter?"),
    ("train", 750): (14, 6, "A volleyball team has {total} players. In how many ways can we choose {selected} starters with no restrictions?"),
    ("test", 33): (8, 4, "A school's math team has {total} members. In how many ways can the coach choose {selected} members for a contest?"),
    ("test", 100): (6, 5, "In how many ways can {selected} students be selected from a group of {total} students?"),
    ("test", 109): (5, 3, "Mary has {total} tourist locations in Italy that she would like to visit, but can only see {selected}. In how many ways can she choose the locations?"),
    ("test", 163): (9, 2, "Sarah can choose from {total} pizza toppings. How many pizzas with {selected} different toppings can she order?"),
    ("test", 191): (8, 3, "In how many ways can a {selected}-person committee be chosen from a group of {total} people?"),
    ("test", 193): (8, 2, "Mikka can choose from {total} pizza toppings. How many pizzas with {selected} different toppings can he order?"),
    ("test", 331): (12, 4, "A bookshelf contains {total} distinct books. In how many ways can I choose {selected} of them to read over the next month?"),
    ("test", 388): (15, 13, "In how many ways can {selected} students be selected from a group of {total} students to serve on a chalkboard-cleaning team?"),
}


def _choose_fixed(total, selected, context, family="discrete.unordered_selection"):
    return _template(
        family, {"total": (total, max(3, selected), max(total, 35))},
        lambda total: context.format(total=total),
        lambda total: comb(total, selected), lambda total: _choose(total, selected),
    )


def _curated_selection(split, index):
    if (split, index) not in _SELECTIONS:
        return None
    total, selected, context = _SELECTIONS[split, index]
    if "{selected}" not in context:
        return _choose_fixed(total, selected, context)
    return _selection(total, selected, context.format)


def _handshakes_and_diagonals(split, index):
    handshakes = {("train", 463): 8, ("test", 119): 10}
    diagonals = {("train", 537): 7, ("train", 733): 8, ("test", 175): 5}
    key = (split, index)
    if key in handshakes:
        return _choose_fixed(
            handshakes[key], 2,
            "{total} people attend a party. Each pair of people shakes hands once. How many handshakes occur?",
            "discrete.handshakes",
        )
    if key in diagonals:
        return _template(
            "discrete.polygon_diagonals", {"sides": (diagonals[key], 3, 40)},
            lambda sides: f"How many diagonals does a convex polygon with {sides} sides have?",
            lambda sides: sides * (sides - 3) // 2,
            lambda sides: sum(1 < j - i < sides - 1
                              for i, j in combinations(range(sides), 2)),
        )
    return None


def _occupancy(split, index):
    cases = {
        ("train", 157): (5, 3, "neither"),
        ("train", 164): (4, 2, "both"),
        ("train", 178): (4, 3, "neither"),
        ("train", 324): (4, 3, "both"),
        ("train", 573): (5, 2, "both"),
        ("train", 661): (4, 2, "neither"),
        ("train", 759): (5, 2, "boxes"),
        ("test", 157): (4, 2, "boxes"),
        ("test", 227): (5, 3, "both"),
        ("test", 344): (5, 2, "neither"),
    }
    if (split, index) not in cases:
        return None
    balls, boxes, case = cases[split, index]
    adjective = {
        "neither": ("indistinguishable", "indistinguishable"),
        "both": ("distinguishable", "distinguishable"),
        "boxes": ("indistinguishable", "distinguishable"),
    }[case]
    solve = {
        "both": lambda balls, boxes: boxes ** balls,
        "boxes": lambda balls, boxes: comb(balls + boxes - 1, boxes - 1),
        "neither": _restricted_partitions,
    }[case]

    def reference(balls, boxes):
        if case == "both":
            return sum(1 for _ in product(range(boxes), repeat=balls))
        outcomes = (product(range(balls + 1), repeat=boxes) if case == "boxes"
                    else combinations_with_replacement(range(balls + 1), boxes))
        return sum(sum(allocation) == balls for allocation in outcomes)

    return _template(
        "discrete.occupancy_" + case,
        {"balls": (balls, 1, 7), "boxes": (boxes, 2, 4)},
        lambda balls, boxes: (
            f"In how many ways can {balls} {adjective[0]} balls be placed in "
            f"{boxes} {adjective[1]} boxes? Empty boxes are allowed."
        ), solve, reference,
    )


def _restricted_partitions(balls, boxes):
    # Conjugation turns partitions with at most boxes parts into parts <= boxes.
    ways = [1] + [0] * balls
    for part in range(1, boxes + 1):
        for total in range(part, balls + 1):
            ways[total] += ways[total - part]
    return ways[balls]


def _fair_coins(split, index):
    cases = {
        ("train", 28): (3, 1, "at_least"),
        ("train", 242): (2, 2, "all"),
        ("train", 478): (5, 3, "half"),
        ("train", 498): (3, 1, "exact"),
        ("train", 704): (3, 1, "mixed"),
        ("test", 448): (3, 2, "below"),
    }
    if (split, index) not in cases:
        return None
    flips, heads, mode = cases[split, index]
    domains = {"flips": (flips, 2, 9)}
    if mode in {"exact", "below", "at_least"}:
        domains["heads"] = (heads, 1, 8)

    def render(flips, heads=None):
        if mode in {"mixed", "half"}:
            event = "at least one boy and at least one girl" if mode == "mixed" else "at least half girls"
            return (f"Assume the sex of each child is independent and a boy and a girl "
                    f"are equally likely. What is the probability that a family with "
                    f"{flips} children has {event}?")
        event = {
            "exact": f"exactly {heads} heads and {flips - heads} tails",
            "below": f"fewer than {heads} heads",
            "at_least": f"at least {heads} heads",
            "all": "heads on every flip",
        }[mode] if heads is not None else "heads on every flip"
        return f"A fair coin is tossed {flips} times. What is the probability of getting {event}?"

    def success(hits, flips, heads):
        if mode == "all":
            return hits == flips
        if mode == "mixed":
            return 0 < hits < flips
        if mode == "half":
            return 2 * hits >= flips
        if mode == "exact":
            return hits == heads
        return hits < heads if mode == "below" else hits >= heads

    return _template(
        "discrete.fair_trials_" + mode, domains, render,
        lambda flips, heads=None: Fraction(sum(comb(flips, h) for h in range(flips + 1)
                                               if success(h, flips, heads)), 2 ** flips),
        lambda flips, heads=None: Fraction(sum(success(sum(outcome), flips, heads)
                                               for outcome in product((0, 1), repeat=flips)), 2 ** flips),
        allowed=(lambda flips, heads: heads <= flips) if "heads" in domains else None,
        constraints=("heads <= flips",) if "heads" in domains else (),
        adaptation=("States the independent-trial convention explicitly."
                    if mode in {"half", "mixed"} else ""),
    )


def _unfair_coins(split, index):
    cases = {
        ("test", 349): (5, 2, 2, 3),
    }
    if (split, index) not in cases:
        return None
    flips, heads, numerator, denominator = cases[split, index]

    def reference(flips, heads, numerator, denominator):
        p = Fraction(numerator, denominator)
        probabilities = {0: Fraction(1)}
        for _ in range(flips):
            next_probabilities = {}
            for count, probability in probabilities.items():
                next_probabilities[count] = next_probabilities.get(count, 0) + probability * (1 - p)
                next_probabilities[count + 1] = next_probabilities.get(count + 1, 0) + probability * p
            probabilities = next_probabilities
        return probabilities[heads]

    return _template(
        "discrete.biased_exact_trials",
        {"flips": (flips, 2, 15), "heads": (heads, 1, 12),
         "numerator": (numerator, 1, 12), "denominator": (denominator, 2, 20)},
        lambda flips, heads, numerator, denominator: (
            rf"A coin lands heads with probability $\frac{{{numerator}}}{{{denominator}}}$."
            f" The coin is flipped {flips} times independently. What is the probability of exactly {heads} heads?"
        ),
        lambda flips, heads, numerator, denominator: Fraction(
            comb(flips, heads) * numerator ** heads * (denominator - numerator) ** (flips - heads),
            denominator ** flips,
        ),
        reference, allowed=lambda flips, heads, numerator, denominator: (
            heads <= flips and numerator < denominator
        ), constraints=("heads <= flips", "numerator < denominator"),
        adaptation="States that flips are independent.",
    )


def _complement(split, index):
    cases = {
        ("train", 132): (4, 7, "Kim has a math test today", "Kim does not have a math test today"),
        ("train", 488): (4, 9, "Asha loses a game in which ties are impossible", "Asha wins the game"),
        ("train", 653): (3, 10, "it rains tomorrow", "it does not rain tomorrow"),
        ("test", 0): (1, 11, "it rains tomorrow", "it does not rain tomorrow"),
        ("test", 351): (3, 8, "a randomly thrown dart lands on a target", "the dart misses the target"),
    }
    if (split, index) not in cases:
        return None
    numerator, denominator, event, opposite = cases[split, index]
    return _template(
        "discrete.event_complement",
        {"numerator": (numerator, 1, 15), "denominator": (denominator, 2, 30)},
        lambda numerator, denominator: (
            rf"The probability that {event} is $\frac{{{numerator}}}{{{denominator}}}$."
            f" What is the probability that {opposite}? Express your answer as a common fraction."
        ),
        lambda numerator, denominator: 1 - Fraction(numerator, denominator),
        lambda numerator, denominator: Fraction(sum(i >= numerator for i in range(denominator)), denominator),
        allowed=lambda numerator, denominator: numerator < denominator,
        constraints=("numerator < denominator",),
    )


def _dice_sums(split, index):
    cases = {
        ("train", 31): (8, 2, 15, "equal"),
        ("train", 37): (6, 2, 3, "above"),
        ("train", 145): (6, 2, 11, "below"),
        ("train", 515): (6, 3, 18, "equal"),
        ("test", 127): (6, 2, (3, 11), "between"),
    }
    if (split, index) not in cases:
        return None
    sides, dice, target, mode = cases[split, index]
    domains = {"sides": (sides, 4, 14), "dice": (dice, 2, 4)}
    if mode == "between":
        low, high = target
        domains.update(low=(low, 2, 14), high=(high, 3, 27))
    else:
        domains["target"] = (target, 2, 22)

    def event(sides, dice, target=None, low=None, high=None):
        if mode == "equal":
            return target, target, f"equals {target}"
        if mode == "above":
            return target + 1, sides * dice, f"is greater than {target}"
        if mode == "below":
            return dice, target - 1, f"is less than {target}"
        return low, high, f"is between {low} and {high}, inclusive"

    def allowed(sides, dice, **limits):
        low, high, _ = event(sides, dice, **limits)
        return dice <= low <= high <= sides * dice

    def render(sides, dice, **limits):
        _, _, event_text = event(sides, dice, **limits)
        return (f"{dice} independent fair {sides}-sided dice, each numbered from "
                f"1 to {sides}, are rolled. What is the probability that their sum {event_text}?")

    def solve(sides, dice, **limits):
        low, high, _ = event(sides, dice, **limits)
        counts = [1]
        for _ in range(dice):
            counts = [sum(counts[max(0, value - sides):value])
                      for value in range(len(counts) + sides)]
        return Fraction(sum(counts[low:high + 1]), sides ** dice)

    def reference(sides, dice, **limits):
        low, high, _ = event(sides, dice, **limits)
        return Fraction(sum(low <= sum(rolls) <= high
                            for rolls in product(range(1, sides + 1), repeat=dice)), sides ** dice)

    return _template(
        "discrete.dice_sum_" + mode, domains, render, solve, reference, allowed=allowed,
        constraints=("The requested inclusive sum interval must be nonempty and lie between dice and sides*dice.",),
        adaptation="Makes fairness, independence and face labels explicit.",
    )


def _dice_distance(split, index):
    cases = {
        ("train", 121): (6, 2),
        ("test", 118): (6, 0),
        ("test", 357): (6, 0),
    }
    if (split, index) not in cases:
        return None
    sides, distance = cases[split, index]
    return _template(
        "discrete.dice_distance",
        {"sides": (sides, 3, 20), "distance": (distance, 0, 12)},
        lambda sides, distance: (
            f"Two independent fair {sides}-sided dice numbered from 1 to {sides} are rolled. "
            f"What is the probability that the absolute difference of the two results is {distance}?"
        ),
        lambda sides, distance: Fraction((1 if distance == 0 else 2) * (sides - distance), sides ** 2),
        lambda sides, distance: Fraction(sum(abs(a - b) == distance for a, b in
                                             product(range(1, sides + 1), repeat=2)), sides ** 2),
        allowed=lambda sides, distance: distance < sides,
        constraints=("distance < sides",),
        adaptation="Makes fairness, independence and face labels explicit.",
    )


_URNS = {
    ("train", 55): (5, 4, 2, "same", "red", "blue", "plates"),
    ("train", 95): (5, 6, 2, "first_color", "white", "black", "balls"),
    ("train", 103): (3, 5, 2, "ordered", "red", "white", "marbles"),
    ("train", 104): (5, 5, 2, "first_color", "girls", "boys", "club members"),
    ("train", 136): (6, 4, 2, "same_replace", "green", "red", "balls"),
    ("train", 158): (3, 4, 2, "first_color", "green", "red", "apples"),
    ("train", 202): (5, 3, 2, "different_replace", "blue", "yellow", "chips"),
    ("train", 310): (10, 8, 2, "same", "gray-bottomed", "white-bottomed", "socks"),
    ("train", 569): (3, 2, 2, "first_color", "female", "male", "contestants"),
    ("train", 694): (5, 6, 5, "first_color", "white", "black", "balls"),
    ("test", 142): (4, 12, 2, "first_color", "blue", "red", "blocks"),
    ("test", 204): (3, 6, 2, "first_color", "white", "black", "balls"),
    ("test", 313): (12, 6, 2, "different", "red", "blue", "marbles"),
    ("test", 337): (12, 8, 2, "different", "boys", "girls", "club members"),
    ("test", 377): (4, 6, 2, "same", "red", "blue", "marbles"),
}


def _urn(split, index):
    if (split, index) not in _URNS:
        return None
    first, second, drawn, mode, first_color, second_color, noun = _URNS[split, index]
    replace = mode.endswith("_replace")
    domains = {"first": (first, 2, 18), "second": (second, 1, 18)}
    if mode == "first_color":
        domains["drawn"] = (drawn, 1, 6)

    def render(first, second, drawn=2):
        protocol = "with replacement" if replace else "without replacement"
        event_text = {
            "same": "all selected items are in the same group",
            "same_replace": "both selected items are in the same group",
            "first_color": f"all selected items are in the {first_color} group",
            "different": "one selected item is from each group",
            "different_replace": "one selected item is from each group",
            "ordered": f"the first item is {first_color} and the second is {second_color}",
        }[mode]
        return (f"A collection of {noun} has {first} in the {first_color} group and "
                f"{second} in the {second_color} group. Select {drawn} of them at random "
                f"{protocol}. What is the probability that {event_text}?")

    def solve(first, second, drawn=2):
        total = first + second
        if mode == "first_color":
            return Fraction(comb(first, drawn), comb(total, drawn))
        if mode == "same":
            return Fraction(comb(first, 2) + comb(second, 2), comb(total, 2))
        if mode == "same_replace":
            return Fraction(first ** 2 + second ** 2, total ** 2)
        if mode == "different_replace":
            return Fraction(2 * first * second, total ** 2)
        return Fraction((1 if mode == "ordered" else 2) * first * second, total * (total - 1))

    def reference(first, second, drawn=2):
        if mode == "first_color":
            result = Fraction(1)
            for offset in range(drawn):
                result *= Fraction(first - offset, first + second - offset)
            return result
        identifiers = range(first + second)
        hits = total = 0
        for a, b in product(identifiers, repeat=2):
            if a == b and not replace:
                continue
            total += 1
            if mode == "ordered":
                hits += a < first <= b
            else:
                same = (a < first) == (b < first)
                hits += same == mode.startswith("same")
        return Fraction(hits, total)

    return _template(
        "discrete.urn_" + mode, domains, render, solve, reference,
        allowed=(lambda first, second, drawn: drawn <= first) if "drawn" in domains else None,
        constraints=("drawn <= first",) if "drawn" in domains else (),
        adaptation="States the replacement convention and identifies the two original groups explicitly.",
    )


def _factorization(n):
    factors = {}
    divisor = 2
    while divisor * divisor <= n:
        while n % divisor == 0:
            factors[divisor] = factors.get(divisor, 0) + 1
            n //= divisor
        divisor += 1
    if n > 1:
        factors[n] = 1
    return factors


def _divisors(n):
    return {divisor for candidate in range(1, isqrt(n) + 1) if n % candidate == 0
            for divisor in (candidate, n // candidate)}


def _plain_divisors(body):
    count_pattern = (
        r"How many (?:distinct,? )?(?:positive|natural-number) "
        r"(?:whole-number )?(?:factors|divisors) does \$?(?P<n>[\d,]+)\$? have\?"
        r"|Find the number of positive (?:divisors|factors) of \$?(?P<n2>[\d,]+)\$?\."
    )
    sum_pattern = (
        r"(?:What is|Find) the sum of (?:all (?:of )?(?:the )?|the )?"
        r"(?:positive(?: integer)?|whole-number) (?:divisors|factors) of \$?(?P<n>[\d,]+)\$?[?.]"
    )
    product_pattern = (
        r"What is the product of all the positive integer divisors of \$?(?P<n>[\d,]+)\$?\?"
    )
    for mode, pattern in (("count", count_pattern), ("sum", sum_pattern), ("product", product_pattern)):
        match = re.fullmatch(pattern, body)
        if match:
            n = int(next(group for group in match.groups() if group is not None).replace(",", ""))
            break
    else:
        return None

    def solve(n):
        factors = _factorization(n)
        count = prod(exponent + 1 for exponent in factors.values())
        if mode == "count":
            return count
        if mode == "sum":
            return prod((prime ** (exponent + 1) - 1) // (prime - 1)
                        for prime, exponent in factors.items())
        return n ** (count // 2) * (isqrt(n) if count % 2 else 1)

    operation = {"count": len, "sum": sum, "product": prod}[mode]
    question = {
        "count": "How many positive divisors does {n} have?",
        "sum": "What is the sum of the positive divisors of {n}?",
        "product": "What is the product of the positive divisors of {n}?",
    }[mode]
    return _template(
        "discrete.divisors_" + mode, {"n": (n, 2, max(n, 2200))},
        lambda n: question.format(n=n), solve, lambda n: operation(_divisors(n)),
    )


def _plain_gcd_lcm(body):
    match = re.fullmatch(
        r"(?:Find|What is) the (greatest common (?:divisor|factor)|least common multiple)"
        r" of \$?([\d,]+)\$? and \$?([\d,]+)(?:\$)?(?:[.?!])?(?:\$)?", body
    )
    if match:
        operation, a, b = match.groups()
        a, b = (int(value.replace(",", "")) for value in (a, b))
    else:
        match = re.fullmatch(
            r"(?:Find|Compute|Evaluate) \$\\(?:gcd|lcm)\(\s*([\d,]+),\s*([\d,]+)\s*\)\$[.?!]?",
            body,
        )
        if not match:
            return None
        operation = "least common multiple" if "\\lcm" in body else "greatest common divisor"
        a, b = (int(value.replace(",", "")) for value in match.groups())
    common_divisor = operation.startswith("greatest")

    def reference(a, b):
        # Compare prime valuations using the lattice of divisibility.
        left, right = _factorization(a), _factorization(b)
        extremum = min if common_divisor else max
        return prod(prime ** extremum(left.get(prime, 0), right.get(prime, 0))
                    for prime in left.keys() | right.keys())

    return _template(
        "discrete.gcd" if common_divisor else "discrete.lcm",
        {"a": (a, 2, max(a, 2200)), "b": (b, 2, max(b, 2200))},
        lambda a, b: f"Find the {operation} of {a} and {b}.",
        lambda a, b: gcd(a, b) if common_divisor else lcm(a, b), reference,
    )


def _divisor_restrictions(split, index):
    cases = {
        ("train", 206): (72, 3, "powers"),
        ("train", 268): (150, 5, "exclude"),
        ("train", 499): (180, 2, "powers"),
        ("test", 22): (4000, 100, "include"),
        ("test", 460): (48, 156, "common"),
    }
    if (split, index) not in cases:
        return None
    n, k, mode = cases[split, index]
    question = {
        "powers": "How many positive divisors of {n} are perfect {k}th powers?",
        "exclude": "How many positive divisors of {n} are not divisible by {k}?",
        "include": "How many positive divisors of {n} are divisible by {k}?",
        "common": "How many positive divisors do {n} and {k} share?",
    }[mode]

    def count(value):
        return prod(exponent + 1 for exponent in _factorization(value).values())

    def solve(n, k):
        if mode == "powers":
            return prod(exponent // k + 1 for exponent in _factorization(n).values())
        if mode == "common":
            return count(gcd(n, k))
        multiples = count(n // k) if n % k == 0 else 0
        return multiples if mode == "include" else count(n) - multiples

    def reference(n, k):
        divisors = _divisors(n)
        if mode == "powers":
            return sum(candidate ** k in divisors for candidate in range(1, isqrt(n) + 1))
        if mode == "common":
            return len(divisors & _divisors(k))
        return sum((divisor % k == 0) == (mode == "include") for divisor in divisors)

    return _template(
        "discrete.divisor_" + mode, {"n": (n, 12, max(1400, n)),
                                     "k": (k, 2, 5 if mode == "powers" else max(24, k))},
        lambda n, k: question.format(n=n, k=k), solve, reference,
    )


def _base_digits(n, base):
    digits = []
    while n:
        n, digit = divmod(n, base)
        digits.append(digit)
    return digits[::-1] or [0]


_BASE_REPRESENTATIONS = {
    ("train", 4): ("31", 8),
    ("train", 44): ("10101", 3),
    ("train", 176): ("A03", 16),
    ("train", 223): ("154", 6),
    ("train", 392): ("12012", 3),
    ("train", 398): ("567", 8),
    ("train", 439): ("432", 9),
    ("train", 528): ("3206", 7),
    ("train", 540): ("245", 8),
    ("train", 740): ("135", 7),
    ("train", 770): ("54321", 6),
    ("train", 773): ("12345", 6),
    ("test", 178): ("852", 9),
    ("test", 208): ("101010", 5),
    ("test", 268): ("1230", 4),
    ("test", 408): ("634", 7),
    ("test", 414): ("3254", 6),
    ("test", 470): ("1222", 3),
}


def _base_to_decimal(body, split, index):
    match = re.fullmatch(
        r"Convert \$([0-9A-F]+)_(?:\{(\d+)\}|(\d+))\$ to (?:a )?base[ -]10(?: integer)?\.", body
    )
    if match:
        text, a, b = match.groups()
        base = int(a or b)
    elif (split, index) in _BASE_REPRESENTATIONS:
        text, base = _BASE_REPRESENTATIONS[split, index]
    else:
        return None

    domains = {"base": (base, 2, 16)}
    for index, digit in enumerate(text):
        domains[f"digit_{index + 1}"] = (int(digit, 16), int(index == 0), 15)

    def render(base, **digits):
        numeral = "".join("0123456789ABCDEF"[value] for value in digits.values())
        return rf"Convert ${numeral}_{{{base}}}$ to base 10."

    def reference(base, **digits):
        numeral = "".join("0123456789ABCDEF"[value] for value in digits.values())
        return int(numeral, base)

    def solve(base, **digits):
        total = 0
        for digit in digits.values():
            total = total * base + digit
        return total

    def sample_allowed(base, **digits):
        return max(digits.values()) < base

    # Independent uniform sampling over all 16 digits is too sparse for long
    # numerals and small bases. Use a per-ID upper bound for each position.
    for name in tuple(domains)[1:]:
        original, low, _ = domains[name]
        domains[name] = (original, low, max(base - 1, 6))

    # Parameter order is explicit because validate accepts any dictionary order.
    def ordered(function):
        return lambda base, **digits: function(
            base, **{name: digits[name] for name in domains if name != "base"}
        )

    return _template(
        "discrete.base_to_decimal", domains, ordered(render), ordered(solve),
        ordered(reference), allowed=sample_allowed,
        constraints=("Every digit is strictly smaller than the base.",),
        adaptation="States the radix conversion directly, dropping the story framing where present.",
    )


def _base_statistics(split, index):
    cases = {
        ("train", 54): (199, 2, "ones_minus_zeros"),
        ("train", 66): (403, 7, "even"),
        ("train", 191): (473, 8, "first"),
        ("train", 250): (233, 4, "odd"),
        ("train", 508): (777, 7, "sum"),
        ("train", 522): (222, 2, "sum"),
        ("train", 777): (956, 7, "length"),
        ("test", 16): (682, 6, "end_product"),
        ("test", 159): (527, 4, "sum"),
        ("test", 216): (355, 6, "last"),
        ("test", 471): (269, 5, "sum"),
    }
    if (split, index) not in cases:
        return None
    n, base, mode = cases[split, index]
    describe = {
        "ones_minus_zeros": "the number of ones minus the number of zeros",
        "even": "the number of even digits",
        "odd": "the number of odd digits",
        "first": "the first digit",
        "last": "the last digit",
        "end_product": "the product of the first and last digits",
        "sum": "the sum of the digits",
        "length": "the number of digits",
    }[mode]

    def statistic(digits):
        if mode == "ones_minus_zeros":
            return digits.count(1) - digits.count(0)
        if mode == "even":
            return sum(digit % 2 == 0 for digit in digits)
        if mode == "odd":
            return sum(digit % 2 == 1 for digit in digits)
        if mode == "first":
            return digits[0]
        if mode == "last":
            return digits[-1]
        if mode == "end_product":
            return digits[0] * digits[-1]
        if mode == "sum":
            return sum(digits)
        return len(digits)

    def reference(n, base=2):
        place = 1
        while place * base <= n:
            place *= base
        digits = []
        while place:
            digit, n = divmod(n, place)
            digits.append(digit)
            place //= base
        return statistic(digits)

    domains = {"n": (n, 20, 3500)}
    if mode != "ones_minus_zeros":
        domains["base"] = (base, 2, 10)
    return _template(
        "discrete.base_" + mode, domains,
        lambda n, base=2: f"Find {describe} in the base-{base} representation of {n} (given in base ten).",
        lambda n, base=2: statistic(_base_digits(n, base)), reference,
    )


def _decimal_digit(split, index):
    cases = {
        ("train", 199): (12, 37, 308),
        ("train", 226): (1, 13, 43),
        ("train", 705): (5, 13, 534),
        ("train", 731): (33, 555, 111),
        ("train", 754): (3, 16, 3),
        ("test", 155): (123, 999, 123999),
        ("test", 187): (1, 37, 291),
        ("test", 199): (1, 19, 39),
        ("test", 385): (3, 7, 9),
        ("test", 465): (9, 160, 2),
        ("test", 535): (6, 13, 453),
    }
    if (split, index) not in cases:
        return None
    numerator, denominator, place = cases[split, index]
    fixed_denominators = {754: (8, 16, 32, 40, 64, 80, 125),
                          465: (8, 16, 32, 40, 64, 80, 125, 160)}
    denominator_domain = ((denominator, fixed_denominators[index])
                          if (split, index) in {("train", 754), ("test", 465)}
                          else (denominator, 3, max(110, denominator)))

    def reference(numerator, denominator, place):
        # Long division can skip repetitions once it encounters a repeated remainder.
        seen, digits = {}, []
        remainder = numerator
        while remainder not in seen:
            seen[remainder] = len(digits)
            digit, remainder = divmod(10 * remainder, denominator)
            digits.append(digit)
            if len(digits) == place:
                return digit
        start = seen[remainder]
        return digits[start + (place - 1 - start) % (len(digits) - start)]

    return _template(
        "discrete.decimal_digit",
        {"numerator": (numerator, 1, max(20, numerator)),
         "denominator": denominator_domain, "place": (place, 2, max(260, place))},
        lambda numerator, denominator, place: (
            rf"What is digit number ${place}$ to the right of the decimal point in "
            rf"$\frac{{{numerator}}}{{{denominator}}}$, counting the first digit as number 1?"
        ),
        lambda numerator, denominator, place: (
            10 * (numerator * pow(10, place - 1, denominator) % denominator) // denominator
        ),
        reference, allowed=lambda numerator, denominator, place: numerator < denominator,
        constraints=("numerator < denominator",),
        adaptation=("Asks for the same position by index and drops precomputed repetend hints."
                    if (split, index) in {("test", 199), ("test", 385)} else ""),
    )


def _residue_expression(body):
    # The full question must ask about a fixed expression, with no hypotheses.
    remainder_patterns = (
        r"(?:What is|Find|Determine|Calculate) the (?:whole number )?remainder "
        r"when (?:(?:the sum|the product) )?(.+?)\s*is\s+divided by \$?([\d,]+)\$?[?.]",
        r"(?:What is|Find|Determine) the remainder of (.+?) (?:when it is )?divided by \$?([\d,]+)\$?[?.]",
        r"(?:What is|Find|Determine) the remainder of (.+?) \(mod ([\d,]+)\)[?.]",
    )
    digit_patterns = (
        r"(?:What is|Find|Determine) the (units|ones|tens|hundreds) digit (?:of|in) (.+?)"
        r"(?: when expressed as an integer| when written as an integer)?[?.]?",
        r"What is the (units|ones) digit when (.+?) is multiplied out\?",
        r"When (.+?) is written in decimal notation, what is its (ones|units) digit\?",
    )
    modulus = None
    place = None
    for pattern in remainder_patterns:
        match = re.fullmatch(pattern, body)
        if match:
            expression, modulus = match.groups()
            modulus = int(modulus.replace(",", ""))
            break
    if modulus is None:
        for i, pattern in enumerate(digit_patterns):
            match = re.fullmatch(pattern, body)
            if match:
                label, expression = match.groups()[::-1] if i == 2 else match.groups()
                place = {"units": 0, "ones": 0, "tens": 1, "hundreds": 2}[label]
                break
    if modulus is None and place is None:
        match = re.fullmatch(
            r"(?:What is|Find|Determine) the modulo \$?(\d+)\$? (?:remainder|residue) "
            r"of (?:the (?:following )?sum: )?(.+)", body,
        )
        if match:
            modulus, expression = match.groups()
            modulus = int(modulus)
    if modulus is None and place is None:
        match = re.fullmatch(
            r"Compute (.+?) modulo (\d+)\.|Find the residue of (.+?)\\pmod\{(\d+)\}\$?\.",
            body,
        )
        if match:
            left, a, right, b = match.groups()
            expression, modulus = (left or right), int(a or b)
    if modulus is None and place is None:
        return None

    expression = expression.strip().strip(".$? ").replace(r"\[", "").replace(r"\]", "")
    expression = re.sub(r"(?<=\d)(?:\{,\}|,)(?:\\!)?(?=\d)", "", expression)
    expression = re.sub(r"\\(?:cdot|times)", "*", expression)
    expression = re.sub(r"\\(?:left|right)", "", expression)
    expression = re.sub(r"\)\s*\(", ")*(", expression)
    expression = re.sub(r"\^\{(\d+)\}", r"^\1", expression)
    if not re.fullmatch(r"[\s\d!^()+*\-]+", expression):
        return None

    # Powers have fixed integer exponents. Keeping the tiny grammar explicit
    # excludes power towers, rational expressions, and variable-dependent input.
    python_expression = re.sub(r"\b(\d+)!", r"factorial(\1)", expression.replace("^", "**"))
    try:
        syntax = ast.parse(python_expression.strip(), mode="eval").body
    except SyntaxError:
        return None
    domains = {}
    names = {}

    def parameter(value, kind):
        key = value, kind
        if key not in names:
            name = f"{kind}_{len(domains) + 1}"
            lower = 0 if value == 0 else 1
            upper = max(value, {"exponent": 60, "term": 320, "factorial": 14}[kind])
            names[key] = name
            domains[name] = (value, lower, upper)
        return names[key]

    def convert(node):
        if isinstance(node, ast.Constant) and type(node.value) is int:
            return "value", parameter(node.value, "term")
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
            return ("negative" if isinstance(node.op, ast.USub) else "positive"), convert(node.operand)
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Pow):
            if not isinstance(node.right, ast.Constant) or type(node.right.value) is not int:
                raise ValueError("unsupported exponent")
            if not isinstance(node.left, ast.Constant) or type(node.left.value) is not int:
                raise ValueError("unsupported power base")
            # An exponent of zero remains fixed when it is a structural part
            # of the calculation, e.g. terms explicitly demonstrating a^0.
            exponent = (("fixed", 0) if node.right.value == 0
                        else ("value", parameter(node.right.value, "exponent")))
            return "power", convert(node.left), exponent
        if isinstance(node, ast.BinOp) and type(node.op) in {ast.Add, ast.Sub, ast.Mult}:
            operation = {ast.Add: "sum", ast.Sub: "difference", ast.Mult: "product"}[type(node.op)]
            return operation, convert(node.left), convert(node.right)
        if (isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
                and node.func.id == "factorial" and len(node.args) == 1
                and isinstance(node.args[0], ast.Constant) and type(node.args[0].value) is int):
            return "factorial", parameter(node.args[0].value, "factorial")
        raise ValueError("unsupported expression")

    try:
        tree = convert(syntax)
    except ValueError:
        return None
    if not domains:
        return None
    if modulus is not None:
        domains["modulus"] = (modulus, 2, max(85, modulus))

    def typeset(node, values):
        operation, *parts = node
        if operation == "value":
            return str(values[parts[0]])
        if operation == "fixed":
            return str(parts[0])
        if operation == "factorial":
            return f"{values[parts[0]]}!"
        if operation in {"negative", "positive"}:
            return ("-" if operation == "negative" else "+") + typeset(parts[0], values)
        a, b = (typeset(part, values) for part in parts)
        if operation == "power":
            return f"{a}^{{{b}}}"
        operator = {"sum": " + ", "difference": " - ", "product": r" \cdot "}[operation]
        return f"({a}{operator}{b})"

    def evaluate(node, values, mod):
        operation, *parts = node
        if operation == "value":
            return values[parts[0]]
        if operation == "fixed":
            return parts[0]
        if operation == "factorial":
            return factorial(values[parts[0]])
        if operation in {"negative", "positive"}:
            child = evaluate(parts[0], values, mod)
            return -child if operation == "negative" else child
        a, b = (evaluate(part, values, mod) for part in parts)
        if operation == "power":
            return a ** b if mod is None else pow(a, b, mod)
        if operation == "sum":
            value = a + b
        elif operation == "difference":
            value = a - b
        else:
            value = a * b
        return value if mod is None else value % mod

    def render(**values):
        text = typeset(tree, values)
        if place is None:
            return f"What is the remainder when ${text}$ is divided by {values['modulus']}?"
        label = ("units", "tens", "hundreds")[place]
        return f"What is the {label} digit of ${text}$?"

    requires_digit_length = place is not None and (place > 0 or "-" in expression)

    def allowed(**values):
        minimum = 10 ** place if place else 0
        return evaluate(tree, values, None) >= minimum

    def solve(**values):
        if place is None:
            return evaluate(tree, values, values["modulus"]) % values["modulus"]
        return evaluate(tree, values, 10 ** (place + 1)) // (10 ** place) % 10

    def reference(**values):
        value = evaluate(tree, values, None)
        if place is None:
            return divmod(value, values["modulus"])[1]
        for _ in range(place):
            value //= 10
        return value % 10

    return _template(
        "discrete.arithmetic_residue" if place is None else "discrete.decimal_place",
        domains, render, solve, reference,
        allowed=allowed if requires_digit_length else None,
        constraints=("The expression must be nonnegative and contain the requested decimal position.",)
        if requires_digit_length else (),
    )


def _congruence(split, index):
    cases = {
        ("train", 27): (9, 1, 25, 11),
        ("train", 279): (4, 13, 27, None),
        ("train", 466): (4, 1, 21, 0),
        ("train", 743): (27, 1, 28, 0),
        ("train", 807): (11, 7, 43, 0),
        ("test", 200): (3, 2, 11, 0),
        ("test", 237): (7, 1, 398, 0),
        ("test", 387): (6, 7, 13, 0),
        ("test", 500): (5, 8, 17, 0),
        ("test", 532): (2, 15, 47, 0),
    }
    if (split, index) not in cases:
        return None
    a, residue, modulus, shift = cases[split, index]
    inverse = residue == 1
    domains = {"a": (a, 1, 47), "modulus": (modulus, 3, max(modulus, 65))}
    if not inverse:
        domains["residue"] = (residue, 0, 20)
    if shift not in {0, None}:
        domains["shift"] = (shift, 1, 25)

    def allowed(a, modulus, residue=1, shift=0):
        return gcd(a, modulus) == 1 and residue < modulus

    def render(a, modulus, residue=1, shift=0):
        equation = rf"${a}x\equiv {residue}\pmod{{{modulus}}}$"
        if shift:
            return f"Given {equation}, what is the remainder when $x+{shift}$ is divided by {modulus}?"
        if inverse:
            return f"Find the multiplicative inverse of {a} modulo {modulus} in the range 0 to {modulus - 1}."
        if cases[split, index][3] is None:
            return f"What is the smallest positive integer satisfying {equation}?"
        return f"Find the integer $x$ in the range 0 to {modulus - 1} satisfying {equation}."

    def adjusted(value, modulus, shift):
        value = (value + shift) % modulus
        return value if value or cases[split, index][3] is not None else modulus

    def solve(a, modulus, residue=1, shift=0):
        return adjusted(pow(a, -1, modulus) * residue, modulus, shift)

    def reference(a, modulus, residue=1, shift=0):
        value = next(x for x in range(modulus) if a * x % modulus == residue)
        return adjusted(value, modulus, shift)

    return _template(
        "discrete.linear_congruence", domains, render, solve, reference, allowed=allowed,
        constraints=("gcd(a, modulus) = 1",) + (("residue < modulus",) if not inverse else ()),
    )


def _repeating_decimal(split, index):
    cases = {
        ("train", 154): (42, 2, "sum"),
        ("train", 414): (28, 2, "fraction"),
        ("train", 471): (3, 1, "denominator"),
        ("test", 343): (54, 2, "fraction"),
        ("test", 442): (5, 1, "fraction"),
    }
    if (split, index) not in cases:
        return None
    repetend, length, mode = cases[split, index]
    goal = {
        "sum": "What is the sum of its numerator and denominator?",
        "denominator": "What is its denominator?",
        "fraction": "",
    }[mode]

    def answer(fraction):
        if mode == "sum":
            return fraction.numerator + fraction.denominator
        return fraction.denominator if mode == "denominator" else fraction

    return _template(
        "discrete.repeating_decimal_" + mode,
        {"repetend": (repetend, 1, 998), "length": (length, 1, 3)},
        lambda repetend, length: (
            rf"Express $0.\overline{{{repetend:0{length}d}}}$ as a fraction in lowest terms."
            + (f" {goal}" if goal else "")
        ),
        lambda repetend, length: answer(Fraction(repetend, 10 ** length - 1)),
        lambda repetend, length: answer(
            sum((Fraction(repetend, 10 ** (length * i)) for i in range(1, 3)), Fraction())
            / (1 - Fraction(1, 10 ** (2 * length)))
        ),
        allowed=lambda repetend, length: repetend < 10 ** length - 1,
        constraints=("repetend < 10**length - 1. Leading zeros are permitted.",),
    )


def _linear_pairs(split, index):
    cases = {
        ("train", 598): (1, 30),
        ("test", 55): (2, 100),
    }
    if (split, index) not in cases:
        return None
    coefficient, total = cases[split, index]
    domains = {"total": (total, 5, 250)}
    if coefficient != 1:
        domains["coefficient"] = (coefficient, 2, 15)

    def render(total, coefficient=1):
        expression = "x+y" if coefficient == 1 else f"x+{coefficient}y"
        return f"How many ordered pairs of positive integers $(x,y)$ satisfy ${expression}={total}$?"

    return _template(
        "discrete.positive_linear_pairs", domains, render,
        lambda total, coefficient=1: (total - 1) // coefficient,
        lambda total, coefficient=1: sum(
            x + coefficient * y == total
            for x in range(1, total) for y in range(1, total)
        ),
    )


def _prime_sieve(n):
    prime = [False, False] + [True] * max(0, n - 1)
    for p in range(2, isqrt(n) + 1):
        if prime[p]:
            for candidate in range(p * p, n + 1, p):
                prime[candidate] = False
    return [candidate for candidate in range(2, n + 1) if prime[candidate]]


def _is_prime(n):
    return n >= 2 and all(n % d for d in range(2, isqrt(n) + 1))


def _prime_family(subject, split, index):
    cases = {
        ("number_theory", "train", 19): (10, "sum"),
        ("number_theory", "train", 103): (3, "composite_product_digit"),
        ("number_theory", "train", 141): (3, "reciprocal_mean"),
        ("number_theory", "train", 334): (20, "factorial_primes"),
        ("number_theory", "train", 363): (221, "largest_factor"),
        ("number_theory", "train", 413): (3, "first_product"),
        ("number_theory", "train", 444): (25, "sum_extreme"),
        ("number_theory", "train", 530): (10, "nth"),
        ("number_theory", "test", 263): (100, "prime_product_digit"),
        ("number_theory", "test", 358): (40, "largest_pair_product"),
        ("number_theory", "test", 498): (30, "count_odd"),
        ("counting_and_probability", "train", 428): (20, "pair_probability"),
        ("counting_and_probability", "train", 702): (30, "factorial_primes"),
    }
    if (subject, split, index) not in cases:
        return None
    n, mode = cases[subject, split, index]
    question = {
        "sum": "What is the sum of all prime numbers less than {n}?",
        "sum_extreme": "What is the sum of the smallest and largest primes strictly between 1 and {n}?",
        "reciprocal_mean": "What is the arithmetic mean of the reciprocals of the first {n} primes?",
        "factorial_primes": "How many distinct prime factors does {n}! have?",
        "largest_factor": "What is the largest prime factor of {n}?",
        "first_product": "What is the least positive integer divisible by {n} distinct primes?",
        "nth": "What is prime number {n} in the increasing list of all primes?",
        "largest_pair_product": "What is the greatest product of two distinct primes less than {n}?",
        "count_odd": "How many odd prime numbers are less than {n}?",
        "composite_product_digit": "What is the units digit of the product of the first {n} positive composite integers?",
        "prime_product_digit": "What is the units digit of the product of the first {n} primes?",
        "pair_probability": "Two distinct integers are chosen uniformly at random from 1 through {n}. What is the probability that both are prime?",
    }[mode]

    def solve(n):
        if mode == "largest_factor":
            return max(_factorization(n))
        if mode in {"reciprocal_mean", "nth", "first_product", "prime_product_digit", "composite_product_digit"}:
            # For all supported n <= 100 there are at least n primes below 1000.
            primes = _prime_sieve(1000)
            if mode == "composite_product_digit":
                prime_set = set(primes)
                return prod([k for k in range(4, 1001) if k not in prime_set][:n]) % 10
            if mode == "prime_product_digit":
                return prod(primes[:n]) % 10
            if mode == "reciprocal_mean":
                return sum(Fraction(1, p) for p in primes[:n]) / n
            if mode == "nth":
                return primes[n - 1]
            return prod(primes[:n])
        primes = _prime_sieve(n if mode in {"pair_probability", "factorial_primes"} else n - 1)
        if mode == "sum":
            return sum(primes)
        if mode == "sum_extreme":
            return primes[0] + primes[-1]
        if mode == "largest_pair_product":
            return primes[-1] * primes[-2]
        if mode == "count_odd":
            return sum(p % 2 for p in primes)
        if mode == "factorial_primes":
            return len(primes)
        return Fraction(comb(len(primes), 2), comb(n, 2))

    def reference(n):
        if mode == "largest_factor":
            return max(p for p in _divisors(n) if _is_prime(p))
        if mode in {"reciprocal_mean", "nth", "first_product", "prime_product_digit", "composite_product_digit"}:
            values = []
            k = 2
            while len(values) < n:
                if _is_prime(k) != (mode == "composite_product_digit"):
                    values.append(k)
                k += 1
            if mode.endswith("_digit"):
                return int(str(prod(values))[-1])
            if mode == "nth":
                return values[-1]
            common = prod(values)
            if mode == "reciprocal_mean":
                return Fraction(sum(common // value for value in values), n * common)
            return common
        if mode == "pair_probability":
            return Fraction(sum(_is_prime(a) and _is_prime(b)
                                for a, b in combinations(range(1, n + 1), 2)), comb(n, 2))
        if mode == "factorial_primes":
            value = factorial(n)
            return sum(value % candidate == 0 and _is_prime(candidate)
                       for candidate in range(2, n + 1))
        primes = [p for p in range(2, n) if _is_prime(p)]
        if mode == "sum":
            return sum(primes)
        if mode == "sum_extreme":
            return min(primes) + max(primes)
        if mode == "largest_pair_product":
            return max(a * b for a, b in combinations(primes, 2))
        return len(primes) - 1

    lower, upper = {
        "reciprocal_mean": (2, 12), "first_product": (2, 12),
        "nth": (2, 40), "prime_product_digit": (2, 100),
        "composite_product_digit": (2, 15), "largest_factor": (12, 900),
    }.get(mode, (6, 140))
    domain = (n, (2, 3, 4, 5, 6, 7, 100)) if mode == "prime_product_digit" else (n, lower, upper)
    return _template(
        "discrete.prime_" + mode, {"n": domain},
        lambda n: question.format(n=n), solve, reference,
    )


def _square_ranges(subject, split, index):
    cases = {
        ("counting_and_probability", "train", 53): (50, 250, 2, "count"),
        ("counting_and_probability", "test", 36): (10, 1000, 2, "count"),
        ("counting_and_probability", "test", 221): (200, 300, 2, "count"),
        ("counting_and_probability", "test", 272): (100, 200, 2, "inclusive_exclude"),
        ("counting_and_probability", "test", 288): (25, 250, 3, "inclusive_exclude"),
        ("number_theory", "train", 219): (0, 100, 4, "fourth_sum"),
        ("number_theory", "train", 245): (0, 100, 6, "square_cube_count"),
        ("number_theory", "train", 476): (1, 150, 6, "square_cube_exclude"),
        ("number_theory", "train", 716): (4000, 7000, 2, "prime_count"),
        ("counting_and_probability", "test", 231): (100, 300, 2, "prime_count"),
    }
    key = subject, split, index
    if key not in cases:
        return None
    low, high, power, mode = cases[key]
    inclusive = mode in {"inclusive_exclude", "square_cube_exclude"}
    domains = {"high": (high, 35, max(high, 1400))}
    if low != 0 and mode != "square_cube_exclude":
        domains["low"] = (low, 1, max(low, 700))

    def render(high, low=low):
        label = "squares" if power == 2 else "cubes"
        if mode == "fourth_sum":
            return f"What is the sum of all positive integers below {high} that are squares of perfect squares?"
        if mode == "square_cube_count":
            return f"How many positive integers less than {high} are both a perfect square and a perfect cube?"
        if mode == "square_cube_exclude":
            return f"How many integers from 1 through {high} are neither perfect squares nor perfect cubes?"
        if mode == "prime_count":
            return f"How many prime numbers have squares strictly between {low} and {high}?"
        if mode == "inclusive_exclude":
            return f"How many integers from {low} through {high} are not perfect {label}?"
        return f"How many perfect {label} are strictly between {low} and {high}?"

    def solve(high, low=low):
        first, last = (low, high) if inclusive else (low + 1, high - 1)
        if mode == "prime_count":
            return sum(first <= p * p <= last for p in _prime_sieve(isqrt(last)))
        if mode == "square_cube_exclude":
            return last - isqrt(last) - _iroot(last, 3) + _iroot(last, 6)
        if mode == "fourth_sum":
            return sum(root ** 4 for root in range(1, _iroot(last, 4) + 1))
        count = _iroot(last, power) - _iroot(first - 1, power)
        return last - first + 1 - count if inclusive else count

    def reference(high, low=low):
        first, last = (low, high) if inclusive else (low + 1, high - 1)
        if mode == "prime_count":
            return sum(isqrt(n) ** 2 == n and _is_prime(isqrt(n)) for n in range(first, last + 1))
        if mode == "square_cube_exclude":
            powers = {k ** p for k in range(1, isqrt(last) + 1) for p in (2, 3)}
            return sum(n not in powers for n in range(first, last + 1))
        powers = {k ** power for k in range(1, isqrt(last) + 1)}
        if mode == "fourth_sum":
            return sum(n for n in range(first, last + 1) if n in powers)
        return sum((n in powers) != inclusive for n in range(first, last + 1))

    return _template(
        "discrete.power_range_" + mode, domains, render, solve, reference,
        allowed=lambda high, low=low: low < high,
        constraints=("low < high",) if "low" in domains else (),
    )


def _iroot(n, exponent):
    if exponent == 2:
        return isqrt(n)
    lo, hi = 0, 1
    while hi ** exponent <= n:
        hi *= 2
    while hi - lo > 1:
        midpoint = (lo + hi) // 2
        if midpoint ** exponent <= n:
            lo = midpoint
        else:
            hi = midpoint
    return lo


def _fixed_progression(split, index):
    cases = {
        ("train", 45): (1, 1, 10, 11, "square_sum"),
        ("train", 73): (11065, 2, 7, 14, "sum"),
        ("train", 290): (7145, 1, 5, 8, "sum"),
        ("train", 437): (8735, 1, 4, 11, "sum"),
        ("train", 486): (75, 1, 8, 16, "sum"),
        ("train", 537): (88134, 1, 6, 9, "sum"),
        ("train", 774): (2, 10, 10, 5, "product"),
        ("train", 801): (1, 1, 123, 5, "sum"),
        ("test", 17): (1, 1, 11, 8, "alternating"),
        ("test", 39): (7438, 1, 8, 8, "sum"),
        ("test", 196): (1, 1, 100, 6, "sum"),
        ("test", 197): (1, 1, 12, 4, "sum"),
        ("test", 246): (2000, 1, 7, 7, "sum"),
        ("test", 251): (2010, 1, 2009, 2009, "sum"),
        ("test", 301): (1, 1, 10, 9, "sum"),
        ("test", 380): (91145, 1, 4, 4, "sum"),
    }
    if (split, index) not in cases:
        return None
    start, step, length, modulus, mode = cases[split, index]
    domains = {"length": (length, 3, max(35, length)), "modulus": (modulus, 2, max(110, modulus))}
    if start != 1:
        domains["start"] = (start, 1, max(125, start))
    if step != 1:
        domains["step"] = (step, 1, 12)

    def render(length, modulus, start=start, step=step):
        progression = f"the {length} terms of the arithmetic progression starting at {start} with common difference {step}"
        if mode == "alternating":
            target = f"the alternating sum of {progression}, starting with a plus sign"
        elif mode == "square_sum":
            target = f"the sum of the squares of {progression}"
        else:
            target = f"the {mode} of {progression}"
        return f"What remainder does {target} leave upon division by {modulus}?"

    def solve(length, modulus, start=start, step=step):
        if mode == "product":
            result = 1
            for j in range(length):
                result = result * (start + j * step) % modulus
            return result
        if mode == "alternating":
            result = -(length // 2) * step
            if length % 2:
                result += start + (length - 1) * step
            return result % modulus
        if mode == "square_sum":
            return (length * (length + 1) * (2 * length + 1) // 6) % modulus
        return (length * (2 * start + (length - 1) * step) // 2) % modulus

    def reference(length, modulus, start=start, step=step):
        values = range(start, start + length * step, step)
        if mode == "product":
            result = prod(values)
        elif mode == "alternating":
            result = sum((-1) ** i * n for i, n in enumerate(values))
        elif mode == "square_sum":
            result = sum(n * n for n in values)
        else:
            result = sum(values)
        return result % modulus

    return _template(
        "discrete.progression_residue_" + mode, domains, render, solve, reference,
    )


def _crt(split, index):
    cases = {
        ("train", 110): ((4, 5, 7), (3, 2, 4), 0, 0, "first"),
        ("train", 190): ((7, 5), (3, 1), 0, 40, "unique"),
        ("train", 208): ((17, 6, 2), (1, 1, 1), 1, 0, "common"),
        ("train", 234): ((8, 7), (7, 4), 0, 100, "last"),
        ("train", 251): ((2, 3, 4, 5), (1, 2, 3, 4), 0, 0, "one_before"),
        ("train", 277): ((4, 5, 7), (1, 2, 3), 0, 0, "first"),
        ("train", 283): ((5, 7), (4, 6), 0, 0, "one_before"),
        ("train", 374): ((4, 5), (3, 2), 10, 0, "first"),
        ("train", 380): ((6, 7, 8), (1, 1, 1), 1, 0, "common"),
        ("train", 388): ((5, 3), (1, 2), 0, 0, "first"),
        ("train", 429): ((4, 5, 7), (1, 2, 3), 100, 200, "unique"),
        ("train", 451): ((5, 7), (3, 4), 0, 60, "sum"),
        ("train", 488): ((3, 4, 5), (2, 2, 2), 50, 100, "unique"),
        ("train", 545): ((4, 3, 5), (1, 1, 2), -1, 0, "first"),
        ("train", 717): ((6, 8, 5), (0, 2, 2), 30, 80, "unique"),
        ("train", 727): ((2, 3, 4), (0, 1, 2), 0, 0, "first"),
        ("test", 350): ((3, 7), (2, 3), 0, 0, "second"),
        ("test", 360): ((4, 5), (3, 4), 0, 0, "one_before"),
        ("test", 373): ((3, 4, 5), (1, 1, 4), 0, 0, "first"),
        ("test", 474): ((5, 7), (3, 5), 0, 40, "unique"),
        ("test", 503): ((4, 3, 5), (3, 1, 1), 0, 101, "sum_two"),
    }
    if (split, index) not in cases:
        return None
    original_moduli, original_residues, low, high, mode = cases[split, index]
    count = len(original_moduli)
    domains = {f"modulus_{i}": (m, 2, max(10, m))
               for i, m in enumerate(original_moduli, 1)}
    if mode == "common":
        domains["remainder"] = (original_residues[0], 0, 4)
    elif mode != "one_before":
        domains.update({f"remainder_{i}": (r, 0, max(7, r))
                        for i, r in enumerate(original_residues, 1)})
    if high:
        domains["high"] = (high, 25, max(140, high))
    if low > 1:
        domains["low"] = (low, 1, max(70, low))

    def unpack(values):
        moduli = tuple(values[f"modulus_{i}"] for i in range(1, count + 1))
        if mode == "common":
            remainders = (values["remainder"],) * count
        elif mode == "one_before":
            remainders = tuple(m - 1 for m in moduli)
        else:
            remainders = tuple(values[f"remainder_{i}"] for i in range(1, count + 1))
        return moduli, remainders, values.get("low", low), values.get("high", high)

    def progression(values):
        moduli, remainders, bottom, top = unpack(values)
        period, value = 1, 0
        for modulus, remainder in zip(moduli, remainders):
            divisor = gcd(period, modulus)
            difference = remainder - value
            if difference % divisor:
                return None
            factor = modulus // divisor
            if factor > 1:
                value += period * ((difference // divisor * pow(period // divisor, -1, factor)) % factor)
            period *= factor
        first = bottom + 1 + (value - bottom - 1) % period
        last = top - 1 - (top - 1 - value) % period if top else first
        return first, last, period

    def allowed(**values):
        moduli, remainders, bottom, top = unpack(values)
        if len(set(moduli)) < count or any(r >= m for m, r in zip(moduli, remainders)):
            return False
        solution = progression(values)
        if solution is None:
            return False
        first, last, period = solution
        if mode == "unique":
            return first == last
        if mode == "sum_two":
            return last == first + period
        if top:
            return first <= last
        return True

    def render(**values):
        moduli, remainders, bottom, top = unpack(values)
        conditions = ", ".join(f"{r} modulo {m}" for m, r in zip(moduli, remainders))
        premise = f"An integer has remainders {conditions}."
        interval = f" strictly between {bottom} and {top}" if top else f" greater than {bottom}"
        if mode in {"sum", "sum_two"}:
            return f"{premise} What is the sum of all such integers{interval}?"
        ordinal = "greatest" if mode == "last" else "second-smallest" if mode == "second" else "smallest"
        if mode == "unique":
            return f"{premise} What is the integer{interval}?"
        return f"{premise} What is the {ordinal} such integer{interval}?"

    def solve(**values):
        first, last, period = progression(values)
        if mode == "last":
            return last
        if mode == "second":
            return first + period
        if mode in {"sum", "sum_two"}:
            return (first + last) * ((last - first) // period + 1) // 2
        return first

    def reference(**values):
        moduli, remainders, bottom, top = unpack(values)
        period_bound = prod(moduli)
        hits = [n for n in range(bottom + 1, top or bottom + 1 + 2 * period_bound)
                if all(n % m == r for m, r in zip(moduli, remainders))]
        if mode in {"sum", "sum_two"}:
            return sum(hits)
        if mode == "last":
            return hits[-1]
        return hits[int(mode == "second")]

    restrictions = ["All moduli are distinct. Each remainder is smaller than its modulus.",
                    "The congruences are jointly consistent."]
    if high:
        restrictions.append("The open interval contains a solution.")
    if mode in {"unique", "sum_two"}:
        restrictions.append(f"The open interval contains exactly {1 if mode == 'unique' else 2} solution(s).")
    return _template(
        "discrete.chinese_remainder_" + mode, domains, render, solve, reference,
        allowed=allowed, constraints=restrictions,
        adaptation="Writes the original remainders directly as congruences, omitting any story framing.",
    )


def _multiples_in_range(subject, split, index):
    cases = {
        ("number_theory", "train", 285): (1000, 9999, 47, "first"),
        ("number_theory", "train", 314): (1000, 9999, 33, "first"),
        ("number_theory", "train", 320): (100, 999, 13, "last"),
        ("number_theory", "train", 325): (100, 999, 19, "last"),
        ("number_theory", "train", 276): (10, 99, (8, 2), "count"),
        ("number_theory", "test", 97): (16, 84, 20, "count"),
        ("number_theory", "test", 107): (10, 99, 13, "sum_extreme"),
        ("number_theory", "test", 119): (0, 999, 11, "last"),
        ("number_theory", "test", 407): (100, 999, (7, 1), "first"),
        ("number_theory", "test", 479): (100, 999, 13, "count"),
        ("counting_and_probability", "train", 513): (1000, 9999, 3, "count"),
        ("counting_and_probability", "test", 156): (100, 999, 7, "exclude"),
        ("counting_and_probability", "test", 472): (100, 999, 11, "count"),
    }
    key = subject, split, index
    if key not in cases:
        return None
    low, high, modulus, mode = cases[key]
    domains = {}
    fixed_width = (low, high) in {(10, 99), (100, 999), (1000, 9999)}
    if fixed_width:
        digits = len(str(low))
        domains["digits"] = (digits, 2, 4)
    elif low == 0:
        domains["high"] = (high, 45, 1300)
    else:
        domains["low"] = (low, 5, 85)
        domains["high"] = (high, 55, 200)
    has_remainder = isinstance(modulus, tuple)
    if has_remainder:
        modulus, remainder = modulus
        domains["remainder"] = (remainder, 1, 12)
    domains["modulus"] = (modulus, 2, 54)

    def limits(digits=None, low=low, high=high):
        if fixed_width:
            return 10 ** (digits - 1), 10 ** digits - 1
        return low, high

    def render(modulus, remainder=0, **bounds):
        start, end = limits(**bounds)
        if fixed_width:
            scope = f"{bounds['digits']}-digit positive integers"
        else:
            scope = f"integers from {start} through {end}, inclusive"
        condition = (f"are not divisible by {modulus}" if mode == "exclude"
                     else f"are divisible by {modulus}" if not has_remainder
                     else f"leave remainder {remainder} when divided by {modulus}")
        if mode in {"count", "exclude"}:
            return f"How many {scope} {condition}?"
        if mode == "sum_extreme":
            target = "sum of the least and greatest"
        else:
            target = "least" if mode == "first" else "greatest"
        return f"Among {scope} that {condition}, what is the {target}?"

    def solve(modulus, remainder=0, **bounds):
        start, end = limits(**bounds)
        first = start + (remainder - start) % modulus
        last = end - (end - remainder) % modulus
        if mode == "first":
            return first
        if mode == "last":
            return last
        if mode == "sum_extreme":
            return first + last
        count = (last - first) // modulus + 1
        return end - start + 1 - count if mode == "exclude" else count

    def reference(modulus, remainder=0, **bounds):
        start, end = limits(**bounds)
        numbers = [n for n in range(start, end + 1) if n % modulus == remainder]
        if mode == "first":
            return numbers[0]
        if mode == "last":
            return numbers[-1]
        if mode == "sum_extreme":
            return numbers[0] + numbers[-1]
        return end - start + 1 - len(numbers) if mode == "exclude" else len(numbers)

    def allowed(modulus, remainder=0, **bounds):
        start, end = limits(**bounds)
        if not start <= end or remainder >= modulus:
            return False
        return mode in {"count", "exclude"} or start + (remainder - start) % modulus <= end

    constraints = []
    if has_remainder:
        constraints.append("remainder < modulus")
    if not fixed_width and low != 0:
        constraints.append("low <= high")
    if mode not in {"count", "exclude"}:
        constraints.append("At least one integer in the interval satisfies the required congruence.")
    return _template(
        "discrete.multiples_range_" + mode, domains, render, solve, reference,
        allowed=allowed, constraints=constraints,
    )


def _quota_selection(split, index):
    cases = {
        ("train", 150): ((4, 6), (1, 2), ("yogurt flavors", "toppings"), "a yogurt order"),
        ("train", 162): ((6, 8), (3, 3), ("boys", "girls"), "a math club team"),
        ("train", 240): ((3, 4, 4), (1, 2, 1), ("meat dishes", "vegetable dishes", "desserts"), "a buffet meal"),
        ("train", 243): ((8, 6), (3, 2), ("Republicans", "Democrats"), "a Senate subcommittee"),
        ("train", 469): ((3, 5), (2, 2), ("girls", "boys"), "a math team"),
        ("train", 686): ((10, 9), (1, 2), ("kinds of meat", "kinds of cheese"), "a sandwich"),
        ("test", 125): ((7, 4), (3, 2), ("boys", "girls"), "a presentation group"),
        ("test", 220): ((4, 6), (1, 3), ("seventh-graders", "eighth-graders"), "a committee"),
        ("test", 266): ((5, 7, 6), (2, 3, 3), ("teachers", "parents", "students"), "a subcommittee"),
        ("test", 291): ((15, 10), (2, 3), ("kinds of fruit", "kinds of soup"), "a grocery order"),
        ("test", 332): ((8, 6), (3, 2), ("boys", "girls"), "a group of trumpet players"),
    }
    if (split, index) not in cases:
        return None
    totals, selections, types, context = cases[split, index]
    domains = {}
    for i, (available, required) in enumerate(zip(totals, selections), 1):
        domains[f"available_{i}"] = (available, 2, 15)
        domains[f"required_{i}"] = (required, 1, 6)

    def pairs(values):
        return [(values[f"available_{i}"], values[f"required_{i}"]) for i in range(1, len(types) + 1)]

    def render(**values):
        available = ", ".join(f"{n} {label}" for (n, _), label in zip(pairs(values), types))
        quotas = ", ".join(f"{k} from the {label} group" for (_, k), label in zip(pairs(values), types))
        return (f"Available for {context} are {available}. How many ways can we select "
                f"{quotas}, without regard to the order of selection?")

    return _template(
        "discrete.quota_selection", domains, render,
        lambda **values: prod(comb(n, k) for n, k in pairs(values)),
        lambda **values: prod(sum(1 for _ in combinations(range(n), k)) for n, k in pairs(values)),
        allowed=lambda **values: all(k <= n for n, k in pairs(values)),
        constraints=("For each group required_i <= available_i.",),
    )


def _forced_selection(split, index):
    cases = {
        ("train", 109): (14, 6, 3, "volleyball"),
        ("train", 487): (12, 5, 2, "basketball"),
    }
    if (split, index) not in cases:
        return None
    total, selected, required, sport = cases[split, index]
    return _template(
        "discrete.forced_selection",
        {"total": (total, 5, 18), "selected": (selected, 3, 12), "required": (required, 1, 4)},
        lambda total, selected, required: (
            f"A {sport} team has {total} players. In how many ways can {selected} starters be chosen "
            f"if a specified set of {required} players must all start? Order does not matter."
        ),
        lambda total, selected, required: comb(total - required, selected - required),
        lambda total, selected, required: sum(
            all(player in lineup for player in range(required))
            for lineup in combinations(range(total), selected)
        ),
        allowed=lambda total, selected, required: required < selected < total,
        constraints=("required < selected < total",),
    )


def _pascal_triangle(split, index):
    cases = {
        ("train", 151): (42, 2, "entry"),
        ("train", 175): (6, 0, "interior"),
        ("train", 211): (12, 4, "entry"),
        ("train", 699): (8, 0, "sum"),
        ("train", 712): (20, 0, "cumulative"),
        ("test", 76): (10, 0, "sum"),
        ("test", 106): (11, 9, "entry"),
        ("test", 160): (6, 0, "primes"),
        ("test", 195): (10, 3, "entry"),
        ("test", 435): (4, 0, "sum_expression"),
    }
    if (split, index) not in cases:
        return None
    n, position, mode = cases[split, index]
    domains = {"n": (n, 2, 18 if mode == "primes" else 48)}
    if mode == "entry":
        domains["position"] = (position, 2, 20)

    def render(n, position=0):
        if mode == "sum_expression":
            summands = "+".join(rf"\binom{{{n}}}{{{i}}}" for i in range(n + 1))
            return f"Compute ${summands}$."
        if mode == "entry":
            return f"In the row of Pascal's triangle that begins 1, {n}, what is entry number {position}, counting from 1?"
        if mode == "cumulative":
            return f"How many entries are in the first {n} rows of Pascal's triangle, starting with the row containing only 1?"
        target = {
            "sum": "What is the sum of all the entries",
            "interior": "What is the sum of the entries other than the first and last",
            "primes": "How many entries are prime numbers",
        }[mode]
        return f"{target} in row {n} of Pascal's triangle, if the row containing only 1 is row 0?"

    def solve(n, position=0):
        if mode == "entry":
            return comb(n, position - 1)
        if mode == "interior":
            return 2 ** n - 2
        if mode == "cumulative":
            return n * (n + 1) // 2
        if mode == "primes":
            return sum(_is_prime(comb(n, i)) for i in range(n + 1))
        return 2 ** n

    def reference(n, position=0):
        row = [1]
        count = 0
        for _ in range(n):
            count += len(row)
            row = [a + b for a, b in zip([0] + row, row + [0])]
        if mode == "entry":
            return row[position - 1]
        if mode == "interior":
            return sum(row[1:-1])
        if mode == "cumulative":
            return count
        if mode == "primes":
            return sum(len(_divisors(value)) == 2 for value in row)
        return sum(row)

    return _template(
        "discrete.pascal_" + mode, domains, render, solve, reference,
        allowed=(lambda n, position: position <= n + 1) if mode == "entry" else None,
        constraints=("position <= n + 1",) if mode == "entry" else (),
        adaptation="States the row and entry indexing explicitly.",
    )


def _standard_deck(split, index):
    cases = {
        ("train", 11): (3, ("Jack", "Queen", "King"), "ordered_ranks"),
        ("train", 391): (2, ("diamonds", "spades"), "ordered_suits"),
        ("train", 517): (2, ("6", "Queen"), "ordered_ranks"),
        ("train", 747): (2, ("red",), "all_color"),
        ("test", 35): (2, ("hearts", "diamonds"), "either_suit"),
        ("test", 88): (2, ("face cards",), "all_face"),
        ("test", 297): (3, ("hearts",), "all_suit"),
        ("test", 355): (2, ("hearts", "clubs"), "ordered_suits"),
        ("test", 453): (2, ("Ace",), "all_rank"),
    }
    if (split, index) not in cases:
        return None
    drawn, labels, mode = cases[split, index]
    if mode == "ordered_ranks":
        choices = ("Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King")
        domains = {"drawn": (drawn, 2, 5)}
    elif mode == "ordered_suits":
        choices = ("clubs", "diamonds", "hearts", "spades")
        domains = {"drawn": (drawn, 2, 4)}
    else:
        choices = ()
        domains = {"drawn": (drawn, 2, 4 if mode == "all_rank" else 8)}

    # Preserve distinct classes and add subsequent classes when the draw count
    # exceeds the source case. A selected class is never depleted by earlier draws.
    ordered = bool(choices)
    if ordered:
        labels += tuple(choice for choice in choices if choice not in labels)

    def render(drawn):
        if ordered:
            label = "ranks" if mode == "ordered_ranks" else "suits"
            event = f"the drawn cards have {label} {', '.join(labels[:drawn])}, respectively"
        elif mode == "either_suit":
            event = "all are hearts or all are diamonds"
        elif mode == "all_suit":
            event = f"all are {labels[0]}"
        elif mode == "all_rank":
            event = f"all are of rank {labels[0]}"
        elif mode == "all_face":
            event = "all are face cards (Jacks, Queens, or Kings)"
        else:
            event = "all are red"
        return (f"Draw {drawn} cards at random without replacement from a standard deck of 52 cards. "
                f"What is the probability that {event}?")

    matching = {"ordered_ranks": 4, "ordered_suits": 13, "all_color": 26,
                "either_suit": 13, "all_face": 12, "all_suit": 13, "all_rank": 4}[mode]
    multiplier = 2 if mode == "either_suit" else 1

    def solve(drawn):
        if ordered:
            return Fraction(matching ** drawn, perm(52, drawn))
        return Fraction(multiplier * comb(matching, drawn), comb(52, drawn))

    def reference(drawn):
        return multiplier * prod(Fraction(matching if ordered else matching - i, 52 - i)
                                 for i in range(drawn))

    return _template(
        "discrete.deck_" + mode, domains, render, solve, reference,
        adaptation="States that the cards are drawn without replacement.",
    )


def _seating(split, index):
    cases = {
        ("train", 127): (6, 6, "bracelet"),
        ("train", 275): (4, 4, "separate"),
        ("train", 318): (5, 5, "circle"),
        ("train", 590): (4, 4, "not_first"),
        ("train", 616): (7, 6, "seats"),
        ("test", 114): (8, 8, "circle"),
        ("test", 176): (5, 5, "keychain"),
        ("test", 234): (6, 6, "ends"),
    }
    if (split, index) not in cases:
        return None
    people, places, mode = cases[split, index]
    domains = {"people": (people, 4, 8)}
    if mode == "seats":
        domains["places"] = (places, 3, 7)

    def render(people, places=None):
        if mode == "seats":
            return (f"{people} people arrive at a round table that seats only {places}. "
                    "How many ways can people fill the table if rotations count as the same seating?")
        if mode in {"circle", "bracelet", "keychain"}:
            if mode == "circle":
                return (f"In how many ways can {people} people sit around a circular table? "
                        "Rotations count as the same seating.")
            item = "beads on a bracelet" if mode == "bracelet" else "keys on a keychain"
            return (f"In how many ways can {people} distinct {item} be arranged? "
                    "Rotations and reflections count as the same arrangement.")
        if mode == "separate":
            return (f"In how many ways can {people} people stand in a row if a specified pair "
                    "of people refuses to stand next to each other?")
        if mode == "not_first":
            return f"In how many ways can {people} people stand in a row if the youngest person cannot be first?"
        return (f"How many ways can {people} different books, exactly two of which are math books, "
                "be arranged on a shelf if both ends must be occupied by math books?")

    def solve(people, places=None):
        if mode == "seats":
            return comb(people, places) * factorial(places - 1)
        if mode == "circle":
            return factorial(people - 1)
        if mode in {"bracelet", "keychain"}:
            return factorial(people - 1) // 2
        if mode == "separate":
            return factorial(people) - 2 * factorial(people - 1)
        if mode == "not_first":
            return factorial(people) - factorial(people - 1)
        return 2 * factorial(people - 2)

    def reference(people, places=None):
        count = 0
        for lineup in permutations(range(people), places or people):
            if mode in {"seats", "circle", "bracelet", "keychain"}:
                accepted = lineup[0] == min(lineup)
                if mode in {"bracelet", "keychain"}:
                    accepted = accepted and lineup[1] < lineup[-1]
            elif mode == "separate":
                accepted = abs(lineup.index(0) - lineup.index(1)) > 1
            elif mode == "not_first":
                accepted = lineup[0] != 0
            else:
                accepted = {lineup[0], lineup[-1]} == {0, 1}
            count += accepted
        return count

    return _template(
        "discrete.arrangements_" + mode, domains, render, solve, reference,
        allowed=(lambda people, places: places < people) if mode == "seats" else None,
        constraints=("places < people",) if mode == "seats" else (),
    )

def build(row):
    subject, split, index = row["id"].split("/")
    index = int(index)
    body = " ".join(row["problem"].strip().split())
    if subject == "number_theory":
        template = _fixed_progression(split, index)
        if template is not None:
            return template
    for parser in (_prime_family, _square_ranges, _multiples_in_range):
        template = parser(subject, split, index)
        if template is not None:
            return template
    for parser in (_plain_gcd_lcm, _plain_divisors, _binomial, _residue_expression):
        template = parser(body)
        if template is not None:
            return template
    if subject == "number_theory":
        template = _base_to_decimal(body, split, index)
        if template is not None:
            return template
        parsers = (_divisor_restrictions, _base_statistics, _decimal_digit,
                   _congruence, _repeating_decimal, _crt)
    elif subject == "counting_and_probability":
        template = _arrange_word(body, split, index)
        if template is not None:
            return template
        parsers = (_curated_selection, _handshakes_and_diagonals, _occupancy,
                   _fair_coins, _unfair_coins, _complement, _dice_sums, _dice_distance,
                   _urn, _linear_pairs, _quota_selection, _forced_selection,
                   _pascal_triangle, _standard_deck, _seating)
    else:
        return None
    for parser in parsers:
        template = parser(split, index)
        if template is not None:
            return template
    return None
