"""Determinants vectors and planes; exact source-bound mathematical models."""
from fractions import Fraction as Q
from itertools import permutations
from math import gcd, prod
from template_dataset.families.construction import choice, integers, is_square
from template_dataset.families.arithmetic.finite_integer_and_radical_models import add as _add

BINDINGS = {}


def add(key, *args, **kwargs):
    _add(key,*args,bindings=BINDINGS,**kwargs)


def matrix(rows, environment='pmatrix'):
    return r'\begin{'+environment+'}'+r'\\'.join(' & '.join(map(str,row)) for row in rows)+r'\end{'+environment+'}'


def vector(entries):
    return matrix([(entry,) for entry in entries])


def det(rows):
    if len(rows)==1:
        return rows[0][0]
    return sum((-1)**j*entry*det([row[:j]+row[j+1:] for row in rows[1:]])
               for j,entry in enumerate(rows[0]))


def dot(a,b):
    return sum(x*y for x,y in zip(a,b))


def cross(a,b):
    return [a[(i+1)%3]*b[(i+2)%3]-a[(i+2)%3]*b[(i+1)%3] for i in range(3)]


def tex_fraction(q):
    q=Q(q)
    if q.denominator==1:
        return str(q.numerator)
    return ('-' if q<0 else '')+rf'\frac{{{abs(q.numerator)}}}{{{q.denominator}}}'


def skew_matrix(a,b,c):
    return [[0,a,b],['-'+a,0,c],['-'+b,'-'+c,0]]


def skew_differences(a,b,c):
    rows=[[0,rf'{a}(b-a)',rf'{b}(c-a)'],[rf'{a}(a-b)',0,rf'{c}(c-b)'],[rf'{b}(a-c)',rf'{c}(b-c)',0]]
    rows = [[entry[1:] if isinstance(entry,str) and entry.startswith('1(') else entry
             for entry in row] for row in rows]
    return 'Evaluate $'+matrix(rows,'vmatrix')+'$.'


add('test/171','skew_difference_determinant',{'ab_weight':(1,12),'ac_weight':(1,12),'bc_weight':(1,12)},(1,1,1),
    skew_differences,lambda a,b,c:0,
    reference=lambda a,b,c:det([[0,2*a,5*b],[-2*a,0,3*c],[-5*b,-3*c,0]]))

def orthogonal_triple_prompt(a,b):
    a=[a[0],r'\sqrt{\pi}',a[1]]
    return rf'Let $\mathbf a={vector(a)}$ and $\mathbf b={vector(b)}$. Compute $\mathbf a\cdot(\mathbf a\times\mathbf b)$.'


def orthogonal_triple_ref(a,b):
    # Constant and sqrt(pi) coefficients determined by evaluating the
    # determinant polynomial at 0 and 1. It is at most degree one.
    return max(abs(dot(v,cross(v,b))) for t in (0,1) for v in ([a[0],t,a[1]],))


add('test/198','orthogonal_vector_triple_product',{'a_numeric_entries':integers(2,-30,30),'b_entries':integers(3,-30,30)},
    ([4,-14],[-1,3,10]),orthogonal_triple_prompt,lambda a,b:0,reference=orthogonal_triple_ref)


def cut_planes(planes):
    labels=('x=y','y=z','z=x')
    return ', '.join('$'+labels[i]+'$' for i in planes)


add('test/266','cube_cut_by_coordinate_equalities',{'side_length':(1,20),'planes':integers(3,0,2,min_length=1,max_length=3)},
    (1,[0,1,2]),lambda s,p:rf'The cube $\{{(x,y,z):0\le x,y,z\le {s}\}}$ is cut along {cut_planes(p)}. How many pieces are there?',
    lambda s,p:2*len(p) if len(p)==3 else 2**len(p),valid=lambda s,p:len(set(p))==len(p),
    sample=lambda r:(r.randint(1,20),sorted(r.sample(range(3),r.randint(1,3)))),
    constraint='The cutting planes are distinct. Plane indices 0, 1 and 2 denote x=y, y=z and z=x.',
    reference=lambda s,p:len({tuple((point[i]<point[(i+1)%3]) for i in p) for point in permutations(range(3))}))


def log_det(n):
    names=list('xyzuvw')[:n]
    rows=[[1 if a==b else rf'\log_{{{a}}}{b}' for b in names] for a in names]
    return 'For positive real numbers $'+','.join(names)+'$, none equal to 1, find $'+matrix(rows,'vmatrix')+'$.'


add('test/272','logarithm_change_of_base_determinant',{'dimension':(2,6)},(3,),log_det,lambda n:0,
    reference=lambda n:det([[Q(j,i) for j in range(1,n+1)] for i in range(1,n+1)]))

RATIONAL={'type':'rational','min':-120,'max':120}


def sum_product_matrix_prompt(a,b,c,d):
    mat_a=matrix([[1,'x'],['y',tex_fraction(a)]])
    mat_b=matrix([[tex_fraction(b),tex_fraction(c)],[tex_fraction(d),'z']])
    return rf'The matrices $A={mat_a}$ and $B={mat_b}$ satisfy $A+B=AB$. Find $x+y+z$.'


def sample_matrix_equation(r):
    b=Q(r.choice((-2,-1,2,3,4,5)),r.randint(1,3))
    if b==1:
        b=Q(7,3)
    d=r.randint(2,20)
    y=r.randint(1,16)
    a=1-y*(b-1)/d
    return str(a),str(b),str(Q(1,y)),str(d)


def matrix_equation_valid(a,b,c,d):
    a,b,c,d=map(Q,(a,b,c,d))
    return b!=1 and d!=0 and (1-a)*d*c==b-1


def sum_product_matrix(a,b,c,d):
    a,b,c,d=map(Q,(a,b,c,d))
    return 1/d+(1-a)*d/(b-1)+1


add('test/347','matrix_sum_equals_product',
    {'a22':RATIONAL,'b11':RATIONAL,'b12':RATIONAL,'b21':RATIONAL},('-9/5','12/5','1/10','5'),
    sum_product_matrix_prompt,sum_product_matrix,valid=matrix_equation_valid,sample=sample_matrix_equation,
    constraint='b11 differs from one, b21 is nonzero, and (1−a22) b21 b12 = b11−1.')


def shifted_quartic_prompt(cubic,re,im):
    d=cubic//4
    return f'The roots of $z^4{cubic:+d}iz^3{-6*d*d:+d}z^2{-4*d**3:+d}iz{re:+d}{im:+d}i=0$ form a convex polygon in the complex plane. Its area is $p^{{a/b}}$ for positive coprime integers $a,b$ and prime $p$. Find $a+b+p$.'


def quartic_norm(cubic,re,im):
    return ((cubic//4)**4-re)**2+im*im


def sample_quartic(r):
    d=r.choice(tuple(range(-5,0))+tuple(range(1,6)))
    k=r.randint(0,5)
    # Gaussian numbers with squared modulus 2^k.
    n=2**(k//2)
    a,b=(n,0) if k%2==0 else (n,n)
    if r.choice((False,True)):
        a,b=b,a
    return 4*d,d**4-r.choice((-a,a)),-r.choice((-b,b))


def quartic_polygon(cubic,re,im):
    exponent=1+Q(quartic_norm(cubic,re,im).bit_length()-1,4)
    return exponent.numerator+exponent.denominator+2


add('test/95','shifted_quartic_square_area',
    {'cubic_imaginary_coefficient':(-20,20),'constant_real':(-16,650),'constant_imaginary':(-16,16)},
    (4,0,-1),shifted_quartic_prompt,quartic_polygon,
    valid=lambda a,b,c:a%4==0 and (n:=quartic_norm(a,b,c))>0 and n&(n-1)==0,
    sample=sample_quartic,constraint='The cubic imaginary coefficient is divisible by four. The translated constant has squared modulus a positive power of two, including 2^0.')


def triple_difference(a,b,c,t):
    b=[b[0],t,b[1]]
    return dot([u-v for u,v in zip(a,b)],cross([u-v for u,v in zip(b,c)],[u-v for u,v in zip(c,a)]))


add('train/125','dependent_vector_differences',
    {'a_entries':integers(3,-30,30),'b_numeric_entries':integers(2,-30,30),'c_entries':integers(3,-30,30)},
    ([-3,10,1],[5,0],[-2,-2,7]),
    lambda a,b,c:rf'Let $\mathbf a={vector(a)}$, $\mathbf b={vector([b[0],chr(92)+"pi",b[1]])}$ and $\mathbf c={vector(c)}$. Compute $(\mathbf a-\mathbf b)\cdot[(\mathbf b-\mathbf c)\times(\mathbf c-\mathbf a)]$.',
    lambda a,b,c:0,reference=lambda a,b,c:max(abs(triple_difference(a,b,c,t)) for t in (0,1,2)))


def skew_real_roots(a,b,c,d):
    rows=[[f'x-{d}' if d else 'x',f'{c}c',f'-{b}b'],[f'-{c}c',f'x-{d}' if d else 'x',f'{a}a'],
          [f'{b}b',f'-{a}a',f'x-{d}' if d else 'x']]
    return 'Let $a,b,c$ be nonzero real numbers. How many real roots does $'+matrix(rows,'vmatrix')+r'=0$ have?'


add('train/137','real_roots_shifted_skew_determinant',
    {'a_coefficient':(1,10),'b_coefficient':(1,10),'c_coefficient':(1,10),'diagonal_shift':(0,15)},(1,1,1,0),
    skew_real_roots,lambda a,b,c,d:1)


def trig_skew_prompt(a,b,c):
    rows=skew_matrix(rf'{a}\sin\alpha',rf'{b}\cos\alpha',rf'{c}\sin\beta')
    rows[0][2]='-'+rows[0][2]
    rows[2][0]=rows[2][0][1:]
    return 'Evaluate $'+matrix(rows,'vmatrix')+'$.'


add('train/233','trigonometric_skew_determinant',{'sine_alpha_coefficient':(1,20),'cosine_alpha_coefficient':(1,20),'sine_beta_coefficient':(1,20)},
    (1,1,1),trig_skew_prompt,lambda a,b,c:0)


def rotations_prompt(signs):
    rows=[[r'\cos\alpha\cos\beta',r'\cos\alpha\sin\beta',r'-\sin\alpha'],[r'-\sin\beta',r'\cos\beta','0'],
          [r'\sin\alpha\cos\beta',r'\sin\alpha\sin\beta',r'\cos\alpha']]
    rows=[[('-' if not value.startswith('-') else '')+value.lstrip('-') if s<0 and value!='0' else value for value in row] for row,s in zip(rows,signs)]
    return 'Evaluate $'+matrix(rows,'vmatrix')+'$.'


add('train/28','orientation_of_orthogonal_trig_matrix',{'row_signs':integers(3,-1,1)},([1,1,1],),
    rotations_prompt,prod,valid=lambda signs:all(signs),sample=lambda r:([r.choice((-1,1)) for _ in range(3)],),
    constraint='Every row sign is +1 or −1.')


def orthogonal_columns(a,b,c):
    return all((dot(a,a),dot(b,b),dot(c,c))) and dot(a,b)==dot(b,c)==dot(c,a)==0


def sample_orthogonal_columns(r):
    a,b=r.sample(range(1,5),2)
    k=r.randint(1,4)
    v=[0,a,b]
    w=[k,b,-a]
    t=cross(v,w)
    common=gcd(*t)
    return v,w,[x//common for x in t]


def orthogonal_column_prompt(a,b,c):
    return rf'The matrix $M={matrix([[f"{i}x",f"{j}y",f"{k}z"] for i,j,k in zip(a,b,c)])}$ satisfies $M^TM=I$. Find $x^2+y^2+z^2$.'


add('train/303','orthogonal_column_normalization',
    {'x_coefficients':integers(3,-40,40),'y_coefficients':integers(3,-40,40),'z_coefficients':integers(3,-40,40)},
    ([0,1,1],[2,1,-1],[1,-1,1]),orthogonal_column_prompt,
    lambda a,b,c:sum(Q(1,dot(v,v)) for v in (a,b,c)),valid=orthogonal_columns,
    sample=sample_orthogonal_columns,constraint='The three coefficient columns are nonzero and pairwise orthogonal.')


def cube_height_terms(side,heights):
    total=sum(heights)
    radicand=total*total-3*(sum(x*x for x in heights)-side*side)
    return total,radicand


def cube_height_valid(side,heights):
    r,s=cube_height_terms(side,heights)
    return (s>0 and not is_square(s) and r*r>s and (r-3*min(heights))**2<s and not (r%3==0 and s%9==0))


def sample_cube_heights(r):
    candidates=[]
    for side in range(4,19):
        for offset1 in range(0,3):
            for offset2 in range(0,4):
                heights=[side,side+offset1,side+offset1+offset2]
                if cube_height_valid(side,heights):
                    candidates.append((side,heights))
    return r.choice(candidates)


add('train/309','closest_cube_vertex_height',{'side_length':(4,30),'adjacent_heights':integers(3,4,45)},(10,[10,11,12]),
    lambda l,h:rf'A cube of side {l} lies above a plane. The closest vertex is $A$, and the vertices adjacent to $A$ have heights {h[0]}, {h[1]}, and {h[2]} above the plane. Write the height of $A$ as $(r-\sqrt s)/t$ with positive integers $r,s,t$, $s$ nonsquare, and $t$ as small as possible. Find $r+s+t$.',
    lambda l,h:sum(cube_height_terms(l,h))+3,valid=cube_height_valid,sample=sample_cube_heights,
    constraint='The height equation has a positive lower root below all three given heights. Its discriminant term is nonsquare and no common factor of 3 can be removed.',
    adaptation='Replace the source sum bound by the primitive representation condition on t, preserving the original unique triple.')


def cubic_circulant(a,b,c):
    terms=[f'{a:+d}x^2' if a else '',f'{b:+d}x' if b else '',f'{c:+d}' if c else '']
    if not a and not b and not c:
        terms=['+px','+q']
    return 'Let $a,b,c$ be the roots, counted with multiplicity, of $x^3'+''.join(terms)+'=0$. Compute $'+matrix([['a','b','c'],['b','c','a'],['c','a','b']],'vmatrix')+'$.'


add('train/434','circulant_determinant_vieta',{'quadratic_coefficient':(-12,12),'linear_coefficient':(-30,30),'constant_coefficient':(-30,30)},
    (0,0,0),cubic_circulant,lambda a,b,c:a*(a*a-3*b),
    adaptation='The source symbolic p and q remain arbitrary when all coefficients are zero in the parameter encoding. That symbolic case and the zero-coefficient cubic have the same determinant.')


def oriented_basis_prompt(orientation,coords):
    a,b,c=coords
    target=rf'{a}\mathbf a{b:+d}\mathbf b{c:+d}\mathbf c'
    if coords==[1,0,0]:
        target=r'\mathbf a'
    return rf'Let $\mathbf a,\mathbf b,\mathbf c$ be mutually orthogonal unit vectors with $\mathbf a\cdot(\mathbf b\times\mathbf c)={orientation}$. If ${target}=p(\mathbf a\times\mathbf b)+q(\mathbf b\times\mathbf c)+r(\mathbf c\times\mathbf a)$, find $p+q+r$.'


add('train/544','oriented_basis_cross_coordinates',{'orientation':choice((-1,1)),'target_coefficients':integers(3,-12,12)},(1,[1,0,0]),
    oriented_basis_prompt,lambda o,c:o*sum(c),
    reference=lambda o,c:sum(dot([c[0],c[1],o*c[2]],cross(u,v)) for u,v in [([1,0,0],[0,1,0]),([0,1,0],[0,0,o]),([0,0,o],[1,0,0])]))


def gram_prompt(a,b,c):
    f=lambda n,s: (str(n) if n!=1 else '')+s
    rows=[[a*a,f(a*b,r'\cos(a-b)'),f(a*c,r'\cos a')],[f(a*b,r'\cos(a-b)'),b*b,f(b*c,r'\cos b')],
          [f(a*c,r'\cos a'),f(b*c,r'\cos b'),c*c]]
    return 'Compute $'+matrix(rows,'vmatrix')+'$.'


add('train/566','rank_two_trigonometric_gram_matrix',{'first_radius':(1,12),'second_radius':(1,12),'third_radius':(1,12)},
    (1,1,1),gram_prompt,lambda a,b,c:0,
    reference=lambda a,b,c:det([[dot(u,v) for v in ([a,0],[0,b],[c,0])] for u in ([a,0],[0,b],[c,0])]))


def vector_cross_prompt(a,b,k):
    return rf'Let vectors $\mathbf u,\mathbf v$ have lengths {a} and {b}, respectively. Suppose $\mathbf w=\mathbf u\times\mathbf v+{k}\mathbf u$ and $\mathbf w\times\mathbf u={a*a}\mathbf v$. Compute $\mathbf u\cdot(\mathbf v\times\mathbf w)$.'


add('train/592','vector_triple_product_constrained_cross',{'u_length':(1,12),'v_length':(1,12),'u_coefficient':(1,12)},
    (1,1,1),vector_cross_prompt,lambda a,b,k:(a*b)**2,
    reference=lambda a,b,k:dot([a,0,0],cross([0,b,0],[k*a,0,a*b])))


def centroid_prompt(n):
    labels='ABCDEFHI'[:n]
    return rf'Let $G$ be the centroid of the {n} points ${",".join(labels)}$, and $P$ an arbitrary point. Find $k$ such that ${"+".join("P"+v+"^2" for v in labels)}=k\,PG^2+{"+".join("G"+v+"^2" for v in labels)}$ for all $P$.'


add('train/743','centroid_squared_distances',{'points':(3,8)},(3,),centroid_prompt,lambda n:n,
    reference=lambda n:(lambda g:sum(i*i-(i-g)**2 for i in range(n))/(g*g))(Q(n-1,2)),
    adaptation='Apply the same centroid identity to a variable number of points, with three at the source instance.')

def intercept_sphere_prompt(n):
    fixed=', '.join('abcdef'[:n])
    center=', '.join('pqrstu'[:n])
    total='+'.join(rf'\frac{{{a}}}{{{b}}}' for a,b in zip('abcdef'[:n],'pqrstu'[:n]))
    return rf'In $\mathbb R^{n}$, a hyperplane passes through $({fixed})$ and meets each coordinate axis in a single point distinct from the origin. Let $({center})$ be the center of the sphere through these intercepts and the origin. Find ${total}$.'


add('train/512','coordinate_intercept_sphere_center',{'dimension':(2,6)},(3,),
    lambda n:intercept_sphere_prompt(n),lambda n:2,
    adaptation='Allow the same intercept-sphere problem in dimensions other than the source dimension three.')
