"""Exact mathematical models for precalculus."""
