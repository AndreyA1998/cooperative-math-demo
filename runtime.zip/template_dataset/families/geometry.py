"""Exact geometry and precalculus templates bound to verified source IDs."""
import re
from fractions import Fraction
from itertools import permutations, product
from math import ceil, gcd, isqrt

from template_dataset.core import Template


_INT_TOKEN = re.compile(r'-?\d+')
_DEGREES = re.compile(
    r'(?:Compute|Find|Simplify|Evaluate) \$\\(sin|cos|tan|cot|sec|csc) '
    r'\(?(-?\d+)\^\{?\\circ\}?\)?\$\.'
)
_RADIAN_IDS = {
    'train/118': ('sin', -6), 'train/139': ('sec', 20),
    'train/305': ('tan', 27), 'train/729': ('tan', -9),
    'test/91': ('cos', 4), 'test/209': ('cot', 18),
}
_SINE = dict(zip(range(0, 360, 30), (
    0, Fraction(1, 2), None, 1, None, Fraction(1, 2),
    0, Fraction(-1, 2), None, -1, None, Fraction(-1, 2),
)))


def _trig(function, angle):
    if function in ('tan', 'cot'):
        numerator = {0: 0, 45: 1, 135: -1, 180: 0, 225: 1, 315: -1}
        if function == 'tan':
            return numerator.get(angle % 360)
        return numerator.get((90 - angle) % 360)
    value = _SINE.get((angle + (90 if function in ('cos', 'sec') else 0)) % 360)
    if function in ('csc', 'sec'):
        return Fraction(1, value) if value else None
    return value


def _latex_fraction(value):
    value = Fraction(value)
    if value.denominator == 1:
        return str(value.numerator)
    return ('-' if value < 0 else '') + (
        rf'\frac{{{abs(value.numerator)}}}{{{value.denominator}}}'
    )


def _exact_trig(function, original, radians=False):
    name = 'pi_twelfths' if radians else 'degrees'
    step = 15 if radians else 1
    valid = [n for n in range(-4320 // step, 4320 // step + 1)
             if _trig(function, n * step) is not None]

    def render(p):
        angle = p[name]
        if radians:
            multiple = Fraction(angle, 12)
            num = abs(multiple.numerator)
            numerator = (str(num) if num != 1 else '') + r'\pi' if num else '0'
            literal = numerator if multiple.denominator == 1 else (
                rf'\frac{{{numerator}}}{{{multiple.denominator}}}'
            )
            literal = ('-' if multiple < 0 else '') + literal
        else:
            literal = rf'{angle}^\circ'
        return rf'Compute $\{function}\left({literal}\right)$.'

    return Template(
        family='exact-special-angle', parameters={name: {'type': 'int', 'choices': valid}},
        original={name: original}, render=render,
        solve=lambda p: _trig(function, p[name] * step),
        sample=lambda rng: {name: rng.choice(valid)},
        validate=lambda p: set(p) == {name} and type(p[name]) is int and p[name] in valid,
        constraints=['The function is defined and the special-angle value is rational.'],
        reference=None, adaptation='Equivalent angle notation, with the original angular unit.',
    )


_RECIPES = {}


def _register(subject, ids, family, fields, solve, *, domains=None, valid=None,
              sample=None, constraint='', reference=None, adaptation=''):
    for source_id in ids.split():
        split, number = source_id.split('/')
        key = f'{subject}/{split}/{number}'
        if key in _RECIPES:
            raise ValueError(f'Duplicate geometry template: {key}')
        _RECIPES[key] = (family, fields.split(), solve, domains or {}, valid,
                         sample, constraint, reference, adaptation)


def _geometry(ids, family, fields, solve, **kwargs):
    _register('geometry', ids, family, fields, solve, **kwargs)


def _precalculus(ids, family, fields, solve, **kwargs):
    _register('precalculus', ids, family, fields, solve, **kwargs)


def _bind(problem, recipe):
    # An underscore keeps a structural literal from the source, such as the
    # degree measure of a right angle or a coordinate equal to zero.
    family, fields, solve, overrides, valid, sample, constraint, reference, adaptation = recipe
    tokens = list(_INT_TOKEN.finditer(problem))
    if len(tokens) != len(fields):
        raise ValueError(f'Unexpected numeric literals for {family}: {problem}')
    original = {}
    for token, key in zip(tokens, fields):
        if key != '_':
            value = int(token[0])
            if key in original and original[key] != value:
                raise ValueError(f'Inconsistent repeated parameter {key}: {problem}')
            original[key] = value
    bounds = {key: overrides.get(key, (min(1, value), max(40, value)))
              for key, value in original.items()}
    parameters = {
        key: ({'type': 'int', 'min': domain[0], 'max': domain[1]}
              if isinstance(domain, tuple) else {'type': 'int', 'choices': domain})
        for key, domain in bounds.items()
    }

    def validate(p):
        if set(p) != set(original):
            return False
        for key, domain in bounds.items():
            value = p[key]
            if type(value) is not int:
                return False
            if isinstance(domain, tuple):
                if not domain[0] <= value <= domain[1]:
                    return False
            elif value not in domain:
                return False
        return valid is None or valid(**p)

    def generate(rng):
        if sample is not None:
            return sample(rng)
        # Coupled simple inequalities here have a large feasible subset. Bound
        # the retries and use the known valid source input as a last resort.
        for _ in range(128):
            p = {
                key: rng.randint(*domain) if isinstance(domain, tuple) else rng.choice(domain)
                for key, domain in bounds.items()
            }
            if validate(p):
                return p
        return dict(original)

    def render(p):
        chunks = []
        cursor = 0
        for token, key in zip(tokens, fields):
            chunks.append(problem[cursor:token.start()])
            literal = token[0] if key == '_' else str(p[key])
            if key != '_' and token.start() and problem[token.start()-1] == '^' and len(literal)>1:
                literal = '{' + literal + '}'
            chunks.append(literal)
            cursor = token.end()
        return ''.join(chunks) + problem[cursor:]

    return Template(
        family=family, parameters=parameters, original=original, render=render,
        solve=lambda p: solve(**p), sample=generate, validate=validate,
        constraints=[constraint] if constraint else [],
        reference=None if reference is None else lambda p: reference(**p),
        adaptation=adaptation,
    )


def _square(value):
    return value >= 0 and isqrt(value) ** 2 == value


def _cube_root(value):
    # Domains are bounded. Integer binary search avoids floating point.
    lo, hi = 0, value + 1
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if mid ** 3 <= value:
            lo = mid
        else:
            hi = mid
    return lo


def _round(value, places=0):
    factor = 10 ** places
    positive = abs(Fraction(value))
    result = Fraction((2 * positive * factor + 1) // 2, factor)
    return result if value >= 0 else -result


def _possible_sides(a, b):
    return range(abs(a - b) + 1, a + b)


def _triangle(a, b, c):
    return min(a, b, c) > 0 and 2 * max(a, b, c) < a + b + c


def _area4_squared(a, b, c):
    return (a + b + c) * (-a + b + c) * (a - b + c) * (a + b - c)


def _triangle_area(a, b, c):
    return Fraction(isqrt(_area4_squared(a, b, c)), 4)


def _heron_valid(a, b, c):
    return _triangle(a, b, c) and _square(_area4_squared(a, b, c))


_TRIPLES = tuple(
    (a, b, c)
    for a in range(1, 61)
    for b in range(a + 1, 81)
    for c in (isqrt(a*a + b*b),)
    if c*c == a*a + b*b
)


def _right(a, b, c):
    return a > 0 and b > 0 and a*a + b*b == c*c


def _triple_sample(rng, names=('a', 'b', 'c'), maximum=40):
    return dict(zip(names, rng.choice([t for t in _TRIPLES if t[-1] <= maximum])))


def _triangle_coordinates(x1, y1, x2, y2, x3, y3):
    return (x2-x1)*(y3-y1) - (x3-x1)*(y2-y1)


def _shoelace(*points):
    return Fraction(abs(sum(
        x * v - y * u
        for (x, y), (u, v) in zip(points, points[1:] + points[:1])
    )), 2)


for ids, fields, compute, reference in (
    ('train/114', 'a b', lambda a, b: a + b - 1, lambda a, b: max(_possible_sides(a, b))),
    ('train/131 test/281', 'a b', lambda a, b: max(a, b) * (2 * min(a, b) - 1),
     lambda a, b: sum(_possible_sides(a, b))),
    ('train/371 train/376 train/676', 'a b', lambda a, b: 2 * min(a, b) - 1,
     lambda a, b: len(_possible_sides(a, b))),
    ('train/233', 'a b', lambda a, b: 2 * max(a, b) + 1,
     lambda a, b: a + b + min(_possible_sides(a, b))),
    ('test/464', 'a b', lambda a, b: 2 * min(a, b) - 2,
     lambda a, b: max(_possible_sides(a, b)) - min(_possible_sides(a, b))),
    ('test/29', 'a', lambda a: 4 * a - 1, lambda a: 2 * a + max(_possible_sides(a, a))),
    ('test/145', '_ b', lambda b: b, lambda b: sum(_possible_sides(1, b))),
):
    _geometry(ids, 'integer-triangle-inequality', fields,
              compute, reference=reference,
              domains={'a':(2,40),'b':(2,40)} if ids=='test/464' else None)

_geometry('test/447', 'triangle-inequality-die', 'a b _ _',
          lambda a, b: Fraction(max(0, min(6, a+b-1)-abs(a-b)), 6),
          reference=lambda a, b: Fraction(
              sum(_triangle(a, b, c) for c in range(1, 7)), 6))
_geometry('test/102', 'isosceles-perimeter-count', 'p',
          lambda p: (p-1)//2 - p//4,
          reference=lambda p: sum(_triangle(a, a, p-2*a) for a in range(1, p)))
_geometry('test/218', 'isosceles-max-perimeter', 'a b',
          lambda a, b: 2*max(a, b) + min(a, b),
          reference=lambda a, b: max(
              2*x+y for x, y in [(a,b),(b,a)] if _triangle(x,x,y)))
_geometry('train/400', 'isosceles-base', 'a p', lambda a, p: p-2*a,
          valid=lambda a, p: 2*a < p < 4*a, constraint='The base lies between 0 and twice the leg.')
_geometry('train/578', 'scalene-max-side', 'p', lambda p: (p-1)//2,
          domains={'p': (11, 80)},
          reference=lambda p: max(
              c for c in range(1,p) for a in range(1,c)
              for b in (p-a-c,) if a < b < c and a+b > c))

for ids, fields, compute in (
    ('train/148 test/285', 'r', lambda r: r*r),
    ('test/412', 'r', lambda r: 2*r*r),
    ('test/283', 'a', lambda a: Fraction(a*a,2)),
    ('test/244', 'r', lambda r: (2*r)**3),
    ('train/678', '_ a', lambda a: a*a),
):
    _geometry(ids, 'inscribed-or-subdivided-shape', fields, compute)

_DIVISORS = [n for n in range(1,121) if 360 % n == 0]
for ids, family, solve, ref in (
    ('train/87 train/447', 'exterior-angle-side-count', lambda angle: 360//angle,
     lambda angle: next(n for n in range(3,361) if n*angle == 360)),
    ('train/19', 'exterior-angle-interior-sum', lambda angle: (360//angle-2)*180,
     lambda angle: (180-angle)*(360//angle)),
):
    _geometry(ids, family, 'angle', solve, domains={'angle': _DIVISORS}, reference=ref)
_geometry('train/791', 'regular-polygon-integral-angles', '_ limit',
          lambda limit: sum(360 % n != 0 for n in range(3,limit)),
          domains={'limit': (4,80)},
          reference=lambda limit: sum(Fraction(180*(n-2),n).denominator != 1
                                      for n in range(3,limit)))
_geometry('train/298', 'isosceles-angle-difference', 'd',
          lambda d: Fraction(180+2*d,3), domains={'d': (1,179)})
_geometry('train/717', 'isosceles-angle-multiple', 'm',
          lambda m: Fraction(180*m,2*m+1), domains={'m': (2,24)}, adaptation='Use a numeral for the angle multiplier.')
_geometry('test/146', 'trapezoid-supplement', 'acute', lambda acute: 180-acute,
          domains={'acute': (1,89)})
_geometry('test/160', 'trapezoid-angle-ratio', 'm', lambda m: Fraction(180,m+1),
          domains={'m': (2,24)})
_geometry('test/336', 'trapezoid-angle-progression', 'acute', lambda acute: 180-acute,
          domains={'acute': (1,89)}, reference=lambda acute: acute+3*Fraction(180-2*acute,3))
_geometry('test/403', 'isosceles-possible-angles', 'angle',
          lambda angle: angle + (180-2*angle) + Fraction(180-angle,2),
          domains={'angle': [a for a in range(1,90) if a != 60]},
          constraint='The given angle is acute and the three candidate values are distinct.',
          reference=lambda angle: sum({
              a for a in [angle, 180-2*angle, Fraction(180-angle,2)]
              if 0 < a < 180
          }))
_geometry('train/762', 'prism-edge-face-count', 'e', lambda e: e//3+2,
          domains={'e': list(range(9,151,3))},
          reference=lambda e: 2-e//3*2+e)
_geometry('test/112', 'pyramid-edge-vertex-count', 'e', lambda e: e//2+1,
          domains={'e': list(range(6,101,2))})

_geometry('train/55 train/216', 'cube-area-to-volume', 'area',
          lambda area: isqrt(area//6)**3,
          domains={'area': [6*a*a for a in range(1,41)]},
          reference=lambda area: next(a**3 for a in range(1,41) if 6*a*a == area))
_geometry('test/287', 'scaled-cube-area-to-volume', 'area',
          lambda area: (2*isqrt(area//6))**3,
          domains={'area': [6*a*a for a in range(1,41)]},
          reference=lambda area: 8*next(a**3 for a in range(1,41) if 6*a*a == area))
_geometry('test/117', 'cube-edge-to-area', 'a', lambda a: 6*a*a)
_geometry('train/730', 'cube-total-edge-to-volume', 'edges', lambda edges: (edges//12)**3,
          domains={'edges': [12*a for a in range(1,41)]})
_geometry('train/193', 'identical-cubes-volume', 'a', lambda a: 3*a**3)
_geometry('test/179', 'cube-volume-difference', 'vol',
          lambda vol: 26*vol, domains={'vol': [a**3 for a in range(1,31)]})
_geometry('test/439', 'cube-cut-surface-area-ratio', 'a b',
          lambda a, b: Fraction(b,a), valid=lambda a,b: a > b and a % b == 0,
          constraint='The large cube edge is an integral multiple of the smaller edge.',
          sample=lambda rng: (lambda b,n: {'a': b*n,'b':b})(rng.randint(1,4),rng.randint(2,10)),
          reference=lambda a,b: Fraction(6*a*a,(a//b)**3*6*b*b))
def _rational_sqrt(value):
    return Fraction(isqrt(value.numerator), isqrt(value.denominator))


def _prism_face_sample(rng):
    x, y, z = rng.sample(range(1, 21), 3)
    return {'a': x*y, 'b': x*z, 'c': y*z}


for ids, fields in (
    ('train/33 train/264 train/498', 'a b c'),
    ('train/718', 'a _ _ b _ _ c _ _'),
):
    _geometry(ids, 'prism-face-areas-to-volume', fields,
              lambda a,b,c: isqrt(a*b*c),
              domains={k:(1,400) for k in 'abc'},
              valid=lambda a,b,c: len({a,b,c}) == 3 and _square(a*b*c),
              constraint='The three distinct face areas are necessarily adjacent, and their product is a perfect square.',
              sample=_prism_face_sample,
              reference=lambda a,b,c: a * _rational_sqrt(Fraction(b*c,a)))


def _prime_factors(n):
    factors = []
    for i in range(2, isqrt(n) + 1):
        while n % i == 0:
            factors.append(i)
            n //= i
    if n > 1:
        factors.append(n)
    return factors


_geometry('train/35', 'prime-prism-volume-to-surface', 'vol',
          lambda vol: 2*sum(Fraction(vol,f) for f in _prime_factors(vol)),
          domains={'vol': sorted({a*b*c for a,b,c in product([2,3,5,7,11,13,17,19], repeat=3)})},
          constraint='The volume is the product of three prime edge lengths.')
_geometry('train/772', 'equal-volume-cube', 'a b c',
          lambda a,b,c: 6*_cube_root(a*b*c)**2,
          valid=lambda a,b,c: _cube_root(a*b*c)**3 == a*b*c,
          constraint='The rectangular prism volume is a perfect cube.',
          sample=lambda rng: (lambda x,y: {'a':x*x,'b':y*y,'c':x*y})(
              rng.randint(1,3),rng.randint(1,3)))
_geometry('test/446', 'cube-volume-increment', 'a a a d',
          lambda a,d: _cube_root(a**3+d),
          domains={'a': (1,16), 'd':(1,4096)},
          valid=lambda a,d: _cube_root(a**3+d)**3 == a**3+d,
          constraint='The enlarged volume is a perfect cube.',
          adaptation='Use consistent formatting for the three equal side lengths.',
          sample=lambda rng: (lambda a,b: {'a':a,'d':b**3-a**3})(
              *sorted(rng.sample(range(1,17),2))))

_geometry('train/223', 'cylinder-volume-scaling', 'vol', lambda vol: 12*vol)
_geometry('train/113', 'cylinder-area-to-height', '_ _ _ r area',
          lambda r,area: Fraction(area,2*r)-r, domains={'area':(1,1600),'r':(1,16)},
          valid=lambda r,area: area > 2*r*r,
          constraint='The total area exceeds the area of the two circular bases.',
          sample=lambda rng: (lambda r,h: {'r':r,'area':2*r*(r+h)})(
              rng.randint(1,16),rng.randint(1,24)))
_geometry('test/45', 'cylinder-volume-to-height', 'r vol', lambda r,vol: Fraction(vol,r*r),
          domains={'vol':(1,10000)})
_geometry('test/263', 'cylinder-area-volume-to-radius', 'area vol',
          lambda area,vol: Fraction(2*vol,area))
_geometry('test/114', 'equal-cylinder-volumes', 'r1 h1 r2',
          lambda r1,h1,r2: Fraction(r1*r1*h1,r2*r2))
_geometry('test/124', 'same-height-cylinder-capacity', 'h small large',
          lambda h,small,large: Fraction(large,small)**2,
          valid=lambda h,small,large: large > small and large % small == 0,
          constraint='The diameter ratio is an integer greater than one.',
          sample=lambda rng: (lambda h,d,n: {'h':h,'small':d,'large':d*n})(
              rng.randint(1,10),rng.randint(1,4),rng.randint(2,10)))
_geometry('test/354', 'transfer-cylinder-capacity', 'n small large',
          lambda n,small,large: ceil(Fraction(n*small*small,large*large)),
          valid=lambda n,small,large: large > small,
          constraint='The new containers have larger radius.')
_geometry('train/106', 'hemisphere-cylinder-fill', 'r h b',
          lambda r,h,b: ceil(Fraction(3*r*r*h,2*b**3)))
_geometry('test/300', 'hemisphere-cylinder-height', 'b r',
          lambda b,r: _round(Fraction(2*b**3,3*r*r),1))
_geometry('test/350', 'sphere-cylinder-fill', 'h r b',
          lambda h,r,b: Fraction(4*b**3,3*r*r*h),
          domains={'h': (1,80), 'r': (1,40), 'b': (1,40)},
          valid=lambda h,r,b: (4*b**3) % (3*r*r*h) == 0,
          constraint='The spherical tank holds a whole number of full beakers.',
          sample=lambda rng: (lambda r,n: {'h':12*r,'r':r,'b':3*r*n})(
              rng.randint(1,3),rng.randint(1,4)))
_geometry('test/329', 'sphere-cone-fill', 'r b h',
          lambda r,b,h: ceil(Fraction(b*b*h,4*r**3)))
_geometry('test/315', 'cone-volume-to-height', 'vol', lambda vol: Fraction(vol,3))
_geometry('train/333', 'cube-pyramid-equal-volume', 'a b',
          lambda a,b: Fraction(3*a**3,b*b))
_geometry('test/416', 'square-pyramid-volume', 'a h',
          lambda a,h: Fraction(a*a*h,3))
_geometry('test/116', 'square-pyramid-volume-from-perimeter', 'a',
          lambda a: Fraction(8*a**3,3))
_geometry('test/184', 'triangular-pyramid-volume', 'a b c h',
          lambda a,b,c,h: _triangle_area(a,b,c)*Fraction(h,3),
          valid=lambda a,b,c,h: _heron_valid(a,b,c),
          constraint='The base is a nondegenerate triangle with rational area.',
          sample=lambda rng: dict(_triple_sample(rng),h=rng.randint(1,40)),
          reference=lambda a,b,c,h: _triangle_area(c,a,b)*Fraction(h,3))
_geometry('train/856', 'scale-container-capacity', 'vol', lambda vol: 8*vol)
_geometry('train/395', 'cylinder-diameter-diagonal', 'r h',
          lambda r,h: isqrt(4*r*r+h*h), valid=lambda r,h: _square(4*r*r+h*h),
          constraint='The axial rectangle has an integer diagonal.',
          sample=lambda rng: (lambda t: {'r':t[0]//2,'h':t[1]})(
              rng.choice([(a,b,c) for a,b,c in _TRIPLES if a%2==0 and c<=40])))
_geometry('train/869', 'circle-area-circumference', 'total',
          lambda total: isqrt(total+1)-1,
          domains={'total': [r*r+2*r for r in range(1,41)]},
          reference=lambda total: next(r for r in range(1,41) if r*(r+2)==total))
_geometry('test/228', 'arc-length-radius', 'angle arc',
          lambda angle,arc: Fraction(180*arc,angle),
          domains={'angle': (1,180), 'arc': (1,40)})
_geometry('test/192', 'sphere-surface-ratio', 'a b',
          lambda a,b: Fraction(a*a,2*b*b))

_geometry('train/44', 'equilateral-triangle-cut-ratio', 'large small',
          lambda large,small: Fraction(small*small,large*large-small*small),
          valid=lambda large,small: large > small,
          constraint='The removed triangle is smaller than the original triangle.')
_geometry('train/186', 'similar-isosceles-perimeter', 'a a b c',
          lambda a,b,c: Fraction((2*a+b)*c,b),
          valid=lambda a,b,c: a < b < 2*a and c > b,
          constraint='The original isosceles triangle is nondegenerate, with its base longest, and the other triangle is larger.')
_geometry('train/242', 'similar-triangle-longest-side', 'a b c p',
          lambda a,b,c,p: Fraction(max(a,b,c)*p,a+b+c),
          domains={'p': (1,160)},
          valid=lambda a,b,c,p: _triangle(a,b,c),
          constraint='The three given sides form a nondegenerate triangle.')
_geometry('train/190', 'similar-right-triangle-leg', 'a b c',
          lambda a,b,c: _round(Fraction(a*c,b),2))
_geometry('test/150', 'similar-right-triangle-short-leg', 'a b h',
          lambda a,b,h: Fraction(min(a,b)*h,isqrt(a*a+b*b)),
          domains={'h': (1,160)},
          valid=lambda a,b,h: _square(a*a+b*b),
          constraint='The first right triangle has integer hypotenuse.',
          sample=lambda rng: (lambda t: {'a':t[0],'b':t[1],'h':rng.randint(1,160)})(
              rng.choice([t for t in _TRIPLES if t[-1]<=40])))
_geometry('test/379', 'similar-side-correspondence', 'a b c',
          lambda a,b,c: Fraction(a*c,b))
_geometry('test/398', 'similar-side-correspondence', 'a b c',
          lambda a,b,c: Fraction(b*c,a))
_geometry('train/648', 'similar-shadow-height', 'a b c',
          lambda a,b,c: _round(Fraction(a*b,c)), domains={'a':(1,120)})
_geometry('train/754', 'scaled-triangle-area', 'area', lambda area: Fraction(area,9))
_geometry('train/119', 'triangle-area-ratio', 'a b c d e f',
          lambda a,b,c,d,e,f: _triangle_area(a,b,c)/_triangle_area(d,e,f),
          valid=lambda a,b,c,d,e,f: _heron_valid(a,b,c) and _heron_valid(d,e,f),
          constraint='Both triangles are nondegenerate and have rational areas.',
          sample=lambda rng: dict(_triple_sample(rng), **_triple_sample(rng,('d','e','f'))),
          reference=lambda a,b,c,d,e,f: Fraction(
              isqrt(_area4_squared(a,b,c)),isqrt(_area4_squared(d,e,f))))

_geometry('train/386 test/395 test/386', 'heron-area', 'a b c', _triangle_area,
          domains={k:(1,80) for k in 'abc'}, valid=_heron_valid,
          constraint='The triangle inequality holds and the Heron radicand is a perfect square.',
          sample=lambda rng: _triple_sample(rng,maximum=80) if rng.randrange(2) else (
              lambda t: {'a':t[2],'b':t[2],'c':2*t[0]}
          )(rng.choice([t for t in _TRIPLES if t[0]<=40 and t[-1]<=80])),
          reference=lambda a,b,c: Fraction(
              isqrt(4*a*a*b*b-(a*a+b*b-c*c)**2),4))
for ids, family, compute, reference in (
    ('test/78', 'right-triangle-hypotenuse-median', lambda a,b: Fraction(isqrt(a*a+b*b),2),
     lambda a,b: Fraction(isqrt(a*a+b*b),2)),
):
    _geometry(ids, family, 'a b', compute,
              valid=lambda a,b: _square(a*a+b*b),
              constraint='The hypotenuse is an integer.',
              sample=lambda rng: (lambda t: {'a':t[0],'b':t[1]})(
                  rng.choice([t for t in _TRIPLES if t[-1]<=40])))
for ids, fields, rounded in (
    ('test/317', 'a b c', True),
    ('test/358', 'a b c', False),
    ('test/367', 'a b c', False),
):
    _geometry(ids, 'triangle-circumradius', fields,
              (lambda a,b,c: _round(Fraction(a*b*c,isqrt(_area4_squared(a,b,c))),1))
              if rounded else (lambda a,b,c: Fraction(a*b*c,isqrt(_area4_squared(a,b,c)))),
              valid=_heron_valid,
              constraint='The triangle is nondegenerate and has rational area.',
              sample=_triple_sample,
              reference=lambda a,b,c: (_round(Fraction(c,2),1) if rounded else Fraction(c,2)) if _right(a,b,c) else
              (_round(Fraction(a*b*c,4*_triangle_area(a,b,c)),1) if rounded else
               Fraction(a*b*c,4*_triangle_area(a,b,c))))

_geometry('test/225', 'isosceles-trapezoid-area', 'a b leg',
          lambda a,b,leg: Fraction((a+b)*isqrt(4*leg*leg-(a-b)**2),4),
          valid=lambda a,b,leg: a != b and abs(a-b) < 2*leg and _square(4*leg*leg-(a-b)**2),
          constraint='Bases differ, and the altitude is positive and rational.',
          sample=lambda rng: (lambda a,t: {'a':a,'b':a+2*t[0],'leg':t[2]})(
              rng.randint(1,10),rng.choice([t for t in _TRIPLES if t[-1]<=25 and t[0]<=15])))
_geometry('test/234', 'isosceles-trapezoid-area', 'a leg b leg',
          lambda a,b,leg: Fraction((a+b)*isqrt(4*leg*leg-(a-b)**2),4),
          valid=lambda a,b,leg: a < b and b-a < 2*leg and _square(4*leg*leg-(a-b)**2),
          constraint='The first base is smaller, and the altitude is positive and rational.',
          sample=lambda rng: (lambda a,t: {'a':a,'b':a+2*t[0],'leg':t[2]})(
              rng.randint(1,10),rng.choice([t for t in _TRIPLES if t[-1]<=25 and t[0]<=15])))
_geometry('train/734', 'square-pyramid-total-area', 'a h',
          lambda a,h: a*a+a*isqrt(a*a+4*h*h),
          valid=lambda a,h: _square(a*a+4*h*h),
          constraint='Twice the slant height is an integer.',
          sample=lambda rng: (lambda t: {'a':2*t[0],'h':t[1]})(
              rng.choice([t for t in _TRIPLES if t[-1]<=40 and t[0]<=20])))
_geometry('train/121', 'right-triangle-complementary-sines', 'a c _',
          lambda a,c: Fraction(isqrt(c*c-a*a),c),
          valid=lambda a,c: 0 < a < c and _square(c*c-a*a),
          constraint='The sine is the leg-to-hypotenuse ratio of an integer right triangle.',
          sample=lambda rng: (lambda t: {'a':t[0],'c':t[2]})(
              rng.choice([t for t in _TRIPLES if t[-1]<=40])))
_geometry('train/377', 'right-triangle-adjacent-from-tangent', '_ a b h',
          lambda a,b,h: Fraction(b*h,isqrt(a*a+b*b)), valid=lambda a,b,h: _square(a*a+b*b),
          constraint='The tangent numerator and denominator are integer right-triangle legs.',
          adaptation='Use braced numerator and denominator in LaTeX.',
          sample=lambda rng: (lambda t: {'a':t[0],'b':t[1],'h':rng.randint(1,40)})(
              rng.choice([t for t in _TRIPLES if t[-1]<=40])))
_geometry('train/379', 'right-triangle-tangent-sine-equation', '_ h k',
          lambda h,k: Fraction(h,k), domains={'k': (2,30)})
_geometry('train/644', 'right-triangle-tangent-from-radical', '_ a c2',
          lambda a,c2: Fraction(a,isqrt(c2-a*a)),
          domains={'c2': (2,1600)},
          valid=lambda a,c2: c2 > a*a and _square(c2-a*a),
          constraint='The unknown leg is a positive integer.',
          sample=lambda rng: (lambda a,b: {'a':a,'c2':a*a+b*b})(
              rng.randint(1,28),rng.randint(1,28)))
_geometry('train/723', 'right-triangle-tangent-from-leg-hypotenuse', '_ b c',
          lambda b,c: Fraction(isqrt(c*c-b*b),b),
          valid=lambda b,c: 0 < b < c and _square(c*c-b*b),
          constraint='The second leg is a positive integer.',
          sample=lambda rng: (lambda t: {'b':t[1],'c':t[2]})(
              rng.choice([t for t in _TRIPLES if t[-1]<=40])))
_geometry('test/307', 'right-triangle-opposite-from-tangent', '_ b m n',
          lambda b,m,n: Fraction(b*m,n))
_geometry('test/178', 'right-triangle-tangent-from-cosine', '_ a c h',
          lambda a,c,h: Fraction(a,isqrt(c*c-a*a)),
          valid=lambda a,c,h: 0 < a < c and _square(c*c-a*a),
          constraint='The cosine is a leg-to-hypotenuse ratio of an integer right triangle.',
          sample=lambda rng: (lambda t: {'a':t[0],'c':t[2],'h':rng.randint(1,40)})(
              rng.choice([t for t in _TRIPLES if t[-1]<=40])))
_geometry('test/106', 'right-triangle-tangent-from-ratio', '_ k', lambda k: k)
_geometry('train/124', 'intersecting-chord-segment-ratio', 'a c',
          lambda a,c: Fraction(c,a), reference=lambda a,c: Fraction(1,a)/Fraction(1,c))
_geometry('train/145', 'triangle-line-intersection-area', 'h', lambda h: h*h)
_geometry('test/353', 'triangle-intercept-area', 'a', lambda a: Fraction(a*a,2))
_geometry('train/161', 'rectangle-width-from-area', '_ _ _ h h _ area _',
          lambda h,area: Fraction(area,h))
_geometry('train/197', 'rectangle-height-from-area', 'x1 x2 x1 b x2 b area',
          lambda x1,x2,b,area: b+Fraction(area,x2-x1),
          domains={'x1':(-20,0), 'x2':(1,20), 'b':(1,15), 'area':(1,200)},
          valid=lambda x1,x2,b,area: area >= b*(x2-x1),
          constraint='The other candidate ordinate is nonpositive, so the positive solution is unique.')
_geometry('train/378', 'triangle-coordinate-scale', '_ _ _ _ _ area',
          lambda area: isqrt(area), domains={'area':[n*n for n in range(1,41)]})
_geometry('test/216', 'triangle-coordinate-scale', '_ _ _ _ h area',
          lambda h,area: Fraction(2*area,h))
_geometry('train/345', 'fixed-perimeter-rectangle-area-spread', 'p',
          lambda p: (p//4)*(p//2-p//4)-(p//2-1),
          domains={'p':list(range(8,202,2))},
          reference=lambda p: max(a*(p//2-a) for a in range(1,p//2))-(p//2-1))
_geometry('train/797', 'midpoint-trisection-distance', 'distance',
          lambda distance: distance*6)
_geometry('test/429', 'rhombus-area-to-diagonal', 'a _ neg_a _ area _ _',
          lambda a,neg_a,area: Fraction(area,a-neg_a),
          domains={'neg_a':(-40,-1), 'area':(1,160)},
          valid=lambda a,neg_a,area: a == -neg_a,
          constraint='The horizontal diagonal is centered at the origin.',
          sample=lambda rng: (lambda a: {'a':a,'neg_a':-a,'area':rng.randint(1,160)})(
              rng.randint(1,40)))


_COORDINATES = 'x1 y1 x2 y2 x3 y3'
_SIGNED = (-40,40)
for register, ids, places in (
    (_geometry, 'train/150 train/818 test/277', None),
    (_geometry, 'train/368 train/705', 1),
    (_precalculus, 'train/35 train/487', None),
):
    def area(x1,y1,x2,y2,x3,y3, *, places=places):
        value = Fraction(abs(_triangle_coordinates(x1,y1,x2,y2,x3,y3)),2)
        return _round(value,places) if places is not None else value

    register(ids, 'coordinate-triangle-area', _COORDINATES, area,
             domains=dict.fromkeys(_COORDINATES.split(),_SIGNED),
             valid=lambda **p: _triangle_coordinates(**p) != 0,
             constraint='The vertices are noncollinear.',
             reference=lambda x1,y1,x2,y2,x3,y3: _shoelace((x1,y1),(x2,y2),(x3,y3)))


def _convex_hull(points):
    ordered = sorted(set(points))

    def chain(vertices):
        result = []
        for point in vertices:
            while len(result)>1 and _triangle_coordinates(*result[-2],*result[-1],*point) <= 0:
                result.pop()
            result.append(point)
        return result

    return chain(ordered)[:-1] + chain(reversed(ordered))[:-1]


def _quad(x1,y1,x2,y2,x3,y3,x4,y4):
    return [(x1,y1),(x2,y2),(x3,y3),(x4,y4)]


def _parallel(x1,y1,x2,y2,x3,y3,x4,y4):
    return (x1 == x2 and x3 == x4 and x1 != x3
            and (y2-y1)*(y4-y3) < 0 and abs(y2-y1) != abs(y4-y3))


def _quad_parallel_sample(rng):
    x1,x3 = rng.sample(range(-20,21),2)
    y1 = rng.randint(-20,10)
    y4 = rng.randint(-20,10)
    first,second = rng.sample(range(1,20),2)
    y2,y3 = y1+first,y4+second
    return dict(x1=x1,y1=y1,x2=x1,y2=y2,x3=x3,y3=y3,x4=x3,y4=y4)


_QUAD_FIELDS = _COORDINATES + ' x4 y4'
_geometry('train/228 train/706 test/363', 'coordinate-trapezoid-area', _QUAD_FIELDS,
          lambda **p: _shoelace(*_convex_hull(_quad(**p))),
          domains=dict.fromkeys(_QUAD_FIELDS.split(),_SIGNED),
          valid=_parallel, sample=_quad_parallel_sample,
          constraint='The two vertical sides have different positive lengths, lie on distinct lines and are traversed in opposite directions.',
          reference=lambda x1,y1,x2,y2,x3,y3,x4,y4: Fraction(
              abs(x1-x3)*(abs(y1-y2)+abs(y3-y4)),2))
_geometry('test/198 test/148', 'coordinate-convex-quadrilateral-area', _QUAD_FIELDS,
          lambda **p: _shoelace(*_quad(**p)),
          domains=dict.fromkeys(_QUAD_FIELDS.split(),_SIGNED),
          valid=lambda **p: _is_convex_ordered(_quad(**p)),
          constraint='The vertices in the stated order trace a strictly convex quadrilateral.',
          reference=lambda **p: _quad_area_by_triangulation(_quad(**p)))


def _is_convex_ordered(points):
    cross = [_triangle_coordinates(*points[i-2],*points[i-1],*p) for i,p in enumerate(points)]
    return min(cross) > 0 or max(cross) < 0


def _quad_area_by_triangulation(points):
    a,b,c,d = points
    return Fraction(abs(_triangle_coordinates(*a,*b,*c))+abs(_triangle_coordinates(*a,*c,*d)),2)


def _parallelogram_valid(x1,y1,x2,y2,x3,y3):
    return _triangle_coordinates(x1,y1,x2,y2,x3,y3) != 0


_geometry('test/147', 'parallelogram-fourth-vertex', _COORDINATES,
          lambda x1,y1,x2,y2,x3,y3: x1+y1+x3+y3-x2-y2,
          domains=dict.fromkeys(_COORDINATES.split(),_SIGNED), valid=_parallelogram_valid,
          constraint='The given three vertices are noncollinear.')
_geometry('test/23', 'reflected-midpoint-coordinate-sum', 'a b c d',
          lambda a,b,c,d: Fraction(a+c-b-d,2),
          domains=dict.fromkeys('abcd',_SIGNED),
          valid=lambda a,b,c,d: (a,b)!=(c,d),
          constraint='The endpoints of the reflected segment are distinct.')
_geometry('train/344', 'point-reflection-coordinate-sum', 'y', lambda y: 2*y,
          domains={'y':_SIGNED})
for ids, selected in [('train/32','x1'),('train/683','x3')]:
    _geometry(ids, 'reflection-distance', _COORDINATES,
              lambda selected=selected,**p: 2*abs(p[selected]),
              domains=dict.fromkeys(_COORDINATES.split(),_SIGNED), valid=_parallelogram_valid,
              constraint='The given three vertices are noncollinear.')

_geometry('train/692', 'bounded-coordinate-trapezoid-area', 'hi lo',
          lambda hi,lo: _round(Fraction(hi*hi-lo*lo,2),1),
          valid=lambda hi,lo: hi > lo,
          constraint='The two horizontal lines have distinct positive heights in the stated order.',
          reference=lambda hi,lo: Fraction((hi+lo)*(hi-lo),2))
_geometry('test/250', 'rectangle-corner-cut-area-ratio', '_ _ w _ w h _ h x h',
          lambda w,h,x: Fraction(x,2*w-x),
          valid=lambda w,h,x: 0 < x < w, constraint='E is in the relative interior of CD.',
          reference=lambda w,h,x: Fraction(x*h,2)/(w*h-Fraction(x*h,2)))


def _det2(a,b,c,d):
    return a*d-b*c


def _det3(a,b,c,d,e,f,g,h,i):
    return a*(e*i-f*h)-b*(d*i-f*g)+c*(d*h-e*g)


def _leibniz(*entries):
    order = isqrt(len(entries))
    total = 0
    for columns in permutations(range(order)):
        inversions = sum(a>b for i,a in enumerate(columns) for b in columns[i+1:])
        term = -1 if inversions%2 else 1
        for row,column in enumerate(columns):
            term *= entries[row*order+column]
        total += term
    return total


_precalculus('train/181 train/602 test/350', 'two-by-two-determinant', 'a b c d',
             _det2, domains=dict.fromkeys('abcd',_SIGNED), reference=lambda a,b,c,d: _leibniz(a,b,c,d))
_precalculus('train/288 train/607', 'three-by-three-determinant', 'a b c d e f g h i',
             _det3, domains=dict.fromkeys('abcdefghi',_SIGNED), reference=lambda a,b,c,d,e,f,g,h,i: _leibniz(a,b,c,d,e,f,g,h,i))
_precalculus('train/344 test/173 test/286', 'determinant-product', 'a b',
             lambda a,b: a*b, domains=dict.fromkeys('ab',_SIGNED))
_precalculus('train/489 train/730', 'determinant-power', 'a n',
             lambda a,n: a**n, domains={'a':_SIGNED,'n':(1,12)})
_precalculus('test/310 test/421', 'determinant-scaled-two-by-two', '_ _ a n',
             lambda a,n: a*n*n, domains={'a':_SIGNED,'n':_SIGNED})
_precalculus('test/84', 'determinant-scaled-product', '_ _ a b n',
             lambda a,b,n: a*b*n*n, domains=dict.fromkeys('abn',_SIGNED))
_precalculus('train/371', 'determinant-scaled-two-by-two', 'd n n n n',
             lambda d,n: d*n*n, domains={'d':_SIGNED})
_precalculus('train/407', 'determinant-row-operations', 'd',
             lambda d: d, domains={'d':_SIGNED})
# Interchanging columns changes the sign, while a row addition does not.
_precalculus('test/34', 'determinant-column-swap', 'd',
             lambda d: -d, domains={'d':_SIGNED})
_precalculus('train/520', 'determinant-column-combination', 'd a b a b',
             lambda d,a,b: d*b, domains={'d':_SIGNED,'a':(1,20),'b':(1,20)})
_precalculus('train/128 train/300', 'linear-transformation-area', 'area a b c d',
             lambda area,a,b,c,d: area*abs(_det2(a,b,c,d)),
             domains=dict.fromkeys('abcd',_SIGNED),
             valid=lambda area,a,b,c,d: _det2(a,b,c,d)!=0,
             constraint='The planar transformation matrix is invertible.',
             reference=lambda area,a,b,c,d: area*abs(_leibniz(a,b,c,d)))
_precalculus('train/91', 'dilation-determinant', '_ _ k', lambda k:k*k)
_precalculus('train/332', 'singular-two-by-two-matrix', 'a b c d',
             lambda a,b,c,d: Fraction(b*c-a*d,b+d),
             reference=lambda a,b,c,d: -Fraction(_det2(a,b,c,d),_det2(1,b,-1,d)))
_precalculus('train/473', 'symmetric-determinant-zero-sum', 'a b c d d _',
             lambda a,b,c,d: Fraction(d*(b+c),a))
_precalculus('train/572', 'self-inverse-matrix-count', 'a b',
             lambda a,b: 2 if a*b < 1 else int(a*b == 1),
             domains={'a':(1,40),'b':(-40,40)},
             valid=lambda a,b: b != 0 and a*b <= 1,
             sample=lambda rng: {'a':1,'b':1} if rng.randrange(5)==0 else
             {'a':rng.randint(1,40),'b':rng.randint(-40,-1)},
             constraint='Both fixed off-diagonal entries are nonzero and at least one real pair exists.')
_precalculus('train/609', 'determinant-matrix-polynomial', 'a b c d _ k',
             lambda a,b,c,d,k: _det2(a,b,c,d)*_det2(a-k,b,c,d-k),
             domains=dict.fromkeys('abcd',_SIGNED),
             reference=lambda a,b,c,d,k: _det2(a*a+b*c-k*a,b*(a+d-k),c*(a+d-k),b*c+d*d-k*d))

for ids, fields, solve in (
    ('train/255 test/136','a b c d e f',lambda a,b,c,d,e,f:a*d+b*e+c*f),
    ('train/646 test/425','a b c d',lambda a,b,c,d:a*c+b*d),
):
    _precalculus(ids, 'dot-product', fields, solve,
                 domains=dict.fromkeys(fields.split(),_SIGNED),
                 reference=lambda fields=fields,**p: sum(p[a]*p[b] for a,b in zip(
                     fields.split()[:len(p)//2],fields.split()[len(p)//2:])))

_precalculus('train/223', 'orthogonal-vector-component', 'a b c d e',
             lambda a,b,c,d,e: -Fraction(a*d+c*e,b),
             domains=dict.fromkeys('abcde',_SIGNED), valid=lambda a,b,c,d,e: b!=0,
             constraint='The coefficient of the unknown is nonzero.')
_precalculus('train/518', 'orthogonal-vector-component', 'a b c',
             lambda a,b,c: -Fraction(b*c,a),
             domains=dict.fromkeys('abc',_SIGNED), valid=lambda a,b,c: a!=0,
             constraint='The coefficient of the unknown is nonzero.')
_precalculus('train/724', 'orthogonal-direction-component', 'a b c',
             lambda a,b,c: -Fraction(b*c,a),
             domains=dict.fromkeys('abc',_SIGNED), valid=lambda a,b,c: a*c!=0,
             constraint='Both direction vectors are nonzero, and the coefficient of the unknown is nonzero.')
_precalculus('train/396', 'dependent-vector-component', 'a b c',
             lambda a,b,c: Fraction(b*c,a),
             domains=dict.fromkeys('abc',_SIGNED), valid=lambda a,b,c: a!=0 and a!=c,
             constraint='The coefficient of the unknown is nonzero and the vectors are distinct.')
_precalculus('train/260', 'dot-product-norm-difference', 'a b', lambda a,b:a*a-b*b)
_precalculus('train/558', 'dot-product-self', 'a', lambda a:a*a)
_precalculus('train/562', 'scaled-vector-norm', 'a k', lambda a,k:abs(k)*a,
             domains={'k':(-40,40)})
_precalculus('train/578', 'dot-product-linearity', 'ab ac bc m n',
             lambda ab,ac,bc,m,n: m*bc-n*ab,
             domains={'ab':_SIGNED,'ac':_SIGNED,'bc':_SIGNED})
_precalculus('test/330', 'cross-product-linearity', 'a b d',
             lambda a,b,d: a*d+b)
_precalculus('test/368', 'scalar-triple-product-norm', 'a', lambda a:a*a)
_precalculus('test/540', 'vector-dot-product-minimum', 'a b', lambda a,b:-a*b)
_precalculus('test/275 test/293', 'norm-difference-minimum', 'a b', lambda a,b:abs(a-b))
_precalculus('test/533', 'vector-projection-maximum', 'a b', lambda a,b:a)
_precalculus('train/664', 'vector-projection-magnitude', 'dot b',
             lambda dot,b: abs(Fraction(dot,b)), domains={'dot':_SIGNED})
_precalculus('train/176', 'vector-projection-magnitude', 'a b dot',
             lambda a,b,dot: abs(Fraction(dot,b)),
             domains={'dot':(-200,200)}, valid=lambda a,b,dot: abs(dot)<=a*b,
             constraint='The dot product satisfies the Cauchy–Schwarz bound.')
_precalculus('train/377', 'angle-from-vector-norms', 'a b c',
             lambda a,b,c: Fraction(c*c-a*a-b*b,2*a*b),
             valid=lambda a,b,c: abs(a-b)<=c<=a+b,
             constraint='The norm of the sum lies between the norm difference and sum.')
_precalculus('train/47', 'dot-product-from-cross-product', 'a b c',
             lambda a,b,c: isqrt((a*b)**2-c*c),
             domains={'c':(1,1600)},
             valid=lambda a,b,c: _square((a*b)**2-c*c),
             constraint='The cross product is at most the product of norms and leaves an integral dot product magnitude.',
             sample=lambda rng: (lambda t: {'a':1,'b':t[2],'c':t[0]})(
                 rng.choice([t for t in _TRIPLES if t[-1]<=40])))
_precalculus('train/293 train/415', 'vector-triangle-area', 'a b c d _',
             lambda a,b,c,d: Fraction(abs(_det2(a,b,c,d)),2),
             domains=dict.fromkeys('abcd',_SIGNED),
             valid=lambda a,b,c,d: _det2(a,b,c,d)!=0, constraint='The two vectors are nonparallel.',
             reference=lambda a,b,c,d: _shoelace((0,0),(a,b),(c,d)))
_precalculus('train/320 test/160', 'vector-parallelogram-area', 'a b c d _',
             lambda a,b,c,d: abs(_det2(a,b,c,d)), domains=dict.fromkeys('abcd',_SIGNED),
             valid=lambda a,b,c,d: _det2(a,b,c,d)!=0, constraint='The two vectors are nonparallel.',
             reference=lambda a,b,c,d: _shoelace((0,0),(a,b),(a+c,b+d),(c,d)))

def _principal_degree(function, n):
    if function == 'tan':
        return (n+90)%180-90
    if function == 'sin':
        return 90-abs((n+90)%360-180)
    return abs((n+180)%360-180)


for ids,function,fields in (
    ('train/75','sin','_ _ n'),
    ('train/256 train/410 test/214','tan','_ _ n'),
    ('train/322 train/447 test/247','cos','_ _ n'),
    ('train/668 test/248 test/329','sin','_ _ n'),
):
    cosine_rhs = ids == 'train/75'
    _precalculus(
        ids, 'principal-angle', fields,
        lambda n,function=function,cosine_rhs=cosine_rhs: _principal_degree(
            function,90-n if cosine_rhs else n),
        domains={'n':(-1500,1500)},
        valid=(lambda n: n%180!=90) if function=='tan' else None,
        constraint='The given tangent is defined.' if function=='tan' else '',
    )


def _chebyshev(n,value):
    first, second = 1, value
    for _ in range(n):
        first, second = second, 2*value*second-first
    return first


for ids,fields in (
    ('train/45','n a b'),
    ('train/440 train/703 train/587','a b n'),
):
    _precalculus(ids,'cosine-multiple-angle',fields,
                 lambda a,b,n: _chebyshev(n,Fraction(a,b)),
                 domains={'n':(1,10),'a':(-40,40)},
                 valid=lambda a,b,n: abs(a)<=b,
                 constraint='The supplied cosine lies in the interval [-1, 1].')

_precalculus('train/44', 'sine-double-from-sum', 'a b _',
             lambda a,b: (Fraction(a,b)**2-1),
             domains={'a':(-40,40)},
             valid=lambda a,b: a*a <= 2*b*b,
             constraint='The squared sum of sine and cosine is at most 2.')
_precalculus('train/395', 'sixth-power-sine-cosine-sum', '_ a b _ _',
             lambda a,b: 1-Fraction(3*a*a,4*b*b), domains={'a':(-40,40)},
             valid=lambda a,b: abs(a)<=b, constraint='The sine of twice the angle lies in [-1, 1].')
_precalculus('test/482', 'cube-sine-cosine-sum', 'a b _ _',
             lambda a,b: Fraction(a,b)*(3-Fraction(a,b)**2)/2,
             domains={'a':(-40,40)}, valid=lambda a,b: a*a<=2*b*b,
             constraint='The squared sum of sine and cosine is at most 2.')
_precalculus('test/528', 'sine-reciprocal-sum-from-cosine', 'a b _ _ _ _',
             lambda a,b: Fraction(2*b*b,a*a),
             valid=lambda a,b: a<=b, constraint='The cosine is nonzero and at most 1.')
_precalculus('train/49', 'sine-from-secant-tangent-sum', 'a b',
             lambda a,b: Fraction(a*a-b*b,a*a+b*b))
_precalculus('train/245', 'reciprocal-secant-tangent-combination', 'a b',
             lambda a,b: Fraction(b,a))
_precalculus('test/88', 'reciprocal-secant-tangent-combination', 'a',
             lambda a: Fraction(1,a))
_precalculus('train/121', 'tangent-angle-difference', 'a b',
             lambda a,b: Fraction(a-b,1+a*b))
_precalculus('train/326', 'tangent-quarter-period-addition', 'a _',
             lambda a: Fraction(a+1,1-a), domains={'a':(2,40)})
_precalculus('train/205', 'tangent-triple-angle', 'a _',
             lambda a: Fraction(3*a-a**3,1-3*a*a))
_precalculus('test/341', 'tangent-double-angle', 'a _',
             lambda a: Fraction(2*a,1-a*a), domains={'a':(2,40)})
_precalculus('train/433', 'sine-cosine-product-from-ratio', 'a',
             lambda a: Fraction(a,1+a*a))
_precalculus('train/654 test/244', 'tangent-sum-from-tangent-cotangent-sums', 'a b',
             lambda a,b: Fraction(a*b,b-a), valid=lambda a,b: a!=b and a*b>=4,
             constraint='The tangent sum is defined, and the underlying quadratic has real nonzero roots.')
_precalculus('train/589', 'tangent-of-inverse-cotangent', 'a b',
             lambda a,b: Fraction(b,a))
_precalculus('test/372', 'double-angle-from-sine-shift', '_ a b _',
             lambda a,b: Fraction(2*a*a,b*b)-1, valid=lambda a,b: a<=b,
             constraint='The given sine lies between zero and one.')
_precalculus('test/427', 'cosine-product-sum-and-difference', 'a b c d',
             lambda a,b,c,d: Fraction(a*a,b*b)+Fraction(c*c,d*d)-1,
             valid=lambda a,b,c,d: a<=b and c<=d,
             constraint='Both supplied cosines lie between zero and one.')
_precalculus('test/53', 'sine-cosine-difference-from-double-angle', '_ a b _',
             lambda a,b: Fraction(isqrt((b-a)*b),b),
             valid=lambda a,b: a<b and _square((b-a)*b),
             constraint='The difference is positive with rational magnitude.',
             sample=lambda rng: (lambda d,n: {'a':d*d-n*n,'b':d*d})(
                 rng.randint(2,6),1))
_precalculus('train/97', 'angle-difference-from-vector-sum', 'a b c',
             lambda a,b,c: (a*a+Fraction(b*b,c*c)-1-1)/2,
             domains={'a':(-2,2)}, valid=lambda a,b,c: a*a+Fraction(b*b,c*c)<=4,
             constraint='The vector sum has length at most 2.')
_precalculus('test/86', 'tangent-double-arctangent-offset', '_ a b _',
             lambda a,b: Fraction(2*a*b-b*b+a*a,b*b-a*a+2*a*b),
             valid=lambda a,b: b*b-a*a+2*a*b!=0,
             constraint='The resulting tangent is defined.')
_precalculus('train/209', 'cotangent-difference-identity', 'a a',
             lambda a: 1-Fraction(1,a), domains={'a':(2,40)})
_precalculus('test/89', 'triple-angle-ratio-transfer', '_ a b _',
             lambda a,b: Fraction(a,b)+2, valid=lambda a,b: a<b,
             constraint='The given positive quotient is less than 1 and both trig quotients are defined.')
_precalculus('train/289', 'complex-angle-power-count', 'limit',
             lambda limit: (limit+3)//4, domains={'limit':(1,2000)},
             reference=lambda limit: sum(n%4==1 for n in range(1,limit+1)))
_precalculus('train/725', 'rotation-order', 'angle angle angle angle',
             lambda angle: 360//gcd(360,angle), domains={'angle':(1,359)},
             reference=lambda angle: next(n for n in range(1,361) if (angle*n)%360==0))
_precalculus('test/274', 'first-real-complex-power', 'angle angle',
             lambda angle: 180//gcd(180,angle), domains={'angle':(1,359)},
             reference=lambda angle: next(n for n in range(1,181) if (angle*n)%180==0))
_precalculus('train/541', 'centroid-squared-distance-sum', '_ _ _ total _ _ _',
             lambda total: 3*total, domains={'total':(1,160)})
_precalculus('train/239', 'plane-intercept-centroid-norm', 'd _ _ _ _ _ _',
             lambda d: Fraction(9,d*d))
_precalculus('train/529', 'line-interpolation-coordinate', 'a b c d e f x',
             lambda a,b,c,d,e,f,x: c+Fraction((x-a)*(f-c),d-a),
             domains=dict.fromkeys('abcdefx',_SIGNED),
             valid=lambda a,b,c,d,e,f,x: a!=d,
             constraint='The x-coordinates of the defining points differ.')
_precalculus('test/428', 'spherical-azimuth-tangent', 'x y z',
             lambda x,y,z: Fraction(y,x), domains=dict.fromkeys('xyz',_SIGNED),
             valid=lambda x,y,z:x!=0, constraint='The azimuth tangent is defined.')
_precalculus('train/338', 'line-segment-parameter-norm', 'x y u v _ _ _ x y _ _ _ _',
             lambda x,y,u,v: (u-x)**2+x*x+(v-y)**2+y*y,
             domains=dict.fromkeys('xyuv',_SIGNED),
             valid=lambda x,y,u,v: (x,y)!=(u,v),
             constraint='The line segment has distinct endpoints.')
_precalculus('train/432', 'lattice-points-on-sphere', 'r',
             lambda r: _lattice_sphere(r), domains={'r':(1,20)},
             reference=lambda r: _lattice_reference(r))
_precalculus('test/145', 'complex-modulus-zero-count', 'a _',
             lambda a: int(a==0), domains={'a':(0,40)})


def _lattice_sphere(r):
    result = 0
    for x,y in product(range(-r,r+1),repeat=2):
        z2 = r*r-x*x-y*y
        if _square(z2):
            result += 1 if z2==0 else 2
    return result


def _lattice_reference(r):
    # Enumerate sorted absolute coordinates, then count sign and order choices.
    count = 0
    for a in range(r+1):
        for b in range(a,r+1):
            for c in range(b,r+1):
                if a*a+b*b+c*c==r*r:
                    count += len(set(permutations((a,b,c)))) * 2**sum(i!=0 for i in (a,b,c))
    return count


# Bind statements in other subjects to the same exact geometry machinery.
def _algebra(ids, family, fields, solve, **kwargs):
    _register('algebra', ids, family, fields, solve, **kwargs)


def _prealgebra(ids, family, fields, solve, **kwargs):
    _register('prealgebra', ids, family, fields, solve, **kwargs)


_algebra('train/175', 'square-area-ratio', 'a b', lambda a,b: Fraction(a*a,b*b))
_algebra('train/203', 'coordinate-square-area', 'x y u v',
         lambda x,y,u,v: (x-u)**2+(y-v)**2,
         domains=dict.fromkeys('xyuv',_SIGNED), valid=lambda x,y,u,v: (x,y)!=(u,v),
         constraint='The adjacent vertices are distinct.')
for subject,ids in (
    ('algebra','train/277 train/1347 test/158 test/422'),
    ('intermediate_algebra','train/1039'),
):
    _register(subject,ids,'maximum-rectangle-area','p',lambda p: Fraction(p*p,16),
              domains={'p':(4,240)})
for ids,k in (('train/36',2),('test/973',4)):
    _algebra(ids,'rectangle-fixed-aspect-area','p',
             lambda p,k=k: k*Fraction(p,2*(k+1))**2, domains={'p':(4,240)})
for ids,k in (('train/812',3),('train/819',2)):
    _prealgebra(ids,'rectangle-fixed-aspect-area','p',
                lambda p,k=k: k*Fraction(p,2*(k+1))**2, domains={'p':(4,240)})
_algebra('train/418', 'triangle-coordinate-intercepts-area', 'm b',
         lambda m,b: Fraction(b*b,2*m))
_algebra('train/697', 'equal-perimeter-regular-polygons', 'n',
         lambda n: 2*n, domains={'n':(3,80)})


def _from_origin_sample(rng):
    x,y,_ = rng.choice([t for t in _TRIPLES if t[-1]<=35])
    return {'x':x*rng.choice((-1,1)), 'y':y*rng.choice((-1,1))}


_algebra('train/731 train/1216 test/12','coordinate-origin-distance','x y',
         lambda x,y:isqrt(x*x+y*y), domains=dict.fromkeys('xy',_SIGNED),
         valid=lambda x,y: (x!=0 or y!=0) and _square(x*x+y*y), sample=_from_origin_sample,
         constraint='The point differs from the origin and has integer distance to it.')
for ids,factor in (('train/296',1),('test/224',4)):
    _algebra(ids,'coordinate-segment-distance','x y u v',
             lambda x,y,u,v,factor=factor: factor*isqrt((u-x)**2+(v-y)**2),
             domains=dict.fromkeys('xyuv',_SIGNED),
             valid=lambda x,y,u,v:(x,y)!=(u,v) and _square((u-x)**2+(v-y)**2),
             constraint='The endpoints are distinct and their distance is an integer.',
             sample=lambda rng: _translated_point_sample(rng))


def _translated_point_sample(rng):
    x,y = (rng.randint(-7,7) for _ in range(2))
    delta = _from_origin_sample(rng)
    return {'x':x,'y':y,'u':x+delta['x'],'v':y+delta['y']}


_algebra('train/1612','rectangle-short-side-from-perimeter-and-area','p area',
         lambda p,area: Fraction(p-isqrt(p*p-16*area),4),
         domains={'p':(4,160),'area':(1,1600)},
         valid=lambda p,area:p*p>16*area and _square(p*p-16*area) and (p-isqrt(p*p-16*area))%4==0,
         sample=lambda rng: (lambda a,b: {'p':2*(a+b),'area':a*b})(*rng.sample(range(1,41),2)),
         constraint='The perimeter and area specify two distinct positive integer side lengths.')
_register('counting_and_probability','train/491','integer-rectangle-perimeter-count','p',
          lambda p: p//4, domains={'p':list(range(4,162,2))},
          reference=lambda p:sum(a<=p//2-a for a in range(1,p//2)))
_register('counting_and_probability','test/294','isosceles-perimeter-count','p',
          lambda p:(p-1)//2-p//4,
          reference=lambda p:sum(_triangle(a,a,p-2*a) for a in range(1,p)))
_register('counting_and_probability','train/656','integer-triangle-perimeter-count','p',
          lambda p:sum(max(0,min((p-1)//2,p-2*a)-((p-a+1)//2)+1)
                       for a in range(1,p//3+1)),
          reference=lambda p:sum(_triangle(a,b,p-a-b) and p-a-b>=b
                                 for a in range(1,p) for b in range(a,p-a)))

for ids,field,solve in (
    ('train/1','p',lambda p: Fraction(p*p,16)),
    ('test/589','p _',lambda p: Fraction(p*p,16)),
    ('train/318','a _',lambda a: 4*isqrt(a)),
    ('test/118','p',lambda p: Fraction(p*p,9)),
    ('test/814','p',lambda p: Fraction(p*p,18)),
    ('test/354 test/399','p',lambda p: 2*p),
    ('train/956','r',lambda r:4*r*r),
    ('train/611','a',lambda a:2*a),
    ('test/509','a',lambda a:6*a),
    ('test/649','p',lambda p:Fraction(p*p,4)),
    ('test/85','r',lambda r:2*r),
    ('test/862','a',lambda a:Fraction(a*a,2)),
):
    domains = {'a':[n*n for n in range(1,41)]} if ids=='train/318' else (
        {'p':(4,160)} if 'p' in field else {}
    )
    _prealgebra(ids,'elementary-shape-measure',field,solve,domains=domains)
_prealgebra('train/86','integer-radius-from-strict-area-bound','area',
            lambda area:isqrt(area-1),domains={'area':(2,1600)},
            reference=lambda area:max(r for r in range(1,41) if r*r<area))
_prealgebra('train/227','circle-radius-from-area','area',lambda area:isqrt(area),
            domains={'area':[n*n for n in range(1,41)]})
_prealgebra('train/972','circle-diameter-from-area','area _',lambda area:2*isqrt(area),
            domains={'area':[n*n for n in range(1,41)]})
_prealgebra('train/269','isosceles-right-triangle-area','_ a',lambda a:Fraction(a*a,2))
_prealgebra('train/1017','isosceles-right-triangle-area','a _ _',lambda a:Fraction(a*a,2))
_prealgebra('train/866','triangle-altitude-from-area','area base',
            lambda area,base:Fraction(2*area,base),domains={'area':(1,1600)})
_prealgebra('test/400','triangle-altitude-from-equal-area','a base',
            lambda a,base:Fraction(2*a*a,base))
_prealgebra('train/575','regular-polygon-side-count-from-perimeter','p a',
            lambda p,a:p//a, domains={'p':(3,1600)},
            valid=lambda p,a:p%a==0 and p>=3*a,
            sample=lambda rng: (lambda n,a: {'p':n*a,'a':a})(rng.randint(3,40),rng.randint(1,40)),
            constraint='Perimeter is an integral multiple of side length, with at least three sides.')
_prealgebra('train/527','rectangle-area-minus-window','a b w h',
            lambda a,b,w,h:a*b-w*h,
            valid=lambda a,b,w,h:w<b and h<a,
            constraint='The rectangular window fits strictly inside the wall.')
_prealgebra('train/1011','triangle-perimeter','a b c',lambda a,b,c:a+b+c,
            valid=_triangle,constraint='The side lengths form a nondegenerate triangle.')
_prealgebra('train/1126','heron-area','a b c',_triangle_area,
            valid=_heron_valid,sample=_triple_sample,
            reference=lambda a,b,c:Fraction(isqrt(4*a*a*b*b-(a*a+b*b-c*c)**2),4),
            constraint='The side lengths form a nondegenerate triangle with rational area.')
for ids,fields in (
    ('train/339','a c'),
    ('test/33','c a'),
):
    _prealgebra(ids,'right-triangle-area-from-leg-and-hypotenuse',fields,
                lambda a,c:Fraction(a*isqrt(c*c-a*a),2),
                valid=lambda a,c:c>a and _square(c*c-a*a),
                sample=lambda rng: (lambda t: {'a':t[0],'c':t[2]})(
                    rng.choice([t for t in _TRIPLES if t[-1]<=40])),
                constraint='The unknown leg is a positive integer.')
_prealgebra('train/568','right-triangle-area-from-shortest-side-and-hypotenuse','c a',
            lambda a,c:Fraction(a*isqrt(c*c-a*a),2),
            valid=lambda a,c:c*c>=2*a*a and _square(c*c-a*a),
            sample=lambda rng: (lambda t: {'a':t[0],'c':t[2]})(
                rng.choice([t for t in _TRIPLES if t[-1]<=40])),
            constraint='The specified leg is the shorter leg and the other leg is a positive integer.')
_prealgebra('train/855 train/1097','right-triangle-hypotenuse','a b',
            lambda a,b:isqrt(a*a+b*b),domains={'a':(1,100),'b':(1,100)},
            valid=lambda a,b:_square(a*a+b*b),
            sample=lambda rng: (lambda t: {'a':t[0],'b':t[1]})(rng.choice(_TRIPLES)),
            constraint='The hypotenuse is an integer.')
_prealgebra('test/243','square-area-from-equal-right-triangle-perimeter','a b',
            lambda a,b:Fraction(a+b+isqrt(a*a+b*b),4)**2,
            valid=lambda a,b:_square(a*a+b*b),
            sample=lambda rng: (lambda t: {'a':t[0],'b':t[1]})(
                rng.choice([t for t in _TRIPLES if t[-1]<=40])),
            constraint='The right triangle has integer hypotenuse.')

# Further explicit variants in the two source subjects.
_geometry('train/68','right-triangle-consecutive-legs','h',lambda h:isqrt(2*h*h-1),
          domains={'h':[5,29,169,985,5741,33461]},
          constraint='The hypotenuse is realizable by two consecutive positive integer legs.')
_geometry('train/50','sphere-hemisphere-volume-ratio','k',lambda k:Fraction(2,k**3))
_geometry('train/91','rectangular-snow-volume','a b n d',
          lambda a,b,n,d:Fraction(a*b*n,d))
_geometry('train/273','cube-volume-unit-conversion','a',
          lambda a:Fraction(a,12)**3, adaptation='Write the side length in inches as a numeral.')
_geometry('train/306','scale-container-capacity','vol',lambda vol:27*vol,
          adaptation='Write the initial capacity as a numeral.')
_geometry('train/151','cube-free-volume-after-ice','a b',
          lambda a,b:Fraction(a**3,2)-10*b**3,
          domains={'a':(4,80),'b':(1,20)}, valid=lambda a,b:a>=4*b,
          sample=lambda rng: (lambda b,k: {'a':b*k,'b':b})(rng.randint(1,10),rng.randint(4,8)),
          constraint='The container side is at least four ice-cube edges.')
_geometry('train/214','triangle-longest-affine-side','a b k c p',
          lambda a,b,k,c,p:max(_affine_sides(a,b,k,c,p)),
          domains={'p':(3,160),'k':(1,10)},
          valid=lambda a,b,k,c,p:_triangle(*_affine_sides(a,b,k,c,p)),
          constraint='The given perimeter determines a nondegenerate triangle.')


def _affine_sides(a,b,k,c,p):
    x = Fraction(p-a-b-c,k+1)
    return a,x+b,k*x+c


_geometry('train/259','equal-cone-sphere-volumes','r h',
          lambda r,h:_cube_root(r*r*h//4),domains={'r':(1,24),'h':(1,160)},
          valid=lambda r,h:r*r*h%4==0 and _cube_root(r*r*h//4)**3==r*r*h//4,
          sample=lambda rng: (lambda r,n: {'r':r,'h':4*r*n**3})(
              rng.randint(1,5),rng.randint(1,2)),
          constraint='The volume equality yields an integer sphere radius.')
_geometry('train/752','minimum-right-triangle-area','a b',
          lambda a,b:Fraction(min(a,b)*isqrt(max(a,b)**2-min(a,b)**2),2),
          valid=lambda a,b:a!=b and _square(abs(a*a-b*b)),
          sample=lambda rng: (lambda t: {'a':t[0],'b':t[2]})(
              rng.choice([t for t in _TRIPLES if t[-1]<=40])),
          constraint='The given sides are a leg and hypotenuse of an integer right triangle, as well as possible legs.')
_geometry('test/127','isosceles-median-length','a b',
          lambda a,b:Fraction(isqrt(4*a*a-b*b),2),
          domains={'a':(1,40),'b':(1,80)},
          valid=lambda a,b: b<2*a and _square(4*a*a-b*b),
          sample=lambda rng: (lambda t: {'a':t[2],'b':2*t[0]})(
              rng.choice([t for t in _TRIPLES if t[-1]<=40])),
          constraint='The isosceles triangle is nondegenerate and its median is rational.')
_geometry('test/123','combine-equal-sphere-volumes','n r',
          lambda n,r:_cube_root(n)*r,domains={'n':[k**3 for k in range(2,13)]},
          adaptation='Write the number of beads as a numeral.')
_geometry('test/154','open-cube-surface-area','a',lambda a:5*a*a,
          adaptation='Write the cube edge length as a numeral.')
_geometry('test/337','right-triangle-affine-sides','_ k k _',
          lambda k:2*k-2,domains={'k':(2,40)},
          reference=lambda k:next(a for a in range(1,80) if (a+1)**2+(k*a)**2==(k*a+1)**2))
_geometry('test/352','perpendicular-route-rounded-distance','a b',
          lambda a,b:_round_square_root(a*a+b*b))
_geometry('test/319','polygon-interior-sum','n',
          lambda n:180*(n-2),domains={'n':(3,40)},
          adaptation='Specify the side count in place of a reference to the original diagram.')
_geometry('test/92 test/347','prism-edge-count','n',
          lambda n:3*n,domains={'n':(3,40)},
          adaptation='Specify the number of sides of the prism base.')
_geometry('test/459','regular-polygon-rotation-angle','n',
          lambda n:Fraction(360,n),domains={'n':(3,40)},
          adaptation='Specify the number of sides of the regular polygon.')
_geometry('test/76','intersecting-chord-segment-ratio','a c',
          lambda a,c:Fraction(c,a),
          adaptation='State the two segment lengths separately so they can vary independently.',
          reference=lambda a,c:Fraction(1,a)/Fraction(1,c))


def _round_square_root(value):
    floor = isqrt(value)
    return floor + (4*value > (2*floor+1)**2)


_precalculus('test/387','double-angle-from-right-triangle-area','area h _',
             lambda area,h:Fraction(4*area,h*h),domains={'area':(1,160),'h':(1,60)},
             valid=lambda area,h:4*area<=h*h,
             constraint='The area is at most the isosceles right triangle area for the given hypotenuse.')
_precalculus('test/445','parallelogram-sine-from-altitudes','p a b',
             lambda p,a,b:Fraction(2*(a+b),p),domains={'p':(1,160)},
             valid=lambda p,a,b:2*(a+b)<=p,
             constraint='The given perimeter and altitudes yield a sine no greater than one.')
_precalculus('test/438','triangle-area-from-projected-base-product','total',
             lambda total:Fraction(total,2),domains={'total':(1,160)})
_precalculus('test/202','equilateral-triangle-coordinate-product','_ _ u v',
             lambda u,v:Fraction(2*u*u+2*v*v-5*u*v,3),
             domains=dict.fromkeys('uv',_SIGNED),valid=lambda u,v: u!=0 or v!=0,
             constraint='The two given ordinates do not both vanish.')
_precalculus('test/245','triangle-area-from-base-angle-tangents','base a b c d',
             lambda base,a,b,c,d:Fraction(base*base*a*c,2*(a*d+c*b)),
             domains={'base':(1,80)})
_precalculus('test/35','right-triangle-angle-cosine','a b _',
             lambda a,b:Fraction(a,isqrt(a*a+b*b)),
             valid=lambda a,b:_square(a*a+b*b),
             sample=lambda rng: (lambda t: {'a':t[0],'b':t[1]})(
                 rng.choice([t for t in _TRIPLES if t[-1]<=40])),
             constraint='The right triangle has integer hypotenuse.')
_precalculus('test/424','right-triangle-angle-cosine','a b _',
             lambda a,b:Fraction(b,isqrt(a*a+b*b)),
             valid=lambda a,b:_square(a*a+b*b),
             sample=lambda rng: (lambda t: {'a':t[0],'b':t[1]})(
                 rng.choice([t for t in _TRIPLES if t[-1]<=40])),
             constraint='The right triangle has integer hypotenuse.')
_precalculus('test/307','right-triangle-sine-from-leg-hypotenuse','_ c b',
             lambda c,b:Fraction(isqrt(c*c-b*b),c),valid=lambda c,b:c>b and _square(c*c-b*b),
             sample=lambda rng: (lambda t: {'c':t[2],'b':t[1]})(
                 rng.choice([t for t in _TRIPLES if t[-1]<=40])),
             constraint='The missing leg is a positive integer.')
_precalculus('test/529','right-triangle-sine-from-radical-leg','_ a b2',
             lambda a,b2:Fraction(a,isqrt(a*a+b2)),domains={'b2':(1,1600)},
             valid=lambda a,b2:_square(a*a+b2),
             sample=lambda rng: (lambda t: {'a':t[0],'b2':t[1]**2})(
                 rng.choice([t for t in _TRIPLES if t[1]<=40])),
             constraint='The hypotenuse is an integer.')
_precalculus('train/585','cosine-of-arcsine-rational','a c',
             lambda a,c:Fraction(isqrt(c*c-a*a),c),
             valid=lambda a,c:c>a and _square(c*c-a*a),
             sample=lambda rng: (lambda t: {'a':t[0],'c':t[2]})(
                 rng.choice([t for t in _TRIPLES if t[-1]<=40])),
             constraint='The arcsine has rational cosine.')
_precalculus('test/70','tangent-from-right-triangle-median-sine','_ a c',
             lambda a,c:Fraction(2*a,isqrt(c*c-a*a)),
             valid=lambda a,c:c>a and _square(c*c-a*a),
             sample=lambda rng: (lambda t: {'a':t[0],'c':t[2]})(
                 rng.choice([t for t in _TRIPLES if t[-1]<=40])),
             constraint='The given sine is a rational ratio from a right triangle with integer sides.')
_precalculus('train/76','maximum-ray-distance','angle length',
             lambda angle,length:Fraction(length,_trig('sin',angle)),
             domains={'angle':[30,90,150]},
             valid=lambda angle,length:angle<=90,
             constraint='The angle has rational sine and is acute or right.')
_precalculus('train/80','sum-to-product-frequency-grid','a b c d',
             lambda a,b,c,d:4+(a+d)//2+(d-b)//2+(b-a)//2,
             domains=dict.fromkeys('abcd',(1,80)),
             valid=lambda a,b,c,d: a<b<c<d and a+d==b+c and (a+d)%2==0 and (b-a)%2==0,
             sample=lambda rng: (lambda a,u,v: {'a':a,'b':a+2*u,'c':a+2*u+2*v,'d':a+4*u+2*v})(
                 rng.randint(1,10),rng.randint(1,7),rng.randint(1,7)),
             constraint='The frequencies are distinct, symmetric and of equal parity.',
             adaptation='Write the initial implicit cosine frequency as a numeral.')


_NORMALIZATIONS = {
    'geometry/train/273': ('six inches', '6 inches'),
    'geometry/train/306': ('two-gallon', '2-gallon'),
    'geometry/test/123': ('Twenty-seven solid', '27 solid'),
    'geometry/test/154': ('length two inches', 'length 2 inches'),
    'geometry/test/319': ('convex hexagon shown', 'convex polygon with 6 sides'),
    'geometry/test/92': ('a hexagonal prism', 'a prism whose base has 6 sides'),
    'geometry/test/347': ('an octagonal prism', 'a prism whose base has 8 sides'),
    'geometry/test/459': ('regular pentagon', 'regular polygon with 5 sides'),
    'geometry/test/76': ('$AP = CP = 7,$', '$AP = 7$ and $CP = 7$,'),
    'geometry/train/717': ('four times', '$4$ times'),
    'geometry/train/377': (r'\frac34', r'\frac{3}{4}'),
    'geometry/test/446': ('2-cm-by-2cm-by-2cm', '$2$ cm by $2$ cm by $2$ cm'),
    'precalculus/train/80': (r'\cos x +', r'\cos 1x +'),
}


def _normalize_statement(problem_id, problem):
    replacement = _NORMALIZATIONS.get(problem_id)
    return problem.replace(*replacement) if replacement is not None else problem


def build(row):
    problem = row['problem']
    degrees = _DEGREES.fullmatch(problem)
    if degrees:
        function, angle = degrees.groups()
        value = int(angle)
        if abs(value) <= 4320 and _trig(function,value) is not None:
            return _exact_trig(function,value)
    if row['id'].startswith('precalculus/'):
        radians = _RADIAN_IDS.get(row['id'].split('/',1)[1])
        if radians is not None:
            return _exact_trig(*radians,radians=True)
    if row['id'] == 'geometry/train/717':
        problem = problem.replace('four times', '$4$ times')
    elif row['id'] == 'geometry/train/377':
        problem = problem.replace(r'\frac34', r'\frac{3}{4}')
    elif row['id'] == 'geometry/test/446':
        problem = problem.replace('2-cm-by-2cm-by-2cm', '$2$ cm by $2$ cm by $2$ cm')
    problem = _normalize_statement(row['id'], problem)
    recipe = _RECIPES.get(row['id'])
    return _bind(problem,recipe) if recipe is not None else None
