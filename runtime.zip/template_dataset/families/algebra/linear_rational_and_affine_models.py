"""Linear rational and affine models; exact source-bound mathematical models."""
from fractions import Fraction as Q
from functools import partial

from template_dataset.families.algebra.parameter_bindings import register

BINDINGS = {}
bind = partial(register, BINDINGS)


bind('train/134 test/108', 'ratio_and_linear_relation',
     {'ratio': (1, 20), 'slope': (-30, 30), 'intercept': (-100, 100)},
     [(3,-5,12), (2,4,-36)],
     lambda r,m,b: f'The ratio of $y$ to $x$ is {r}. Find $x$ if $y={m}x+({b})$.',
     lambda r,m,b:Q(b,r-m), valid=lambda r,m,b:m!=r and b!=0,
     constraints=('slope differs from the ratio and intercept is nonzero',),
     adaptation='Use x and y for the two quantities and express the ratio in the order y to x.')

bind('train/305', 'linear_offset_system',
     {'a': (1, 50), 'b': (1, 50), 'total': (-200, 200), 'offset': (1, 50)},
     [(9,5,108,2)],
     lambda a,b,c,d: f'If $ {a}s+{b}t={c}$ and $s$ is {d} less than $t$, what is $t$?',
     lambda a,b,c,d:Q(c+a*d,a+b))

bind('train/1058', 'linear_offset_system_scaled',
     {'a': (1, 50), 'b': (1, 50), 'total': (-200, 200), 'offset': (1, 50), 'scale': (1, 30)},
     [(5,2,0,2,7)],
     lambda a,b,c,d,k: f'If $ {a}u+{b}v={c}$ and $u$ is {d} less than $v$, what is $ {k}v$?',
     lambda a,b,c,d,k:k*Q(c+a*d,a+b))

bind('test/795', 'linear_multiple_system',
     {'a': (1, 50), 'b': (1, 50), 'total': (-200, 200), 'multiple': (2, 40)},
     [(2,4,5,3)],
     lambda a,b,c,k: f'If $ {a}u+{b}v={c}$ and $u={k}v$, what is $ {k}u$?',
     lambda a,b,c,k:Q(k*k*c,a*k+b))

bind('test/1175', 'linear_consecutive_system',
     {'a': (1, 50), 'b': (1, 50), 'rhs': (-200, 200)}, [(2,3,-23)],
     lambda a,b,c: f'Consecutive integers $u<v$ satisfy $ {a}u-{b}v={c}$. What is $u$?',
     lambda a,b,c:(c+b)//(a-b),
     valid=lambda a,b,c:a!=b and (c+b)%(a-b)==0,
     sample=lambda rng:(lambda a,b,u:(a,b,(a-b)*u-b))(
         rng.randint(1,30),rng.randint(31,50),rng.randint(-3,3)),
     constraints=('a differs from b and a-b divides rhs+b',))

bind('test/41', 'line_point_substitution',
     {'a': (1, 50), 'b': (1, 50), 'rhs': (-200, 200), 'x': (-100, 100)}, [(3,2,12,4)],
     lambda a,b,c,x: f'The point $(u,v)$ is on $ {a}x+{b}y={c}$. What is $v$ when $u={x}$?',
     lambda a,b,c,x:Q(c-a*x,b))

bind('train/894', 'line_coefficient_substitution',
     {'constant': (-50, 50), 'y_coefficient': (1, 50), 'x': (1, 50), 'y': (-50, 50)},
     [(1,3,4,-3)],
     lambda c,d,x,y: f'For what $k$ does the line $ {c}-kx=-{d}y$ contain $( {x},{y} )$?',
     lambda c,d,x,y:Q(c+d*y,x))

bind('train/1084', 'parallel_line_coefficient',
     {'slope': (-50, 50), 'coefficient': (1, 20), 'intercept': (-100, 100),
      'intercept_gap': (1, 100)}, [(8,2,2,6)],
     lambda m,k,b,d: f'Find $c$ if the lines $y={m}x+({b})$ and $y=({k}c)x+({b-d})$ are parallel.',
     lambda m,k,b,d:Q(m,k))

bind('test/1068', 'parallel_line_intercept',
     {'slope': (-50, 50), 'intercept': (-50, 50), 'x': (-50, 50), 'y': (-100, 100)},
     [(4,6,5,10)],
     lambda m,b,x,y: f'A line parallel to $y={m}x+({b})$ passes through $( {x},{y} )$. '
                     'Find its $y$-intercept.',
     lambda m,b,x,y:y-m*x, valid=lambda m,b,x,y:y-m*x!=b,
     constraints=('the two parallel lines are distinct',))

bind('train/108 test/198 test/1075', 'linear_coefficients_from_points',
     {'x1': (-40, 40), 'x_gap': (1, 60), 'y1': (-150, 150), 'y2': (-150, 150), 'sign': (-1, 1)},
     [(4,4,5,17,-1),(-1,8,7,-1,1),(2,3,15,3,1)],
     lambda x,d,y,z,s: f'The line $y=ax+b$ passes through $({x},{y})$ and $({x+d},{z})$. '
                        f'Find $a{"+" if s==1 else "-"}b$.',
     lambda x,d,y,z,s:Q(z-y,d)*(1-s*x)+s*y,
     valid=lambda x,d,y,z,s:s!=0, constraints=('sign is -1 or 1',),
     reference=lambda x,d,y,z,s:Q((z-y)+s*((x+d)*y-x*z),d),
     adaptation='Represent function values as points of the line.')

bind('train/1575 test/1184', 'linear_interpolation',
     {'x1': (-30, 30), 'gap': (1, 30), 'y1': (-50, 50), 'rise': (-30, 30), 'target': (-100, 100)},
     [(1,2,7,6,28),(7,2,0,1,19)],
     lambda x,d,y,r,k: f'Points $({x},{y})$, $({x+d},{y+r})$, and $({k},t)$ lie on a line. Find $t$.',
     lambda x,d,y,r,k:y+Q((k-x)*r,d),
     valid=lambda x,d,y,r,k:k not in (x,x+d),
     constraints=('target differs from both given x-coordinates',),
     adaptation='The redundant third point in the source table is omitted.')

bind('train/1229', 'parallel_segment_slope',
     {'x1': (-50, 50), 'y1': (-50, 50), 'dx1': (1, 50), 'dy1': (-50, 50),
      'x2': (-50, 50), 'y2': (-50, 50), 'dx2': (1, 50)},
     [(-4,0,4,-4,0,8,14)],
     lambda x,y,d,r,u,v,e: f'Segments $AB$ and $XY$ are parallel, with $A({x},{y})$, '
                          f'$B({x+d},{y+r})$, $X({u},{v})$, and $Y({u+e},k)$. Find $k$.',
     lambda x,y,d,r,u,v,e:v+Q(r*e,d),
     valid=lambda x,y,d,r,u,v,e:(v-y)*d!=(u-x)*r,
     constraints=('the two segments lie on distinct parallel lines',))

bind('train/1682', 'line_increments',
     {'run': (1, 50), 'rise': (1, 50), 'target_run': (1, 100)}, [(3,7,9)],
     lambda a,b,c: f'Along a line, when $x$ increases by {a}, $y$ increases by {b}. '
                   f'How much does $y$ increase when $x$ increases by {c}?',
     lambda a,b,c:Q(b*c,a))

bind('train/187 test/814', 'same_addend_fraction',
     {'numerator': (1, 60), 'denominator_gap': (1, 60), 'target_numerator': (1, 60),
      'target_gap': (1, 60)}, [(3,2,5,1),(5,3,2,3)],
     lambda a,g,b,h: f'What number can be added to both numerator and denominator of '
                     f'$ {a}/{a+g}$ to obtain a fraction equal to $ {b}/{b+h}$?',
     lambda a,g,b,h:Q(b*g,h)-a,
     reference=lambda a,g,b,h:Q(b*(a+g)-a*(b+h),h),
     adaptation='The terminating target decimal is written as its equivalent fraction.')

bind('train/1126', 'recover_original_denominator',
     {'numerator': (1, 60), 'addition': (1, 60), 'target_numerator': (1, 60),
      'target_gap': (1, 60)}, [(2,5,1,1)],
     lambda a,k,b,h: f'A fraction has numerator {a}. Adding {k} to both numerator and '
                     f'denominator makes it equal to $ {b}/{b+h}$. Find its original denominator.',
     lambda a,k,b,h:Q((a+k)*(b+h),b)-k,
     valid=lambda a,k,b,h:(a+k)*h%b==0,
     sample=lambda rng:(lambda a,k,h:(a,k,1,h))(
         rng.randint(1,60),rng.randint(1,60),rng.randint(1,60)),
     constraints=('original denominator is a positive integer',))

bind('train/700', 'reciprocal_linear_equation',
     {'a': (1, 30), 'b': (-60, 60), 'c': (-60, 60), 'd': (1, 30)}, [(5,5,12,12)],
     lambda a,b,c,d: f'Find $x$ if $1/{a}+({b})/x=({c})/x+1/{d}$.',
     lambda a,b,c,d:Q((c-b)*a*d,d-a),
     valid=lambda a,b,c,d:a!=d and b!=c,
     constraints=('a differs from d and b differs from c',))

bind('train/763', 'inverse_affine_reciprocal',
     {'slope': (1, 50), 'shift': (-50, 50), 'target_num': (1, 50),
      'target_den': (1, 50)}, [(3,1,1,1)],
     lambda a,b,n,d: f'If $y=1/({a}x+({b}))$, find $x$ when $y={n}/{d}$.',
     lambda a,b,n,d:(Q(d,n)-b)/a)

bind('train/772', 'rational_function_zero',
     {'numerator_constant': (1, 100), 'denominator_scale': (1, 100)}, [(3,4)],
     lambda r,a: f'For what $x$ is $\\frac{{x-{r}}}{{{a}x}}=0$?',
     lambda r,a:r)

bind('train/1136', 'reciprocal_plus_constant',
     {'offset': (-30, 30), 'rhs_num': (1, 100), 'rhs_den': (1, 40)}, [(1,7,3)],
     lambda a,n,d: f'The reciprocal of a number plus {a} equals $ {n}/{d}$. Find the number.',
     lambda a,n,d:Q(d,n-a*d), valid=lambda a,n,d:n!=a*d,
     constraints=('rhs_num differs from offset times rhs_den',))

bind('test/718', 'two_reciprocal_terms',
     {'offset': (1, 30), 'numerator': (2, 100)}, [(3,7)],
     lambda a,n: f'The number {a} plus the reciprocal of a number equals {n} divided by that number. '
                  'What is the number?',
     lambda a,n:Q(n-1,a))

bind('test/1005', 'reciprocal_sum_equation',
     {'x': (1, 100), 'z': (1, 100)}, [(25,24)],
     lambda x,z: f'If $1/x+1/y=1/z$, find $y$ when $x={x}$ and $z={z}$.',
     lambda x,z:Q(x*z,x-z), valid=lambda x,z:x!=z, constraints=('x differs from z',))

bind('train/850', 'inverse_radical_reciprocal',
     {'numerator': (1, 30), 'offset': (1, 30), 'rhs_num': (1, 80),
      'rhs_den': (1, 30)}, [(2,2,3,2)],
     lambda a,b,n,d: f'Find $x$ if $\\sqrt{{{a}/x+{b}}}={n}/{d}$.',
     lambda a,b,n,d:Q(a*d*d,n*n-b*d*d),
     valid=lambda a,b,n,d:n*n!=b*d*d, constraints=('rhs_num squared differs from offset times rhs_den squared',))

bind('test/775 test/801', 'solve_two_linear_equations',
     {'a': (1, 20), 'b': (1, 20), 'c': (1, 20), 'd': (1, 20), 'rhs1': (-100, 100),
      'rhs2': (-100, 100), 'target_x': (1, 30), 'target_y': (1, 30)},
     [(5,2,3,1,7,2,24,14),(2,1,1,1,3,1,8,7)],
     lambda a,b,c,d,r,s,u,v: f'Given $ {a}x-{b}y={r}$ and $ {c}x+{d}y={s}$, find $ {u}x-{v}y$.',
     lambda a,b,c,d,r,s,u,v:Q(u*(r*d+b*s)-v*(a*s-c*r),a*d+b*c),
     reference=lambda a,b,c,d,r,s,u,v:(lambda x:u*x-v*(s-c*x)/d)(Q(r+Q(b*s,d),a+Q(b*c,d))))

bind('test/487 test/585', 'coincident_lines',
     {'a': (1, 30), 'b': (1, 30), 'rhs': (-50, 50), 'scale': (2, 12),
      'offset': (-50, 50), 'parameter_coefficient': (1, 20)}, [(3,2,8,2,-7,2),(2,5,-8,3,16,1)],
     lambda a,b,c,k,o,d: f'For what $t$ does the system $ {a}x+{b}y={c}$ and '
                         f'$ {k*a}x={d}t+({o})-{k*b}y$ have infinitely many solutions?',
     lambda a,b,c,k,o,d:Q(k*c-o,d))

bind('train/1260', 'nested_linear_system',
     {'first_sum': (-100, 100), 'second_sum': (-200, 200)}, [(59,106)],
     lambda a,b: f'Given $t+q={a}$ and $(t+q)+q={b}$, find $t$.',
     lambda a,b:2*a-b)

bind('test/587', 'double_linear_inequality',
     {'lower': (-100, 50), 'gap': (1, 100), 'coefficient': (1, 30), 'shift': (-40, 40)},
     [(-4,12,2,1)],
     lambda a,d,k,s: f'The solution to $ {a}<{k}(x-({s}))<{a+d}$ is $u<x<v$. Find $u+v$.',
     lambda a,d,k,s:Q(2*a+d,k)+2*s)
