"""Symbolic evaluation; exact source-bound mathematical models."""
from fractions import Fraction
import re

from template_dataset.families.algebra.equations_and_expressions import _MATH_BLOCK, _ParseError, _evaluate, _math_body
from template_dataset.families.algebra.symbolic_forms import _Bindings, _ExactParser, _exact, _multivariate, _rational, _scalar

from template_dataset.families.algebra.real_roots import EquationParser, quadratic_roots, rational_form, variables
from template_dataset.families.construction import template


def proposal_template(bindings, family, solve, constraints, *, reference=None, adaptation="", render=None):
    if not bindings.domains:
        return None

    def valid(p):
        try:
            return isinstance(solve(p), (int, Fraction))
        except (ArithmeticError, ValueError, TypeError, KeyError, IndexError):
            return False

    original = bindings.original
    if not valid(original):
        return None

    def sample(rng):
        for _ in range(30):
            p = {k: rng.randint(d["min"], d["max"]) for k, d in bindings.domains.items()}
            if p != original and valid(p):
                return p
        # A radical target may only be rational for a thin set of inputs.
        # Complete one chosen literal around a random proposal, then try the
        # source neighborhood; the source itself never counts as a variant.
        slots = list(bindings.domains)
        rng.shuffle(slots)
        for base in (p, original):
            for k in slots:
                d = bindings.domains[k]
                values = list(range(d["min"], d["max"] + 1))
                rng.shuffle(values)
                for value in values:
                    candidate = dict(base, **{k: value})
                    if candidate != original and valid(candidate):
                        return candidate
        return dict(original)

    return template(
        "extensions.algebra." + family, bindings.domains, original, render or bindings.render, solve,
        valid=valid, sample=sample, reference=reference, constraints=constraints, adaptation=adaptation,
    )


def blocks(problem):
    return [_math_body(block) for block in _MATH_BLOCK.finditer(problem)]


def split_assignments(source, offset):
    for match in re.finditer(r"([^,]+)", source):
        part = re.sub(r"^\s*(?:and\s+)?", "", match[1])
        start = match.end() - len(part)
        yield part, offset + start


def parse_assignment(bindings, source, offset):
    match = re.fullmatch(r"\s*([A-Za-z])\s*=\s*(.+)", source)
    if not match:
        raise _ParseError("expected assignment to a single variable")
    return match[1], bindings.parse(match[2], offset + match.start(2), _ExactParser, match[1])


DIRECT = {
    "algebra/train/147": 0, "algebra/train/164": 0, "algebra/train/207": -1,
    "algebra/train/314": -1, "algebra/train/485": 0, "algebra/train/1134": 0,
    "algebra/train/1634": -2, "algebra/test/64": -1, "algebra/test/112": -1,
    "algebra/test/564": 0, "algebra/test/641": 1, "algebra/test/699": -2,
    "algebra/test/776": -1, "algebra/test/893": -1,
    "algebra/test/1000": 0,
}


def _direct(row, query_index):
    problem = row["problem"]
    inputs = blocks(problem)
    bindings = _Bindings(problem)
    source, offset = inputs.pop(query_index)
    if row["id"] == "algebra/test/564":
        # The source uses a juxtaposed coefficient immediately after a
        # closing parenthesis. Parse it as the equivalent explicit product
        # with offsets translated back to the unmodified source.
        match = re.search(r"(?<=\))(?=\d)", source)
        position = match.start()
        source = source[:position] + "*" + source[position:]
        node, literals = _ExactParser(source).parse()
        qkeys = []
        for start, end, _, single in literals:
            begin = offset + start - int(start > position)
            finish = offset + end - int(end > position)
            key = bindings.bind(f"query_{len(qkeys) + 1}", begin, finish, single=single)
            qkeys.append((key, 1))
        query = node
    else:
        query, qkeys = bindings.parse(source, offset, _ExactParser, "query")
    givens = {}
    for source, offset in inputs:
        for part, start in split_assignments(source, offset):
            name, parsed = parse_assignment(bindings, part, start)
            if name in givens:
                raise _ParseError("duplicate assignment")
            givens[name] = parsed

    def solve(p):
        values = {}
        pending = dict(givens)
        while pending:
            progress = False
            for name, (node, keys) in tuple(pending.items()):
                try:
                    values[name] = _exact(node, bindings.values(keys, p), values)
                except KeyError:
                    continue
                del pending[name]
                progress = True
            if not progress:
                raise ValueError("unbound variable or cyclic assignments")
        result = _scalar(_exact(query, bindings.values(qkeys, p), values))
        if row["id"] == "algebra/test/1000" and result <= 0:
            raise ValueError("the source explicitly asks for a positive value")
        return result

    return proposal_template(
        bindings, "exact_substitution", solve,
        ("Assignments form an acyclic substitution and all operations are defined with a rational final value.",)
        + (("The source explicitly requires the queried radical value to be strictly positive.",)
           if row["id"] == "algebra/test/1000" else ()),
    )


def _aligned_equations(problem):
    for environment in re.finditer(r"\\begin\{align(?:ed|\*)?\}([\s\S]+?)\\end\{align(?:ed|\*)?\}", problem):
        for line in re.finditer(r"(?s).*?(?:\\\\|$)", environment[1]):
            source = line[0].removesuffix(r"\\").rstrip(" ,.;\n")
            if r"\text" in source:
                source = source.split(r"\text")[0].rstrip(" ,.;\n")
            if "=" in source:
                yield source, environment.start(1) + line.start()


def _matrices(equations, values, names):
    zero = (0,) * len(names)
    exponents = [tuple(int(i == j) for i in range(len(names))) for j in range(len(names))]
    matrix = []
    for lhs, rhs in equations:
        (left, lkeys), (right, rkeys) = lhs, rhs
        lpoly = _multivariate(left, values(lkeys), names)
        rpoly = _multivariate(right, values(rkeys), names)
        if (lpoly.keys() | rpoly.keys()) - {zero, *exponents}:
            raise ValueError("equations must be affine")
        matrix.append([lpoly.get(m, 0) - rpoly.get(m, 0) for m in exponents]
                      + [rpoly.get(zero, 0) - lpoly.get(zero, 0)])
    return [[Fraction(x) for x in row] for row in matrix]


def _eliminate(rows):
    n = len(rows)
    rows = [list(row) for row in rows]
    for col in range(n):
        pivot = next((r for r in range(col, n) if rows[r][col]), None)
        if pivot is None:
            raise ValueError("singular system")
        rows[col], rows[pivot] = rows[pivot], rows[col]
        row = rows[col]
        scale = row[col]
        rows[col] = row = [x / scale for x in row]
        for r in range(n):
            if r != col and rows[r][col]:
                multiplier = rows[r][col]
                rows[r] = [x - multiplier * y for x, y in zip(rows[r], row)]
    return tuple(row[-1] for row in rows)


def _det(rows):
    if len(rows) == 1:
        return rows[0][0]
    return sum((-1)**i * rows[0][i] * _det([row[:i] + row[i + 1:] for row in rows[1:]])
               for i in range(len(rows)))


def _cramer(rows):
    matrix = [row[:-1] for row in rows]
    determinant = _det(matrix)
    if not determinant:
        raise ValueError("singular system")
    return tuple(_det([row[:i] + [full[-1]] + row[i + 1:] for row, full in zip(matrix, rows)])
                 / determinant for i in range(len(rows)))


LINEAR = {
    "algebra/train/99", "algebra/train/635", "algebra/train/1542",
    "algebra/test/118", "algebra/test/131", "algebra/test/211", "algebra/test/215",
    "algebra/test/559", "algebra/test/868",
}


PROJECTIVE = {
    "algebra/train/325", "algebra/train/506", "algebra/train/1160", "algebra/train/1294",
    "algebra/test/154", "algebra/test/302", "algebra/test/477", "algebra/test/729",
    "algebra/test/1021",
}


def _linear(row, projective):
    problem = row["problem"]
    bindings = _Bindings(problem)
    original_blocks = blocks(problem)
    source, offset = original_blocks[-1]
    if row["id"] == "algebra/test/118":
        query, qkeys = ("*", ("var", "x"), ("var", "y")), ()
    else:
        query, qkeys = bindings.parse(source, offset, _ExactParser, "query")
    equations = []
    denominators = []
    names = set()
    for source, offset in [*_aligned_equations(problem), *original_blocks[:-1]]:
        if source.count("=") != 1:
            continue
        left, right = source.split("=")
        left_node, left_keys = bindings.parse(left.replace("&", " "), offset, EquationParser, "given")
        right_node, right_keys = bindings.parse(right, offset + len(left) + 1, EquationParser, "given")
        lhs_names, rhs_names = variables(left_node), variables(right_node)
        names |= lhs_names | rhs_names
        if projective and left_node[0] == "/" and lhs_names and not rhs_names:
            numerator, denominator = left_node[1:]
            # The RHS is scalar. Move it into the left AST using a zero-free
            # placeholder for its exact value. Its source literal slots stay
            # independent from the symbolic denominator.
            coefficients = _exact(right_node, bindings.values(right_keys, bindings.original))
            _scalar(coefficients)
            denominators.append((denominator, left_keys))
            equations.append(((numerator, left_keys), (denominator, left_keys), (right_node, right_keys)))
        else:
            equations.append(((left_node, left_keys), (right_node, right_keys), None))
    names = sorted(names)
    if len(names) != len(equations) + int(projective):
        return None

    def evaluate(p, linear_solver):
        def values(keys):
            return bindings.values(keys, p)

        adjusted = []
        for lhs, rhs, scalar in equations:
            if scalar:
                scale = _scalar(_exact(scalar[0], values(scalar[1])))
                rhs = (("*", ("const", scale), rhs[0]), rhs[1])
            adjusted.append((lhs, rhs))
        rows = _matrices(adjusted, values, names)
        if projective:
            if any(row[-1] for row in rows):
                raise ValueError("ratio relations must be homogeneous")
            rows.append([Fraction(int(i == 0)) for i in range(len(names))] + [Fraction(1)])
        solution = dict(zip(names, linear_solver(rows)))
        if projective and not all(solution.values()):
            raise ValueError("the ratio variables must be nonzero")
        for denominator, keys in denominators:
            if not _evaluate(denominator, values(keys), solution, {}):
                raise ValueError("undefined source ratio")
        return _scalar(_exact(query, values(qkeys), {k: _rational(v) for k, v in solution.items()}))

    return proposal_template(
        bindings, "ratio_chain" if projective else "linear_system_value",
        lambda p: evaluate(p, _eliminate),
        ("Ratios have a unique nonzero solution up to common scaling and the query is homogeneous of degree zero.",)
        if projective else ("The affine system is nonsingular and the query is defined with a rational value.",),
        reference=lambda p: evaluate(p, _cramer),
    )


OPERATORS = {
    "algebra/train/295": ("@", False), "algebra/train/376": ("@", False),
    "algebra/train/495": (r"\#", True), "algebra/train/537": (r"\diamondsuit", False),
    "algebra/train/590": (r"\clubsuit", True), "algebra/train/723": (r"\oplus", False),
    "algebra/train/748": (r"\star", False), "algebra/train/843": (r"\text{ Y }", False),
    "algebra/train/1135": (r"\ast", False), "algebra/train/1215": (r"\clubsuit", False),
    "algebra/train/1246": (r"\star", True), "algebra/train/1270": ("@", False),
    "algebra/train/1345": ("*", False), "algebra/test/84": (r"\ast", False),
    "algebra/test/192": (r"\Psi", False), "algebra/test/236": ("*", False),
    "algebra/test/597": ("*", False), "algebra/test/629": (r"\spadesuit", True),
    "algebra/test/859": (r"\star", False),
}


def _operator(row, symbol, inverse):
    bindings = _Bindings(row["problem"])
    inputs = blocks(row["problem"])
    definition = next(((s, i) for s, i in inputs if "=" in s and symbol in s and
                       re.fullmatch(r"\s*[A-Za-z]\s*(?:" + re.escape(symbol) + r")\s*[A-Za-z]\s*",
                                    s.split("=")[0].replace(r"\ ", " "))), None)
    if row["id"] == "algebra/train/376":
        names = ("a", "b")
        rhs, rhs_offset = inputs[2]
    elif definition is not None:
        source, offset = definition
        lhs, rhs = source.split("=", 1)
        names = tuple(s.replace(r"\ ", " ").strip() for s in lhs.split(symbol))
        rhs_offset = offset + len(lhs) + 1
    else:
        return None
    definition_tree, definition_keys = bindings.parse(rhs, rhs_offset, _ExactParser, "definition")

    class OperatorParser(_ExactParser):
        _operators = dict(_ExactParser._operators, **{symbol: (2, "operation")})

        def _peek(self):
            self._skip()
            if self.source.startswith(symbol, self.offset):
                return symbol
            return super()._peek()

    if row["id"] == "algebra/train/748":
        query = ("operation", ("var", "a"), ("var", "b"))
        qkeys = ()
        givens = dict(parse_assignment(bindings, s, i) for s, i in inputs if symbol not in s)
    elif inverse:
        source, offset = next((s, i) for s, i in inputs if symbol in s and "=" in s and (s, i) != definition)
        lhs, rhs = source.split("=")
        query, qkeys = bindings.parse(lhs, offset, OperatorParser, "query")
        target, tkeys = bindings.parse(rhs, offset + len(lhs) + 1, _ExactParser, "target")
        givens = {}
    else:
        source, offset = inputs[-1]
        query, qkeys = bindings.parse(source, offset, OperatorParser, "query")
        givens = {}

    def solve(p):
        constants = {name: _exact(node, bindings.values(keys, p)) for name, (node, keys) in givens.items()}
        dvalues = bindings.values(definition_keys, p)
        qvalues = bindings.values(qkeys, p)

        def replace(node):
            op = node[0]
            if op == "operation":
                values = [_exact(replace(child), qvalues, constants) for child in node[1:]]
                result = _scalar(_exact(definition_tree, dvalues, dict(zip(names, values))))
                return ("const", result)
            if op in ("+", "-", "*", "/", "^"):
                return (op, replace(node[1]), replace(node[2]))
            if op == "neg":
                return (op, replace(node[1]))
            return node

        if not inverse:
            return _scalar(_exact(replace(query), qvalues, constants))
        left, right = query[1:]
        if left[0] == "var" and right[0] != "var":
            unknown_name, fixed_name, fixed = names[0], names[1], right
        elif right[0] == "var" and left[0] != "var":
            unknown_name, fixed_name, fixed = names[1], names[0], left
        else:
            raise ValueError("a single free argument is required")
        fixed = _scalar(_exact(fixed, qvalues))
        value = _scalar(_exact(target, bindings.values(tkeys, p)))

        def plug(node):
            op = node[0]
            if op == "var":
                return ("const", fixed) if node[1] == fixed_name else node
            if op in ("+", "-", "*", "/", "^"):
                exponent = node[2]
                if op == "^":
                    exponent = ("const", _scalar(_exact(exponent, dvalues)))
                return (op, plug(node[1]), plug(exponent))
            if op == "neg":
                return (op, plug(node[1]))
            return node

        n, d, _ = rational_form(("-", plug(definition_tree), ("const", value)), dvalues, unknown_name)
        if len(d) != 1:
            raise ValueError("operator inverse must be polynomial")
        roots = quadratic_roots(n)
        if row["id"] == "algebra/train/495":
            roots = tuple(root for root in roots if not root[1] and root[0] > 0)
        if len(roots) != 1 or roots[0][1]:
            raise ValueError("the operator inverse does not specify a unique rational argument")
        return roots[0][0]

    return proposal_template(
        bindings, "binary_operation", solve,
        ("All applications of the displayed operation are defined and the queried value is rational.",
         "For inverse queries the requested argument exists and is unique under the source sign restriction."),
    )


def build(row):
    key = row["id"]
    try:
        if key in DIRECT:
            return _direct(row, DIRECT[key])
        if key in LINEAR or key in PROJECTIVE:
            return _linear(row, key in PROJECTIVE)
        if key in OPERATORS:
            return _operator(row, *OPERATORS[key])
    except (ValueError, KeyError, IndexError):
        return None
    return None
