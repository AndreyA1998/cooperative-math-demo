"""Progressions; exact source-bound mathematical models."""
from fractions import Fraction as Q
from math import isqrt, prod
from functools import partial

from template_dataset.families.algebra.parameter_bindings import register

BINDINGS = {}
bind = partial(register, BINDINGS)


def triangle(n):
    return n * (n + 1) // 2


bind('train/362 test/237', 'counting_sum', {'n': (5, 3000)}, [(49,), (100,)],
     lambda n: f'Find the sum $1+2+3+\\cdots+{n-1}+{n}$.',
     triangle, reference=lambda n: sum(range(1, n+1)))

bind('train/674 train/1114 test/1044', 'odd_sum', {'n': (4, 3000)}, [(9,), (10,), (5,)],
     lambda n: f'Find the sum of the first {n} positive odd integers.',
     lambda n: n*n, reference=lambda n: sum(range(1, 2*n, 2)))

bind('train/690 train/834 test/1055', 'multiples_sum',
     {'n': (2, 3000), 'step': (2, 200)}, [(10, 13), (7, 9), (10, 3)],
     lambda n,d: f'Find the sum of the first {n} positive multiples of {d}.',
     lambda n,d: d*triangle(n), reference=lambda n,d: sum(range(d, d*(n+1), d)))

bind('train/1261 train/1698 train/1150', 'interval_sum',
     {'start': (-1000, 1000), 'length': (2, 3000)}, [(80, 11), (-30, 81), (4, 8)],
     lambda a,n: f'Find the sum of all integers from {a} to {a+n-1}, inclusive.',
     lambda a,n: n*(2*a+n-1)//2, reference=lambda a,n: sum(range(a,a+n)),
     adaptation='The strict-bound version expresses the same set by its first and last integers.')

bind('test/1016', 'odd_interval_sum',
     {'start_index': (-500, 500), 'length': (2, 1000)}, [(23, 9)],
     lambda a,n: f'Find the sum of the odd integers strictly between {2*a} and {2*(a+n)}.',
     lambda a,n: n*(2*a+n), reference=lambda a,n: sum(range(2*a+1,2*(a+n),2)))

bind('test/702', 'multiples_difference',
     {'n': (2, 3000), 'step': (3, 200)}, [(20, 5)],
     lambda n,d: f'Find the positive difference between the sum of the first {n} positive '
                 f'multiples of {d} and the sum of the first {n} positive even integers.',
     lambda n,d: (d-2)*triangle(n),
     reference=lambda n,d: sum(range(d,d*(n+1),d))-sum(range(2,2*(n+1),2)))

bind('train/1577', 'geometric_integer_sum',
     {'base': (2, 20), 'exponent': (4, 22)}, [(2, 10)],
     lambda b,n: f'Find $1+{b}+{b*b}+{b**3}+\\cdots+{b**n}$. '
                 'Each term is obtained by multiplying its predecessor by the same constant.',
     lambda b,n: (b**(n+1)-1)//(b-1), reference=lambda b,n: sum(b**i for i in range(n+1)))

bind('train/554', 'alternating_geometric_sum',
     {'base': (2, 30), 'terms': (3, 22)}, [(3, 5)],
     lambda b,n: 'Find the sum as a common fraction. $' + ''.join(
         ('-' if i%2==0 else '+' if i>1 else '') + f'\\frac{{1}}{{{b**i}}}'
         for i in range(1,n+1)) + '$',
     lambda b,n: (1-Q(-1,b)**n)/(b+1),
     reference=lambda b,n: sum((-1)**(i-1)*Q(1,b**i) for i in range(1,n+1)))

bind('train/128', 'successive_portions',
     {'denominator': (2, 25), 'trips': (2, 30)}, [(2, 5)],
     lambda d,n: f'On each trip to the refrigerator you eat $1/{d}$ of the pizza that remains. '
                 f'You start with a whole pizza. What fraction of the original pizza have you eaten after {n} trips?',
     lambda d,n: 1-Q(d-1,d)**n,
     reference=lambda d,n: sum(Q(1,d)*Q(d-1,d)**i for i in range(n)))

bind('train/323', 'daily_splitting', {'factor': (2, 9), 'days': (2, 25)}, [(2, 7)],
     lambda f,n: f'An amoeba is placed in an empty puddle. That day it splits into {f} amoebas. '
                 f'On each subsequent day every amoeba splits into {f} amoebas. '
                 f'How many amoebas are in the puddle after {n} days, counting the placement day?',
     lambda f,n: f**n, reference=lambda f,n: prod(f for _ in range(n)))

bind('train/1435', 'monthly_production',
     {'first': (1, 100), 'ratio': (2, 8), 'months': (2, 12)}, [(7, 2, 5)],
     lambda a,r,n: f'BoatsRUs built {a} canoes in the first month and {r} times as many '
                   'as in the preceding month in each subsequent month. '
                   f'How many canoes did it build in the first {n} months?',
     lambda a,r,n: a*(r**n-1)//(r-1),
     reference=lambda a,r,n: sum(a*r**i for i in range(n)))

def first_term(total, count, step):
    return (total - step*triangle(count-1)) // count


def consecutive_total(first, count, step):
    return count*first + step*triangle(count-1)


def sample_consecutive(rng, minimum_count, maximum_count, step):
    first = rng.randint(-50,50) * step
    count = rng.randint(minimum_count,maximum_count)
    return consecutive_total(first,count,step), count


bind('train/718 test/387 test/398', 'first_consecutive_term',
     {'total': (-20000, 20000), 'count': (3, 25), 'step': (1, 2)},
     [(320,5,2), (66,3,2), (49,7,1)],
     lambda s,n,d: f'The sum of {n} consecutive {"even " if d==2 else ""}integers is '
                   f'{s}. What is the smallest?',
     first_term,
     valid=lambda s,n,d:(s-d*triangle(n-1))%(n*d)==0,
     sample=lambda rng:(lambda d:sample_consecutive(rng,3,25,d)+(d,))(rng.randint(1,2)),
     constraints=('total minus the sum of the offsets is divisible by count times step',),
     reference=lambda s,n,d: next(a for a in range(-6700,6701,d)
                                  if consecutive_total(a,n,d)==s))

bind('test/317 test/713', 'consecutive_product',
     {'total': (-600, 600), 'count': (3, 12)}, [(5,5), (27,3)],
     lambda s,n: f'The sum of {n} consecutive integers is {s}. What is their product?',
     lambda s,n: (lambda a:prod(range(a,a+n)))(first_term(s,n,1)),
     valid=lambda s,n:(s-triangle(n-1))%n==0,
     sample=lambda rng:(lambda n,a:(consecutive_total(a,n,1),n))(
         rng.randint(3,12),rng.randint(-40,40)),
     constraints=('total minus the sum of the offsets is divisible by count',))

bind('train/1323', 'consecutive_middle',
     {'endpoint_sum': (-2000, 2000)}, [(118,)],
     lambda s: f'The sum of the first and third of three consecutive integers is {s}. '
               'What is the second integer?',
     lambda s:s//2, valid=lambda s:s%2==0,
     sample=lambda rng:(2*rng.randint(-1000,1000),), constraints=('endpoint_sum is even',))

bind('train/654', 'even_consecutive_sum',
     {'endpoint_sum': (-4000, 4000)}, [(128,)],
     lambda s: f'The sum of the first and third of three consecutive even integers is {s}. '
               'What is the sum of the three integers?',
     lambda s:3*s//2, valid=lambda s:s%4==0,
     sample=lambda rng:(4*rng.randint(-1000,1000),), constraints=('endpoint_sum is divisible by 4',),
     reference=lambda s:sum(range(s//2-2,s//2+3,2)))

bind('test/1064', 'shift_scale_consecutive_sum',
     {'total': (-2000, 2000), 'count': (3, 20), 'shift': (-50, 50), 'scale': (2, 100)},
     [(22,4,2,20)],
     lambda s,n,b,c: f'A set of {n} consecutive integers has a sum of {s}. '
                     f'If {b} is added to each integer and each result is multiplied by {c}, '
                     'what is the new sum?',
     lambda s,n,b,c:c*(s+n*b),
     valid=lambda s,n,b,c:(s-triangle(n-1))%n==0,
     sample=lambda rng:sample_consecutive(rng,3,20,1)+(rng.randint(-50,50),rng.randint(2,100)),
     constraints=('total minus the sum of the offsets is divisible by count',),
     reference=lambda s,n,b,c: (lambda a:sum((x+b)*c for x in range(a,a+n)))(first_term(s,n,1)))

bind('test/1085', 'inverse_odd_sum', {'total': (1, 1000000)}, [(121,)],
     lambda s: f'The sum of the first $N$ positive odd integers is {s}. Find $N$.',
     isqrt, valid=lambda s: isqrt(s)**2 == s,
     sample=lambda rng: (rng.randint(1,1000)**2,),
     constraints=('total is a perfect square',),
     reference=lambda s: next(n for n in range(1,1001) if sum(range(1,2*n,2))==s))

bind('test/528', 'inverse_tournament_games', {'games': (1, 124750)}, [(55,)],
     lambda g: 'A round-robin tournament with $n$ teams requires $(n^2-n)/2$ games. '
               f'How many teams play if there are {g} games?',
     lambda g: (1+isqrt(8*g+1))//2,
     valid=lambda g: isqrt(8*g+1)**2==8*g+1,
     sample=lambda rng: (triangle(rng.randint(1,499)),),
     constraints=('8*games+1 is an odd square',),
     reference=lambda g: next(n for n in range(2,501) if n*(n-1)//2==g))

bind('train/455', 'row_major_lattice',
     {'width': (3, 15), 'row': (5, 100), 'column': (1, 15)}, [(5, 9, 3)],
     lambda w,r,c: f'The counting numbers fill a lattice from left to right, with {w} entries in '
                   f'each row. Its first row runs from 1 through {w}; its second from {w+1} through {2*w}. '
                   f'What is the entry in column {c} of row {r}?',
     lambda w,r,c: w*(r-1)+c, valid=lambda w,r,c:c<=w,
     sample=lambda rng: (lambda w: (w,rng.randint(5,100),rng.randint(1,w)))(rng.randint(3,15)),
     constraints=('column <= width',),
     reference=lambda w,r,c: list(range(1,w*r+1))[-w+c-1])

bind('test/592', 'serpentine_lattice',
     {'width': (3, 20), 'count': (20, 600), 'column': (1, 20)}, [(5, 50, 5)],
     lambda w,n,c: f'The counting numbers from 1 to {n} fill rows of {w} columns. The first row '
                   'runs left to right, the second right to left, and the direction alternates thereafter. '
                   f'Find the sum of the entries in column {c}, counting columns from the left.',
     lambda w,n,c: sum(v for r in range((n+w-1)//w)
                      if (v:=r*w+(c if r%2==0 else w+1-c))<=n),
     valid=lambda w,n,c:c<=w,
     sample=lambda rng: (lambda w: (w,rng.randint(20,600),rng.randint(1,w)))(rng.randint(3,20)),
     constraints=('column <= width',),
     reference=lambda w,n,c: sum(i+1 for i in range(n) if
         (i%w+1 if (i//w)%2==0 else w-i%w)==c))
