"""Polynomial operations; exact source-bound mathematical models."""
from fractions import Fraction
from itertools import combinations
from math import comb, gcd, prod

from template_dataset.families.algebra.equations_and_expressions import _poly_divmod, _poly_mul, _tex_polynomial
from template_dataset.families.algebra.symbolic_forms import _Bindings, _horner

from template_dataset.families.algebra.real_roots import EquationParser, rational_form, variables
from template_dataset.families.algebra.symbolic_evaluation import blocks, proposal_template
from template_dataset.families.construction import choice, draw, integer, integers, template


def _remainder_power(exponent, divisor):
    result, base = (Fraction(1),), (Fraction(0), Fraction(1))
    while exponent:
        if exponent % 2:
            _, result = _poly_divmod(_poly_mul(result, base), divisor)
        exponent //= 2
        if exponent:
            _, base = _poly_divmod(_poly_mul(base, base), divisor)
    return result


def _modular_remainder(row):
    key = row["id"]
    if key == "intermediate_algebra/train/130":
        domains = {"degree": choice([2, 4, 6, 8]), "power": integer(1, 1200),
                   "coefficient": integer(1, 13), "constant": integer(-20, 20)}
        original = {"degree": 2, "power": 1000, "coefficient": 1, "constant": 0}

        def divisor(p):
            return _poly_mul((1, 1), (1,) + (0,) * (p["degree"] - 1) + (1,))

        def dividend(p):
            return ((p["power"], p["coefficient"]), (0, p["constant"]))

        def valid(p):
            return p["power"] % (2 * p["degree"]) == 0

        def sample(rng):
            p = {k: draw(rng, d) for k, d in domains.items()}
            p["power"] = 2 * p["degree"] * rng.randint(1, 70)
            return p

        def reference(p):
            return p["coefficient"] + p["constant"]

        condition = "The degree is even and the exponent is a multiple of twice the degree."

    elif key == "intermediate_algebra/test/865":
        domains = {"terms": choice([3, 5, 7]), "power": integer(1, 220)}
        original = {"terms": 5, "power": 100}

        def divisor(p):
            return tuple((-1)**(k // 2) if k % 2 == 0 else 0
                         for k in range(2 * p["terms"] - 1))

        def dividend(p):
            return ((p["power"], 1),)

        def valid(p):
            return p["power"] % (2 * p["terms"]) == 0

        def sample(rng):
            terms = draw(rng, domains["terms"])
            return {"terms": terms, "power": 2 * terms * rng.randint(1, 12)}

        def reference(p):
            return (-1)**(p["power"] // (2 * p["terms"]))

        condition = "The exponent is a multiple of twice the odd number of divisor terms."

    elif key == "intermediate_algebra/train/957":
        domains = {"terms": integer(3, 9), "stride": integer(1, 45)}
        original = {"terms": 5, "stride": 11}

        def divisor(p):
            return (1,) * p["terms"]

        def dividend(p):
            return tuple((i * p["stride"], 1) for i in range(p["terms"]))

        def valid(p):
            return gcd(p["terms"], p["stride"]) in (1, p["terms"])

        def sample(rng):
            terms = draw(rng, domains["terms"])
            stride = rng.choice([d for d in range(1, 46) if gcd(terms, d) in (1, terms)])
            return {"terms": terms, "stride": stride}

        def reference(p):
            return p["terms"] if p["stride"] % p["terms"] == 0 else 0

        condition = "The exponent stride is either coprime to or a multiple of the number of terms."

    elif key == "intermediate_algebra/test/119":
        domains = {"terms": integer(3, 9), "multipliers": integers(3, 1, 9),
                   "coefficients": integers(4, -9, 9)}
        original = {"terms": 3, "multipliers": [1, 2, 3], "coefficients": [-1, 1, -1, 1]}

        def divisor(p):
            return (1,) * p["terms"]

        def dividend(p):
            return tuple(zip([0] + [p["terms"] * k for k in p["multipliers"]], p["coefficients"]))

        def valid(p):
            return p["multipliers"] == sorted(set(p["multipliers"])) and all(p["coefficients"])

        def sample(rng):
            return {"terms": draw(rng, domains["terms"]),
                    "multipliers": sorted(rng.sample(range(1, 10), 3)),
                    "coefficients": [rng.choice([i for i in range(-9, 10) if i]) for _ in range(4)]}

        def reference(p):
            return sum(p["coefficients"])

        condition = "The three positive exponents are distinct multiples of the divisor's term count."

    elif key == "intermediate_algebra/train/891":
        domains = {"power_a": integer(1, 40), "power_b": integer(1, 40), "shift": integer(-12, 12)}
        original = {"power_a": 4, "power_b": 2, "shift": 1}

        def divisor(p):
            return (1, 1, 1)

        def dividend(p):
            a, b, h = p["power_a"], p["power_b"], p["shift"]
            return ((a + b, 1), (a, -h), (b, -h), (0, h * h))

        def valid(p):
            return {p["power_a"] % 3, p["power_b"] % 3} == {1, 2} and p["shift"] != 0

        def sample(rng):
            a = rng.choice(range(1, 41, 3))
            b = rng.choice(range(2, 41, 3))
            if rng.randrange(2):
                a, b = b, a
            return {"power_a": a, "power_b": b, "shift": rng.choice([k for k in range(-12, 13) if k])}

        def reference(p):
            return 1 + p["shift"] + p["shift"]**2

        condition = "The two exponents have residues 1 and 2 modulo 3 and the common shift is nonzero."

    else:
        return None

    def solve(p):
        divisor_poly = tuple(Fraction(c) for c in divisor(p))
        remainder = [Fraction(0)] * (len(divisor_poly) - 1)
        for exponent, coefficient in dividend(p):
            for i, term in enumerate(_remainder_power(exponent, divisor_poly)):
                remainder[i] += coefficient * term
        if any(remainder[1:]):
            raise ValueError("the remainder must be constant")
        return remainder[0]

    def render(p):
        if key == "intermediate_algebra/train/891":
            def factor(power):
                return _tex_polynomial([-p["shift"]] + [0] * (power - 1) + [1])
            expression = f"({factor(p['power_a'])})({factor(p['power_b'])})"
        else:
            terms = dividend(p)
            coefficients = [0] * (1 + max(exponent for exponent, _ in terms))
            for exponent, coefficient in terms:
                coefficients[exponent] += coefficient
            expression = _tex_polynomial(coefficients)
        if key == "intermediate_algebra/train/130":
            degree = p["degree"]
            divisor_tex = f"(x^{{{degree}}}+1)(x+1)"
        else:
            divisor_tex = _tex_polynomial(divisor(p))
        return f"Find the remainder when ${expression}$ is divided by ${divisor_tex}$."

    return template(
        "extensions.algebra.modular_polynomial_remainder", domains, original, render, solve,
        valid=valid, sample=sample, reference=reference, constraints=(condition,),
        adaptation="Vary the exponents and, where the source permits a scalar remainder, coefficients or divisor size.",
    )


EXPANSIONS = {
    "algebra/train/64": (1, "sum"),
    "algebra/train/395": (0, "constant"),
    "algebra/train/615": (0, "sum"),
}


def _coefficient_sum(row, index, query):
    bindings = _Bindings(row["problem"])
    source, offset = blocks(row["problem"])[index]
    source = source.split("=")[0]
    node, keys = bindings.parse(source, offset, EquationParser, "polynomial")
    variable, = variables(node)
    target = Fraction(1 if query == "sum" else 0)

    def coefficients(p):
        numerator, denominator, _ = rational_form(node, bindings.values(keys, p), variable)
        if len(denominator) != 1:
            raise ValueError("not a polynomial")
        return tuple(c / denominator[0] for c in numerator)

    def solve(p):
        result = coefficients(p)
        return sum(result) if query == "sum" else result[0]

    def reference(p):
        from template_dataset.families.algebra.equations_and_expressions import _evaluate
        return _evaluate(node, bindings.values(keys, p), {variable: target}, {})

    return proposal_template(bindings, "polynomial_coefficient_sum", solve,
                             ("The source product or sum remains a polynomial.",), reference=reference)


def _laurent_binomial():
    domains = {"left_num": integer(1, 12), "left_den": integer(1, 12), "right_num": integer(1, 12),
               "right_den": integer(1, 12), "up": integer(1, 6), "down": integer(1, 6), "power": integer(2, 15)}
    original = {"left_num": 3, "left_den": 2, "right_num": 1, "right_den": 3,
                "up": 2, "down": 1, "power": 6}

    def scalars(p):
        return Fraction(p["left_num"], p["left_den"]), -Fraction(p["right_num"], p["right_den"])

    def solve(p):
        power = p["power"]
        k, remainder = divmod(power * p["up"], p["up"] + p["down"])
        a, b = scalars(p)
        return 0 if remainder else comb(power, k) * a ** (power - k) * b**k

    def reference(p):
        terms = {0: Fraction(1)}
        a, b = scalars(p)
        for _ in range(p["power"]):
            result = {}
            for k, value in terms.items():
                result[k + p["up"]] = result.get(k + p["up"], 0) + a * value
                result[k - p["down"]] = result.get(k - p["down"], 0) + b * value
            terms = result
        return terms.get(0, 0)

    def render(p):
        a = r"\frac{%d}{%d}" % (p["left_num"], p["left_den"])
        b = r"\frac{%d}{%d x^{%d}}" % (p["right_num"], p["right_den"], p["down"])
        return f"Find the constant term in the expansion of $({a}x^{{{p['up']}}}-{b})^{{{p['power']}}}$."

    return template("extensions.algebra.laurent_constant_term", domains, original, render, solve,
                    reference=reference, constraints=("The two exponents have opposite signs.",))


def _consecutive_factors():
    domains = {"start": integer(-20, 32), "step": integer(1, 10), "length": integer(6, 65),
               "degree": integer(3, 64)}
    original = {"start": 1, "step": 2, "length": 50, "degree": 49}

    def offsets(p):
        return [p["start"] + p["step"] * i for i in range(p["length"])]

    def valid(p):
        return 1 <= p["length"] - p["degree"] <= 3

    def sample(rng):
        p = {k: draw(rng, d) for k, d in domains.items()}
        p["degree"] = p["length"] - rng.randint(1, 3)
        return p

    def solve(p):
        k = p["length"] - p["degree"]
        coeffs = [1] + [0] * k
        for a in offsets(p):
            for j in range(k, 0, -1):
                coeffs[j] += a * coeffs[j - 1]
        return coeffs[-1]

    def reference(p):
        return sum(map(prod, combinations(offsets(p), p["length"] - p["degree"])))

    def render(p):
        values = offsets(p)
        factors = ["(" + _tex_polynomial((value, 1)) + ")" for value in values]
        shown = "".join(factors[:3]) + r"\cdots " + "".join(factors[-2:])
        return f"Find the coefficient of $x^{{{p['degree']}}}$ in the expansion of ${shown}$."

    return template(
        "extensions.algebra.progression_product_coefficient", domains, original, render, solve,
        valid=valid, sample=sample, reference=reference,
        constraints=("The requested degree is one, two or three below the product's degree.",),
    )


def _interpolation():
    domains = {"equal_nodes": integers(3, -12, 12), "equal_value": integer(-30, 30),
               "other_node": integer(-12, 12), "other_value": integer(-30, 30), "target": integer(-16, 16)}
    original = {"equal_nodes": [-3, -2, 4], "equal_value": 4,
                "other_node": 5, "other_value": 16, "target": 11}

    def valid(p):
        return len(set(p["equal_nodes"] + [p["other_node"], p["target"]])) == 5 and p["equal_value"] != p["other_value"]

    def solve(p):
        a, b, t = p["equal_value"], p["other_value"], p["target"]
        return a + Fraction((b - a) * prod(t - n for n in p["equal_nodes"]),
                            prod(p["other_node"] - n for n in p["equal_nodes"]))

    def reference(p):
        nodes = p["equal_nodes"] + [p["other_node"]]
        values = [p["equal_value"]] * 3 + [p["other_value"]]
        return sum(y * prod(Fraction(p["target"] - v, x - v) for v in nodes if v != x)
                   for x, y in zip(nodes, values))

    def render(p):
        points = [f"p({x})={p['equal_value']}" for x in p["equal_nodes"]]
        points.append(f"p({p['other_node']})={p['other_value']}")
        return (f"Let $p(x)$ be a cubic polynomial with $" + r",\; ".join(points)
                + f"$. Find $p({p['target']})$.")

    return template(
        "extensions.algebra.cubic_interpolation", domains, original, render, solve,
        valid=valid, reference=reference,
        constraints=("All four interpolation nodes and the target differ. The fourth value differs from the first three.",),
    )


def _partial_fractions(key):
    repeated = key == "intermediate_algebra/test/844"
    domains = {"pole": integer(-12, 12), "numerator": integers(3 if repeated else 2, -250, 250)}
    original = {"pole": 1 if repeated else 3, "numerator": [-7, 5, 0] if repeated else [-23, 4]}
    if not repeated:
        domains["second_pole"] = integer(-12, 12)
        original["second_pole"] = -8

    def residues(p):
        coeffs = p["numerator"]
        h = p["pole"]
        if repeated:
            return coeffs[2], coeffs[1] + 2 * h * coeffs[2], _horner(coeffs, h)
        k = p["second_pole"]
        return Fraction(_horner(coeffs, h), h - k), Fraction(_horner(coeffs, k), k - h)

    def valid(p):
        if repeated:
            return any(p["numerator"])
        return p["pole"] != p["second_pole"] and all(v.denominator == 1 for v in residues(p))

    def sample(rng):
        h, k = rng.sample(range(-12, 13), 2)
        a, b, c = (rng.randint(-9, 9) for _ in range(3))
        if repeated:
            return {"pole": h, "numerator": [a*h*h - b*h + c, b - 2*a*h, a]}
        return {"pole": h, "second_pole": k, "numerator": [-a*k - b*h, a+b]}

    def solve(p):
        return sum(residues(p)) if repeated else prod(residues(p))

    def reference(p):
        if repeated:
            return _horner(p["numerator"], p["pole"] + 1)
        n, m = p["numerator"]
        h, k = p["pole"], p["second_pole"]
        a = Fraction(n + m*h, h - k)
        return a * (m - a)

    def render(p):
        n = _tex_polynomial(p["numerator"])
        h = _tex_polynomial((-p["pole"], 1))
        if repeated:
            lhs = r"\frac{%s}{(%s)^3}" % (n, h)
            rhs = " + ".join(r"\frac{%s}{(%s)%s}" % (variable, h, f"^{i}" if i > 1 else "")
                             for i, variable in enumerate("ABC", 1))
            return fr"If ${lhs}={rhs}$ for all $x\ne {p['pole']}$, find $A+B+C$."
        k = _tex_polynomial((-p["second_pole"], 1))
        denominator = _tex_polynomial(_poly_mul((-p["pole"], 1), (-p["second_pole"], 1)))
        lhs = r"\frac{C}{%s}+\frac{D}{%s}" % (h, k)
        rhs = r"\frac{%s}{%s}" % (n, denominator)
        return (f"Find $CD$ for the integers $C,D$ satisfying ${lhs}={rhs}$ "
                f"for all real $x$ other than ${p['pole']}$ and ${p['second_pole']}$.")

    return template(
        "extensions.algebra.partial_fraction_coefficients", domains, original, render, solve,
        valid=valid, sample=sample, reference=reference,
        constraints=("The two poles are distinct and both residues are integers.",)
        if not repeated else ("The numerator is nonzero and has degree below the denominator's.",),
    )


def _conjugates(key):
    originals = {
        "intermediate_algebra/train/300": ([2, 4, 14, 0], [-1, 1, -2, -1], [5, 10, 7, 2]),
        "intermediate_algebra/train/765": ([3, -3, 1, 1], [-2, -2, 1, -1], [2, 2, 7, 7]),
        "intermediate_algebra/test/649": ([1, 3, 1, 5], [-1, 1, 1, 0], [2, 7, 2, 1]),
    }
    centers, scales, radicals = originals[key]
    length = sum(bool(x) for x in scales)
    squarefree = [d for d in range(2, 34) if all(d % (k*k) for k in range(2, 6))]
    domains = {"centers": integers(4, -18, 18), "radical_coefficients": integers(length, -7, 7),
               "radicands": integers(length, 2, 33)}
    original = {"centers": centers, "radical_coefficients": scales[:length], "radicands": radicals[:length]}

    def triples(p):
        return list(zip(p["centers"], p["radical_coefficients"], p["radicands"]))

    def valid(p):
        return all(b and d in squarefree for _, b, d in triples(p)) and len(set(triples(p))) == length

    def sample(rng):
        p = {k: draw(rng, d) for k, d in domains.items()}
        p["radical_coefficients"] = [rng.choice([b for b in range(-7, 8) if b]) for _ in range(length)]
        p["radicands"] = [rng.choice(squarefree) for _ in range(length)]
        pairs = rng.randint(0, length // 2)
        positions = rng.sample(range(length), 2 * pairs)
        for left, right in zip(positions[::2], positions[1::2]):
            p["centers"][right] = p["centers"][left]
            p["radicands"][right] = p["radicands"][left]
            p["radical_coefficients"][right] = -p["radical_coefficients"][left]
        return p

    def solve(p):
        factors = {(-2*a, a*a - b*b*d) for a, b, d in triples(p)}
        return 2 * len(factors) + 4 - length

    def render(p):
        terms = []
        for a, b, d in triples(p):
            coefficient = str(abs(b)) if abs(b) != 1 else ""
            radical = coefficient + r"\sqrt{%d}" % d
            if a:
                terms.append(str(a) + ("+" if b > 0 else "-") + radical)
            else:
                terms.append(("-" if b < 0 else "") + radical)
        terms.extend(map(str, p["centers"][length:]))
        shown = r",\; ".join(terms)
        return (f"Suppose the four numbers ${shown}$ are roots of the same nonzero polynomial "
                "with rational coefficients. What is its smallest possible degree?")

    return template(
        "extensions.algebra.minimum_conjugate_polynomial_degree", domains, original, render, solve,
        valid=valid, sample=sample,
        constraints=("The radical coefficients are nonzero, each radicand is squarefree, and the four displayed roots are distinct.",),
    )


def build(row):
    key = row["id"]
    if key in EXPANSIONS:
        return _coefficient_sum(row, *EXPANSIONS[key])
    if key == "intermediate_algebra/test/729":
        return _consecutive_factors()
    if key == "intermediate_algebra/test/835":
        return _laurent_binomial()
    if key == "intermediate_algebra/test/651":
        return _interpolation()
    if key in {"intermediate_algebra/test/429", "intermediate_algebra/test/844"}:
        return _partial_fractions(key)
    if key in {"intermediate_algebra/train/300", "intermediate_algebra/train/765", "intermediate_algebra/test/649"}:
        return _conjugates(key)
    return _modular_remainder(row)
