"""Sequences growth and sum inversion; exact source-bound mathematical models."""
from fractions import Fraction as Q
from math import isqrt

from template_dataset.families.algebra.given_bindings import register

BINDINGS = {}


def add(*args, **kwargs):
    register(BINDINGS, *args, **kwargs)


def triangular(n):
    return n*(n+1)//2


add(609, 'even_sum_over_consecutive_sum',
    (('even_upper',500,2,3000),('ordinary_upper',250,1,1500)),
    lambda a,b:f'Sean adds all even integers from 2 through {a}, inclusive. Julie adds all integers from 1 through {b}, inclusive. Find Sean’s sum divided by Julie’s sum.',
    lambda a,b:Q(2*triangular(a//2),triangular(b)),
    reference=lambda a,b:Q(sum(range(2,a+1,2)),sum(range(1,b+1))),
    valid=lambda a,b:a%2==0, sample=lambda r:(2*r.randint(1,1500),r.randint(1,1500)),
    constraints=('even_upper is even',))


def odd_middle(limit, factor):
    return tuple(n for n in range(3,limit,2) if 3*n*factor==(n-2)*n*(n+2) and n+2<=limit)


def odd_sample(r):
    n=r.choice([n for n in range(3,98,2) if (n*n-4)%3==0 and (n*n-4)//3<=3000])
    return (1 if n<=7 else 2),(n*n-4)//3


add(616, 'odd_triplet_sum_product',
    (('max_digits',1,1,2),('fraction_denominator',7,1,3000)),
    lambda d,k:rf'The sum of three consecutive positive odd integers, each with at most {d} decimal digit(s), is $\frac{{1}}{{{k}}}$ of their product. What is the middle integer?',
    lambda d,k:isqrt(3*k+4),
    valid=lambda d,k:len(odd_middle(10**d-1,k))==1,
    reference=lambda d,k:odd_middle(10**d-1,k)[0],
    sample=odd_sample,
    constraints=('3*fraction_denominator+4 is the square of an odd integer from 3 through 10^max_digits-3',))


add(972, 'first_two_progression_product',
    (('index',5,3,80),('indexed_term',11,-1000,1000),('increase',1,1,40)),
    lambda n,t,d:f'Term number {n} of an arithmetic sequence is {t}. Each term is {d} larger than the previous term. Find the product of the first two terms.',
    lambda n,t,d:(t-(n-1)*d)*(t-(n-2)*d),
    reference=lambda n,t,d:(lambda terms:terms[-1]*terms[-2])([t-k*d for k in range(n)]),
    adaptation='State explicitly that the given consecutive difference is the increase.')

def floor_division_count(n,d):
    count=0
    while n>1:
        n//=d
        count+=1
    return count,n


add(1138, 'iterated_floor_division_to_one',
    (('initial',100,2,10**12),('divisor',2,2,20)),
    lambda n,d:f'Shaffiq starts with {n}, repeatedly divides by {d}, and rounds down to an integer after each division. How many divisions are required to reach 1?',
    lambda n,d:floor_division_count(n,d)[0],
    valid=lambda n,d:floor_division_count(n,d)[1]==1,
    sample=lambda r:((d:=r.randint(2,10))**(k:=r.randint(1,10))+r.randint(0,d**k-1),d),
    reference=lambda n,d:next(k for k in range(1,41) if d**k<=n<2*d**k),
    constraints=('the iterated divisions reach 1 before reaching 0',))


def median_data(n,a,b):
    return Q(a**b,n)


add(1248, 'consecutive_integer_median',
    (('count',49,3,150),('total_base',7,2,30),('total_exponent',5,1,8)),
    lambda n,a,b:rf'The sum of {n} consecutive integers is ${a}^{{{b}}}$. What is their median?',
    median_data,
    valid=lambda n,a,b:(median_data(n,a,b)-Q(n-1,2)).denominator==1,
    sample=lambda r:((a:=r.choice(range(3,16,2)))**(k:=r.randint(1,2)),a,r.randint(k,8)),
    constraints=('the average minus (count-1)/2 is an integer',))


def growth_days(initial, factor, bound):
    day=1
    population=initial*factor
    while population<=bound:
        population*=factor
        day+=1
    return day


add(1266, 'strict_integer_growth_threshold',
    (('initial_population',3,1,100),('daily_multiplier',2,2,10),('threshold',100,1,10000)),
    lambda a,b,t:f'A colony starts with {a} bacteria. At the end of each day its population is multiplied by {b}, so at the end of day 1 it contains {a*b}. What is the first day ending with more than {t} bacteria?',
    growth_days,
    reference=lambda a,b,t:next(k for k in range(1,16) if a*b**k>t))


def finite_sum(a,b,r,n):
    return sum((Q(a,b)*r**k for k in range(n)),Q())


def finite_term_count(a,b,c,d,p,q):
    r=Q(b,c)
    if r>=1 or Q(c,d)!=r:
        return None
    target=Q(p,q)
    return next((n for n in range(1,15) if target==finite_sum(a,b,r,n)),None)


def series_sample(rng):
    a,b,r,n=rng.randint(1,20),rng.randint(1,40),rng.randint(2,8),rng.randint(2,10)
    value=finite_sum(a,b,Q(1,r),n)
    return a,b,b*r,b*r*r,value.numerator,value.denominator


def series_reference(a,b,c,d,p,q):
    r=Q(b,c)
    return next(n for n in range(1,15) if Q(p,q)==Q(a,b)*(1-r**n)/(1-r))


add(1376, 'geometric_partial_sum_inverse',
    (('common_numerator',1,1,20),('first_denominator',4,1,40),
     ('second_denominator',8,2,320),('third_denominator',16,3,2560),
     ('sum_numerator',63,1,10**15),('sum_denominator',128,1,10**15)),
    lambda a,b,c,d,p,q:rf'The first $n$ terms of the geometric sequence $\{{\frac{{{a}}}{{{b}}},\frac{{{a}}}{{{c}}},\frac{{{a}}}{{{d}}},\dots\}}$ sum to $\frac{{{p}}}{{{q}}}$. Find $n$.',
    finite_term_count,
    valid=lambda *p:finite_term_count(*p) is not None,
    sample=series_sample,
    constraints=('the first three terms have a common ratio strictly between 0 and 1',
                 'target fraction is the sum of 1 through 14 terms for at least one term count'),
    reference=series_reference)


def missing_term_ratio(a,b,c,d,en,ed,fn,fd):
    ratio=Q(b,a)
    return ratio if (ratio!=1 and a*ratio**2==c and a*ratio**5==d and
                     a*ratio**6==Q(en,ed) and a*ratio**7==Q(fn,fd)) else None


def missing_sample(r):
    d=r.randint(2,5)
    k=r.randint(1,100)
    return k*d**5,k*d**4,k*d**3,k,k,d,k,d*d


add(1447, 'missing_geometric_terms_sum',
    (('first',2048,1,10**7),('second',512,1,10**7),('third',128,1,10**7),('sixth',2,1,10**7),
     ('seventh_numerator',1,1,10**7),('seventh_denominator',2,1,10**7),
     ('eighth_numerator',1,1,10**7),('eighth_denominator',8,1,10**7)),
    lambda a,b,c,d,e,f,g,h:rf'Each term after the first in ${a},{b},{c},x,y,{d},\frac{{{e}}}{{{f}}},\frac{{{g}}}{{{h}}},\dots$ is obtained by multiplying the previous term by a constant. Find $x+y$.',
    lambda a,b,c,d,*p: c*Q(b,a)+d/Q(b,a),
    valid=lambda *p:missing_term_ratio(*p) is not None,
    sample=missing_sample,
    constraints=('all displayed terms agree with a common positive ratio different from 1',))


def display_rows(a,d,total):
    discriminant=(2*a-d)**2+8*d*total
    if isqrt(discriminant)**2!=discriminant:
        return Q(0)
    return Q(d-2*a+isqrt(discriminant),2*d)


add(1463, 'arithmetic_display_row_count',
    (('top_cans',1,1,30),('row_increase',2,1,30),('total_cans',100,1,200000)),
    lambda a,d,t:f'A grocer’s display has {a} cans in the top row and each lower row has {d} more cans than the previous row. There are {t} cans total. How many rows are there?',
    display_rows,
    valid=lambda a,d,t:(x:=display_rows(a,d,t))>0 and x.denominator==1,
    sample=lambda r:((a:=r.randint(1,30)),(d:=r.randint(1,30)),(n:=r.randint(1,100))*a+triangular(n-1)*d),
    reference=lambda a,d,t:next(n for n in range(1,634) if sum(a+k*d for k in range(n))==t),
    constraints=('total_cans is a positive integral number of complete rows',))


def bounce_count(a,b,h,t):
    height=Q(h*a,b)
    count=1
    while height>=t:
        count+=1
        height*=Q(a,b)
    return count


add(1567, 'strict_bounce_threshold',
    (('ratio_numerator',2,1,19),('ratio_denominator',3,2,20),('height',243,1,5000),('threshold',30,1,5000)),
    lambda a,b,h,t:rf'A ball rebounds to $\frac{{{a}}}{{{b}}}$ of its previous drop height. It is dropped from {h} cm. After how many bounces does it first rise less than {t} cm?',
    bounce_count,
    valid=lambda a,b,h,t:a<b and t<=h,
    constraints=('ratio_numerator < ratio_denominator and threshold <= height',),
    reference=lambda a,b,h,t:next(n for n in range(1,168) if h*a**n<t*b**n))
