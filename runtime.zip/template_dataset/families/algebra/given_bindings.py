"""Given bindings; exact source-bound mathematical models."""
from fractions import Fraction
from math import isqrt

from template_dataset.families.construction import integer, template


def register(group, key, family, givens, render, solve, *,
             valid=None, constraints=(), sample=None, reference=None, adaptation=''):
    """Givens specify (name, original, minimum, maximum) in argument order."""
    original = {name: value for name, value, _, _ in givens}
    domains = {name: integer(lo, hi) for name, _, lo, hi in givens}

    def unpack(fn):
        return lambda p: fn(*(p[name] for name in original))

    def factory():
        return template(
            'round3_algebra_train_' + family, domains, original, unpack(render), unpack(solve),
            valid=unpack(valid) if valid else lambda p: True, constraints=constraints,
            sample=(lambda rng: dict(zip(original, sample(rng)))) if sample else None,
            reference=unpack(reference) if reference else None, adaptation=adaptation,
        )

    for number in (key if isinstance(key, tuple) else (key,)):
        group[number] = factory


def decimal(value, places):
    unit = 10**places
    sign = '-' if value < 0 else ''
    whole, part = divmod(abs(value), unit)
    return f'{sign}{whole}.{part:0{places}d}'


def root(n, k):
    """Floor of the nonnegative integer kth root by monotone binary search."""
    lo, hi = 0, 1 << ((n.bit_length() + k - 1) // k)
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if mid**k <= n:
            lo = mid
        else:
            hi = mid
    return hi if hi**k <= n else lo


def square(n):
    return n >= 0 and isqrt(n)**2 == n


def roots(a, b, c):
    discriminant = b*b - 4*a*c
    if not a or not square(discriminant):
        return ()
    delta = isqrt(discriminant)
    return tuple(sorted({Fraction(-b-delta, 2*a), Fraction(-b+delta, 2*a)}))


def signed(number):
    return f'{number:+d}'
