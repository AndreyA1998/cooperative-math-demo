"""Symmetric identities; exact source-bound mathematical models."""
from fractions import Fraction
from math import isqrt

from template_dataset.families.algebra.equations_and_expressions import _tex_polynomial

from template_dataset.families.algebra.real_roots import quadratic_roots, rational_roots
from template_dataset.families.construction import draw, integer, is_square, sqrt_fraction, template


# Inputs: s=x+y, d=x-y, p=xy, q=x²+y², ss=(x+y)², dd=x²-y², c=x³+y³.
PAIRS = {
    "algebra/train/82": ("d", 15, "p", 4, "q"),
    "algebra/train/104": ("q", 90, "p", 27, "s_max"),
    "algebra/train/264": ("s", 9, "p", 20, "reciprocal_integer"),
    "algebra/train/477": ("p", 4, "s", 5, "absdiff"),
    "algebra/train/514": ("ss", 25, "p", 6, "q"),
    "algebra/train/583": ("p", 9, "s", 6, "q"),
    "algebra/train/652": ("s", 6, "dd", 12, "d"),
    "algebra/train/1399": ("s", 4, "q", 8, "c"),
    "algebra/test/65": ("p", 7, "s", 8, "absdiff"),
    "algebra/test/312": ("p", 7, "s", 5, "q"),
    "algebra/test/677": ("ss", 105, "q", 65, "p"),
    "intermediate_algebra/train/236": ("d", 5, "q", 35, "diff_cubes"),
    "intermediate_algebra/train/984": ("s", 10, "p", 17, "c"),
    "intermediate_algebra/train/1092": ("s", 3, "c", 81, "p"),
    "intermediate_algebra/test/610": ("s", 5, "q", 15, "c"),
}


def _pair(key):
    first, a, second, b, query = PAIRS[key]
    domains = {name: integer(min(-250, value), max(250, value))
               for name, value in ((first, a), (second, b))}
    if query in {"c", "diff_cubes"}:
        for name in domains:
            domains[name] = integer(-350, 350)
    if "c" in domains:
        domains["c"] = integer(-4000, 4000)
    original = {first: a, second: b}
    x, y = ("a", "b") if key.startswith("intermediate") else ("x", "y")
    expressions = {
        "s": f"{x}+{y}", "d": f"{x}-{y}", "p": x+y, "q": f"{x}^2+{y}^2",
        "ss": f"({x}+{y})^2", "dd": f"{x}^2-{y}^2", "c": f"{x}^3+{y}^3",
        "s_max": f"{x}+{y}", "absdiff": f"|{x}-{y}|", "diff_cubes": f"{x}^3-{y}^3",
        "reciprocal_integer": r"\frac{1}{%s}+\frac{1}{%s}" % (x, y),
    }

    def invariants(parameters):
        p = {k: Fraction(v) for k, v in parameters.items()}
        if "dd" in p:
            if not p["s"]:
                raise ValueError("sum must be nonzero")
            p["d"] = p["dd"] / p["s"]
            return p
        if "s" in p:
            p["ss"] = p["s"]**2
        if "c" in p:
            if not p["s"]:
                raise ValueError("sum must be nonzero")
            p["p"] = (p["s"]**3 - p["c"]) / (3 * p["s"])
        if "d" in p:
            if "q" in p:
                p["p"] = (p["q"] - p["d"]**2) / 2
            p["ss"] = p["d"]**2 + 4*p["p"]
        if "p" not in p:
            p["p"] = (p["ss"] - p["q"]) / 2
        if "ss" not in p:
            p["ss"] = p["q"] + 2*p["p"]
        if "q" not in p:
            p["q"] = p["ss"] - 2*p["p"]
        if key != "algebra/test/312" and (p["ss"] < 0 or p["ss"] - 4*p["p"] < 0):
            raise ValueError("no real pair realizes the givens")
        return p

    def solve(p):
        v = invariants(p)
        if query == "s_max":
            return sqrt_fraction(v["ss"])
        if query == "absdiff":
            return sqrt_fraction(v["ss"] - 4*v["p"])
        if query == "diff_cubes":
            return v["d"] * (v["q"] + v["p"])
        if query == "c":
            return v["s"] * (v["q"] - v["p"])
        if query == "reciprocal_integer":
            if not v["p"]:
                raise ValueError("both integers must be nonzero")
            roots = quadratic_roots((v["p"], -v["s"], Fraction(1)))
            if not all(not scale and root.denominator == 1 for root, scale, _ in roots):
                raise ValueError("both roots must be integers")
            return v["s"] / v["p"]
        return v[query]

    def valid(p):
        try:
            solve(p)
        except (ArithmeticError, ValueError):
            return False
        return True

    def sample(rng):
        if query in {"s_max", "absdiff", "reciprocal_integer"} or "c" in domains:
            r, t = (rng.randint(-12, 12) for _ in range(2))
            values = {"s": r+t, "p": r*t, "q": r*r+t*t, "c": r**3+t**3}
            return {k: values[k] for k in domains}
        return {k: draw(rng, domain) for k, domain in domains.items()}

    def render(p):
        given = f"${expressions[first]}={p[first]}$ and ${expressions[second]}={p[second]}$"
        target = f"${expressions[query]}$"
        if query == "s_max":
            return f"For real ${x},{y}$ satisfying {given}, find the greatest possible value of {target}."
        if query == "reciprocal_integer":
            return (fr"Define $a*b=\frac{{1}}{{a}}+\frac{{1}}{{b}}$ for nonzero integers. "
                    f"If {given.replace(x, 'a').replace(y, 'b')}, find $a*b$ as a common fraction.")
        kind = "complex" if key == "algebra/test/312" else "real"
        return f"If {kind} ${x},{y}$ satisfy {given}, find {target}."

    return template(
        "extensions.algebra.symmetric_pair_identity", domains, original, render, solve,
        valid=valid, sample=sample,
        constraints=("The query is a rational scalar even when its two roots are complex.",)
        if key == "algebra/test/312" else
        ("The givens admit real values and the query is an exact rational scalar.",
         "If the original operation requires integers, the roots must be nonzero integers."),
        adaptation="Specify complex roots because the source sum and product have negative discriminant."
        if key == "algebra/test/312" else "",
    )


RECIPROCAL = {
    "algebra/train/53": ("m", 1, 8, 2, 4),
    "algebra/train/357": ("x", 1, 6, 2, 0),
    "intermediate_algebra/train/374": ("a", 1, 4, 4, 0),
    "algebra/test/657": ("x", 2, 7, 2, 0),
}


def _reciprocal(key):
    variable, input_power, s, power, offset = RECIPROCAL[key]
    domains = {"sum": integer(-22 if input_power == 1 else 2, 30), "product": integer(1, 25),
               "power": integer(2, 9)}
    original = {"sum": s, "product": 1, "power": power}
    if offset:
        original["offset"] = offset
        domains["offset"] = integer(-10, 14)

    def valid(p):
        return p["sum"]**2 >= 4*p["product"]

    def solve(p):
        s, k = p["sum"], p["product"]
        older, current = 2, s
        for _ in range(2, p["power"] + 1):
            older, current = current, s * current - k * older
        return current + p.get("offset", 0)

    def reference(p):
        s, k = p["sum"], p["product"]
        a, b = 1, 0
        # Compute the remainder of t^n modulo t²-s t+k.
        for _ in range(p["power"]):
            a, b = -k * b, a + s * b
        return 2*a + b*s + p.get("offset", 0)

    def render(p):
        t = variable if input_power == 1 else f"{variable}^{input_power}"
        k, n, s = p["product"], p["power"], p["sum"]
        expression = f"{variable}^{{{input_power*n}}}+" + r"\left(\frac{%d}{%s}\right)^{%d}" % (k, t, n)
        if p.get("offset"):
            expression += ("+" if p["offset"] > 0 else "-") + str(abs(p["offset"]))
        return fr"If ${t}+\frac{{{k}}}{{{t}}}={s}$, find ${expression}$."

    return template(
        "extensions.algebra.reciprocal_power_sum", domains, original, render, solve,
        valid=valid, reference=reference,
        constraints=("The displayed sum and product have a nonnegative discriminant. An even input power requires positive roots.",),
        adaptation="Allow the product of the two reciprocal terms and the queried exponent to vary.",
    )


TRIPLES = {
    "algebra/train/1509": ([24, 48, 72], ("x", "y", "z"), False),
    "algebra/test/672": ([24, 48, 18], ("j", "k", "l"), False),
    "intermediate_algebra/test/612": ([24, 48, 72], ("x", "y", "z"), False),
    "intermediate_algebra/train/1040": ([152, 162, 170], ("a", "b", "c"), True),
}


def _triples(key):
    givens, names, star = TRIPLES[key]
    domains = {name: integer(1, 450) for name in ("first", "second", "third")}
    original = dict(zip(domains, givens))

    def products(p):
        a, b, c = (Fraction(p[k]) for k in domains)
        if star:
            return (a+b-c)/2, (a+c-b)/2, (b+c-a)/2
        return a, b, c

    def valid(p):
        u, v, w = products(p)
        return min(u, v, w) > 0 and is_square(u*v*w)

    def solve(p):
        u, v, w = products(p)
        k = sqrt_fraction(u*v*w)
        return k if star else u*v/k + u*w/k + v*w/k

    def reference(p):
        u, v, w = products(p)
        x = sqrt_fraction(u*v/w)
        y, z = u/x, v/x
        return x*y*z if star else x+y+z

    def sample(rng):
        a, b, c = (rng.randint(1, 14) for _ in range(3))
        ab, ac, bc = a*b, a*c, b*c
        quantities = (ab+ac, ab+bc, ac+bc) if star else (ab, ac, bc)
        return dict(zip(domains, quantities))

    def render(p):
        a, b, c = names
        lhs = (f"{a}({b}+{c})", f"{b}({c}+{a})", f"{c}({a}+{b})") if star else (a+b, a+c, b+c)
        givens = ", ".join(f"${e}={p[k]}$" for e, k in zip(lhs, domains))
        query = a+b+c if star else f"{a}+{b}+{c}"
        return f"If positive real ${a},{b},{c}$ satisfy {givens}, find ${query}$."

    return template(
        "extensions.algebra.positive_pairwise_products", domains, original, render, solve,
        valid=valid, sample=sample, reference=reference,
        constraints=("The three pairwise products inferred from the givens are positive and their product is a rational square.",),
    )


def _symmetric_cross_terms():
    domains = {"total_product": integer(-80, 80), "cross_terms": integer(-80, 80)}
    original = {"total_product": 25, "cross_terms": 7}
    return template(
        "extensions.algebra.cubic_symmetric_identity", domains, original,
        lambda p: (r"For real $x,y,z$, suppose $(x+y+z)(xy+xz+yz)=" + str(p["total_product"])
                   + r"$ and $x^2(y+z)+y^2(x+z)+z^2(x+y)=" + str(p["cross_terms"]) + r"$. Find $xyz$."),
        lambda p: Fraction(p["total_product"] - p["cross_terms"], 3),
        constraints=("Both cubic quantities are unrestricted real-compatible integers.",),
    )


def _shifted_products():
    domains = {"p_shift": integer(-15, 15), "q_shift": integer(-15, 15),
               "step": integer(1, 9), "total": integer(-120, 120)}
    original = {"p_shift": 3, "q_shift": 4, "step": 2, "total": 44}

    def solve(p):
        a, b, s, t = (p[k] for k in domains)
        return Fraction(t - a*b + (a-s)*(b-s), s)

    def render(p):
        a, b, s, t = (p[k] for k in domains)
        def factor(name, constant):
            return "(" + _tex_polynomial((constant, 1), name) + ")"
        return f"Find $p+q$ given ${factor('q',b)}{factor('p',a)}-{factor('q',b-s)}{factor('p',a-s)}={t}$."

    return template("extensions.algebra.shifted_bilinear_difference", domains, original, render, solve,
                    constraints=("Both shifts decrease by the same nonzero amount, so only the sum p+q remains.",))


def _integer_pair():
    domains = {"sum_and_product": integer(3, 220), "sum_times_product": integer(2, 3200)}
    original = {"sum_and_product": 71, "sum_times_product": 880}

    def feasible(p):
        n, k = p["sum_and_product"], p["sum_times_product"]
        values = set()
        for s in rational_roots((Fraction(k), Fraction(-n), Fraction(1))):
            xy = n - s
            if s <= 0 or s.denominator != 1 or xy <= 0:
                continue
            roots = quadratic_roots((xy, -s, Fraction(1)))
            if roots and all(r > 0 and not scale and r.denominator == 1 for r, scale, _ in roots):
                values.add(s*s-2*xy)
        return values

    def solve(p):
        answer, = feasible(p)
        return answer

    def reference(p):
        n, k = p["sum_and_product"] + 1, p["sum_times_product"]
        values = {(d-1)**2+(n//d-1)**2 for d in range(2, isqrt(n)+1)
                  if n % d == 0 and (d-1)*(n//d-1)*(d+n//d-2) == k}
        answer, = values
        return answer

    def sample(rng):
        x, y = rng.randint(1, 12), rng.randint(1, 12)
        return {"sum_and_product": x*y+x+y, "sum_times_product": x*y*(x+y)}

    def render(p):
        return (f"For positive integers $x,y$ with $xy+x+y={p['sum_and_product']}$ "
                f"and $x^2y+xy^2={p['sum_times_product']}$, find $x^2+y^2$.")

    return template(
        "extensions.algebra.integer_symmetric_system", domains, original, render, solve,
        valid=lambda p: len(feasible(p)) == 1, sample=sample, reference=reference,
        constraints=("A positive integer pair realizes the givens and every such pair has the same sum of squares.",),
    )


def _positive_reciprocal_system():
    domains = {"product": integer(1, 15), "sum_x": integer(1, 30), "sum_y": integer(1, 45)}
    original = {"product": 1, "sum_x": 5, "sum_y": 29}

    def solve(p):
        k, a, b = (p[name] for name in domains)
        return Fraction(b+k, a*b-1) + Fraction(k*a+1, k*(a*b-1))

    def reference(p):
        k, a, b = (p[name] for name in domains)
        x = Fraction(k*a+1, b+k)
        y = b - 1/x
        z = k / (x*y)
        return z + 1/y

    def render(p):
        return (f"For positive real $x,y,z$ with $xyz={p['product']}$, "
                f"$x+1/z={p['sum_x']}$, and $y+1/x={p['sum_y']}$, find $z+1/y$.")

    return template(
        "extensions.algebra.positive_reciprocal_cycle", domains, original, render, solve,
        valid=lambda p: p["sum_x"]*p["sum_y"] > 1, reference=reference,
        constraints=("The two stated sums have product greater than one, which gives positive x, y and z.",),
    )


def _quadratic_norm_product(key):
    original = {"left_norm": 8, "right_norm": 13} if key.endswith("/28") else {"left_norm": 3, "right_norm": 4}
    domains = {k: integer(1, 50) for k in original}

    def render(p):
        return (f"If real $a,b,c,d$ satisfy $a^2+b^2={p['left_norm']}$ and "
                f"$c^2+d^2={p['right_norm']}$, find $(ac+bd)^2+(ad-bc)^2$.")

    return template("extensions.algebra.quadratic_norm_product", domains, original, render,
                    lambda p: p["left_norm"] * p["right_norm"],
                    constraints=("Both squared norms are positive.",))


def _canceling_cubic():
    domains = {"root_scale": integer(1, 9), "equation_scale": integer(1, 12), "shift": integer(-8, 8)}
    original = {"root_scale": 2, "equation_scale": 1, "shift": 0}

    def coefficients(p):
        c, t = p["equation_scale"], p["root_scale"]
        return c, c*t*t, c*t**3

    def solve(p):
        c, a, b = coefficients(p)
        return Fraction(a*a*b, c)

    def render(p):
        c, a, b = coefficients(p)
        t = "x" if not p["shift"] else "(" + _tex_polynomial((p["shift"], 1)) + ")"
        c_text = str(c) if c != 1 else ""
        return f"If real $x$ satisfies ${c_text}{t}^3+{a}{t}={b}$, find ${c*c}{t}^7+{2*a*b}{t}^2$."

    return template(
        "extensions.algebra.cubic_reduction_identity", domains, original, render, solve,
        constraints=("The linear and constant coefficients satisfy c*b²=a³. The shifted cubic is strictly increasing.",),
        adaptation="Allow an affine shift of the input while retaining the coefficient relation that makes the remainder constant.",
    )


SPECIAL = {
    "algebra/test/823": _shifted_products,
    "algebra/train/229": _symmetric_cross_terms,
    "intermediate_algebra/train/539": _integer_pair,
    "intermediate_algebra/train/668": _canceling_cubic,
    "intermediate_algebra/train/693": _positive_reciprocal_system,
}


def build(row):
    key = row["id"]
    if key in PAIRS:
        return _pair(key)
    if key in RECIPROCAL:
        return _reciprocal(key)
    if key in TRIPLES:
        return _triples(key)
    if key in SPECIAL:
        return SPECIAL[key]()
    if key in {"intermediate_algebra/test/28", "intermediate_algebra/test/473"}:
        return _quadratic_norm_product(key)
    return None
