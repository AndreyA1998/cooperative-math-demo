"""Quadratic roots and common factors; exact source-bound mathematical models."""
from fractions import Fraction as Q
from math import isqrt

from template_dataset.families.algebra.parameter_bindings import polynomial
from template_dataset.families.algebra.given_bindings import register, roots, signed, square

BINDINGS = {}


def add(*args, **kwargs):
    register(BINDINGS, *args, **kwargs)


def temperature_sample(r):
    a,b = sorted(r.sample(range(1,31),2))
    c = r.randint(-100,100)
    return a+b,c,c+a*b


add(97, 'temperature_largest_root',
    (('linear_coefficient',12,3,59),('constant',50,-100,100),('target',77,-99,970)),
    lambda b,c,t:rf'The temperature $t$ hours after noon is ${polynomial(-1,b,c,"t")}$. What is the largest $t$ at which it equals {t} degrees?',
    lambda b,c,t:roots(-1,b,c-t)[-1],
    valid=lambda b,c,t:bool(roots(-1,b,c-t)) and t>c,
    sample=temperature_sample,
    constraints=('target > constant and the quadratic has rational roots',))

add(129, 'repeated_denominator_root',
    (('cubic_coefficient',2,1,30),('numerator_constant',3,-30,30),
     ('denominator_linear',-20,-60,60),('denominator_constant',100,0,900)),
    lambda a,b,c,d:rf'For what $x$ is $\frac{{{a}x^3{signed(b)}}}{{{polynomial(1,c,d)}}}$ undefined?',
    lambda a,b,c,d:Q(-c,2),
    valid=lambda a,b,c,d:c*c==4*d,
    sample=lambda r:(r.randint(1,30),r.randint(-30,30),-2*(z:=r.randint(-30,30)),z*z),
    constraints=('denominator_linear² = 4*denominator_constant',))


def ordered_factors_sample(r):
    b,a=sorted(r.sample(range(31),2))
    return -(a+b),a*b,r.randint(1,15)


add(158, 'ordered_monic_factors',
    (('linear_coefficient',-16,-59,-1),('constant',60,0,870),('multiplier',3,1,15)),
    lambda b,c,k:rf'Write ${polynomial(1,b,c)}$ as $(x-a)(x-b)$ for nonnegative integers $a>b$. What is ${k}b-a$?',
    lambda b,c,k:(lambda v:k*v[0]-v[1])(roots(1,b,c)),
    valid=lambda b,c,k:len(v:=roots(1,b,c))==2 and all(x>=0 and x.denominator==1 for x in v),
    sample=ordered_factors_sample,
    constraints=('the monic quadratic has two distinct nonnegative integer roots',))


def rectangle_equal_sample(r):
    return r.choice(((1,3),(2,2),(3,1),(3,5),(4,3),(6,2),(12,2),(15,3),(20,2),(30,2)))


def rectangle_equal_root(a,b):
    return roots(a,a*b-2*a-2,-2*b)


add(213, 'rectangle_area_equals_perimeter',
    (('length_coefficient',3,1,30),('width_offset',5,1,50)),
    lambda a,b:f'A rectangle has length ${a}x$ inches and width $x+{b}$ inches. If its area and perimeter have equal numerical values, what is $x$?',
    lambda a,b:rectangle_equal_root(a,b)[-1],
    valid=lambda a,b:bool(rectangle_equal_root(a,b)),
    sample=rectangle_equal_sample,
    constraints=('the area-minus-perimeter quadratic has rational roots',))


def factor_candidates(a,b,c,d):
    if c*d==0 or not a:
        return ()
    return tuple((x,a//x) for x in range(-abs(a),abs(a)+1)
                 if x and a%x==0 and x*d+(a//x)*c==-b)


def factor_sample(r):
    a,b,c,d=r.randint(1,15),r.randint(1,15),r.randint(1,20),r.randint(1,20)
    return a*b,-a*d-b*c,c,d


add(262, 'two_linear_factors_with_constants',
    (('leading',12,1,225),('linear',-65,-600,-2),('first_constant_magnitude',14,1,20),
     ('second_constant_magnitude',3,1,20)),
    lambda a,b,c,d:rf'Write ${polynomial(a,b,c*d,"y")}$ as $(Ay-{c})(By-{d})$, where $A,B$ are integers. Find $AB+A$.',
    lambda a,b,c,d:a+factor_candidates(a,b,c,d)[0][0],
    valid=lambda a,b,c,d:len(factor_candidates(a,b,c,d))==1,
    sample=factor_sample,
    constraints=('exactly one integer pair A,B has AB=leading and A*second_constant_magnitude+B*first_constant_magnitude=-linear',))


add(798, 'complete_the_square_positive_coefficient',
    (('constant',44,2,10001),('vertex_offset',8,-100,100)),
    lambda c,d:rf'For a positive number $b$, $x^2+bx+{c}$ can be rewritten as $(x+m)^2+({d})$. Find $b$.',
    lambda c,d:2*isqrt(c-d),
    valid=lambda c,d:c>d and square(c-d),
    sample=lambda r:((d:=r.randint(1,100))+r.randint(1,99)**2,d),
    constraints=('constant - vertex_offset is a positive perfect square',))


def pole_sample(r):
    a,b,c,d=(r.randint(1,15) for _ in range(4))
    return r.randint(-30,30),a*c,-a*d-b*c,b*d


add(916, 'larger_undefined_input',
    (('numerator_constant',1,-30,30),('leading',8,1,225),('linear',-65,-450,450),('constant',8,-225,225)),
    lambda n,a,b,c:rf'What is the largest $x$ for which $\dfrac{{x{signed(n)}}}{{{polynomial(a,b,c)}}}$ is undefined?',
    lambda n,a,b,c:roots(a,b,c)[-1],
    valid=lambda n,a,b,c:bool(roots(a,b,c)),
    sample=pole_sample, constraints=('the denominator quadratic has real rational roots',))


def shared_monic(s,t,u,v,op):
    first=roots(1,-s,t)
    second=roots(1,-u,v)
    solutions=[]
    for b in first:
        if b in second and len(first)==len(second)==2:
            a=s-b
            c=op*(u-b)
            if all(x.denominator==1 for x in (a,b,c)):
                solutions.append(a+b+c)
    return tuple(solutions)


def shared_sample(r,op):
    a,b,c=r.sample(range(1,31),3)
    return a+b,a*b,b+op*c,op*b*c


add(935, 'shared_monic_factor_opposite_sign',
    (('first_linear',15,3,60),('first_constant',54,1,900),
     ('second_linear_magnitude',17,3,60),('second_constant',72,1,900)),
    lambda s,t,u,v:rf'Write ${polynomial(1,s,t)}=(x+a)(x+b)$ and ${polynomial(1,-u,v)}=(x-b)(x-c)$ with integers $a,b,c$. Find $a+b+c$.',
    lambda *p:shared_monic(*p,1)[0],
    valid=lambda *p:len(shared_monic(*p,1))==1,
    sample=lambda r:shared_sample(r,1),
    constraints=('the first and second monic factorizations have exactly one shared integer magnitude b and both have distinct roots',))

add(1230, 'shared_monic_factor_mixed_sign',
    (('first_linear',13,3,60),('first_constant',30,1,900),
     ('second_linear',5,-29,29),('second_constant',-50,-900,-1)),
    lambda s,t,u,v:rf'Write ${polynomial(1,s,t)}=(x+a)(x+b)$ and ${polynomial(1,u,v)}=(x+b)(x-c)$ with integers $a,b,c$. Find $a+b+c$.',
    lambda *p:shared_monic(*p,-1)[0],
    valid=lambda *p:len(shared_monic(*p,-1))==1,
    sample=lambda r:shared_sample(r,-1),
    constraints=('the first and second monic factorizations have exactly one shared integer b and both have distinct roots',))


def field_sample(r):
    a,b,c,x=(r.randint(1,30) for _ in range(4))
    return a,b,c,(a*(x+c)+b)*x


add(1062, 'rectangular_field_positive_dimensions',
    (('first_coefficient',2,1,30),('first_constant',7,1,30),
     ('second_offset',2,1,30),('area',51,1,54900)),
    lambda a,b,c,t:f'A rectangle has dimensions ${a}m+{b}$ and $m-{c}$ and area {t}. Find $m$.',
    lambda a,b,c,t:roots(a,b-a*c,-b*c-t)[-1],
    valid=lambda a,b,c,t:bool(roots(a,b-a*c,-b*c-t)),
    sample=field_sample, constraints=('the area equation has rational roots',))


add(1140, 'constant_from_quadratic_radical_root',
    (('leading',5,1,50),('linear',21,-70,70),('radicand',301,0,5000)),
    lambda a,b,d:rf'For what real $v$ is $\frac{{{-b}-\sqrt{{{d}}}}}{{{2*a}}}$ a root of ${a}x^2{signed(b)}x+v$?',
    lambda a,b,d:Q(b*b-d,4*a),
    constraints=('displayed denominator is twice leading',))


add(1379, 'sideways_parabola_x_intercept',
    (('quadratic_coefficient',-2,-50,50),('linear_coefficient',1,-50,50),('constant',1,-50,50)),
    lambda a,b,c:f'How many $x$-intercepts does the parabola $x={polynomial(a,b,c,"y")}$ have?',
    lambda a,b,c:1,
    valid=lambda a,b,c:a!=0, constraints=('quadratic_coefficient is nonzero',))


def other_root_sample(r):
    a,b,c,d=(r.randint(1,15) for _ in range(4))
    offset=r.randint(-80,80)
    return a*c, b*d+offset, a*d+b*c, offset, b,a


add(1408, 'other_quadratic_root_with_split_constant',
    (('leading',56,1,225),('left_constant',27,-79,305),('right_linear',89,2,450),
     ('right_constant',-8,-80,80),('known_numerator',5,1,15),('known_denominator',7,1,15)),
    lambda a,b,c,d,m,n:rf'Given that $x=\frac{{{m}}}{{{n}}}$ solves ${a}x^2{signed(b)}={c}x{signed(d)}$, find the other solution as a fraction.',
    lambda a,b,c,d,m,n:Q(c,a)-Q(m,n),
    valid=lambda a,b,c,d,m,n:a*m*m-c*m*n+(b-d)*n*n==0 and 2*a*m!=c*n,
    sample=other_root_sample,
    constraints=('known_numerator / known_denominator is a root and the two roots are distinct',))


add(1429, 'symmetric_circle_intersection',
    (('fixed_y',7,-100,100),('squared_radius',100,1,20000)),
    lambda y,n:f'Find the sum of the $x$ solutions of $y={y}$ and $x^2+y^2={n}$.',
    lambda y,n:0,
    valid=lambda y,n:n>y*y, constraints=('squared_radius > fixed_y²',))


def squares_sample(r):
    a,b=sorted(r.sample(range(1,81),2))
    return a*a+b*b,b*b-a*a


def two_square_areas(s,d):
    return s+d,s-d


add(1511, 'square_perimeters_from_area_totals',
    (('area_sum',65,5,12641),('area_difference',33,1,6399)),
    lambda s,d:f'The sum of the areas of two squares is {s}, and the difference is {d}. Find the sum of their perimeters.',
    lambda s,d:4*(isqrt((s+d)//2)+isqrt((s-d)//2)),
    valid=lambda s,d:s>d and (s-d)%2==0 and all(square(v//2) for v in two_square_areas(s,d)),
    sample=squares_sample,
    constraints=('both (area_sum ± area_difference)/2 are positive perfect squares',))


def shared_roots(a,b,c,d,e,f):
    return tuple(x for x in roots(a,b,c) if d*x*x+e*x+f==0)


def common_root_sample(r):
    a,b,c,d,e,f=(r.randint(1,15) for _ in range(6))
    return a*c,a*d-b*c,-b*d,a*e,a*f-b*e,-b*f


add(1520, 'common_quadratic_root',
    (('first_leading',8,1,225),('first_linear',7,-225,225),('first_constant',-1,-225,-1),
     ('second_leading',24,1,225),('second_linear',53,-225,225),('second_constant',-7,-225,-1)),
    lambda a,b,c,d,e,f:f'Find the common solution of ${polynomial(a,b,c)}=0$ and ${polynomial(d,e,f)}=0$ as a simplified fraction.',
    lambda *p:shared_roots(*p)[0],
    reference=lambda a,b,c,d,e,f:Q(a*f-d*c,d*b-a*e),
    valid=lambda *p:len(shared_roots(*p))==1, sample=common_root_sample,
    constraints=('the two quadratics have exactly one common rational root',))


add(1541, 'sum_of_excluded_rational_inputs',
    (('numerator_coefficient',3,1,25),('leading',2,1,225),('linear',-6,-450,450),('constant',4,-225,225)),
    lambda n,a,b,c:rf'The domain of $y=\frac{{{n}x}}{{{polynomial(a,b,c)}}}$ omits exactly two real values $A,B$. What is $A+B$?',
    lambda n,a,b,c:Q(-b,a),
    valid=lambda n,a,b,c:b*b>4*a*c,
    sample=lambda r:(r.randint(1,25),*pole_sample(r)[1:]),
    constraints=('the denominator discriminant is positive',))


add(1580, 'vertical_asymptote_no_cancellation',
    (('linear',2,-40,40),('constant',8,-60,60),('pole',4,-40,40)),
    lambda b,c,d:rf'Where does $y=\frac{{{polynomial(1,b,c)}}}{{x-({d})}}$ have a vertical asymptote?',
    lambda b,c,d:d,
    valid=lambda b,c,d:d*d+b*d+c!=0, constraints=('the numerator is nonzero at pole',))


def nonmonic_factor_candidates(k,b,c):
    return tuple((b-k*y,y) for y in range(-abs(c),abs(c)+1)
                 if y and (b-k*y)*y==c)


def nonmonic_sample(r):
    k,a,b=r.randint(1,15),r.randint(1,30),r.randint(-30,-1)
    return k,a+k*b,a*b


add(1661, 'nonmonic_factor_constant_difference',
    (('leading',3,1,15),('linear',-1,-449,29),('constant',-24,-900,-1)),
    lambda k,b,c:rf'Write ${polynomial(k,b,c,"y")}=( {k}y+a)(y+b)$ with integer $a,b$. Find $a-b$.',
    lambda *p:(lambda v:v[0]-v[1])(nonmonic_factor_candidates(*p)[0]),
    valid=lambda *p:len(nonmonic_factor_candidates(*p))==1,
    sample=nonmonic_sample, constraints=('there is exactly one integer factor-constant pair a,b',))


def linear_area_roots(a,b,c,d,e):
    return tuple(x for x in roots(b,c-a*b-d,-a*c-e) if x>a and b*x+c>0)


def linear_area_sample(r):
    a,b,c,z,d=(r.randint(1,10) for _ in range(5))
    x=a+z
    return a,b,c,d,z*(b*x+c)-d*x


add(1672, 'rectangular_linear_area',
    (('first_offset',2,1,10),('second_coefficient',2,1,10),('second_constant',5,1,10),
     ('area_slope',8,1,10),('area_constant',-6,-200,2100)),
    lambda a,b,c,d,e:f'A rectangle has dimensions $x-{a}$ by ${b}x+{c}$ and area ${d}x{signed(e)}$. What is $x$?',
    lambda *p:linear_area_roots(*p)[0],
    valid=lambda *p:len(linear_area_roots(*p))==1,
    sample=linear_area_sample,
    constraints=('the area equation has exactly one rational root giving positive dimensions and at most one real root giving positive dimensions',))


add(1737, 'constant_from_quadratic_radical_roots',
    (('leading_numerator',3,1,60),('leading_denominator',2,1,20),
     ('linear',11,-50,50),('radicand',7,1,1000)),
    lambda a,d,b,n:rf'If the roots of $\frac{{{a}}}{{{d}}}x^2{signed(b)}x+c=0$ are $x=\frac{{{-b}\pm\sqrt{{{n}}}}}{{{Q(2*a,d)}}}$, find $c$.',
    lambda a,d,b,n:Q(d*(b*b-n),4*a),
    constraints=('the radical-root denominator is twice the displayed leading coefficient',))
