"""Quadratic constraints; exact source-bound mathematical models."""
from fractions import Fraction as Q
from functools import partial
from math import gcd, isqrt

from template_dataset.families.construction import is_square, sqrt_fraction
from template_dataset.families.algebra.parameter_bindings import polynomial, register

BINDINGS = {}
bind = partial(register, BINDINGS)


def discriminant(a,b,c):
    return b*b-4*a*c


def roots(a,b,c):
    delta = sqrt_fraction(discriminant(a,b,c))
    return tuple(sorted(((-b-delta)/(2*a),(-b+delta)/(2*a))))


def rational_roots(a,b,c):
    return a!=0 and is_square(discriminant(a,b,c))


def sample_quadratic(rng, sign=1, minimum_gap=1):
    a = rng.randint(1,12)*sign
    u = rng.randint(-30,29)
    v = u+rng.randint(minimum_gap,20)
    return a,-a*(u+v),a*u*v


def ceil(value):
    return -(-value.numerator//value.denominator)


def floor(value):
    return value.numerator//value.denominator


quadratic = {'a': (1, 12), 'b': (-1000, 1000), 'c': (-20000, 20000)}
downward_quadratic = {'a': (-12,-1), **{k:v for k,v in quadratic.items() if k!='a'}}


bind('train/318 test/1135', 'largest_integer_quadratic_negative',
     quadratic, [(1,-9,18),(6,1,-2)],
     lambda a,b,c: f'Find the greatest integer $x$ such that $ {polynomial(a,b,c)}<0$.',
     lambda a,b,c:ceil(roots(a,b,c)[1])-1,
     valid=lambda a,b,c:rational_roots(a,b,c) and ceil(roots(a,b,c)[1])-1>roots(a,b,c)[0],
     sample=lambda rng:sample_quadratic(rng, minimum_gap=2),
     constraints=('quadratic has rational roots and their open interval contains an integer',),
     reference=lambda a,b,c:max(x for x in range(-1100,1101) if a*x*x+b*x+c<0))

bind('train/1441', 'greatest_quadratic_nonpositive',
     quadratic, [(1,-10,21)],
     lambda a,b,c: f'Find the greatest real $x$ such that $ {polynomial(a,b,c)}\\leq 0$.',
     lambda a,b,c:roots(a,b,c)[1], valid=rational_roots, sample=sample_quadratic,
     constraints=('the quadratic has real rational roots',))

bind('test/1084', 'least_quadratic_nonpositive',
     quadratic, [(1,2,-15)],
     lambda a,b,c: f'Find the least real $x$ such that $ {polynomial(a,b,c)}\\leq 0$.',
     lambda a,b,c:roots(a,b,c)[0], valid=rational_roots, sample=sample_quadratic,
     constraints=('the quadratic has real rational roots',))

bind('train/1265', 'greatest_downward_quadratic_nonnegative',
     downward_quadratic, [(-1,7,-10)],
     lambda a,b,c: f'Find the greatest real $x$ such that $ {polynomial(a,b,c)}\\geq0$.',
     lambda a,b,c:roots(a,b,c)[1], valid=rational_roots,
     sample=lambda rng:sample_quadratic(rng,-1),
     constraints=('the quadratic has real rational roots',))

bind('train/78', 'integer_count_factored_quadratic',
     {'offset1': (-100, 100), 'offset2': (-100, 100)}, [(3,-7)],
     lambda a,b: f'How many integers $n$ satisfy $(n+({a}))(n+({b}))\\leq 0$?',
     lambda a,b:abs(a-b)+1,
     reference=lambda a,b:sum((n+a)*(n+b)<=0 for n in range(-100,101)))

bind('train/255 train/1262', 'signed_integer_plus_square',
     {'sum': (2, 200000), 'sign': (-1,1)}, [(156,1),(6,-1)],
     lambda s,k: f'The sum of a {"positive" if k==1 else "negative"} integer and its square is {s}. '
                 'What is the integer?',
     lambda s,k:(k*isqrt(1+4*s)-1)//2,
     valid=lambda s,k:k!=0 and isqrt(1+4*s)**2==1+4*s,
     sample=lambda rng:(lambda n,k:(n*(n+1),k))(rng.randint(1,400),rng.choice((-1,1))),
     constraints=('sign is -1 or 1 and 1+4*sum is an odd square',),
     reference=lambda s,k:next(x for x in range(-448,448) if k*x>0 and x*x+x==s),
     adaptation='State that the positive solution is an integer, as it is throughout the selected domain.')

bind('train/656 train/961', 'consecutive_integer_product_sum',
     {'product': (2, 200000), 'sign': (-1,1)}, [(2550,-1),(506,1)],
     lambda s,k: f'The product of two consecutive {"positive" if k==1 else "negative"} integers is {s}. '
                 'Find their sum.',
     lambda s,k:k*isqrt(1+4*s),
     valid=lambda s,k:k!=0 and isqrt(1+4*s)**2==1+4*s,
     sample=lambda rng:(lambda n,k:(n*(n+1),k))(rng.randint(1,400),rng.choice((-1,1))),
     constraints=('sign is -1 or 1 and 1+4*product is an odd square',),
     reference=lambda s,k:next(x+x+1 for x in range(-448,448) if k*x>0 and x*(x+1)==s))

bind('train/105 test/87', 'unknown_linear_quadratic_coefficient',
     {'given_root': (-60, -1), 'constant': (-1000, 1000)}, [(-7,-28),(-4,-36)],
     lambda r,c: f'Given that {r} is a solution to $x^2+bx+({c})=0$, find $b$.',
     lambda r,c:Q(-r*r-c,r))

bind('train/724 test/483', 'complete_square_constant',
     {'linear': (-100, 100), 'offset': (-80, 80)}, [(-16,0),(24,16)],
     lambda b,c: f'What $k$ makes $ {polynomial(1,b,c)}+k$ the square of a binomial?',
     lambda b,c:Q(b,2)**2-c,
     valid=lambda b,c:b!=0, constraints=('linear coefficient is nonzero',))

bind('train/1068', 'complete_square_remainder',
     {'linear': (-100, 100), 'constant': (-250, 250)}, [(10,33)],
     lambda b,c: f'Write $ {polynomial(1,b,c,"y")}$ as the square of a binomial plus an integer. '
                 'Find that integer.',
     lambda b,c:c-b*b//4,
     valid=lambda b,c:b!=0 and b%2==0,
     sample=lambda rng:(2*rng.choice(tuple(range(-50,0))+tuple(range(1,51))),rng.randint(-250,250)),
     constraints=('linear coefficient is a nonzero even integer',))

bind('train/1199 test/482', 'complete_square_equation',
     {'linear': (-100, 100), 'constant': (-250, 250), 'include_shift': (0,1)},
     [(-8,8,1),(18,-9,0)],
     lambda b,c,k: f'Rewrite $ {polynomial(1,b,c)}=0$ as $(x+d)^2=e$, with integers $d,e$. '
                   f'Find {"d+e" if k else "e"}.',
     lambda b,c,k:b*b//4-c+k*b//2,
     valid=lambda b,c,k:b%2==0,
     sample=lambda rng:(2*rng.randint(-50,50),rng.randint(-250,250),rng.randint(0,1)),
     constraints=('linear coefficient is even',))

bind('test/341 train/1646', 'complete_square_leading_coefficient',
     {'linear': (-100, 100), 'constant': (1, 200), 'form': (0,1)},
     [(8,4,0),(12,9,1)],
     lambda b,c,k: f'Find nonzero $a$ such that $ax^2+({b})x+{c}' +
                   ('$ is the square of a binomial.' if k else '=0$ has exactly one real solution.'),
     lambda b,c,k:Q(b*b,4*c),
     valid=lambda b,c,k:b!=0, constraints=('linear coefficient is nonzero',))

bind('train/1393', 'single_root_positive_middle_coefficient',
     {'a': (1, 80), 'c': (1, 200)}, [(4,25)],
     lambda a,c: f'Find positive $n$ for which $ {a}x^2+nx+{c}=0$ has exactly one real solution.',
     lambda a,c:2*isqrt(a*c),
     valid=lambda a,c:isqrt(a*c)**2==a*c,
     sample=lambda rng:(lambda k,u,v:(k*u*u,k*v*v))(
         rng.randint(1,5),rng.randint(1,4),rng.randint(1,6)),
     constraints=('a*c is a perfect square',))

bind('test/334', 'radical_zero_nonzero_root',
     {'linear': (1, 100), 'quadratic': (1, 100)}, [(4,5)],
     lambda a,b: f'Find a nonzero solution to $\\sqrt{{{a}x-{b}x^2}}=0$.',
     Q)

bind('test/933', 'absolute_value_root_product',
     {'shift': (-50, 50), 'offset': (1, 60), 'rhs': (1, 60)}, [(4,10,2)],
     lambda a,b,c: f'Find the product of all real solutions to $|x-({a})|-{b}={c}$.',
     lambda a,b,c:a*a-(b+c)**2, reference=lambda a,b,c:(a+b+c)*(a-b-c))

bind('test/1069', 'inverse_fourth_power_from_quadratic',
     {'a': (1, 500), 'c': (1, 500)}, [(192,16)],
     lambda a,c: f'If $ {a}x^2-{c}=0$, find $1/x^4$.',
     lambda a,c:Q(a,c)**2)

bind('test/476', 'fourth_power_from_quadratic',
     {'a': (2, 50), 'b': (1, 49), 'shift': (1, 50), 'rhs': (1, 100)}, [(3,2,4,42)],
     lambda a,b,c,d: f'If $ {a}x^2-{b}(x^2+{c})={d}$, what is $x^4$?',
     lambda a,b,c,d:Q(d+b*c,a-b)**2,
     valid=lambda a,b,c,d:a>b, constraints=('a exceeds b',))

bind('train/210', 'minimum_affine_of_quadratic_root',
     {**quadratic, 'rhs': (-100, 100), 'slope': (1, 20), 'shift': (-20, 20)},
     [(6,5,4,3,2,1)],
     lambda a,b,c,r,m,k: f'If $ {polynomial(a,b,c,"u")}={r}$, find the smallest possible value of '
                         f'$ {m}u+({k})$.',
     lambda a,b,c,r,m,k:m*roots(a,b,c-r)[0]+k,
     valid=lambda a,b,c,r,m,k:rational_roots(a,b,c-r),
     sample=lambda rng:(lambda a,b,c,r:(a,b,c+r,r,rng.randint(1,20),rng.randint(-20,20)))(
         *sample_quadratic(rng),rng.randint(-100,100)),
     constraints=('after subtracting rhs the equation has real rational roots',))

bind('train/192 train/1303', 'quadratic_radical_coefficients',
     {**quadratic, 'sum_coefficients': (0,1)}, [(3,-7,3,1),(2,-5,-4,0)],
     lambda a,b,c,k: f'The roots of $ {polynomial(a,b,c)}=0$ have the form '
                     '$x=(m\\pm\\sqrt{n})/p$, with ' +
                     ('integers $m,n,p$, positive $p$, and ' if k else 'positive integers $m,n,p$ and ') +
                     '$\\gcd(m,n,p)=1$. Find ' +
                     ('$m+n+p$.' if k else '$n$.'),
     lambda a,b,c,k: radical_coefficients(a,b,c,k),
     valid=lambda a,b,c,k:valid_radical(a,b,c,k),
     constraints=('discriminant is positive and not a square, the reduced m,n,p are coprime, '
                  'and m is positive in the n-only version',))


def reduced_radical(a,b,c):
    delta = discriminant(a,b,c)
    common = gcd(b,2*a)
    # Removing a denominator factor requires removing its square under the radical.
    d = max(x for x in range(1,common+1) if common%x==0 and delta%(x*x)==0)
    return -b//d,delta//(d*d),2*a//d


def valid_radical(a,b,c,k):
    delta = discriminant(a,b,c)
    if delta<=0 or is_square(delta) or (not k and b>=0):
        return False
    m,n,p = reduced_radical(a,b,c)
    return gcd(gcd(m,n),p)==1


def radical_coefficients(a,b,c,k):
    m,n,p = reduced_radical(a,b,c)
    return n+k*(m+p)
