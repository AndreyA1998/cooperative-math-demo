"""Function composition and inverses; exact source-bound mathematical models."""
from fractions import Fraction as Q
from math import floor

from template_dataset.families.algebra.given_bindings import decimal, register, root, signed

BINDINGS = {}


def add(*args, **kwargs):
    register(BINDINGS, *args, **kwargs)


add(148, 'affine_composition_unknown',
    (('p_slope',2,1,30),('p_constant',-7,-50,50),('q_slope',3,1,30),
     ('argument',4,-30,30),('composition_value',7,-150,150)),
    lambda a,b,c,x,v: f'Let $p(x)={a}x{signed(b)}$ and $q(x)={c}x-b$, where $b$ is unknown. If $p(q({x}))={v}$, find $b$.',
    lambda a,b,c,x,v:c*x-Q(v-b,a))


def table_valid(x1,x2,x3,x4,x5,y1,y2,y3,y4,y5):
    xs, ys = (x1,x2,x3,x4,x5), (y1,y2,y3,y4,y5)
    return len(set(xs))==len(set(ys))==5 and x1*x5+x3 in ys


def table_render(x1,x2,x3,x4,x5,y1,y2,y3,y4,y5):
    entries = ', '.join(f'({x},{y})' for x,y in zip((x1,x2,x3,x4,x5),(y1,y2,y3,y4,y5)))
    return rf'The complete table of $(x,f(x))$ pairs is ${entries}$. Evaluate $f^{{-1}}(f^{{-1}}({y5})\times f^{{-1}}({y1})+f^{{-1}}({y3}))$.'


def table_sample(rng):
    xs = sorted(rng.sample(range(-20,21),5))
    target = xs[0]*xs[4]+xs[2]
    ys = rng.sample([n for n in range(-500,501) if n!=target],4)
    ys.insert(rng.randrange(5),target)
    return (*xs,*ys)


add(320, 'nested_inverse_table',
    tuple((f'x{i}', x, -20, 20) for i,x in enumerate((3,4,5,6,7),1))+
    tuple((f'y{i}', y, -500, 500) for i,y in enumerate((10,17,26,37,50),1)),
    table_render,
    lambda x1,x2,x3,x4,x5,y1,y2,y3,y4,y5:dict(zip((y1,y2,y3,y4,y5),(x1,x2,x3,x4,x5)))[x1*x5+x3],
    valid=table_valid, sample=table_sample,
    constraints=('x entries and y entries are each pairwise distinct', 'x1*x5+x3 is a y entry'),
    adaptation='Declare the displayed table the domain and range of f to make the inverse unambiguous.')

add(425, 'even_function_composition',
    (('quadratic_coefficient',3,-30,30),('constant',-7,-50,50),
     ('argument',4,1,40),('composition_value',9,-50,50)),
    lambda a,b,x,v:f'Let $f(x)={a}x^2{signed(b)}$ and $g(f({x}))={v}$. Find $g(f(-{x}))$.',
    lambda a,b,x,v:v,
    valid=lambda a,b,x,v:a!=0, constraints=('quadratic_coefficient is nonzero',))


def piecewise(a,b,c,x,y):
    if x>=0 and y>=0:
        return x+y
    if x<0 and y<0:
        return x-a*y
    return b*x+c*y


add(695, 'nested_piecewise_operation',
    (('negative_y_coefficient',2,1,10),('mixed_x_coefficient',3,-10,10),('mixed_y_coefficient',1,-10,10),
     ('x1',1,-20,20),('y1',-1,-20,20),('x2',-5,-20,20),('y2',-2,-20,20)),
    lambda a,b,c,x,y,u,v: rf'Let $p(x,y)=\begin{{cases}} x+y & x\ge 0,\ y\ge 0\\ x-{a}y & x<0,\ y<0\\ {b}x{signed(c)}y & \text{{otherwise}}.\end{{cases}}$ Find $p(p({x},{y}),p({u},{v}))$.',
    lambda a,b,c,x,y,u,v:piecewise(a,b,c,piecewise(a,b,c,x,y),piecewise(a,b,c,u,v)))


def hash_operation(numerator, offset, x):
    for _ in range(3):
        x = Q(numerator,10)*x+offset
    return x


def add_hash(key, start):
    add(key, 'iterated_affine_hash',
        (('slope_tenths',5,-10,15),('offset',1,-30,30),('argument',start,-300,300)),
        lambda a,b,x:rf'Let $\#N={decimal(a,1)}N{signed(b)}$. Calculate $\#(\#(\#({x})))$.',
        hash_operation,
        reference=lambda a,b,x:Q(a,10)**3*x+b*(1+Q(a,10)+Q(a,10)**2))


add_hash(698,50)
add_hash(1223,58)


def piecewise_sum(a,b,c,d,h,v):
    left,right = Q(v-b,a),Q(v-d,c)
    return (left if left<h else 0)+(right if right>=h else 0)


add(738, 'piecewise_affine_preimages',
    (('left_slope',9,1,30),('left_constant',16,-80,80),('right_slope',2,1,30),
     ('right_constant',-14,-80,80),('threshold',2,-20,20),('target',-2,-100,100)),
    lambda a,b,c,d,h,v:rf'Let $f(x)=\begin{{cases}}{a}x{signed(b)} & x<{h}\\{c}x{signed(d)} & x\ge {h}.\end{{cases}}$ Find the sum of all possible $x$ for which $f(x)={v}$.',
    piecewise_sum,
    valid=lambda a,b,c,d,h,v:v<a*h+b or v>=c*h+d,
    constraints=('at least one branch contains a preimage of target',))


add(884, 'radical_binary_operation_inverse',
    (('coefficient',2,-12,12),('left_argument',4,-20,20),('target',27,0,1000000)),
    lambda a,b,v:rf'Let $a\oslash b=(\sqrt{{{a}a+b}})^3$. If $({b})\oslash x={v}$, find $x$.',
    lambda a,b,v:root(v,3)**2-a*b,
    valid=lambda a,b,v:root(v,3)**3==v,
    sample=lambda r:(r.randint(-12,12),r.randint(-20,20),r.randint(0,100)**3),
    constraints=('target is a nonnegative perfect cube',))

add(921, 'nested_binary_average',
    (('divisor',3,1,30),('first',2,-50,50),('second',10,-50,50),('third',5,-50,50)),
    lambda d,a,b,c:rf'Define $A\star B=\frac{{A+B}}{{{d}}}$. Find $(({a})\star({b}))\star({c})$.',
    lambda d,a,b,c:Q(Q(a+b,d)+c,d),
    reference=lambda d,a,b,c:Q(a+b+d*c,d*d))


def delta_valid(a,b,c,d,e,f):
    return -12<=c*c-d<=12 and -12<=e*e-f<=12


add(964, 'powers_of_nested_delta',
    (('left_base',2,1,12),('right_base',3,1,12),('left_inner_a',4,-8,8),
     ('left_inner_b',13,-12,76),('right_inner_a',3,-8,8),('right_inner_b',5,-12,76)),
    lambda a,b,c,d,e,f:rf'Let $a\Delta b=a^2-b$. Find $( {a}^{{({c})\Delta({d})}} )\Delta( {b}^{{({e})\Delta({f})}} )$.',
    lambda a,b,c,d,e,f:Q(a)**(2*(c*c-d))-Q(b)**(e*e-f),
    valid=delta_valid,
    sample=lambda r:(r.randint(1,12),r.randint(1,12),(c:=r.randint(-8,8)),c*c-r.randint(-12,12),
                     (e:=r.randint(-8,8)),e*e-r.randint(-12,12)),
    constraints=('each inner Delta is between -12 and 12',))


def floor_sum_solution(value):
    return value-floor(value/2)


add(1299, 'floor_plus_argument',
    (('numerator',13,-1000,1000),('denominator',3,1,100)),
    lambda a,b:rf'Find $x$ such that $\lfloor x\rfloor+x=\frac{{{a}}}{{{b}}}$. Express the result as a fraction.',
    lambda a,b:floor_sum_solution(Q(a,b)),
    reference=lambda a,b:next(Q(a,b)-n for n in range(-500,501) if n<=Q(a,b)-n<n+1),
    valid=lambda a,b:floor(floor_sum_solution(Q(a,b)))==floor(Q(a,2*b)),
    constraints=('the fractional residual after subtracting 2*floor(numerator/(2*denominator)) is less than 1',))

add(1533, 'floor_plus_decimal',
    (('target_tenths',165,-2000,2000),),
    lambda t:rf'Find all $r$ such that $\lfloor r\rfloor+r={decimal(t,1)}$.',
    lambda t:floor_sum_solution(Q(t,10)),
    valid=lambda t:t%20<10,
    reference=lambda t:next(Q(t,10)-n for n in range(-100,101) if n<=Q(t,10)-n<n+1),
    constraints=('target_tenths modulo 20 is less than 10',))

add(1353, 'inverse_quadratic_binary_operation',
    (('coefficient',2,1,30),('argument',5,-20,20),('target',9,-200,200)),
    lambda m,b,v:rf'Define $a*b={m}a-b^2$. If $a*({b})={v}$, find $a$.',
    lambda m,b,v:Q(v+b*b,m))


def star_candidates(v):
    return [(a,b) for b in range(2,v.bit_length()+1) for a in range(2,root(v,b)+1)
            if a**b+a*b==v]


add(1368, 'integer_star_inverse',
    (('target',15,8,10000),),
    lambda v:rf'Let $a\star b=a^b+ab$. If $a,b$ are integers at least 2 and $a\star b={v}$, find $a+b$.',
    lambda v:sum(star_candidates(v)[0]),
    valid=lambda v:len({a+b for a,b in star_candidates(v)})==1,
    sample=lambda r:((a:=r.randint(2,20))**(b:=r.randint(2,3))+a*b,),
    constraints=('at least one pair solves the equation and every solution has the same sum',))


def piecewise_coefficients(k,positive,pv,zv,negative,nv):
    a=Q(pv-k,positive)
    if not a:
        return ()
    b=zv/a
    return a,b,nv-b*negative


def coefficients_valid(*values):
    coeffs=piecewise_coefficients(*values)
    return bool(coeffs) and all(x.denominator==1 and x>=0 for x in coeffs)


def coefficient_sample(r):
    k,p,n=r.randint(-10,10),r.randint(1,10),r.randint(-10,-1)
    a,b,c=r.randint(1,10),r.randint(0,10),r.randint(0,10)
    return k,p,a*p+k,a*b,n,b*n+c


add(1380, 'piecewise_coefficient_recovery',
    (('positive_constant',3,-10,10),('positive_argument',2,1,10),('positive_value',5,-10,110),
     ('zero_value',5,0,100),('negative_argument',-2,-10,-1),('negative_value',-10,-100,10)),
    lambda k,p,v,z,n,w:rf'Let $f(x)=\begin{{cases}}ax{signed(k)} & x>0\\ ab & x=0\\ bx+c & x<0.\end{{cases}}$ For nonnegative integers $a,b,c$, suppose $f({p})={v}$, $f(0)={z}$, and $f({n})={w}$. Find $a+b+c$.',
    lambda *args:sum(piecewise_coefficients(*args)),
    sample=coefficient_sample, valid=coefficients_valid,
    constraints=('the positive branch determines a>0 and the three coefficients are nonnegative integers',))

add(1568, 'pi_shift_floor',
    (('offset',4,-100,100),),
    lambda n:rf'The notation $[x]$ denotes the greatest integer less than or equal to $x$. Find $[\pi-({n})]$.',
    lambda n:3-n, reference=lambda n:floor(Q(22,7)-n))

add(1632, 'infinite_radical_inverse',
    (('offset',7,-40,40),('target',9,-38,65)),
    lambda a,t:rf'For $b>0$ define $a\bowtie b=a+\sqrt{{b+\sqrt{{b+\sqrt{{b+\cdots}}}}}}$. If $({a})\bowtie g={t}$, find $g$.',
    lambda a,t:(t-a)*(t-a-1),
    valid=lambda a,t:t-a>=2,
    constraints=('target - offset is at least 2',),
    adaptation='Specify b>0 so the infinite radical is the positive fixed point reached by its finite truncations.')

add(1680, 'bilinear_operation',
    (('a',-2,-30,30),('b',3,-30,30),('offset',1,-30,30)),
    lambda a,b,k:rf'Define $a\text{{ \$ }}b=a(b{signed(k)})+ab$. Find $({a})\text{{ \$ }}({b})$.',
    lambda a,b,k:a*(2*b+k), reference=lambda a,b,k:a*(b+k)+a*b)


def shifted_argument(n,d):
    return 'x' if n==0 else rf'x+\frac{{{n}}}{{{d}}}'


add(1480, 'floor_ceiling_shifted_integer',
    (('shift_numerator',0,0,200),('shift_denominator',1,1,100)),
    lambda n,d:rf'Suppose $\lceil {shifted_argument(n,d)}\rceil-\lfloor {shifted_argument(n,d)}\rfloor=0$. Find $\lceil x\rceil-x$.',
    lambda n,d:Q(n%d,d),
    reference=lambda n,d: -floor(Q(n,d))+Q(n,d),
    adaptation='Permit a rational shift in the premise, with shift zero at the source.')
