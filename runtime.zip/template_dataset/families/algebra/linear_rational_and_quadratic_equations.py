"""Linear rational and quadratic equations; exact source-bound mathematical models."""
from fractions import Fraction as F
from math import ceil, floor, isqrt

from template_dataset.families.algebra.parameter_bindings import polynomial
from template_dataset.families.algebra.source_spans import bind


def quadratic_roots(a,b,c):
    delta=b*b-4*a*c
    if delta < 0 or isqrt(delta)**2 != delta:
        return ()
    return tuple(sorted({F(-b-isqrt(delta),2*a),F(-b+isqrt(delta),2*a)}))


def build(row,index):
    def make(*args,**kwargs):
        return bind(row,*args,**kwargs)

    if index == 0:
        def solve(n,b,c):
            delta=b*b-4*c
            return 1+(delta>0) if delta>=0 else 0

        return make('vertical_asymptotes',dict(numerator=(1,150),linear=(-150,150),constant=(-5000,5000)),
                    (2,1,-6),[(r'\frac{2}{x^2+x-6}',lambda n,b,c:fr'\frac{{{n}}}{{{polynomial(1,b,c).replace(" ","")}}}')],
                    solve)
    if index in (202,1160):
        a,b,c=(5,0,-9) if index==202 else (2,-7,10)
        spacing=' ' if index==1160 else ''
        def render(a,b,c):
            den=polynomial(1,b,c)
            if not spacing:
                den=den.replace(' ','')
            return fr'\frac{{x-{a}}}{{{den}}}'

        return make('rational_function_undefined_count',dict(numerator_root=(1,150),linear=(-150,150),constant=(-5000,5000)),
                    (a,b,c),[(render(a,b,c).replace(' ','') if index==1160 else render(a,b,c),lambda *p:render(*p).replace(' ','') if index==1160 else render(*p))],
                    lambda a,b,c: (b*b>=4*c)+(b*b>4*c))
    if index == 73:
        return make('given_radical_quadratic_root',dict(quadratic=(1,150),linear_magnitude=(1,150),radicand=(1,5000)),
                    (2,13,131),[(r'\frac{13-\sqrt{131}}{4}',lambda a,b,c:fr'\frac{{{b}-\sqrt{{{c}}}}}{{{2*a}}}'),
                                ('2x^2-13x+k',lambda a,b,c:f'{a}x^2-{b}x+k')],
                    lambda a,b,c:F(b*b-c,4*a))
    if index == 88:
        def solve(a,b,c,d,e):
            return F(c+a*e,b-a*d)

        return make('two_linear_relations',dict(d_coefficient=(1,40),e_coefficient=(1,80),
                    first_offset=(1,100),second_e_coefficient=(1,40),second_offset=(1,100)),(2,17,8,2,9),
                    [('2d',lambda a,b,c,d,e:f'{a}d'),('$8$',lambda a,b,c,d,e:f'${c}$'),
                     ('17e',lambda a,b,c,d,e:f'{b}e'),('2e',lambda a,b,c,d,e:f'{d}e'),
                     ('$9$',lambda a,b,c,d,e:f'${e}$')],
                    solve,valid=lambda a,b,c,d,e:b!=a*d,
                    constraints=['The two equations have a nonzero determinant.'])
    if index in (351,1155):
        def answer(t):
            r=F(t,10)
            if index==1155:
                x=r-ceil(r/2)
                return x if ceil(x)+x==r else None
            if t%30==0:
                return r/3
            x=r-2*floor(r/3)-1
            return x if ceil(x)+floor(x)+x==r else None

        return make('rounded_parts_plus_unknown',dict(rhs_tenths=(-5000,5000)),(48 if index==351 else 155,),
                    [('4.8' if index==351 else '15.5',lambda t:f'{"-" if t<0 else ""}{abs(t)//10}.{abs(t)%10}')],
                    answer,valid=lambda t:answer(t) is not None,
                    reference=lambda t:next(F(x,10) for x in range(-5000,5001) if
                      (ceil(F(x,10))+F(x,10)+(floor(F(x,10)) if index==351 else 0))*10==t),
                    constraints=['The right side lies in the image of the specified strictly increasing ceiling/floor expression.'])
    if index == 451:
        return make('affine_composition_unknown_coefficient',dict(outer_shift=(1,100),inner_constant=(1,100),
                    input=(1,100),output=(-200,200)),(3,1,1,-3),
                    [('x - 3',lambda a,b,c,d:f'x - {a}'),('bx +1',lambda a,b,c,d:f'bx +{b}'),
                     ('q(1)',lambda a,b,c,d:f'q({c})'),('= -3',lambda a,b,c,d:f'= {d}')],
                    lambda a,b,c,d:F(d+a-b,c))
    if index == 687:
        def solve(t,b,c):
            return next(x for x in range(t,t+3) if x*x+b*x+c!=0)

        return make('domain_of_radical_quotient',dict(threshold=(1,100),linear=(-200,200),constant=(-10000,10000)),
                    (2,1,-6),[(r'\sqrt{x-2}',lambda t,b,c:fr'\sqrt{{x-{t}}}'),
                              ('x^2+x-6',lambda t,b,c:polynomial(1,b,c).replace(' ',''))],
                    solve)
    if index == 754:
        def solve(b,c):
            d=isqrt(b*b+4*c)
            t=(b+d)//2
            return t+(t*t-b*t-c<0)

        return make('quadratic_break_even',dict(linear_magnitude=(1,150),constant_magnitude=(1,10000)),
                    (8,33),[('x^2-8x-33',lambda b,c:f'x^2-{b}x-{c}'),
                                ('quantity produced.',lambda b,c:'whole-number quantity produced.')],
                    solve,reference=lambda b,c:next(x for x in range(b+c+1) if x*x-b*x>=c),
                    constraints=['Quantity produced is a nonnegative integer.'],
                    adaptation='Makes the usual whole-item interpretation of quantity produced explicit.')
    if index == 772:
        def solve(a,b,c,d,e,f):
            denominator=d*b-a*e
            return F(a*f-d*c,denominator) if denominator else None

        def valid(a,b,c,d,e,f):
            x=solve(a,b,c,d,e,f)
            return x is not None and (a*x+b)*x+c==0

        def draw(rng):
            p,q=(rng.randint(1,10) for _ in range(2))
            r,s=rng.sample(range(-15,16),2)
            return q*q,q*(r+p),r*p,q*q,q*(s+p),s*p

        return make('common_root_of_two_quadratics',dict(first_quadratic=(1,150),first_linear=(-300,300),
                    first_constant=(-300,300),second_quadratic=(1,150),second_linear=(-300,300),second_constant=(-300,300)),
                    (9,-18,-16,15,28,12),[('9x^2 - 18x - 16',lambda a,b,c,d,e,f:polynomial(a,b,c)),
                                          ('15x^2 + 28x + 12',lambda a,b,c,d,e,f:polynomial(d,e,f))],
                    solve,valid=valid,sample=draw,
                    reference=lambda a,b,c,d,e,f:next(iter(set(quadratic_roots(a,b,c)) & set(quadratic_roots(d,e,f)))),
                    constraints=['Eliminating the quadratic term gives a nonconstant linear equation and its root satisfies both quadratics.'])
    if index == 1092:
        return make('positive_linear_factor_constant',dict(linear=(-150,150),constant_magnitude=(1,10000)),
                    (18,63),[('x^2 + 18x - 63',lambda b,c:polynomial(1,b,-c))],
                    lambda b,c:F(b+isqrt(b*b+4*c),2),
                    valid=lambda b,c:isqrt(b*b+4*c)**2==b*b+4*c,
                    sample=lambda rng:factor_constant_draw(rng),
                    reference=lambda b,c:next(k for k in range(1,c+1) if k*(k-b)==c),
                    constraints=['The quadratic discriminant is a perfect square.'])
    if index == 1099:
        def choices(a,b,c,d):
            return tuple(x for x in quadratic_roots(b,c-b*d-a,a*d)
                         if x>0 and x!=d and b*(x-d)+c!=0)

        return make('nested_rational_equation',dict(outer_numerator=(1,10000),outer_offset=(1,100),
                    inner_numerator=(1,10000),inner_offset=(1,100)),(1,2,1,2),
                    [(r'\frac{1}{2+\frac{1}{x-2}}',lambda a,b,c,d:fr'\frac{{{a}}}{{{b}+\frac{{{c}}}{{x-{d}}}}}')],
                    lambda *p:choices(*p)[0],
                    valid=lambda *p:len(choices(*p))==1,sample=lambda rng:nested_rational_draw(rng),
                    constraints=['The cleared quadratic has exactly one positive rational root outside the poles; its discriminant is a square.'])


def factor_constant_draw(rng):
    a,b=(rng.randint(1,100) for _ in range(2))
    return b-a,a*b


def nested_rational_draw(rng):
    d=rng.randint(1,20)
    r=rng.choice(tuple(k for k in range(1,21) if k!=d))
    return r*r,d,(d-r)**2,d
