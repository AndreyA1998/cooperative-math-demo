"""Scalar identities; exact source-bound mathematical models."""
from fractions import Fraction as Q
from functools import partial
from math import isqrt, prod
from itertools import permutations

from template_dataset.families.algebra.parameter_bindings import register

BINDINGS = {}
bind = partial(register, BINDINGS)


bind('train/56 train/1016 test/638', 'nearby_squares',
     {'center': (10, 5000), 'offset': (1, 9)}, [(30,1), (40,1), (40,2)],
     lambda a,d: f'To calculate ${a+d}^2$, Emily adds {d*(2*a+d)} to ${a}^2$. '
                 f'What does she subtract from ${a}^2$ to calculate ${a-d}^2$?',
     lambda a,d: d*(2*a-d), reference=lambda a,d:a*a-(a-d)**2)

bind('train/503 test/452', 'expanded_binomial_square',
     {'a': (2, 500), 'b': (2, 500)}, [(19,6), (21,19)],
     lambda a,b: f'${a*a}+2({a})({b})+{b*b}=x$. Solve for $x$.',
     lambda a,b: (a+b)**2, reference=lambda a,b:a*a+2*a*b+b*b)

bind('test/472 test/678 train/582', 'difference_of_squares',
     {'smaller': (1, 5000), 'gap': (1, 500)}, [(27,16),(19,12),(99,2)],
     lambda a,d: f'How much greater than ${a}^2$ is ${a+d}^2$?',
     lambda a,d: d*(2*a+d), reference=lambda a,d:(a+d)**2-a*a,
     adaptation='Present the larger square first in the subtraction so the difference is positive.')

bind('train/1187', 'half_difference_of_squares',
     {'smaller': (1, 5000), 'gap': (1, 500)}, [(16,2)],
     lambda a,d: f'What is half the absolute difference between ${a+d}^2$ and ${a}^2$?',
     lambda a,d: Q(d*(2*a+d),2), reference=lambda a,d:Q((a+d)**2-a*a,2))

bind('train/299 test/330', 'four_square_sum',
     {'a': (2, 5000), 'b': (2, 5000), 'c': (2, 5000), 'd': (2, 5000)},
     [(1003,997,999,1001),(1002,502,298,202)],
     lambda a,b,c,d: f'Compute without a calculator: ${a}^2-{b}^2+{c}^2-{d}^2$.',
     lambda a,b,c,d: (a+b)*(a-b)+(c+d)*(c-d),
     reference=lambda a,b,c,d:a*a-b*b+c*c-d*d,
     adaptation='The positive summand in the second pair is displayed before the negative summand.')

bind('train/189 test/825', 'square_of_constant_sum',
     {'offset': (0, 40), 'complement': (1, 100)}, [(1,3),(0,5)],
     lambda a,b: square_of_sum('x' if a==0 else f'x+{a}', f'{b}-x'),
     lambda a,b: (a+b)**2,
     reference=lambda a,b:(2+a)**2+2*(2+a)*(b-2)+(b-2)**2)


def square_of_sum(u,v):
    return f'For real $x$, evaluate $({u})^2+2({u})({v})+({v})^2$.'


bind('train/1197', 'conjugate_product',
     {'square': (1, 1000000), 'offset': (1, 100)}, [(1521,1)],
     lambda s,d: f'The square of the integer $x$ is {s}. Find $(x+{d})(x-{d})$.',
     lambda s,d:s-d*d, reference=lambda s,d:(isqrt(s)+d)*(isqrt(s)-d),
     valid=lambda s,d:isqrt(s)**2==s,
     sample=lambda rng:(rng.randint(1,1000)**2,rng.randint(1,100)),
     constraints=('square is a perfect square',))

bind('train/1180', 'difference_of_squares_given_sum',
     {'sum': (3, 1500), 'difference': (1, 500)}, [(50,12)],
     lambda s,d: f'Two positive integers have sum {s} and difference {d}. '
                 'Find the positive difference between their squares.',
     lambda s,d:s*d, reference=lambda s,d:((s+d)//2)**2-((s-d)//2)**2,
     valid=lambda s,d:s>d and (s-d)%2==0,
     sample=lambda rng:(lambda a,d:(2*a+d,d))(rng.randint(1,500),rng.randint(1,500)),
     constraints=('sum exceeds difference and has the same parity',))

bind('test/205', 'symmetric_quadratic_identity',
     {'product': (1, 400000), 'square_sum': (2, 900000)}, [(24,73)],
     lambda p,s: f'Two positive numbers have product {p} and sum of squares {s}. '
                 'Find the square of their difference.',
     lambda p,s:s-2*p,
     valid=lambda p,s:s>=2*p, constraints=('square_sum is at least twice product',),
     sample=lambda rng:(lambda p,d:(p,2*p+d))(rng.randint(1,400000),rng.randint(0,100000)))

bind('train/1685', 'product_from_difference',
     {'difference': (1, 300), 'square_sum': (1, 900000)}, [(9,153)],
     lambda d,s: f'Two numbers have difference {d} and sum of squares {s}. '
                 'What is their product?',
     lambda d,s:Q(s-d*d,2),
     valid=lambda d,s:2*s>=d*d, constraints=('2*square_sum is at least difference squared',),
     sample=lambda rng:(lambda a,d:(d,a*a+(a+d)**2))(rng.randint(-500,500),rng.randint(1,300)))

bind('train/641', 'factor_and_add',
     {'x_product': (1, 800), 'y_product': (1, 800)}, [(27,54)],
     lambda a,b: f'If $x(x+y)={a}$ and $y(x+y)={b}$, what is $(x+y)^2$?',
     lambda a,b:a+b)

bind('train/1067', 'factor_by_grouping',
     {'sum': (1, 800), 'factor': (1, 200)}, [(30,5)],
     lambda a,b: f'If $ab+bc+cd+da={a}$ and $b+d={b}$, find $a+c$.',
     Q)

bind('train/1365', 'cancel_square',
     {'linear_term': (-500, 500)}, [(8,)],
     lambda a: f'If $x(x+y)=x^2+({a})$, what is $xy$?',
     lambda a:a)

bind('test/773', 'square_sum_identity',
     {'sum': (0, 400), 'square_sum': (0, 80000)}, [(4,10)],
     lambda a,b: f'If $x^2+y={a}$ and $x^4+y^2={b}$, what is $x^2y$?',
     lambda a,b:Q(a*a-b,2),
     valid=lambda a,b:2*b>=a*a,
     sample=lambda rng:(lambda x,y:(x+y,x*x+y*y))(rng.randint(0,200),rng.randint(0,200)),
     constraints=('sum is nonnegative and 2*square_sum >= sum squared so one quadratic root is nonnegative',))

bind('test/480', 'shifted_reciprocal_identity',
     {'numerator': (1, 100)}, [(1,)],
     lambda a: f'For real $p,q>{a}$, suppose \\(\\frac{{{a}}}p+\\frac{{{a}}}q=1\\). '
               f'What is $(p-{a})(q-{a})$?',
     lambda a:a*a)

bind('test/167', 'reciprocal_square',
     {'given_sum': (2, 100), 'offset': (-30, 30)}, [(7,1)],
     lambda a,b: f'If $x+1/x={a}$, evaluate $x^2+1/x^2+({b})$.',
     lambda a,b:a*a-2+b)

bind('test/506', 'power_of_reciprocal_difference',
     {'difference': (1, 30), 'power': (2, 12)}, [(3,4)],
     lambda a,n: f'A number $x$ is {a} larger than its reciprocal. Evaluate $(x-1/x)^{n}$.',
     pow)

bind('test/1116', 'scaled_product_square',
     {'given_coefficient': (1, 50), 'given_product': (-100, 100),
      'target_coefficient': (1, 100)}, [(2,12,8)],
     lambda a,b,c: f'If ${a}ab={b}$, find ${c}a^2b^2$.',
     lambda a,b,c:c*Q(b,a)**2)

bind('test/70', 'evaluate_bivariate_polynomial',
     {'x': (-20, 20), 'y': (-20, 20), 'coefficient': (1, 20), 'offset': (-50, 50)},
     [(3,9,3,8)],
     lambda x,y,a,b: f'If $(x,y)=({x},{y})$, find $y^2-{a}xy+({b})$.',
     lambda x,y,a,b:y*(y-a*x)+b, reference=lambda x,y,a,b:y*y-a*x*y+b)

bind('test/1147', 'evaluate_square_quotient',
     {'x': (-20, 20), 'y': (1, 20), 'numerator': (1, 30), 'denominator': (1, 30)},
     [(3,2,4,9)],
     lambda x,y,a,b: f'Given $x={x}$ and $y={y}$, find \\(\\frac{{{a}x^2}}{{{b}y^2}}\\).',
     lambda x,y,a,b: Q(a,b)*Q(x,y)**2,
     reference=lambda x,y,a,b: Q(a*x*x,b*y*y))

def bounded_root(value, index, limit):
    lo, hi = 1, limit
    while lo <= hi:
        mid = (lo+hi)//2
        power = mid**index
        if power == value:
            return mid
        if power < value:
            lo = mid+1
        else:
            hi = mid-1
    return None


bind('test/647', 'exact_rational_root',
     {'radicand_num': (1, 25**9), 'radicand_den': (2, 30**9), 'index': (2, 9)}, [(16,625,4)],
     lambda a,b,n: f'Express $\\left(\\frac{{{a}}}{{{b}}}\\right)^{{1/{n}}}$ as a common fraction.',
     lambda a,b,n: Q(bounded_root(a,n,25),bounded_root(b,n,30)),
     valid=lambda a,b,n:bounded_root(a,n,25) is not None and bounded_root(b,n,30) is not None,
     sample=lambda rng:(lambda a,b,n:(a**n,b**n,n))(
         rng.randint(1,25),rng.randint(2,30),rng.randint(2,9)),
     constraints=('radicand_num and radicand_den are exact index-th powers of integers up to 25 and 30',))

bind('test/149 test/519', 'square_cube_root_difference',
     {'radicand': (64, 50**6)}, [(64,),(1000000,)],
     lambda a: f'Find the positive square root of {a} minus its real cube root.',
     lambda a:isqrt(a)-bounded_root(a,3,2500),
     valid=lambda a:bounded_root(a,6,50) is not None,
     sample=lambda rng:(rng.randint(2,50)**6,),
     constraints=('radicand is an exact sixth power',),
     reference=lambda a:isqrt(a)-next(i for i in range(1,2501) if i**3==a))

bind('train/508', 'prime_power_cube_root',
     {'e2': (3, 30), 'e3': (3, 30), 'e11': (3, 30)}, [(6,3,3)],
     lambda a,b,c: f'Rewrite \\(\\sqrt[3]{{2^{{{a}}}\\cdot3^{{{b}}}\\cdot11^{{{c}}}}}\\) as an integer.',
     lambda a,b,c:2**(a//3)*3**(b//3)*11**(c//3),
     valid=lambda a,b,c:a%3==b%3==c%3==0,
     sample=lambda rng:tuple(3*rng.randint(1,10) for _ in range(3)),
     constraints=('All three given prime exponents are positive multiples of three.',))

bind('train/1110', 'extract_prime_power_radical',
     {'index': (2, 8), 'e2': (1, 24), 'e3': (1, 24)}, [(4,7,3)],
     lambda n,a,b: f'Simplify \\(\\sqrt[{n}]{{2^{{{a}}}\\cdot3^{{{b}}}}}\\) to '
                   f'\\(A\\sqrt[{n}]{{B}}\\), with positive integers $A,B$ and $B$ '
                   'as small as possible. Find $A+B$.',
     lambda n,a,b:2**(a//n)*3**(b//n)+2**(a%n)*3**(b%n))

bind('train/875', 'nearest_cube_root',
     {'radicand': (1, 100000)}, [(100,)],
     lambda a: f'Which integer is closest to the real cube root of {a}?',
     lambda a: next(k for k in range(1,50) if (2*k+1)**3 > 8*a),
     reference=lambda a: next(k for k in range(1,50) if (2*k-1)**3 < 8*a < (2*k+1)**3))
bind('train/634', 'nearest_cube_root_of_sum',
     {'a': (1, 60), 'b': (1, 60)}, [(6,8)],
     lambda a,b: f'Which integer is closest to \\(\\sqrt[3]{{{a}^3+{b}^3}}\\)?',
     lambda a,b:next(k for k in range(1,81) if (2*k+1)**3 > 8*(a**3+b**3)))

bind('train/499', 'integers_between_cube_roots',
     {'low': (0, 100000), 'gap': (1, 100000)}, [(10,190)],
     lambda a,d: f'How many whole numbers are strictly between \\(\\sqrt[3]{{{a}}}\\) '
                 f'and \\(\\sqrt[3]{{{a+d}}}\\)?',
     lambda a,d:sum(a<k**3<a+d for k in range(60)))

bind('train/962', 'inverse_radical_power',
     {'rhs': (1, 60**3)}, [(64,)],
     lambda r: f'When the square root of $x$ is cubed, the answer is {r}. Find $x$.',
     lambda r:bounded_root(r,3,60)**2,
     valid=lambda r:bounded_root(r,3,60) is not None,
     sample=lambda rng:(rng.randint(1,60)**3,),
     constraints=('rhs is a perfect cube',))
bind('test/972', 'inverse_cubic_radical',
     {'rhs': (1, 60)}, [(7,)],
     lambda r: f'Find $x$ if \\(\\sqrt[3]{{x\\sqrt{{x}}}}={r}\\).',
     lambda r:r*r)

bind('train/1496 train/1143', 'nested_square_root',
     {'offset': (1, 50), 'rhs_squared': (2, 100), 'inner_slope': (1, 30),
      'inner_shift': (-40, 40)}, [(2,9,1,0),(1,6,2,-3)],
     lambda a,b,c,d: f'Find $x$ if \\(\\sqrt{{{a}+\\sqrt{{{c}x+({d})}}}}=\\sqrt{{{b}}}\\).',
     lambda a,b,c,d:Q((b-a)**2-d,c),
     valid=lambda a,b,c,d:b>=a,
     constraints=('rhs_squared >= offset',))

bind('test/443', 'solve_square_root_sum',
     {'left_radicand': (9, 40000), 'right_radicand': (4, 10000)}, [(400,81)],
     lambda a,b: f'If \\(\\sqrt{{{a}}}=\\sqrt{{{b}}}+\\sqrt{{n}}\\), find $n$.',
     lambda a,b:(isqrt(a)-isqrt(b))**2,
     valid=lambda a,b:a>b and isqrt(a)**2==a and isqrt(b)**2==b,
     sample=lambda rng:(lambda root,gap:((root+gap)**2,root**2))(
         rng.randint(2,100),rng.randint(1,100)),
     constraints=('Both given radicands are perfect squares, and the left one is larger.',),
     reference=lambda a,b:a+b-2*isqrt(a*b))

bind('test/219', 'minimum_permutation_expression',
     {'first': (1, 100), 'gap1': (1, 50), 'gap2': (1, 50)}, [(4,1,1)],
     lambda a,d,e: f'Use {a}, {a+d} and {a+d+e} once each for $A,B,C$. '
                   'Find the least possible value of $A(B-C)$.',
     lambda a,d,e:min(-a*e,-(a+d)*(d+e),-(a+d+e)*d),
     reference=lambda a,d,e:min(x*(y-z) for x,y,z in permutations((a,a+d,a+d+e))))

bind('test/884', 'symmetric_square_resize',
     {'side': (62, 10000), 'change': (1, 60)}, [(3491,60)],
     lambda a,d: f'A {a} by {a} square has its length decreased by {d} and its width '
                 f'increased by {d}. By how much does its area change?',
     lambda a,d:d*d, reference=lambda a,d:a*a-(a-d)*(a+d))

bind('train/1006', 'five_shifted_factors',
     {'x': (-40, 60), 'first_shift': (-20, 20)}, [(2,-1)],
     lambda x,s: 'Evaluate $'+'\\cdot'.join(
         '(n)' if not j else f'(n{j:+})' for j in range(s,s+5)) + f'$ at $n={x}$.',
     lambda x,s:prod(range(x+s,x+s+5)))
