"""Function iterations and identities; exact source-bound mathematical models."""
from fractions import Fraction as F
from math import gcd, isqrt

from template_dataset.families.algebra.source_spans import bind
from template_dataset.families.algebra.coefficient_matching_and_factorization import prime


def build(row,index):
    def make(*args,**kwargs):
        return bind(row,*args,**kwargs)

    if index == 58:
        def values(x,u,y,v,z,w,q):
            inverse={u:x,v:y,w:z}
            return inverse.get(inverse.get(q))

        def draw(rng):
            x,u,y,z,q=rng.sample(range(-30,31),5)
            return x,u,y,q,z,y,q

        return make('nested_inverse_table',dict(first_argument=(-50,50),first_value=(-50,50),
                    second_argument=(-50,50),second_value=(-50,50),third_argument=(-50,50),
                    third_value=(-50,50),query=(-50,50)),(1,2,4,3,7,4,3),
                    [('f(1)=2',lambda x,u,y,v,z,w,q:f'f({x})={u}'),
                     ('f(4)=3',lambda x,u,y,v,z,w,q:f'f({y})={v}'),
                     ('f(7)=4',lambda x,u,y,v,z,w,q:f'f({z})={w}'),
                     (r'f^{-1}(3)',lambda x,u,y,v,z,w,q:fr'f^{{-1}}({q})')],
                    values,valid=lambda x,u,y,v,z,w,q:len({x,y,z})==len({u,v,w})==3 and values(x,u,y,v,z,w,q) is not None,
                    sample=draw,
                    constraints=['The three inputs and outputs are separately distinct, and both inverse lookups are determined by the table.'])
    if index == 159:
        def f(n,c):
            return n*n+n+c

        def draw(rng):
            c=rng.choice((5,11,17,41))
            hi=rng.randint(2,c-2)
            x,y=rng.sample(range(hi+1),2)
            return c,hi,x,y

        return make('difference_of_prime_generating_values',dict(constant=(2,200),upper=(2,50),first_input=(0,50),second_input=(0,50)),
                    (17,15,10,9), [('n + 17',lambda c,h,x,y:f'n + {c}'),
                                    (r'\leq 15',lambda c,h,x,y:fr'\leq {h}'),
                                    ('f (10)-f (9)',lambda c,h,x,y:f'f ({x})-f ({y})')],
                    lambda c,h,x,y:(x-y)*(x+y+1),
                    valid=lambda c,h,x,y:x!=y and max(x,y)<=h and all(prime(f(n,c)) for n in range(h+1)),
                    sample=draw,reference=lambda c,h,x,y:f(x,c)-f(y,c),
                    constraints=['The two inputs are distinct integers in the displayed interval and every integer in that interval gives a prime.'])
    if index in (510,1083):
        def solve(odd,linear,even,x,count):
            for _ in range(count):
                x=x*x+odd if x%2 else x*x-linear*x+even
            return x

        def additive(n):
            return f' + {n}' if n>0 else f' - {-n}' if n<0 else ''

        return make('parity_piecewise_iteration',dict(odd_constant=(-8,8),even_linear_magnitude=(1,8),
                    even_constant=(-8,8),argument=(-8,8),iterations=(2,6)),
                    (1,3,1,2,6) if index==510 else (0,4,-1,4,5),
                    [('n^2 + 1 &' if index==510 else 'n^2 &',lambda o,l,e,x,k:f'n^2{additive(o)} &'),
                     ('n^2 - 3n + 1' if index==510 else 'n^2 - 4n - 1',
                      lambda o,l,e,x,k:f'n^2 - {l}n{additive(e)}'),
                     ('f(f(f(f(f(f(2))))))' if index==510 else 'f(f(f(f(f(4)))))',
                      lambda o,l,e,x,k:'f('*k+str(x)+')'*k)],
                    solve)
    if index == 558:
        def terms(*p):
            return '+'.join(str(n) for n in p)

        return make('cancelling_fractions_of_sums',dict(first=(1,40),second=(1,40),third=(1,40),
                    fourth=(1,40),fifth=(1,40),sixth=(1,40),seventh=(1,40),eighth=(1,40),ninth=(1,40)),
                    (7,8,9,2,3,4,6,9,12), [('7+8+9',lambda *p:terms(*p[:3])),
                                             ('2+3+4',lambda *p:terms(*p[3:6])),
                                             ('6+9+12',lambda *p:terms(*p[6:])),
                                             ('9+8+7',lambda *p:terms(*reversed(p[:3])))],
                    lambda *p:F(sum(p[6:]),sum(p[3:6])),
                    reference=lambda *p:F(sum(p[:3]),sum(p[3:6]))*F(sum(p[6:]),sum(p[:3])))
    if index == 747:
        return make('mean_squared_and_cubed_root',dict(first=(-100,100),second=(-100,100),third=(-100,100),radicand=(-1000,1000)),
                    (13,-16,6,8),[('$13$',lambda a,b,c,d:f'${a}$'),('$-16$',lambda a,b,c,d:f'${b}$'),
                                   ('$6$',lambda a,b,c,d:f'${c}$'),('$8$',lambda a,b,c,d:f'${d}$')],
                    lambda a,b,c,d:F((a+b+c)**2,9)+d)
    if index == 946:
        return make('monomial_product_cancellation',dict(first=(1,100),second=(1,100),third=(1,100),fourth=(1,100)),
                    (12,14,35,3),[(r'\frac{12}',lambda a,b,c,d:fr'\frac{{{a}}}'),
                                  ('14x',lambda a,b,c,d:f'{b}x'),
                                  (r'\frac{35}{3x}',lambda a,b,c,d:fr'\frac{{{c}}}{{{d}x}}')],
                    lambda a,b,c,d:F(a*c,b*d),
                    reference=lambda a,b,c,d:F(a,9)*F(3**4,b*3)*F(c,d*3))
    if index == 964:
        from template_dataset.families.construction import choice
        def solve(a,b,c,n):
            if n==r'\pi':
                return b if c>=4 else None
            x=int(n)
            if x<0:
                return -x*x-a
            if x<c:
                return b
            root=isqrt(x)
            return root if root*root==x else None

        return make('piecewise_sqrt_branch',dict(negative_constant=(1,50),middle_constant=(-50,50),
                    threshold=(1,50),argument=choice([r'\pi',*(str(i) for i in range(-50,101))])),
                    (1,2,4,r'\pi'),[('-x^2 - 1',lambda a,b,c,n:f'-x^2 - {a}'),
                                      ('2&',lambda a,b,c,n:f'{b}&'),('x< 4',lambda a,b,c,n:f'x< {c}'),
                                      (r'x \ge 4',lambda a,b,c,n:fr'x \ge {c}'),
                                      (r'f(\pi)',lambda a,b,c,n:f'f({n})')],
                    solve,valid=lambda *p:solve(*p) is not None,
                    constraints=['The selected branch produces a rational answer. The comparison with π uses 3 < π < 4.'])
    if index == 1002:
        def expression(k,n):
            return str(k)+''.join(('+' if i%2 else '-')+str(k*i) for i in range(2,n+1))

        return make('ratio_of_alternating_runs',dict(numerator_scale=(1,30),denominator_scale=(1,30),terms=(2,25)),
                    (2,3,7), [('2-4+6-8+10-12+14',lambda a,b,n:expression(a,n)),
                              ('3-6+9-12+15-18+21',lambda a,b,n:expression(b,n))],
                    lambda a,b,n:F(a,b),
                    reference=lambda a,b,n:F(sum((-1)**(i+1)*a*i for i in range(1,n+1)),
                                               sum((-1)**(i+1)*b*i for i in range(1,n+1))))


def symbols(row):
    triangle=r'\triangle'
    diamond=r'\diamond'

    def choices(a,b,c,upper):
        results=[]
        for d in range(1,upper+1):
            n,r=divmod(b*d,a)
            club=c*n-d
            square=club-n
            if r==0 and 1<=min(n,club,square) and max(n,club,square)<=upper and len({d,n,club,square})==4:
                results.append(square)
        return results

    feasible=[]
    for a in range(2,9):
        for b in range(2,16):
            common=gcd(a,b)
            triangle_value,diamond_value=b//common,a//common
            for c in range(2,9):
                club=c*triangle_value-diamond_value
                square=club-triangle_value
                values={triangle_value,diamond_value,club,square}
                lo,hi=max(5,max(values)),min(40,2*max(values)-1)
                if len(values)==4 and min(values)>0 and lo<=hi:
                    feasible.append((a,b,c,lo,hi))

    def draw(rng):
        a,b,c,lo,hi=rng.choice(feasible)
        return a,b,c,rng.randint(lo,hi)

    return bind(row,'symbol_addition_system',dict(second_triangle_count=(2,8),diamond_count=(2,15),
                third_triangle_count=(2,8),maximum=(5,40)),(2,5,2,9),
                [('1 to 9',lambda a,b,c,u:f'1 to {u}'),
                 (' + '.join((triangle,)*2),lambda a,b,c,u:' + '.join((triangle,)*a)),
                 (diamond+' +'+ ' + '.join((diamond,)*4),lambda a,b,c,u:diamond+' +'+ ' + '.join((diamond,)*(b-1))),
                 (' + '.join((triangle,)*2),lambda a,b,c,u:' + '.join((triangle,)*c))],
                lambda *p:choices(*p)[0],valid=lambda *p:len(choices(*p))==1,sample=draw,
                constraints=['Exactly one choice of diamond gives distinct integer symbols within the given bounds.'])


def rational_powers(row):
    def solve(a,b,c,d,e,f,p,q,r,s,t):
        return len({F(1,a**(15*p)),F(1,b**(15*q)),F(1,c**(5*r)),F(d**15,e**(15*s)),F(1,f**(3*t))})

    def draw(rng):
        b=rng.randint(2,6)
        p,q,r,s,t=(rng.randint(1,4) for _ in range(5))
        return b,b*b,b**3,b*b,b**4,b**5,p,q,r,s,t

    return bind(row,'count_distinct_rational_powers',
                dict(first_base=(2,36),second_base=(2,36),third_base=(2,216),multiplier=(1,36),
                     fourth_base=(2,1296),fifth_base=(2,7776),first_exponent_magnitude=(1,8),
                     second_exponent_magnitude=(1,8),third_numerator=(1,8),fourth_exponent_magnitude=(1,8),
                     fifth_numerator=(1,8)),
                (3,9,27,9,81,243,2,2,2,1,4),
                [(r'3^{-2}, 9^{-2}, 27^{-\frac{2}{3}}, 9\cdot81^{-1}, 243^{-\frac{4}{5}}',
                  lambda a,b,c,d,e,f,p,q,r,s,t:
                  fr'{a}^{{-{p}}}, {b}^{{-{q}}}, {c}^{{-\frac{{{r}}}{{3}}}}, {d}\cdot{e}^{{-{s}}}, {f}^{{-\frac{{{t}}}{{5}}}}')],
                solve,sample=draw)
