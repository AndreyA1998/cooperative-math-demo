"""Source spans; exact source-bound mathematical models."""
from template_dataset.families.construction import integer, template


def bind(row, family, domains, original, fragments, solve, *, reference=None,
         valid=None, sample=None, constraints=(), adaptation=''):
    names = tuple(domains)
    original = dict(zip(names, original))
    source = row['problem']
    spans = []
    offset = 0
    for literal, render in fragments:
        start = source.index(literal, offset)
        offset = start + len(literal)
        spans.append((start, offset, render))

    def unpack(function):
        return lambda p: function(*(p[name] for name in names))

    def render(p):
        result = []
        offset = 0
        for start, end, value in spans:
            result.extend((source[offset:start], str(unpack(value)(p))))
            offset = end
        return ''.join(result) + source[offset:]

    options = {'constraints': constraints, 'adaptation': adaptation}
    if valid:
        options['valid'] = unpack(valid)
    if sample:
        options['sample'] = lambda rng: dict(zip(names, sample(rng)))
    return template(
        'round3_algebra_test_' + family,
        {key: integer(*bounds) if isinstance(bounds, tuple) else bounds
         for key, bounds in domains.items()},
        original, render, unpack(solve),
        reference=unpack(reference) if reference else None, **options,
    )
