"""Inverse congruences; exact source-bound mathematical models."""

from template_dataset.families.discrete.exact_arithmetic import binder

TRAIN, train = binder('number_theory/train')

_FIELDS = dict(c=(1, 1, 20), r=(1, 1, 6))


def _power(c, r):
    return c**r


train(
    7, 'scaled_inverse_product', _FIELDS,
    'Let c = {c} and r = {r}. Let n be an integer greater than c^r. Let a and b be '
    'invertible integers modulo n such that a ≡ c·b⁻¹ (mod n). '
    'What is the remainder of a^r·b^r upon division by n?',
    _power,
    constraints=['The symbolic modulus n exceeds c^r and both a and b are invertible modulo n.'],
    adaptation='Scales the inverse congruence by c and raises both factors to power r. '
               'The modulus stays symbolic with n > c^r. Setting c = r = 1 recovers the source.',
)
train(
    239, 'scaled_self_inverse_power', _FIELDS,
    'Let c = {c} and r = {r}. Let n be an integer greater than c^r. Let a be an '
    'invertible integer modulo n such that a ≡ c·a⁻¹ (mod n). '
    'What is the remainder of a^(2r) upon division by n?',
    _power,
    constraints=['The symbolic modulus n exceeds c^r and a is invertible modulo n.'],
    adaptation='Scales the self-inverse congruence by c and asks for the power 2r. '
               'The modulus stays symbolic with n > c^r. Setting c = r = 1 recovers the source.',
)
