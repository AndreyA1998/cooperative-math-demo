"""Probability and combinatorial models; exact source-bound mathematical models."""

from calendar import isleap, leapdays, weekday
from fractions import Fraction
from functools import lru_cache
from itertools import combinations, combinations_with_replacement, product
from math import ceil, comb, factorial, isqrt, prod

from template_dataset.families.construction import choice, integers
from template_dataset.families.discrete.exact_arithmetic import binder, ceildiv, choose, digits, one, singleton

TRAIN, train = binder('counting_and_probability/train')
TEST, test = binder('counting_and_probability/test')


def pascal_rows(limit):
    for row in range(4, (1+isqrt(1+8*limit))//2+1):
        for col in range(2, row//2+1):
            n = comb(row, col)
            if n > limit:
                break
            yield row, n


def trace(a, power):
    previous, current = 2, 2*a
    for _ in range(1, power):
        previous, current = current, 2*a*current-previous
    return current


def factorial_product(a, b):
    value = factorial(a)*factorial(b)
    return [n for n in range(1, a+b+1) if factorial(n) == value]


def stack_counts(height, thicknesses):
    counts = [0]*(height+1)
    counts[0] = 1
    for h in range(1, height+1):
        for t in thicknesses:
            if t <= h:
                counts[h] |= counts[h-t] << 1
    return counts[height]


def sample_stack(rng):
    low = rng.randint(25, 200)
    thicknesses = [low+rng.randint(0, low//12) for _ in range(4)]
    return dict(thicknesses=thicknesses,
                height=sum(rng.choice(thicknesses) for _ in range(rng.randint(2, 9))))


def factorial_difference(delta, divisor):
    x = delta
    while factorial(x)-factorial(x-delta) < divisor:
        x += 1
    return [x] if factorial(x)-factorial(x-delta) == divisor else []


def nearest_probability(per_thousand, at_bats, places):
    p = Fraction(per_thousand, 1000)**at_bats
    scale = 10**places
    return Fraction((2*p.numerator*scale+p.denominator)//(2*p.denominator), scale)


def valid_tournament(scores):
    n = len(scores)+1
    complete = sorted([*scores, comb(n, 2)-sum(scores)])
    return all(sum(complete[:k]) >= comb(k, 2) for k in range(1, n+1))


def sample_scores(rng):
    scores = [0]*rng.randint(4, 9)
    for pair in combinations(range(len(scores)), 2):
        scores[rng.choice(pair)] += 1
    return dict(scores=scores[:-1])


def coin_win(first, second, heads):
    if heads == 50:
        # For fair coins, H2 + T1 is binomial with first+second trials.
        if second == first+1:
            return Fraction(1, 2)
        return Fraction(sum(comb(first+second, k) for k in range(first+1,first+second+1)),
                        2**(first+second))
    count = sum(comb(first,a)*comb(second,b)*heads**(a+b)*(100-heads)**(first+second-a-b)
                for a in range(first+1) for b in range(a+1,second+1))
    return Fraction(count, 100**(first+second))


def valid_distances(distances):
    distances = dict(zip(combinations('ABCD',2),distances))
    for a,b,c in combinations('ABCD',3):
        sides = sorted((distances[a,b],distances[a,c],distances[b,c]))
        if sides[0]+sides[1] < sides[2]:
            return False
    return True


def max_plate_growth(first,second,third,additions):
    counts = [first,second,third]
    for _ in range(additions):
        i = counts.index(min(counts))
        counts[i] += 1
    return prod(counts)-first*second*third


train(5, 'exact_budget_max_items', dict(budget=(50,22,120), jig=(2,2,9), jog=(7,3,20)),
      'Jags cost 1 dollar each, jigs {jig} dollars, and jogs {jog} dollars. What is the greatest '
      'number of jogs one can buy spending exactly {budget} dollars and buying at least one of each?',
      lambda budget,jig,jog: (budget-1-jig)//jog,
      valid=lambda budget,jig,jog: budget >= 1+jig+jog,
      constraints=['The budget covers one unit of each item.'])
train(62, 'mixed_plate_duplicate', dict(letters=(26,2,40), digits=(10,2,30)),
      'A three-symbol plate starts with a letter and ends with a digit. The middle is either. '
      'There are {letters} letter symbols and {digits} disjoint digit symbols. How many plates '
      'have a repeated symbol?',
      lambda letters,digits: 2*letters*digits,
      reference=lambda letters,digits: sum(m in (a,b) for a in range(letters)
              for b in range(letters,letters+digits) for m in range(letters+digits)))
train(64, 'calendar_day_count', dict(start=(2001,1800,2210), end=(2004,1801,2240)),
      'In the Gregorian calendar, how many days occur from January 1 of {start} to December 31 of {end}, inclusive?',
      lambda start,end: 365*(end-start+1)+leapdays(start,end+1),
      valid=lambda start,end: start<=end, constraints=['The years are in chronological order.'],
      reference=lambda start,end: sum(365+isleap(y) for y in range(start,end+1)))
train(112, 'inverse_polygon_diagonals', dict(excess=(0,0,207)),
      'A regular polygon has {excess} more diagonals than sides. How many sides does it have?',
      lambda excess: (5+isqrt(25+8*excess))//2,
      valid=lambda excess: isqrt(25+8*excess)**2==25+8*excess,
      sample=lambda rng: (lambda n: dict(excess=n*(n-5)//2))(rng.randint(5,23)),
      constraints=['The discriminant 25 + 8 times the excess is a perfect square.'],
      reference=lambda excess: next(n for n in range(3,24) if n*(n-5)//2==excess))
train(168, 'pascal_distinct_value_rank', dict(width=(4,2,5), rank=(2,1,30)),
      'What is the {rank}-th smallest distinct {width}-digit value in Pascal’s triangle?',
      lambda width,rank: 10**(width-1)+rank-1,
      adaptation='Ranks distinct values. Every positive integer occurs as the entry in column one.')
train(185, 'quadratic_unit_rounding', dict(a=(2,2,12), power=(4,1,12)),
      lambda a,power: f'What is the nearest integer to ({a} + √{a*a-1})^{power}?',
      trace)
train(201, 'digit_difference_count', dict(base=(10,3,16), gap=(1,1,6)),
      'In base {base}, how many two-digit numbers have a leading digit at least {gap} greater '
      'than their units digit? Give the count in decimal.',
      lambda base,gap: (base-gap)*(base-gap+1)//2,
      valid=lambda base,gap: gap<base, constraints=['The minimum gap is below the radix.'],
      reference=lambda base,gap: sum(a-b>=gap for a in range(1,base) for b in range(base)),
      adaptation='Adds a minimum difference, equal to one in the source.')
train(221, 'exhausted_initials_probability', dict(letters=(26,5,40), vowels=(6,2,15)),
      'An alphabet has {letters} letters, including {vowels} vowels. In a class of {letters} students '
      'every student has matching first and last initials, and no two students have the same initials. '
      'What is the probability a uniformly chosen student has vowel initials?',
      lambda letters,vowels: Fraction(vowels,letters), valid=lambda letters,vowels: vowels<letters,
      constraints=['The alphabet contains vowels and consonants.'])
train(253, 'uniform_city_pair_distance_probability',
      dict(distances=([6300,6609,5944,11535,5989,7240],integers(6,4500,12000)),
           threshold=(7000,4500,12000)),
      lambda distances,threshold: 'Four cities A, B, C, D have these pairwise distances in miles: '+
      ', '.join(f'{a}{b} = {d}' for (a,b),d in zip(combinations('ABCD',2),distances))+
      f'. Choose a uniformly random unordered pair of distinct cities. What is the probability its '
      f'distance is strictly less than {threshold} miles?',
      lambda distances,threshold: Fraction(sum(d<threshold for d in distances),6),
      valid=lambda distances,threshold: valid_distances(distances),
      constraints=['Every triangle in the distance table satisfies the triangle inequality.'],
      adaptation='Uses neutral labels for the cities and makes the uniform pair selection explicit.')
train(255, 'distinguishable_arrangements', dict(counts=([1,3,2],integers(3,1,6))),
      lambda counts: 'How many orders can be made from labeled letter tokens '+
      ', '.join(f'{chr(65+i)}_{j+1}' for i,c in enumerate(counts) for j in range(c))+
      ' when tokens with different labels are distinct?',
      lambda counts: factorial(sum(counts)))
train(455, 'inverse_factorial_product', dict(a=(5,1,120), b=(3,2,5)),
      'A positive integer n satisfies {a}! × {b}! = n!. What is n?',
      one(factorial_product), valid=singleton(factorial_product),
      sample=lambda rng: (lambda b: dict(a=factorial(b)-1,b=b))(rng.randint(2,5)),
      constraints=['The displayed product is a factorial.'])
train(458, 'pascal_value_row_count', dict(value=(43,4,1000)),
      'How many distinct rows of Pascal’s triangle contain {value}?',
      lambda value: 1+len({row for row,n in pascal_rows(value) if n==value}),
      sample=lambda rng: dict(value=rng.choice([6,10,15,20,21,35,36,43,56,70,120])))
train(541, 'maximum_additional_plate_capacity',
      dict(first=(5,2,12),second=(3,2,12),third=(4,2,12),additions=(2,1,12)),
      'Three positions of a license plate have {first}, {second}, and {third} choices respectively. '
      'Distribute {additions} new distinct letters among these three sets, assigning each to exactly '
      'one set. What is the greatest number of additional plates possible?',
      max_plate_growth,
      reference=lambda first,second,third,additions: max((first+a)*(second+b)*(third+additions-a-b)
              for a in range(additions+1) for b in range(additions-a+1))-first*second*third)
train(621, 'square_of_radical_factorials', dict(a=(4,2,12),b=(3,2,12)),
      'What is (√({a}! × {b}!))²?', lambda a,b: factorial(a)*factorial(b))
train(660, 'unique_coin_stack_length', dict(height=(1400,30,2200), thicknesses=([155,195,135,175],integers(4,20,250))),
      lambda height,thicknesses: 'Four types of coin have thicknesses '+
      ', '.join(f'{t//100}.{t%100:02d}' for t in thicknesses)+
      f' mm. A stack of these coins is exactly {height//100}.{height%100:02d} mm tall. How many coins are in the stack?',
      lambda height,thicknesses: stack_counts(height,thicknesses).bit_length()-1,
      valid=lambda height,thicknesses: bin(stack_counts(height,thicknesses)).count("1")==1,
      sample=sample_stack, constraints=['At least one stack exists and all stacks have the same length.'],
      adaptation='Uses generic coin types to permit different physical thicknesses.')
train(662, 'three_digit_average', dict(base=(10,3,16), offset=(0,-3,3)),
      'How many three-digit base-{base} numbers have middle digit equal to {offset} plus the '
      'average of the first and last digits? Give the count in decimal.',
      lambda base,offset: sum((a+c)%2==0 and 0<=(a+c)//2+offset<base
                for a in range(1,base) for c in range(base)),
      reference=lambda base,offset: sum(2*(b-offset)==a+c for a,b,c in
                         product(range(1,base),range(base),range(base))),
      adaptation='Adds an offset to the middle-digit average, zero in the source.')
train(671, 'weighted_die_expectation', dict(sides=(6,3,15),face=(6,1,15),percent=(50,5,90)),
      'A die has faces 1 through {sides}. Face {face} occurs with probability {percent}%. The other '
      'faces are equally likely to one another. What is the expected face value?',
      lambda sides,face,percent: Fraction(percent*face,100)+
      Fraction((100-percent)*(sides*(sides+1)//2-face),100*(sides-1)),
      valid=lambda sides,face,percent: face<=sides, constraints=['The distinguished face is on the die.'])
train(697, 'inverse_factorial_difference', dict(delta=(3,1,6),divisor=(23,1,39916800)),
      'For an integer x ≥ {delta}, solve (x! − (x − {delta})!) / {divisor} = 1.',
      one(factorial_difference), valid=singleton(factorial_difference),
      sample=lambda rng: (lambda d,x: dict(delta=d,divisor=factorial(x)-factorial(x-d)))(
          rng.randint(1,6),rng.randint(7,10)),
      constraints=['The factorial difference attains the given positive value.'])
train(717, 'first_nonpalindromic_power', dict(base=(11,2,30),initial=(1,0,8)),
      'What is the smallest nonpalindromic decimal integer that is a power of {base} with exponent at least {initial}?',
      lambda base,initial: next(base**i for i in range(initial,13)
              if digits(base**i)!=digits(base**i)[::-1]),
      valid=lambda base,initial: any(digits(base**i)!=digits(base**i)[::-1] for i in range(initial,13)),
      constraints=['A nonpalindromic power exists at an exponent no greater than 12.'],
      adaptation='Makes the lower exponent bound explicit.')
train(751, 'periodic_leap_year_count', dict(years=(150,10,300),period=(4,2,14)),
      'A calendar has leap years every {period} years. What is the maximum possible number of leap years '
      'in {years} consecutive years?',
      lambda years,period: ceildiv(years,period),
      reference=lambda years,period: max(sum(i%period==offset for i in range(years)) for offset in range(period)))
train(754, 'independent_coin_next_flip', dict(streak=(5,1,25),heads=(50,15,85)),
      'A coin is tossed independently each time with probability {heads}% of heads. The first {streak} '
      'tosses were heads. What is the probability the next toss is a tail?',
      lambda streak,heads: Fraction(100-heads,100),
      adaptation='Allows bias and states independence explicitly.')

test(34, 'interleaved_progressions', dict(start=(6,1,20),step=(4,2,15),end=(98,60,130)),
     'An increasing list contains every integer from {start} through {end} inclusive congruent '
     'to either {start} or {start}+1 modulo {step}. How many terms does it have?',
     lambda start,step,end: 2+(end-start)//step+(end-start-1)//step,
     reference=lambda start,step,end: sum((n-start)%step<2 for n in range(start,end+1)))
test(39, 'minimum_menu_options', dict(desserts=(3,1,10),ratio=(2,1,5),year=(2003,1900,2200)),
     'A restaurant offers {desserts} desserts and {ratio} times as many appetizers as main courses. '
     'Every dinner uses one of each. What is the least number of main courses needed for a different '
     'dinner on every date of Gregorian year {year}?',
     lambda desserts,ratio,year: 1+isqrt((364+isleap(year))//(desserts*ratio)),
     reference=lambda desserts,ratio,year: next(n for n in range(1,367)
         if n*n*desserts*ratio>=365+isleap(year)))
test(62, 'linear_factorial_equation', dict(left=(2,1,7),right=(3,2,12),plain=(6,3,72)),
     'For a positive integer n, solve {left}(n+1)! + {plain}n! = {right}(n+1)!.',
     lambda left,right,plain: plain//(right-left)-1,
     valid=lambda left,right,plain: right>left and plain%(right-left)==0 and plain>right-left,
     sample=lambda rng: (lambda a,d,n: dict(left=a,right=a+d,plain=d*(n+1)))(
         rng.randint(1,6),rng.randint(1,5),rng.randint(2,12)),
     constraints=['The divided linear equation has a positive integral solution.'])
test(138, 'count_below_multiple_of_pi', dict(scale=(100,1,10000)),
     'How many positive integers are strictly less than {scale}π?',
     lambda scale: scale*3141592653589793//10**15,
     valid=lambda scale: scale*3141592653589793//10**15==scale*3141592653589794//10**15,
     constraints=['The products of the rational lower and upper bounds on π have equal floors.'])
test(179, 'complement_percentage_population', dict(total=(130,25,500),percent=(60,5,95)),
     'An orchestra has {total} members. Exactly {percent}% play string instruments. How many do not play strings?',
     lambda total,percent: total*(100-percent)//100,
     valid=lambda total,percent: total*percent%100==0,
     sample=lambda rng: dict(total=rng.randint(5,25)*20,percent=rng.randint(1,19)*5),
     constraints=['The percentage yields an integer count.'])
test(180, 'rounded_all_hits_probability', dict(per_thousand=(323,100,950),at_bats=(3,2,9),places=(2,2,5)),
     'A player gets a hit in each at-bat independently with probability {per_thousand}/1000. '
     'Find the probability of getting hits in all {at_bats} at-bats, rounded to {places} decimal places '
     'with exact halves rounded upward.',
     nearest_probability, adaptation='States independence and the tie rule for rounding.')
test(206, 'reserved_row_seats', dict(seats=(33,15,60),first=(12,1,30),last=(22,8,50)),
     'An amphitheater has {seats} seats per row. Rows {first} through {last}, inclusive, are reserved '
     'for a club. How many seats are reserved?',
     lambda seats,first,last: seats*(last-first+1), valid=lambda seats,first,last: first<=last,
     constraints=['The row bounds are ordered.'])
test(210, 'palindrome_interval_multiple', dict(lower=(10000,10000,45000),upper=(70000,50000,99000),divisor=(2,2,13)),
     'How many decimal palindromes are strictly between {lower} and {upper} and divisible by {divisor}?',
     lambda lower,upper,divisor: sum(lower<n<upper and n%divisor==0 for n in
         (int(str(i)+str(i)[-2::-1]) for i in range(100,1000))))
test(236, 'visible_die_face_product', dict(faces=(6,4,12),divisor=(6,2,100)),
     'A die has faces numbered 1 through {faces}. Exactly one face, chosen uniformly, is hidden. '
     'What is the probability that the product of all visible face numbers is divisible by {divisor}?',
     lambda faces,divisor: Fraction(sum(factorial(faces)//h%divisor==0 for h in range(1,faces+1)),faces),
     reference=lambda faces,divisor: Fraction(sum(prod(i for i in range(1,faces+1) if i!=h)%divisor==0
                                           for h in range(1,faces+1)),faces),
     adaptation='Uses one uniformly hidden face for a variable number of faces.')
test(240, 'integer_count_between_rational_powers', dict(num=(17,5,32),den=(3,2,8),power=(2,2,4)),
     'How many integers are strictly between {num}/{den} and ({num}/{den})^{power}?',
     lambda num,den,power: ceil(Fraction(num,den)**power)-1-num//den,
     valid=lambda num,den,power: num>den, constraints=['The rational endpoint exceeds one.'])
test(251, 'independent_quiz_pattern',
     dict(pattern=('TFTFT',choice(['TFTFT','TTFT','FFTFFT','TTTT','FT','TFTFF','FFFFFF','TTTFF'])),heads=(50,20,80)),
     'Each question on a true-false quiz is chosen independently. The probability its answer is T is {heads}%. '
     'What is the probability the full answer sequence is {pattern}?',
     lambda pattern,heads: Fraction(heads,100)**pattern.count('T')*Fraction(100-heads,100)**pattern.count('F'),
     adaptation='Allows a biased coin.')
test(271, 'single_parenthesized_expression_count', dict(a=(8,1,15),b=(4,1,15),c=(6,1,15),d=(2,1,15)),
     'How many distinct rational values can be obtained from {a} + {b} × {c} ÷ {d} by placing one '
     'pair of parentheses around consecutive operands and the intervening operations?',
     lambda a,b,c,d: len({a+Fraction(b*c,d),Fraction((a+b)*c,d),Fraction(a+b*c,d)}))
test(316, 'hypergeometric_rps_sweep', dict(paper=(5,1,14),scissors=(3,1,14),draw=(3,1,12)),
     'Matt always plays Rock. Ryan has {paper} Paper and {scissors} Scissors cards. Ryan draws {draw} '
     'cards uniformly without replacement. What is the probability every draw beats Rock, given Paper '
     'beats Rock and Rock beats Scissors?',
     lambda paper,scissors,draw: Fraction(comb(paper,draw),comb(paper+scissors,draw)),
     valid=lambda paper,scissors,draw: draw<=paper+scissors, constraints=['There are enough cards to draw.'],
     reference=lambda paper,scissors,draw: prod(Fraction(paper-i,paper+scissors-i)
          for i in range(draw)) if draw<=paper else 0)
test(330, 'single_repeated_ball_color', dict(balls=(4,3,22),colors=(3,2,10)),
     'A bag contains {balls} balls in exactly {colors} colors. At most one color has more than one ball. '
     'What is the probability two balls drawn uniformly without replacement have the same color?',
     lambda balls,colors: Fraction(comb(balls-colors+1,2),comb(balls,2)),
     valid=lambda balls,colors: colors<=balls, constraints=['Every color is represented.'],
     adaptation='States the single repeated color condition, implied by the original counts.')
test(350, 'strict_floor_decimal_power', dict(tenths=(103,21,220),power=(3,2,8)),
     lambda tenths,power: f'What is the greatest integer strictly less than ({tenths//10}.{tenths%10})^{power}?',
     lambda tenths,power: (tenths**power-1)//10**power)
test(367, 'round_robin_missing_score', dict(scores=([4,3,2,2,2],integers(5,0,8,min_length=3,max_length=8))),
     lambda scores: f'In a {len(scores)+1}-player round robin, each pair played once with no ties. '
     f'The first players won these numbers of games: {scores}. How many games did the remaining player win?',
     lambda scores: comb(len(scores)+1,2)-sum(scores), valid=valid_tournament, sample=sample_scores,
     constraints=['The complete sorted score sequence satisfies Landau’s tournament inequalities.'])
test(378, 'integral_nested_square_roots', dict(max_a=(10,1,100),max_b=(36,1,1000)),
     'For how many integer pairs (a,b) with 1 ≤ a ≤ {max_a} and 1 ≤ b ≤ {max_b} is √(a + √b) an integer?',
     lambda max_a,max_b: sum(isqrt(max_a+c)-isqrt(c) for c in range(1,isqrt(max_b)+1)),
     reference=lambda max_a,max_b: sum(isqrt(a+c)**2==a+c for a in range(1,max_a+1)
                                      for c in range(1,isqrt(max_b)+1)))
test(394, 'reverse_interval_rank', dict(end=(201,30,400),target=(53,10,250)),
     'When listing integers in descending order starting at {end}, what is the position of {target}? '
     'The first position is 1.',
     lambda end,target: end-target+1, valid=lambda end,target: target<=end,
     constraints=['The target is no greater than the starting point.'],
     adaptation='Omits the redundant lower endpoint and forward rank supplied by the source.')
test(398, 'pair_disjunction_intersection',
     dict(a=(1,0,9),b=(1,0,9),ys=([0,2],integers(2,0,9,min_length=1,max_length=5)),
          xs=([0,2],integers(2,0,9,min_length=1,max_length=5))),
     'How many integer pairs (x,y) satisfy both (x = {a} or y is in {ys}) and (x is in {xs} or y = {b})?',
     lambda a,b,ys,xs: 1+len(xs)*len(ys),
     valid=lambda a,b,ys,xs: a not in xs and b not in ys and len(xs)==len(set(xs)) and len(ys)==len(set(ys)),
     constraints=['The exceptional values are outside their respective lists, which have distinct entries.'])
test(419, 'compare_independent_coin_heads', dict(first=(2008,1,2010),second=(2009,1,2010),heads=(50,30,70)),
     'Two players independently toss identical coins with {heads}% chance of heads. The first tosses '
     '{first} times, the second {second} times. What is the probability the second gets strictly more heads?',
     coin_win, valid=lambda first,second,heads: heads==50 or first+second<=60,
     sample=lambda rng: dict(first=rng.randint(2,16),second=rng.randint(2,17),heads=rng.randint(35,65)),
     constraints=['Biased-coin cases use at most 60 total tosses.'],
     adaptation='Allows biased coins and unequal toss counts and states independence.')
test(438, 'sum_first_last_power_digits', dict(base=(2007,12,3000),power=(3,2,18)),
     'What is the sum of the first and last decimal digits of {base}^{power}?',
     lambda base,power: int(str(base**power)[0])+pow(base,power,10))
test(461, 'weekday_count_gregorian', dict(year=(2007,1900,2200),target=(4,0,6)),
     lambda year,target: f'How many {["Mondays","Tuesdays","Wednesdays","Thursdays","Fridays","Saturdays","Sundays"][target]} '
     f'are in Gregorian year {year}?',
     lambda year,target: 52+int((target-weekday(year,1,1))%7<1+isleap(year)),
     adaptation='Uses the Gregorian calendar to derive the weekday of January 1.')



@lru_cache(maxsize=None)
def factorion_candidates(base,width):
    weights = [factorial(d) for d in range(base)]
    result = []
    for word in combinations_with_replacement(range(base),width):
        value = sum(weights[d] for d in word)
        if tuple(sorted(digits(value,base)))==word and value>=base**(width-1):
            result.append(value)
    return tuple(result)


@lru_cache(maxsize=1)
def factorion_catalog():
    return [(b,w) for b in range(3,13) for w in range(2,6)
            if len(factorion_candidates(b,w))==1]


def square_factorial_product(a,b):
    value = factorial(a)*factorial(b)
    return isqrt(value)**2==value


def sample_factorial_product(rng):
    a = rng.randint(2,15)
    return dict(a=a,b=rng.choice([b for b in range(2,16) if square_factorial_product(a,b)]))


def count_handshakes(preferences):
    taller = 0
    total = 0
    for preference in preferences:
        if preference:
            taller += 1
        else:
            total += taller
    return total


def min_pascal_occurrences(lower,upper):
    counts = [2]*(upper+1)
    counts[2] = 1
    for row in range(4,(1+isqrt(1+8*upper))//2+1):
        for col in range(2,row//2+1):
            value = comb(row,col)
            if value>upper:
                break
            counts[value] += 1 if 2*col==row else 2
    return min(counts[max(2,lower):])


train(146,'unique_digit_factorial_fixed_point',dict(base=(10,3,12),width=(3,2,5)),
      'In base {base}, what is the unique {width}-digit integer that equals the sum of the '
      'factorials of its digits? Give the answer in decimal.',
      one(factorion_candidates),valid=singleton(factorion_candidates),
      sample=lambda rng: choose(rng,('base','width'),factorion_catalog()),
      constraints=['The factorial-sum fixed-point search yields exactly one numeral of the stated width.'])
train(227,'weighted_barycentric_area',dict(ratio=('1',choice(['1','1/2','2/3','3/2','2','3']))),
      'A point P is uniform in equilateral triangle ABC. What is the probability that ABP has '
      'area greater than {ratio} times the area of ACP and greater than {ratio} times the area of BCP?',
      lambda ratio: Fraction(2)/((1+Fraction(ratio))*(2+Fraction(ratio))),
      adaptation='Uses a common positive comparison ratio, equal to one in the source.')
train(572,'square_root_of_factorial_product',dict(a=(3,2,15),b=(3,2,15)),
      'Express the positive square root of {a}! × {b}! as an integer.',
      lambda a,b: isqrt(factorial(a)*factorial(b)),
      valid=square_factorial_product,sample=sample_factorial_product,
      constraints=['The product of the two factorials is a perfect square.'])
train(650,'mutual_height_preferences_handshakes',
      dict(preferences=([0]*8,integers(8,0,1,min_length=3,max_length=15))),
      lambda preferences: 'Order the guests from shortest to tallest. Their preferences in that order are '+
      ', '.join('taller' if p else 'shorter' for p in preferences)+
      '. Each guest shakes hands only with guests of the indicated relative height, and a handshake '
      'requires mutual agreement. How many handshakes occur?',
      count_handshakes,
      reference=lambda preferences: sum(a==1 and b==0 for a,b in combinations(preferences,2)),
      adaptation='Allows individual preferences for shorter or taller partners. The source has only shorter preferences.')
test(113,'cancelled_factorial_quotient',dict(left=(1,0,10),right=(1,0,10)),
     'What is the exact value of (x + {left} − x)! / (x − x + {right})!?',
     lambda left,right: Fraction(factorial(left),factorial(right)))
test(263,'least_pascal_entry_multiplicity_in_interval',dict(lower=(1,1,180),upper=(100,2,200)),
     'What is the smallest number of times any integer from {lower} to {upper} inclusive appears '
     'in Pascal’s triangle? Each position is counted separately, and 1 appears infinitely often.',
     min_pascal_occurrences,valid=lambda lower,upper: lower<=upper,
     sample=lambda rng: (lambda lo: dict(lower=lo,upper=rng.randint(max(2,lo),min(200,max(2,lo)+12))))(
         rng.randint(1,180)),
     constraints=['The interval is ordered and contains an integer greater than 1.'],
     adaptation='Specifies a finite interval, which includes 2 in the original case so that the source minimum is preserved.')
test(284,'binomial_coefficient_from_lower_index',dict(n=(10,2,80),r=(0,0,12)),
     'What is the binomial coefficient C({n}, {r})?',
     lambda n,r: comb(n,r),valid=lambda n,r: r<=n,
     constraints=['The lower index is between 0 and the upper index.'],
     adaptation='The source identity is the special case r = 0 for any positive n.')
test(286,'binomial_coefficient_from_upper_index',dict(n=(10,2,80),offset=(0,0,12)),
     lambda n,offset: f'What is the binomial coefficient C({n}, {n-offset})?',
     lambda n,offset: comb(n,n-offset),valid=lambda n,offset: offset<=n,
     constraints=['The distance from the upper index is at most that index.'],
     adaptation='The source identity is the special case where the lower index equals n.')
