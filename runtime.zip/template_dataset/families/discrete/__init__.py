"""Exact mathematical models for discrete."""
