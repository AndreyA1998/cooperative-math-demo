"""Exact templates for discrete source problems with additional statement forms."""

from collections import Counter
from functools import lru_cache, reduce
from fractions import Fraction
from hashlib import sha256
from itertools import combinations, permutations, product
from math import comb, factorial, gcd, isqrt, lcm, prod

from template_dataset.core import Template
from template_dataset.families.discrete import _factorization, _is_prime


def _case(family, domains, prompt, solve, reference, *, valid=None, sample=None,
          constraints=(), adaptation="Restated with explicit numerical parameters and consistent notation."):
    """Declare bounded integer inputs and, where needed, a constructive sampler."""
    parameters = {}
    original = {}
    for name, (source, lower, upper) in domains.items():
        parameters[name] = {"type": "int", "min": lower, "max": upper}
        original[name] = source

    def draw(rng):
        return {name: rng.randint(domain["min"], domain["max"])
                for name, domain in parameters.items()}

    def ordered(p):
        return {name: p[name] for name in parameters}

    return Template(
        family=f"discrete_v2.{family}",
        parameters=parameters,
        original=original,
        render=lambda p: prompt(**ordered(p)),
        solve=lambda p: solve(**ordered(p)),
        reference=lambda p: reference(**ordered(p)),
        sample=sample or draw,
        validate=(lambda p: valid(**ordered(p))) if valid else (lambda p: True),
        constraints=list(constraints),
        adaptation=adaptation,
    )


def _factors(n):
    return [i for i in range(1, n + 1) if n % i == 0]


def _factor_count(n):
    return prod(exponent + 1 for _, exponent in _factorization(n).items())


def _sum_factors(n):
    return prod((p ** (e + 1) - 1) // (p - 1) for p, e in _factorization(n).items())


def _widths(width):
    return 10 ** (width - 1), 10 ** width - 1


def _count_multiples(low, high, d):
    return high // d - (low - 1) // d


def _product_digits(n):
    return prod(int(digit) for digit in str(n))


def _minimum_root(n, power):
    return prod(p ** ((exponent + power - 1) // power)
                for p, exponent in _factorization(n).items())


def _integer_root(n, power):
    lower, upper = 0, 1 << ((n.bit_length() + power - 1) // power)
    while upper - lower > 1:
        middle = (lower + upper) // 2
        if middle ** power <= n:
            lower = middle
        else:
            upper = middle
    return upper if upper ** power <= n else lower


def _decimal_digits(numerator, denominator):
    value = Fraction(numerator, denominator)
    return max((e for _, e in _factorization(value.denominator).items()), default=0)


def _long_division(numerator, denominator):
    digits = []
    remainder = numerator % denominator
    while remainder:
        digit, remainder = divmod(10 * remainder, denominator)
        digits.append(digit)
    return digits


def _number_theory(case):
    plain_residues = {
        "nt158": (38574, 19), "nt202": (-1111, 9), "nt291": (10389, 12),
        "nt821": (100000, 7), "ns31": (142857, 18), "ns230": (123456, 101),
        "ns539": (12345, 6),
    }
    if case in plain_residues:
        n, modulus = plain_residues[case]
        return _case(
            "least_residue", {"value": (n, -200000, 200000), "modulus": (modulus, 2, 130)},
            lambda value, modulus: f"Find the integer `n` with `0 ≤ n < {modulus}` "
            f"such that `n ≡ {value} (mod {modulus})`.",
            lambda value, modulus: value % modulus,
            lambda value, modulus: next(i for i in range(modulus) if (value - i) % modulus == 0),
        )

    if case == "nt825":
        return _case(
            "interval_residue", {"value": (7882, 10, 30000), "modulus": (5, 2, 31),
                                 "lower": (4, 0, 100)},
            lambda value, modulus, lower: f"Find the integer `n` in "
            f"`{lower} ≤ n ≤ {lower + modulus - 1}` such that `n ≡ {value} (mod {modulus})`.",
            lambda value, modulus, lower: lower + (value - lower) % modulus,
            lambda value, modulus, lower: next(i for i in range(lower, lower + modulus)
                                                if (value - i) % modulus == 0),
            constraints=("The upper endpoint is lower + modulus − 1.",),
        )

    if case in {"nt12", "nt107", "nt417", "nt435", "nt470"}:
        return _extreme_residue(case)

    if case in {"nt67", "nt225", "nt666", "ns195", "nt311", "nt598"}:
        return _power_or_product_residue(case)

    if case in {"nt182", "nt467", "nt505", "nt506", "nt724", "nt246", "nt494",
                "ns168", "ns223", "ns239", "ns258", "ns494", "ns45", "ns65", "ns374"}:
        return _residue_operations(case)

    if case in {"nt49", "nt238", "nt409", "nt531", "nt82", "ns365", "nt213", "nt272",
                "ns106", "nt167", "nt346", "nt185", "nt337", "ns48"}:
        return _divisor_cases(case)

    if case in {"nt132", "nt480", "nt489", "nt822", "ns120", "ns238",
                "ns250", "ns286", "ns463", "nt546", "nt827", "ns288", "nt861",
                "nt249", "nt441", "ns404", "nt229", "nt362", "ns306", "ns74"}:
        return _base_cases(case)

    if case in {"nt192", "nt257", "nt309", "nt345", "nt365", "nt706", "nt462", "nt857",
                "ns129", "ns133", "ns167", "ns203", "ns274", "ns361", "ns411"}:
        return _decimal_cases(case)

    if case in {"nt533", "ns25", "ns486", "ns533", "ns219", "ns315", "ns255", "nt858",
                "nt5", "nt645", "nt694", "ns183", "ns440"}:
        return _perfect_powers(case)

    if case in {"nt28", "nt166", "nt222", "nt432", "ns201", "ns395", "ns425", "ns445",
                "ns469"}:
        return _factorials(case)

    if case in {"nt24", "nt117", "nt128", "nt231", "nt235", "nt261", "nt291", "nt347",
                "nt399", "nt427", "nt525", "nt539", "nt569", "nt684", "nt721", "nt799",
                "nt812", "nt839", "nt868", "ns0", "ns2", "ns147", "ns175", "ns185",
                "ns221", "ns225", "ns233", "ns245", "ns276", "ns291", "ns326",
                "ns348", "ns412", "ns430", "ns493", "ns510", "ns520"}:
        return _number_misc(case)

    if case in {"nt87", "nt214", "nt266", "nt356", "nt400", "nt697", "ns33",
                "ns164", "ns193", "ns429"}:
        return _digit_cases(case)

    return None


def _extreme_residue(case):
    if case == "nt12":
        return _case(
            "largest_digit_residue", {"digits": (4, 2, 6), "residue": (15, 0, 99),
                                     "modulus": (22, 2, 100)},
            lambda digits, residue, modulus: f"What is the largest {digits}-digit "
            f"integer congruent to {residue} modulo {modulus}?",
            lambda digits, residue, modulus: _widths(digits)[1]
            - (_widths(digits)[1] - residue) % modulus,
            lambda digits, residue, modulus: next(n for n in range(_widths(digits)[1], 0, -1)
                                                   if n % modulus == residue),
            valid=lambda digits, residue, modulus: residue < modulus <= 9 * 10 ** (digits - 1),
            sample=lambda rng: _sample_digit_residue(rng),
            constraints=("The residue is canonical and the interval covers every residue.",),
        )
    if case == "nt107":
        return _case(
            "least_digit_above_residue", {"digits": (3, 2, 6), "modulus": (9, 2, 30),
                                         "threshold": (5, 0, 28)},
            lambda digits, modulus, threshold: f"What is the least {digits}-digit integer "
            f"whose remainder modulo {modulus} exceeds {threshold}?",
            lambda digits, modulus, threshold: _widths(digits)[0]
            + max(0, threshold + 1 - _widths(digits)[0] % modulus),
            lambda digits, modulus, threshold: next(n for n in range(_widths(digits)[0],
                                                                    _widths(digits)[0] + modulus)
                                                     if n % modulus > threshold),
            valid=lambda digits, modulus, threshold: threshold < modulus - 1,
            sample=lambda rng: _sample_residue_threshold(rng),
            constraints=("The threshold is at most modulus − 2.",),
        )
    if case == "nt470":
        return _case(
            "next_multiple_gap", {"value": (412, 10, 10000), "divisor": (3, 2, 200)},
            lambda value, divisor: f"What is the least positive integer that can be "
            f"added to {value} to make the sum a multiple of {divisor}?",
            lambda value, divisor: divisor - value % divisor,
            lambda value, divisor: next(n for n in range(1, divisor + 1)
                                        if (value + n) % divisor == 0),
        )
    bound, residue, modulus = (80, 3, 5) if case == "nt417" else (74, 3, 7)
    return _case(
        "strict_lower_residue", {"bound": (bound, 5, 200), "residue": (residue, 0, 29),
                                 "modulus": (modulus, 2, 30)},
        lambda bound, residue, modulus: f"What is the largest integer less than {bound} "
        f"that leaves a remainder of {residue} when divided by {modulus}?",
        lambda bound, residue, modulus: bound - 1 - (bound - 1 - residue) % modulus,
        lambda bound, residue, modulus: next(n for n in range(bound - 1, bound - modulus - 1, -1)
                                             if n % modulus == residue),
        valid=lambda bound, residue, modulus: residue < modulus,
        sample=lambda rng: _sample_canonical_residue(rng, "bound", 5, 200),
        constraints=("The residue is less than the modulus.",),
    )


def _sample_digit_residue(rng):
    digits = rng.randint(2, 6)
    modulus = rng.randint(2, min(100, 9 * 10 ** (digits - 1)))
    return {"digits": digits, "modulus": modulus, "residue": rng.randrange(modulus)}


def _sample_residue_threshold(rng):
    modulus = rng.randint(2, 30)
    return {"digits": rng.randint(2, 6), "modulus": modulus,
            "threshold": rng.randrange(modulus - 1)}


def _sample_canonical_residue(rng, field, low, high):
    modulus = rng.randint(2, 30)
    return {field: rng.randint(low, high), "modulus": modulus, "residue": rng.randrange(modulus)}


def _power_or_product_residue(case):
    if case in {"nt67", "nt225"}:
        values, m = ((173, 927), 50) if case == "nt67" else ((77, 88, 99), 20)
        factors = {chr(97 + i): (value, 2, 1000) for i, value in enumerate(values)}
        return _case(
            "product_congruence", {"modulus": (m, 2, 100), **factors},
            lambda modulus, **p: f"Suppose `{' × '.join(str(x) for x in p.values())} ≡ n "
            f"(mod {modulus})` with `0 ≤ n < {modulus}`. Find `n`.",
            lambda modulus, **p: reduce(lambda a, b: (a * b) % modulus, p.values(), 1),
            lambda modulus, **p: prod(p.values()) % modulus,
        )
    if case in {"nt666", "ns195", "nt311"}:
        b, e, m = {"nt666": (11, 5, 9), "ns195": (1999, 2000, 5),
                   "nt311": (5, 1993, 1000)}[case]
        domains = {"base": (b, 2, 2000), "exponent": (e, 1, 2000)}
        if case == "nt311":
            return _case(
                "trailing_power_digits", domains,
                lambda base, exponent: f"What are the rightmost three digits of `{base}^{exponent}`? Give their value as an integer.",
                lambda base, exponent: pow(base, exponent, 1000),
                lambda base, exponent: (base ** exponent) % 1000,
            )
        return _case(
            "power_remainder", {**domains, "modulus": (m, 2, 100)},
            lambda base, exponent, modulus: f"Find the remainder of `{base}^{exponent}` "
            f"upon division by {modulus}.",
            lambda base, exponent, modulus: pow(base, exponent, modulus),
            lambda base, exponent, modulus: (base ** exponent) % modulus,
        )
    return _case(
        "power_tower_units", {"base": (9, 2, 20), "middle": (8, 2, 10), "top": (7, 2, 7)},
        lambda base, middle, top: f"Find the units digit of ${{ {base} }}^{{ {middle}^{top} }}$.",
        lambda base, middle, top: pow(base, middle ** top, 10),
        lambda base, middle, top: _units_power_cycle(base, middle ** top),
    )


def _units_power_cycle(base, exponent):
    seen = []
    digit = base % 10
    while digit not in seen:
        seen.append(digit)
        digit = digit * base % 10
    start = seen.index(digit)
    index = exponent - 1
    if index >= len(seen):
        index = start + (index - start) % (len(seen) - start)
    return seen[index]


def _residue_operations(case):
    tuples = {"nt182": (5, (1, 2, 3)), "nt467": (24, (10, 4, 12)),
              "nt505": (12, (7, 9, 10)), "nt506": (47, (25, 20, 3)),
              "nt724": (11, (2, 4, 6, 8)), "ns494": (6, (3, 5))}
    if case in tuples:
        m, values = tuples[case]
        op = "product" if case == "nt182" else "sum"
        aggregate = prod if case == "nt182" else sum
        domains = {chr(97 + i): (v, 0, 59) for i, v in enumerate(values)}

        def sample(rng):
            modulus = rng.randint(2, 60)
            return {"modulus": modulus, **{name: rng.randrange(modulus) for name in domains}}

        return _case(
            f"{op}_of_residues", {"modulus": (m, 2, 60), **domains},
            lambda modulus, **p: f"The remainders when {len(p)} positive integers are "
            f"divided by {modulus} are {', '.join(map(str, p.values()))}, respectively. "
            f"What is the remainder when their {op} is divided by {modulus}?",
            lambda modulus, **p: aggregate(p.values()) % modulus,
            lambda modulus, **p: divmod(aggregate(v + (i + 1) * modulus
                                                   for i, v in enumerate(p.values())), modulus)[1],
            valid=lambda modulus, **p: max(p.values()) < modulus,
            sample=sample,
            constraints=("Every listed remainder is less than the modulus.",),
        )

    affine = {
        "nt246": (6, 1, 1, 2010), "nt494": (3, 2, 5, 0),
        "ns168": (5, 3, 2, 0), "ns223": (7, 3, 3, 0),
        "ns239": (7, 5, 5, 0), "ns258": (7, 3, 2, 1),
    }
    if case in affine:
        m, r, factor, addend = affine[case]
        if case == "ns223":
            return _case(
                "multiply_polynomial_residue", {"modulus": (m, 2, 30), "constant": (r, 1, 20),
                                               "factor": (factor, 2, 15)},
                lambda modulus, constant, factor: f"For a positive integer `j`, multiply "
                f"`({modulus}j + {constant})` by {factor}. What is the remainder "
                f"when the result is divided by {modulus}?",
                lambda modulus, constant, factor: factor * constant % modulus,
                lambda modulus, constant, factor: divmod((17 * modulus + constant) * factor,
                                                        modulus)[1],
            )
        extra = {"addend": (addend, 1, 3000)} if case in {"nt246", "ns258"} else {}

        def sample(rng):
            p = _sample_canonical_residue(rng, "factor", 2, 15)
            if case == "nt246":
                p.pop("factor")
            if extra:
                p["addend"] = rng.randint(1, 3000)
            return p

        def render(modulus, residue, factor=1, addend=0):
            expression = "n" if factor == 1 else f"{factor}n"
            if addend:
                expression += f" + {addend}"
            return (f"When the integer `n` is divided by {modulus}, its remainder is {residue}. "
                    f"What remainder does `{expression}` leave when divided by {modulus}?")

        factor_field = {"factor": (factor, 2, 15)} if case != "nt246" else {}
        return _case(
            "affine_residue", {"modulus": (m, 2, 30), "residue": (r, 0, 29), **factor_field, **extra},
            render,
            lambda modulus, residue, factor=1, addend=0: (factor * residue + addend) % modulus,
            lambda modulus, residue, factor=1, addend=0: divmod(factor * (residue + 31 * modulus)
                                                               + addend, modulus)[1],
            valid=lambda modulus, residue, **p: residue < modulus,
            sample=sample,
            constraints=("The given remainder is less than the modulus.",),
        )

    if case == "ns374":
        return _case(
            "polynomial_residue", {"modulus": (7, 2, 30), "residue": (2, 0, 29),
                                   "a": (2, 1, 20), "b": (4, 1, 20), "c": (6, 1, 20)},
            lambda modulus, residue, a, b, c: f"If `n ≡ {residue} (mod {modulus})`, "
            f"find the remainder when `(n+{a})(n+{b})(n+{c})` is divided by {modulus}.",
            lambda modulus, residue, a, b, c: prod((residue + j) % modulus for j in (a, b, c)) % modulus,
            lambda modulus, residue, a, b, c: prod(residue + modulus + j for j in (a, b, c)) % modulus,
            valid=lambda modulus, residue, **p: residue < modulus,
            sample=lambda rng: {**_sample_canonical_residue(rng, "a", 1, 20),
                                "b": rng.randint(1, 20), "c": rng.randint(1, 20)},
            constraints=("The given remainder is less than the modulus.",),
        )
    m, x, y = (14, 4, 10) if case == "ns45" else (37, 16, 21)

    def render(modulus, a, b):
        if case == "ns45":
            return (f"For integers `m,n`, suppose `m ≡ {a} (mod {modulus})` and "
                    f"`m-n ≡ {b} (mod {modulus})`. Find the remainder of `m+n` modulo {modulus}.")
        return (f"For integers `a,b` with `a ≡ {a} (mod {modulus})` and "
                f"`b ≡ {b} (mod {modulus})`, find the residue of `a-b` between 0 and {modulus-1}.")

    def reference(modulus, a, b):
        if case == "ns45":
            y = next(i for i in range(modulus) if (a - i) % modulus == b)
            return (a + y) % modulus
        return next(i for i in range(modulus) if (a - b - i) % modulus == 0)

    def sample(rng):
        modulus = rng.randint(2, 50)
        return {"modulus": modulus, "a": rng.randrange(modulus), "b": rng.randrange(modulus)}

    return _case(
        "difference_congruence", {"modulus": (m, 2, 50), "a": (x, 0, 49), "b": (y, 0, 49)},
        render, lambda modulus, a, b: ((2 * a if case == "ns45" else a) - b) % modulus,
        reference, valid=lambda modulus, a, b: max(a, b) < modulus, sample=sample,
        constraints=("The two given residues are less than the modulus.",),
    )


def _divisor_cases(case):
    minimum = {"nt49": 10, "nt238": 10, "nt409": 8, "nt531": 5}
    if case in minimum:
        return _case(
            "least_with_divisor_count", {"count": (minimum[case], 2, 12)},
            lambda count: f"What is the least positive integer with exactly {count} positive divisors?",
            lambda count: next(n for n in range(2, 2049) if _factor_count(n) == count),
            lambda count: next(n for n in range(2, 2049) if len(_factors(n)) == count),
        )

    if case in {"nt82", "ns365"}:
        n, k = (24516, 9) if case == "nt82" else (1452, 6)
        return _case(
            "divisors_in_initial_interval", {"n": (n, 100, 30000), "limit": (k, 2, 20)},
            lambda n, limit: f"How many integers from 1 through {limit} are divisors of {n}?",
            lambda n, limit: sum(n % k == 0 for k in range(1, limit + 1)),
            lambda n, limit: sum(d <= limit for d in _factors(n)),
        )

    if case == "ns48":
        return _case(
            "maximum_divisor_count", {"bound": (20, 5, 220)},
            lambda bound: f"What is the greatest number of positive divisors that "
            f"an integer from 1 through {bound - 1} can have?",
            lambda bound: max(_factor_count(n) for n in range(1, bound)),
            lambda bound: max(len(_factors(n)) for n in range(1, bound)),
        )

    if case in {"nt167", "nt346"}:
        return _case(
            "sum_divisibility_solutions", {"offset": (6 if case == "nt167" else 18, 2, 600)},
            lambda offset: f"Find the sum of the positive integers n for which (n + {offset})/n is an integer.",
            lambda offset: _sum_factors(offset),
            lambda offset: sum(n for n in range(1, offset + 1) if (n + offset) % n == 0),
        )

    if case == "nt337":
        return _case(
            "positive_divisor_operator", {"a": (10, 2, 35)},
            lambda a: f"Define a ⋆ b = a²/b for b nonzero. How many integer values of x "
            f"make {a} ⋆ x a positive integer?",
            lambda a: _factor_count(a * a),
            lambda a: sum(a * a % x == 0 for x in range(1, a * a + 1)),
        )

    if case == "nt185":
        def sample(rng):
            order = rng.randint(2, 7)
            if rng.randrange(5) == 0:
                return {"n": rng.randint(4, 2500), "order": order}
            factor = rng.randint(2, _integer_root(2500, order)) ** order
            return {"n": factor * rng.randint(1, 2500 // factor), "order": order}

        return _case(
            "greatest_perfect_power_divisor", {"n": (1512, 4, 2500), "order": (2, 2, 7)},
            lambda n, order: f"What is the largest divisor of {n} that is a perfect power of order {order}?",
            lambda n, order: prod(p ** (e - e % order) for p, e in _factorization(n).items()),
            lambda n, order: next(a ** order for a in range(_integer_root(n, order), 0, -1)
                                  if n % a ** order == 0),
            sample=sample,
        )

    n = {"nt213": 18, "nt272": 6, "ns106": 12}[case]
    prompts = {
        "nt213": lambda n: f"What is the sum of all positive divisors of {n}?",
        "nt272": lambda n: f"What is the sum of the reciprocals of all positive divisors of {n}?",
        "ns106": lambda n: f"For a positive integer x define □(x) as the product of its "
        f"divisors greater than 1 and smaller than x. Find □({n}).",
    }
    solvers = {
        "nt213": _sum_factors,
        "nt272": lambda n: Fraction(_sum_factors(n), n),
        "ns106": lambda n: prod(p ** (e * _factor_count(n) // 2 - e)
                               for p, e in _factorization(n).items()),
    }
    references = {
        "nt213": lambda n: sum(_factors(n)),
        "nt272": lambda n: sum(Fraction(1, d) for d in _factors(n)),
        "ns106": lambda n: prod(d for d in _factors(n) if 1 < d < n),
    }
    return _case("divisor_statistics", {"n": (n, 4, 600)}, prompts[case],
                 solvers[case], references[case])


def _digit_value(digits, base):
    return reduce(lambda value, digit: value * base + int(digit), str(digits), 0)


def _base_encode(value, base):
    place = 1
    digits = 0
    while value:
        value, digit = divmod(value, base)
        digits += place * digit
        place *= 10
    return digits


def _base_width(value, base):
    power = base
    width = 1
    while power <= value:
        width += 1
        power *= base
    return width


def _base_cases(case):
    if case == "ns238":
        def sample(rng):
            small, large = sorted(rng.sample(range(2, 11), 2))
            return {"digits": _sample_based_digits(rng, small), "larger_base": large, "smaller_base": small}

        return _case(
            "shared_digit_string_difference",
            {"digits": (321, 10, 999), "larger_base": (7, 3, 10), "smaller_base": (5, 2, 9)},
            lambda digits, larger_base, smaller_base:
            f"Express the difference of ${digits}_{{{larger_base}}}-{digits}_{{{smaller_base}}}$ in base ten.",
            lambda digits, larger_base, smaller_base:
            _digit_value(digits, larger_base) - _digit_value(digits, smaller_base),
            lambda digits, larger_base, smaller_base:
            int(str(digits), larger_base) - int(str(digits), smaller_base),
            valid=lambda digits, larger_base, smaller_base:
            max(map(int, str(digits))) < smaller_base < larger_base,
            sample=sample, constraints=("The shared digits are valid in both bases, with the first base larger.",),
        )
    pairs = {
        "nt132": (121, 5, 11, 5, "×"), "nt480": (1001, 2, 121, 3, "×"),
        "nt822": (213, 8, 142, 7, "−"), "ns120": (333, 4, 344, 5, "−"),
        "ns250": (235, 7, 1324, 5, "+"),
        "ns286": (62, 7, 34, 5, "+"), "ns463": (332, 4, 212, 3, "−"),
    }
    if case in pairs:
        a, b, c, d, operation = pairs[case]
        same_base = case == "nt132"
        domains = {"left": (a, 10, 1999), "left_base": (b, 2, 10), "right": (c, 10, 1999)}
        if not same_base:
            domains["right_base"] = (d, 2, 10)

        def render(left, left_base, right, right_base=None):
            right_base = right_base or left_base
            result_base = left_base if same_base else 10
            suffix = " Write only the digits without a base subscript." if same_base else ""
            return (f"Express the result of ${left}_{{{left_base}}} {operation} "
                    f"{right}_{{{right_base}}}$ in base {result_base}.{suffix}")

        def solve(left, left_base, right, right_base=None):
            x, y = _digit_value(left, left_base), _digit_value(right, right_base or left_base)
            value = {"+": lambda: x + y, "−": lambda: x - y, "×": lambda: x * y}[operation]()
            return _base_encode(value, left_base) if same_base else value

        def reference(left, left_base, right, right_base=None):
            x, y = int(str(left), left_base), int(str(right), right_base or left_base)
            if same_base:
                v = x * y
                return int("".join(str(v // left_base ** i % left_base)
                                   for i in range(_base_width(v, left_base) - 1, -1, -1)))
            return x + y if operation == "+" else x - y if operation == "−" else x * y

        def sample(rng):
            left_base = rng.randint(2, 10)
            right_base = left_base if same_base else rng.randint(2, 10)
            p = {"left": _sample_based_digits(rng, left_base),
                 "left_base": left_base, "right": _sample_based_digits(rng, right_base)}
            if not same_base:
                p["right_base"] = right_base
            return p

        return _case(
            "base_arithmetic", domains, render, solve, reference,
            valid=lambda left, left_base, right, right_base=None:
            max(map(int, str(left))) < left_base
            and max(map(int, str(right))) < (right_base or left_base),
            sample=sample, constraints=("Each digit is smaller than its operand's base.",),
        )

    modulo = {"nt546": (100101110010, 2, 4), "nt827": (1531, 12, 8), "ns288": (729, 16, 15)}
    if case in modulo:
        digits, base, m = modulo[case]

        def sample(rng):
            base = rng.randint(2, 16)
            return {"digits": _sample_based_digits(rng, base), "base": base,
                    "divisor": rng.randint(2, 50)}

        return _case(
            "base_remainder", {"digits": (digits, 10, 111111111111), "base": (base, 2, 16),
                               "divisor": (m, 2, 50)},
            lambda digits, base, divisor: f"When the base-{base} integer ${digits}_{{{base}}}$ "
            f"is divided by the base-ten integer {divisor}, what is the remainder in base ten?",
            lambda digits, base, divisor: _digit_value(digits, base) % divisor,
            lambda digits, base, divisor: int(str(digits), base) % divisor,
            valid=lambda digits, base, divisor: max(map(int, str(digits))) < base,
            sample=sample, constraints=("Every displayed digit is smaller than the base.",),
        )

    if case == "nt861":
        return _case(
            "base_ten_conversion", {"digits": (2847, 10, 9999), "base": (9, 2, 16)},
            lambda digits, base: f"Mary ran a total of ${digits}_{{{base}}}$ miles while training "
            f"for a half marathon. How many miles did she run, expressed in base ten?",
            _digit_value, lambda digits, base: int(str(digits), base),
            valid=lambda digits, base: max(map(int, str(digits))) < base,
            sample=lambda rng: _sample_base_digits(rng),
            constraints=("Every displayed digit is smaller than the base.",),
        )

    if case in {"nt249", "nt441", "ns404"}:
        least = case == "nt249"
        width, base = {"nt249": (6, 2), "nt441": (4, 4), "ns404": (8, 2)}[case]
        return _case(
            "extreme_base_integer", {"width": (width, 2, 12), "base": (base, 2, 9)},
            lambda width, base: f"Express in base ten the {'least' if least else 'greatest'} "
            f"positive integer whose base-{base} representation has exactly {width} digits.",
            lambda width, base: base ** (width - 1) if least else base ** width - 1,
            lambda width, base: int("1" + "0" * (width - 1), base) if least
            else int(str(base - 1) * width, base),
        )

    if case == "nt229":
        return _case(
            "base_width_difference", {"small": (200, 2, 350), "large": (1200, 351, 2600),
                                      "base": (2, 2, 9)},
            lambda small, large, base: f"How many more digits does {large} have than {small} "
            f"when both base-ten numbers are expressed in base {base}?",
            lambda small, large, base: _base_width(large, base) - _base_width(small, base),
            lambda small, large, base: len(str(_base_encode(large, base)))
            - len(str(_base_encode(small, base))),
        )

    if case in {"nt362", "ns306"}:
        n, small, large = (987, 3, 8) if case == "nt362" else (87, 2, 3)
        return _case(
            "base_width_comparison", {"n": (n, 20, 2500), "small_base": (small, 2, 5),
                                      "large_base": (large, 3, 9)},
            lambda n, small_base, large_base: f"How many more digits does {n} have in base "
            f"{small_base} than in base {large_base}? The number {n} is given in base ten.",
            lambda n, small_base, large_base: _base_width(n, small_base) - _base_width(n, large_base),
            lambda n, small_base, large_base: len(str(_base_encode(n, small_base)))
            - len(str(_base_encode(n, large_base))),
            valid=lambda n, small_base, large_base: small_base < large_base,
            sample=lambda rng: _sample_width_comparison(rng),
            constraints=("The first base is strictly smaller than the second base.",),
        )

    if case == "nt489":
        return _case(
            "base_fraction_arithmetic",
            {"a": (165, 100, 999), "b": (11, 10, 99), "c": (121, 100, 999), "d": (21, 10, 99)},
            lambda a, b, c, d: f"Express ${{\\frac{{{a}_7}}{{{b}_2}}}}"
            f"+{{\\frac{{{c}_6}}{{{d}_3}}}}$ in base ten.",
            lambda a, b, c, d: Fraction(_digit_value(a, 7), _digit_value(b, 2))
            + Fraction(_digit_value(c, 6), _digit_value(d, 3)),
            lambda a, b, c, d: Fraction(int(str(a), 7), int(str(b), 2))
            + Fraction(int(str(c), 6), int(str(d), 3)),
            valid=lambda **p: all(max(map(int, str(digit))) < base
                                  for digit, base in zip(p.values(), (7, 2, 6, 3))),
            sample=lambda rng: {name: _sample_based_digits(rng, base, width)
                                for name, base, width in zip("abcd", (7, 2, 6, 3), (3, 2, 3, 2))},
            constraints=("Every displayed digit is smaller than its operand's base.",),
        )

    return _case(
        "least_two_digit_base", {"n": (47, 3, 2500)},
        lambda n: f"What is the smallest integer base in which {n} has exactly two digits?",
        lambda n: isqrt(n) + 1,
        lambda n: next(b for b in range(2, n + 1) if b <= n < b * b),
    )


def _sample_based_digits(rng, base, width=None):
    width = rng.randint(2, 3) if width is None else width
    ceiling = min(10, base)
    result = rng.randrange(1, ceiling)
    for _ in range(width - 1):
        result = 10 * result + rng.randrange(ceiling)
    return result


def _sample_base_digits(rng):
    base = rng.randint(2, 16)
    return {"digits": _sample_based_digits(rng, base, rng.randint(2, 4)), "base": base}


def _sample_width_comparison(rng):
    base = rng.randint(2, 5)
    return {"n": rng.randint(20, 2500), "small_base": base, "large_base": rng.randint(base + 1, 9)}


def _decimal_cases(case):
    if case in {"nt257", "nt462", "nt857"}:
        return _repeating_decimal_cases(case)

    if case == "nt192":
        return _case(
            "first_nonzero_decimal_digit", {"denominator": (129, 2, 10000)},
            lambda denominator: f"What is the first nonzero digit after the decimal point in 1/{denominator}?",
            lambda denominator: 10 ** len(str(denominator - 1)) // denominator,
            lambda denominator: _first_nonzero_digit(denominator),
        )

    if case in {"nt309", "ns129"}:
        last = case == "nt309"
        return _case(
            "decimal_reciprocal_of_power", {"power": (10, 1, 20), "base": (2, 2, 5)},
            lambda power, base: f"What is the {'last digit' if last else 'number of digits'} "
            f"to the right of the decimal point in the terminating decimal for $1/{base}^{{{power}}}$?",
            lambda power, base: (5 if base == 2 else 2 ** power % 10) if last else power,
            lambda power, base: _long_division(1, base ** power)[-1] if last
            else len(_long_division(1, base ** power)),
            valid=lambda power, base: base in {2, 5},
            sample=lambda rng: {"power": rng.randint(1, 20), "base": rng.choice((2, 5))},
            constraints=("The base is 2 or 5, so the decimal terminates.",),
        )

    if case in {"ns167", "nt365", "ns361"}:
        n, a, b = {"ns167": (4321, 8, 7), "nt365": (31, 1, 6), "ns361": (21, 2, 7)}[case]
        digit_sum = case == "ns167"

        def render(numerator, twos, fives):
            fraction = f"$\\frac{{{numerator}}}{{2^{{{twos}}} \\cdot 5^{{{fives}}}}}$"
            if digit_sum:
                return f"Find the sum of the digits of the terminating decimal for {fraction}."
            return f"Express {fraction} as a terminating decimal."

        def solve(numerator, twos, fives):
            if not digit_sum:
                return Fraction(numerator, 2 ** twos * 5 ** fives)
            width = max(twos, fives)
            digits = numerator * 2 ** (width - twos) * 5 ** (width - fives)
            return sum(map(int, str(digits)))

        def reference(numerator, twos, fives):
            denominator = 2 ** twos * 5 ** fives
            if not digit_sum:
                digits = _long_division(numerator, denominator)
                return numerator // denominator + Fraction(
                    sum(d * 10 ** i for i, d in enumerate(reversed(digits))), 10 ** len(digits))
            return sum(map(int, str(numerator // denominator))) + sum(_long_division(numerator, denominator))

        return _case(
            "terminating_power_denominator", {"numerator": (n, 1, 6000),
                                              "twos": (a, 1, 12), "fives": (b, 1, 12)},
            render, solve, reference,
        )

    n, d = {"nt345": (37, 80), "nt706": (11, 125), "ns133": (54317, 80000),
            "ns203": (137, 500), "ns274": (57, 160), "ns411": (141, 400)}[case]
    last = case in {"ns203", "ns411"}
    count = case == "ns133"
    denominators = tuple(sorted({2 ** a * 5 ** b for a in range(17) for b in range(8)
                                if 1 < 2 ** a * 5 ** b <= 80000}))

    def render(numerator, denominator):
        fraction = f"$\\frac{{{numerator}}}{{{denominator}}}$"
        if last:
            return f"What is the last nonzero digit after the decimal point in the decimal for {fraction}?"
        if count:
            return f"How many digits are to the right of the decimal point in the shortest decimal for {fraction}?"
        return f"Express {fraction} as a terminating decimal."

    def solve(numerator, denominator):
        width = _decimal_digits(numerator, denominator)
        if last:
            return numerator * 10 ** width // denominator % 10
        if count:
            return width
        return Fraction(numerator, denominator)

    def reference(numerator, denominator):
        digits = _long_division(numerator, denominator)
        if last:
            return digits[-1]
        if count:
            return len(digits)
        return Fraction(sum(d * 10 ** i for i, d in enumerate(reversed(digits))), 10 ** len(digits))

    def sample(rng):
        denominator = rng.choice(denominators)
        return {"denominator": denominator, "numerator": rng.randrange(1, denominator)}

    return _case(
        "terminating_decimal", {"numerator": (n, 1, 79999), "denominator": (d, 2, 80000)},
        render, solve, reference,
        valid=lambda numerator, denominator: denominator in denominators and numerator < denominator,
        sample=sample,
        constraints=("The numerator is smaller than the denominator. The denominator has "
                     "no prime factors other than 2 and 5.",),
    )


def _first_nonzero_digit(denominator):
    remainder = 1
    while remainder * 10 < denominator:
        remainder *= 10
    return remainder * 10 // denominator


def _repeating_decimal_cases(case):
    if case == "nt257":
        return _case(
            "nonterminating_fraction_count", {"denominator": (12, 3, 200)},
            lambda denominator: f"For how many integers n from 1 to {denominator - 1} "
            f"does n/{denominator} have a nonterminating repeating decimal?",
            lambda denominator: denominator - prod(p ** e for p, e in
                                                    _factorization(denominator).items() if p in {2, 5}),
            lambda denominator: sum(_has_repeating_decimal(n, denominator)
                                    for n in range(1, denominator)),
            constraints=("The numerator interval is 1 through denominator − 1, inclusive.",),
        )

    if case == "nt857":
        return _case(
            "indexed_decimal_digit", {"denominator": (7, 2, 50), "index": (100, 1, 600)},
            lambda denominator, index: f"What is digit number {index} after the decimal point "
            f"in the decimal representation of 1/{denominator}? Use trailing zeroes if it terminates.",
            lambda denominator, index: 10 * pow(10, index - 1, denominator) // denominator,
            lambda denominator, index: _decimal_digit_reference(denominator, index),
        )

    def sample(rng):
        denominator = rng.choice((3, 7, 9, 11, 13, 17, 19, 21, 23, 27, 29))
        return {"denominator": denominator,
                "numerator": rng.choice(tuple(n for n in range(1, denominator) if gcd(n, denominator) == 1))}

    return _case(
        "decimal_repetition_period", {"numerator": (8, 1, 29), "denominator": (11, 3, 30)},
        lambda numerator, denominator: f"The decimal for {numerator}/{denominator} repeats. "
        f"What is the length of its shortest repeating block?",
        lambda numerator, denominator: next(k for k in range(1, denominator)
                                            if pow(10, k, denominator) == 1),
        lambda numerator, denominator: _cycle_length(numerator, denominator),
        valid=lambda numerator, denominator: numerator < denominator and gcd(denominator, 10) == 1
        and gcd(numerator, denominator) == 1,
        sample=sample,
        constraints=("The fraction is reduced and proper. The denominator is coprime to 10.",),
    )


def _cycle_length(numerator, denominator):
    steps = {}
    remainder = numerator % denominator
    while remainder not in steps:
        steps[remainder] = len(steps)
        remainder = remainder * 10 % denominator
    return len(steps) - steps[remainder]


def _has_repeating_decimal(numerator, denominator):
    seen = set()
    while numerator and numerator not in seen:
        seen.add(numerator)
        numerator = 10 * numerator % denominator
    return numerator != 0


def _decimal_digit_reference(denominator, index):
    remainder = 1
    for _ in range(index):
        digit, remainder = divmod(10 * remainder, denominator)
    return digit


def _perfect_powers(case):
    complements = {"ns25": (720, 3, False),
                   "ns486": (240, 3, True), "ns533": (735, 2, False)}
    if case in complements:
        n, k, multiplier = complements[case]

        def render(value, power):
            if multiplier:
                return (f"What is the least positive integer k such that "
                        f"{value}k is a perfect {power}th power?")
            return (f"Let x = {value} and let a be a positive integer such that ax is a "
                    f"perfect {power}th power. What is the least possible positive {power}th root of ax?")

        def solve(value, power):
            root = _minimum_root(value, power)
            return root ** power // value if multiplier else root

        def reference(value, power):
            root = next(r for r in range(1, value + 1) if r ** power % value == 0)
            return root ** power // value if multiplier else root

        return _case("perfect_power_completion", {"value": (n, 2, 1400), "power": (k, 2, 6)},
                     render, solve, reference)

    if case == "ns219":
        return _case(
            "least_nonunit_common_perfect_power",
            {"power_a": (3, 2, 4), "power_b": (4, 3, 5)},
            lambda power_a, power_b: f"What is the smallest positive integer other than 1 "
            f"that is both a perfect power of order {power_a} and of order {power_b}?",
            lambda power_a, power_b: 2 ** lcm(power_a, power_b),
            lambda power_a, power_b: next(a ** power_a for a in range(2, 65)
                                          if _integer_root(a ** power_a, power_b) ** power_b == a ** power_a),
        )
    if case == "ns255":
        def sample(rng):
            return {"bound": rng.randint(2, 10) ** 6}

        return _case(
            "successor_common_perfect_power", {"bound": (64, 64, 10**6)},
            lambda bound: f"The number {bound} is both a perfect cube and a perfect square. "
            "What is the next larger positive integer that is both a perfect cube and a perfect square?",
            lambda bound: (_integer_root(bound, 6) + 1) ** 6,
            lambda bound: next(n * n for n in range(isqrt(bound) + 1, 1332)
                               if _integer_root(n*n, 3) ** 3 == n*n),
            valid=lambda bound: _integer_root(bound, 6) ** 6 == bound, sample=sample,
            constraints=("The starting number is itself a sixth power.",),
        )
    if case == "nt858":
        return _case(
            "least_fixed_width_cube_and_square", {"width": (4, 2, 7)},
            lambda width: f"What is the least positive {width}-digit integer "
            "that is both a perfect square and a perfect cube?",
            lambda width: (_integer_root(10 ** (width - 1) - 1, 6) + 1) ** 6,
            lambda width: next(n*n for n in range(isqrt(10 ** (width - 1)-1)+1, isqrt(10**width-1)+1)
                               if _integer_root(n*n, 3) ** 3 == n*n),
        )
    if case == "ns315":
        return _case(
            "least_cube_and_square_above_bound", {"bound": (10, 2, 1500)},
            lambda bound: f"What is the smallest integer greater than {bound} that is "
            "both a perfect square and a perfect cube?",
            lambda bound: (_integer_root(bound, 6) + 1) ** 6,
            lambda bound: next(n*n for n in range(isqrt(bound)+1, 150)
                               if _integer_root(n*n, 3) ** 3 == n*n),
        )
    if case == "nt645":
        def count(width, base):
            low, high = _widths(width)
            result, value = 0, 1
            while value <= high:
                result += value >= low
                value *= base
            return result

        return _case(
            "fixed_width_power_count", {"width": (2, 1, 7), "base": (2, 2, 12)},
            lambda width, base: f"How many positive {width}-digit integers are "
            f"of the form ${base}^n$ for an integer n?",
            count, lambda width, base: sum(_widths(width)[0] <= base ** i <= _widths(width)[1]
                                          for i in range(24)),
        )

    if case == "nt694":
        return _case(
            "divisible_fixed_width_power_count", {"width": (3, 2, 5), "power": (3, 2, 5),
                                                  "divisor": (9, 2, 80)},
            lambda width, power, divisor: f"How many positive {width}-digit perfect "
            f"powers of order {power} are divisible by {divisor}?",
            lambda width, power, divisor: _count_multiples(
                _integer_root(_widths(width)[0] - 1, power) + 1,
                _integer_root(_widths(width)[1], power), _minimum_root(divisor, power)),
            lambda width, power, divisor: sum(_widths(width)[0] <= x ** power <= _widths(width)[1]
                                               and x ** power % divisor == 0 for x in range(1, 317)),
        )
    if case == "nt5":
        return _case(
            "palindromic_square_count", {"width": (3, 2, 5)},
            lambda width: f"How many positive {width}-digit perfect squares are palindromes?",
            lambda width: sum(str(x * x) == str(x * x)[::-1]
                              for x in range(isqrt(_widths(width)[0] - 1) + 1, isqrt(_widths(width)[1]) + 1)),
            lambda width: sum(isqrt(x) ** 2 == x and str(x) == str(x)[::-1]
                              for x in range(_widths(width)[0], _widths(width)[1] + 1)),
        )
    if case == "ns183":
        return _case(
            "squares_by_units_digit", {"units": (6, 0, 9)},
            lambda units: f"How many distinct tens digits occur among positive two-digit "
            f"perfect squares ending in the digit {units}?",
            lambda units: sum(n * n % 10 == units for n in range(4, 10)),
            lambda units: sum(isqrt(n) ** 2 == n for n in range(10 + units, 100, 10)),
        )
    if case == "ns440":
        return _case(
            "largest_divisible_square", {"bound": (225, 200, 2000), "divisor": (9, 2, 14)},
            lambda bound, divisor: f"What is the largest perfect square less than "
            f"{bound} that is a multiple of {divisor}?",
            lambda bound, divisor: (_minimum_root(divisor, 2)
            * (isqrt(bound - 1) // _minimum_root(divisor, 2))) ** 2,
            lambda bound, divisor: next(n for n in range(bound - 1, 0, -1)
                                        if n % divisor == 0 and isqrt(n) ** 2 == n),
        )
    return None


def _factorials(case):
    remainders = {"nt222": (9, 11), "ns201": (7, 23), "ns425": (9, 10)}
    if case in remainders:
        n, m = remainders[case]
        return _case(
            "factorial_remainder", {"n": (n, 3, 55), "divisor": (m, 2, 80)},
            lambda n, divisor: f"What remainder does {n}! leave upon division by {divisor}?",
            lambda n, divisor: reduce(lambda a, b: a * b % divisor, range(2, n + 1), 1),
            lambda n, divisor: factorial(n) % divisor,
        )
    if case in {"nt166", "nt28"}:
        n, m = (5, 6) if case == "nt166" else (5, 8)
        ratio = case == "nt28"

        def render(a, b, denominator=None):
            second = f"{b}!/{denominator}!" if ratio else f"{b}!"
            return f"What is the greatest common divisor of {a}! and {second}?"

        def solve(a, b, denominator=None):
            return gcd(factorial(a), factorial(b) // factorial(denominator or 1))

        def reference(a, b, denominator=None):
            return max(d for d in _factors(factorial(a))
                       if prod(range((denominator or 1) + 1, b + 1)) % d == 0)

        return _case(
            "gcd_of_factorials", {"a": (n, 3, 7), "b": (m, 5, 10),
                                  **({"denominator": (3, 2, 4)} if ratio else {})},
            render, solve, reference,
        )
    if case == "nt432":
        def solve(n):
            factors = {}
            for k in range(2, n + 1):
                for p, e in _factorization(k).items():
                    factors[p] = factors.get(p, 0) + e
            return prod(e + 1 for e in factors.values())

        return _case(
            "factorial_divisor_count", {"n": (6, 3, 8)},
            lambda n: f"How many positive integers divide {n}!?", solve,
            lambda n: len(_factors(factorial(n))),
        )
    if case == "ns395":
        return _case(
            "gcd_of_offset_factorials",
            {"n": (10, 4, 15), "first_offset": (2, 1, 14), "second_offset": (8, 1, 40)},
            lambda n, first_offset, second_offset: f"Find the greatest common divisor of "
            f"{n}! + {first_offset} and {n + 1}! + {second_offset}.",
            lambda n, first_offset, second_offset: gcd(factorial(n) + first_offset,
                                                      abs(second_offset - (n + 1) * first_offset)),
            lambda n, first_offset, second_offset: gcd(factorial(n) + first_offset,
                                                      factorial(n + 1) + second_offset),
        )
    if case == "ns469":
        return _case(
            "greatest_odd_factor_of_factorial", {"n": (5, 3, 22)},
            lambda n: f"What is the greatest odd factor of {n}!?",
            lambda n: factorial(n) // (factorial(n) & -factorial(n)),
            lambda n: prod(k // (k & -k) for k in range(1, n + 1)),
        )
    if case == "ns445":
        def render(n, trailing, width):
            return (f"{n}! has {width} digits and its last {width - 1} digits are "
                    f"{trailing:0{width - 1}d}. What is its first digit?")

        def sample(rng):
            n = rng.randint(4, 22)
            value = str(factorial(n))
            return {"n": n, "trailing": int(value[1:]), "width": len(value)}

        return _case(
            "first_factorial_digit", {"n": (20, 4, 22), "width": (19, 2, 22),
                                      "trailing": (432902008176640000, 0, 10 ** 21 - 1)},
            render, lambda n, trailing, width: factorial(n) // 10 ** (width - 1),
            lambda n, trailing, width: int(str(prod(range(1, n + 1)))[0]),
            valid=lambda n, trailing, width: width == len(str(factorial(n)))
            and trailing == factorial(n) % 10 ** (width - 1),
            sample=sample,
            constraints=("The given width and suffix must match the decimal digits of n!.",),
        )
    return None


def _digit_cases(case):
    if case in {"nt356", "ns33", "nt697"}:
        least = case == "ns33"
        required_divisor = 9 if case == "nt697" else 1
        length, total = {"nt356": (4, 16), "ns33": (5, 20), "nt697": (3, 18)}[case]
        min_digit = int(least)

        def solve(width, target):
            digits = []
            for position in range(width):
                lower = max(min_digit, int(position == 0))
                remaining = width - position - 1
                digit = (max(lower, target - 9 * remaining) if least
                         else min(9, target - remaining * min_digit))
                target -= digit
                digits.append(digit)
            return reduce(lambda value, digit: value * 10 + digit, digits, 0)

        def reference(width, target):
            first, last = _widths(width)
            candidates = range(first, last + 1) if least else range(last, first - 1, -1)
            return next(n for n in candidates if sum(map(int, str(n))) == target
                        and (not least or "0" not in str(n)) and n % required_divisor == 0)

        def sample(rng):
            width = rng.randint(2, 5)
            target = rng.randint(width if least else 1, 9 * width) if required_divisor == 1 else 9 * rng.randint(1, width)
            return {"width": width, "target": target}

        def render(width, target):
            extra = " with all digits nonzero" if least else " that is a multiple of 9" if required_divisor == 9 else ""
            return (f"What is the {'smallest' if least else 'largest'} positive {width}-digit "
                    f"integer{extra} whose digits add up to {target}?")

        return _case(
            "extreme_digit_sum", {"width": (length, 2, 5), "target": (total, 1, 45)},
            render, solve, reference,
            valid=lambda width, target: (width if least else 1) <= target <= 9 * width
            and target % required_divisor == 0, sample=sample,
            constraints=(("Each digit is nonzero, so width ≤ target ≤ 9 × width." if least
                          else "1 ≤ target ≤ 9 × width."),)
            + (("The digit sum is a multiple of 9.",) if required_divisor == 9 else ()),
        )

    if case in {"nt400", "ns164", "ns429"}:
        least = case == "nt400"
        target = 12 if case == "ns429" else 6

        def solve(target):
            triples = (100 * a + 10 * b + target // (a * b)
                       for a in range(1, 10) for b in range(1, 10)
                       if target % (a * b) == 0 and 1 <= target // (a * b) <= 9)
            return (min if least else max)(triples)

        return _case(
            "extreme_digit_product", {"target": (target, 1, 64)},
            lambda target: f"What is the {'least' if least else 'greatest'} three-digit "
            f"positive integer whose digits multiply to {target}?",
            solve, lambda target: (min if least else max)(n for n in range(100, 1000)
                                                          if _product_digits(n) == target),
            valid=lambda target: any(a * b * c == target for a, b, c in product(range(1, 10), repeat=3)),
            sample=lambda rng: {"target": prod(rng.randint(1, 4) for _ in range(3))},
            constraints=("The target is a product of three decimal digits from 1 through 9.",),
        )

    if case == "nt87":
        return _case(
            "next_palindrome_gap", {"n": (5678, 10, 19999)},
            lambda n: f"What is the smallest positive integer x such that x + {n} is a palindrome?",
            lambda n: _next_palindrome(n) - n,
            lambda n: next(x for x in range(1, 1001) if str(n + x) == str(n + x)[::-1]),
        )

    if case == "nt266":
        def candidates(width):
            for prefix in range(*_palindrome_prefix_bounds(width)):
                left = str(prefix)
                yield int(left + left[:width//2][::-1])

        def solve(width, divisor):
            return next(n for n in candidates(width) if n % divisor == 0)

        def reference(width, divisor):
            first, last = _widths(width)
            return next(n for n in range((first + divisor - 1) // divisor * divisor, last + 1, divisor)
                        if str(n) == str(n)[::-1])

        return _case(
            "least_divisible_palindrome", {"width": (4, 2, 6), "divisor": (3, 2, 11)},
            lambda width, divisor: f"What is the least positive {width}-digit palindrome divisible by {divisor}?",
            solve, reference, valid=lambda width, divisor: any(n % divisor == 0 for n in candidates(width)),
            sample=lambda rng: {"width": rng.randint(2, 6),
                                "divisor": rng.choice((2, 3, 4, 5, 6, 7, 8, 9, 11))},
            constraints=("There is a positive palindrome of the specified width divisible by the divisor.",),
        )

    if case == "ns193":
        def sample(rng):
            return {"cube": rng.randint(10, 99) ** 3}

        return _case(
            "cube_root_digit_sum", {"cube": (912673, 1000, 970299)},
            lambda cube: f"The cube of the two-digit positive integer AB is {cube:,}. What is A + B?",
            lambda cube: sum(divmod(_integer_root(cube, 3), 10)),
            lambda cube: sum(map(int, str(next(n for n in range(10, 100) if n ** 3 == cube)))),
            valid=lambda cube: _integer_root(cube, 3) ** 3 == cube, sample=sample,
            constraints=("The given integer is a perfect cube with a two-digit positive cube root.",),
        )

    if case == "nt214":
        def sample(rng):
            a, b = rng.sample(range(10), 2)
            return {"lower": rng.randrange(100, 500), "upper": rng.randrange(550, 1300),
                    "a": a, "b": b}

        return _case(
            "count_with_two_digits", {"lower": (500, 100, 500), "upper": (1000, 550, 1300),
                                      "a": (3, 0, 9), "b": (4, 0, 9)},
            lambda lower, upper, a, b: f"How many integers strictly between {lower} and {upper} "
            f"contain both the digit {a} and the digit {b}?",
            lambda lower, upper, a, b: sum(str(a) in str(n) and str(b) in str(n)
                                           for n in range(lower + 1, upper)),
            lambda lower, upper, a, b: sum({str(a), str(b)} <= set(str(n))
                                           for n in range(lower + 1, upper)),
            valid=lambda lower, upper, a, b: a != b, sample=sample,
            constraints=("The two required digits are distinct.",),
        )
    return None


def _next_palindrome(n):
    text = str(n)
    width = len(text)

    def reflect(left):
        return int(left + left[:width // 2][::-1])

    left = text[:(width + 1) // 2]
    if reflect(left) > n:
        return reflect(left)
    next_left = str(int(left) + 1)
    return 10 ** width + 1 if len(next_left) > len(left) else reflect(next_left)


def _number_misc(case):
    if case == "nt24":
        return _case(
            "multiples_count_inverse", {"count": (2, 1, 12)},
            lambda count: f"For how many positive integers x are there exactly "
            f"{count} positive two-digit multiples of x?",
            lambda count: sum(_count_multiples(10, 99, x) == count for x in range(1, 100)),
            lambda count: sum(sum(n % x == 0 for n in range(10, 100)) == count for x in range(1, 100)),
        )
    if case == "nt117":
        def solve(divisor):
            return Fraction(((9 // divisor + 1) + 99 // divisor) * divisor, 2)

        def reference(divisor):
            values = [n for n in range(10, 100) if n % divisor == 0]
            return Fraction(sum(values), len(values))

        return _case("mean_two_digit_multiples", {"divisor": (7, 2, 55)},
                     lambda divisor: f"What is the arithmetic mean of the positive two-digit multiples of {divisor}?",
                     solve, reference)

    if case == "nt128":
        def candidates(n):
            return (x * y for x, y in combinations(_factors(n), 2) if n % (x * y))

        def reference(n):
            factors = set(_factors(n))
            return next(t for t in range(2, n * n + 1) if t not in factors
                        and any(t % x == 0 and t // x != x and t // x in factors for x in factors))

        return _case(
            "least_nondivisor_product", {"n": (36, 4, 144)},
            lambda n: f"What is the least possible product of two distinct positive divisors "
            f"of {n} if their product does not divide {n}?",
            lambda n: min(candidates(n)), reference,
            valid=lambda n: not _is_prime(n),
            sample=lambda rng: {"n": rng.randint(2, 12) * rng.randint(2, 12)},
            constraints=("The number n is composite, so two distinct divisors with a nondivisor product exist.",),
        )
    if case in {"nt231", "ns2", "ns185", "nt235"}:
        return _gcd_lcm_cases(case)

    if case == "nt261":
        return _case(
            "greatest_odd_divisor_count_number", {"bound": (100, 3, 400)},
            lambda bound: f"What is the greatest positive integer less than {bound} "
            "with an odd number of positive divisors?",
            lambda bound: isqrt(bound - 1) ** 2,
            lambda bound: next(n for n in range(bound - 1, 0, -1) if len(_factors(n)) % 2),
        )

    if case in {"nt291", "ns291"}:
        return _case(
            "gcd_plus_constant", {"a": (6432, 100, 7000), "b": (132, 10, 220), "offset": (11, 1, 35)},
            lambda a, b, offset: f"What do you get when the greatest common divisor of {a} and {b} "
            f"is increased by {offset}?",
            lambda a, b, offset: gcd(a, b) + offset,
            lambda a, b, offset: max(d for d in _factors(b) if a % d == 0) + offset,
        )

    if case in {"nt347", "nt399"}:
        least = case == "nt347"
        d, u = (7, 9) if least else (5, 5)

        def solve(divisor, units, bound=None):
            step = lcm(divisor, 10)
            residue = next(n for n in range(1, step + 1) if n % divisor == 0 and n % 10 == units)
            return residue if least else _count_multiples(1 - residue, bound - 1 - residue, step)

        def sample(rng):
            divisor = rng.randint(2, 15)
            p = {"divisor": divisor, "units": rng.randint(1, 10) * divisor % 10}
            if not least:
                p["bound"] = rng.randint(20, 200)
            return p

        def render(divisor, units, bound=None):
            if least:
                return f"What is the smallest positive multiple of {divisor} ending in digit {units}?"
            return f"How many positive multiples of {divisor} less than {bound} end in digit {units}?"

        def reference(divisor, units, bound=None):
            found = (n for n in range(divisor, bound or 151, divisor) if n % 10 == units)
            return next(found) if least else sum(1 for _ in found)

        return _case(
            "multiples_with_units_digit", {"divisor": (d, 2, 15), "units": (u, 0, 9),
                                           **({} if least else {"bound": (100, 20, 200)})},
            render, solve, reference, sample=sample,
            valid=lambda divisor, units, **p: units % gcd(divisor, 10) == 0,
            constraints=("The units digit is divisible by the greatest common divisor of 10 and the divisor.",),
        )
    if case in {"nt427", "nt569", "ns225", "ns276", "nt539", "ns412"}:
        return _integer_products(case)
    if case in {"nt525", "nt799", "nt812", "nt839", "nt868", "ns221", "ns245", "ns510"}:
        return _remainder_word(case)
    if case == "nt684":
        return _case(
            "indexed_odd_multiple", {"index": (10, 1, 40), "divisor": (3, 1, 25)},
            lambda index, divisor: f"What is positive odd multiple number {index} of {divisor}, "
            "counting in increasing order?",
            lambda index, divisor: (2 * index - 1) * divisor,
            lambda index, divisor: [n for n in range(1, 2001, 2) if n % divisor == 0][index - 1],
            valid=lambda index, divisor: divisor % 2 == 1,
            sample=lambda rng: {"index": rng.randint(1, 40), "divisor": 2 * rng.randrange(13) + 1},
            constraints=("The divisor is odd so it has positive odd multiples.",),
        )
    if case == "nt721":
        return _case(
            "nearest_multiple", {"divisor": (15, 2, 80), "target": (2009, 100, 3000)},
            lambda divisor, target: f"Which multiple of {divisor} is closest to {target}?",
            lambda divisor, target: ((target + divisor // 2) // divisor) * divisor,
            lambda divisor, target: min(range(0, target + divisor + 1, divisor), key=lambda n: abs(n - target)),
            valid=lambda divisor, target: 2 * (target % divisor) != divisor,
            sample=lambda rng: _sample_nearest_multiple(rng),
            constraints=("The target is not exactly halfway between consecutive multiples.",),
        )
    if case == "ns0":
        return _case(
            "multiple_has_two_digits", {"divisor": (45, 2, 99), "bound": (1000, 101, 2000)},
            lambda divisor, bound: f"A positive multiple of {divisor} less than {bound} is chosen uniformly "
            "at random. What is the probability that it has exactly two digits?",
            lambda divisor, bound: Fraction(_count_multiples(10, 99, divisor), (bound - 1) // divisor),
            lambda divisor, bound: Fraction(sum(10 <= n < 100 for n in range(divisor, bound, divisor)),
                                            len(range(divisor, bound, divisor))),
        )
    if case == "ns175":
        return _case(
            "cyclic_position", {"steps": (11, 2, 30), "total": (139, 1, 400)},
            lambda steps, total: f"Tim walks around a circular cakewalk with {steps} numbered steps. "
            f"He counts his first step on position 1 and moves to the next position each time, "
            f"returning to position 1 after position {steps}. What position is he on at step {total}?",
            lambda steps, total: (total - 1) % steps + 1,
            lambda steps, total: (list(range(1, steps + 1)) * total)[total - 1],
        )
    if case == "ns348":
        return _case(
            "least_divisible_multiplier", {"a": (28, 2, 80), "divisor": (365, 2, 500)},
            lambda a, divisor: f"What is the least positive integer n for which {a}n is divisible by {divisor}?",
            lambda a, divisor: divisor // gcd(a, divisor),
            lambda a, divisor: next(n for n in range(1, divisor + 1) if a * n % divisor == 0),
        )
    if case == "ns493":
        return _case(
            "percent_residue_in_initial_interval", {"bound": (100, 10, 160), "divisor": (5, 2, 30),
                                                    "residue": (1, 0, 29)},
            lambda bound, divisor, residue: f"What percent of the integers from 1 through {bound}, "
            f"inclusive, leave remainder {residue} when divided by {divisor}?",
            lambda bound, divisor, residue: Fraction(100 * _count_multiples(1 - residue, bound - residue, divisor),
                                                    bound),
            lambda bound, divisor, residue: Fraction(100 * sum(n % divisor == residue
                                                              for n in range(1, bound + 1)), bound),
            valid=lambda bound, divisor, residue: residue < divisor,
            sample=lambda rng: _sample_named_modulus(rng, "bound", 10, 160),
            constraints=("The remainder is smaller than the divisor.",),
        )
    if case == "ns520":
        return _case(
            "greatest_gcd_at_fixed_sum", {"total": (80, 4, 200)},
            lambda total: f"Two positive integers have sum {total}. What is the greatest possible "
            "value of their greatest common divisor?",
            lambda total: total // min(p for p in _factorization(total)),
            lambda total: max(gcd(n, total - n) for n in range(1, total)),
        )
    return None


def _sample_nearest_multiple(rng):
    divisor = rng.randint(2, 80)
    target = rng.randint(100, 2999)
    return {"divisor": divisor, "target": target + int(2 * (target % divisor) == divisor)}


def _sample_named_modulus(rng, name, low, high):
    p = _sample_canonical_residue(rng, name, low, high)
    p["divisor"] = p.pop("modulus")
    return p


def _gcd_lcm_cases(case):
    if case == "nt231":
        def sample(rng):
            divisor = rng.randint(1, 20)
            return {"divisor": divisor, "multiple": divisor * rng.randint(1, 20)}

        return _case(
            "product_from_gcd_lcm", {"divisor": (6, 1, 20), "multiple": (36, 1, 400)},
            lambda divisor, multiple: f"Two positive integers have greatest common divisor {divisor} "
            f"and least common multiple {multiple}. What is their product?",
            lambda divisor, multiple: divisor * multiple,
            lambda divisor, multiple: next(a * b for a in _factors(multiple) for b in _factors(multiple)
                                            if gcd(a, b) == divisor and lcm(a, b) == multiple),
            valid=lambda divisor, multiple: multiple % divisor == 0, sample=sample,
            constraints=("The greatest common divisor divides the least common multiple.",),
        )
    if case == "nt235":
        def sample(rng):
            a, b = rng.sample(range(2, 9), 2)
            return {"a": a, "b": b, "multiple": lcm(a, b) * rng.randint(1, 25)}

        return _case(
            "gcd_from_ratio_and_lcm", {"a": (3, 2, 8), "b": (4, 2, 8), "multiple": (120, 1, 1400)},
            lambda a, b, multiple: f"Two positive integers are in the ratio {a}:{b} and have least common "
            f"multiple {multiple}. What is their greatest common divisor?",
            lambda a, b, multiple: multiple * gcd(a, b) // lcm(a, b),
            lambda a, b, multiple: next(gcd(x, y) for x in _factors(multiple) for y in _factors(multiple)
                                        if x * b == y * a and lcm(x, y) == multiple),
            valid=lambda a, b, multiple: multiple % (lcm(a, b) // gcd(a, b)) == 0,
            sample=sample,
            constraints=("The least common multiple is divisible by the least common multiple of the reduced ratio terms.",),
        )

    n, d, m = (40, 10, 280) if case == "ns2" else (120, 8, 3720)

    def valid(known, divisor, multiple):
        other, r = divmod(divisor * multiple, known)
        return r == 0 and gcd(known, other) == divisor and lcm(known, other) == multiple

    def sample(rng):
        divisor = rng.randint(1, 15)
        a = rng.randint(2, 16)
        b = rng.choice([i for i in range(2, 24) if gcd(a, i) == 1])
        return {"known": a * divisor, "divisor": divisor, "multiple": divisor * a * b}

    return _case(
        "other_integer_from_gcd_lcm", {"known": (n, 2, 240), "divisor": (d, 1, 15),
                                       "multiple": (m, 2, 6000)},
        lambda known, divisor, multiple: f"Two positive integers have greatest common divisor {divisor} "
        f"and least common multiple {multiple}. One of them is {known}. What is the other?",
        lambda known, divisor, multiple: divisor * multiple // known,
        lambda known, divisor, multiple: next(n for n in _factors(multiple)
                                               if gcd(known, n) == divisor and lcm(known, n) == multiple),
        valid=valid, sample=sample,
        constraints=("The known integer and gcd × lcm / known must have the stated gcd and lcm.",),
    )


def _integer_products(case):
    if case == "nt427":
        return _case(
            "maximum_product_width", {"a": (4, 1, 8), "b": (3, 1, 8)},
            lambda a, b: f"What is the greatest possible number of digits in the product of "
            f"an {a}-digit positive integer and a {b}-digit positive integer?",
            lambda a, b: a + b,
            lambda a, b: len(str(_widths(a)[1] * _widths(b)[1])),
        )
    if case in {"nt569", "ns225", "ns276", "nt539", "ns412"}:
        factors = {
            "nt569": ((2, 12), (5, 8)),
            "ns225": ((4, 5), (5, 13)),
            "ns276": ((2, 3), (3, 1), (4, 3), (5, 8)),
            "nt539": ((2, 3), (3, 2), (5, 1)),
            "ns412": ((6, 2), (10, 2), (15, 4)),
        }[case]
        domains = {chr(97 + i): (exponent, 1, 20) for i, (_, exponent) in enumerate(factors)}

        def values(p):
            return [base ** e for (base, _), e in zip(factors, p.values())]

        def render(**p):
            terms = [f"${base}^{{{e}}}$" for (base, _), e in zip(factors, p.values())]
            if case == "nt539":
                return f"How many positive factors does {' × '.join(terms)} have?"
            if case == "ns412":
                return f"Find the greatest common divisor of {terms[0]} × {terms[1]} and {terms[2]}."
            return f"How many decimal digits are in {' × '.join(terms)}?"

        def solve(**p):
            nums = values(p)
            if case == "nt539":
                return prod(e + 1 for e in p.values())
            if case == "ns412":
                return gcd(nums[0] * nums[1], nums[2])
            return len(str(prod(nums)))

        def reference(**p):
            if case == "nt539":
                return prod(len(range(e + 1)) for e in p.values())
            if case == "ns412":
                exponents = [e for e in p.values()]
                return 3 ** min(exponents[0], exponents[2]) * 5 ** min(exponents[1], exponents[2])
            n = prod(values(p))
            return next(k for k in range(1, 100) if n < 10 ** k)

        return _case("prime_and_power_products", domains, render, solve, reference)
    return None


def _remainder_word(case):
    if case == "nt525":
        return _case(
            "packaging_remainder", {"count": (25197624, 50, 30000000), "size": (4, 2, 40)},
            lambda count, size: f"If {count:,} hot dogs are packed in groups of {size}, "
            "how many hot dogs will be left over after making as many full groups as possible?",
            lambda count, size: count % size,
            lambda count, size: count - (count // size) * size,
        )
    if case == "nt799":
        return _case(
            "smaller_even_deal", {"cards": (52, 25, 120), "people": (8, 2, 24)},
            lambda cards, people: f"If {cards} cards are dealt among {people} people as evenly as possible, "
            f"how many people get fewer than {cards // people + 1} cards?",
            lambda cards, people: people - cards % people,
            lambda cards, people: sum(len(range(i, cards, people)) < cards // people + 1 for i in range(people)),
            constraints=("The threshold for the question is floor(cards / people) + 1.",),
        )
    if case in {"nt812", "ns221"}:
        count = 99 if case == "nt812" else 9
        square_sum = case == "ns221"

        def solve(n):
            return n * (n + 1) * (2 * n + 1) // 6 % 10 if square_sum else (
                0 if n >= 5 else prod(range(1, n + 1)) % 10)

        def reference(n):
            return (sum(k * k for k in range(1, n + 1)) if square_sum else factorial(n)) % 10

        return _case(
            "units_digit_of_integer_series", {"n": (count, 2, 150)},
            lambda n: f"What is the units digit of the {'sum of the squares' if square_sum else 'product'} "
            f"of the first {n} positive integers?",
            solve, reference,
        )

    if case == "nt868":
        return _case(
            "sum_initial_interval_remainder", {"last": (10, 2, 150), "divisor": (8, 2, 25)},
            lambda last, divisor: f"What is the remainder when 1 + 2 + … + {last} is divided by {divisor}?",
            lambda last, divisor: (last * (last + 1) // 2) % divisor,
            lambda last, divisor: sum(range(1, last + 1)) % divisor,
        )

    if case == "nt839":
        def sample(rng):
            divisor = rng.randint(2, 30)
            return {"first": rng.randint(2, 14), "step": divisor * rng.randint(1, 5),
                    "terms": rng.randint(6, 35), "divisor": divisor}

        return _case(
            "progression_product_remainder",
            {"first": (3, 2, 14), "step": (10, 2, 150), "terms": (20, 6, 35), "divisor": (5, 2, 30)},
            lambda first, step, terms, divisor: f"Find the remainder of the product "
            f"{first} × {first + step} × {first + 2 * step} × … × {first + (terms - 1) * step} "
            f"upon division by {divisor}.",
            lambda first, step, terms, divisor: pow(first, terms, divisor),
            lambda first, step, terms, divisor: prod(first + i * step for i in range(terms)) % divisor,
            valid=lambda first, step, terms, divisor: step % divisor == 0, sample=sample,
            constraints=("The progression step is a multiple of the divisor.",),
        )

    if case == "ns245":
        return _case(
            "units_digit_odd_range_product", {"low": (0, 0, 8), "high": (12, 12, 80)},
            lambda low, high: f"What is the units digit of the product of all odd integers "
            f"strictly between {low} and {high}?",
            lambda low, high: reduce(lambda a, b: a * b % 10, range(low + 1 + low % 2, high, 2), 1),
            lambda low, high: prod(n for n in range(low + 1, high) if n % 2) % 10,
        )

    if case == "ns510":
        return _case(
            "hundreds_digit_consecutive_product", {"start": (5, 2, 25), "terms": (6, 3, 15)},
            lambda start, terms: f"What is the hundreds digit of the product of the consecutive integers "
            f"{start} through {start + terms - 1}, inclusive? Treat a missing hundreds digit as 0.",
            lambda start, terms: (factorial(start + terms - 1) // factorial(start - 1)) // 100 % 10,
            lambda start, terms: int(str(prod(range(start, start + terms))).zfill(3)[-3]),
        )
    return None


def _falling(n, k):
    return prod(range(n - k + 1, n + 1)) if 0 <= k <= n else 0


def _permutation_reference(n, k):
    if k == 0:
        return 1
    return n * _permutation_reference(n - 1, k - 1)


def _choice_reference(n, k):
    row = [1]
    for _ in range(n):
        row = [a + b for a, b in zip([0] + row, row + [0])]
    return row[k] if 0 <= k <= n else 0


def _multinomial(sizes):
    return factorial(sum(sizes)) // prod(map(factorial, sizes))


def _multinomial_reference(sizes):
    left, ways = sum(sizes), 1
    for count in sizes:
        ways *= _choice_reference(left, count)
        left -= count
    return ways


def _counting(case):
    if case in {"ct43", "ct83", "ct86", "ct186", "ct187", "ct200", "ct203", "ct251", "ct252",
                "ct345", "ct506", "ct571", "cs99", "cs132", "cs301", "cs433", "cs437"}:
        return _arrangements(case)

    if case in {"ct97", "ct167", "ct214", "ct467", "cs2", "cs223", "cs250",
                "cs326", "cs449", "ct165", "cs455", "ct648", "ct134", "cs189"}:
        return _sampling(case)

    if case in {"ct6", "ct7", "ct102", "ct264", "ct276", "ct468", "ct551", "ct578", "ct608",
                "ct610", "ct625", "ct630", "ct678", "ct719", "cs82", "cs86", "cs155"}:
        return _independent_events(case)

    if case in {"ct23", "ct143", "ct161", "ct223", "ct225", "ct228", "ct229", "ct235",
                "ct544", "ct545", "ct575", "ct632", "ct654", "ct664", "ct744", "ct749",
                "cs91", "cs299", "cs318", "cs363"}:
        return _integer_events(case)

    if case in {"ct94", "ct210", "ct212", "ct233", "ct263", "ct274", "ct301", "ct311",
                "ct457", "ct466", "ct496", "ct521", "ct588", "ct622", "ct695", "ct723",
                "ct738", "ct740", "ct752", "ct760", "cs72", "cs144", "cs181", "cs290",
                "cs335", "cs385", "cs393", "cs401", "cs420", "cs471"}:
        return _counting_digits(case)

    if case in {"ct75", "ct82", "ct114", "ct142", "ct154", "ct189", "ct219", "ct313",
                "ct483", "ct497", "ct501", "cs95", "cs96", "cs147", "cs232", "cs295",
                "cs320", "cs323", "cs446"}:
        return _binomial_factorial(case)

    if case in {"ct24", "ct198", "ct245", "ct250", "ct407", "ct510", "ct531", "ct532",
                "ct534", "ct585", "ct594", "ct614", "ct659", "ct662", "ct675", "ct692",
                "ct758", "cs41", "cs69", "cs85", "cs116", "cs136", "cs139", "cs256",
                "cs280", "cs312", "cs341", "cs365", "cs405", "cs422"}:
        return _other_counting(case)
    return None


def _arrangements(case):
    if case == "ct43":
        return _case(
            "arrangement_with_two_fixed_ends", {"length": (4, 3, 6)},
            lambda length: f"How many {length}-letter sequences can be formed from EQUALS "
            "without repeating a letter, with L first and Q last?",
            lambda length: _falling(4, length - 2),
            lambda length: sum(1 for _ in permutations("EUAS", length - 2)),
        )
    if case == "ct83":
        return _case(
            "outfits_excluding_monochrome", {"colors": (6, 2, 14)},
            lambda colors: f"I have one shirt, one pair of pants and one hat in each of the "
            f"same {colors} colors. How many outfits can I make with one item of each kind, "
            "if the three items cannot all be the same color?",
            lambda colors: colors ** 3 - colors,
            lambda colors: sum(not a == b == c for a, b, c in product(range(colors), repeat=3)),
        )
    if case == "ct86":
        return _case(
            "split_identical_copies", {"copies": (6, 3, 100)},
            lambda copies: f"A library has {copies} indistinguishable copies of a book. "
            "How many ways can the copies be split into those in the library and those "
            "checked out, with at least one copy in each group?",
            lambda copies: copies - 1,
            lambda copies: sum(a + b == copies for a in range(1, copies) for b in range(1, copies)),
        )
    if case == "ct186":
        return _case(
            "one_repeated_book", {"identical": (2, 2, 5), "other": (3, 1, 7)},
            lambda identical, other: f"How many shelf arrangements are possible with {identical} "
            f"identical math books and {other} other books, all different from each other and from the math book?",
            lambda identical, other: factorial(identical + other) // factorial(identical),
            lambda identical, other: _choice_reference(identical + other, identical) * factorial(other),
        )
    if case in {"ct187", "ct251"}:
        needs_vowel = case == "ct187"

        def render(length, vowels, consonants):
            letters = sorted("AEIOU"[:vowels] + "BCDFGHJK"[:consonants])
            category = "vowel" if needs_vowel else "consonant"
            return (f"How many {length}-letter strings from {', '.join(letters)} contain at least "
                    f"one {category}? Letters can be reused.")

        def solve(length, vowels, consonants):
            return (vowels + consonants) ** length - (consonants if needs_vowel else vowels) ** length

        def reference(length, vowels, consonants):
            needed, other = (vowels, consonants) if needs_vowel else (consonants, vowels)
            return sum(comb(length, k) * needed ** k * other ** (length - k)
                       for k in range(1, length + 1))

        return _case("letter_strings_with_required_class",
                     {"length": (4, 2, 8), "vowels": (2, 1, 5), "consonants": (3, 1, 8)},
                     render, solve, reference)
    if case == "ct200":
        return _case(
            "fixed_tile_word", {"xs": (3, 1, 5), "os": (2, 1, 5)},
            lambda xs, os: f"Randomly arrange {xs} tiles marked X and {os} tiles marked O in a row. "
            f"What is the probability of reading {'XO' * min(xs, os) + 'X' * max(0, xs - os) + 'O' * max(0, os - xs)}?",
            lambda xs, os: Fraction(1, comb(xs + os, xs)),
            lambda xs, os: Fraction(1, sum(sum(word) == xs for word in product((0, 1), repeat=xs + os))),
        )
    if case in {"ct203", "ct571", "cs301", "cs433", "cs437"}:
        values = {
            "ct203": (3, 2, 2), "ct571": (3, 4), "cs301": (4, 3, 1),
            "cs433": (2, 2), "cs437": (2, 5),
        }[case]
        prompts = {
            "ct203": lambda a, b, c: f"Cory has {a} apples, {b} oranges and {c} bananas. "
            f"He eats one piece of fruit each day for {a+b+c} days. Fruit of the same type "
            "is indistinguishable. In how many orders can he eat the fruit?",
            "ct571": lambda a, b: f"How many shelf arrangements are possible with {a} identical copies "
            f"of Introduction to Geometry and {b} identical copies of Introduction to Number Theory?",
            "cs301": lambda a, b, c: f"There are {a+b+c} pens in a row. In how many ways can "
            f"{a} be assigned to dogs, {b} to cats and {c} to roosters?",
            "cs433": lambda a, b: f"How many distinct rows can be made from {a} indistinguishable IMO "
            f"gold medals and {b} indistinguishable IPhO gold medals?",
            "cs437": lambda a, b: f"How many distinct rows can be planted using {a} identical Golden "
            f"Delicious apple trees and {b} identical Bartlett pear trees?",
        }
        domains = {name: (value, 1, 7) for name, value in zip("abc", values)}
        return _case("multiset_arrangement", domains, prompts[case],
                     lambda **p: _multinomial(tuple(p.values())),
                     lambda **p: _multinomial_reference(tuple(p.values())))

    if case in {"ct252", "ct345", "cs99"}:
        if case == "cs99":
            return _case(
                "single_contiguous_block", {"sons": (4, 1, 6), "daughters": (3, 2, 6)},
                lambda sons, daughters: f"How many ways can the {sons} sons and {daughters} "
                f"daughters in the Smith family sit in a row of {sons + daughters} chairs "
                "if all daughters sit together?",
                lambda sons, daughters: factorial(sons + 1) * factorial(daughters),
                lambda sons, daughters: (sons + 1) * _permutation_reference(sons, sons)
                * _permutation_reference(daughters, daughters),
            )

        def render(a, b, c=None):
            if c is None:
                return (f"How many ways can {a} distinct math books and {b} distinct English books "
                        "be arranged on a shelf if all books of each subject must stay together?")
            return (f"In how many ways can {a} Cubs, {b} Red Sox and {c} Yankees be seated "
                    "in a row at an All-Star press conference if each team's players sit together?")

        values = (3, 5) if case == "ct252" else (3, 3, 2)
        return _case(
            "separate_contiguous_blocks", {name: (n, 1, 6) for name, n in zip("abc", values)},
            render, lambda **p: factorial(len(p)) * prod(factorial(n) for n in p.values()),
            lambda **p: sum(prod(_permutation_reference(p[name], p[name]) for name in order)
                            for order in permutations(p)),
        )
    if case in {"ct506", "cs132"}:
        race = case == "ct506"
        if race:
            return _case(
                "race_finishing_orders", {"racers": (3, 2, 9)},
                lambda racers: f"There are {racers} participants in a broomstick race. "
                "If there are no ties, how many finishing orders are possible?",
                factorial_named("racers"), lambda racers: _permutation_reference(racers, racers),
            )
        return _case(
            "all_assignments_guessed", {"anonymous": (4, 2, 9), "students": (20, 12, 32)},
            lambda anonymous, students: f"In a class of {students}, {anonymous} students turn "
            "in unsigned assignments and everyone else signs theirs. If the teacher matches "
            "the unsigned assignments to their authors uniformly at random, what is the "
            "probability that she assigns every paper to its correct author?",
            lambda anonymous, students: Fraction(1, factorial(anonymous)),
            lambda anonymous, students: Fraction(1, _permutation_reference(anonymous, anonymous)),
        )
    return None


def factorial_named(name):
    return lambda **p: factorial(p[name])


def _sampling(case):
    if case in {"ct97", "cs449", "cs250"}:
        if case == "ct97":
            domains = {"a": (2, 2, 10), "b": (3, 1, 12), "c": (10, 1, 12)}
            draw = 2
            prompt = lambda a, b, c: (
                f"A jar contains {a} red, {b} green and {c} white marbles. Two are chosen "
                "uniformly at random without replacement. What is the probability both are red?")
        elif case == "cs449":
            domains = {"a": (5, 3, 10), "b": (6, 1, 10), "c": (2, 1, 7)}
            draw = 3
            prompt = lambda a, b, c: (
                f"A Senate committee has {a} Republicans, {b} Democrats and {c} Independents. "
                "What is the probability that a uniformly chosen subcommittee of three consists "
                "entirely of Republicans?")
        else:
            domains = {"a": (4, 2, 9), "b": (21, 10, 30)}
            draw = 2
            prompt = lambda a, b: (
                f"A class has {a+b} students, of whom {a} are Smith siblings from the same multiple birth. "
                "Two students are chosen uniformly at random to represent the class. "
                "What is the probability both are from that group of siblings?")

        def reference(a, b, c=0):
            cases = list(combinations(range(a + b + c), draw))
            return Fraction(sum(max(s) < a for s in cases), len(cases))

        return _case(
            "all_draws_from_one_group", domains, prompt,
            lambda a, b, c=0: Fraction(comb(a, draw), comb(a + b + c, draw)), reference,
        )

    if case in {"ct167", "ct214", "cs2"}:
        mode = {"ct167": "different", "ct214": "same", "cs2": "any"}[case]

        def acceptable(x, y):
            return mode == "any" or (x == y) == (mode == "same")

        def render(boys, girls):
            condition = "" if mode == "any" else f" The officers must be of {mode} genders."
            return (f"A club has {boys} boys and {girls} girls. In how many ways can a president and "
                    f"a vice-president be chosen if they must be different people?{condition}")

        def solve(boys, girls):
            if mode == "different":
                return 2 * boys * girls
            if mode == "same":
                return boys * (boys - 1) + girls * (girls - 1)
            return (boys + girls) * (boys + girls - 1)

        return _case(
            "club_officer_assignments", {"boys": (10, 2, 22), "girls": (10, 2, 22)}, render, solve,
            lambda boys, girls: sum(acceptable(x < boys, y < boys)
                                    for x, y in permutations(range(boys + girls), 2)),
        )

    if case == "ct467":
        return _case(
            "ordered_deck_color_probability", {"ranks": (13, 2, 16)},
            lambda ranks: f"A deck contains {ranks} ranks in each of four suits, two red "
            "and two black, with one card per rank and suit. After shuffling it uniformly, "
            "what is the probability the top card is red and the second card is black?",
            lambda ranks: Fraction(ranks, 4 * ranks - 1),
            lambda ranks: Fraction(sum(a < 2 * ranks <= b for a, b in permutations(range(4 * ranks), 2)),
                                   4 * ranks * (4 * ranks - 1)),
        )
    if case == "cs223":
        return _case(
            "uniform_color_complement", {"hockey": (3, 1, 12), "football": (2, 1, 12),
                                         "baseball": (7, 1, 12)},
            lambda hockey, football, baseball: f"Morgan has {hockey} hockey shirts, {football} football "
            f"shirts and {baseball} baseball shirts. What is the probability a uniformly chosen shirt "
            "is not a baseball shirt?",
            lambda hockey, football, baseball: Fraction(hockey + football, hockey + football + baseball),
            lambda hockey, football, baseball: 1 - Fraction(baseball, hockey + football + baseball),
        )
    if case == "cs326":
        return _case(
            "separate_groups_unordered", {"upper": (5, 4, 14), "lower": (10, 8, 18),
                                          "choose_upper": (4, 2, 4), "choose_lower": (8, 2, 8)},
            lambda upper, lower, choose_upper, choose_lower: f"A Greek army unit has {upper} upper-class "
            f"and {lower} lower-class soldiers. How many different battalions consist of "
            f"{choose_upper} upper-class and {choose_lower} lower-class soldiers?",
            lambda upper, lower, choose_upper, choose_lower: comb(upper, choose_upper) * comb(lower, choose_lower),
            lambda upper, lower, choose_upper, choose_lower: _choice_reference(upper, choose_upper)
            * _choice_reference(lower, choose_lower),
        )
    if case in {"ct165", "cs455"}:
        if case == "ct165":
            domains = {"maroon": (4, 1, 7), "teal": (7, 1, 8), "cyan": (8, 1, 9), "sparkly": (1, 1, 7)}

            def render(maroon, teal, cyan, sparkly):
                return (f"Two identical fair dice each have {maroon+teal+cyan+sparkly} faces, "
                        f"{maroon} maroon, {teal} teal, {cyan} cyan and {sparkly} sparkly. "
                        "What is the probability that independent rolls give the same type of face?")
        else:
            domains = {"red": (3, 1, 5)}

            def render(red):
                return (f"Each of two fair cubes has {red} red faces and {6-red} white faces. "
                        "What is the probability of one red and one white result on independent rolls?")

        def solve(**p):
            if case == "ct165":
                return Fraction(sum(x * x for x in p.values()), sum(p.values()) ** 2)
            red = p["red"]
            return Fraction(2 * red * (6 - red), 36)

        def reference(**p):
            if case == "cs455":
                p["white"] = 6 - p["red"]
            labels = [name for name, n in p.items() for _ in range(n)]
            return Fraction(sum((x == y) == (case == "ct165") for x, y in product(labels, repeat=2)),
                            len(labels) ** 2)

        return _case("color_faces_two_dice", domains, render, solve, reference)
    if case == "ct648":
        return _case(
            "uniform_random_pairing", {"pairs": (15, 2, 24)},
            lambda pairs: f"A class of {2*pairs} students is uniformly paired for a quiz. "
            "What is the probability Margo is paired with Irma?",
            lambda pairs: Fraction(1, 2 * pairs - 1),
            lambda pairs: Fraction(prod(range(1, 2 * pairs - 2, 2)), prod(range(1, 2 * pairs, 2))),
            constraints=("The class size is twice the number of pairs.",),
        )
    if case in {"ct134", "cs189"}:
        extra = case == "cs189"

        def render(children):
            restriction = " Their youngest child may not sit in the other front seat." if extra else ""
            return (f"Mr. and Mrs. Lopez and their {children} children occupy a car with two front "
                    f"seats and {children} distinct back seats. The driver must be one of the two parents."
                    f"{restriction} How many seating arrangements are possible?")

        def reference(children):
            return sum(seats[0] < 2 and (not extra or seats[1] != children + 1)
                       for seats in permutations(range(children + 2)))

        return _case(
            "driver_and_passenger_constraints", {"children": (3 if extra else 2, 2, 5)},
            render, lambda children: 2 * (children if extra else children + 1) * factorial(children),
            reference,
        )
    return None


def _independent_events(case):
    if case == "ct6":
        return _case(
            "two_dice_thresholds", {"sides": (6, 3, 18), "first": (3, 2, 17), "second": (3, 1, 17)},
            lambda sides, first, second: f"Two independent fair dice each have faces numbered "
            f"1 through {sides}. What is the probability that the first roll is less "
            f"than {first} and the second roll is greater than {second}?",
            lambda sides, first, second: Fraction((first - 1) * (sides - second), sides ** 2),
            lambda sides, first, second: Fraction(sum(a < first and b > second
                                                       for a, b in product(range(1, sides + 1), repeat=2)),
                                                   sides ** 2),
            valid=lambda sides, first, second: first <= sides and second < sides,
            sample=lambda rng: _sample_dice_thresholds(rng),
            constraints=("The first threshold is at most the number of sides. The second is strictly smaller.",),
        )
    if case == "ct7":
        return _case(
            "probability_from_odds", {"wins": (3, 1, 60), "losses": (4, 1, 60)},
            lambda wins, losses: f"The odds in favor of drawing a prize are {wins}:{losses}. "
            "What is the probability of not drawing a prize?",
            lambda wins, losses: Fraction(losses, wins + losses),
            lambda wins, losses: 1 - Fraction(wins, wins + losses),
        )
    if case in {"ct102", "ct468", "ct719", "ct678"}:
        original_rolls = {"ct102": 6, "ct468": 6, "ct719": 3, "ct678": 3}[case]
        domains = {"rolls": (original_rolls, 2, 6), "sides": (6, 2, 12)}
        if case == "ct678":
            domains["excluded"] = (1, 1, 12)

        def render(rolls, sides, excluded=None):
            event = {
                "ct102": "all of the results are distinct",
                "ct468": "the product of the results is odd",
                "ct719": "the same result occurs on every roll",
                "ct678": f"the product of all factors (r − {excluded}), one for each roll r, is nonzero",
            }[case]
            return (f"A fair die with faces numbered 1 through {sides} is rolled independently "
                    f"{rolls} times. What is the probability that {event}?")

        def solve(rolls, sides, excluded=None):
            numer = {"ct102": _falling(sides, rolls), "ct468": ((sides + 1) // 2) ** rolls,
                     "ct719": sides, "ct678": (sides - 1) ** rolls}
            return Fraction(numer[case], sides ** rolls)

        def reference(rolls, sides, excluded=None):
            faces = range(1, sides + 1)
            if case == "ct102":
                wins = sum(1 for _ in combinations(faces, rolls)) * factorial(rolls)
            elif case == "ct719":
                wins = len({(face,) * rolls for face in faces})
            else:
                wins = prod(sum(face % 2 == 1 if case == "ct468" else face != excluded
                                for face in faces) for _ in range(rolls))
            return Fraction(wins, sides ** rolls)

        def sample(rng):
            sides = rng.randint(2, 12)
            return {"rolls": rng.randint(2, 6), "sides": sides,
                    **({"excluded": rng.randint(1, sides)} if case == "ct678" else {})}

        return _case("independent_die_rolls", domains, render, solve, reference,
                     valid=lambda rolls, sides, excluded=None: excluded is None or excluded <= sides,
                     sample=sample, constraints=("The excluded value is a face of the die.",)
                     if case == "ct678" else ())
    if case == "ct276":
        def solve(rolls, sides, even):
            p = Fraction(sides // 2, sides)
            return comb(rolls, even) * p ** even * (1 - p) ** (rolls - even)

        def reference(rolls, sides, even):
            return sum(Fraction((sides // 2) ** even * ((sides + 1) // 2) ** (rolls - even), sides ** rolls)
                       for values in product((0, 1), repeat=rolls) if sum(values) == even)

        return _case(
            "dice_even_results_binomial", {"rolls": (5, 2, 8), "sides": (12, 3, 20), "even": (2, 1, 8)},
            lambda rolls, sides, even: f"Roll {rolls} fair dice independently, each numbered from 1 "
            f"through {sides}. What is the probability that exactly {even} results are even?",
            solve, reference, valid=lambda rolls, sides, even: even <= rolls,
            sample=lambda rng: _sample_even_dice(rng),
            constraints=("The requested number of even results does not exceed the number of dice.",),
        )
    if case in {"ct264", "ct551"}:
        sports = case == "ct264"

        def render(trials, favorable, total):
            p = Fraction(favorable, total)
            if sports:
                return (f"The Grunters play the Screamers {trials} times, and the stronger Grunters team has a "
                        f"{100*p}% chance to win each independent game. What is the probability "
                        "that they win every game? Give a common fraction.")
            return (f"On each of the next {trials} days the probability of snowfall is {p}, "
                    "independently of the other days. What is the probability of no snow "
                    "during this period? Give a common fraction.")

        def sample(rng):
            total = 100 if sports else rng.randint(2, 20)
            return {"trials": rng.randint(2, 9), "favorable": rng.randrange(51 if sports else 1, total), "total": total}

        def solve(trials, favorable, total):
            p = Fraction(favorable if sports else total - favorable, total)
            return p ** trials

        def reference(trials, favorable, total):
            return Fraction(prod(favorable if sports else total - favorable for _ in range(trials)),
                            prod(total for _ in range(trials)))

        return _case(
            "all_independent_trials", {"trials": (4 if sports else 3, 2, 9),
                                        "favorable": (75 if sports else 3, 51 if sports else 1, 99),
                                        "total": (100 if sports else 4, 100 if sports else 2,
                                                  100 if sports else 20)},
            render, solve, reference, sample=sample,
            valid=lambda trials, favorable, total: favorable < total,
            constraints=("The favorable numerator is strictly smaller than its denominator.",),
        )
    if case == "ct578":
        return _case(
            "two_independent_percent_events", {"saturday": (60, 5, 95), "sunday": (25, 5, 95)},
            lambda saturday, sunday: f"It rains on Saturday with probability {saturday}% "
            f"and on Sunday with probability {sunday}%, independently. "
            "What is the probability of rain on both days, expressed as a percent?",
            lambda saturday, sunday: Fraction(saturday * sunday, 100),
            lambda saturday, sunday: 100 * Fraction(saturday, 100) * Fraction(sunday, 100),
        )
    if case == "ct608":
        def sample(rng):
            total = rng.randint(2, 20)
            return {"heads": rng.randrange(1, total), "total": total,
                    "gain": rng.randint(1, 12), "loss": rng.randint(1, 12)}

        return _case(
            "binary_payout_expectation", {"heads": (1, 1, 19), "total": (3, 2, 20),
                                          "gain": (3, 1, 12), "loss": (2, 1, 12)},
            lambda heads, total, gain, loss: f"A weighted coin lands heads with probability "
            f"{Fraction(heads,total)}. On a single toss you gain {gain} dollars for heads "
            f"and lose {loss} dollars for tails. What is the expected net gain in dollars?",
            lambda heads, total, gain, loss: Fraction(heads * (gain + loss), total) - loss,
            lambda heads, total, gain, loss: Fraction(sum([gain] * heads + [-loss] * (total - heads)), total),
            valid=lambda heads, total, **p: heads < total, sample=sample,
            constraints=("The heads numerator is strictly smaller than its denominator.",),
        )
    if case == "ct610":
        return _case(
            "die_decreasing_payout_expectation", {"sides": (6, 2, 30)},
            lambda sides: f"Roll a fair die with faces 1 through {sides}. On a result n, "
            f"you win {sides} − n dollars. What is the expected win in dollars?",
            lambda sides: Fraction(sides - 1, 2),
            lambda sides: Fraction(sum(sides - i for i in range(1, sides + 1)), sides),
        )
    if case == "ct625":
        def sample(rng):
            n = rng.randint(2, 10)
            a, b = rng.sample(range(n + 1), 2)
            if a + b == n:
                b = (b + 1) % (n + 1)
                if b == a:
                    b = (b + 1) % (n + 1)
            return {"flips": n, "a": a, "b": b}

        def reference(flips, a, b):
            totals = [sum(x) for x in product((0, 1), repeat=flips)]
            return Fraction(abs(totals.count(a) - totals.count(b)), len(totals))

        return _case(
            "binomial_probability_difference", {"flips": (3, 2, 10), "a": (2, 0, 10), "b": (3, 0, 10)},
            lambda flips, a, b: f"What is the positive difference between the probabilities "
            f"of exactly {a} heads and exactly {b} heads in {flips} independent fair coin tosses?",
            lambda flips, a, b: Fraction(abs(comb(flips, a) - comb(flips, b)), 2 ** flips),
            reference, valid=lambda flips, a, b: max(a, b) <= flips and a != b and a + b != flips,
            sample=sample, constraints=("Both counts are attainable and have different binomial coefficients.",),
        )
    if case == "ct630":
        return _case(
            "two_dice_square_sum", {"sides": (6, 2, 24)},
            lambda sides: f"Two fair dice numbered 1 through {sides} are rolled independently. "
            "What is the probability their sum is a perfect square?",
            lambda sides: Fraction(sum(min(n - 1, 2 * sides + 1 - n)
                                        for n in (i * i for i in range(2, isqrt(2*sides) + 1))), sides ** 2),
            lambda sides: Fraction(sum(isqrt(a + b) ** 2 == a + b
                                        for a, b in product(range(1, sides + 1), repeat=2)), sides ** 2),
        )
    if case == "cs82":
        return _case(
            "compare_two_binomial_counts", {"a": (3, 1, 7), "b": (2, 1, 7)},
            lambda a, b: f"Fair coin A is tossed {a} times and fair coin B is tossed {b} times, "
            "all tosses independent. What is the probability A produces more heads than B?",
            lambda a, b: Fraction(sum(comb(a, i) * comb(b, j)
                                       for i in range(1, a + 1) for j in range(min(i, b + 1))), 2 ** (a + b)),
            lambda a, b: Fraction(sum(sum(xs[:a]) > sum(xs[a:]) for xs in product((0, 1), repeat=a+b)),
                                  2 ** (a + b)),
        )
    if case == "cs86":
        return _case(
            "traffic_light_complement", {"green": (25, 10, 80), "yellow": (5, 2, 12), "red": (30, 10, 80)},
            lambda green, yellow, red: f"A traffic light cycle lasts {green+yellow+red} seconds: "
            f"{green} green, {yellow} yellow, then {red} red. At a uniformly random moment "
            "during the cycle, what is the probability the light is not green?",
            lambda green, yellow, red: Fraction(yellow + red, green + yellow + red),
            lambda green, yellow, red: 1 - Fraction(green, green + yellow + red),
        )
    if case == "cs155":
        return _case(
            "specified_coin_toss_sequence", {"tosses": (4, 2, 12)},
            lambda tosses: f"A fair nickel is flipped independently {tosses} times. What is the probability "
            f"of exactly this sequence: {', '.join(('Head', 'Tail')[i % 2] for i in range(tosses))}?",
            lambda tosses: Fraction(1, 2 ** tosses),
            lambda tosses: Fraction(1, sum(1 for _ in product((0, 1), repeat=tosses))),
        )
    return None


def _sample_dice_thresholds(rng):
    sides = rng.randint(3, 18)
    return {"sides": sides, "first": rng.randint(2, sides), "second": rng.randrange(1, sides)}


def _sample_even_dice(rng):
    rolls = rng.randint(2, 8)
    return {"rolls": rolls, "sides": rng.randint(3, 20), "even": rng.randint(1, rolls)}


def _integer_events(case):
    if case in {"ct544", "cs363", "cs91", "ct161", "cs299", "ct654"}:
        n = {"ct544": 5, "cs363": 4, "cs91": 9, "ct161": 17, "cs299": 5, "ct654": 7}[case]
        low_field = {"lower": (5, 1, 8)} if case == "ct161" else {}
        gap_field = {"gap": (2, 1, 4)} if case == "ct654" else {}
        odd = case in {"cs91", "ct161"}
        event = {
            "ct544": "their product is even", "cs363": "their product is even",
            "cs91": "both are odd", "ct161": "their product is odd",
            "cs299": "their sum is greater than their product",
        }

        def render(upper, lower=1, gap=None):
            condition = f"their positive difference is at least {gap}" if gap is not None else event[case]
            return (f"Two distinct integers are chosen uniformly from {lower} through "
                    f"{upper}, inclusive. What is the probability that {condition}?")

        def solve(upper, lower=1, gap=None):
            count = upper - lower + 1
            if gap is not None:
                winners = comb(count - gap + 1, 2)
            elif case == "cs299":
                winners = count - 1
            else:
                winners = comb(_count_multiples(lower - 1, upper - 1, 2), 2)
                if not odd:
                    winners = comb(count, 2) - winners
            return Fraction(winners, comb(count, 2))

        def reference(upper, lower=1, gap=None):
            pairs = list(combinations(range(lower, upper + 1), 2))
            if gap is not None:
                wins = sum(y - x >= gap for x, y in pairs)
            elif case == "cs299":
                wins = sum(x + y > x * y for x, y in pairs)
            else:
                wins = sum(x * y % 2 == odd for x, y in pairs)
            return Fraction(wins, len(pairs))

        low = 10 if low_field else 4
        return _case(
            "uniform_integer_pair_event", {"upper": (n, low, 35), **low_field, **gap_field},
            render, solve, reference,
        )
    if case == "ct23":
        def render(negative, positive):
            negatives = (-5, -8, -2, -1, -3, -4, -6, -7, -9, -10, -11, -12)
            positives = (7, 4, 1, 2, 3, 5, 6, 8, 9, 10, 11, 12)
            values = negatives[:negative] + positives[:positive]
            return ("Two distinct integers are chosen uniformly from the set "
                    f"{{{', '.join(map(str, values))}}}. What is the probability their product is negative?")

        return _case(
            "pair_opposite_signs", {"negative": (3, 1, 12), "positive": (2, 1, 12)},
            render, lambda negative, positive: Fraction(negative * positive, comb(negative + positive, 2)),
            lambda negative, positive: Fraction(sum(a * b < 0 for a, b in
                                                     combinations([*range(-negative, 0), *range(1, positive+1)], 2)),
                                                 comb(negative + positive, 2)),
        )
    if case in {"ct235", "ct545", "ct749", "cs318"}:
        remove = case in {"ct235", "cs318"}
        n, a, b = {"ct235": (50, 2, 3), "ct545": (25, 2, 5),
                   "ct749": (50, 5, 7), "cs318": (100, 3, 4)}[case]
        context = "card" if case == "ct545" else "ball"

        def render(upper, a, b):
            if remove:
                return (f"From the integers 1 through {upper}, remove every multiple "
                        f"of {a} or {b}. How many integers remain?")
            return (f"One {context} is chosen uniformly from {upper} {context}s numbered "
                    f"1 through {upper}. What is the probability its number is a multiple "
                    f"of {a} or {b}, including numbers divisible by both?")

        def solve(upper, a, b):
            n = upper // a + upper // b - upper // lcm(a, b)
            return upper - n if remove else Fraction(n, upper)

        def reference(upper, a, b):
            winners = sum(n % a == 0 or n % b == 0 for n in range(1, upper + 1))
            return upper - winners if remove else Fraction(winners, upper)

        def sample(rng):
            a, b = rng.sample(range(2, 16), 2)
            return {"upper": rng.randint(20, 300), "a": a, "b": b}

        return _case(
            "two_divisibility_sets", {"upper": (n, 20, 300), "a": (a, 2, 15), "b": (b, 2, 15)},
            render, solve, reference, sample=sample, valid=lambda upper, a, b: a != b,
            constraints=("The two divisors are distinct.",),
        )
    if case == "ct143":
        return _case(
            "fixed_units_divisibility_probability", {"units": (3, 0, 9), "divisor": (3, 2, 30)},
            lambda units, divisor: f"A three-digit positive integer is chosen uniformly from those "
            f"with units digit {units}. What is the probability it is divisible by {divisor}?",
            lambda units, divisor: Fraction(sum((10*n + units) % divisor == 0 for n in range(10, 100)), 90),
            lambda units, divisor: Fraction(sum(n % 10 == units
                                                for n in range(((99 // divisor) + 1) * divisor, 1000, divisor)), 90),
        )
    if case == "ct223":
        return _case(
            "units_digit_with_divisibility", {"divisor": (7, 2, 30), "bound": (1000, 100, 1500),
                                              "units": (3, 0, 9)},
            lambda divisor, bound, units: f"How many positive multiples of {divisor} "
            f"strictly below {bound} end with the digit {units}?",
            lambda divisor, bound, units: sum(n % 10 == units for n in range(divisor, bound, divisor)),
            lambda divisor, bound, units: sum(n % divisor == 0 for n in range(units or 10, bound, 10)),
        )
    if case == "ct225":
        return _case(
            "spinner_product_threshold", {"a": (5, 2, 14), "b": (10, 2, 16), "bound": (30, 3, 210)},
            lambda a, b, bound: f"Paco and Manu independently spin equal-probability spinners "
            f"numbered 1 through {a} and 1 through {b}, respectively. What is the probability "
            f"the product of the results is less than {bound}?",
            lambda a, b, bound: Fraction(sum(min(b, (bound - 1) // n) for n in range(1, a + 1)), a * b),
            lambda a, b, bound: Fraction(sum(x * y < bound for x, y in product(range(1, a+1), range(1, b+1))), a*b),
        )
    if case == "ct228":
        def reference(count):
            candidates = [n for n in range(2, 100) if all(n % k for k in range(2, isqrt(n) + 1))]
            return Fraction(sum((x + y) % 2 == 0 for x, y in combinations(candidates[:count], 2)), comb(count, 2))

        return _case(
            "first_primes_even_sum_probability", {"count": (7, 2, 20)},
            lambda count: f"Two distinct numbers are chosen uniformly from the first {count} primes. "
            "What is the probability their sum is even?",
            lambda count: Fraction(count - 2, count), reference,
        )
    if case == "ct229":
        return _case(
            "locker_sequence_with_position_constraints", {"upper": (30, 8, 70), "divisor": (3, 2, 8)},
            lambda upper, divisor: f"Lark's locker combination has three positions, each containing "
            f"an integer from 1 to {upper}. The first is odd, the second even and the third a "
            f"multiple of {divisor}. Repeated values are allowed. How many sequences are possible?",
            lambda upper, divisor: ((upper + 1) // 2) * (upper // 2) * (upper // divisor),
            lambda upper, divisor: prod(sum(pred(n) for n in range(1, upper+1))
                                        for pred in (lambda n: n % 2 == 1, lambda n: n % 2 == 0,
                                                     lambda n: n % divisor == 0)),
        )
    if case == "ct575":
        def render(a, b, c, d, divisor):
            return (f"Two integers are chosen uniformly without replacement from "
                    f"{{{a}, {b}, {c}, {d}}}. What is the probability their product is divisible by {divisor}?")

        def sample(rng):
            a, b, c, d = rng.sample(range(1, 21), 4)
            return {"a": a, "b": b, "c": c, "d": d, "divisor": rng.randint(2, 18)}

        return _case(
            "integer_set_product_divisibility", {"a": (3, 1, 20), "b": (4, 1, 20), "c": (5, 1, 20),
                                                  "d": (6, 1, 20), "divisor": (9, 2, 18)},
            render, lambda a, b, c, d, divisor: Fraction(sum(x*y % divisor == 0 for x, y in
                                                            combinations((a,b,c,d), 2)), 6),
            lambda a, b, c, d, divisor: Fraction(sum(y % (divisor // gcd(x, divisor)) == 0 for x, y in
                                                     permutations((a,b,c,d), 2)), 12),
            valid=lambda a, b, c, d, divisor: len({a, b, c, d}) == 4, sample=sample,
            constraints=("The four integers in the set are distinct.",),
        )
    if case == "ct632":
        return _case(
            "sum_expectation_without_replacement", {"count": (5, 2, 30)},
            lambda count: f"A bag contains {count} marbles numbered 1 through {count}. "
            "What is the expected sum of the numbers on two marbles drawn uniformly without replacement?",
            lambda count: count + 1,
            lambda count: Fraction(sum(a+b for a,b in combinations(range(1,count+1),2)), comb(count,2)),
        )
    if case == "ct664":
        return _case(
            "integer_pairs_square_plus_linear", {"bound": (22, 4, 90)},
            lambda bound: f"How many ordered pairs of positive integers (m,n) satisfy m² + n < {bound}?",
            lambda bound: sum(bound - 1 - m*m for m in range(1, isqrt(bound - 2) + 1)),
            lambda bound: sum(m*m+n < bound for m,n in product(range(1,bound),repeat=2)),
        )
    return None


def _counting_digits(case):
    unrestricted_palindromes = {"ct210": 4, "ct622": 5, "cs420": 4}
    if case in unrestricted_palindromes:
        return _case(
            "count_fixed_width_palindromes", {"width": (unrestricted_palindromes[case], 2, 7)},
            lambda width: f"How many positive {width}-digit integers read the same forwards and backwards?",
            lambda width: 9 * 10 ** ((width - 1) // 2),
            lambda width: sum(1 for _ in range(*_palindrome_prefix_bounds(width))),
        )

    restricted_palindromes = {"ct740": (7, "7, 8, 9", 3), "cs290": (5, "1, 2, 9", 3),
                              "cs401": (4, "2, 3, 4, 5", 4)}
    if case in restricted_palindromes:
        n, digits, count = restricted_palindromes[case]
        return _case(
            "count_palindromes_from_digit_set", {"width": (n, 2, 9)},
            lambda width: f"How many positive {width}-digit palindromes can be made using only "
            f"digits {digits}, with repetition allowed?",
            lambda width: count ** ((width + 1) // 2),
            lambda width: sum(1 for _ in product(range(count), repeat=(width + 1) // 2)),
        )

    if case in {"ct94", "ct496", "ct723", "ct752"}:
        width, name, prompt, solve, reference = {
            "ct94": (3, "count_fixed_width_integers", "How many positive {}-digit integers are there?",
                     lambda w: 9 * 10 ** (w - 1), lambda w: len(range(10 ** (w - 1), 10 ** w))),
            "ct496": (2, "probability_distinct_digits", "What is the probability that a uniformly "
                      "chosen positive {}-digit integer has all digits different?",
                      lambda w: Fraction(_falling(9, w-1), 10 ** (w-1)),
                      lambda w: Fraction(sum(len(set(str(n))) == w for n in range(10 ** (w-1), 10 ** w)),
                                         9 * 10 ** (w-1))),
            "ct723": (3, "count_only_odd_digits", "How many positive {}-digit integers use only odd digits?",
                      lambda w: 5 ** w, lambda w: sum(1 for _ in product("13579", repeat=w))),
            "ct752": (2, "count_only_prime_digits", "How many positive {}-digit integers have each digit prime?",
                      lambda w: 4 ** w, lambda w: sum(1 for _ in product("2357", repeat=w))),
        }[case]
        return _case(name, {"width": (width, 2, 5)}, lambda width: prompt.format(width),
                     lambda width: solve(width), lambda width: reference(width))

    if case in {"ct233", "ct263", "ct301"}:
        width = 4 if case == "ct301" else 3
        a, b = (2, 3) if case == "ct301" else (7, 9)
        avoid = case == "ct233"

        def render(width, a, b):
            event = f"contain neither digit {a} nor digit {b}" if avoid else f"contain digit {a} or digit {b} or both"
            return f"How many positive {width}-digit integers {event}?"

        def solve(width, a, b):
            without = (7 + int(0 in (a,b))) * 8 ** (width - 1)
            return without if avoid else 9 * 10 ** (width - 1) - without

        def reference(width, a, b):
            banned = {str(a), str(b)}
            return sum(bool(banned & set(str(n))) != avoid for n in range(10 ** (width - 1), 10 ** width))

        def sample(rng):
            a, b = rng.sample(range(10), 2)
            return {"width": rng.randint(2, 4), "a": a, "b": b}

        return _case(
            "presence_of_two_digits", {"width": (width, 2, 4), "a": (a, 0, 9), "b": (b, 0, 9)},
            render, solve, reference, sample=sample, valid=lambda width, a, b: a != b,
            constraints=("The two digits are distinct.",),
        )

    if case in {"ct274", "ct311", "ct457", "ct588"}:
        original = {"ct274": (2, 2, 9, 9), "ct311": (2, 2, 5, 5, 9, 9),
                    "ct457": (2, 2, 2, 9, 9), "ct588": (2, 0, 0, 4)}[case]
        fields = "abcdef"[:len(original)]

        def solve(**p):
            sizes = [list(p.values()).count(d) for d in range(10)]
            ways = _multinomial(sizes)
            if sizes[0]:
                sizes[0] -= 1
                ways -= _multinomial(sizes)
            return ways

        def render(**p):
            return (f"How many distinct positive {len(fields)}-digit integers can be "
                    f"formed using these digits exactly as listed, in any order: {', '.join(map(str,p.values()))}?")

        def sample(rng):
            values = [rng.randint(1, 9)] + [rng.randrange(10) for _ in fields[1:]]
            rng.shuffle(values)
            return dict(zip(fields, values))

        return _case(
            "distinct_numbers_from_digit_multiset",
            {name: (value, 0, 9) for name, value in zip(fields, original)},
            render, solve, lambda **p: len({x for x in permutations(p.values()) if x[0]}),
            sample=sample, valid=lambda **p: any(p.values()),
            constraints=("At least one digit is nonzero. The first digit of an integer cannot be zero.",),
        )

    if case in {"ct466", "cs393"}:
        original = (1,2,3,4) if case == "ct466" else (1,3,5)
        reverse = case == "cs393"
        fields = "abcd"[:len(original)]
        max_rank = factorial(len(original))

        def render(rank, **p):
            values = ", ".join(map(str, p.values()))
            return (f"List all {len(fields)}-digit positive integers that use each digit in "
                    f"{values} exactly once, in {'descending' if reverse else 'ascending'} order. "
                    f"What number has rank {rank}, with the first number having rank 1?")

        def solve(rank, **p):
            values = sorted(p.values(), reverse=reverse)
            index = rank - 1
            result = 0
            while values:
                i, index = divmod(index, factorial(len(values) - 1))
                result = 10 * result + values.pop(i)
            return result

        def reference(rank, **p):
            values = (reduce(lambda n, d: n * 10 + d, perm, 0) for perm in permutations(p.values()))
            return sorted(values, reverse=reverse)[rank - 1]

        return _case(
            "ranked_digit_permutation",
            {"rank": (5 if reverse else 15, 1, max_rank),
             **{name: (value, 1, 9) for name, value in zip(fields, original)}},
            render, solve, reference, valid=lambda rank, **p: len(set(p.values())) == len(fields),
            sample=lambda rng: {"rank": rng.randint(1, max_rank), **dict(zip(fields, rng.sample(range(1,10), len(fields))))},
            constraints=("The listed digits are distinct and nonzero.",),
        )

    if case in {"ct738", "cs181"}:
        probability = case == "ct738"
        original = (2,3,5,7) if probability else (3,4,5,6)

        def render(a, b, c, d):
            digits = f"{a}, {b}, {c}, {d}"
            if probability:
                return (f"Arrange digits {digits} in uniformly random order to form a "
                        "four-digit integer. What is the probability it is odd?")
            return f"How many odd three-digit numbers can be made from {digits} without repeating a digit?"

        def solve(**p):
            odd = sum(d % 2 for d in p.values())
            return Fraction(odd, 4) if probability else 6 * odd

        def reference(**p):
            wins = sum(p[-1] % 2 for p in permutations(p.values(), 4 if probability else 3))
            return Fraction(wins, 24) if probability else wins

        return _case(
            "digit_arrangement_is_odd", {name: (d, 1, 9) for name, d in zip("abcd", original)},
            render, solve, reference, valid=lambda **p: len(set(p.values())) == 4,
            sample=lambda rng: dict(zip("abcd", rng.sample(range(1,10), 4))),
            constraints=("The four listed digits are distinct and nonzero.",),
        )

    if case == "ct212":
        def sample(rng):
            width = rng.randint(2, 5)
            if rng.randrange(5) == 0:
                return {"width": width, "target": rng.randint(1, 200)}
            target = 1
            for _ in range(width):
                target *= rng.randint(1, min(9, 200 // target))
            return {"width": width, "target": target}

        return _case(
            "count_digit_products", {"width": (4, 2, 5), "target": (12, 1, 200)},
            lambda width, target: f"How many positive {width}-digit integers have digit product {target}?",
            _digit_product_count,
            lambda width, target: _decimal_product_histogram(width)[target],
            sample=sample,
        )
    if case == "ct521":
        return _case(
            "even_integer_with_suffix_digit_sum", {"target": (10, 2, 16), "width": (3, 3, 4)},
            lambda target, width: f"How many positive even {width}-digit integers have the sum "
            f"of their tens and units digits equal to {target}?",
            lambda target, width: 9 * 10 ** (width - 3) * sum(0 <= target - d <= 9 for d in range(0,10,2)),
            lambda target, width: sum(n // 10 % 10 + n % 10 == target
                                      for n in range(10 ** (width - 1), 10 ** width, 2)),
        )
    if case == "ct695":
        return _case(
            "sum_odd_and_divisible_counts", {"width": (4, 2, 5), "divisor": (5, 2, 16)},
            lambda width, divisor: f"Let A be the number of odd positive {width}-digit integers "
            f"and B the number of positive {width}-digit multiples of {divisor}. Find A + B.",
            lambda width, divisor: 45 * 10 ** (width - 2) + _count_multiples(*_widths(width), divisor),
            lambda width, divisor: sum(n % 2 + int(n % divisor == 0)
                                       for n in range(10 ** (width - 1), 10 ** width)),
        )
    if case == "cs144":
        return _case(
            "restricted_postal_code_prefix", {"prefix": (3, 1, 4), "threshold": (4, 0, 8)},
            lambda prefix, threshold: f"How many five-digit ZIP codes have each of the first "
            f"{prefix} digits greater than {threshold}? Zero is permitted in unrestricted positions.",
            lambda prefix, threshold: (9-threshold) ** prefix * 10 ** (5-prefix),
            lambda prefix, threshold: sum(all(int(d) > threshold for d in f"{n:05}"[:prefix]) for n in range(100000)),
        )
    if case == "cs335":
        return _case(
            "count_digit_multiple_relation", {"multiplier": (3, 1, 9)},
            lambda multiplier: f"How many three-digit integers have their first digit "
            f"equal to {multiplier} times their final digit?",
            lambda multiplier: 10 * (9 // multiplier),
            lambda multiplier: sum(n // 100 == multiplier * (n % 10) for n in range(100,1000)),
        )
    if case == "cs385":
        def solve(upper):
            odds = (upper + 1) // 2
            evens = upper // 2
            return factorial(odds) * factorial(evens) * (1 if odds > evens else 2)

        return _case(
            "alternating_distinct_parities", {"upper": (9, 3, 9)},
            lambda upper: f"How many positive {upper}-digit integers can be made using each "
            f"of digits 1 through {upper} exactly once, with neighboring digits of opposite parity?",
            solve, lambda upper: sum(all((a+b) % 2 for a,b in zip(p,p[1:]))
                                     for p in permutations(range(1,upper+1))),
        )
    if case == "ct760":
        return _case(
            "palindromes_between_round_endpoints", {"first_hundred": (1, 1, 4), "last_hundred": (5, 5, 10)},
            lambda first_hundred, last_hundred: f"How many integer palindromes are strictly between "
            f"{100*first_hundred} and {100*last_hundred}?",
            lambda first_hundred, last_hundred: 10 * (last_hundred - first_hundred),
            lambda first_hundred, last_hundred: sum(str(n) == str(n)[::-1]
                                                    for n in range(100*first_hundred+1,100*last_hundred)),
        )
    if case == "cs471":
        return _case(
            "nonzero_product_from_digit_cards", {"number": (2001, 1000, 9999), "draw": (3, 2, 4)},
            lambda number, draw: f"Put each digit of {number} on a separate card. In how many "
            f"ways can {draw} distinct cards be chosen so their product is nonzero?",
            lambda number, draw: comb(4 - str(number).count("0"), draw),
            lambda number, draw: sum(prod(map(int, digits)) > 0 for digits in combinations(str(number), draw)),
        )
    return None


@lru_cache(maxsize=1024)
def _digit_product_count(width, target):
    if width == 0:
        return int(target == 1)
    return sum(_digit_product_count(width - 1, target // d) for d in range(1, 10)
               if target % d == 0)


@lru_cache(maxsize=4)
def _decimal_product_histogram(width):
    return Counter(_product_digits(n) for n in range(10 ** (width - 1), 10 ** width))



def _palindrome_prefix_bounds(width):
    half = (width + 1) // 2
    return 10 ** (half - 1), 10 ** half


def _binomial_factorial(case):
    if case in {"ct75", "ct82", "ct154", "ct313", "cs320"}:
        if case == "ct75":
            return _case(
                "sum_pascal_symmetric_indices", {"half": (13, 2, 17)},
                lambda half: f"Find the sum of all integers n from 0 through {2*half} for which "
                f"C({2*half}, {half}) + C({2*half}, n) = C({2*half+1}, {half+1}), "
                "where C(a,b) is the binomial coefficient.",
                lambda half: 2 * half,
                lambda half: sum(n for n in range(2*half+1)
                                 if comb(2*half,half)+comb(2*half,n)==comb(2*half+1,half+1)),
            )
        if case == "ct313":
            return _case(
                "largest_pascal_symmetric_index", {"half": (4, 2, 18)},
                lambda half: f"What is the largest n with C({2*half}, {half-1}) + C({2*half}, {half}) "
                f"= C({2*half+1}, n), where C(a,b) is the binomial coefficient?",
                lambda half: half+1,
                lambda half: max(n for n in range(2*half+2)
                                 if comb(2*half,half-1)+comb(2*half,half)==comb(2*half+1,n)),
            )
        if case == "ct82":
            def sample(rng):
                power = rng.randint(3, 15)
                return {"power": power, "degree": rng.randint(0, power), "constant": rng.randint(1, 7)}

            return _case(
                "binomial_with_negative_constant", {"power": (9, 3, 15), "degree": (8, 0, 15),
                                                     "constant": (1, 1, 7)},
                lambda power, degree, constant: f"Find the coefficient of $x^{{{degree}}}$ in "
                f"$(x-{constant})^{{{power}}}$.",
                lambda power, degree, constant: comb(power, degree) * (-constant) ** (power-degree),
                lambda power, degree, constant: sum((-constant) ** (power-degree)
                                                     for _ in combinations(range(power),degree)),
                valid=lambda power, degree, constant: degree <= power, sample=sample,
                constraints=("The requested degree is at most the outer power.",),
            )
        if case == "ct154":
            return _case(
                "binomial_two_variable_coefficient", {"a": (2, 1, 10), "b": (4, 1, 10)},
                lambda a, b: f"Find the coefficient of $x^{{{a}}}y^{{{b}}}$ in $(x+y)^{{{a+b}}}$.",
                lambda a,b: comb(a+b,a), lambda a,b: _choice_reference(a+b,b),
                constraints=("The outer power is the sum of the two requested exponents.",),
            )
        return _case(
            "laurent_binomial_coefficient", {"left": (4, 2, 10), "right": (2, 1, 10)},
            lambda left,right: f"Find the coefficient of $x^{{{left-right}}}$ in $(x+1/x)^{{{left+right}}}$.",
            lambda left,right: comb(left+right,left),
            lambda left,right: _choice_reference(left+right,right),
            constraints=("Requested degree is left minus right and outer power is left plus right.",),
        )

    if case in {"ct142", "ct497"}:
        n = 11 if case == "ct142" else 5

        def solve(n):
            return max(max(p for p in range(2, n+1) if _is_prime(p)), max(_factorization(n+2)))

        def reference(n):
            value = factorial(n) + factorial(n+1)
            return max(k for k in range(2,n+3) if value % k == 0
                       and all(k % i for i in range(2, isqrt(k)+1)))

        return _case(
            "largest_prime_divisor_factorial_sum", {"n": (n, 3, 26)},
            lambda n: f"What is the largest prime divisor of {n}! + {n+1}!?", solve, reference,
        )

    if case in {"ct189", "cs147", "cs323"}:
        if case == "cs323":
            return _case(
                "gcd_three_factorials", {"a": (5, 3, 9), "b": (10, 6, 15), "c": (15, 10, 18)},
                lambda a,b,c: f"Find the greatest common divisor of {a}!, {b}! and {c}!.",
                lambda a,b,c: factorial(min(a,b,c)),
                lambda a,b,c: reduce(gcd, map(factorial, (a,b,c))),
            )
        use_gcd = case == "ct189"
        op = "greatest common divisor" if use_gcd else "least common multiple"
        n,m = (7,5) if use_gcd else (6,4)

        def solve(a,b,power):
            x,y = factorial(a),factorial(b)**power
            divisor = gcd(x,y)
            return divisor if use_gcd else x*y//divisor

        def reference(a,b,power):
            x,y = factorial(a),factorial(b)**power
            return gcd(x,y) if use_gcd else lcm(x,y)

        return _case(
            "factorials_gcd_or_lcm", {"a": (n, 3, 12), "b": (m, 3, 9), "power": (2, 2, 5)},
            lambda a,b,power: f"Find the {op} of {a}! and $({b}!)^{{{power}}}$.",
            solve, reference,
        )
    if case in {"ct219", "cs232", "cs96", "cs95"}:
        if case == "cs95":
            return _case(
                "nested_factorial_ratio", {"n": (3, 2, 4)},
                lambda n: f"Find the value of ({n}!)! / {n}!.",
                lambda n: factorial(factorial(n) - 1),
                lambda n: factorial(factorial(n)) // factorial(n),
            )
        if case == "cs96":
            return _case(
                "factorial_ratio_difference_arguments", {"a": (8, 7, 16), "b": (4, 4, 6),
                                                         "c": (3, 2, 3)},
                lambda a,b,c: f"Find ({a} − {b})! ÷ ({a} − {c})! as a common fraction.",
                lambda a,b,c: Fraction(1, prod(range(a-b+1,a-c+1))),
                lambda a,b,c: Fraction(factorial(a-b), factorial(a-c)),
            )
        n,m = (8,3) if case == "ct219" else (11,9)

        def render(a,b):
            if case == "cs232":
                return f"By what integer factor must {b}! be multiplied to equal {a}!?"
            return f"Given {a}! = {factorial(a)}, what is {a}! divided by {b}!?"

        return _case(
            "factorial_ratio", {"a": (n, 3, 17), "b": (m, 2, 16)},
            render, lambda a,b: prod(range(b+1,a+1)), lambda a,b: factorial(a)//factorial(b),
            valid=lambda a,b: b < a, sample=lambda rng: _sample_factorial_ratio(rng),
            constraints=("The smaller factorial argument is strictly less than the larger.",),
        )
    if case == "cs295":
        return _case(
            "indexed_triangular_number", {"index": (50, 2, 200)},
            lambda index: f"The triangular numbers are on the third diagonal of Pascal's triangle, "
            f"with term n equal to 1 + 2 + … + n. What is triangular number {index}?",
            lambda index: comb(index+1,2), lambda index: sum(range(1,index+1)),
        )
    if case == "cs446":
        return _case(
            "multiples_between_successive_powers", {"base": (9, 2, 15), "power": (3, 2, 9)},
            lambda base,power: f"How many multiples of ${base}^{{{power}}}$ are strictly between "
            f"${base}^{{{power+1}}}$ and ${base}^{{{power+2}}}$?",
            lambda base,power: base * base - base - 1,
            lambda base,power: len(range((base+1)*base**power,base**(power+2),base**power)),
        )
    return None


def _sample_factorial_ratio(rng):
    a = rng.randint(3,17)
    return {"a": a, "b": rng.randrange(2,a)}


def _other_counting(case):
    if case in {"ct614", "ct758"}:
        return _case(
            "single_elimination_games", {"entrants": (17 if case == "ct614" else 256, 3, 280)},
            lambda entrants: f"A single-elimination tournament has {entrants} entrants. Each game "
            "matches two entrants and eliminates one, with no ties. How many games are played "
            "before only the champion remains?",
            lambda entrants: entrants-1, lambda entrants: _elimination_rounds(entrants),
        )
    if case in {"ct534", "ct510", "ct250", "cs405", "cs139"}:
        if case == "ct250":
            return _case(
                "adjacent_polygon_vertices", {"vertices": (8, 3, 45)},
                lambda vertices: f"Two distinct vertices of a polygon with {vertices} vertices are "
                "chosen uniformly at random. What is the probability they are adjacent?",
                lambda vertices: Fraction(2, vertices-1),
                lambda vertices: Fraction(sum((y-x) in {1,vertices-1} for x,y in
                                               combinations(range(vertices),2)), comb(vertices,2)),
            )
        if case == "ct534":
            return _case(
                "maximum_handshakes", {"people": (23, 3, 80)},
                lambda people: f"At a party with {people} people, each pair can shake hands at "
                "most once. What is the maximum possible number of handshakes?",
                lambda people: comb(people,2), lambda people: sum(range(1,people)),
            )
        if case == "ct510":
            return _case(
                "maximum_planes_by_points", {"points": (12, 4, 25)},
                lambda points: f"Three non-collinear points determine a unique plane. What is "
                f"the maximum number of planes that can be determined by {points} distinct points in space?",
                lambda points: comb(points,3), lambda points: _choice_reference(points,3),
            )
        if case == "cs405":
            choices = {comb(n,2) for n in range(3,41)}
            return _case(
                "invert_handshake_count", {"handshakes": (78, 3, 780)},
                lambda handshakes: f"Everyone at a party shook hands once with every other attendee. "
                f"There were {handshakes} handshakes. How many people attended?",
                lambda handshakes: (1+isqrt(1+8*handshakes))//2,
                lambda handshakes: next(n for n in range(3,41) if sum(range(n))==handshakes),
                valid=lambda handshakes: handshakes in choices,
                sample=lambda rng: {"handshakes": comb(rng.randint(3,40),2)},
                constraints=("The handshake count equals n(n−1)/2 for an integer n from 3 through 40.",),
            )
        return _case(
            "one_or_two_switches", {"switches": (8, 3, 50)},
            lambda switches: f"A row of {switches} switches controls distinct banks of lights. "
            "How many settings turn on exactly one or two banks of lights?",
            lambda switches: switches + comb(switches,2),
            lambda switches: _choice_reference(switches,1)+_choice_reference(switches,2),
        )
    if case in {"ct407", "ct531", "ct532", "ct594"}:
        values = {"ct407": (1,2,1,5), "ct531": (1,3,1,2), "ct532": (3,8,1,4), "ct594": (1,3,5,12)}
        a,b,c,d = values[case]
        groups = 2 if case == "ct532" else 1

        def render(a,b,c,d):
            prompt = f"A spinner lands in region A with probability {Fraction(a,b)} and B with probability {Fraction(c,d)}. "
            if groups == 2:
                prompt += "The remaining probability is divided equally between regions C and D. "
            else:
                prompt += "The only remaining region is C. "
            return prompt + "What is the probability it lands in C? Give a common fraction."

        def sample(rng):
            total = rng.randint(3,30)
            a,b = sorted(rng.sample(range(1,total),2))
            return {"a": a, "b": total, "c": b-a, "d": total}

        return _case(
            "missing_spinner_probability", {"a": (a, 1, 29), "b": (b, 2, 30),
                                           "c": (c, 1, 29), "d": (d, 2, 30)},
            render, lambda a,b,c,d: (1-Fraction(a,b)-Fraction(c,d))/groups,
            lambda a,b,c,d: Fraction(b*d-a*d-b*c, b*d*groups),
            valid=lambda a,b,c,d: a*d+b*c < b*d, sample=sample,
            constraints=("The two given probabilities are positive and sum to less than 1.",),
        )
    if case in {"ct659", "cs422", "cs280"}:
        rows = {
            "ct659": ((10, 2, 18), 3, 0, "A professor gives only grades A, B, and C. In how many "
                      "ways can grades be assigned to {} distinct students?"),
            "cs422": ((10, 2, 18), 2, 0, "Each of {} Caltech students chooses either Chipotle "
                      "or Panda Express for lunch. How many assignments of students to restaurants are possible?"),
            "cs280": ((4, 2, 18), 2, 1, "Alyssa has {} differently colored marbles. "
                      "How many nonempty subsets of marbles can she select?"),
        }
        domain, choices, omit, prompt = rows[case]
        return _case(
            "independent_choices", {"n": domain}, lambda n: prompt.format(n),
            lambda n: choices ** n - omit,
            lambda n: prod(choices for _ in range(n))-omit if not omit
            else sum(_choice_reference(n,k) for k in range(1,n+1)),
        )
    if case in {"cs341", "cs365"}:
        pizza = case == "cs341"
        if pizza:
            def render(a,b,both,neither=0):
                return (f"A {a+b+both}-slice pizza uses only pepperoni and mushroom toppings. "
                        f"Every slice has at least one topping. There are {a+both} slices with pepperoni "
                        f"and {b+both} with mushrooms. How many have both toppings?")
        else:
            def render(a,b,both,neither):
                return (f"Roslyn has {a+b+both+neither} boxes. There are {a+both} boxes with pencils, "
                        f"{b+both} with pens and {both} with both. How many boxes have neither item?")

        def solve(total,a,b,overlap=None):
            return a+b-total if pizza else total-a-b+overlap

        def reference(total,a,b,overlap=None):
            group = set(range(a))
            if pizza:
                return len(group & set(range(total-b,total)))
            return len(set(range(total)) - (group | set(range(a-overlap,a-overlap+b))))

        def render_public(total,a,b,overlap=None):
            if pizza:
                return render(total-b,total-a,a+b-total)
            return render(a-overlap,b-overlap,overlap,total-a-b+overlap)

        def sample(rng):
            a,b,both,neither = (rng.randint(1,7) for _ in range(4))
            p = {"total": a+b+both+(0 if pizza else neither), "a": a+both, "b": b+both}
            if not pizza:
                p["overlap"] = both
            return p

        return _case(
            "two_set_membership_counts",
            {"total": (12 if pizza else 10, 3, 28), "a": (5, 2, 14), "b": (8 if pizza else 4, 2, 14),
             **({} if pizza else {"overlap": (2,1,7)})},
            render_public, solve, reference, sample=sample,
            valid=lambda total,a,b,overlap=None: max(a,b)<=total<=a+b if pizza
            else overlap<=min(a,b) and a+b-overlap<=total,
            constraints=("The stated subset and overlap counts are consistent with the total.",),
        )
    if case == "ct245":
        return _case(
            "pennies_nickels_dimes", {"cents": (25, 5, 150)},
            lambda cents: f"How many unordered combinations of pennies (1 cent), nickels "
            f"(5 cents) and dimes (10 cents) have total value {cents} cents?",
            lambda cents: sum((cents-10*d)//5+1 for d in range(cents//10+1)),
            lambda cents: sum(p+5*n+10*d==cents for p,n,d in
                              product(range(cents+1),range(cents//5+1),range(cents//10+1))),
        )
    if case == "cs312":
        return _case(
            "three_odd_piles", {"dimes": (12, 3, 80)},
            lambda dimes: f"In how many ways can {dimes} indistinguishable dimes be divided into "
            "three unordered piles with an odd positive number in each pile?",
            lambda dimes: sum((dimes-a-b)%2==1 for a in range(1,dimes//3+1,2)
                              for b in range(a,(dimes-a)//2+1,2)),
            lambda dimes: len({tuple(sorted((a,b,dimes-a-b))) for a in range(1,dimes,2)
                              for b in range(1,dimes-a,2) if (dimes-a-b)%2==1}),
            adaptation="The source piles are interpreted as unordered and this is explicit in the render.",
        )
    return None


def _elimination_rounds(n):
    games = 0
    while n > 1:
        games += n//2
        n -= n//2
    return games


def _additional_number_theory(case):
    if case == "nt56":
        def sample(rng):
            a,b = rng.choice(tuple((a,b) for a in range(2,13) for b in range(2,13)
                                   if a % b != 0 and b % a != 0))
            return {"a":a, "b":b, "remainder":rng.randrange(lcm(a,b))}

        return _case(
            "sum_residues_under_divisors", {"a": (3,2,12), "b": (5,2,12), "remainder": (7,0,131)},
            lambda a,b,remainder: f"An integer leaves remainder {remainder} when divided by {lcm(a,b)}. "
            f"Find the sum of its remainders when divided separately by {a} and {b}.",
            lambda a,b,remainder: remainder%a+remainder%b,
            lambda a,b,remainder: sum((17*lcm(a,b)+remainder)%d for d in (a,b)),
            valid=lambda a,b,remainder: a % b != 0 and b % a != 0 and remainder < lcm(a,b),
            sample=sample,
            constraints=("The two divisors are proper divisors of their least common multiple. "
                         "The known remainder is smaller than that least common multiple.",),
        )
    if case == "nt160":
        return _case(
            "odd_product_units_digit", {"low":(10,0,25),"high":(110,27,150)},
            lambda low,high: f"What is the units digit of the product of all positive odd integers "
            f"strictly between {low} and {high}?",
            lambda low,high: reduce(lambda a,b: a*b%10,range(low+1+low%2,high,2),1),
            lambda low,high: prod(n for n in range(low+1,high) if n%2)%10,
        )
    if case == "nt361":
        return _case(
            "closest_square", {"n":(273,5,2500)},
            lambda n: f"What perfect-square integer is closest to {n}?",
            lambda n: min((isqrt(n)**2,(isqrt(n)+1)**2), key=lambda x:abs(n-x)),
            lambda n: min((x*x for x in range(52)), key=lambda x:abs(n-x)),
        )
    if case == "nt438":
        return _case(
            "affine_shift_by_modulus", {"divisor":(7,2,30),"residue":(2,0,29),"factor":(3,2,15)},
            lambda divisor,residue,factor: f"An integer n leaves remainder {residue} when divided "
            f"by {divisor}. What remainder does {factor}n − {divisor} leave when divided by {divisor}?",
            lambda divisor,residue,factor: factor*residue%divisor,
            lambda divisor,residue,factor: divmod(factor*(3*divisor+residue)-divisor,divisor)[1],
            valid=lambda divisor,residue,factor: residue<divisor,
            sample=lambda rng: _sample_named_modulus(rng,"factor",2,15),
            constraints=("The given remainder is less than the divisor.",),
        )
    if case == "nt533":
        def reference(base,exponent):
            n = base**(exponent+1)-base**exponent
            return next(p for p in range(2,base+1) if n%p==0)

        return _case(
            "smallest_prime_factor_power_difference", {"base":(7,3,30),"exponent":(3,1,15)},
            lambda base,exponent: f"What is the least prime factor of ${base}^{{{exponent+1}}}"
            f"-{base}^{{{exponent}}}$?",
            lambda base,exponent: min(min(_factorization(base)),min(_factorization(base-1))),
            reference,
        )
    if case == "nt719":
        return _case(
            "difference_of_repeating_decimals", {"a":(789,1,999),"b":(456,1,999),"c":(123,1,999)},
            lambda a,b,c: f"Express $0.\\overline{{{a:03}}}-0.\\overline{{{b:03}}}-"
            f"0.\\overline{{{c:03}}}$ as a fraction in lowest terms.",
            lambda a,b,c: Fraction(a-b-c,999),
            lambda a,b,c: sum(Fraction(v*1001,999999) for v in (a,-b,-c)),
        )
    if case in {"ns147","ns430"}:
        inverse = case=="ns147"
        domains={"quotient":(123 if inverse else 28,2,150),"remainder":(17 if inverse else 6,0,39)}
        domains.update({"dividend":(39500,5,60000)} if inverse else {"divisor":(7,2,40)})

        def render(quotient,remainder,dividend=None,divisor=None):
            if inverse:
                return (f"When {dividend:,} is divided by a positive integer, the quotient is "
                        f"{quotient} and the remainder is {remainder}. What is the divisor?")
            return (f"When an integer is divided by {divisor}, the quotient is {quotient} "
                    f"and the remainder is {remainder}. What is the integer?")

        def valid(quotient,remainder,dividend=None,divisor=None):
            if inverse:
                divisor,leftover=divmod(dividend-remainder,quotient)
                return leftover==0 and divisor>remainder and divisor>=2
            return remainder<divisor

        def sample(rng):
            divisor=rng.randint(2,380 if inverse else 40)
            quotient=rng.randint(2,150)
            remainder=rng.randrange(min(40,divisor))
            p={"quotient":quotient,"remainder":remainder}
            p.update({"dividend":divisor*quotient+remainder} if inverse else {"divisor":divisor})
            return p

        def solve(quotient,remainder,dividend=None,divisor=None):
            return (dividend-remainder)//quotient if inverse else divisor*quotient+remainder

        def reference(quotient,remainder,dividend=None,divisor=None):
            if inverse:
                return next(d for d in range(2,dividend//quotient+1) if divmod(dividend,d)==(quotient,remainder))
            return next(n for n in range(divisor*quotient,(quotient+1)*divisor)
                        if divmod(n,divisor)==(quotient,remainder))

        return _case("recover_division_operand",domains,render,solve,reference,valid=valid,sample=sample,
                     constraints=("The dividend equals quotient × divisor + remainder, with remainder less than divisor.",))
    if case == "ns149":
        return _case(
            "zeros_in_scientific_product",
            {"tenths":(92,11,99),"multiplier":(8,2,15),"a":(2,1,8),"b":(6,1,8)},
            lambda tenths,multiplier,a,b: f"How many zero digits occur in the decimal integer "
            f"$({tenths//10}.{tenths%10}\\times10^{{{a}}})({multiplier}\\times10^{{{b}}})$?",
            lambda tenths,multiplier,a,b: str(tenths*multiplier).count("0")+a+b-1,
            lambda tenths,multiplier,a,b: str(tenths*multiplier*10**(a+b-1)).count("0"),
        )
    if case == "ns198":
        return _case(
            "tens_digit_power_sum", {"base":(11,2,35),"last":(9,3,45)},
            lambda base,last: f"What is the tens digit of ${base}^1+{base}^2+\\cdots+{base}^{{{last}}}$? "
            "Treat a missing tens digit as zero.",
            lambda base,last: sum(pow(base,e,100) for e in range(1,last+1))//10%10,
            lambda base,last: int(str(sum(base**e for e in range(1,last+1))).zfill(2)[-2]),
        )
    if case == "ns204":
        def candidate(total,divisor):
            return total * (total + 1) // 2 % divisor or divisor

        def valid(total,divisor):
            r=candidate(total,divisor)
            return 1<=r<=total<r+divisor

        def sample(rng):
            total=rng.randint(20,105)
            return {"total":total,"divisor":rng.choice([d for d in range(2,201) if valid(total,d)])}

        return _case(
            "unique_card_removed_from_interval", {"total":(100,20,105),"divisor":(77,2,200)},
            lambda total,divisor: f"Cards are numbered 1 through {total}. One card is removed. "
            f"The sum of the remaining {total-1} card numbers is a multiple of {divisor}. "
            "Which card was removed?",
            candidate,
            lambda total,divisor: next(i for i in range(1,total+1)
                                       if sum(j for j in range(1,total+1) if i!=j)%divisor==0),
            valid=valid,sample=sample,
            constraints=("Exactly one card number leaves a remaining sum divisible by the divisor.",),
        )
    if case == "ns217":
        return _case(
            "units_digit_filtered_product", {"last":(10,4,70),"divisor":(5,2,15)},
            lambda last,divisor: f"What is the units digit of the product of the integers "
            f"from 1 to {last}, excluding multiples of {divisor}?",
            lambda last,divisor: reduce(lambda a,b: a*b%10,
                                        (n for n in range(1,last+1) if n%divisor),1),
            lambda last,divisor: prod(set(range(1,last+1))-set(range(divisor,last+1,divisor)))%10,
        )
    if case in {"ns233","ns326"}:
        evens=case=="ns326"

        def product_from_start(n):
            return n*(n+2) if evens else n*(n+1)*(n+2)

        def solve(value):
            if evens:
                return isqrt(value+1)+1
            return _integer_root(value,3)+2

        def reference(value):
            first=2 if evens else 1
            step=2 if evens else 1
            return next(n+2 for n in range(first,100,step) if product_from_start(n)==value)

        def render(value):
            description="two consecutive positive even integers" if evens else "three consecutive integers"
            return f"The product of {description} is {value}. What is the greatest of these integers?"

        def sample(rng):
            return {"value":product_from_start(2*rng.randint(1,40) if evens else rng.randint(2,40))}

        choices={product_from_start(i) for i in range(2 if evens else 1,81 if evens else 41,2 if evens else 1)}
        return _case("consecutive_integer_product",{"value":(288 if evens else 720,min(choices),max(choices))},
                     render,solve,reference,sample=sample,valid=lambda value:value in choices,
                     constraints=("The product is attainable by the indicated consecutive integers.",))
    if case == "ns249":
        roots=tuple(n for n in range(6,55) if _factor_count(n)==4)
        return _case(
            "sum_divisors_of_square_root", {"radicand":(196,36,54**2)},
            lambda radicand: f"Find the sum of the four positive divisors of the positive square root of {radicand}.",
            lambda radicand: _sum_factors(isqrt(radicand)),
            lambda radicand: sum(_factors(next(n for n in range(6,55) if n*n==radicand))),
            valid=lambda radicand: isqrt(radicand)**2==radicand and isqrt(radicand) in roots,
            sample=lambda rng: {"radicand":rng.choice(roots)**2},
            constraints=("The radicand is a perfect square whose square root has exactly four positive divisors.",),
        )
    if case == "ns354":
        return _case(
            "sum_linear_terms_for_known_multiple",
            {"divisor":(3,2,15),"a":(4,1,35),"b":(6,1,35),"c":(8,1,35)},
            lambda divisor,a,b,c: f"An integer n is a multiple of {divisor}. What remainder does "
            f"(n + {a}) + (n + {b}) + (n + {c}) leave upon division by {3*divisor}?",
            lambda divisor,a,b,c: (a+b+c)%(3*divisor),
            lambda divisor,a,b,c: sum(13*divisor+j for j in (a,b,c))%(3*divisor),
            constraints=("The final divisor equals three times the known divisor of n.",),
        )
    if case == "ns423":
        return _case(
            "distinct_prime_triples_with_sum", {"total":(20,9,90)},
            lambda total: f"How many strictly increasing triples of prime numbers have sum {total}?",
            lambda total: sum(_is_prime(total-p-q) and total-p-q>q for p,q in
                              combinations([i for i in range(2,total) if _is_prime(i)],2)),
            lambda total: sum(sum(xs)==total for xs in combinations(
                [i for i in range(2,total) if all(i%j for j in range(2,isqrt(i)+1))],3)),
        )
    return None


def _additional_counting(case):
    if case=="ct24":
        def solve(length,upper):
            odd,even=(upper+1)//2,upper//2
            return odd**((length+1)//2)*even**(length//2)+even**((length+1)//2)*odd**(length//2)

        def reference(length,upper):
            ends=[1]*upper
            for _ in range(1,length):
                ends=[sum(n for j,n in enumerate(ends,1) if (i+j)%2)
                      for i in range(1,upper+1)]
            return sum(ends)

        return _case(
            "alternating_digit_code", {"length":(5,2,9),"upper":(5,2,9)},
            lambda length,upper: f"Jason's safe code has {length} digits, each from 1 through "
            f"{upper}. Digits may repeat, but consecutive digits always have opposite parity. "
            "How many different codes are possible?",solve,reference,
        )
    if case in {"ct114","ct501"}:
        powers=case=="ct114"
        domains=({"n":(8,5,14),"a":(5,1,10),"b":(2,1,5)} if powers else
                 {"n":(7,5,14),"a":(5,2,10),"b":(8,2,10),"c":(2,2,10)})

        def divisor(a,b,c=None):
            return 2**a*3**b if powers else a*b*c

        def render(n,a,b,c=None):
            expression=(f"$2^{{{a}}}\\cdot3^{{{b}}}\\cdot x$" if powers
                        else f"{a} × {b} × {c} × x")
            return f"Find x such that {expression} = {n}!."

        def sample(rng):
            n=rng.randint(5,14)
            if powers:
                factors=_factorization(factorial(n))
                return {"n":n,"a":rng.randint(1,min(factors[2],10)),"b":rng.randint(1,min(factors[3],5))}
            remaining=factorial(n)
            p={"n":n}
            for name in "abc":
                p[name]=rng.choice([d for d in range(2,11) if remaining%d==0])
                remaining//=p[name]
            return p

        return _case(
            "factorial_divided_by_product",domains,render,
            lambda n,**p: factorial(n)//divisor(**p),
            lambda n,**p: Fraction(prod(range(1,n+1)),divisor(**p)),
            valid=lambda n,**p: factorial(n)%divisor(**p)==0,sample=sample,
            constraints=("The coefficient of x divides n! exactly.",),
        )
    if case=="ct198":
        colors=("black","gold","white","green","navy","pink","orange","red","purple","gray")

        def render(shared,extra):
            return (f"The shorts color is selected uniformly from {', '.join(colors[:shared])}. "
                    f"The jersey color is selected independently and uniformly from "
                    f"{', '.join(colors[:shared+extra])}. What is the probability the colors differ?")

        return _case(
            "nested_uniform_color_choices", {"shared":(2,1,5),"extra":(1,1,5)},render,
            lambda shared,extra: 1-Fraction(1,shared+extra),
            lambda shared,extra: Fraction(sum(a!=b for a,b in product(range(shared),range(shared+extra))),
                                          shared*(shared+extra)),
        )
    if case=="ct483":
        factorials=tuple(factorial(n) for n in range(4,13))
        return _case(
            "invert_sum_with_factorial", {"value":(720,factorials[0],factorials[-1])},
            lambda value: f"Find the positive integer n such that n × n! + n! = {value}.",
            lambda value: factorials.index(value)+3,
            lambda value: next(n for n in range(3,12) if n*factorial(n)+factorial(n)==value),
            valid=lambda value:value in factorials,sample=lambda rng:{"value":rng.choice(factorials)},
            constraints=("The right-hand side is a factorial of an integer from 4 through 12.",),
        )
    if case=="ct585":
        return _case(
            "nonmonochrome_outfits_with_nested_colors", {"common":(4,2,10),"extra":(2,1,6)},
            lambda common,extra: f"I own one pair of pants, one shirt and one hat in each of "
            f"{common} colors, plus one shirt and one hat in each of {extra} other colors. "
            "How many outfits with one of each garment have at least two colors?",
            lambda common,extra: common*((common+extra)**2-1),
            lambda common,extra: sum(not a==b==c for a,b,c in
                                    product(range(common),range(common+extra),range(common+extra))),
        )
    if case=="ct675":
        return _case(
            "sandwich_excluded_ingredient_pairs", {"bread":(4,2,9),"meat":(6,2,10),"cheese":(5,2,9)},
            lambda bread,meat,cheese: f"A deli offers {bread} breads, {meat} meats and {cheese} cheeses, "
            "including white bread, ham, chicken and cheddar. A sandwich uses one of each category. "
            "Al never orders a sandwich containing both ham and cheddar, or one containing both white bread and chicken. "
            "How many sandwiches can Al order?",
            lambda bread,meat,cheese:bread*meat*cheese-bread-cheese,
            lambda bread,meat,cheese:sum(not (m==0 and c==0 or b==0 and m==1) for b,m,c in
                                         product(range(bread),range(meat),range(cheese))),
        )
    if case=="ct692":
        return _case(
            "outfits_different_shirt_and_hat_colors",
            {"red_shirts":(5,1,10),"green_shirts":(5,1,10),"pants":(6,1,9),
             "green_hats":(8,1,10),"red_hats":(8,1,10)},
            lambda red_shirts,green_shirts,pants,green_hats,red_hats:
            f"You have {red_shirts} red shirts, {green_shirts} green shirts, {pants} pairs of pants, "
            f"{green_hats} green hats and {red_hats} red hats, all distinct. How many outfits "
            "with a shirt, a pair of pants and a hat have different shirt and hat colors?",
            lambda red_shirts,green_shirts,pants,green_hats,red_hats:
            pants*(red_shirts*green_hats+green_shirts*red_hats),
            lambda red_shirts,green_shirts,pants,green_hats,red_hats:
            sum(x!=y for x,y,_ in product([0]*red_shirts+[1]*green_shirts,
                                          [1]*green_hats+[0]*red_hats,range(pants))),
        )
    if case=="ct744":
        def render(a,b,c,d,e,f):
            return (f"Tamika uniformly chooses two distinct numbers from {{{a}, {b}, {c}}} and adds them. "
                    f"Independently, Carlos uniformly chooses two distinct numbers from {{{d}, {e}, {f}}} "
                    "and multiplies them. What is the probability Tamika's result is larger?")

        def sample(rng):
            return dict(zip("abcdef",rng.sample(range(2,18),3)+rng.sample(range(2,18),3)))

        def reference(a,b,c,d,e,f):
            sums=(a+b,a+c,b+c)
            products=(d*e,d*f,e*f)
            return Fraction(sum(3-sum(x<=p for x in sums) for p in products),9)

        return _case(
            "sum_greater_than_independent_product",
            {name:(n,2,17) for name,n in zip("abcdef",(8,9,10,3,5,6))},render,
            lambda a,b,c,d,e,f: Fraction(sum(sum(x)>prod(y) for x,y in
                                               product(combinations((a,b,c),2),combinations((d,e,f),2))),9),
            reference,sample=sample,valid=lambda a,b,c,d,e,f:len({a,b,c})==len({d,e,f})==3,
            constraints=("Each of the two sets contains three distinct integers.",),
        )
    if case=="cs41":
        return _case(
            "license_plate_format_increase", {"old_letters":(3,1,4)},
            lambda old_letters: f"A state switches from {old_letters} letters followed by "
            f"{6-old_letters} digits to {old_letters+1} letters followed by {5-old_letters} digits "
            "per license plate. Each letter is A–Z and each digit is 0–9. Repetitions are allowed. "
            "How many more plates does the new format permit?",
            lambda old_letters: 16*26**old_letters*10**(5-old_letters),
            lambda old_letters: 26**(old_letters+1)*10**(5-old_letters)-26**old_letters*10**(6-old_letters),
            constraints=("Both formats have six characters. The new format replaces one digit with a letter.",),
        )
    if case=="cs69":
        def render(letters,digits,eligible):
            choices=", ".join(map(str,(1,2,4,6,3,5,7,8)[:eligible]))
            return (f"An Atlantis license plate has {letters} letters followed by {digits} digits. "
                    "The first letter is one of A, E, I, O, U. No letter repeats. "
                    f"The first digit must be in {{{choices}}} and no digit repeats. How many plates are possible?")

        return _case(
            "restricted_license_plate", {"letters":(3,2,6),"digits":(3,2,7),"eligible":(4,1,8)},
            render,lambda letters,digits,eligible:5*_falling(25,letters-1)*eligible*_falling(9,digits-1),
            lambda letters,digits,eligible:5*_permutation_reference(25,letters-1)*
            eligible*_permutation_reference(9,digits-1),
        )
    if case=="cs72":
        def sample(rng):
            low=rng.randint(0,7)
            return {"hundreds_min":rng.randint(1,8),"tens_low":low,"tens_high":rng.randint(low+2,10)}

        return _case(
            "fixed_three_digit_constraints",
            {"hundreds_min":(5,1,8),"tens_low":(4,0,7),"tens_high":(8,2,10)},
            lambda hundreds_min,tens_low,tens_high: f"How many three-digit positive integers have hundreds digit "
            f"greater than {hundreds_min}, tens digit strictly between {tens_low} and {tens_high}, and units digit 2, "
            "the smallest prime number?",
            lambda hundreds_min,tens_low,tens_high:(9-hundreds_min)*(tens_high-tens_low-1),
            lambda hundreds_min,tens_low,tens_high:sum(n//100>hundreds_min and tens_low<n//10%10<tens_high
                                                     for n in range(102,1000,10)),
            valid=lambda hundreds_min,tens_low,tens_high:tens_high>=tens_low+2,sample=sample,
            constraints=("The tens digit interval contains at least one digit.",),
        )
    if case=="cs85":
        return _case(
            "alphabetical_three_letter_rank", {"first":(1,0,2),"middle":(0,0,2),"last":(1,0,2)},
            lambda first,middle,last: f"List all three-letter strings made from A, B, C in alphabetical order "
            f"with AAA first and CCC last. Which position (starting from 1) is "
            f"{''.join('ABC'[i] for i in (first,middle,last))}?",
            lambda first,middle,last:1+9*first+3*middle+last,
            lambda first,middle,last:list(product(range(3),repeat=3)).index((first,middle,last))+1,
        )
    if case=="cs116":
        return _case(
            "fruit_selection_with_disjoint_exclusions", {"choose":(3,2,4)},
            lambda choose: f"Choose {choose} distinct fruits from apples, bananas, grapes, strawberries, "
            "and pineapples. Strawberries cannot be paired with pineapples, and bananas cannot "
            "be paired with grapes. How many unordered fruit selections are possible?",
            lambda choose: comb(5,choose)-2*comb(3,choose-2)+int(choose==4),
            lambda choose:sum(not ({1,2}<=set(s) or {3,4}<=set(s))
                              for s in combinations(range(5),choose)),
        )
    if case=="cs136":
        return _case(
            "ordered_two_red_cards", {"ranks":(13,2,18)},
            lambda ranks: f"A deck contains four suits of {ranks} distinct cards each, two red and "
            "two black. How many ordered draws of two distinct red cards are possible?",
            lambda ranks:2*ranks*(2*ranks-1),
            lambda ranks:sum(1 for _ in permutations(range(2*ranks),2)),
        )
    if case=="cs256":
        def solve(quarters,nickels,pennies):
            totals={0}
            for value,count in ((25,quarters),(5,nickels),(1,pennies)):
                totals={t+k*value for t in totals for k in range(count+1)}
            return len(totals)-1

        def reference(quarters,nickels,pennies):
            coins=[25]*quarters+[5]*nickels+[1]*pennies
            return len({sum(choice) for n in range(1,len(coins)+1) for choice in combinations(coins,n)})

        return _case(
            "exact_change_distinct_prices", {"quarters":(1,1,4),"nickels":(2,1,4),"pennies":(3,1,7)},
            lambda quarters,nickels,pennies: f"Steve has {quarters} quarters, {nickels} nickels "
            f"and {pennies} pennies. How many different positive prices can he pay exactly, "
            "considering each purchase independently?",
            solve,reference,
        )
    return None


def _round_two_counting(case):
    if case in {"ct52", "ct669", "ct729"}:
        return _class_ratio_case(case)
    if case in {"ct739", "cs153", "cs432"}:
        return _three_sets_case(case)
    if case in {"ct131", "ct708", "cs120", "cs307"}:
        return _pascal_hints_case(case)
    if case in {"ct89", "ct169", "ct769", "cs140", "ct645"}:
        return _binomial_and_race_cases(case)
    if case in {"ct91", "ct302", "ct529", "ct555", "ct761", "cs177", "cs201"}:
        return _weighted_outcome_cases(case)
    if case in {"ct470", "ct562", "ct68", "ct222", "cs421", "cs10"}:
        return _sequence_and_set_cases(case)
    if case in {"ct505", "ct567", "ct600", "cs6", "cs23", "cs167", "cs222",
                "cs265", "cs283", "cs431"}:
        return _arrangement_round_two(case)
    return None


def _class_ratio_case(case):
    factor, total, both, neither = {
        "ct52": (2, 25, 2, 0), "ct669": (3, 43, 5, 0), "ct729": (2, 30, 6, 3),
    }[case]
    domains = {"factor": (factor, 2, 5), "total": (total, 5, 145), "both": (both, 1, 22)}
    if case == "ct729":
        domains["neither"] = (neither, 1, 15)

    def render(factor, total, both, neither=0):
        if case == "ct52":
            return (f"There are {total} students taking English or French or both. Exactly {both} take "
                    f"both. The English class has {factor} times as many students as the French class. "
                    "How many take English but not French?")
        if case == "ct669":
            return (f"Each of {total} students takes chemistry, biology or both. Exactly {both} take "
                    f"both. The chemistry class has {factor} times as many students as the biology "
                    "class. How many students take chemistry?")
        return (f"Among {total} students there are {factor} times as many with blond hair as with blue "
                f"eyes. Exactly {both} have both traits and {neither} have neither. How many have blue eyes?")

    def solve(factor, total, both, neither=0):
        smaller = (total - neither + both) // (factor + 1)
        return smaller if case == "ct729" else factor * smaller - (both if case == "ct52" else 0)

    def reference(factor, total, both, neither=0):
        for only_small in range(total + 1):
            only_large = total - neither - both - only_small
            if only_large + both == factor * (only_small + both):
                return {"ct52": only_large, "ct669": only_large + both,
                        "ct729": only_small + both}[case]
        raise ValueError("inconsistent class sizes")

    def valid(factor, total, both, neither=0):
        smaller, remainder = divmod(total - neither + both, factor + 1)
        return remainder == 0 and smaller >= both

    def sample(rng):
        factor, smaller = rng.randint(2, 5), rng.randint(3, 22)
        both = rng.randint(1, smaller)
        p = {"factor": factor, "total": (factor + 1) * smaller - both, "both": both}
        if case == "ct729":
            p["neither"] = rng.randint(1, min(15, 145 - p["total"]))
            p["total"] += p["neither"]
        return p

    return _case("ratio_with_two_set_overlap", domains, render, solve, reference,
                 valid=valid, sample=sample,
                 constraints=("The implied two class sizes are whole numbers and each is at least the overlap.",))


def _three_sets_case(case):
    names = {"ct739": ("sit", "stay", "roll over"), "cs153": ("math", "English", "science"),
             "cs432": ("sunglasses", "bathing suits", "hats")}[case]
    values = {"ct739": (50, 29, 34, 17, 18, 12), "cs153": (59, 49, 42, 31, 29, 20),
              "cs432": (110, 70, 95, 30, 40, 25)}[case]
    domains = {name: (n, 0, 160) for name, n in zip(("a", "b", "c", "ab", "ac", "bc"), values)}
    if case != "cs432":
        domains["triple"] = (9 if case == "ct739" else 12, 0, 35)
    if case == "ct739":
        domains["outside"] = (9, 0, 35)
    else:
        domains["total"] = (100 if case == "cs153" else 190, 1, 220)

    def cells(a, b, c, ab, ac, bc, triple=None, outside=None, total=None):
        net = a + b + c - ab - ac - bc
        if triple is None:
            triple = total - net
        if outside is None:
            outside = total - net - triple
        return (outside, a - ab - ac + triple, b - ab - bc + triple, ab - triple,
                c - ac - bc + triple, ac - triple, bc - triple, triple)

    def render(a, b, c, ab, ac, bc, triple=None, outside=None, total=None):
        labels = f"The three categories, in order, are {names[0]}, {names[1]} and {names[2]}."
        memberships = (f"The respective category counts are {a}, {b} and {c}. The counts in the "
                       f"first and second, first and third, and second and third are {ab}, {ac} and {bc}, "
                       "respectively. Each pair count includes members of all three categories.")
        if case == "ct739":
            return (f"At a dog obedience school, dogs can learn three tricks. {labels} {memberships} "
                    f"Exactly {triple} dogs know all three and {outside} know none. How many dogs attend?")
        if case == "cs153":
            return (f"A survey of {total} students tracks homework by subject. {labels} {memberships} "
                    f"Exactly {triple} did homework in all three. How many did homework in none?")
        return (f"Each of {total} people on a beach wears at least one of three items. {labels} "
                f"{memberships} How many wear all three?")

    def solve(a, b, c, ab, ac, bc, triple=None, outside=None, total=None):
        net = a + b + c - ab - ac - bc
        if case == "ct739":
            return net + triple + outside
        if case == "cs153":
            return total - net - triple
        return total - net

    def reference(**p):
        occupancy = tuple(mask for mask, count in enumerate(cells(**p)) for _ in range(count))
        if case == "ct739":
            return len(occupancy)
        return occupancy.count(0 if case == "cs153" else 7)

    def sample(rng):
        counts = [rng.randint(0, 24) for _ in range(8)]
        counts[7] += 1
        if case == "cs432":
            counts[0] = 0
        p = {name: sum(n for mask, n in enumerate(counts) if mask & bits == bits)
             for name, bits in zip(("a", "b", "c", "ab", "ac", "bc"), (1, 2, 4, 3, 5, 6))}
        if case != "cs432":
            p["triple"] = counts[7]
        if case == "ct739":
            p["outside"] = counts[0]
        else:
            p["total"] = sum(counts)
        return p

    return _case("three_set_inclusion_exclusion", domains, render, solve, reference,
                 valid=lambda **p: min(cells(**p)) >= 0 and sum(cells(**p)) > 0,
                 sample=sample, constraints=("All eight disjoint membership counts are nonnegative.",))


def _pascal_hints_case(case):
    def display(n, k):
        return f"C({n},{k}) = {comb(n,k)}"

    if case == "ct708":
        def render(k):
            n = 2 * k - 3
            return f"Find C({n+2},{k}), given {display(n,k-3)} and {display(n,k-1)}."

        return _case("pascal_twice_with_symmetry", {"k": (9, 4, 19)}, render,
                     lambda k: comb(2*k-3,k-3) + 3 * comb(2*k-3,k-1),
                     lambda k: comb(2*k-1,k),
                     constraints=("The given row is 2k−3, so its indicated entries determine their symmetric partners.",))

    if case == "cs307":
        return _case(
            "pascal_center_and_neighbor", {"k": (7, 2, 19)},
            lambda k: f"Find C({2*k+1},{k}), given {display(2*k,k+1)} and {display(2*k,k)}.",
            lambda k: comb(2*k,k-1) + comb(2*k,k), lambda k: comb(2*k+1,k),
            constraints=("C denotes a binomial coefficient. The given row is twice the queried column index.",),
        )

    def render(n, k):
        if case == "ct131":
            return (f"Given {display(n,k-2)}, {display(n,k-1)} and {display(n,k)}, "
                    f"find C({n+2},{k}).")
        return (f"Given {display(n,k-2)}, {display(n+1,k-1)} and {display(n+1,k)}, "
                f"find C({n},{k}).")

    def solve(n, k):
        if case == "ct131":
            return comb(n,k-2) + 2 * comb(n,k-1) + comb(n,k)
        return comb(n+1,k) - comb(n+1,k-1) + comb(n,k-2)

    def sample(rng):
        n = rng.randint(7, 30)
        return {"n": n, "k": rng.randint(3, n - 1)}

    return _case(
        "pascal_adjacent_rows", {"n": (23 if case == "ct131" else 15, 7, 30),
                                "k": (5 if case == "ct131" else 10, 3, 29)},
        render, solve, lambda n,k: comb(n+2 if case == "ct131" else n,k),
        valid=lambda n,k: k < n, sample=sample,
        constraints=("C denotes a binomial coefficient. Column k is strictly less than row n.",),
    )


def _binomial_and_race_cases(case):
    if case == "ct89":
        return _case(
            "sum_pascal_symmetric_indices", {"half": (10, 2, 17)},
            lambda half: f"Find the sum of all integers n from 0 through {2*half} for which "
            f"C({2*half},n) + C({2*half},{half}) = C({2*half+1},{half+1}), "
            "where C denotes a binomial coefficient.",
            lambda half: 2 * half,
            lambda half: sum(n for n in range(2*half+1)
                             if comb(2*half,n)+comb(2*half,half)==comb(2*half+1,half+1)),
        )

    if case in {"ct169", "ct769"}:
        quiz = case == "ct169"
        domains = {"trials": (15 if quiz else 7, 2, 20),
                   **({"choices": (2, 2, 6)} if quiz else {"at_least": (4, 1, 20)})}

        def render(trials, choices=2, at_least=None):
            if quiz:
                return (f"Steve guesses independently on {trials} multiple-choice questions, each "
                        f"with {choices} choices and exactly one correct answer. What is the probability "
                        "he gets at least half of the questions right?")
            return (f"The Badgers and Cougars play {trials} independent basketball games. Each team has "
                    f"an equal chance in each game. What is the probability the Badgers win at least {at_least}?")

        def solve(trials, choices=2, at_least=None):
            threshold = (trials + 1) // 2 if quiz else at_least
            return Fraction(sum(comb(trials,k) * (choices-1)**(trials-k)
                                for k in range(threshold,trials+1)), choices**trials)

        def reference(trials, choices=2, at_least=None):
            p = Fraction(1, choices)
            threshold = (trials + 1) // 2 if quiz else at_least
            distribution = [Fraction(1)]
            for _ in range(trials):
                distribution = [p*a + (1-p)*b for a,b in zip([0]+distribution, distribution+[0])]
            return sum(distribution[threshold:])

        def sample(rng):
            n = rng.randint(2, 20)
            return {"trials": n, **({"choices": rng.randint(2, 6)} if quiz
                                    else {"at_least": rng.randint(1, n)})}

        return _case("binomial_right_tail", domains, render, solve, reference, sample=sample,
                     valid=lambda trials, choices=2, at_least=None: at_least is None or at_least <= trials,
                     constraints=() if quiz else ("The required number of wins does not exceed the games played.",))

    if case == "cs140":
        def render(goal, bob, meena, numerator, denominator):
            return (f"Bob and Meena play a game until one reaches {goal} points. On each independent "
                    f"turn Bob scores one point with probability {Fraction(numerator,denominator)} "
                    f"and otherwise Meena scores. The current score is Bob {bob}, Meena {meena}, with "
                    "Meena ahead. What is the probability Meena wins?")

        def solve(goal, bob, meena, numerator, denominator):
            p = Fraction(numerator, denominator)
            x, y = goal - bob, goal - meena
            return sum(comb(y-1+i,i) * (1-p)**y * p**i for i in range(x))

        def reference(goal, bob, meena, numerator, denominator):
            p = Fraction(numerator, denominator)
            dp = [[Fraction(0)] * (goal+1) for _ in range(goal+1)]
            for a in range(goal):
                dp[a][goal] = Fraction(1)
            for a in range(goal-1,bob-1,-1):
                for b in range(goal-1,meena-1,-1):
                    dp[a][b] = p*dp[a+1][b] + (1-p)*dp[a][b+1]
            return dp[bob][meena]

        def sample(rng):
            goal, denominator = rng.randint(4,16), rng.randint(2,10)
            bob, meena = sorted(rng.sample(range(goal),2))
            return {"goal": goal, "bob": bob, "meena": meena,
                    "numerator": rng.randrange(1,denominator), "denominator": denominator}

        return _case(
            "race_to_target_score", {"goal": (10, 4, 16), "bob": (8, 0, 14), "meena": (9, 1, 15),
                                     "numerator": (1, 1, 9), "denominator": (3, 2, 10)},
            render, solve, reference, sample=sample,
            valid=lambda goal,bob,meena,numerator,denominator: bob < meena < goal and numerator < denominator,
            constraints=("Meena is ahead, neither player has won, and both scoring probabilities are positive.",),
        )

    def render(turns, a, b, c, d):
        return (f"Alice starts holding a ball. On each turn the holder either passes to the other person "
                f"or keeps it. Alice passes with probability {Fraction(a,b)} and Bob passes with "
                f"probability {Fraction(c,d)}, independently given who holds the ball. "
                f"What is the probability Alice holds it after {turns} turns?")

    def solve(turns, a, b, c, d):
        alpha, beta = Fraction(a,b), Fraction(c,d)
        p = Fraction(1)
        for _ in range(turns):
            p = p * (1-alpha) + (1-p)*beta
        return p

    def reference(turns, a, b, c, d):
        weights = ((b-a,a),(d-c,c))
        total = Fraction(0)
        for actions in product((0,1), repeat=turns):
            holder, probability = 0, Fraction(1)
            for act in actions:
                probability *= Fraction(weights[holder][act], (b,d)[holder])
                holder ^= act
            if holder == 0:
                total += probability
        return total

    def sample(rng):
        b,d = rng.randint(2,10),rng.randint(2,10)
        return {"turns": rng.randint(1,6), "a": rng.randrange(1,b), "b": b,
                "c": rng.randrange(1,d), "d": d}

    return _case(
        "two_person_ball_pass", {"turns": (2, 1, 6), "a": (1, 1, 9), "b": (2, 2, 10),
                                 "c": (2, 1, 9), "d": (5, 2, 10)},
        render, solve, reference, valid=lambda turns,a,b,c,d: a < b and c < d, sample=sample,
        constraints=("The two passing probabilities lie strictly between zero and one.",),
    )


def _weighted_outcome_cases(case):
    if case == "ct91":
        def sample(rng):
            a = rng.randint(7, 24)
            b = rng.randint(a + 1, 42)
            return {"a": a, "b": b, "age": rng.choice((a,b)) + rng.randint(1,6)}

        return _case(
            "coin_plus_die_target", {"a": (10, 7, 24), "b": (20, 8, 42), "age": (14, 8, 48)},
            lambda a,b,age: f"Erika is {age} years old. She tosses a fair coin labelled {a} and {b} "
            "and independently rolls a fair six-sided die numbered 1 through 6. "
            "What is the probability that the results add to her age?",
            lambda a,b,age: Fraction(int(1 <= age-a <= 6) + int(1 <= age-b <= 6),12),
            lambda a,b,age: Fraction(sum(x+y==age for x,y in product((a,b),range(1,7))),12),
            valid=lambda a,b,age: a < b and any(1 <= age-v <= 6 for v in (a,b)), sample=sample,
            constraints=("The labels are distinct and the target age is attainable.",),
        )
    if case == "ct302":
        def count(slips, low, high, mean_cents):
            return Fraction(slips * (100*high - mean_cents), 100*(high-low))

        def valid(slips, low, high, mean_cents):
            if low >= high:
                return False
            quantity = count(slips,low,high,mean_cents)
            return quantity.denominator == 1 and 0 < quantity < slips

        def sample(rng):
            n = rng.choice((5,8,10,12,16,20,25,40))
            low = rng.randint(0,15)
            high = rng.randint(low+1,25)
            feasible = [x for x in range(1,n) if 100*(high-low)*x % n == 0]
            quantity = rng.choice(feasible)
            mean = 100 * high - 100*(high-low)*quantity // n
            return {"slips": n, "low": low, "high": high, "mean_cents": mean}

        return _case(
            "invert_two_value_expectation", {"slips": (12, 5, 48), "low": (2, 0, 15),
                                             "high": (7, 1, 25), "mean_cents": (325, 1, 2500)},
            lambda slips,low,high,mean_cents: f"A bag contains {slips} slips labelled either {low} or "
            f"{high}, with both labels represented. A uniformly chosen slip has expected label "
            f"{mean_cents//100}.{mean_cents%100:02}. How many slips are labelled {low}?",
            count, lambda slips,low,high,mean_cents: next(x for x in range(1,slips)
                if Fraction(sum([low]*x+[high]*(slips-x)),slips)==Fraction(mean_cents,100)),
            valid=valid, sample=sample,
            constraints=("low < high, and the displayed mean (mean_cents/100) implies "
                         "a whole number of slips of each label, both positive.",),
        )
    if case == "ct529":
        def sample(rng):
            fixed = rng.randint(2,6)
            return {"fixed": fixed, "low": rng.randrange(1,fixed),
                    "high": rng.randint(fixed+1,12), "copies": rng.randint(1,5)}

        return _case(
            "constant_die_strictly_beats_two", {"fixed": (5, 2, 6), "low": (2, 1, 5),
                                               "high": (6, 3, 12), "copies": (3, 1, 5)},
            lambda fixed,low,high,copies: f"All six faces of Allison's cube show {fixed}. Brian's "
            f"cube has faces numbered 1 through 6. Noah's cube has {copies} faces showing {low} "
            f"and {6-copies} showing {high}. All cubes are rolled independently, with equally likely "
            "faces. What is the probability Allison's result strictly exceeds both others?",
            lambda fixed,low,high,copies: Fraction((fixed-1)*copies,36),
            lambda fixed,low,high,copies: Fraction(sum(fixed > max(b,n) for b,n in
                product(range(1,7),[low]*copies+[high]*(6-copies))),36),
            valid=lambda fixed,low,high,copies: low < fixed < high, sample=sample,
            constraints=("Noah's labels lie strictly below and strictly above Allison's label.",),
        )
    if case == "ct555":
        return _case(
            "container_mixture_probability", {"green": (4, 1, 20), "special_red": (8, 1, 20),
                                              "other_red": (2, 1, 20), "others": (2, 1, 6)},
            lambda green,special_red,other_red,others: f"One container holds {special_red} red and "
            f"{green} green balls. Each of {others} other containers holds {other_red} red and "
            f"{green} green balls. Select a container uniformly, then one ball uniformly from it. "
            "What is the probability that the ball is green?",
            lambda green,special_red,other_red,others:
            (Fraction(green,green+special_red) + others*Fraction(green,green+other_red))/(others+1),
            lambda green,special_red,other_red,others: sum(
                Fraction(1,(others+1)*(green+red)) for red in [special_red]+[other_red]*others
                for _ in range(green)),
        )
    if case == "ct761":
        def solve(total, numerator, denominator):
            winning_pairs = Fraction(numerator,denominator) * comb(total,2)
            if winning_pairs.denominator != 1:
                return 0
            return (1 + isqrt(1 + 8 * int(winning_pairs))) // 2

        def valid(total, numerator, denominator):
            n = solve(total,numerator,denominator)
            return 2 <= n < total and Fraction(comb(n,2),comb(total,2)) == Fraction(numerator,denominator)

        def sample(rng):
            total = rng.randint(3,50)
            red = rng.randrange(2,total)
            chance = Fraction(comb(red,2),comb(total,2))
            return {"total": total, "numerator": chance.numerator, "denominator": chance.denominator}

        def reference(total, numerator, denominator):
            pairs = tuple(combinations(range(total),2))
            return next(k for k in range(2,total) if sum(j < k for _,j in pairs) * denominator
                        == len(pairs) * numerator)

        return _case(
            "invert_without_replacement_pair", {"total": (10, 3, 50), "numerator": (1, 1, 1225),
                                               "denominator": (15, 2, 1225)},
            lambda total,numerator,denominator: f"A bag contains {total} red or yellow balls, with "
            f"both colors represented. Two balls are selected uniformly without replacement. "
            f"The probability both are red is {Fraction(numerator,denominator)}. How many red balls are there?",
            solve, reference, valid=valid, sample=sample,
            constraints=("The probability is attainable with two or more red balls and at least one yellow ball.",),
        )
    if case == "cs177":
        def render(a, b, kinds):
            faces = [", ".join(str(v) for v in range(start,start+kinds) for _ in range(2))
                     for start in (a,b)]
            return (f"One fair die has faces {faces[0]}. Another has faces {faces[1]}. "
                    "The dice are rolled independently. What is the probability their sum is odd?")

        def solve(a, b, kinds):
            n = (kinds + a % 2) // 2
            m = (kinds + b % 2) // 2
            return Fraction(n*(kinds-m) + m*(kinds-n), kinds*kinds)

        return _case(
            "sum_parity_dice_with_repeated_labels", {"a": (1, 1, 15), "b": (4, 1, 15), "kinds": (3, 2, 7)},
            render, solve, lambda a,b,kinds: Fraction(sum((x+y)%2 for x,y in product(
                [v for v in range(a,a+kinds) for _ in range(2)],
                [v for v in range(b,b+kinds) for _ in range(2)])),4*kinds*kinds),
        )
    return _case(
        "weighted_spinner_matching", {"labels": (4, 2, 12)},
        lambda labels: f"A spinner is labelled 1 through {labels}; the probability of label k "
        f"is k/{labels*(labels+1)//2}. Phil and Sarah spin independently. What is the probability "
        "they get the same label?",
        lambda labels: Fraction(2*(2*labels+1),3*labels*(labels+1)),
        lambda labels: Fraction(sum(a==b for a,b in product(
            [i for i in range(1,labels+1) for _ in range(i)],repeat=2)),(labels*(labels+1)//2)**2),
    )


def _sequence_and_set_cases(case):
    if case in {"ct470", "ct562"}:
        def render(midpoint, radius):
            low, high = midpoint-radius, midpoint+radius
            return (f"Remove one integer from the consecutive integers {low} through {high}, inclusive. "
                    "Then choose two distinct integers uniformly from those remaining. Which integer should "
                    f"be removed to maximize the probability the two chosen integers sum to {2*midpoint}?")

        def reference(midpoint, radius):
            numbers = tuple(range(midpoint-radius,midpoint+radius+1))
            return max(numbers, key=lambda removed: sum(a+b==2*midpoint and removed not in (a,b)
                                                        for a,b in combinations(numbers,2)))

        return _case(
            "remove_number_to_maximize_pair_event",
            {"midpoint": (6 if case == "ct470" else 5, 5, 25),
             "radius": (5 if case == "ct470" else 6, 2, 18)},
            render, lambda midpoint,radius: midpoint, reference,
            valid=lambda midpoint,radius: case == "ct562" or radius < midpoint,
            sample=lambda rng: _sample_pair_midpoint(rng, case == "ct470"),
            constraints=("The interval is symmetric about half the requested sum.",)
            + (("The smallest integer in the interval is positive.",) if case == "ct470" else ()),
        )
    if case == "ct68":
        def length(high):
            return sum(high-10**k+1 for k in range(len(str(high))))

        def solve(high, index):
            top = high
            while top:
                width = len(str(top))
                bottom = 10 ** (width-1)
                span = (top-bottom+1)*width
                if index <= span:
                    number_offset,digit_offset = divmod(index-1,width)
                    return int(str(top-number_offset)[digit_offset])
                index -= span
                top = bottom-1
            raise ValueError("index outside concatenation")

        def sample(rng):
            high = rng.randint(10,700)
            return {"high": high, "index": rng.randint(1,length(high))}

        return _case(
            "indexed_descending_concatenation", {"high": (50, 10, 700), "index": (67, 1, 1992)},
            lambda high,index: f"Write the consecutive integers from {high} down to 1, in that "
            f"order, without separators. What is digit number {index}, counting from the left?",
            solve, lambda high,index: int("".join(str(n) for n in range(high,0,-1))[index-1]),
            valid=lambda high,index: index <= length(high), sample=sample,
            constraints=("The one-based index is within the concatenated decimal string.",),
        )
    if case == "ct222":
        def sample(rng):
            daughters = rng.randint(3,10)
            return {"daughters": daughters, "total": daughters*(1+rng.randrange(1,daughters))}

        return _case(
            "two_generations_count_leaves", {"daughters": (6, 3, 10), "total": (30, 6, 110)},
            lambda daughters,total: f"Bertha has {daughters} daughters and no sons. Some of those daughters "
            f"have {daughters} daughters of their own and the rest have none. Bertha has {total} "
            "daughters and granddaughters combined and no great-granddaughters. How many of her "
            "daughters and granddaughters have no daughters?",
            lambda daughters,total: total-total//daughters+1,
            lambda daughters,total: next((daughters-k)+k*daughters for k in range(1,daughters+1)
                                         if daughters+k*daughters==total),
            valid=lambda daughters,total: total%daughters==0 and daughters < total < daughters*(daughters+1),
            sample=sample, constraints=("The implied number of daughters with children is a positive "
                                        "whole number at most daughters.",),
        )
    if case == "cs421":
        def reference(top, index):
            value, direction = 1, 1
            for _ in range(1,index):
                if value == top:
                    direction = -1
                elif value == 1:
                    direction = 1
                value += direction
            return value

        return _case(
            "alternating_bounce_count", {"top": (9, 2, 35), "index": (1000, 1, 3000)},
            lambda top,index: f"Suelyn counts up from 1 through {top}, then down to 1, then up "
            f"again, reversing direction at each endpoint without repeating it. What is term {index}?",
            lambda top,index: top - abs((index-1)%(2*top-2)-(top-1)), reference,
        )
    def sample(rng):
        b,d = rng.randint(2,8),rng.randint(2,8)
        return {"a": rng.randrange(1,b), "b": b, "c": rng.randrange(1,d), "d": d,
                "total": lcm(b,d)*rng.randint(1,5)}

    def valid(a,b,c,d,total):
        return a < b and c < d and total*a % b == 0 and total*c % d == 0

    return _case(
        "minimum_overlap_from_fractions", {"a": (3, 1, 7), "b": (4, 2, 8), "c": (6, 1, 7),
                                          "d": (7, 2, 8), "total": (28, 2, 300)},
        lambda a,b,c,d,total: f"In a class of {total} students, {Fraction(a,b)} have brown hair "
        f"and {Fraction(c,d)} are right-handed. What is the smallest possible number with both traits?",
        lambda a,b,c,d,total: max(0,total*a//b+total*c//d-total),
        lambda a,b,c,d,total: len(set(range(total*a//b)) & set(range(total-total*c//d,total))),
        valid=valid, sample=sample, constraints=("Both fractions are proper and each implies a whole count.",),
    )


def _sample_pair_midpoint(rng, positive):
    midpoint = rng.randint(5,25)
    return {"midpoint": midpoint, "radius": rng.randint(2,min(18,midpoint-1) if positive else 18)}


def _arrangement_round_two(case):
    if case == "ct505":
        def sample(rng):
            members = rng.randint(2,12)
            return {"schools": rng.randint(2,6), "members": members, "host": rng.randint(1,members),
                    "visitor": rng.randint(1,members)}

        return _case(
            "host_and_visiting_delegations",
            {"schools": (3, 2, 6), "members": (5, 2, 12), "host": (2, 1, 12), "visitor": (1, 1, 12)},
            lambda schools,members,host,visitor: f"A club has {members} members from each of "
            f"{schools} schools. It chooses one school to host a meeting. The host sends {host} "
            f"representatives and each other school sends {visitor}. In how many ways can the host "
            "and the groups of representatives be chosen?",
            lambda schools,members,host,visitor: schools*comb(members,host)*comb(members,visitor)**(schools-1),
            lambda schools,members,host,visitor: sum(prod(_choice_reference(members,host if i==j else visitor)
                for i in range(schools)) for j in range(schools)),
            valid=lambda schools,members,host,visitor: max(host,visitor) <= members, sample=sample,
            constraints=("Each requested delegation fits within its school.",),
        )
    if case == "ct567":
        return _case(
            "restricted_rotoka_license_plate", {"length": (5, 3, 11)},
            lambda length: f"Rotoka license plates use only letters A, E, G, I, K, O, P, R, S, T, U, V. "
            f"How many {length}-letter plates begin with G or K, end with T, contain no S, "
            "and have no repeated letters?",
            lambda length: 2*_falling(9,length-2),
            lambda length: 2*_permutation_reference(9,length-2),
        )
    if case in {"ct600", "cs265"}:
        lineup = case == "ct600"
        domains = {"people": (10, 4, 16), "eligible": (3, 1, 16)} if lineup else {
            "people": (4, 3, 9), "eligible": (2, 1, 9)}

        def render(people, eligible):
            if lineup:
                return (f"A football team has {people} players. Only {eligible} are eligible for "
                        "offensive lineman. Any player may fill the quarterback, running back, or wide "
                        "receiver position. How many lineups with four different players are possible?")
            return (f"There are {people} people and {people} distinct seats in a vehicle, including a "
                    f"driver's seat. Exactly {eligible} of the people can drive. How many seating arrangements "
                    "are possible when the driver is eligible?")

        def reference(people, eligible):
            free = 3 if lineup else people-1
            return sum(1 for choice in permutations(range(people),free+1) if choice[0] < eligible)

        def sample(rng):
            people = rng.randint(*domains["people"][1:])
            return {"people": people, "eligible": rng.randint(1,people)}

        return _case(
            "one_restricted_ordered_position", domains, render,
            lambda people,eligible: eligible*_falling(people-1,3 if lineup else people-1),
            reference, valid=lambda people,eligible: eligible <= people, sample=sample,
            constraints=("The eligible group is a nonempty subset of all people.",),
        )
    if case == "cs6":
        return _case(
            "roman_strings_with_required_letter", {"length": (3, 2, 12), "minimum": (1, 1, 12)},
            lambda length,minimum: f"How many strings of length {length} from A through Z contain "
            f"the letter A at least {minimum} times? Letters may repeat.",
            lambda length,minimum: sum(comb(length,k)*25**(length-k) for k in range(minimum,length+1)),
            lambda length,minimum: sum(25**(length-sum(bits)) for bits in product((0,1),repeat=length)
                                       if sum(bits)>=minimum),
            valid=lambda length,minimum: minimum <= length,
            sample=lambda rng: _sample_string_occurrences(rng),
            constraints=("The required number of A's does not exceed the string length.",),
        )
    if case == "cs23":
        def reference(books, kinds):
            endings = [1]*kinds
            for _ in range(1,books):
                endings = [sum(endings)-n for n in endings]
            return sum(endings)

        def render(books, kinds):
            names = ("math","history","physics","art","biology","music","geography")
            return (f"A shelf holds {books} books, and copies are available without limit in "
                    f"these subjects: {', '.join(names[:kinds])}. Copies within a subject are "
                    "identical. How many shelf arrangements avoid placing two books of the same "
                    "subject next to each other?")

        return _case("no_adjacent_identical_books", {"books": (8, 2, 18), "kinds": (3, 2, 7)},
                     render, lambda books,kinds: kinds*(kinds-1)**(books-1), reference)
    if case == "cs167":
        return _case(
            "choose_unordered_starters", {"roster": (4, 3, 15), "starters": (3, 2, 8)},
            lambda roster,starters: f"A basketball team has {roster} players on its roster. "
            f"How many ways can {starters} starters be chosen if the positions are not assigned?",
            lambda roster,starters: comb(roster,starters),
            lambda roster,starters: _choice_reference(roster,starters),
            valid=lambda roster,starters: starters < roster,
            sample=lambda rng: _sample_starting_team(rng),
            constraints=("The number of starters is strictly less than the roster size.",),
        )
    if case == "cs222":
        return _case(
            "cross_term_in_affine_square", {"a": (3, 1, 18), "b": (2, 1, 18), "c": (1, 1, 18)},
            lambda a,b,c: f"What is the coefficient of xy in the expansion of ({a}x+({b}y+{c}))²?",
            lambda a,b,c: 2*a*b,
            lambda a,b,c: ((a+b+c)**2-(a+c)**2-(b+c)**2+c*c),
        )
    if case == "cs283":
        return _case(
            "one_country_per_region", {"europe": (6, 2, 12), "asia": (4, 2, 12),
                                      "north_america": (3, 2, 12), "africa": (7, 2, 12)},
            lambda europe,asia,north_america,africa: f"An international commission includes one "
            f"country from each pool: {europe} European countries, {asia} Asian countries, "
            f"{north_america} North American countries and {africa} African countries. "
            "How many commissions can be formed?",
            lambda **p: prod(p.values()),
            lambda **p: sum(1 for _ in product(*(range(n) for n in p.values()))),
        )
    def sample(rng):
        cards = rng.randint(5,14)
        return {"cards": cards, "draw": rng.randint(2,min(5,cards))}

    def render(cards, draw):
        alphabet = "MATHCBEDFGIJKL"
        labels = ", ".join(alphabet[:cards])
        wanted = ", ".join(alphabet[:draw])
        return (f"Distinct cards labelled {labels} are placed in a hat. Draw {draw} uniformly "
                f"without replacement. What is the probability of drawing {wanted} in this order?")

    return _case(
        "specified_ordered_card_sequence", {"cards": (7, 5, 14), "draw": (4, 2, 5)},
        render, lambda cards,draw: Fraction(1,_falling(cards,draw)),
        lambda cards,draw: prod(Fraction(1,cards-i) for i in range(draw)),
        sample=sample,
    )


def _sample_starting_team(rng):
    roster = rng.randint(3,15)
    return {"roster": roster, "starters": rng.randint(2,min(8,roster-1))}


def _sample_string_occurrences(rng):
    length = rng.randint(2,12)
    return {"length": length, "minimum": rng.randint(1,length)}


def _round_two_number_theory(case):
    if case in {"nt40", "nt153", "nt240"}:
        return _power_factor_cases(case)
    if case in {"nt383", "nt543", "ns467", "ns506"}:
        return _crt_round_two(case)
    if case in {"nt71", "nt259", "nt389", "nt415", "nt419", "nt785", "ns484"}:
        return _residue_round_two(case)
    if case in {"nt416", "ns372", "ns390", "nt236", "ns305", "ns513"}:
        return _base_digit_round_two(case)
    if case == "nt188":
        def reference(n, constant):
            first = n*n-n+constant
            second = (n+1)**2-(n+1)+constant
            return next(d for d in range(2*n,0,-1) if first%d==second%d==0)

        return _case(
            "gcd_of_adjacent_quadratic_values", {"n": (100, 2, 200), "constant": (2010, 1, 3000)},
            lambda n,constant: f"Let f(x) = x² − x + {constant}. What is the greatest common "
            f"divisor of f({n}) and f({n+1})?",
            lambda n,constant: gcd(n*n-n+constant,2*n), reference,
        )
    return None


def _power_factor_cases(case):
    if case == "nt240":
        def sample(rng):
            e = rng.randint(1,10)
            return {"num_exp": rng.randint(e,16), "six_exp": e, "five_exp": rng.randint(1,10)}

        return _case(
            "terminating_decimal_after_prime_cancellation",
            {"num_exp": (6, 1, 16), "six_exp": (4, 1, 10), "five_exp": (4, 1, 10)},
            lambda num_exp,six_exp,five_exp: f"How many digits are to the right of the decimal point "
            f"in the shortest decimal representation of $\\frac{{3^{{{num_exp}}}}}{{6^{{{six_exp}}}\\cdot {5**five_exp}}}$?",
            lambda num_exp,six_exp,five_exp: max(six_exp,five_exp),
            lambda num_exp,six_exp,five_exp: len(_long_division(3**num_exp,6**six_exp*5**five_exp)),
            valid=lambda num_exp,six_exp,five_exp: num_exp >= six_exp,
            sample=sample, constraints=("The numerator cancels all factors of 3 in the denominator.",),
        )

    def solve(square_multiplier, cube_multiplier):
        s, c = _factorization(square_multiplier), _factorization(cube_multiplier)
        def exponent(p):
            mod3 = -c.get(p,0) % 3
            return mod3 + 3 * ((s.get(p,0) + mod3) % 2)
        return prod(p**exponent(p) for p in s.keys() | c.keys())

    def reference(square_multiplier, cube_multiplier):
        primes = [p for p in range(2,max(square_multiplier,cube_multiplier)+1)
                  if _is_prime(p) and square_multiplier*cube_multiplier%p==0]

        def valuation(n, p):
            e = 0
            while n % p == 0:
                e += 1
                n //= p
            return e

        return prod(next(p**k for k in range(6)
                         if valuation(square_multiplier*p**k,p)%2==0
                         and valuation(cube_multiplier*p**k,p)%3==0)
                    for p in primes)

    a,b = (2,3) if case=="nt40" else (3,2)
    return _case(
        "simultaneous_square_and_cube_completion",
        {"square_multiplier": (a, 2, 36), "cube_multiplier": (b, 2, 36)},
        lambda square_multiplier,cube_multiplier: f"What is the least positive integer n such that "
        f"{square_multiplier}n is a perfect square and {cube_multiplier}n is a perfect cube?",
        solve, reference,
    )


def _crt_pair(a, m, b, n):
    common = gcd(m,n)
    if (b-a)%common:
        raise ValueError("incompatible congruences")
    reduced = n//common
    shift = (b-a)//common * pow(m//common,-1,reduced) % reduced
    return (a+m*shift)%lcm(m,n)


def _crt_round_two(case):
    if case in {"nt383", "nt543"}:
        largest = case == "nt383"
        m,n,a,b = (9,5,1,3) if largest else (6,5,4,3)
        domains = {"m": (m, 2, 20), "n": (n, 2, 20), "a": (a, 0, 19), "b": (b, 0, 19)}
        if not largest:
            domains["final"] = (7, 2, 20)

        def render(m,n,a,b,final=None):
            if largest:
                return (f"What is the greatest three-digit integer that leaves remainder {a} "
                        f"upon division by {m}, and remainder {b} upon division by {n}?")
            return (f"A box holds the least positive number of coins leaving remainders {a} and {b} "
                    f"when divided among {m} and {n} people, respectively. What remainder is left "
                    f"when the coins are divided among {final} people?")

        def solve(m,n,a,b,final=None):
            residue = _crt_pair(a,m,b,n)
            step = lcm(m,n)
            if largest:
                return 999 - (999-residue)%step
            return (residue or step)%final

        def reference(m,n,a,b,final=None):
            space = range(999,99,-1) if largest else range(1,m*n+1)
            candidate = next(value for value in space if value%m==a and value%n==b)
            return candidate if largest else candidate%final

        def sample(rng):
            m,n = rng.sample(range(2,21),2)
            witness = rng.randint(1,1000)
            return {"m":m, "n":n, "a":witness%m, "b":witness%n,
                    **({} if largest else {"final":rng.randint(2,20)})}

        return _case(
            "two_congruences_with_positive_extreme", domains, render, solve, reference,
            valid=lambda m,n,a,b,final=None: m!=n and a<m and b<n and (a-b)%gcd(m,n)==0,
            sample=sample, constraints=("The distinct moduli have compatible canonical remainders.",),
        )
    if case == "ns467":
        def sample(rng):
            a,b = rng.sample(range(4,20),2)
            return {"a":a,"b":b,"remainder":rng.randrange(1,min(a,b)),"minimum":rng.randint(30,450)}

        return _case(
            "least_above_bound_same_two_remainders",
            {"a": (12, 4, 19), "b": (13, 4, 19), "remainder": (1, 1, 18),
             "minimum": (200, 30, 450)},
            lambda a,b,remainder,minimum: f"Your friend has at least {minimum} eggs. When packed into "
            f"containers holding {a} eggs each, {remainder} eggs are left over. When packed into "
            f"containers holding {b} eggs each, the same {remainder} eggs are left over. "
            "What is the least possible number of eggs?",
            lambda a,b,remainder,minimum: minimum + (remainder-minimum)%lcm(a,b),
            lambda a,b,remainder,minimum: next(n for n in range(minimum,minimum+a*b)
                                               if n%a==n%b==remainder),
            valid=lambda a,b,remainder,minimum: a != b and remainder < min(a,b), sample=sample,
            constraints=("The capacities are distinct and the common remainder is smaller than both.",),
        )

    def possible(scale, remainder, final, bound):
        return [age for age in range(1,bound) if age % (12*scale) == remainder and age%final==0]

    def sample(rng):
        scale,remainder,final,first,step = rng.choice(_age_congruence_choices())
        return {"scale":scale,"remainder":remainder,"final":final,
                "bound":rng.randint(max(30,first+1),min(120,first+step))}

    return _case(
        "unique_age_under_congruences",
        {"scale": (1, 1, 3), "remainder": (1, 1, 5), "final": (7, 2, 14), "bound": (75, 30, 120)},
        lambda scale,remainder,final,bound: f"Rosa's age leaves remainder {remainder} when divided "
        f"by {2*scale}, {3*scale}, {4*scale}, or {6*scale}, and is divisible by {final}. "
        f"She is less than {bound} years old. What is her age in whole years?",
        lambda scale,remainder,final,bound: _crt_pair(remainder,12*scale,0,final),
        lambda scale,remainder,final,bound: next(age for age in range(final,bound,final)
            if all(age%(scale*k)==remainder for k in (2,3,4,6))),
        valid=lambda scale,remainder,final,bound: remainder < 2*scale
        and len(possible(scale,remainder,final,bound))==1, sample=sample,
        constraints=("The common remainder is canonical for all four divisors. Exactly one positive "
                     "age below the bound satisfies the congruences.",),
    )


@lru_cache(maxsize=1)
def _age_congruence_choices():
    options = []
    for scale,final in product(range(1,4),range(2,15)):
        period = lcm(12*scale,final)
        for residue in range(1,2*scale):
            if residue%gcd(12*scale,final):
                continue
            first = _crt_pair(residue,12*scale,0,final)
            if max(30,first+1) <= min(120,first+period):
                options.append((scale,residue,final,first,period))
    return tuple(options)


def _residue_round_two(case):
    if case in {"nt71", "nt415"}:
        powers = case == "nt71"
        domains = {"modulus": (5 if powers else 20, 2, 50),
                   "r": (4 if powers else 8, 0, 49), "s": (2 if powers else 16, 0, 49)}
        if not powers:
            domains.update(a=(4, 2, 12), b=(3, 2, 12))

        def matching(modulus,r,s,a=None,b=None):
            if powers:
                return [n for n in range(modulus) if n*n%modulus==r and n**3%modulus==s]
            return [n for n in range(modulus) if a*n%modulus==r and b*n%modulus==s]

        def render(modulus,r,s,a=None,b=None):
            if powers:
                return (f"For a positive integer n, the remainders of n² and n³ upon division by "
                        f"{modulus} are {r} and {s}, respectively. What is the remainder of n?")
            return (f"If {a}x ≡ {r} (mod {modulus}) and {b}x ≡ {s} (mod {modulus}), "
                    f"what is the remainder of x² when divided by {modulus}?")

        def solve(modulus,r,s,a=None,b=None):
            if powers and gcd(r,modulus)==1:
                return s*pow(r,-1,modulus)%modulus
            n = matching(modulus,r,s,a,b)[0]
            return n if powers else n*n%modulus

        def reference(modulus,r,s,a=None,b=None):
            p,q = ((lambda n:n*n),(lambda n:n**3)) if powers else ((lambda n:a*n),(lambda n:b*n))
            return next((n if powers else n*n)%modulus for n in range(modulus,2*modulus)
                        if (p(n)-r)%modulus==(q(n)-s)%modulus==0)

        def sample(rng):
            modulus = rng.randint(2,50)
            if powers:
                witness = rng.choice(tuple(n for n in range(1,modulus) if gcd(n,modulus)==1))
                return {"modulus":modulus,"r":witness*witness%modulus,"s":witness**3%modulus}
            a,b = rng.choice(tuple((a,b) for a in range(2,13) for b in range(2,13) if gcd(a,b,modulus)==1))
            witness = rng.randrange(modulus)
            return {"modulus":modulus,"r":a*witness%modulus,"s":b*witness%modulus,"a":a,"b":b}

        return _case("recover_residue_from_two_conditions", domains, render, solve, reference,
                     valid=lambda **p: len(matching(**p))==1, sample=sample,
                     constraints=("Exactly one residue class satisfies both conditions.",))
    if case == "nt259":
        def sample(rng):
            bags = rng.randint(2,22)
            return {"bags":bags,"each":rng.choice(tuple(n for n in range(2,26) if gcd(n,bags)==1))}

        return _case(
            "least_box_count_after_eating_one", {"each": (13, 2, 25), "bags": (9, 2, 22)},
            lambda each,bags: f"Donna has n boxes with {each} doughnuts each. She eats one doughnut "
            f"and can pack all remaining doughnuts into bags of {bags} with none left over. "
            "What is the smallest positive n?",
            lambda each,bags: pow(each,-1,bags),
            lambda each,bags: next(n for n in range(1,bags+1) if (each*n-1)%bags==0),
            valid=lambda each,bags: gcd(each,bags)==1, sample=sample,
            constraints=("The box and bag capacities are coprime, so the congruence has a solution.",),
        )
    if case == "nt389":
        def matching(multiplier,suffix):
            return [t for t in range(10,100) if multiplier*t%100==suffix]

        def sample(rng):
            multiplier = rng.choice(tuple(n for n in range(2,41) if gcd(n,100)==1))
            return {"multiplier":multiplier,"suffix":multiplier*rng.randint(10,99)%100}

        return _case(
            "inverse_trailing_two_digits", {"multiplier": (11, 2, 40), "suffix": (36, 0, 99)},
            lambda multiplier,suffix: f"There is exactly one positive two-digit integer t such that "
            f"the final two digits of {multiplier} × t are {suffix:02}. What is t?",
            lambda multiplier,suffix: matching(multiplier,suffix)[0],
            lambda multiplier,suffix: next(t for t in range(10,100)
                                            if str(multiplier*t).zfill(2)[-2:]==f"{suffix:02}"),
            valid=lambda multiplier,suffix: len(matching(multiplier,suffix))==1, sample=sample,
            constraints=("The suffix has exactly one positive two-digit solution.",),
        )
    if case in {"nt419","nt785"}:
        divisor,r,s = (15,37,9) if case=="nt419" else (35,64,99)
        factors = (3,2) if case=="nt419" else (2,3)

        def sample(rng):
            divisor = rng.randint(2,40)
            a,b = rng.sample(range(2,7),2)
            return {"divisor":divisor,"a":a,"b":b,"r":rng.randrange(divisor*a),
                    "s":rng.randrange(divisor*b)}

        return _case(
            "sum_remainders_under_common_divisor",
            {"divisor": (divisor, 2, 40), "a": (factors[0], 2, 6), "b": (factors[1], 2, 6),
             "r": (r, 0, 239), "s": (s, 0, 239)},
            lambda divisor,a,b,r,s: f"The remainder of x modulo {divisor*a} is {r}, and "
            f"the remainder of y modulo {divisor*b} is {s}. What is the remainder of x+y "
            f"upon division by {divisor}?",
            lambda divisor,a,b,r,s: (r+s)%divisor,
            lambda divisor,a,b,r,s: (r+s + (13*a+17*b)*divisor)%divisor,
            valid=lambda divisor,a,b,r,s: a!=b and r<divisor*a and s<divisor*b, sample=sample,
            constraints=("The source moduli are distinct multiples of the requested divisor, "
                         "and both given remainders are canonical.",),
        )

    def sample(rng):
        page = rng.randint(5,50)
        return {"bound":rng.randint(50,650),"page":page,"last":rng.randrange(1,page)}

    return _case(
        "least_stamp_count_with_partial_page", {"bound": (200, 50, 650), "page": (30, 5, 50), "last": (5, 1, 49)},
        lambda bound,page,last: f"Your friend has more than {bound} stamps and puts {page} stamps "
        f"on each full album page. Every page except the last is full, and the last contains {last} "
        "stamps. What is the smallest possible number of stamps?",
        lambda bound,page,last: bound + 1 + (last-bound-1)%page,
        lambda bound,page,last: next(n for n in range(bound+1,bound+page+1) if n%page==last),
        valid=lambda bound,page,last: last<page, sample=sample,
        constraints=("The positive count on the last page is smaller than page capacity.",),
    )


def _base_digit_round_two(case):
    if case in {"nt416", "ns372", "ns390"}:
        middle_missing = case=="ns390"
        width = {"nt416":4,"ns372":5,"ns390":3}[case]
        fixed = {"nt416":15,"ns372":357,"ns390":2}[case]
        divisor = 7 if middle_missing else 18

        def numeral(fixed,digit):
            if middle_missing:
                return 101*fixed + 10*digit
            return (10**(width-1)+1)*digit + 10*fixed

        def render(fixed,divisor):
            digits = f"{fixed}x{fixed}" if middle_missing else f"x{fixed:0{width-2}d}x"
            return (f"In the positive {width}-digit numeral ${digits}$, every x is the same decimal "
                    f"digit. If the numeral is divisible by {divisor}, what is x?")

        def candidates(fixed,divisor):
            return [d for d in range(0 if middle_missing else 1,10) if numeral(fixed,d)%divisor==0]

        def sample(rng):
            primes = [p for p in (11,13,17,19,23,29,31,37) if (10**(width-1)+1)%p]
            if middle_missing:
                fixed,divisor = rng.choice(tuple((a,p) for a in range(1,10) for p in primes
                                                  if len(candidates(a,p))==1))
            else:
                divisor = rng.choice(primes)
                target = rng.randint(1,9)
                residue = -(10**(width-1)+1)*target * pow(10,-1,divisor) % divisor
                fixed = residue + divisor*rng.randint(0,(10**(width-2)-1-residue)//divisor)
            return {"fixed":fixed,"divisor":divisor}

        def reference(fixed,divisor):
            if middle_missing:
                pattern = f"{fixed}x{fixed}"
            else:
                pattern = f"x{fixed:0{width-2}d}x"
            return next(d for d in range(0 if middle_missing else 1,10)
                        if int(pattern.replace("x",str(d)))%divisor==0)

        return _case(
            "unique_missing_digit_by_divisibility",
            {"fixed": (fixed, 1 if middle_missing else 0, 9 if middle_missing else 10**(width-2)-1),
             "divisor": (divisor, 2, 40)},
            render, lambda fixed,divisor: candidates(fixed,divisor)[0], reference,
            valid=lambda fixed,divisor: len(candidates(fixed,divisor))==1, sample=sample,
            constraints=("Exactly one decimal digit gives the indicated width and divisibility.",),
        )
    if case == "nt236":
        def sample(rng):
            base,seats = rng.randint(2,10),rng.randint(2,8)
            low = (base+seats-1)//seats
            upper = min(120,(base**4-1)//seats)
            return {"digits":_base_encode(seats*rng.randint(low,upper),base),"base":base,"seats":seats}

        return _case(
            "bench_capacity_given_in_another_base",
            {"digits": (204, 10, 9999), "base": (6, 2, 10), "seats": (2, 2, 8)},
            lambda digits,base,seats: f"A shop has exactly enough benches for ${digits}_{{{base}}}$ "
            f"people if each bench seats {seats}. How many benches does it have? Give the answer in base ten.",
            lambda digits,base,seats: _digit_value(digits,base)//seats,
            lambda digits,base,seats: len(range(0,int(str(digits),base),seats)),
            valid=lambda digits,base,seats: max(map(int,str(digits)))<base and _digit_value(digits,base)%seats==0,
            sample=sample, constraints=("The digits fit the base and the total capacity is a multiple "
                                        "of the positive seats per bench.",),
        )

    def sample(rng):
        base = rng.randint(2,12)
        digits = _sample_based_digits(rng,base,3)
        return {"digits":digits,"value":_digit_value(digits,base)}

    def matching(digits,value):
        lower = max(2,max(map(int,str(digits)))+1)
        return next((b for b in range(lower,13) if _digit_value(digits,b)==value),None)

    def reference(digits,value):
        a,b,c = map(int,str(digits))
        return next(base for base in range(max(2,a+1,b+1,c+1),13)
                    if a*base*base+b*base+c==value)

    digits,value = (321,57) if case=="ns305" else (131,55)
    return _case(
        "infer_base_of_three_digit_numeral", {"digits": (digits, 100, 999), "value": (value, 4, 1413)},
        lambda digits,value: f"The base-b numeral ${digits}_b$ equals {value} in base ten. What is the base b?",
        matching, reference, valid=lambda digits,value: matching(digits,value) is not None, sample=sample,
        constraints=("The represented integer is consistent with a base from 2 through 12, "
                     "and all displayed digits are smaller than that base.",),
    )

# Curated bindings require the reviewed source text and ID to match.
_STATEMENT_HASHES = {
    "nt5": "fc474d165fef9decee347a4604bf832f0ee91a280ff397be9edc55b30ac3604d",
    "nt12": "d982f3b12bbbb45cb1d011c5e49501e5488b728c3363a23d9246ff8feec557a1",
    "nt24": "12319f316d341d36bbfe1508e1b024519c40e6dd411f6ab7357bfa6fad21ef41",
    "nt28": "e16cd2f1183e02c5be744242266e700246a9238a0e3b4c419539dd92846210e7",
    "nt49": "b6c776e1c0586aaa6defd34c759a573b5e68d1d40184ee5e839b483b9c0ea2b8",
    "nt56": "8294bf6fbbf31b32d4d70866a3b5ff881783dacae1a62335e45d0a17b056ba7d",
    "nt67": "93f358b5a0e4d8fcdca5717c95f098448606dd0ed7da54fae73e20a84f3be391",
    "nt82": "9cb09f2639effcf577c749fe9194d07aa59b80a20cd1b5bd89df616be49fc625",
    "nt87": "c23df35bab4e4ccfbcbbaa1d583ad60712364dd8f7a09905d825f8597ef610d0",
    "nt107": "c7da1398ea54b4472eca4789ce7132b72d6fb4ed0d5d614f8b38187af915f957",
    "nt117": "6dbf6563aedd4f1eb6fef824214840c69470188738781f839b4021a4f81c2606",
    "nt128": "43c223f1aa53c75cc8af79bfa7696b4b684deb98b4eb014782d80101d40043fc",
    "nt132": "3149bbf09d4d35bfe8d08e7271963473791a42a61f6a911038b14fdbdb99313b",
    "nt158": "465b50e1f418173f332d88ded84d5edcc0331fe3e3d11192279e4bf60f73b86b",
    "nt160": "54c02dfe7c04591baadb5f2b724db765764244903a5b734cae78bdd47c987dda",
    "nt166": "b0d97bbc7687a2de6c6cf7d6476537b079452465bf14b5bef7ae322fce504367",
    "nt167": "e9e746c2ff11a570fabef36096af0b97aa0e2b2286d5d09611c034ae2925e348",
    "nt182": "f637ccaf0aea23eaa6ae6b7e03fc59dc8a5f1cfc99880d907dfaee0a1dbd814c",
    "nt185": "7a2974e90c78aa6124dc38cd7f2f58e1f33d9c1a4b051837f49b1adee3bbe389",
    "nt192": "549b183f8846486a5832559021a1236c2a46c21c28a0240658e3a11ae64c867b",
    "nt202": "dc4a6ebb16a76f058b7b93f9888a20d1380c6bb6d5b6838b312c8dcd24a2b730",
    "nt213": "3af653a468d6753d2f9b9ab2e87883247e02c5d81381ef840de14be1207ba050",
    "nt222": "569594b8c36123747d5a80526197d15730fdab5a0bbb3bc7370ae8e7ea8b1d81",
    "nt225": "8356b09f21a7b1318301912fd059ed156bf1b2681f0d19d2468d2c18ff2e06e6",
    "nt229": "bea74ecb2427c12f4916dbd9c244e2ec8b5bfd0f7fe415b45c4b789158b1e470",
    "nt231": "34bb4c1874645925f3f8f94be222cad768d733b46918782fbf03a763c30091e6",
    "nt235": "4224217c06e499dd374ce6f429ed1380fe21c79d26e56e84f0e0833a8fc13671",
    "nt238": "675afa8ca59d85736dd0a6a7118f3e3199ef51e555808faba1841fe822df9486",
    "nt246": "d4ebaf27d1a2b2ddcee1860797b8fe23259047a43f04bedd8b083016ed6fc16a",
    "nt249": "4854ec534c782a0fcff1a02c3f472940fa634e2371621f1c852de9d11c292e53",
    "nt257": "a11a8eddeadbb90fc9fbdf7ee0e259e68ec20d9d80bdf00570d2ce1a2958028f",
    "nt261": "9cf3077ce4d66d2700bb8bb1d377c6c9bd00b7ec51198ff6227b87922004de6c",
    "nt266": "e42569cb7b0e758e0a8b86237fde69a78d9d753e65455360d048e0b6d4bc3f1b",
    "nt272": "f84b42ff0819f80bf5e8401863b75710eb97421326af93727f6196e3d4ae92ef",
    "nt291": "2fb0b8d03721f78b3e78eb0bffa28785643ddb121bc20ae0cc7f6aca48aefbf4",
    "nt309": "40a74eaec639304ef89ee326ac0d70148942d67521a339a86a03d260513a256f",
    "nt311": "810ee75311adba3184de695bdd832ad7c8c57185e6a843be0c87061288d90ad7",
    "nt337": "e26a9588402bed6bf555952351cf3dc04a2f071e1fd693a5da54c621d098fc96",
    "nt345": "50faa5b240ed5c5fdad3f82f78e43aa85d864451754a549cc1cad86f808daa85",
    "nt346": "d264244111106d4c1c0a740789708e8b9f4c9c7b6932251c0f51f8deee8d2b7c",
    "nt347": "1ce75a5704568221df4c6fea867fc9100a2db8ac93354859bcc5d618c4aee5da",
    "nt356": "940d579af5649ee2d4d67f17308cd7a2c0ace6f71d521c9f31f9fbbc811f5c9f",
    "nt361": "422f159c50a3414173144041e947243983f908366ea79921e2c11065dedd1f48",
    "nt362": "1d69b1f6ec21606cb6e09ac1d5803a8334a2641e7c2cb48012fc92f68c887de5",
    "nt365": "17a32b588b0e5ae976734239c05fba8f5f6ae342144f75bdcbc533af5925b41c",
    "nt399": "d903483fa798d990b95e1b92fda2755c192ec73311a3b0b26d86fc1da8ee618e",
    "nt400": "00762e640f68cc7ce20a5623e246a04db64d0a01c54be6e5722eb0377424b1a1",
    "nt409": "3af190f51c5826aa10224ac4225e919b8db238be96ddea12d6394d7317288abc",
    "nt417": "c77ed1567dc01e6b2f484e9060fbc35f959e64282d65a155543f43bdcc7f616b",
    "nt427": "dfa0abbff035a9f9b0f4bc5a66ad1f4748b4936c4edc4a2c5603fe7f9d5d3641",
    "nt432": "d9e0f9ad0848d8495ce4a842ea9c0ff806ec849e61be7d9c25abdbffb4f099d3",
    "nt435": "b5cc34728f6ace566a5a32e0a7ac4cc60175dce8a43de5af1f86d92e2de3c4b8",
    "nt438": "c182f90ada5fd685aa691127663f18fbc07a120e071105b0373112a5d4835c90",
    "nt441": "679c1dd2960e739e7528b7365c4dd8750dd0fdf062d69f6efc6bd664f4c61e26",
    "nt462": "6b43055e62400bf73c15aaa9a53d1118e7e15ca6f43d4d119310acbe81e01a3e",
    "nt467": "35b723b3f2e0e2c0975c2d5edb1faa7dc5f870bcdc7caf878185fb137ff37735",
    "nt470": "a28c8cf3a2660fbb164592a570081b71e694d3a22c0c7373d075d7cebe7c1737",
    "nt480": "4d57d83551e6507daaabf29eb7cf9d2ee1447e5c78cdaef611868a93a52c2c6f",
    "nt494": "2a9c52e0e51371924257417fd48de9c2d053e38b25960af37c2fea48e71e3380",
    "nt505": "c9be415a308a3030f96319a81a33d44553985e913fa4855746ae490a31d7aaa1",
    "nt506": "2cf8e1af1256c1b4cd0c46710901ad12576381330b099b48440313a85e83513a",
    "nt525": "6072c201e548b9923186a95610164d5ea78bbd46b7c39cdf74b86f21ea9c5cbd",
    "nt531": "10436b3e6dae26949eabae1db7cfbcf75dedb473a5f34ed595621bad287e91eb",
    "nt533": "d7e8287c705cb2578c0927661628fc27acb15150ea36ea9f0db5b76055853310",
    "nt539": "ea33dc8789a775e9df7fae3a9730528a5616f3186b8dfd69d74619e81af0bb5f",
    "nt546": "1bf7bd9ba79b1bf998e6e5816f6c17d6d8842a4f3bf3dba6a9cef77290f8578d",
    "nt569": "17a5a1e40796bf3823ac41ff5676112dd54a072d9b5d4c6dd835dcc989250bd4",
    "nt645": "ea039fe8928f30c7d877fe5198de584fcb15f2ae8188854d5d36b2c671e916c2",
    "nt666": "c4436e09d452bc520d3db745818127b39b117c0587e3995065e888c31287cc8a",
    "nt684": "c4f0ac94fe928847b070650d406a1583bace03103c7b7b5ec32880d78b725f42",
    "nt694": "124ac3ab8ba070093dc62e1ddaea53f33a8d7f0c411937aa9badc6923d5603cb",
    "nt697": "d80db8b73774a45cfdf39805b8817bc1cee6ef4210d67ed06019e588abb71d4e",
    "nt706": "40756d66cacac95ce5aed1259c534b4e144f6d3f280c8804be972e4e44e88f25",
    "nt719": "9940825c7477d47a1f12605abba41d232a923e35e0ba3ca6973009a585948798",
    "nt721": "74d5dfe779ed07f755299d4e92149c1632360e2c6d201b26b28cac8e4f3df7a5",
    "nt724": "62a90190b5efcfd73686885cf445156e55def66134216fec56cb6bd43cfdfd35",
    "nt799": "08a2b6bf19e5164c6d1e73653f83d0d82a1a6eb423a30ef1fc8584bc136228ba",
    "nt812": "5288bdfde3f29614cb6c00a62ea740f54a298d9e9f9b79c1dbb069a231be2e89",
    "nt821": "3af89ca1f510308ed5effae55adc15c544712d641c56e6f765fb270d8e7df555",
    "nt822": "077d903ddde27ee8cc7e299463f3ba932b2a54361400188cc37af42ac1556db2",
    "nt825": "c8ac55491ed2ce2e542404a81620c9eaca5857b5fad0bae864714cc4c84e3ece",
    "nt827": "920c5175979ca1f2fd4e10164ab4940b939e544323992e0d5f998a89889be329",
    "nt839": "e5da99c4a64975f7a118ef3b91d6e789edc59a8b11d2d9a93f1a31daec7c11e2",
    "nt857": "7dd303ce972a2746e813ef2a3b9302d78620621d25c2a20b070e3041bbfccc49",
    "nt858": "c407f6c1b8f65455a853c983737c9e0dc7e21359c7ff8c52833c6011e1f73f5b",
    "nt861": "6d6ecf37c32b64115b01bc9834521d4bb67eb3ffe1a25848769e1cb90036de3b",
    "nt868": "b72f8c11ea24fd2909f46448c4bfecb8df5365925c64a2565da57c26c7d97bd0",
    "ns0": "1d6164b76ad4724d53cfa25e6cba1e01d28ff4124d07c1b6746e27c06b93fcb6",
    "ns2": "25f079f88bd3b7a61acdcda3ceaa7502d928a7d3255414848caca0d858638273",
    "ns25": "ca456b0d17a4821eefe6a38d159414dfe93b7ae440036f582d873a9dbe2d18e8",
    "ns31": "9b8fb516e314b9fe118354821c7f788a124dfab413370fb0ff088d545c6c4127",
    "ns33": "330fc42d02e1f412c3a1188dd769de2b2440bd22fed83c8e47049a71e39a67b0",
    "ns45": "73ed0a35623019c0d8cb4ecf92ca4cf23b2097c896284b288d238373ef8f4a7c",
    "ns48": "6a5bc90bd2b22083c33b0b6584d505e43ebccf4e7319175fae886af2691e7fd7",
    "ns65": "5438a58eee9cb066ad3fc6feed8c5bbc60aca08f907772fdc6b8f74b505d4fcb",
    "ns74": "7ec80ef4465a01085b39b07769bd87a71fc16690b5ee3f1cf52e0d1dd3f0a319",
    "ns106": "a6f0ad644b91b34b2e276fd110c29cb0bcd96af5ff159afd1f474238733ad7ec",
    "ns120": "d1cf901451e9039456239cff5e613de4f2c64f2d35e62772337a1137eec38eb5",
    "ns129": "18c04f523db5cb92f4c9459fbfc78386a0d301245a178f6295c737d8f9ebe795",
    "ns133": "ae7ebe7dddadd2a3cd864640269ea5c0e3d95909cd32c83e317405c253e2b026",
    "ns147": "59e25d8bc47ac810db1eac65566b3cece92ae5b35abedb4c27d4eb4afc259958",
    "ns149": "0be0cb808c2ba8749ec01c7fd32a4f0fe4550ac083c042e98586a751e6e55c71",
    "ns164": "34b667d658bedb30cbb2dc1970acc00bb7b04f23b76a5513e808f961e4eb4cdd",
    "ns167": "4ad5306cd6ea3bade159a4f48a3168f9d311560e3d355b13afcf18be2163f5eb",
    "ns168": "8c0f3a108d859c564aa2fd7f319dae113f4b7d126c654c3f56240ab250e5e159",
    "ns175": "6ccbf98178e770c487e7f2249ff7ec102292ab486cfa494eed7badfb504f7c59",
    "ns183": "fbe8ea1d8aa2cbd759604fceec4984e5ab6e65c5088e5d337c1caaa6e5b63455",
    "ns185": "bd054edff8c8b127c1c8ee646f607ee61b872f4401334baab8659f5b7d5b2683",
    "ns193": "f3a7efe83de361654e5b9d8fed2795dc4418571503130fef037682e2a26bb071",
    "ns195": "dce9f3790be9b097ee91a095298a574f9a8b659a04839c41fc662d475994a774",
    "ns198": "0dee399909cfa28471b1d0a0d50a1f79d7ea61c920cedc48fb39249f98f9ea1c",
    "ns201": "2346ec79e54ffceaae2436a104e69e9abe5dcab98c0b1fec7aa15cf3da3b2176",
    "ns203": "f23b30541989c47c8f6f258f3f3f6f4fc559ceaf9881fad28a505c3b9c398620",
    "ns204": "f90a514d9da6bb127bd59b5b2d84a542a79decb7a5510045f140e093b47a25bc",
    "ns217": "a33c60cea462f503b70b97d37b0848792a051d8e086b399161435e7016216e0f",
    "ns219": "08c2cb8fffa2d6d271d5e4bdbfb3a49da159fa7743f7f4ce049753bf70e8849b",
    "ns221": "33f831e31cc14192f2e2d8ec90de03008adc276eca4fb38b8b660965aa59f70a",
    "ns223": "7d449a236c699d9837722f23aa24672d317890559c133e00b8b77e58f2b6b8a9",
    "ns225": "8a630e9fe81061afef9c2e57c2f7714fe144c86621bcd54e89fd071862762517",
    "ns230": "22602cbfad1263beada817865125913d890abdf7186218904de14abd8277ac4b",
    "ns233": "35a6ae0c0d1dda4c3de55668622eb3b6654a1292a0bd177ac26f1e0424ee0b3d",
    "ns238": "2f4268e56a7c0e60b314a3cf5995b8b26598c5c84f62062c9756a09215a15630",
    "ns239": "3a29f2c3f8c1b7afa0697620792129393e0616ca1acbb1fd72e18de7bda06bea",
    "ns245": "2b8dead030d32b0160723a99e59d7ea6b8c12949aca25bf2785dc3a95e819678",
    "ns249": "10e41f93b70d517d79525bc50f08f97de990f4bb4183c76800d1b569a722db8b",
    "ns250": "0c19698ede4b39a319124415ad7c43a5a4f8254046ff038aaa19b52b13d47e65",
    "ns255": "38498d50bb2ede84f723bcc211366bfe3215e0ff26ab171cb6f2497cb657d8a3",
    "ns258": "b94ce440660de9a0b1a3865a9175ddcdb668cc812ccaf4088212e07e2ebc884e",
    "ns274": "d43b5b59260aea9d76381878a40b954e6adb57f23b3a01baa7f7f3ae3ecf31d0",
    "ns276": "39bc0a14c70940a81cb95107aab8a58f0d414f3a96821a9090a729b43949eefa",
    "ns286": "52170b773e9c0580f61b45889d3f999ad7dc5f9f8a260de90d9fe4d0ddbf5854",
    "ns288": "c3c5c616dc1cb6ed288600178a8fd7b561b3d27234a154e7d4f14edbe98ba741",
    "ns291": "e8bbc51e4f0cedba36262f97fad41f97059c8e6ad037d851dd35f3afe17cd5e3",
    "ns306": "bd13f22ffae32f103eb0effa57469e5683b992576c7d7df7c664db3ca6127984",
    "ns315": "eb611816125e06c9011fd39d618eaf842502ab16984bf6caa0e9b7289498a3e1",
    "ns326": "b8f8d2320ad189ea99d29b0d158a4bb9fa0493022b0e1875887c77dee794403d",
    "ns348": "357aea7444472a0a3c5afc611231de9a520f8e7c9af8592d5fa327781af67034",
    "ns354": "26b6e4cc3270ace9607789b4315def3660c2c5ff63768b564cb0886b5dd2cfcd",
    "ns361": "b223f2dd3f63d2f783769e71d0bfbaab930ecb71de62029c214d14ddc22c0482",
    "ns365": "e8d687d29a84bf0fc9b5d5822bd216493e1f97790e73b251b72dfb988cfa32de",
    "ns374": "9cf00bc32f46d4ab04e4c9fde7b5b98360366e65d4e0f48754a41e68d75fc86d",
    "ns395": "4454deb865bbdc5a930723637a0946457b16ffd90001e6ec20ae064198b32741",
    "ns404": "5907389c86b8ef4a34a31496be366099bb2d651a41a1be4aac23582ffe77bdb6",
    "ns411": "d92cd7d6825e3d7b983978f3426c85116cd9c37b04279a02d870e03465b89c5c",
    "ns412": "b3d9bf2e08a821ee2d5d6ed2e839c594ecfca349689939ba4d0cebfd994c1c30",
    "ns423": "270f3dfb300c4ddaef0934381356353ef9488488a229e70195a552747522b45a",
    "ns425": "6555cc7d89d1de9d4726fc18f50f35b63a849197f606ad3ad5395fb0b625dcf4",
    "ns429": "b6a5106683460e30e1f3a11c30382b91f006ed4cfe065279e1fd6183e4773205",
    "ns430": "e4b2a536211b4536766c3004c9d6e6fbf493279520d60e983cd16ac0075ac4b9",
    "ns440": "ce2bf1233cecaf19ecd77bb1ba0a49ffe0aa6943163fdf40e79df35e2fb5a05f",
    "ns445": "6f1e95360e8aba743a011540e212f8381723575eee945fe3d1563fa02ab29ffe",
    "ns463": "a3a41e2a04464fb8ee4c4b5e062da3b7e7ac5769ab18cea69b11b340a16cb334",
    "ns469": "41470d0494d0f079cee2e664ed33a76051ef868098bd64c3a0576d0d46202704",
    "ns486": "b5dc33c4111f2507692619135c211b649f219138335e03292fd1430f7b744e21",
    "ns493": "098abf3ddd03da48fd7b4007be5a65466465de0cd270aabee02f17d7c8af5cc2",
    "ns494": "ea1a999fc716dad605fb9276b43eaeca8e7b53368f0708eb1b97d75dd6a9adc8",
    "ns510": "dd357660f948c64b5d082fb67843b7949d479e37b74c91000f90c61184db666b",
    "ns520": "0ac313d1aad628cfe8a0d56e25aad25b1058820604b6204ee2b88b52369fac71",
    "ns539": "cbeaaf28b56b3f2f987b2fe3ed423fd499f9fe897720a84b79bfee5c6b4038ef",
    "ct6": "75841be5f262f71ba27f6251b05a737f7261b8c359b84e6b45a521bdd482bab8",
    "ct7": "802ab2d9fb071d11ffaf43a86b403cb79fa4e04830635d11f18d765fca238910",
    "ct23": "854f5cf23e012a45374928f9123eeeb7fba1d1631e2e731b5270e2fd533340d4",
    "ct24": "158f6343de8fe9b839a33f3fa9c3397233ac72c843d6e93e58a5987daa328f4a",
    "ct43": "f435e7b1f7a756081aafb58b0944b66f1e303ab38f27820316a65978517e2036",
    "ct75": "cfb40c4d9e9fe54de9210edc9f1390a14d2f7e46786f95f0c019a8b30329d219",
    "ct82": "968288f7e03b51d5869739fc2ffd67234a6996d14419a0933ea93e9e04231bbc",
    "ct83": "8b8c4891fa89a7e4e3a5bfb36c554bb24d223c57ab4edc42cbe0be981b7c6e3a",
    "ct86": "7858c6f1b8bd8ab415b28cf8e35d46b09981b0909b4cc1519ed50db96c40ddfb",
    "ct94": "e5099636ee316dc3a1a6aebecbdac710a49ef4b67ce79c1beb609326d6034264",
    "ct97": "4d6ec7c1a499a3f697dd322100185a27878b0258a7dc04ab312e84088779a357",
    "ct102": "b17a7580de4afc653cfa9b0f05a19cc71eefc772be9d98d2f3ee23b3eafd04a8",
    "ct114": "65e772fc0699e547a722a61baba2cebb0a6065cfb9bf2841bbb6c094e764ee25",
    "ct134": "0aa8e173f64c85d596058d281341789a6863094f66c8fb8c7a7d0162e2f8ea67",
    "ct142": "dfe92b1d9b09e879952bd36c31e012d57d6fd0a65227b996f7571803db0d1db3",
    "ct143": "7b8ee74047cf0cf033afef0ed8c8f347e8c42fa5a2152d49e44350521a682eb0",
    "ct154": "74f50b5ae447226e3ae7e33bcf9d9afe0b2ca80250d5db32b96601e7c63f428b",
    "ct161": "12665fa5a6dcc319a48287da46d5f2fe50a30f2cf8a9b6711eb1848cce5bc2bc",
    "ct165": "34bab8a4a8b86e672565f888b867f9f820f75e72b864937037653d68198ec6e0",
    "ct167": "28768fd764a8a6033f0a7dc145ca721a9e00457d0aa3891d7710ebb5759ab60b",
    "ct186": "53472ff0c1d9fc98723d1070bd8a55618a0239991e892d232f141c75eaf622cc",
    "ct187": "1fe6ccec260f25d2444196160d0e513191a10013212ac957bcde177768da0da4",
    "ct189": "52c37d8450900ee0fd08d6b13981a9a9eb2fa6f4e63cda4746e7eafcf2bcaaf5",
    "ct198": "2330330cc0079e810cdabbb8a930e746c27ff5582920eb6532d5aaeaf9d24fe6",
    "ct200": "b2f83775bfa0d2d3ebc56f213973ac3720c93a3e9454e527b88c6aedf99ec561",
    "ct203": "912b1d26bd00eb986056ece8b20dfc92165f783cc71ca24fb09c93a7d218dd85",
    "ct210": "9b0c52cdc6557843126266c5d3dbb40de0318a2968cb95100c162e628c19c9d0",
    "ct212": "bd50ba1490889919cbd8ef36577fba143415c9c00ac0e9d722f13f9616d2277d",
    "ct214": "c45a984af93261484195363316af0ee2cda5dde3c9437a18c67b70fc3d484a50",
    "ct219": "9a6b623998eb721b3c529f1b105e3d01ece7e23e2065afc84acee886be7f63b6",
    "ct223": "063abe66b9b9ae7ae87cc66ad51045413bd3cbf6b65df33f969e29a270d37c3f",
    "ct225": "63e49a2c409292b472655be1705a37ffc3ad2f6c8e5cdd5d3c9cdff7dc25e169",
    "ct228": "527dee38bf4dedaa77b6b8c46f268ebede5b2ee77ba42eaac12d6ca5e1761376",
    "ct229": "796aedc19a78ed9a0731cc76421b9398ebb6bbab32693fb2aeeaba260c55ad52",
    "ct233": "1f3c2a8965b05e592d8225e8bd30952d2529c820605667bba4c7f7fbb548534c",
    "ct235": "3417d5305dc3784724dbceee6b47a0f80960894c76f4d324cd0ae042123e1c84",
    "ct245": "2a6eb75fc336cd005f60ac905e29623788901f5bfd1ce834a1449971defc303f",
    "ct250": "7e70ca13a626853fa3d5e5c3278cfd9ea35471eb4e484d34a03e642982b9e077",
    "ct251": "cb0266a5704309821f65ef4457016a2bcf1c6be12a4a595861e6672c5e80a8a2",
    "ct252": "1c59dddc7a681be8c91450bdffd8e3482b3d7a4efdd84eecfeeb4426eb1969f9",
    "ct263": "72fd053db4024932c632f87cd0d0c0a082650b357f51bba452f8b8cb8a87d82d",
    "ct264": "febcd1fa13a829ab7e2620c3ab3fa77e50a67153ba2f8aa474458c3cf09020e7",
    "ct274": "5dcdfb85c6f39e31073358527ef0068b729780f90cceff2c6088bea6184483f1",
    "ct276": "ee8af3152f9f1f5e3b95d51e8bf0844932021990da5e9c39799127b23a7eefbb",
    "ct301": "5fffc4b5299d1ce638d112413be47e1e0ae2674c950b8e0ad282508b1517fd69",
    "ct311": "c67a86a9505efd1c9a4da7859001eb0e04d8af86beea786d3554dab9a75fd501",
    "ct313": "36ee6bbe1b33f8197eed87294f325c9678bc56633ba8bf84099ae0ab5614f4c0",
    "ct345": "c06be57f509a71534af86d8f4b11a067a4d66938a7a30fdd9309b9e592ade365",
    "ct407": "5ddeb1234ab1e72c11a806259a2f7511c2db81d0819921025c74d4fb7d3173ff",
    "ct457": "011d935e169390c8351f807054cfbce498d6078592df2e884ae3118e4306c069",
    "ct466": "d0083081602fad9e311608624a7c7b25d6cadbf905a03790147445bc7bb52333",
    "ct467": "8854c628999f5dfef9c6438b31e612398e1e78797a0ecf9df7e17b74670d58f2",
    "ct468": "c565f9672be20b2499b01d759755d31f0ac1ee9c14004586d0110f78209b8598",
    "ct483": "e11b447c0db38fa183114c87ae78dc778a6667f73deea25aa9823d96144887ff",
    "ct496": "16aaa0178451ae4f5aafb178626a52f6d823105d442d381491602a20dbc19c6f",
    "ct497": "6f94fb7335b237de65ef48eeacc541f69c3bcecd68ac0d2eb53d934b6260754b",
    "ct501": "18054713f0ba53ffe8ecbe1a91822f00661d793252a988ec13ac64de0d3a38cb",
    "ct506": "da2756ef717ced7f5005d3ae1d57ccbe8209e15e3b9141f5aa03f489e01982bc",
    "ct510": "68eb2315ad2f42609889fea5ddf6ab2ac2054ccf7e0f95085e7e9e6208b219bc",
    "ct521": "7c2ee358c38f46578fa18ed2a4844110e7ae5062408ff985a69dc4346b791637",
    "ct531": "748a07c8d953f205c4f8112fc7421b701e1f8819beb7bab3ca7944455e8b1424",
    "ct532": "a59cc5b553ff51181c382b1e326320db0018ef8633af2ad7bfdc09fa833533ef",
    "ct534": "875535f243f7adbfa82b728b78a3ea904f0db4c931657c9e20af2064a80be2e1",
    "ct544": "12f56e3b16e21fc4f5e15b35c2f86f054b9f56832ec96fa497f79ecbf077950a",
    "ct545": "fb3aaea76415fae1153558e650f511e504227ac8adf9d797e57b926ed8ca9fdd",
    "ct551": "69426fcb3c85eb7541a33d7be9c7fd3ffa943e1cc5fece850fd714f89db71901",
    "ct571": "819aab6ca29105dc0e7698c8b9a5bb861e12244af3da452733fbf9c2633fe49d",
    "ct575": "e60912e4531c04155c4cd5c231bdda7eb2dabfafc6daec1cee1815484ebb3084",
    "ct578": "ebe11c3ffcc8accb68742d825818ef0ca271cfa53cc4c7a30a2e77b9def8400d",
    "ct585": "0ffaccaab96af8e9db3abe84c4dadc5e24805c6ce77b37477e06159de14cd106",
    "ct588": "be7e68ec7af480a431010fd03ec1e5d76a94253070d20d1bc543d80289ed913e",
    "ct594": "7fb7d823d63a396ec0ff297e31f98d00361c3ed80fb3b5309476302de92b1b70",
    "ct608": "ed56faf4f0f9fd205c866358f2d2564d2598e92c7caef31583c95eb1b444c516",
    "ct610": "d81a06f6316a36d0358e177b4525872c566c371b96d4f732d2b36b812510a7b3",
    "ct614": "e826bdd670c98bf10e1179f4b20672b2edab8c2625dc80952d255f53176400df",
    "ct622": "493cb2192f56cd91b06142e9b08083dff639f6d1353dfb1cc4cd3d2bfa163d3f",
    "ct625": "bb4423597998c628a031e6421aff27dbea2bfdbe2913c1d2a9dc63fe5ff0ba71",
    "ct630": "65bffebb6bb2d6c56eda2c6aa5e0785348b533cc4c06698bcdeea99e71f7289e",
    "ct632": "ac72783e4a52d12006267bf03de2c8658529c746fb5a867da2a0f860f01adf1b",
    "ct648": "89a251f8951444945678e096cb4d6fb7b50a2075292e9e4bb48591c11e7dae45",
    "ct654": "4535728215d18e76bde30f429d191ee3ff752f083a4e6453ec337a7e9c23fe10",
    "ct659": "22eae91232563cafc7d7a94a442dc28f883a347c859a879162c397db80359a7c",
    "ct664": "30038bb16e00282ab8a760de2b3aed60eda18e4835a4754fefd46ab4a66d7125",
    "ct675": "0b620146d6d03d31322a4bc8c43ddc63b3385f6928e58bc78db4195c218f6695",
    "ct678": "5ab8f2f8b01ee33cdf127935953aef2221ebc2484f5328b7c1638f150384c276",
    "ct692": "684435b4787df8c55fec42442dff50fd85d617dcbfdad25bb3ea2b5716538ffc",
    "ct695": "56465436c33c47e9701794e89be39c879b7571023806fabecee959cafbf64446",
    "ct719": "6ae37eaffdcb56cffd6d5e17491056b435786fcfc9e52f61bbc7b54993a3b8b7",
    "ct723": "506d55be82256a24440845d2a2082310eceaed4470efca3db0c4f9481caf4e80",
    "ct738": "f0a1d15f06b2697725418bf61e71c1d5e4430c8ebd68cb6b34115c10d4ccbb39",
    "ct740": "a75c1114943d3c031861a2eba74aa0e16c83caede79d920bea6581c43d59fb32",
    "ct744": "78f7953b58dc300ce96a439325e9694f343385f3237967f519d30311a4b8bcc5",
    "ct749": "3d42c04b4ef25e52d4c9e173eea4a4cb4699b538b2fb865047c38405288f221c",
    "ct752": "a2138571a63e17117cfd1808fccf067fa931309d0759d2b63b67cf3fc7842664",
    "ct758": "5325ce17f183c286ba6ca1cd6b8be8dcf602a2e69d1b844de464c8179e152509",
    "ct760": "1077e64d23960d6604bca263522a352ca72fa5797281fb22757739d72ecc0e23",
    "cs2": "2537e44b4d5fa892fed6d82c4f98e904cd272a55264a16bd75badee489d00d79",
    "cs41": "57d6517c3ac32e7ae0330c1c5a89a42be0b94359d938322a5b8d08f0b5d39699",
    "cs69": "b47a23929a7d4680801c6461a84dc86244c11c13325238968bd218196480a701",
    "cs72": "c5dc255de5c088d2ca883405ab0197d6cec5e69a23c99fbe8a30dd5abe537866",
    "cs82": "5764677b9f7b286b14930444c87ddb597808022a33de3ff1f948091b292e27b7",
    "cs85": "6316b37c3a630e12876751846a674f73ddf97e999f563737dd3e63b21ecd73d9",
    "cs86": "702a9d40055734130ea87e8dcefea5e68269940db36550093082e31387701db0",
    "cs91": "22ced312d8adfe8fb9da45cf81afd1c1bedeec3dada58cfb190501a38e536ea0",
    "cs95": "922b96836f78a314f46f8f217fdc9a37316f8a6041309c359e726c6bda8379d7",
    "cs96": "4c25fea6d908b256ac9f44d435e06d5235181a090a5fb8e7a0ad58d3a56a5d1e",
    "cs99": "2da8e175b6872b9ad969c397468630328d0db431ebb53c5b1ecd420f80e40a58",
    "cs116": "956853be2092b230dc32fcb714e0df7313fef03f8c727bffb6d9a8a3ba6bd5af",
    "cs132": "fbb8a70d7a5ba1fcc85661f14abc784641f67f4448b4fd25a187151e39496b0d",
    "cs136": "402966fed6e9b7df66885c8fa241e3d16f4e40aaaa99e6745cd65eaa86607e2a",
    "cs139": "717179b7aa0f82a34abd3556c60739ff9b90556ff79288047b207907ed41fff5",
    "cs144": "6045e8e381f57060df2f323801acdc90faf3d8cf6a05b0faba0f2e12349859fc",
    "cs147": "e6d1f189106cb379f451be7881a454cafcd2bf9fdea102a27fcfbd8c0798f59b",
    "cs155": "507de86412da2066986631afba022944bd17a1c261233ac2eb69ef07c39a69d8",
    "cs181": "6081fc789f2369dd8213df66ce87dc04cae902400c153cdf24fe54c2c434050d",
    "cs189": "9c9921b8170f76b5f048e67faac844c52d256f3851ae01ccd8f49994693c4ab1",
    "cs223": "a676a5c7be5da18e1400ff1c2fc3ff7cf819e78b0adc556687d39a79c2b9f4d0",
    "cs232": "46040b3b123cdeb3ed6852b5fac9d3c4c8aca0d71809556645b5d69436b1982c",
    "cs250": "db8d161797549fe3558dd68b0a6ee09cb3e2709409d7a87ab3c52a455a776215",
    "cs256": "b3c19a2a9877154863bd4c638ad41aab364b14c04dfe84520ccc69f0136e50f2",
    "cs280": "a50ed1f9d9da9410f5fd64a7fc546b394e89eac52bfcd866a940b8308dcb0b51",
    "cs290": "511a1159405e37b5eeed6b4a8c011c5b0b5c3d1c03526091bb8e4d629421e572",
    "cs295": "1025efb0b293672c38b1e7f050c6dc37d1f97be795dff91de68672429b43ad21",
    "cs299": "485a4ae2186b809a47f3f85c9c269e22f250be53a400fa29cd040b432dd56324",
    "cs301": "282b24149b5cc94276e288b6bf5f624108a0a8ad6bc21160cd63ae09b2892357",
    "cs312": "4d124d24c02ec7c3db534c0c263a87f7e908e04aec4d1336e0d1618c81495e0b",
    "cs318": "1bbced946cdf7e26f4f35b56923779f0a3a7d2e16868e6a2a736357655cb08e2",
    "cs320": "1bfcc073b719b436dba9c8fcde22a457cb06ec21bca86399e13a54a69a7a2667",
    "cs323": "0cb1524d8ec840eee90430b9bd37fcf099330d484f97ed2cedea4335bf5b98f7",
    "cs326": "707c6d6754da13d7309321574496d7d8aff61a2b7c392078ff495fa64464620b",
    "cs335": "8eb2514540c6c5db9e843faec7300d50d826d556b0dcde9887637b971a3b5fc5",
    "cs341": "8fd3908090a51c7971b845cd4996a7193526d7a148981e4c8242b77ad1e271b4",
    "cs363": "5b0613ec8ee26c011a4f46e5a355d349b380708c4490aad14df36b9c9aea6292",
    "cs365": "0c9bf35e7280f37a8168eb29585fe0c13c108eb3b95e0522f7549f5d046c4a69",
    "cs385": "f921caa30b87c54c2f7b692044a15312710a64d71fc40d6cafb2315c4a7432e7",
    "cs393": "92fa42d6fab38b2e2181c9ecc8f1ec08ce4045ef40692071746f0d5a91e4d2a6",
    "cs401": "d4702aca8660c3244a1b511d72af1ce80683475c699b3b661c639d302e84280c",
    "cs405": "010517659d8f38ee6d20b1e08ee54c95bf5dc4b7b9d59b83cf138a0295380c87",
    "cs420": "2ebf57e0bcdad66ccd1ce5ed0c1fd46d100a5d8b409d36384edcc9b8888cbfc1",
    "cs422": "0593dece0bd26719e17b32051b8bf451ee58b630b365197af14a35c115c62d7c",
    "cs433": "3447eebbdcaa37f97290ede09df1f2b22667b04d315fe73422b8953b0b22791a",
    "cs437": "4872dd2526aa855fb88ad1bec632a5172c89930f64936463b71093e873068c1c",
    "cs446": "216889af1a083f61819fba10c8927addb4507d9222262dda7e333d705ea74291",
    "cs449": "8d8bca8d264de121477763389435130b96259b450e968aae94212c477fa2721d",
    "cs455": "04dd190c271efebe81503d0a9267600bb673feddd99eb91b0a01046c6aa3f895",
    "cs471": "c8bec88393007286c336287e2588e347d07d2dec8668fe039a9e496cd69574aa",
    "ct52": "e8993e1a7e2b4c24ed690e8f0aaf14825e45898619c87d34edfb4462c3eafcd1",
    "ct68": "8c4f835876a4c8fd6a680b58e3745be47a6159f203807918c970619f8602bfae",
    "ct89": "fce9c95cef6242c6918770c9b6e00d0254d1632bb170b7039879fdd71d014194",
    "ct91": "833231760cd95bcab8bee765ffbee59e25e4567a487eb527fe0b96f3e4b10073",
    "ct131": "1234fe7b7f116e43d0da8713880aa44724bc7708606fefdaeb3d8837e2478abf",
    "ct169": "5427b99174a221d09453b489cecd1e53f0fd3bd5757e3bb77deb50329aca9d62",
    "ct222": "a787d4cd30d63c22041123d2d77d0653bf765b4bca0e20ac64c549400cb82110",
    "ct302": "23ebc92c54b5fc01b36e351d1192a5161afa190c7a5f6e86f3e0f4e04ca171d4",
    "ct470": "26f8422ec20f5f56e907b5c3404ca80893c0296d0ee957509f6c4d0c1a24cb3d",
    "ct505": "7f7c770ef7511a9425620cf5d5c15c71fc0a3f5e958f22aff3a5a2035925a3f2",
    "ct529": "8136f67ae1b29cff2ad091447f1b017a1122866bde1db3d6860d70c58bc284ac",
    "ct555": "a24a5a7c3d3367f3ee90eaeaea59db4f137bd3704a1be7006bffa1f088ae7201",
    "ct562": "8084dbfb3fa2bc7d33bc065d95303583d0cffb96f9bfb927363f78b57526ed13",
    "ct567": "df328fadf7c506e8498245f8d16fe0f0398241b10274e580376873e1d179df3e",
    "ct600": "1dc08af5d9520acf5bd52bd88daa041b2432d9a307a52486eb5f0a529b8168e2",
    "ct645": "bafa318fd51da656e516ed4ca1d5ea162bbf2f86aea399b3396273d99ea62967",
    "ct669": "11febacb94eff228b14b19265487764c10b22d4b8190469a4bf57af19bdd8b54",
    "ct708": "44f829159da8748a483ab453bad1ac49c6fdc79142628d95361ec8f1c7001e9a",
    "ct729": "4f96119356adbfa6f7bd517a916c41da5083d8383ddc4cf335e6a3d6e24d9d6a",
    "ct739": "d4bfc48b61f1904cf6e6fd0994ffeae40beb4c75ff639b5a49d80d5094651d64",
    "ct761": "a5b7d722b9c4c576f11cdf3e46c885765faa417c3d0630bb7ec6534d560b40b4",
    "ct769": "65ff1e94eeddc1a1064ed16f4459f2f28a4fced5bee1bc3a6b24ce44bc1d97a3",
    "cs6": "0ee241ba987f57d73ab0f1214e2273ae380f9bc6eaed111d75e20b6a20392c4b",
    "cs10": "edc91346dce192f70c8c3fca8e56138ed09b704d85db901548a0cf7e0f84e592",
    "cs23": "98f7177f639e602d97ffa878c5c363ab9637932e2520081106c975218f5aa272",
    "cs120": "4ee0ee0aec8e283f9eb6a265725f4191968d5e91f7f925aee88f82dc345dbf3a",
    "cs140": "91ecdbcd3cc5cb14e93f0c2efabe1d47cda29eae9533c6d1851c1ba9656e34aa",
    "cs153": "ce2917cf53a0b50758c0e1d2c2393251828480aaeb9851c6dc2ab3f07c4c61b8",
    "cs167": "93bf311e4bde32e2c7bcc4c0628a1dd2e7e141c56a4f12ca49c79ad72888c89e",
    "cs177": "923a52097b9bcadbd0d9c234c6dcb55cb8fecdd7e3ecef23475a5adb0c615fc8",
    "cs201": "56d532b8ab6185272028ed09d0cfda7c7ef83305df91824094cdcc320b249207",
    "cs222": "9da4497e8d6bb9b27ba456e14b23f7ed3ea1aa2da3e9b7b1cdcd9c94fb591b3a",
    "cs265": "bf0197414ff63e585eb813b8bbcfcc78690afb1d443faf6536f9c5ccbe013674",
    "cs283": "76227751cfddad0598d0937c1584aa7cd84d327e473ccec3fa91bedc7e0d2f6d",
    "cs307": "a6993cd8e9fedf2a5783df3fd3c9fe41000af286af81f9864bc3befc3544091d",
    "cs421": "8ec5d78b4556347529d251b141777073832086660cd38ba81afb636636fb60e4",
    "cs431": "46f2b66df8657d5d2618b9c274c12cdd8a38dc7316441c3ee6407282cff642be",
    "cs432": "cd74cb0a88190b2dfa1dc3da3893721ade0a0e59b628509fc42fee29e7fa0c04",
    "nt40": "79eea4285cc22087e24cfeef614da0a09ab2ee69fe9bfaa044068dff1346d43e",
    "nt71": "03d7b96061c1e890a1631295b39abfce3a2f4c06b6a20e23a5ca28507af8acb1",
    "nt153": "b14b8ea501284d3d30005b06640ab5267016f2d2430c3da5c37fe8c28865832d",
    "nt188": "89b3fa05155666ab1e7acc83b4daa1f7549c9297dd03dc4c9125cb68235403ef",
    "nt236": "a7ff08ff5c3ee3a3e2612b6dce29e8e5180ec304e2918d82d128991e445a28bf",
    "nt240": "2e505b4569ee63c217bee65176798e5546c0f80eb960a3ee0857fd375e1bf334",
    "nt259": "961fe2926a266ca727f7781b3ac41702178fcbb2311a4b2c3e04791597bb2eb9",
    "nt383": "104c7cd432f0ff9adef5ea6bd6ca5fc121f49e5eae60cfdb1333d207752e4942",
    "nt389": "ae5810f8bcf49758c12fca71d65d9027571f29f3241e8e02572f0aa37387d5fd",
    "nt415": "bd30c32028bdf00ce6cf5bc139a1f79e1136be78c6a96de2cbd1c053a06a68f6",
    "nt416": "6343192d647be800c214bbc5d80e929f704e291c4417edd4ae5bb575fab24824",
    "nt419": "4fc232d04273132c5241e25fae7de06ce2942246beb617161d42afaac626e1a3",
    "nt543": "77e0b143f06c55e1eb1bc2c88d879056f2d508b38cfadce6dda9081be128ec0c",
    "nt785": "2bc99fb3b855e329a175267f17fe3d45b715dcea468ff5a4db4979d45385b160",
    "ns305": "28a8a320debe3b21eb27b0bec93bc1240b46e93daa2af137bbbc26c50c6bf358",
    "ns372": "f3dcce7733c01b9d176c24db6b79ff5215a6b083fc00462a2d6263cb58ef6514",
    "ns390": "c798362997dbce9329733b4fe4f585a1cb25adaa453886e04c0d11d02fa36d21",
    "ns467": "9bdb73b97bf7e70f209fd870adbe17bed76be8e66f7349dea87c90e98adc3af5",
    "ns484": "8556e8a0a8ef1206f16a530d492ea1fe02ed075e52837acebd405ed01e80fb28",
    "ns506": "dbb138122c014ce8fa6e74fdf8a127cb606a36500777942f84eb2398bf464044",
    "ns513": "3834b773db9b7747ce00ef7e4fc82c14ccbdd52a77ebccf852bb17fcc7d11728",
}


def build(row):
    subject, split, index = row["id"].split("/")
    prefix = {"number_theory": "n", "counting_and_probability": "c"}.get(subject)
    marker = {"train": "t", "test": "s"}.get(split)
    if prefix is None or marker is None:
        return None
    case = f"{prefix}{marker}{index}"
    expected = _STATEMENT_HASHES.get(case)
    if expected is None or sha256(row["problem"].encode()).hexdigest() != expected:
        return None
    if prefix == "n":
        return _number_theory(case) or _additional_number_theory(case) or _round_two_number_theory(case)
    return _counting(case) or _additional_counting(case) or _round_two_counting(case)
