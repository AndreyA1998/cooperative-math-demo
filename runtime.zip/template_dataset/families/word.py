"""Exact rounding, descriptive statistics, progressions and arithmetic wording."""
from fractions import Fraction as F
from functools import reduce
from math import gcd
from statistics import median
import re
from template_dataset.core import Template
from .arithmetic import parse_expression, evaluate, build as arithmetic_build


def _int(lo,hi):return {'type':'int','min':lo,'max':hi}
def _tex(q):
    q=F(q)
    return str(q.numerator) if q.denominator==1 else rf'\frac{{{q.numerator}}}{{{q.denominator}}}'
def _constant(s):
    s=s.replace('$','').strip().rstrip('.?')
    node,p,_,_=parse_expression(s)
    return evaluate(node,p)
def _lcm(a,b):return a*b//gcd(a,b)


def round_exact(q,places):
    scale=F(10)**places
    a=abs(q*scale)
    r=(2*a.numerator+a.denominator)//(2*a.denominator)
    return F(r,1)/scale*(1 if q>=0 else -1)


def _round_reference(q,places):
    step=F(10)**(-places)
    k=q//step
    choices=[k*step,(k+1)*step]
    return min(choices,key=lambda x:(abs(x-q),-abs(x)))


def _rounding(row):
    s=row['problem'].replace('$','').strip()
    m=re.fullmatch(r'Round (.+?) to the nearest (integer|whole number|tenth|hundredth|thousandth|ten|hundred|thousand|ten thousand)\.',s)
    if not m:return None
    try:q=_constant(m[1])
    except (ValueError,ZeroDivisionError):return None
    places={'integer':0,'whole number':0,'tenth':1,'hundredth':2,'thousandth':3,'ten':-1,'hundred':-2,'thousand':-3,'ten thousand':-4}[m[2]]
    original={'numerator':q.numerator,'denominator':q.denominator,'places':places}
    domains={'numerator':_int(min(-100000,q.numerator),max(100000,q.numerator)),
             'denominator':_int(1,max(10000,q.denominator)),'places':_int(-4,4)}
    return Template(family='arithmetic.rounding',parameters=domains,original=original,
        render=lambda p:f"Round ${_tex(F(p['numerator'],p['denominator']))}$ to the nearest multiple of ${_tex(F(10)**(-p['places']))}$. At a tie, round away from zero.",
        solve=lambda p:round_exact(F(p['numerator'],p['denominator']),p['places']),
        reference=lambda p:_round_reference(F(p['numerator'],p['denominator']),p['places']),
        sample=lambda r:{'numerator':r.randint(-100000,100000),'denominator':r.choice([1,10,100,1000,10000,3,7]),'places':r.randint(-4,4)},
        validate=lambda p:True,constraints=['Positive denominator. Ties round away from zero.'],
        adaptation='Input may be shown as an exact fraction; decimal place wording is replaced by its exact rounding increment and the tie rule is explicit.')


def _statistics(row):
    s=' '.join(row['problem'].replace('$','').split())
    s=re.sub(r' Express your answer as a common fraction\.$','',s)
    m=re.fullmatch(r'(?:What is|Find|Determine) (?:the )?(mean|average|arithmetic mean|median|sum of the median and the mean)(?: \((?:mean|average)\))? of (?:the (?:numbers|integers|set of numbers) )?(.+?)[?.]',s)
    if not m:return None
    raw=re.split(r',\s*(?:and\s+)?|\s+and\s+',m[2])
    try:values=[_constant(x) for x in raw]
    except (ValueError,ZeroDivisionError):return None
    if not 2<=len(values)<=20:return None
    scale=reduce(_lcm,(v.denominator for v in values),1)
    is_set='set of numbers' in s
    if is_set and len(set(values))!=len(values):return None
    original={'values':[int(v*scale) for v in values],'scale':scale}
    extent=max(1000,max(abs(v) for v in original['values']))
    domains={'values':{'type':'list[int]','min_length':2,'max_length':20,'items':_int(-extent,extent)},'scale':_int(1,max(1000,scale))}
    kind=m[1]
    def solver(p):
        vals=[F(x,p['scale']) for x in p['values']]
        mean=sum(vals)/len(vals)
        mid=F(median(vals))
        return mid if kind=='median' else mid+mean if kind=='sum of the median and the mean' else mean
    def ref(p):
        vals=sorted(p['values']);n=len(vals)
        mid=F(vals[n//2],p['scale']) if n%2 else F(vals[n//2-1]+vals[n//2],2*p['scale'])
        avg=sum(F(v,n*p['scale']) for v in vals)
        return mid if kind=='median' else mid+avg if kind=='sum of the median and the mean' else avg
    return Template(family='arithmetic.statistics.'+kind.replace(' ','_'),parameters=domains,original=original,
        render=lambda p:f"Find the {kind} of the numbers $"+', '.join(_tex(F(v,p['scale'])) for v in p['values'])+'$.',
        solve=solver,reference=ref,sample=lambda r:{'values':r.sample(range(-1000,1001),r.randint(2,20)) if is_set else [r.randint(-1000,1000) for _ in range(r.randint(2,20))],'scale':r.randint(1,100)},
        validate=lambda p:not is_set or len(set(p['values']))==len(p['values']),
        constraints=['The collection contains 2–20 numbers. Scale is positive.', 'All elements are distinct, preserving the mathematical set.' if is_set else 'Repetitions are allowed in the list.'],
        adaptation='Names and list introductions are normalized; each listed number and the list length can vary.')


def _progression(row):
    s=' '.join(row['problem'].replace('$','').split())
    m=re.fullmatch(r'How many numbers are in the list\s*(.+?)\s*[?.]?',s)
    if not m:return None
    tokens=[x.strip(' ?.') for x in m[1].split(',')]
    if not any(x in (r'\ldots',r'\dots',r'\cdots','') for x in tokens):return None
    try:values=[F(x) for x in tokens if x not in (r'\ldots',r'\dots',r'\cdots','')]
    except ValueError:return None
    if len(values)<4:return None
    a,d,b=values[0],values[1]-values[0],values[-1]
    if not d or (b-a)/d<1 or ((b-a)/d).denominator!=1:return None
    if values[-1]-values[-2]!=d:return None
    scale=reduce(_lcm,(v.denominator for v in values),1)
    original={'start':int(a*scale),'step':int(d*scale),'end':int(b*scale),'scale':scale}
    def valid(p):return p['step']!=0 and 1<=(p['end']-p['start'])//p['step']<=10000 and (p['end']-p['start'])%p['step']==0
    def sample(r):
        a=r.randint(-1000,1000);d=r.choice([i for i in range(-50,51) if i]);n=r.randint(2,200)
        return {'start':a,'step':d,'end':a+(n-1)*d,'scale':r.randint(1,20)}
    domains={'start':_int(min(-10000,original['start']),max(10000,original['start'])),
             'step':_int(min(-10000,original['step']),max(10000,original['step'])),
             'end':_int(min(-20000,original['end']),max(20000,original['end'])),
             'scale':_int(1,max(1000,scale))}
    return Template(family='arithmetic.progression_count',parameters=domains,original=original,
        render=lambda p:f"How many terms are in the arithmetic progression starting at ${_tex(F(p['start'],p['scale']))}$, with common difference ${_tex(F(p['step'],p['scale']))}$, ending at and including ${_tex(F(p['end'],p['scale']))}$?",
        solve=lambda p:(p['end']-p['start'])//p['step']+1,
        reference=lambda p:len(range(p['start'],p['end']+(1 if p['step']>0 else -1),p['step'])),
        sample=sample,validate=valid,constraints=['step != 0; end-start is a positive integer multiple of step; length <= 10001.'],
        adaptation='The arithmetic-progression rule and included last term are stated explicitly instead of an ellipsis.')


def _word_expression(row):
    s=' '.join(row['problem'].replace('$','').split())
    s=re.sub(r' Express (?:your answer|the result) as (?:a decimal|a common fraction)\.$','',s)
    patterns=[(r'(?:Find|What is) (.+?) divided by (.+?)[?.]',lambda a,b:f'({a})/({b})'),
              (r'Multiply (.+?) by (.+?)\.',lambda a,b:f'({a})*({b})'),
              (r'What is the product of (.+?) and (.+?)\s*\?',lambda a,b:f'({a})*({b})'),
              (r'Add (.+?) to (.+?)\.',lambda a,b:f'({a})+({b})'),
              (r'Subtract (.+?) from (.+?)\.',lambda a,b:f'({b})-({a})'),
              (r'What is (.+?) more than (.+?)\?',lambda a,b:f'({a})+({b})'),
              (r'What is (.+?)\\% of (.+?)\?',lambda a,b:f'({a})*({b})/100')]
    for pattern,make in patterns:
        m=re.fullmatch(pattern,s)
        if not m:continue
        try:_constant(m[1]);_constant(m[2])
        except (ValueError,ZeroDivisionError):continue
        if r'\%' in s:
            a,b=_constant(m[1]),_constant(m[2])
            # Percent's 100 is a mathematical convention, not a dynamic literal.
            orig={'rate_n':a.numerator,'rate_d':a.denominator,'value_n':b.numerator,'value_d':b.denominator}
            domains={k:_int(1 if k.endswith('_d') else 0,max(10000,v)) for k,v in orig.items()}
            return Template(family='arithmetic.percent_of',parameters=domains,original=orig,
                render=lambda p:f"What is ${_tex(F(p['rate_n'],p['rate_d']))}\\%$ of ${_tex(F(p['value_n'],p['value_d']))}$?",
                solve=lambda p:F(p['rate_n']*p['value_n'],100*p['rate_d']*p['value_d']),
                reference=lambda p:F(p['rate_n'],100*p['rate_d'])*F(p['value_n'],p['value_d']),
                sample=lambda r:{'rate_n':r.randint(1,200),'rate_d':r.randint(1,10),'value_n':r.randint(0,10000),'value_d':r.randint(1,100)},
                validate=lambda p:True,constraints=['Percent means division by the fixed mathematical constant 100.'])
        t=arithmetic_build(dict(row,problem='Compute $'+make(*m.groups())+'$.'))
        if t:
            t.family='arithmetic.word_expression'
            t.adaptation='The requested arithmetic operation is written symbolically; numerical arguments remain independently variable.'
        return t
    return None


def _representation(row):
    s=' '.join(row['problem'].replace('$','').split())
    patterns=[r'(?:Express|Write) (.+?) as (?:a |an? )?(decimal|fraction|common fraction)(?: in (?:lowest terms|simplest form))?\.',
              r'What is (.+?) expressed as (?:a )?(decimal|fraction)\?',
              r'Find the fraction that equals (.+?)\.',
              r'Express the following as a common fraction in simplest form: (.+?)\.']
    m=None
    for pat in patterns:
        m=re.fullmatch(pat,s)
        if m:break
    if not m:return None
    text=m[1];kind=m[2] if len(m.groups())>1 else 'fraction'
    repeating=re.fullmatch(r'0\.\\overline\{(\d+)\}',text)
    if repeating:
        digits=repeating[1];original={'digits':int(digits),'width':len(digits)}
        domains={'digits':_int(0,999999),'width':_int(1,6)}
        def sample(r):
            width=r.randint(1,6)
            return {'digits':r.randrange(10**width),'width':width}
        return Template(family='arithmetic.repeating_decimal',parameters=domains,original=original,
            render=lambda p:rf"Express $0.\overline{{{p['digits']:0{p['width']}d}}}$ as a fraction in lowest terms.",
            solve=lambda p:F(p['digits'],10**p['width']-1),
            reference=lambda p:F(p['digits'],10**p['width'])/(1-F(1,10**p['width'])),
            sample=sample,validate=lambda p:p['digits']<10**p['width'],
            constraints=['0 <= digits < 10**width. Leading zeroes belong to the repeating block.'])
    literal=re.fullmatch(r'-?(?:\d+(?:\.\d+)?|\\(?:d|t)?frac\s*(?:\{\d+\}|\d)\s*(?:\{\d+\}|\d))',text)
    if literal is None:
        # Preserve the actual arithmetic task rather than precomputing its input.
        t=arithmetic_build(dict(row,problem='Compute $'+text+'$.'))
        if t is None:return None
        t.family='arithmetic.representation_expression'
        t.adaptation='The full original arithmetic expression is retained. Its requested scalar value is returned exactly as a canonical rational string.'
        if kind=='decimal':
            old_validate=t.validate
            def finite_result(p):
                if not old_validate(p):return False
                d=t.solve(p).denominator
                for prime in (2,5):
                    while d%prime==0:d//=prime
                return d==1
            t.validate=finite_result
            t.constraints.append('The final rational value has a finite decimal expansion.')
        return t
    try:q=_constant(text)
    except (ValueError,ZeroDivisionError):return None
    # A finite decimal output is required, as in the source.
    def finite(d):
        for prime in (2,5):
            while d%prime==0:d//=prime
        return d==1
    if not finite(q.denominator):return None
    original={'numerator':q.numerator,'denominator':q.denominator}
    domains={'numerator':_int(min(-100000,q.numerator),max(100000,q.numerator)),
             'denominator':_int(1,max(10000,q.denominator))}
    def decimal(p):
        value=F(p['numerator'],p['denominator']);d=value.denominator;places=0
        while (10**places)%d:places+=1
        integer=abs(value.numerator)*10**places//d
        if places==0:return str(value.numerator)
        return ('-' if value<0 else '')+str(integer//10**places)+'.'+str(integer%10**places).zfill(places)
    def render(p):
        if kind=='decimal':return f"Express ${_tex(F(p['numerator'],p['denominator']))}$ as a decimal."
        return f"Express ${decimal(p)}$ as a fraction in lowest terms."
    return Template(family='arithmetic.representation.'+kind.replace(' ','_'),parameters=domains,original=original,
        render=render,solve=lambda p:F(p['numerator'],p['denominator']),reference=lambda p:F(decimal(p)),
        sample=lambda r:{'numerator':r.randint(-10000,10000),'denominator':2**r.randint(0,4)*5**r.randint(0,4)},
        validate=lambda p:finite(p['denominator']),constraints=['Denominator has no prime factors other than 2 and 5, ensuring a finite decimal.'],
        adaptation='The same exact number conversion is requested; fraction-to-fraction expressions are normalized to decimal-to-fraction conversion.')


def build(row):
    for builder in (_rounding,_statistics,_progression,_word_expression,_representation):
        t=builder(row)
        if t is not None:return t
    return None
