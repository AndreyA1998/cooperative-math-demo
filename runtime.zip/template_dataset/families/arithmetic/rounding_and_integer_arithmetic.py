"""Rounding and integer arithmetic; exact source-bound mathematical models."""
from fractions import Fraction as Q
from itertools import permutations
from math import ceil, floor, isqrt, prod

from template_dataset.families.algebra.given_bindings import decimal, register, root

BINDINGS = {}


def add(*args, **kwargs):
    register(BINDINGS, *args, **kwargs)


add(43, 'repeating_decimal_ratio',
    (('top_cycle', 666, 1, 999), ('bottom_whole', 1, 1, 30), ('bottom_cycle', 333, 1, 999)),
    lambda a, w, b: rf'Express $\frac{{0.\overline{{{a:03d}}}}}{{{w}.\overline{{{b:03d}}}}}$ as a common fraction.',
    lambda a, w, b: Q(a, 999*w+b),
    reference=lambda a, w, b: Q(a, 999)/(w+Q(b, 999)))


def rounded_sixth(rad, places):
    # The half-tenth thresholds are odd multiples of 1/20.
    return Q(sum((2*j+1)**6 * 10**places <= rad * 20**6 for j in range(20)), 10)


add(138, 'nested_radical_rounding',
    (('decimal_numerator', 64, 1, 100000), ('decimal_places', 6, 5, 9)),
    lambda a, p: rf'Calculate $\sqrt{{\sqrt[3]{{{decimal(a,p)}}}}}$. Express your answer to the nearest tenth (round half up).',
    rounded_sixth,
    adaptation='Specify half-up rounding for ties in the expanded domain.')


add(349, 'affine_operation_composition',
    (('offset', 7, -50, 50), ('argument', 12, -100, 100)),
    lambda a,x: rf'For any number $x$, $x\&={a}-x$ and $\&x=x-({a})$. What is $\&(({x})\&)$?',
    lambda a,x: -x, reference=lambda a,x:(a-x)-a)


def prime_factors(n):
    result = []
    divisor = 2
    while divisor*divisor <= n:
        if n % divisor == 0:
            result.append(divisor)
            while n % divisor == 0:
                n //= divisor
        divisor += 1
    return result + ([n] if n > 1 else [])


add(360, 'mersenne_prime_factor_sum',
    (('exponent', 8, 2, 30),),
    lambda e: rf'Find the sum of the distinct prime divisors of $2^{{{e}}}-1$.',
    lambda e: sum(prime_factors(2**e-1)),
    adaptation='State distinct prime divisors without disclosing their count.')


def cube_extract(n):
    coefficient = 1
    for prime in prime_factors(n):
        while n % prime**3 == 0:
            coefficient *= prime
            n //= prime**3
    return coefficient+n


add(406, 'cube_radical_extraction',
    (('radicand', 2700, 1, 1000000),),
    lambda n: rf'Simplify $\sqrt[3]{{{n}}}$ as $a\sqrt[3]{{b}}$, where $a,b$ are positive integers and $b$ is as small as possible. Find $a+b$.',
    cube_extract,
    reference=lambda n: next(a+n//a**3 for a in range(root(n, 3), 0, -1) if n % a**3 == 0))


def die_score(a,b,c,d,e,f,g,h,i,j):
    def score(roll):
        return a if roll == 6 else b if roll in (2, 4) else 0
    return sum(map(score, (c,d,e,f))) * sum(map(score, (g,h,i,j)))


add(438, 'die_score_product',
    (('both_points',6,1,30), ('even_only_points',2,1,30),
     *((f'allie_{i}', x, 1, 6) for i,x in enumerate((5,4,1,2),1)),
     *((f'betty_{i}', x, 1, 6) for i,x in enumerate((6,3,3,2),1))),
    lambda a,b,c,d,e,f,g,h,i,j: f'Allie and Betty roll a standard die four times each. A roll earns {a} points if it is a multiple of both 2 and 3, {b} points if it is even but not a multiple of 3, and zero otherwise. Allie rolls {c}, {d}, {e}, {f}. Betty rolls {g}, {h}, {i}, {j}. Find the product of their scores.',
    die_score,
    reference=lambda a,b,*rolls: prod(a*part.count(6)+b*(part.count(2)+part.count(4))
                                     for part in (rolls[:4],rolls[4:])))

add(561, 'nested_absolute_value',
    (('a',-1,-40,40),('b',1,-40,40),('c',1,-40,40),('d',1,-40,40)),
    lambda a,b,c,d: rf'Evaluate $\left|\left|-|{a}+({b})|-({c})\right|+({d})\right|$.',
    lambda a,b,c,d: abs(abs(-abs(a+b)-c)+d))

add(679, 'inverse_variation_rounding',
    (('initial_r',1200,1,3000),('initial_hundredths_s',35,1,100),('new_r',2400,1,3000)),
    lambda a,b,c: f'Quantities $r$ and $s$ vary inversely. When $r={a}$, $s={decimal(b,2)}$. Find $s$ when $r={c}$, to the nearest thousandth (round half up).',
    lambda a,b,c: Q(floor(Q(10*a*b,c)+Q(1,2)),1000),
    reference=lambda a,b,c: Q((20*a*b+c)//(2*c),1000),
    adaptation='Specify half-up rounding for ties in the expanded domain.')

add(725, 'difference_of_powers_prime_factors',
    (('base',5,2,20),('high_exponent',5,2,9),('low_exponent',3,1,8)),
    lambda a,b,c: rf'Find the sum of the distinct prime factors of ${a}^{{{b}}}-{a}^{{{c}}}$.',
    lambda a,b,c: sum(prime_factors(a**b-a**c)),
    reference=lambda a,b,c: sum(set(prime_factors(a)+prime_factors(a**(b-c)-1))),
    valid=lambda a,b,c: b>c, constraints=('high_exponent > low_exponent',))

add(726, 'root_and_arithmetic_precedence',
    (('radicand',3,1,100),('dividend',12,1,100),('divisor',3,1,100),
     ('multiplier',2,1,100),('last_base',4,1,2500)),
    lambda a,b,c,d,e: rf'Evaluate $\sqrt{{{a}}}\times {a}^{{1/2}}+{b}\div {c}\times {d}-{e}^{{3/2}}$.',
    lambda a,b,c,d,e: a+Q(b*d,c)-e*isqrt(e),
    valid=lambda a,b,c,d,e: isqrt(e)**2==e,
    sample=lambda r:(r.randint(1,100),r.randint(1,100),r.randint(1,100),r.randint(1,100),r.randint(1,50)**2),
    constraints=('last_base is a perfect square',))

def falling_factorial_render(n,a):
    factors=[rf'(a-{j})' for j in range(n,0,-1)]
    if n>4:
        factors=[*factors[:2],r'\dotsm',factors[-1]]
    expression=r'\cdot '.join([*factors,'a'])
    return rf'Evaluate ${expression}$ at $a={a}$.'


add(734, 'falling_factorial',
    (('start_offset',10,2,30),('argument',2,-30,60)),
    falling_factorial_render,
    lambda n,a: prod(a-j for j in range(n+1)))


def expansion(a,b):
    symbols = 'abcdefghijklmnopqrstuvwxyz'
    return '+'.join(symbols[:a]), '+'.join(symbols[a:a+b])


add(774, 'disjoint_linear_factor_term_count',
    (('first_terms',3,2,13),('second_terms',4,2,13)),
    lambda a,b: 'How many terms are in the expansion of $({})({})$?'.format(*expansion(a,b)),
    lambda a,b: a*b,
    reference=lambda a,b: len({(x,y) for x in range(a) for y in range(b)}),
    adaptation='The parameters count the explicitly printed terms in each factor.')

add(805, 'decimal_floor',
    (('tenths',-12,-2000,2000),),
    lambda n: rf'If $[x]$ denotes the greatest integer less than or equal to $x$, calculate $[{decimal(n,1)}]$.',
    lambda n:n//10, reference=lambda n: floor(Q(n,10)))

add(865, 'powered_quotient',
    (('numerator_base',66666,1,999999),('denominator_base',22222,1,999999),('exponent',4,2,12)),
    lambda a,b,n: rf'Compute $\frac{{{a:,}^{{{n}}}}}{{{b:,}^{{{n}}}}}$.',
    lambda a,b,n: Q(a,b)**n, reference=lambda a,b,n: Q(a**n,b**n),
    sample=lambda r: (r.randint(1,8)*(b:=r.randint(1,124999)),b,r.randint(2,12)))

add(950, 'permutation_power_maximum',
    (('first_value',0,0,12),('second_value',1,0,12),('third_value',2,0,12),('fourth_value',3,0,12)),
    lambda a,b,c,d: f'The values of $a,b,c,d$ in $c\\cdot a^b-d$ are {a}, {b}, {c}, {d}, in some order. Find the maximum.',
    lambda *values: max(c*a**b-d for a,b,c,d in permutations(values)),
    valid=lambda *values: len(set(values))==4,
    sample=lambda r: tuple(sorted(r.sample(range(13),4))),
    constraints=('the four values are distinct',))

add(991, 'cyclic_ratio_sum',
    (('a',2,1,150),('b',12,1,150),('c',9,1,150)),
    lambda a,b,c: rf'For nonzero $a,b,c$ define $J(a,b,c)=\frac ab+\frac bc+\frac ca$. Find $J({a},{b},{c})$.',
    lambda a,b,c: Q(a,b)+Q(b,c)+Q(c,a),
    reference=lambda a,b,c:Q(a*a*c+b*b*a+c*c*b,a*b*c))

add(1141, 'powers_sum_product_difference',
    (('base',6,2,50),('exponent',2,1,10)),
    lambda a,n: rf'Find the positive difference between $\frac{{{a}^{{{n}}}+{a}^{{{n}}}}}{{{a}}}$ and $\frac{{{a}^{{{n}}}\times {a}^{{{n}}}}}{{{a}}}$.',
    lambda a,n: a**(n-1)*(a**n-2),
    reference=lambda a,n: abs((a**(2*n)-2*a**n)//a),
    valid=lambda a,n:a**n>2, constraints=('base^exponent > 2',))

add(1302, 'strict_rational_predecessor',
    (('numerator',-15,-1000,1000),('denominator',4,1,200)),
    lambda a,b: rf'Find the greatest integer strictly less than $\frac{{{a}}}{{{b}}}$.',
    lambda a,b:ceil(Q(a,b))-1, reference=lambda a,b:(a-1)//b)

add(1316, 'square_of_nines_zero_count',
    (('squared_number',99999999,99,10**40-1),),
    lambda n: rf'Squaring 99 gives 9801, with one zero. How many zeros are in the decimal expansion of ${n:,}^2$?',
    lambda n:len(str(n))-1, reference=lambda n:str(n*n).count('0'),
    sample=lambda r:(10**r.randint(2,40)-1,),
    valid=lambda n:set(str(n))=={'9'}, constraints=('squared_number consists entirely of nines',))

add(1349, 'continued_fraction',
    (('a',1,-20,20),('b',2,-20,20),('c',3,1,20),('d',4,1,20),('e',5,1,20)),
    lambda a,b,c,d,e:rf'Express ${a}+\cfrac{{{b}}}{{{c}+\cfrac{{{d}}}{{{e}}}}}$ as a fraction.',
    lambda a,b,c,d,e:a+Q(b,c+Q(d,e)),
    reference=lambda a,b,c,d,e:Q(a*(c*e+d)+b*e,c*e+d))

add(1434, 'sum_in_decimal_interval',
    (('lower_tenths',-121,-3000,2999),('upper_tenths',33,-2999,3000)),
    lambda a,b:f'What is the sum of the integers strictly between {decimal(a,1)} and {decimal(b,1)}?',
    lambda a,b:sum(range(a//10+1,ceil(Q(b,10)))),
    reference=lambda a,b:sum(x for x in range(-300,301) if a < 10*x < b),
    valid=lambda a,b:a<b, constraints=('lower_tenths < upper_tenths',),
    adaptation='Specify strict endpoints for generated intervals with integral endpoints.')

add(1642, 'lattice_circle_maximum',
    (('squared_radius',25,1,2500),),
    lambda n: rf'Among the ordered pairs of integers $(x,y)$ satisfying $x^2+y^2={n}$, what is the greatest possible $x+y$?',
    lambda n:max(x+isqrt(n-x*x) for x in range(isqrt(n)+1) if isqrt(n-x*x)**2==n-x*x),
    reference=lambda n:max(x+y for x in range(isqrt(n)+1) for y in range(isqrt(n)+1) if x*x+y*y==n),
    valid=lambda n:any(isqrt(n-x*x)**2==n-x*x for x in range(isqrt(n)+1)),
    sample=lambda r:(r.randint(1,35)**2+r.randint(1,35)**2,),
    constraints=('squared_radius is representable as the sum of two integer squares',),
    adaptation='Omit the number of lattice pairs, which varies with the squared radius.')

add(1717, 'strict_consecutive_product',
    (('product_bound',400,1,10000),),
    lambda n:f'What is the greatest possible sum of two consecutive integers whose product is less than {n}?',
    lambda n:2*((isqrt(4*n-3)-1)//2)+1,
    reference=lambda n:max(2*x+1 for x in range(isqrt(n)+1) if x*(x+1)<n))

add(1734, 'positive_quadratic_interval',
    (('linear_coefficient',6,0,30),('constant',9,-30,100),
     ('lower_bound',20,-30,999),('upper_bound',40,-29,1000)),
    lambda b,c,l,h:rf'For how many positive integers $x$ is $x^2+({b})x+({c})$ strictly between {l} and {h}?',
    lambda b,c,l,h:sum(l<x*x+b*x+c<h for x in range(1,isqrt(max(0,h-c))+1)),
    valid=lambda b,c,l,h:l<h, constraints=('lower_bound < upper_bound',),
    adaptation='Specify strict endpoints for generated intervals meeting a quadratic value.')


def pi_coefficient(n,d):
    if n==d:
        return r'\pi'
    if d==1:
        return rf'{n}\pi'
    return rf'\frac{{{n}\pi}}{{{d}}}'


add(135, 'floor_rational_multiple_of_pi',
    (('numerator',1,1,200),('denominator',1,1,20)),
    lambda n,d:rf'Evaluate $\lfloor {pi_coefficient(n,d)}\rfloor$.',
    lambda n,d:333*n//(106*d),
    valid=lambda n,d:333*n//(106*d)==355*n//(113*d),
    constraints=('the floors agree using the lower and upper bounds 333/106 and 355/113 for pi',),
    adaptation='Permit a positive rational multiple of pi inside the floor, with factor 1 at the source.')


def prime(n):
    return n>=2 and all(n%d for d in range(2,isqrt(n)+1))


# Each admissible common difference has a progression entirely above 1000.
# The recorded starting primes are internal certificates, never printed.
PRIME_PROGRESSION_WITNESSES = {
    6: 1091, 12: 1447, 18: 1033, 24: 1399, 36: 1151, 42: 1087,
    48: 1153, 54: 1009, 66: 1031, 72: 1217, 78: 1093, 84: 1069,
    96: 1471, 102: 1307, 108: 2053, 114: 1259, 126: 1171, 132: 1097,
    138: 1013, 144: 1019, 156: 1511, 162: 1297, 168: 1063, 174: 1279,
    186: 1051, 192: 1087, 198: 1033, 204: 1249, 216: 1021, 222: 1487,
    228: 1093, 234: 1549, 246: 1051, 252: 1237, 258: 1103, 264: 1039,
    276: 1171, 282: 1297, 288: 1823, 294: 1259,
}


def progression_exists(step, lower):
    start=PRIME_PROGRESSION_WITNESSES.get(step)
    return start is not None and lower<start and all(prime(start+i*step) for i in range(4))


add(702, 'prime_progression_units_digit',
    (('common_difference',6,6,294),('lower_bound',5,5,1000)),
    lambda d,l:f'Four primes $a,b,c,d$ form an increasing arithmetic sequence with $a>{l}$ and common difference {d}. What is the ones digit of $a$?',
    lambda d,l:next(k for k in (1,3,7,9) if k%5==d%5),
    valid=progression_exists,
    sample=lambda r:(r.choice(tuple(PRIME_PROGRESSION_WITNESSES)),r.randint(5,1000)),
    reference=lambda d,l:next(a%10 for a in range(l+1,5001) if all(prime(a+i*d) for i in range(4))),
    constraints=('common_difference is a multiple of 6 and is not divisible by 5; each such step in [6, 294] has a certified progression starting above 1000',))
