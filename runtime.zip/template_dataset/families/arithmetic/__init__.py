"""Exact mathematical models for arithmetic."""
