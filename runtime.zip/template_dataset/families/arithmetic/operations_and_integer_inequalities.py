"""Operations and integer inequalities; exact source-bound mathematical models."""
from fractions import Fraction as F
from math import ceil, floor, isqrt

from template_dataset.families.algebra.source_spans import bind


def build(row, index):
    def make(*args, **kwargs):
        return bind(row, *args, **kwargs)

    if index == 113:
        return make('repeating_decimal', dict(prefix=(0, 9), repetend=(0, 999)), (6, 333),
                    [(r'6\overline{333}', lambda a, b: fr'{a}\overline{{{b:03}}}')],
                    lambda a, b: F(999*a+b, 9990),
                    reference=lambda a, b: (F(a*1000+b, 10000)-F(a, 10))*F(1000, 999)+F(a, 10))
    if index == 185:
        return make('reciprocal_operation', dict(first=(1, 200), second=(1, 200)), (3, 11),
                    [(r'3 \star 11', lambda a, b: fr'{a} \star {b}')],
                    lambda a, b: F(1, a*b),
                    reference=lambda a, b: (F(1, b)-F(1, a))/(a-b),
                    valid=lambda a, b: a != b, constraints=['The two operands are distinct.'])
    if index == 248:
        return make('floors_of_scaled_fraction', dict(numerator=(1, 50), denominator=(2, 150)), (1, 3),
                    [(r'\frac{1}{3}', lambda a, b: fr'\frac{{{a}}}{{{b}}}')],
                    lambda a, b: sum(a*10**k//b for k in range(1, 5)),
                    reference=lambda a, b: sum(floor(10**k*F(a, b)) for k in range(1, 5)))
    if index in (253, 1110):
        if index == 253:
            fragment = (r'3 \ast (6 \ast 8)', lambda a, b, c: fr'{a} \ast ({b} \ast {c})')
            weights = (2, 1, 1)
            oracle = lambda a, b, c: (a+F(b+c, 2))/2
            values = (3, 6, 8)
        else:
            fragment = (r'(3\& 5) \& 8', lambda a, b, c: fr'({a}\& {b}) \& {c}')
            weights = (1, 1, 2)
            oracle = lambda a, b, c: (F(a+b, 2)+c)/2
            values = (3, 5, 8)
        return make('nested_average', dict(first=(-200, 200), second=(-200, 200), third=(-200, 200)),
                    values, [fragment], lambda *values: F(sum(x*w for x, w in zip(values, weights)), 4),
                    reference=oracle)
    if index == 264:
        return make('shift_then_square', dict(shift=(1, 200), argument=(-200, 200)), (5, 4),
                    [('x + 5', lambda a, b: f'x + {a}'), (r'\&4', lambda a, b: fr'\&{b}')],
                    lambda a, b: (a+b)**2, reference=lambda a, b: a*a+2*a*b+b*b)
    if index == 324:
        return make('equal_ratios', dict(numerator=(1, 90), denominator=(2, 100), common=(1, 1000)),
                    (2, 5, 60), [(r'\frac 25', lambda a, b, n: r'\frac 25' if (a, b) == (2, 5) else fr'\frac{{{a}}}{{{b}}}'),
                                  (r'\frac A{60} = \frac {60}B', lambda a, b, n: fr'\frac A{{{n}}} = \frac {{{n}}}B')],
                    lambda a, b, n: F(n*(a*a+b*b), a*b),
                    reference=lambda a, b, n: n*F(a, b)+n*F(b, a))
    if index == 399:
        return make('symmetric_rational_operation', dict(a=(1, 150), b=(1, 150), c=(1, 150)), (2, 4, 6),
                    [('(2,4,6)', lambda a, b, c: f'({a},{b},{c})')],
                    lambda a, b, c: F(a*b*c, a+b+c),
                    reference=lambda a, b, c: 1/(F(1,a*b)+F(1,a*c)+F(1,b*c)))
    if index == 507:
        return make('square_of_sum_operation', dict(a=(-200, 200), b=(-200, 200)), (3, 5),
                    [('a = 3', lambda a, b: f'a = {a}'), ('b = 5', lambda a, b: f'b = {b}')],
                    lambda a, b: (a+b)**2, reference=lambda a, b: a*a+2*a*b+b*b)
    if index == 517:
        return make('arithmetic_expression_difference',
                    dict(a=(1, 50), b=(1, 50), c=(1, 50), d=(1, 50), e=(1, 50), f=(1, 50), g=(1, 50)),
                    (2, 6, 4, 3, 8, 3, 3),
                    [('2(6) + 4(3)', lambda a,b,c,d,e,f,g: f'{a}({b}) + {c}({d})'),
                     ('8(3+3)', lambda a,b,c,d,e,f,g: f'{e}({f}+{g})')],
                    lambda a,b,c,d,e,f,g: abs(a*b+c*d-e*(f+g)),
                    valid=lambda a,b,c,d,e,f,g: a*b+c*d != e*(f+g),
                    constraints=['The two expressions have different values.'])
    if index == 543:
        return make('mean_of_initial_integers', dict(last=(2, 10000)), (250,),
                    [('to 250', lambda n: f'to {n}')],
                    lambda n: F(n+1, 2), reference=lambda n: F(sum(range(1,n+1)), n))
    if index == 660:
        def bounds(a,b,c,d,e):
            return floor(F(a*e,d))+1, ceil(F(a*c,b))-1

        def solve(a,b,c,d,e):
            lo, hi = bounds(a,b,c,d,e)
            return (hi-lo+1)*(hi+lo)//2 if hi >= lo else 0

        return make('reciprocal_inequality', dict(numerator=(1, 50), lower_num=(1, 30),
                    lower_den=(2, 50), upper_num=(1, 50), upper_den=(2, 50)), (3,1,3,3,4),
                    [(r'\frac{3}{x}', lambda a,b,c,d,e: fr'\frac{{{a}}}{{x}}'),
                     (r'\frac{1}{3}', lambda a,b,c,d,e: fr'\frac{{{b}}}{{{c}}}'),
                     (r'\frac{3}{4}', lambda a,b,c,d,e: fr'\frac{{{d}}}{{{e}}}')],
                    solve, valid=lambda a,b,c,d,e: b*e < d*c,
                    constraints=['The lower bound is less than the upper bound.'],
                    reference=lambda a,b,c,d,e: sum(x for x in range(1, a*c+1) if F(b,c)<F(a,x)<F(d,e)))
    if index in (701, 923):
        if index == 701:
            return make('square_interval_count', dict(shift=(1, 30), lower=(1, 1000), upper=(2, 2500)),
                        (2,10,50), [('4x + 4', lambda k,a,b: f'{2*k}x + {k*k}'),
                                    ('10 and 50', lambda k,a,b: f'{a} and {b}')],
                        lambda k,a,b: max(0, isqrt(b-1)-max(k,isqrt(a))),
                        valid=lambda k,a,b: a < b and isqrt(a)**2 != a and isqrt(b)**2 != b,
                        constraints=['The ordered interval endpoints are nonsquares, so between is unambiguous.'],
                        reference=lambda k,a,b: sum(a<(x+k)**2<b for x in range(1,b+1)))
        return make('square_threshold_count', dict(shift=(1, 30), upper=(2, 2500)), (2,20),
                    [('4x+4', lambda k,b: f'{2*k}x+{k*k}'), ('than 20', lambda k,b: f'than {b}')],
                    lambda k,b: max(0,isqrt(b-1)-k),
                    reference=lambda k,b: sum((x+k)**2<b for x in range(1,b+1)))
    if index == 767:
        return make('bracketed_arithmetic', dict(left=(1, 50), square=(1, 50), multiplier=(1, 50),
                    factor=(1, 50), divisor=(1, 50), offset=(1, 50)), (8,6,3,11,8,3),
                    [(r'8[6^2-3(11)]\div8 + 3', lambda a,b,c,d,e,f: fr'{a}[{b}^2-{c}({d})]\div{e} + {f}')],
                    lambda a,b,c,d,e,f: F(a*(b*b-c*d), e)+f)
    if index == 858:
        return make('fraction_sum_product_difference', dict(a=(1,50), b=(1,50), c=(1,50), d=(1,50)),
                    (1,2,1,3), [(r'\frac{1}{2}', lambda a,b,c,d: fr'\frac{{{a}}}{{{b}}}'),
                                (r'\frac{1}{3}', lambda a,b,c,d: fr'\frac{{{c}}}{{{d}}}')],
                    lambda a,b,c,d: F(abs(a*d+b*c-a*c), b*d),
                    valid=lambda a,b,c,d: a*d+b*c != a*c,
                    constraints=['The sum and product are different.'],
                    reference=lambda a,b,c,d: abs(F(a,b)+F(c,d)-F(a,b)*F(c,d)))
    if index == 907:
        return make('prefix_suffix_operation', dict(constant=(1, 100), argument=(-200, 200)), (7,15),
                    [('7-x', lambda a,b: f'{a}-x'), ('x -7', lambda a,b: f'x -{a}'),
                     ('15', lambda a,b: b)], lambda a,b: -b, reference=lambda a,b: (a-b)-a)
    if index == 908:
        return make('rational_quadratic_composition', dict(constant=(1, 100), numerator=(1, 100), argument=(1,100)),
                    (2,6,2), [('2-x^2', lambda a,b,c: f'{a}-x^2'),
                              (r'\frac{6}{x}', lambda a,b,c: fr'\frac{{{b}}}{{x}}'),
                              ('q(2)', lambda a,b,c: f'q({c})')],
                    lambda a,b,c: F(a*c*c-b*b,c*c), reference=lambda a,b,c: a-F(b,c)**2)
    if index == 1012:
        return make('inverse_power_inequality', dict(multiplier=(1, 10000)), (1,),
                    [('x^{-1}', lambda a: 'x^{-1}' if a==1 else f'{a}x^{{-1}}')],
                    lambda a: isqrt(a-1), reference=lambda a: sum(F(a,x)>x for x in range(1,a+1)))
    if index == 1031:
        return make('iterated_absolute_affine', dict(intercept_magnitude=(1,100), slope=(1,100), argument=(-100,100)),
                    (3,2,-4), [('-3+2x', lambda a,b,c: f'-{a}+{b}x'),
                               ('t(-4)', lambda a,b,c: f't({c})')],
                    lambda a,b,c: abs(b*abs(b*c-a)-a))
    if index == 1143:
        return make('cancelled_monomials', dict(first=(1,100), second=(1,100)), (7,4),
                    [('7b^3', lambda a,b: f'{a}b^3'), ('4b^2', lambda a,b: f'{b}b^2')],
                    lambda a,b: F(a*a,b**3),
                    reference=lambda a,b: (F(a)*8)**2*(F(b)*4)**-3)
