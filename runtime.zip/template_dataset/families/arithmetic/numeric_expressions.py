"""Strict numeric-expression templates. No Python eval and no answer lookup.

Each numeric occurrence is an independent parameter in its original decimal
unit. The expression tree, operators and grouping are fixed. Domain membership
requires a defined real rational result and bounded exact intermediate values."""
from fractions import Fraction
from math import factorial, isqrt
import re
from template_dataset.core import Template


def _root(n, k):
    if k < 1 or k > 12 or n < 0 and k % 2 == 0: raise ValueError('root domain')
    if n < 0:return -_root(-n,k)
    lo, hi=0,1 << ((n.bit_length()+k-1)//k)
    while lo<hi:
        mid=(lo+hi+1)//2
        if mid**k<=n:lo=mid
        else:hi=mid-1
    if lo**k!=n:raise ValueError('irrational result')
    return lo


def _power(a,b):
    if abs(b)>10000 or b.denominator>12:raise ValueError('exponent bound')
    if a==0 and b<=0:raise ValueError('undefined zero power')
    if b.denominator!=1:
        a=Fraction(_root(a.numerator,b.denominator),_root(a.denominator,b.denominator))
    e=b.numerator
    if max(abs(a.numerator).bit_length(),a.denominator.bit_length())*abs(e)>4096:
        raise ValueError('output size bound')
    return a**e


def _apply(op,args):
    if op=='+':r=args[0]+args[1]
    elif op=='mixed':
        if args[0].denominator!=1 or not 0<=args[1]<1:raise ValueError('mixed numeral requires proper fraction')
        r=args[0]+args[1]
    elif op=='-':r=args[0]-args[1]
    elif op=='*':r=args[0]*args[1]
    elif op=='/':r=args[0]/args[1]
    elif op=='^':r=_power(*args)
    elif op=='neg':r=-args[0]
    elif op=='abs':r=abs(args[0])
    elif op=='floor':r=Fraction(args[0].numerator//args[0].denominator)
    elif op=='ceil':r=Fraction(-((-args[0].numerator)//args[0].denominator))
    elif op=='!':
        if args[0].denominator!=1 or not 0<=args[0]<=500:raise ValueError('factorial domain')
        r=Fraction(factorial(int(args[0])))
    else:raise ValueError('unknown operator')
    if max(abs(r.numerator).bit_length(),r.denominator.bit_length())>4096:raise ValueError('size limit')
    return r


def evaluate(node,p):
    op=node[0]
    if op=='n':return Fraction(p[node[1]],node[2])
    if op=='const':return Fraction(node[1])
    if op in ('floor','ceil'):return Fraction(_rounded(node[1],p,op=='ceil'))
    return _apply(op,[evaluate(c,p) for c in node[1:]])


def _rounded(node,p,ceiling):
    if node[0]=='neg':return -_rounded(node[1],p,not ceiling)
    if node[0]=='^' and evaluate(node[2],p)==Fraction(1,2):
        q=evaluate(node[1],p)
        if q<0:raise ValueError('negative radicand')
        k=isqrt(q.numerator//q.denominator)
        return k+int(ceiling and k*k!=q)
    q=evaluate(node,p)
    return -((-q.numerator)//q.denominator) if ceiling else q.numerator//q.denominator


def reference(node,p):
    """Postorder stack evaluation, separate from recursive solver traversal."""
    stack=[]
    def tokens(n):
        if n[0] in ('floor','ceil'):
            yield ('const',_rounded(n[1],p,n[0]=='ceil'))
        elif n[0] in ('n','const'):
            yield n
        else:
            for c in n[1:]:yield from tokens(c)
            yield (n[0],len(n)-1)
    for tok in tokens(node):
        if tok[0]=='n':stack.append(Fraction(p[tok[1]],tok[2]))
        elif tok[0]=='const':stack.append(Fraction(tok[1]))
        else:
            args=stack[-tok[1]:];del stack[-tok[1]:]
            stack.append(_apply(tok[0],args))
    return stack[0]


class _Parser:
    def __init__(self,text):
        text=re.sub(r'\\(?:left|right|displaystyle|textstyle)\b','',text)
        text=re.sub(r'\\(?:,|!|;|quad\b|qquad\b)','',text)
        text=text.replace('~',' ')
        text=text.replace(r'\dfrac',r'\frac').replace(r'\tfrac',r'\frac')
        text=text.replace(r'\cfrac',r'\frac')
        text=re.sub(r'\\frac\s*([0-9])\s*([0-9])',r'\\frac{\1}{\2}',text)
        text=re.sub(r'\^([+-]?\d+(?:\.\d+)?)',r'^{\1}',text)
        self.text=text;self.pos=0;self.original={};self.domains={};self.spans=[]

    def peek(self):
        while self.pos<len(self.text) and self.text[self.pos].isspace():self.pos+=1
        return self.text[self.pos:self.pos+1]

    def consume(self,s):
        self.peek()
        if self.text.startswith(s,self.pos):self.pos+=len(s);return True
        return False

    def expr(self):
        n=self.term()
        while self.peek() in ('+','-'):
            op=self.peek();self.pos+=1;n=(op,n,self.term())
        return n

    def term(self):
        n=self.unary()
        while True:
            if self.consume(r'\cdot') or self.consume(r'\times') or self.consume('*'):
                n=('*',n,self.unary())
            elif self.consume(r'\div') or self.consume('/'):
                n=('/',n,self.unary())
            elif self.peek() and (self.peek().isdigit() or self.peek() in '({[' or
                                  self.text.startswith((r'\frac',r'\sqrt',r'\lfloor',r'\lceil'),self.pos)):
                n=('*',n,self.unary())
            else:break
        return n

    def unary(self):
        if self.consume('+'):return self.unary()
        if self.consume('-'):return ('neg',self.unary())
        n=self.atom()
        while self.consume('!'):n=('!',n)
        if self.consume('^'):n=('^',n,self.unary())
        return n

    def atom(self):
        c=self.peek()
        for kind in ('floor','ceil'):
            if self.consume('\\l'+kind):
                n=self.expr()
                if not self.consume('\\r'+kind):raise ValueError('rounding delimiter')
                return (kind,n)
        if c and c in '({[':
            close={'(':')','{':'}','[':']'}[c];self.pos+=1;n=self.expr()
            if not self.consume(close):raise ValueError('unbalanced group')
            return n
        if self.consume(r'\frac'):
            return ('/',self.atom(),self.atom())
        if self.consume(r'\sqrt'):
            degree=2
            if self.consume('['):
                m=re.match(r'[2-9]|1[0-2]',self.text[self.pos:])
                if not m:raise ValueError('root index')
                degree=int(m[0]);self.pos+=len(m[0])
                if not self.consume(']'):raise ValueError('root index')
            return ('^',self.atom(),('const',Fraction(1,degree)))
        if self.consume('|'):
            n=self.expr()
            if not self.consume('|'):raise ValueError('absolute value')
            return ('abs',n)
        m=re.match(r'(?:\d+(?:\.\d+)?|\.\d+)',self.text[self.pos:])
        if not m:raise ValueError('unsupported numeric expression')
        raw=m[0];start=self.pos;self.pos+=len(raw)
        name=f'n{len(self.original)+1}'
        scale=10**len(raw.partition('.')[2]);value=int(Fraction(raw)*scale)
        self.original[name]=value
        self.domains[name]={'type':'int','min':0,'max':max(30*scale,value),
                            'unit':f'1/{scale}', 'description':f'Numeric occurrence {len(self.original)} in units of 1/{scale}'}
        self.spans.append((start,self.pos,name,scale))
        n=('n',name,scale)
        self.peek()
        if scale==1 and self.text.startswith(r'\frac',self.pos):n=('mixed',n,self.atom())
        return n


def parse_expression(text):
    parser=_Parser(text)
    node=parser.expr()
    if parser.peek():raise ValueError('trailing expression content')
    if not parser.original or len(parser.original)>35:raise ValueError('parameter count')
    def render(p):
        def tex(n):
            op=n[0]
            if op=='n':
                value=p[n[1]];scale=n[2]
                if scale==1:return str(value)
                width=len(str(scale))-1
                return f'{value//scale}.{value%scale:0{width}d}'
            if op=='const':
                value=n[1]
                return str(value.numerator) if value.denominator==1 else rf'\frac{{{value.numerator}}}{{{value.denominator}}}'
            args=[tex(c) for c in n[1:]]
            if op=='/':return rf'\frac{{{args[0]}}}{{{args[1]}}}'
            if op=='^':return rf'\left({args[0]}\right)^{{{args[1]}}}'
            if op=='neg':return rf'\left(-{args[0]}\right)'
            if op=='abs':return rf'\left|{args[0]}\right|'
            if op=='!':return rf'\left({args[0]}\right)!'
            if op in ('floor','ceil'):return '\\l'+op+' '+args[0]+'\\r'+op
            operator={'mixed':'+','*':r'\cdot'}.get(op,op)
            return rf'\left({args[0]} {operator} {args[1]}\right)'
        return tex(node)
    return node,parser.original,parser.domains,render


def _expression_from_statement(statement):
    s=' '.join(statement.split()).strip()
    s=re.sub(r'\s*\(No calculators!\)$','',s).strip()
    s=re.sub(r'\s+in your head\.$','.',s)
    s=re.sub(r'\.?\s*(?:Write your answer as an integer|Express your answer as a common fraction)\.$','.',s)
    s=re.sub(r'^(?:Write|Express) (.+?) as an integer\.$',r'Compute \1.',s)
    s=re.sub(r'^What (?:is|number is) (.+?) (?:is equal to|equal to|in simplest terms|expressed as a positive integer)\?$',r'Compute \1.',s)
    prefixes=(r'(?:Compute(?: the value of| without using a calculator)?|Calculate|Evaluate(?: the expression)?|Simplify(?: the fraction| completely| the following expression)?|Find(?: the value of)?|What is(?: the simplified value of| the value of(?: the expression)?| the sum of)?)\s*[:.]?',)
    m=re.fullmatch(prefixes[0]+r'\s*(.*?)\s*[?.]?',s)
    if not m:return None
    exp=m[1].strip()
    exp=re.sub(r'\s*(?:Write your answer as an integer|Express your answer as a common fraction)\.$','',exp)
    if exp.startswith('$$') and exp.endswith('$$'):exp=exp[2:-2]
    elif exp.startswith('$') and exp.endswith('$'):exp=exp[1:-1]
    elif exp.startswith(r'\[') and exp.endswith(r'\]'):exp=exp[2:-2]
    elif '$' in exp:return None
    exp=exp.rstrip('.?').strip()
    if re.search(r'(?<!\\)[a-zA-Z]', re.sub(r'\\[a-zA-Z]+','',exp)):return None
    return exp


def build(row):
    expression=_expression_from_statement(row['problem'])
    if expression is None:return None
    try:
        node,original,domains,render=parse_expression(expression)
        evaluate(node,original)
    except (ValueError,ZeroDivisionError,OverflowError):return None
    def tractable(n):
        if n[0] in ('n','const'):return True
        if n[0] in ('floor','ceil'):return True
        if n[0]=='^' and evaluate(n[2],original).denominator>1 and n[1][0]!='n':return False
        return all(tractable(c) for c in n[1:])
    if not tractable(node):return None
    integer_required=bool(re.search(r'(?:as an integer|as a positive integer)',row['problem']))
    positive_required='positive integer' in row['problem']
    def valid(p):
        try:
            result=evaluate(node,p)
            return (not integer_required or result.denominator==1) and (not positive_required or result>0)
        except (ValueError,ZeroDivisionError,OverflowError):return False
    def sample(rng):
        # Construct direct radicals/powers factorial arguments before bounded rejection.
        p={k:rng.randint(d['min'],min(d['max'],max(30,v*2))) for (k,d),v in zip(domains.items(),original.values())}
        def constrain(n):
            if n[0] in ('n','const'):return
            if n[0] in ('floor','ceil'):return
            for child in n[1:]:constrain(child)
            if n[0]=='^':
                if n[2][0]=='n':p[n[2][1]]=rng.randint(0,min(8,domains[n[2][1]]['max']))
                try:b=evaluate(n[2],p)
                except (ValueError,ZeroDivisionError):return
                if b.denominator>1 and n[1][0]=='n' and n[1][2]==1:
                    key=n[1][1];degree=b.denominator
                    if degree<=12:
                        hi=int(domains[key]['max']**(1/degree))
                        while (hi+1)**degree<=domains[key]['max']:hi+=1
                        while hi**degree>domains[key]['max']:hi-=1
                        p[key]=rng.randint(0,hi)**degree
            elif n[0]=='!' and n[1][0]=='n':p[n[1][1]]=rng.randint(0,min(12,domains[n[1][1]]['max']))
        constrain(node)
        return p
    return Template(family='arithmetic.expression',parameters=domains,original=original,
        render=lambda p:'Compute $'+render(p)+'$.',solve=lambda p:evaluate(node,p),
        sample=sample,validate=valid,reference=lambda p:reference(node,p),
        constraints=['All divisions have nonzero denominators.',
                     'A direct square-root operand of floor/ceil may be irrational and is rounded using exact integer bounds. Other evaluated roots/powers must have defined real rational values; exponents have absolute value <=10000 and denominator <=12.',
                     'Factorial inputs are integers in [0,500]; intermediate numerators and denominators have at most 4096 bits.',
                     'The fractional part of any mixed numeral is in [0,1).',
                     ('The final result must be a positive integer.' if positive_required else 'The final result must be an integer.' if integer_required else 'The final result is an exact rational number.'),
                     'Numeric occurrences are independent; operators and grouping remain fixed.'],
        adaptation='The expression tree is retained and rendered with explicit grouping and braced exponents; the instruction is normalized to Compute. Decimal occurrences use fixed decimal units. Roots are equivalent rational powers with structural root indices.')
