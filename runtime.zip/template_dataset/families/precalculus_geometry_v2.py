"""Exact coordinate constructions and small geometric source extensions."""
from fractions import Fraction as F
from math import isqrt
from template_dataset.families.precalculus_v2 import T,I,L,sq,root,dot,cross,vec,nice_vectors


def norm(v):return dot(v,v)
def sub(a,b):return [x-y for x,y in zip(a,b)]
def build(row):
    key=row['id']
    if key in ('precalculus/test/38','precalculus/test/194','precalculus/test/295','precalculus/test/497','precalculus/test/328'):
        if key.endswith('/38'):
            return T('vector_angle_cosine',dict(a=[3,-4],b=[12,5]),{'a':L(2),'b':L(2)},
              lambda p:f"Find the cosine of the angle between vectors {vec(p['a'])} and {vec(p['b'])}.",
              lambda p:F(dot(p['a'],p['b']))/root(norm(p['a'])*norm(p['b'])),
              lambda p:norm(p['a'])*norm(p['b'])>0 and sq(norm(p['a'])*norm(p['b'])),
              lambda r:dict(a=list(r.choice(nice_vectors(2))),b=list(r.choice(nice_vectors(2)))),
              constraints=['Both vectors are nonzero and the product of squared norms is a perfect square.'])
        if key.endswith('/194'):
            return T('complex_argument_cosine',dict(v=[-24,7]),{'v':L(2,-50,50)},
              lambda p:rf"Write ${p['v'][0]}+({p['v'][1]})i=re^{{i\theta}}$ with r>0. Find cos(theta).",
              lambda p:F(p['v'][0])/root(norm(p['v'])),lambda p:norm(p['v'])>0 and sq(norm(p['v'])),
              lambda r:dict(v=list(r.choice(nice_vectors(2)))),constraints=['Vector is nonzero with perfect-square squared norm.'])
        if key.endswith('/295'):
            return T('point_plane_distance',dict(point=[2,1,0],normal=[2,1,2],offset=5),{'point':L(3),'normal':L(3),'offset':I(-50,50)},
              lambda p:rf"Find the distance from {vec(p['point'])} to the plane $({p['normal'][0]})x+({p['normal'][1]})y+({p['normal'][2]})z+({p['offset']})=0$.",
              lambda p:F(abs(dot(p['point'],p['normal'])+p['offset']))/root(norm(p['normal'])),
              lambda p:norm(p['normal'])>0 and sq(norm(p['normal'])),
              lambda r:dict(point=[r.randint(-20,20) for _ in range(3)],normal=list(r.choice(nice_vectors(3))),offset=r.randint(-30,30)),
              reference=lambda p:root(sum((F(dot(p['point'],p['normal'])+p['offset'],norm(p['normal']))*n)**2 for n in p['normal'])),
              constraints=['Nonzero normal with perfect-square squared norm.'])
        if key.endswith('/497'):
            return T('spherical_polar_cosine',dict(point=[12,-4,3]),{'point':L(3)},
              lambda p:f"A point has rectangular coordinates {vec(p['point'])}. Find cos(phi), where phi is its spherical polar angle measured from the positive z-axis.",
              lambda p:F(p['point'][2])/root(norm(p['point'])),lambda p:norm(p['point'])>0 and sq(norm(p['point'])),
              lambda r:dict(point=list(r.choice(nice_vectors(3)))),constraints=['Nonzero position vector with perfect-square squared norm.'])
        def ref(p):
            a,b,c=p['areas'];xx,yy,zz=F(2*a*b,c),F(2*a*c,b),F(2*b*c,a)
            s,t,u=xx+yy,xx+zz,yy+zz
            return root(F(2*(s*t+s*u+t*u)-s*s-t*t-u*u,16))
        return T('coordinate_face_areas',dict(areas=[4,6,12]),{'areas':L(3,1,30)},
          lambda p:f"O is the origin; A,B,C lie on the x,y,z axes. Areas OAB,OAC,OBC are {p['areas'][0]}, {p['areas'][1]}, {p['areas'][2]}. Find the area of ABC.",
          lambda p:root(norm(p['areas'])),lambda p:sq(norm(p['areas'])),
          lambda r:dict(areas=list(r.choice([v for v in nice_vectors(3) if min(v)>0]))),ref,
          ['Sum of the squares of the three positive face areas is a perfect square.'])
    unit_cases={'precalculus/train/709':([3,4,5],[-12,5,13]),'precalculus/test/182':([3,4,5],[-12,5,13])}
    if key in unit_cases:
        a,b=unit_cases[key];sine=key.endswith('/709')
        def sample(r):
            def one():
                x,y=r.choice(nice_vectors(2));return [x,y,isqrt(x*x+y*y)]
            return dict(a=one(),b=one())
        return T('unit_complex_sum_sine' if sine else 'unit_complex_difference_cosine',dict(a=a,b=b),{'a':L(3,-30,30),'b':L(3,-30,30)},
          lambda p:rf"Given $e^{{i\alpha}}={F(p['a'][0],p['a'][2])}+({F(p['a'][1],p['a'][2])})i$ and $e^{{i\beta}}={F(p['b'][0],p['b'][2])}+({F(p['b'][1],p['b'][2])})i$, find "+('sin(alpha+beta).' if sine else 'cos(alpha-beta).'),
          lambda p:F(p['a'][0]*p['b'][1]+p['a'][1]*p['b'][0] if sine else p['a'][0]*p['b'][0]+p['a'][1]*p['b'][1],p['a'][2]*p['b'][2]),
          lambda p:all(v[2]>0 and v[0]*v[0]+v[1]*v[1]==v[2]*v[2] for v in (p['a'],p['b'])),sample,
          constraints=['Each list is [real numerator, imaginary numerator, positive denominator] on the unit circle.'])
    if key=='precalculus/test/193':
        def sample(r):
            vs=[v for v in nice_vectors(2) if min(v)>0]
            a,b=r.choice(vs);c,d=r.choice(vs)
            return dict(a=a,b=isqrt(a*a+b*b),c=c,d=isqrt(c*c+d*d))
        return T('acute_angle_cosine_sum',dict(a=3,b=5,c=5,d=13),{k:I(1,40) for k in 'abcd'},
          lambda p:rf"Angles alpha,beta are acute, with cos(alpha)={F(p['a'],p['b'])} and cos(beta)={F(p['c'],p['d'])}. Find cos(alpha+beta).",
          lambda p:F(p['a']*p['c']-isqrt(p['b']**2-p['a']**2)*isqrt(p['d']**2-p['c']**2),p['b']*p['d']),
          lambda p:p['a']<p['b'] and p['c']<p['d'] and sq(p['b']**2-p['a']**2) and sq(p['d']**2-p['c']**2),sample,
          constraints=['Each cosine is strictly between zero and one; b²-a² and d²-c² are perfect squares.'])
    if key=='precalculus/test/263':
        def sample(r):
            a,b=r.choice([v for v in nice_vectors(2) if min(v)>0]);return dict(a=a,c=isqrt(a*a+b*b),quadrant=r.choice([2,3]))
        return T('quadrant_tangent',dict(a=20,c=29,quadrant=3),{'a':I(1,40),'c':I(2,50),'quadrant':{'type':'int','choices':[2,3]}},
          lambda p:f"Angle x is in quadrant {p['quadrant']} and cos(x)=-{F(p['a'],p['c'])}. Find tan(x).",
          lambda p:F((1 if p['quadrant']==3 else -1)*isqrt(p['c']**2-p['a']**2),p['a']),
          lambda p:p['a']<p['c'] and sq(p['c']**2-p['a']**2),sample,
          constraints=['0 < a < c and c²-a² is a perfect square; quadrant fixes the sine sign.'])
    if key=='precalculus/test/352':
        def sample(r):
            center=[r.randint(-10,10) for _ in range(3)];radius=r.randint(1,20)
            return dict(linear=[-2*x for x in center],constant=norm(center)-radius*radius)
        return T('sphere_complete_square',dict(linear=[2,6,-12],constant=30),{'linear':L(3,-40,40),'constant':I(-1000,1500)},
          lambda p:rf"The equation $x^2+({p['linear'][0]})x+y^2+({p['linear'][1]})y+z^2+({p['linear'][2]})z+({p['constant']})=0$ is a sphere. Find its radius.",
          lambda p:root(F(norm(p['linear']),4)-p['constant']),
          lambda p:F(norm(p['linear']),4)>p['constant'] and sq(F(norm(p['linear']),4)-p['constant']),sample,
          constraints=['Squared radius (sum of squared linear coefficients)/4 - constant is a positive rational square.'])
    if key=='precalculus/test/374':
        def rad(p):
            a,b,c=p['intercepts'];return (a*b)**2+(a*c)**2+(b*c)**2
        triples=[(a,b,c) for a in range(1,13) for b in range(1,13) for c in range(1,13) if sq((a*b)**2+(a*c)**2+(b*c)**2)]
        return T('coordinate_tetrahedron_inradius',dict(intercepts=[6,4,2]),{'intercepts':L(3,1,20)},
          lambda p:f"A sphere is inscribed in the tetrahedron with vertices (0,0,0), ({p['intercepts'][0]},0,0), (0,{p['intercepts'][1]},0), (0,0,{p['intercepts'][2]}). Find its radius.",
          lambda p:F(p['intercepts'][0]*p['intercepts'][1]*p['intercepts'][2],sum(p['intercepts'][i]*p['intercepts'][j] for i,j in ((0,1),(0,2),(1,2)))+isqrt(rad(p))),
          lambda p:sq(rad(p)),lambda r:dict(intercepts=list(r.choice(triples))),
          constraints=['(ab)²+(ac)²+(bc)² is a perfect square. Radius follows 3V/surface_area.'])
    if key=='geometry/train/108':
        return T('pole_similar_triangles',dict(distance=30,walked=25,height=15),{'distance':I(2,200),'walked':I(1,199),'height':I(8,22)},
          lambda p:f"A cable connects the top of a vertical pole to the ground {F(p['distance'],10)} m from its base. Walking from the base toward that ground point, a person of height {F(p['height'],10)} m touches the cable with their head after {F(p['walked'],10)} m. Find the pole's height in metres.",
          lambda p:F(p['height']*p['distance'],10*(p['distance']-p['walked'])),lambda p:p['walked']<p['distance'],
          constraints=['All input lengths use integer tenths of a metre; 0 < walked < distance.'])
    if key=='geometry/train/268':
        return T('coordinate_parallelogram_area',dict(base=6,height=8,shear=2,x=0,y=0),{'base':I(1,50),'height':I(1,50),'shear':I(-30,30),'x':I(-20,20),'y':I(-20,20)},
          lambda p:f"Find the area of the parallelogram whose vertex set is {vec([p['x'],p['y']])}, {vec([p['x']+p['base'],p['y']])}, {vec([p['x']+p['shear'],p['y']+p['height']])}, {vec([p['x']+p['base']+p['shear'],p['y']+p['height']])}.",
          lambda p:p['base']*p['height'])
    if key=='geometry/test/97':
        def cube(v):
            n=1
            while n**3<v:n+=1
            return n
        return T('cube_surface_from_volume',dict(millivolume=27),{'millivolume':I(1,1000000)},
          lambda p:f"A cube has volume {F(p['millivolume'],1000)} cubic metres. Find its surface area in square metres.",
          lambda p:F(6*cube(p['millivolume'])**2,100),lambda p:cube(p['millivolume'])**3==p['millivolume'],
          lambda r:dict(millivolume=r.randint(1,100)**3),constraints=['Volume in thousandths is a positive perfect cube.'])
    if key=='geometry/test/144':
        return T('yarn_volume_ratio',dict(small=6,large=12),{'small':I(1,30),'large':I(2,120)},
          lambda p:f"A spherical yarn ball of diameter {p['small']} inches makes one pair of mittens. How many pairs can a ball of the same yarn and density with diameter {p['large']} inches make?",
          lambda p:(p['large']**3)//(p['small']**3),lambda p:p['large']>p['small'] and p['large']%p['small']==0,
          lambda r:(lambda s,k:dict(small=s,large=s*k))(r.randint(1,20),r.randint(2,6)),
          constraints=['large is an integer multiple >1 of small, giving a whole number of pairs.'])
    if key=='geometry/test/152':
        return T('odd_polygon_middle_angle',dict(sides=5),{'sides':{'type':'int','choices':list(range(3,22,2))}},
          lambda p:f"A convex polygon has {p['sides']} distinct interior angles forming an arithmetic progression when sorted. Find the middle angle in degrees.",lambda p:F(180*(p['sides']-2),p['sides']))
    if key=='geometry/test/325':
        return T('inscribed_sphere_cube_volume',dict(numerator=1,denominator=6),{'numerator':I(1,100),'denominator':I(1,100)},
          lambda p:rf"A sphere inscribed in a cube has volume $({F(p['numerator'],p['denominator'])})\pi$ cubic inches. Find the cube's volume in cubic inches.",lambda p:F(6*p['numerator'],p['denominator']))
    if key=='geometry/test/327':
        return T('prism_volume_fraction',dict(a=1,b=4,c=1,d=2),{k:I(1,30) for k in 'abcd'},
          lambda p:f"A smaller right rectangular prism has base area {F(p['a'],p['b'])} times the base area of a larger right rectangular prism and height {F(p['c'],p['d'])} times the larger prism's height. Find the volume of the smaller prism divided by the volume of the larger prism.",
          lambda p:F(p['a']*p['c'],p['b']*p['d']),lambda p:p['a']<p['b'] and p['c']<p['d'],
          constraints=['Both area and height fractions are strictly between zero and one.'])
    return None
