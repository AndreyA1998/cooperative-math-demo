"""Bind source IDs to exact mathematical models in deterministic priority order."""
from functools import lru_cache
from copy import deepcopy
import importlib
from source_dataset.loader import load_corpus
from .core import canonical_answer, instantiate, validate_parameters, VERSION


# Module paths express mathematical subjects. Routes express the model's binding
# mechanism; their order is part of deterministic source-ID ownership.
_DIRECT_MODULES = (
    'algebra.equations_and_expressions',
    'discrete.counting_and_congruences',
    'geometry.euclidean_and_coordinate_models',
    'arithmetic.numeric_expressions',
    'word_problems.rounding_statistics_and_progressions',
    'discrete.divisibility_and_prime_ranges',
    'word_problems.rates_proportions_and_costs',
    'algebra.inequalities_and_function_properties',
    'algebra.symbolic_forms',
    'discrete.finite_counts_and_number_models',
    'word_problems.arithmetic_story_models',
    'precalculus.trigonometry_and_linear_algebra',
    'precalculus.geometric_constraints_and_branch_counts',
)
_ROUTES = tuple((name, 'direct', (name,), {}) for name in _DIRECT_MODULES) + (
    ('algebra.exact_roots_and_identities', 'chain', (
        'algebra.real_roots', 'algebra.extrema', 'algebra.symmetric_identities',
        'algebra.polynomial_operations', 'algebra.symbolic_evaluation',
        'algebra.root_identities_and_vertices',
    ), {'order': (0, 5, 4, 3, 2, 1)}),
    ('discrete.bound_models', 'copy_tables', (
        'discrete.probability_and_combinatorial_models', 'discrete.digits_and_radices',
        'discrete.inverse_congruences', 'discrete.modular_models',
        'discrete.primes_and_perfect_powers',
    ), {'tables': ((0, 'TRAIN'), (0, 'TEST'), (1, 'TRAIN'), (1, 'TEST'),
                  (3, 'TRAIN'), (3, 'TEST'), (4, 'TRAIN'), (4, 'TEST'), (2, 'TRAIN'))}),
    ('word_problems.bound_models', 'copy_tables', (
        'word_problems.finite_counts', 'word_problems.place_values_and_numbers',
        'word_problems.physical_quantities', 'word_problems.expressions',
        'word_problems.rates_and_proportions',
    ), {'tables': tuple((i, 'CASES') for i in range(5)), 'reject_overlap': True}),
    ('precalculus.constructive_models', 'chain', (
        'geometry.constructive_euclidean_models', 'precalculus.vector_spaces_and_minima',
        'precalculus.exact_trigonometry', 'precalculus.inverse_matrices_and_eigendirections',
        'precalculus.angle_recurrences',
    ), {'subject': 'precalculus'}),
    ('geometry.equiangular_hexagons', 'direct', ('geometry.equiangular_hexagons',), {}),
    ('algebra.parameter_bindings', 'factories', (
        'algebra.linear_rational_and_affine_models', 'algebra.scalar_identities',
        'algebra.common_base_powers', 'algebra.quadratic_constraints',
        'algebra.progressions', 'word_problems.affine_models',
    ), {'subject': 'algebra', 'prefix': 'algebra/'}),
    ('intermediate_algebra.format_bindings', 'shared', (
        'intermediate_algebra.sequences_complex_numbers_and_inequalities',
        'intermediate_algebra.polynomial_logarithmic_and_integer_equations',
        'geometry.conics_and_curve_areas',
    ), {'shared': 'intermediate_algebra.format_bindings'}),
    ('mixed.subject_bindings', 'subject_tables', (
        'arithmetic.finite_integer_and_radical_models',
        'precalculus.determinants_vectors_and_planes',
        'precalculus.trigonometric_products_and_complex_powers',
    ), {'prefixes': ('prealgebra/', 'precalculus/', 'precalculus/')}),
    ('algebra.given_bindings', 'indexed_factories', (
        'arithmetic.rounding_and_integer_arithmetic',
        'algebra.linear_rational_and_integer_equations',
        'algebra.function_composition_and_inverses',
        'geometry.coordinate_and_perimeter_models',
        'algebra.exponential_equations_and_power_functions',
        'algebra.quadratic_roots_and_common_factors',
        'algebra.sequences_growth_and_sum_inversion',
    ), {'prefix': 'algebra/train/'}),
    ('algebra.source_spans', 'indexed_builders', (
        'arithmetic.operations_and_integer_inequalities',
        'algebra.function_iterations_and_identities',
        'discrete.sequences_and_finite_counts',
        'algebra.linear_rational_and_quadratic_equations',
        'algebra.coefficient_matching_and_factorization',
        'geometry.cartesian_distance_models',
        'algebra.radicals_and_nested_expressions',
        'word_problems.decimal_rates_and_word_equations',
    ), {'subject': 'algebra', 'split': 'test',
        'specials': {260: (1, 'symbols'), 388: (1, 'rational_powers')}}),
    ('intermediate_algebra.callable_bindings', 'shared', (
        'intermediate_algebra.sums_products_and_logarithms',
        'intermediate_algebra.gaussian_integers_and_norms',
        'intermediate_algebra.polynomial_quotients_and_rational_graphs',
        'intermediate_algebra.equations_and_elementary_extrema',
        'intermediate_algebra.symbolic_invariants',
        'intermediate_algebra.real_equations_and_sequence_constraints',
        'intermediate_algebra.constrained_systems_and_stationary_points',
        'intermediate_algebra.surds_and_exponential_equations',
        'intermediate_algebra.series_counts_and_integer_recurrences',
    ), {'shared': 'intermediate_algebra.callable_bindings'}),
    ('precalculus.geometric_and_trigonometric_invariants', 'direct',
     ('precalculus.geometric_and_trigonometric_invariants',), {}),
    ('geometry.conics_extrema_and_pascal_reconstruction', 'direct',
     ('geometry.conics_extrema_and_pascal_reconstruction',), {}),
)
BUILDER_NAMES = tuple(name for name, _, _, _ in _ROUTES)


def _family_module(name):
    return importlib.import_module('.families.' + name, 'template_dataset')


class _Builder:
    """A lazy registry route over mathematical builders or explicit ID tables."""

    def __init__(self, name, strategy, paths, options):
        self.name, self.strategy, self.options = name, strategy, options
        self.modules = tuple(_family_module(path) for path in paths)
        self.bindings = {}
        if strategy == 'copy_tables':
            for index, table in options['tables']:
                models = getattr(self.modules[index], table)
                overlap = self.bindings.keys() & models.keys()
                if options.get('reject_overlap') and overlap:
                    raise ValueError(f'Duplicate word problem bindings: {sorted(overlap)}')
                self.bindings.update(models)
        elif strategy == 'factories':
            for module in self.modules:
                self.bindings.update(module.BINDINGS)
        elif strategy == 'shared':
            # Registration modules above must run before the shared table is read.
            self.bindings = _family_module(options['shared'])._BINDINGS
        elif strategy == 'subject_tables':
            for prefix, module in zip(options['prefixes'], self.modules):
                self.bindings.update((prefix + key, value) for key, value in module.BINDINGS.items())
        self.ids = tuple(self.bindings)

    def build(self, row):
        options = self.options
        if 'subject' in options and row.get('subject') != options['subject']:
            return None
        if 'split' in options and row.get('split') != options['split']:
            return None
        if self.strategy == 'direct':
            return self.modules[0].build(row)
        if self.strategy == 'copy_tables':
            model = self.bindings.get(row['id'])
            return deepcopy(model) if model is not None else None
        if self.strategy in ('shared', 'subject_tables'):
            return self.bindings.get(row['id'])
        if self.strategy == 'factories':
            factory = self.bindings.get(row['id'].removeprefix(options['prefix']))
            return factory() if factory else None
        if self.strategy == 'indexed_factories':
            prefix = options['prefix']
            if not row['id'].startswith(prefix):
                return None
            number = int(row['id'][len(prefix):])
            for module in self.modules:
                factory = module.BINDINGS.get(number)
                if factory is not None:
                    return factory()
            return None
        if self.strategy == 'indexed_builders':
            number = int(row['id'].rsplit('/', 1)[-1])
            if number in options['specials']:
                index, function = options['specials'][number]
                return getattr(self.modules[index], function)(row)
            for module in self.modules:
                result = module.build(row, number)
                if result is not None:
                    return result
            return None
        for index in options.get('order', range(len(self.modules))):
            result = self.modules[index].build(row)
            if result is not None:
                return result
        return None


@lru_cache(maxsize=1)
def _builders():
    return tuple(_Builder(*route) for route in _ROUTES)


def _get_builder(name):
    return next(builder for builder in _builders() if builder.name == name)


class UnsupportedProblemError(ValueError):
    pass


@lru_cache(maxsize=None)
def _bind_id(problem_id):
    """Validate and cache only this source row; unsupported rows cache None."""
    row=load_corpus()[problem_id]
    for module in _builders():
        template=module.build(row)
        if template is None:continue
        if not validate_parameters(template,template.original):
            raise ValueError(f'{problem_id}: original parameters outside domain ({template.family})')
        if canonical_answer(template.solve(template.original))!=canonical_answer(row['answer']):
            raise ValueError(f'{problem_id}: source answer regression ({template.family})')
        from template_dataset.families.reformulations import reformulate
        return reformulate(problem_id, template)
    return None


@lru_cache(maxsize=1)
def registry():
    """The full catalogue, sharing exactly the same bindings as single-ID calls."""
    result={}
    for problem_id in load_corpus():
        template=_bind_id(problem_id)
        if template is not None:result[problem_id]=template
    return result


def get_template(problem_id):
    if problem_id not in load_corpus():raise KeyError(f'Unknown source ID: {problem_id}')
    template=_bind_id(problem_id)
    if template is None:
        raise UnsupportedProblemError(f'{problem_id}: no verified parameterized family')
    return template


def generate(problem_id, seed):
    return instantiate(load_corpus()[problem_id],get_template(problem_id),seed)


def solve(problem_id, parameters):
    t=get_template(problem_id)
    if not validate_parameters(t,parameters):
        raise ValueError('Parameters violate declared domains or joint constraints; use describe(id)')
    return canonical_answer(t.solve(parameters))


def describe(problem_id):
    t=get_template(problem_id);r=load_corpus()[problem_id]
    result = {'id':problem_id,'split':r['split'],'subject':r['subject'],
            'family':t.family,'generator_version':VERSION,'parameters':t.parameters,
            'constraints':t.constraints,'original_parameters':t.original,
            'original_rendered':t.render(t.original),'adaptation':t.adaptation,
            'has_reference':t.reference is not None, 'answer_type':'exact rational scalar'}
    if hasattr(t, 'reformulation'):
        result['reformulated'] = True
        result['reformulation'] = deepcopy(t.reformulation)
    return deepcopy(result)
