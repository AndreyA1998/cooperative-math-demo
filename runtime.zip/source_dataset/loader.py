"""Read the immutable patched corpus, without acquisition or patching code."""
from functools import lru_cache
import json
from pathlib import Path

SOURCE_ROOT = Path(__file__).resolve().parent
REPOSITORY_ROOT = SOURCE_ROOT.parent


@lru_cache(maxsize=1)
def load_corpus():
    rows = {}
    for split in ('train', 'test'):
        directory = SOURCE_ROOT / split
        answers = {r['id']:r for r in (json.loads(s) for s in (directory/'answers.jsonl').read_text().splitlines())}
        for line in (directory/'problems.jsonl').read_text().splitlines():
            row = json.loads(line)
            if row['id'] in rows: raise ValueError('Duplicate source ID')
            row.update(answers.pop(row['id']))
            row['split'] = split
            rows[row['id']] = row
        if answers: raise ValueError('Unmatched source answers')
    return rows
